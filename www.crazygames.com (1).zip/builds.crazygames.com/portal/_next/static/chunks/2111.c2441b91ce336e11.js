!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "9f4b2204-1cc7-45e8-96e6-f38b56639438"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-9f4b2204-1cc7-45e8-96e6-f38b56639438"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2111],
    {
      31365: function (e, t, n) {
        e.exports = n(13608);
      },
      83454: function (e, t, n) {
        "use strict";
        var r, a;
        e.exports =
          (null == (r = n.g.process) ? void 0 : r.env) &&
          "object" == typeof (null == (a = n.g.process) ? void 0 : a.env)
            ? n.g.process
            : n(77663);
      },
      13608: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.SYSTEM_ENTRYPOINTS =
            t.EDGE_UNSUPPORTED_NODE_APIS =
            t.RSC_MODULE_TYPES =
            t.TURBO_TRACE_DEFAULT_MEMORY_LIMIT =
            t.TRACE_OUTPUT_VERSION =
            t.STATIC_STATUS_PAGES =
            t.DEFAULT_SANS_SERIF_FONT =
            t.DEFAULT_SERIF_FONT =
            t.OPTIMIZED_FONT_PROVIDERS =
            t.GOOGLE_FONT_PROVIDER =
            t.SERVER_PROPS_ID =
            t.STATIC_PROPS_ID =
            t.PERMANENT_REDIRECT_STATUS =
            t.TEMPORARY_REDIRECT_STATUS =
            t.EDGE_RUNTIME_WEBPACK =
            t.CLIENT_STATIC_FILES_RUNTIME_POLYFILLS_SYMBOL =
            t.CLIENT_STATIC_FILES_RUNTIME_POLYFILLS =
            t.CLIENT_STATIC_FILES_RUNTIME_WEBPACK =
            t.CLIENT_STATIC_FILES_RUNTIME_AMP =
            t.CLIENT_STATIC_FILES_RUNTIME_REACT_REFRESH =
            t.APP_CLIENT_INTERNALS =
            t.CLIENT_STATIC_FILES_RUNTIME_MAIN_APP =
            t.CLIENT_STATIC_FILES_RUNTIME_MAIN =
            t.MIDDLEWARE_REACT_LOADABLE_MANIFEST =
            t.MIDDLEWARE_BUILD_MANIFEST =
            t.SERVER_REFERENCE_MANIFEST =
            t.FLIGHT_SERVER_CSS_MANIFEST =
            t.CLIENT_REFERENCE_MANIFEST =
            t.NEXT_CLIENT_SSR_ENTRY_SUFFIX =
            t.NEXT_BUILTIN_DOCUMENT =
            t.MODERN_BROWSERSLIST_TARGET =
            t.STRING_LITERAL_DROP_BUNDLE =
            t.CLIENT_STATIC_FILES_RUNTIME =
            t.CLIENT_STATIC_FILES_PATH =
            t.CLIENT_PUBLIC_FILES_PATH =
            t.BLOCKED_PAGES =
            t.BUILD_ID_FILE =
            t.CONFIG_FILES =
            t.SERVER_DIRECTORY =
            t.FONT_MANIFEST =
            t.REACT_LOADABLE_MANIFEST =
            t.DEV_MIDDLEWARE_MANIFEST =
            t.MIDDLEWARE_MANIFEST =
            t.DEV_CLIENT_PAGES_MANIFEST =
            t.SERVER_FILES_MANIFEST =
            t.IMAGES_MANIFEST =
            t.ROUTES_MANIFEST =
            t.PRERENDER_MANIFEST =
            t.EXPORT_DETAIL =
            t.EXPORT_MARKER =
            t.NEXT_FONT_MANIFEST =
            t.SUBRESOURCE_INTEGRITY_MANIFEST =
            t.APP_BUILD_MANIFEST =
            t.BUILD_MANIFEST =
            t.APP_PATH_ROUTES_MANIFEST =
            t.APP_PATHS_MANIFEST =
            t.PAGES_MANIFEST =
            t.PHASE_TEST =
            t.PHASE_DEVELOPMENT_SERVER =
            t.PHASE_PRODUCTION_SERVER =
            t.PHASE_PRODUCTION_BUILD =
            t.PHASE_EXPORT =
            t.COMPILER_INDEXES =
            t.COMPILER_NAMES =
              void 0);
        let n = {
          client: "client",
          server: "server",
          edgeServer: "edge-server",
        };
        t.COMPILER_NAMES = n;
        let r = { [n.client]: 0, [n.server]: 1, [n.edgeServer]: 2 };
        (t.COMPILER_INDEXES = r),
          (t.PHASE_EXPORT = "phase-export"),
          (t.PHASE_PRODUCTION_BUILD = "phase-production-build"),
          (t.PHASE_PRODUCTION_SERVER = "phase-production-server"),
          (t.PHASE_DEVELOPMENT_SERVER = "phase-development-server"),
          (t.PHASE_TEST = "phase-test"),
          (t.PAGES_MANIFEST = "pages-manifest.json"),
          (t.APP_PATHS_MANIFEST = "app-paths-manifest.json"),
          (t.APP_PATH_ROUTES_MANIFEST = "app-path-routes-manifest.json"),
          (t.BUILD_MANIFEST = "build-manifest.json"),
          (t.APP_BUILD_MANIFEST = "app-build-manifest.json"),
          (t.SUBRESOURCE_INTEGRITY_MANIFEST = "subresource-integrity-manifest"),
          (t.NEXT_FONT_MANIFEST = "next-font-manifest"),
          (t.EXPORT_MARKER = "export-marker.json"),
          (t.EXPORT_DETAIL = "export-detail.json"),
          (t.PRERENDER_MANIFEST = "prerender-manifest.json"),
          (t.ROUTES_MANIFEST = "routes-manifest.json"),
          (t.IMAGES_MANIFEST = "images-manifest.json"),
          (t.SERVER_FILES_MANIFEST = "required-server-files.json"),
          (t.DEV_CLIENT_PAGES_MANIFEST = "_devPagesManifest.json"),
          (t.MIDDLEWARE_MANIFEST = "middleware-manifest.json"),
          (t.DEV_MIDDLEWARE_MANIFEST = "_devMiddlewareManifest.json"),
          (t.REACT_LOADABLE_MANIFEST = "react-loadable-manifest.json"),
          (t.FONT_MANIFEST = "font-manifest.json"),
          (t.SERVER_DIRECTORY = "server"),
          (t.CONFIG_FILES = ["next.config.js", "next.config.mjs"]),
          (t.BUILD_ID_FILE = "BUILD_ID"),
          (t.BLOCKED_PAGES = ["/_document", "/_app", "/_error"]),
          (t.CLIENT_PUBLIC_FILES_PATH = "public"),
          (t.CLIENT_STATIC_FILES_PATH = "static"),
          (t.CLIENT_STATIC_FILES_RUNTIME = "runtime"),
          (t.STRING_LITERAL_DROP_BUNDLE = "__NEXT_DROP_CLIENT_FILE__"),
          (t.MODERN_BROWSERSLIST_TARGET = [
            "chrome 64",
            "edge 79",
            "firefox 67",
            "opera 51",
            "safari 12",
          ]),
          (t.NEXT_BUILTIN_DOCUMENT = "__NEXT_BUILTIN_DOCUMENT__"),
          (t.NEXT_CLIENT_SSR_ENTRY_SUFFIX = ".__sc_client__"),
          (t.CLIENT_REFERENCE_MANIFEST = "client-reference-manifest"),
          (t.FLIGHT_SERVER_CSS_MANIFEST = "flight-server-css-manifest"),
          (t.SERVER_REFERENCE_MANIFEST = "server-reference-manifest"),
          (t.MIDDLEWARE_BUILD_MANIFEST = "middleware-build-manifest"),
          (t.MIDDLEWARE_REACT_LOADABLE_MANIFEST =
            "middleware-react-loadable-manifest");
        let a = "main";
        t.CLIENT_STATIC_FILES_RUNTIME_MAIN = a;
        let i = `${a}-app`;
        (t.CLIENT_STATIC_FILES_RUNTIME_MAIN_APP = i),
          (t.APP_CLIENT_INTERNALS = "app-client-internals");
        let o = "react-refresh";
        (t.CLIENT_STATIC_FILES_RUNTIME_REACT_REFRESH = o),
          (t.CLIENT_STATIC_FILES_RUNTIME_AMP = "amp"),
          (t.CLIENT_STATIC_FILES_RUNTIME_WEBPACK = "webpack");
        let s = "polyfills";
        t.CLIENT_STATIC_FILES_RUNTIME_POLYFILLS = s;
        let l = Symbol(s);
        (t.CLIENT_STATIC_FILES_RUNTIME_POLYFILLS_SYMBOL = l),
          (t.EDGE_RUNTIME_WEBPACK = "edge-runtime-webpack"),
          (t.TEMPORARY_REDIRECT_STATUS = 307),
          (t.PERMANENT_REDIRECT_STATUS = 308),
          (t.STATIC_PROPS_ID = "__N_SSG"),
          (t.SERVER_PROPS_ID = "__N_SSP");
        let u = "https://fonts.googleapis.com/";
        (t.GOOGLE_FONT_PROVIDER = u),
          (t.OPTIMIZED_FONT_PROVIDERS = [
            { url: u, preconnect: "https://fonts.gstatic.com" },
            {
              url: "https://use.typekit.net",
              preconnect: "https://use.typekit.net",
            },
          ]),
          (t.DEFAULT_SERIF_FONT = {
            name: "Times New Roman",
            xAvgCharWidth: 821,
            azAvgWidth: 854.3953488372093,
            unitsPerEm: 2048,
          }),
          (t.DEFAULT_SANS_SERIF_FONT = {
            name: "Arial",
            xAvgCharWidth: 904,
            azAvgWidth: 934.5116279069767,
            unitsPerEm: 2048,
          }),
          (t.STATIC_STATUS_PAGES = ["/500"]),
          (t.TRACE_OUTPUT_VERSION = 1),
          (t.TURBO_TRACE_DEFAULT_MEMORY_LIMIT = 6e3),
          (t.RSC_MODULE_TYPES = { client: "client", server: "server" }),
          (t.EDGE_UNSUPPORTED_NODE_APIS = [
            "clearImmediate",
            "setImmediate",
            "BroadcastChannel",
            "Buffer",
            "ByteLengthQueuingStrategy",
            "CompressionStream",
            "CountQueuingStrategy",
            "DecompressionStream",
            "DomException",
            "MessageChannel",
            "MessageEvent",
            "MessagePort",
            "ReadableByteStreamController",
            "ReadableStreamBYOBRequest",
            "ReadableStreamDefaultController",
            "TextDecoderStream",
            "TextEncoderStream",
            "TransformStreamDefaultController",
            "WritableStreamDefaultController",
          ]);
        let c = new Set([a, o, "amp", i]);
        (t.SYSTEM_ENTRYPOINTS = c),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      77663: function (e) {
        !(function () {
          var t = {
              229: function (e) {
                var t,
                  n,
                  r,
                  a = (e.exports = {});
                function i() {
                  throw Error("setTimeout has not been defined");
                }
                function o() {
                  throw Error("clearTimeout has not been defined");
                }
                function s(e) {
                  if (t === setTimeout) return setTimeout(e, 0);
                  if ((t === i || !t) && setTimeout)
                    return (t = setTimeout), setTimeout(e, 0);
                  try {
                    return t(e, 0);
                  } catch (n) {
                    try {
                      return t.call(null, e, 0);
                    } catch (n) {
                      return t.call(this, e, 0);
                    }
                  }
                }
                !(function () {
                  try {
                    t = "function" == typeof setTimeout ? setTimeout : i;
                  } catch (e) {
                    t = i;
                  }
                  try {
                    n = "function" == typeof clearTimeout ? clearTimeout : o;
                  } catch (e) {
                    n = o;
                  }
                })();
                var l = [],
                  u = !1,
                  c = -1;
                function d() {
                  u &&
                    r &&
                    ((u = !1),
                    r.length ? (l = r.concat(l)) : (c = -1),
                    l.length && p());
                }
                function p() {
                  if (!u) {
                    var e = s(d);
                    u = !0;
                    for (var t = l.length; t; ) {
                      for (r = l, l = []; ++c < t; ) r && r[c].run();
                      (c = -1), (t = l.length);
                    }
                    (r = null),
                      (u = !1),
                      (function (e) {
                        if (n === clearTimeout) return clearTimeout(e);
                        if ((n === o || !n) && clearTimeout)
                          return (n = clearTimeout), clearTimeout(e);
                        try {
                          n(e);
                        } catch (t) {
                          try {
                            return n.call(null, e);
                          } catch (t) {
                            return n.call(this, e);
                          }
                        }
                      })(e);
                  }
                }
                function f(e, t) {
                  (this.fun = e), (this.array = t);
                }
                function h() {}
                (a.nextTick = function (e) {
                  var t = Array(arguments.length - 1);
                  if (arguments.length > 1)
                    for (var n = 1; n < arguments.length; n++)
                      t[n - 1] = arguments[n];
                  l.push(new f(e, t)), 1 !== l.length || u || s(p);
                }),
                  (f.prototype.run = function () {
                    this.fun.apply(null, this.array);
                  }),
                  (a.title = "browser"),
                  (a.browser = !0),
                  (a.env = {}),
                  (a.argv = []),
                  (a.version = ""),
                  (a.versions = {}),
                  (a.on = h),
                  (a.addListener = h),
                  (a.once = h),
                  (a.off = h),
                  (a.removeListener = h),
                  (a.removeAllListeners = h),
                  (a.emit = h),
                  (a.prependListener = h),
                  (a.prependOnceListener = h),
                  (a.listeners = function (e) {
                    return [];
                  }),
                  (a.binding = function (e) {
                    throw Error("process.binding is not supported");
                  }),
                  (a.cwd = function () {
                    return "/";
                  }),
                  (a.chdir = function (e) {
                    throw Error("process.chdir is not supported");
                  }),
                  (a.umask = function () {
                    return 0;
                  });
              },
            },
            n = {};
          function r(e) {
            var a = n[e];
            if (void 0 !== a) return a.exports;
            var i = (n[e] = { exports: {} }),
              o = !0;
            try {
              t[e](i, i.exports, r), (o = !1);
            } finally {
              o && delete n[e];
            }
            return i.exports;
          }
          r.ab = "//";
          var a = r(229);
          e.exports = a;
        })();
      },
      12016: function (e, t, n) {
        "use strict";
        n.d(t, {
          X: function () {
            return r;
          },
        });
        let r = !1;
      },
      39877: function (e, t, n) {
        "use strict";
        n.d(t, {
          L2: function () {
            return l;
          },
          _6: function () {
            return u;
          },
          iK: function () {
            return c;
          },
        });
        var r = n(18409),
          a = n(17986),
          i = n(12016),
          o = n(23039);
        let s = {};
        function l(e) {
          let t = s[e];
          if (t) return t;
          let n = o.m[e];
          if ((0, r.QC)(n)) return (s[e] = n.bind(o.m));
          let l = o.m.document;
          if (l && "function" == typeof l.createElement)
            try {
              let t = l.createElement("iframe");
              (t.hidden = !0), l.head.appendChild(t);
              let r = t.contentWindow;
              r && r[e] && (n = r[e]), l.head.removeChild(t);
            } catch (t) {
              i.X &&
                a.kg.warn(
                  `Could not create sandbox iframe for ${e} check, bailing to window.${e}: `,
                  t
                );
            }
          return n ? (s[e] = n.bind(o.m)) : n;
        }
        function u(e) {
          s[e] = void 0;
        }
        function c(...e) {
          return l("setTimeout")(...e);
        }
      },
      25460: function (e, t, n) {
        "use strict";
        let r, a, i;
        n.d(t, {
          O: function () {
            return c;
          },
        });
        var o = n(84105),
          s = n(51150),
          l = n(82305),
          u = n(23039);
        function c(e) {
          (0, o.Hj)("dom", e), (0, o.D2)("dom", d);
        }
        function d() {
          if (!u.m.document) return;
          let e = o.rK.bind(null, "dom"),
            t = p(e, !0);
          u.m.document.addEventListener("click", t, !1),
            u.m.document.addEventListener("keypress", t, !1),
            ["EventTarget", "Node"].forEach((t) => {
              let n = u.m,
                r = n[t],
                a = r && r.prototype;
              a &&
                a.hasOwnProperty &&
                a.hasOwnProperty("addEventListener") &&
                ((0, s.hl)(a, "addEventListener", function (t) {
                  return function (n, r, a) {
                    if ("click" === n || "keypress" == n)
                      try {
                        let r = (this.__sentry_instrumentation_handlers__ =
                            this.__sentry_instrumentation_handlers__ || {}),
                          i = (r[n] = r[n] || { refCount: 0 });
                        if (!i.handler) {
                          let r = p(e);
                          (i.handler = r), t.call(this, n, r, a);
                        }
                        i.refCount++;
                      } catch (e) {}
                    return t.call(this, n, r, a);
                  };
                }),
                (0, s.hl)(a, "removeEventListener", function (e) {
                  return function (t, n, r) {
                    if ("click" === t || "keypress" == t)
                      try {
                        let n = this.__sentry_instrumentation_handlers__ || {},
                          a = n[t];
                        a &&
                          (a.refCount--,
                          a.refCount <= 0 &&
                            (e.call(this, t, a.handler, r),
                            (a.handler = void 0),
                            delete n[t]),
                          0 === Object.keys(n).length &&
                            delete this.__sentry_instrumentation_handlers__);
                      } catch (e) {}
                    return e.call(this, t, n, r);
                  };
                }));
            });
        }
        function p(e, t = !1) {
          return (n) => {
            if (!n || n._sentryCaptured) return;
            let o = (function (e) {
              try {
                return e.target;
              } catch (e) {
                return null;
              }
            })(n);
            if (
              "keypress" === n.type &&
              (!o ||
                !o.tagName ||
                ("INPUT" !== o.tagName &&
                  "TEXTAREA" !== o.tagName &&
                  !o.isContentEditable))
            )
              return;
            (0, s.xp)(n, "_sentryCaptured", !0),
              o && !o._sentryId && (0, s.xp)(o, "_sentryId", (0, l.DM)());
            let c = "keypress" === n.type ? "input" : n.type;
            !(function (e) {
              if (e.type !== a) return !1;
              try {
                if (!e.target || e.target._sentryId !== i) return !1;
              } catch (e) {}
              return !0;
            })(n) &&
              (e({ event: n, name: c, global: t }),
              (a = n.type),
              (i = o ? o._sentryId : void 0)),
              clearTimeout(r),
              (r = u.m.setTimeout(() => {
                (i = void 0), (a = void 0);
              }, 1e3));
          };
        }
      },
      42886: function (e, t, n) {
        "use strict";
        let r;
        n.d(t, {
          a: function () {
            return u;
          },
        });
        var a = n(84105),
          i = n(33280);
        let o = i.n;
        var s = n(51150),
          l = n(23039);
        function u(e) {
          let t = "history";
          (0, a.Hj)(t, e), (0, a.D2)(t, c);
        }
        function c() {
          if (
            !(function () {
              let e = o.chrome,
                t = e && e.app && e.app.runtime,
                n =
                  "history" in o &&
                  !!o.history.pushState &&
                  !!o.history.replaceState;
              return !t && n;
            })()
          )
            return;
          let e = l.m.onpopstate;
          function t(e) {
            return function (...t) {
              let n = t.length > 2 ? t[2] : void 0;
              if (n) {
                let e = r,
                  t = String(n);
                (r = t), (0, a.rK)("history", { from: e, to: t });
              }
              return e.apply(this, t);
            };
          }
          (l.m.onpopstate = function (...t) {
            let n = l.m.location.href,
              i = r;
            if (((r = n), (0, a.rK)("history", { from: i, to: n }), e))
              try {
                return e.apply(this, t);
              } catch (e) {}
          }),
            (0, s.hl)(l.m.history, "pushState", t),
            (0, s.hl)(l.m.history, "replaceState", t);
        }
      },
      67127: function (e, t, n) {
        "use strict";
        n.d(t, {
          UK: function () {
            return l;
          },
          xU: function () {
            return s;
          },
        });
        var r = n(84105),
          a = n(59943),
          i = n(24925),
          o = n(23039);
        let s = "__sentry_xhr_v3__";
        function l(e) {
          (0, r.Hj)("xhr", e), (0, r.D2)("xhr", u);
        }
        function u() {
          if (!o.m.XMLHttpRequest) return;
          let e = XMLHttpRequest.prototype;
          (e.open = new Proxy(e.open, {
            apply(e, t, n) {
              let o = 1e3 * (0, a.ph)(),
                l = (0, i.HD)(n[0]) ? n[0].toUpperCase() : void 0,
                u = (function (e) {
                  if ((0, i.HD)(e)) return e;
                  try {
                    return e.toString();
                  } catch (e) {}
                })(n[1]);
              if (!l || !u) return e.apply(t, n);
              (t[s] = { method: l, url: u, request_headers: {} }),
                "POST" === l &&
                  u.match(/sentry_key/) &&
                  (t.__sentry_own_request__ = !0);
              let c = () => {
                let e = t[s];
                if (e && 4 === t.readyState) {
                  try {
                    e.status_code = t.status;
                  } catch (e) {}
                  let n = {
                    endTimestamp: 1e3 * (0, a.ph)(),
                    startTimestamp: o,
                    xhr: t,
                  };
                  (0, r.rK)("xhr", n);
                }
              };
              return (
                "onreadystatechange" in t &&
                "function" == typeof t.onreadystatechange
                  ? (t.onreadystatechange = new Proxy(t.onreadystatechange, {
                      apply: (e, t, n) => (c(), e.apply(t, n)),
                    }))
                  : t.addEventListener("readystatechange", c),
                (t.setRequestHeader = new Proxy(t.setRequestHeader, {
                  apply(e, t, n) {
                    let [r, a] = n,
                      o = t[s];
                    return (
                      o &&
                        (0, i.HD)(r) &&
                        (0, i.HD)(a) &&
                        (o.request_headers[r.toLowerCase()] = a),
                      e.apply(t, n)
                    );
                  },
                })),
                e.apply(t, n)
              );
            },
          })),
            (e.send = new Proxy(e.send, {
              apply(e, t, n) {
                let i = t[s];
                if (!i) return e.apply(t, n);
                void 0 !== n[0] && (i.body = n[0]);
                let o = { startTimestamp: 1e3 * (0, a.ph)(), xhr: t };
                return (0, r.rK)("xhr", o), e.apply(t, n);
              },
            }));
        }
      },
      22480: function (e, t, n) {
        "use strict";
        let r, a, i, o, s, l;
        n.d(t, {
          PR: function () {
            return Q;
          },
          to: function () {
            return et;
          },
          YF: function () {
            return er;
          },
          $A: function () {
            return ee;
          },
          _j: function () {
            return ea;
          },
          _4: function () {
            return en;
          },
          cN: function () {
            return eh;
          },
        });
        var u = n(17986),
          c = n(39649),
          d = n(12016);
        let p = (e, t) =>
            e > t[1] ? "poor" : e > t[0] ? "needs-improvement" : "good",
          f = (e, t, n, r) => {
            let a, i;
            return (o) => {
              t.value >= 0 &&
                (o || r) &&
                ((i = t.value - (a || 0)) || void 0 === a) &&
                ((a = t.value),
                (t.delta = i),
                (t.rating = p(t.value, n)),
                e(t));
            };
          };
        var h = n(23039);
        let m = () =>
          `v4-${Date.now()}-${Math.floor(Math.random() * (9e12 - 1)) + 1e12}`;
        var _ = n(32599),
          g = n(74181);
        let v = (e, t) => {
            let n = (0, g.W)(),
              r = "navigate";
            return (
              n &&
                ((h.m.document && h.m.document.prerendering) || (0, _.A)() > 0
                  ? (r = "prerender")
                  : h.m.document && h.m.document.wasDiscarded
                  ? (r = "restore")
                  : n.type && (r = n.type.replace(/_/g, "-"))),
              {
                name: e,
                value: void 0 === t ? -1 : t,
                rating: "good",
                delta: 0,
                entries: [],
                id: m(),
                navigationType: r,
              }
            );
          },
          y = (e, t, n) => {
            try {
              if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                let r = new PerformanceObserver((e) => {
                  Promise.resolve().then(() => {
                    t(e.getEntries());
                  });
                });
                return (
                  r.observe(Object.assign({ type: e, buffered: !0 }, n || {})),
                  r
                );
              }
            } catch (e) {}
          };
        var b = n(30378);
        let E = (e) => {
          let t = !1;
          return () => {
            t || (e(), (t = !0));
          };
        };
        var S = n(49250);
        let w = (e) => {
            h.m.document && h.m.document.prerendering
              ? addEventListener("prerenderingchange", () => e(), !0)
              : e();
          },
          T = [1800, 3e3],
          x = (e, t = {}) => {
            w(() => {
              let n;
              let r = (0, S.Y)(),
                a = v("FCP"),
                i = (e) => {
                  e.forEach((e) => {
                    "first-contentful-paint" === e.name &&
                      (o.disconnect(),
                      e.startTime < r.firstHiddenTime &&
                        ((a.value = Math.max(e.startTime - (0, _.A)(), 0)),
                        a.entries.push(e),
                        n(!0)));
                  });
                },
                o = y("paint", i);
              o && (n = f(e, a, T, t.reportAllChanges));
            });
          },
          k = [0.1, 0.25],
          I = (e, t = {}) => {
            x(
              E(() => {
                let n;
                let r = v("CLS", 0),
                  a = 0,
                  i = [],
                  o = (e) => {
                    e.forEach((e) => {
                      if (!e.hadRecentInput) {
                        let t = i[0],
                          n = i[i.length - 1];
                        a &&
                        t &&
                        n &&
                        e.startTime - n.startTime < 1e3 &&
                        e.startTime - t.startTime < 5e3
                          ? ((a += e.value), i.push(e))
                          : ((a = e.value), (i = [e]));
                      }
                    }),
                      a > r.value && ((r.value = a), (r.entries = i), n());
                  },
                  s = y("layout-shift", o);
                s &&
                  ((n = f(e, r, k, t.reportAllChanges)),
                  (0, b.u)(() => {
                    o(s.takeRecords()), n(!0);
                  }),
                  setTimeout(n, 0));
              })
            );
          },
          C = [100, 300],
          A = (e, t = {}) => {
            w(() => {
              let n;
              let r = (0, S.Y)(),
                a = v("FID"),
                i = (e) => {
                  e.startTime < r.firstHiddenTime &&
                    ((a.value = e.processingStart - e.startTime),
                    a.entries.push(e),
                    n(!0));
                },
                o = (e) => {
                  e.forEach(i);
                },
                s = y("first-input", o);
              (n = f(e, a, C, t.reportAllChanges)),
                s &&
                  (0, b.u)(
                    E(() => {
                      o(s.takeRecords()), s.disconnect();
                    })
                  );
            });
          },
          R = 0,
          N = 1 / 0,
          P = 0,
          M = (e) => {
            e.forEach((e) => {
              e.interactionId &&
                ((N = Math.min(N, e.interactionId)),
                (R = (P = Math.max(P, e.interactionId)) ? (P - N) / 7 + 1 : 0));
            });
          },
          L = () => (r ? R : performance.interactionCount || 0),
          D = () => {
            "interactionCount" in performance ||
              r ||
              (r = y("event", M, {
                type: "event",
                buffered: !0,
                durationThreshold: 0,
              }));
          },
          O = [],
          $ = new Map(),
          F = () => L() - 0,
          U = () => {
            let e = Math.min(O.length - 1, Math.floor(F() / 50));
            return O[e];
          },
          j = [],
          H = (e) => {
            if (
              (j.forEach((t) => t(e)),
              !(e.interactionId || "first-input" === e.entryType))
            )
              return;
            let t = O[O.length - 1],
              n = $.get(e.interactionId);
            if (n || O.length < 10 || (t && e.duration > t.latency)) {
              if (n)
                e.duration > n.latency
                  ? ((n.entries = [e]), (n.latency = e.duration))
                  : e.duration === n.latency &&
                    e.startTime === (n.entries[0] && n.entries[0].startTime) &&
                    n.entries.push(e);
              else {
                let t = {
                  id: e.interactionId,
                  latency: e.duration,
                  entries: [e],
                };
                $.set(t.id, t), O.push(t);
              }
              O.sort((e, t) => t.latency - e.latency),
                O.length > 10 && O.splice(10).forEach((e) => $.delete(e.id));
            }
          },
          X = (e) => {
            let t = h.m.requestIdleCallback || h.m.setTimeout,
              n = -1;
            return (
              (e = E(e)),
              h.m.document && "hidden" === h.m.document.visibilityState
                ? e()
                : ((n = t(e)), (0, b.u)(e)),
              n
            );
          },
          B = [200, 500],
          W = (e, t = {}) => {
            "PerformanceEventTiming" in h.m &&
              "interactionId" in PerformanceEventTiming.prototype &&
              w(() => {
                let n;
                D();
                let r = v("INP"),
                  a = (e) => {
                    X(() => {
                      e.forEach(H);
                      let t = U();
                      t &&
                        t.latency !== r.value &&
                        ((r.value = t.latency), (r.entries = t.entries), n());
                    });
                  },
                  i = y("event", a, {
                    durationThreshold:
                      null != t.durationThreshold ? t.durationThreshold : 40,
                  });
                (n = f(e, r, B, t.reportAllChanges)),
                  i &&
                    (i.observe({ type: "first-input", buffered: !0 }),
                    (0, b.u)(() => {
                      a(i.takeRecords()), n(!0);
                    }));
              });
          },
          G = [2500, 4e3],
          q = {},
          Z = (e, t = {}) => {
            w(() => {
              let n;
              let r = (0, S.Y)(),
                a = v("LCP"),
                i = (e) => {
                  t.reportAllChanges || (e = e.slice(-1)),
                    e.forEach((e) => {
                      e.startTime < r.firstHiddenTime &&
                        ((a.value = Math.max(e.startTime - (0, _.A)(), 0)),
                        (a.entries = [e]),
                        n());
                    });
                },
                o = y("largest-contentful-paint", i);
              if (o) {
                n = f(e, a, G, t.reportAllChanges);
                let r = E(() => {
                  q[a.id] ||
                    (i(o.takeRecords()), o.disconnect(), (q[a.id] = !0), n(!0));
                });
                ["keydown", "click"].forEach((e) => {
                  h.m.document &&
                    addEventListener(e, () => X(r), { once: !0, capture: !0 });
                }),
                  (0, b.u)(r);
              }
            });
          },
          V = [800, 1800],
          Y = (e) => {
            h.m.document && h.m.document.prerendering
              ? w(() => Y(e))
              : h.m.document && "complete" !== h.m.document.readyState
              ? addEventListener("load", () => Y(e), !0)
              : setTimeout(e, 0);
          },
          z = (e, t = {}) => {
            let n = v("TTFB"),
              r = f(e, n, V, t.reportAllChanges);
            Y(() => {
              let e = (0, g.W)();
              e &&
                ((n.value = Math.max(e.responseStart - (0, _.A)(), 0)),
                (n.entries = [e]),
                r(!0));
            });
          },
          J = {},
          K = {};
        function Q(e, t = !1) {
          return ed("cls", e, eo, a, t);
        }
        function ee(e, t = !1) {
          return ed("lcp", e, el, o, t);
        }
        function et(e) {
          return ed("fid", e, es, i);
        }
        function en(e) {
          return ed("ttfb", e, eu, s);
        }
        function er(e) {
          return ed("inp", e, ec, l);
        }
        function ea(e, t) {
          return (
            ep(e, t),
            K[e] ||
              ((function (e) {
                let t = {};
                "event" === e && (t.durationThreshold = 0),
                  y(
                    e,
                    (t) => {
                      ei(e, { entries: t });
                    },
                    t
                  );
              })(e),
              (K[e] = !0)),
            ef(e, t)
          );
        }
        function ei(e, t) {
          let n = J[e];
          if (n && n.length)
            for (let r of n)
              try {
                r(t);
              } catch (t) {
                d.X &&
                  u.kg.error(
                    `Error while triggering instrumentation handler.
Type: ${e}
Name: ${(0, c.$P)(r)}
Error:`,
                    t
                  );
              }
        }
        function eo() {
          return I(
            (e) => {
              ei("cls", { metric: e }), (a = e);
            },
            { reportAllChanges: !0 }
          );
        }
        function es() {
          return A((e) => {
            ei("fid", { metric: e }), (i = e);
          });
        }
        function el() {
          return Z(
            (e) => {
              ei("lcp", { metric: e }), (o = e);
            },
            { reportAllChanges: !0 }
          );
        }
        function eu() {
          return z((e) => {
            ei("ttfb", { metric: e }), (s = e);
          });
        }
        function ec() {
          return W((e) => {
            ei("inp", { metric: e }), (l = e);
          });
        }
        function ed(e, t, n, r, a = !1) {
          let i;
          return (
            ep(e, t),
            K[e] || ((i = n()), (K[e] = !0)),
            r && t({ metric: r }),
            ef(e, t, a ? i : void 0)
          );
        }
        function ep(e, t) {
          (J[e] = J[e] || []), J[e].push(t);
        }
        function ef(e, t, n) {
          return () => {
            n && n();
            let r = J[e];
            if (!r) return;
            let a = r.indexOf(t);
            -1 !== a && r.splice(a, 1);
          };
        }
        function eh(e) {
          return "duration" in e;
        }
      },
      32599: function (e, t, n) {
        "use strict";
        n.d(t, {
          A: function () {
            return a;
          },
        });
        var r = n(74181);
        let a = () => {
          let e = (0, r.W)();
          return (e && e.activationStart) || 0;
        };
      },
      74181: function (e, t, n) {
        "use strict";
        n.d(t, {
          W: function () {
            return a;
          },
        });
        var r = n(23039);
        let a = (e = !0) => {
          let t =
            r.m.performance &&
            r.m.performance.getEntriesByType &&
            r.m.performance.getEntriesByType("navigation")[0];
          if (
            !e ||
            (t && t.responseStart > 0 && t.responseStart < performance.now())
          )
            return t;
        };
      },
      49250: function (e, t, n) {
        "use strict";
        n.d(t, {
          Y: function () {
            return u;
          },
        });
        var r = n(23039);
        let a = -1,
          i = () =>
            "hidden" !== r.m.document.visibilityState ||
            r.m.document.prerendering
              ? 1 / 0
              : 0,
          o = (e) => {
            "hidden" === r.m.document.visibilityState &&
              a > -1 &&
              ((a = "visibilitychange" === e.type ? e.timeStamp : 0), l());
          },
          s = () => {
            addEventListener("visibilitychange", o, !0),
              addEventListener("prerenderingchange", o, !0);
          },
          l = () => {
            removeEventListener("visibilitychange", o, !0),
              removeEventListener("prerenderingchange", o, !0);
          },
          u = () => (
            r.m.document && a < 0 && ((a = i()), s()),
            {
              get firstHiddenTime() {
                return a;
              },
            }
          );
      },
      30378: function (e, t, n) {
        "use strict";
        n.d(t, {
          u: function () {
            return a;
          },
        });
        var r = n(23039);
        let a = (e) => {
          let t = (t) => {
            ("pagehide" === t.type ||
              (r.m.document && "hidden" === r.m.document.visibilityState)) &&
              e(t);
          };
          r.m.document &&
            (addEventListener("visibilitychange", t, !0),
            addEventListener("pagehide", t, !0));
        };
      },
      23039: function (e, t, n) {
        "use strict";
        n.d(t, {
          m: function () {
            return a;
          },
        });
        var r = n(33280);
        let a = r.n;
      },
      37895: function (e, t, n) {
        "use strict";
        n.d(t, {
          n: function () {
            return o;
          },
        });
        var r = n(26318),
          a = n(17986),
          i = n(59943);
        function o(e, t) {
          let n = (0, r.s3)(),
            o = (0, r.aF)();
          if (!n) return;
          let { beforeBreadcrumb: s = null, maxBreadcrumbs: l = 100 } =
            n.getOptions();
          if (l <= 0) return;
          let u = (0, i.yW)(),
            c = { timestamp: u, ...e },
            d = s ? (0, a.Cf)(() => s(c, t)) : c;
          null !== d &&
            (n.emit && n.emit("beforeAddBreadcrumb", d, t),
            o.addBreadcrumb(d, l));
        }
      },
      3e4: function (e, t, n) {
        "use strict";
        function r(e, t) {
          return null != e ? e : t();
        }
        n.d(t, {
          h: function () {
            return r;
          },
        });
      },
      13539: function (e, t, n) {
        "use strict";
        function r(e) {
          let t;
          let n = e[0],
            r = 1;
          for (; r < e.length; ) {
            let a = e[r],
              i = e[r + 1];
            if (
              ((r += 2),
              ("optionalAccess" === a || "optionalCall" === a) && null == n)
            )
              return;
            "access" === a || "optionalAccess" === a
              ? ((t = n), (n = i(n)))
              : ("call" === a || "optionalCall" === a) &&
                ((n = i((...e) => n.call(t, ...e))), (t = void 0));
          }
          return n;
        }
        n.d(t, {
          x: function () {
            return r;
          },
        });
      },
      48600: function (e, t, n) {
        "use strict";
        n.d(t, {
          RA: function () {
            return o;
          },
          U4: function () {
            return s;
          },
          vK: function () {
            return u;
          },
        });
        var r = n(23187),
          a = n(17986);
        let i =
          /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;
        function o(e, t = !1) {
          let {
            host: n,
            path: r,
            pass: a,
            port: i,
            projectId: o,
            protocol: s,
            publicKey: l,
          } = e;
          return `${s}://${l}${t && a ? `:${a}` : ""}@${n}${i ? `:${i}` : ""}/${
            r ? `${r}/` : r
          }${o}`;
        }
        function s(e) {
          let t = i.exec(e);
          if (!t) {
            (0, a.Cf)(() => {
              console.error(`Invalid Sentry Dsn: ${e}`);
            });
            return;
          }
          let [n, r, o = "", s = "", u = "", c = ""] = t.slice(1),
            d = "",
            p = c,
            f = p.split("/");
          if (
            (f.length > 1 && ((d = f.slice(0, -1).join("/")), (p = f.pop())), p)
          ) {
            let e = p.match(/^\d+/);
            e && (p = e[0]);
          }
          return l({
            host: s,
            pass: o,
            path: d,
            projectId: p,
            port: u,
            protocol: n,
            publicKey: r,
          });
        }
        function l(e) {
          return {
            protocol: e.protocol,
            publicKey: e.publicKey || "",
            pass: e.pass || "",
            host: e.host,
            port: e.port || "",
            path: e.path || "",
            projectId: e.projectId,
          };
        }
        function u(e) {
          let t = "string" == typeof e ? s(e) : l(e);
          if (
            t &&
            (function (e) {
              if (!r.X) return !0;
              let { port: t, projectId: n, protocol: i } = e,
                o = ["protocol", "publicKey", "host", "projectId"].find(
                  (t) =>
                    !e[t] &&
                    (a.kg.error(`Invalid Sentry Dsn: ${t} missing`), !0)
                );
              return (
                !o &&
                (n.match(/^\d+$/)
                  ? "http" === i || "https" === i
                    ? !(t && isNaN(parseInt(t, 10))) ||
                      (a.kg.error(`Invalid Sentry Dsn: Invalid port ${t}`), !1)
                    : (a.kg.error(`Invalid Sentry Dsn: Invalid protocol ${i}`),
                      !1)
                  : (a.kg.error(`Invalid Sentry Dsn: Invalid projectId ${n}`),
                    !1))
              );
            })(t)
          )
            return t;
        }
      },
      77256: function (e, t, n) {
        "use strict";
        function r() {
          return (
            "undefined" != typeof __SENTRY_BROWSER_BUNDLE__ &&
            !!__SENTRY_BROWSER_BUNDLE__
          );
        }
        function a() {
          return "npm";
        }
        n.d(t, {
          S: function () {
            return a;
          },
          n: function () {
            return r;
          },
        });
      },
      46975: function (e, t, n) {
        "use strict";
        n.d(t, {
          BO: function () {
            return l;
          },
          Cd: function () {
            return y;
          },
          HY: function () {
            return v;
          },
          Jd: function () {
            return s;
          },
          KQ: function () {
            return h;
          },
          R: function () {
            return c;
          },
          V$: function () {
            return p;
          },
          f4: function () {
            return f;
          },
          gv: function () {
            return u;
          },
          mL: function () {
            return g;
          },
          zQ: function () {
            return m;
          },
        });
        var r = n(48600),
          a = n(90059),
          i = n(51150),
          o = n(33280);
        function s(e, t = []) {
          return [e, t];
        }
        function l(e, t) {
          let [n, r] = e;
          return [n, [...r, t]];
        }
        function u(e, t) {
          let n = e[1];
          for (let e of n) {
            let n = e[0].type,
              r = t(e, n);
            if (r) return !0;
          }
          return !1;
        }
        function c(e, t) {
          return u(e, (e, n) => t.includes(n));
        }
        function d(e) {
          return o.n.__SENTRY__ && o.n.__SENTRY__.encodePolyfill
            ? o.n.__SENTRY__.encodePolyfill(e)
            : new TextEncoder().encode(e);
        }
        function p(e) {
          let [t, n] = e,
            r = JSON.stringify(t);
          function i(e) {
            "string" == typeof r
              ? (r = "string" == typeof e ? r + e : [d(r), e])
              : r.push("string" == typeof e ? d(e) : e);
          }
          for (let e of n) {
            let [t, n] = e;
            if (
              (i(`
${JSON.stringify(t)}
`),
              "string" == typeof n || n instanceof Uint8Array)
            )
              i(n);
            else {
              let e;
              try {
                e = JSON.stringify(n);
              } catch (t) {
                e = JSON.stringify((0, a.Fv)(n));
              }
              i(e);
            }
          }
          return "string" == typeof r
            ? r
            : (function (e) {
                let t = e.reduce((e, t) => e + t.length, 0),
                  n = new Uint8Array(t),
                  r = 0;
                for (let t of e) n.set(t, r), (r += t.length);
                return n;
              })(r);
        }
        function f(e) {
          let t = "string" == typeof e ? d(e) : e;
          function n(e) {
            let n = t.subarray(0, e);
            return (t = t.subarray(e + 1)), n;
          }
          function r() {
            var e;
            let r = t.indexOf(10);
            return (
              r < 0 && (r = t.length),
              JSON.parse(
                ((e = n(r)),
                o.n.__SENTRY__ && o.n.__SENTRY__.decodePolyfill
                  ? o.n.__SENTRY__.decodePolyfill(e)
                  : new TextDecoder().decode(e))
              )
            );
          }
          let a = r(),
            i = [];
          for (; t.length; ) {
            let e = r(),
              t = "number" == typeof e.length ? e.length : void 0;
            i.push([e, t ? n(t) : r()]);
          }
          return [a, i];
        }
        function h(e) {
          return [{ type: "span" }, e];
        }
        function m(e) {
          let t = "string" == typeof e.data ? d(e.data) : e.data;
          return [
            (0, i.Jr)({
              type: "attachment",
              length: t.length,
              filename: e.filename,
              content_type: e.contentType,
              attachment_type: e.attachmentType,
            }),
            t,
          ];
        }
        let _ = {
          session: "session",
          sessions: "session",
          attachment: "attachment",
          transaction: "transaction",
          event: "error",
          client_report: "internal",
          user_report: "default",
          profile: "profile",
          profile_chunk: "profile",
          replay_event: "replay",
          replay_recording: "replay",
          check_in: "monitor",
          feedback: "feedback",
          span: "span",
          statsd: "metric_bucket",
          raw_security: "security",
        };
        function g(e) {
          return _[e];
        }
        function v(e) {
          if (!e || !e.sdk) return;
          let { name: t, version: n } = e.sdk;
          return { name: t, version: n };
        }
        function y(e, t, n, a) {
          let o =
            e.sdkProcessingMetadata &&
            e.sdkProcessingMetadata.dynamicSamplingContext;
          return {
            event_id: e.event_id,
            sent_at: new Date().toISOString(),
            ...(t && { sdk: t }),
            ...(!!n && a && { dsn: (0, r.RA)(a) }),
            ...(o && { trace: (0, i.Jr)({ ...o }) }),
          };
        }
      },
      84105: function (e, t, n) {
        "use strict";
        n.d(t, {
          D2: function () {
            return u;
          },
          Hj: function () {
            return l;
          },
          rK: function () {
            return c;
          },
        });
        var r = n(23187),
          a = n(17986),
          i = n(39649);
        let o = {},
          s = {};
        function l(e, t) {
          (o[e] = o[e] || []), o[e].push(t);
        }
        function u(e, t) {
          if (!s[e]) {
            s[e] = !0;
            try {
              t();
            } catch (t) {
              r.X && a.kg.error(`Error while instrumenting ${e}`, t);
            }
          }
        }
        function c(e, t) {
          let n = e && o[e];
          if (n)
            for (let o of n)
              try {
                o(t);
              } catch (t) {
                r.X &&
                  a.kg.error(
                    `Error while triggering instrumentation handler.
Type: ${e}
Name: ${(0, i.$P)(o)}
Error:`,
                    t
                  );
              }
        }
      },
      13185: function (e, t, n) {
        "use strict";
        n.d(t, {
          j: function () {
            return o;
          },
        });
        var r = n(77256),
          a = n(83454),
          i = n(33280);
        function o() {
          return (
            "undefined" != typeof window &&
            (!(
              !(0, r.n)() &&
              "[object process]" ===
                Object.prototype.toString.call(void 0 !== a ? a : 0)
            ) ||
              (function () {
                let e = i.n.process;
                return !!e && "renderer" === e.type;
              })())
          );
        }
      },
      26444: function (e, t, n) {
        "use strict";
        function r(e, t = Date.now()) {
          let n = parseInt(`${e}`, 10);
          if (!isNaN(n)) return 1e3 * n;
          let r = Date.parse(`${e}`);
          return isNaN(r) ? 6e4 : r - t;
        }
        function a(e, t, n = Date.now()) {
          return (e[t] || e.all || 0) > n;
        }
        function i(e, { statusCode: t, headers: n }, a = Date.now()) {
          let i = { ...e },
            o = n && n["x-sentry-rate-limits"],
            s = n && n["retry-after"];
          if (o)
            for (let e of o.trim().split(",")) {
              let [t, n, , , r] = e.split(":", 5),
                o = parseInt(t, 10),
                s = (isNaN(o) ? 60 : o) * 1e3;
              if (n)
                for (let e of n.split(";"))
                  "metric_bucket" === e
                    ? (!r || r.split(";").includes("custom")) && (i[e] = a + s)
                    : (i[e] = a + s);
              else i.all = a + s;
            }
          else s ? (i.all = a + r(s, a)) : 429 === t && (i.all = a + 6e4);
          return i;
        }
        n.d(t, {
          JY: function () {
            return r;
          },
          Q: function () {
            return a;
          },
          WG: function () {
            return i;
          },
        });
      },
      49597: function (e, t, n) {
        "use strict";
        function r(e) {
          return "warn" === e
            ? "warning"
            : ["fatal", "error", "warning", "log", "info", "debug"].includes(e)
            ? e
            : "log";
        }
        n.d(t, {
          V: function () {
            return r;
          },
        });
      },
      18409: function (e, t, n) {
        "use strict";
        n.d(t, {
          Ak: function () {
            return s;
          },
          QC: function () {
            return l;
          },
          t$: function () {
            return u;
          },
          zb: function () {
            return c;
          },
        });
        var r = n(23187),
          a = n(17986),
          i = n(33280);
        let o = i.n;
        function s() {
          if (!("fetch" in o)) return !1;
          try {
            return (
              new Headers(),
              new Request("http://www.example.com"),
              new Response(),
              !0
            );
          } catch (e) {
            return !1;
          }
        }
        function l(e) {
          return (
            e &&
            /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(
              e.toString()
            )
          );
        }
        function u() {
          if ("string" == typeof EdgeRuntime) return !0;
          if (!s()) return !1;
          if (l(o.fetch)) return !0;
          let e = !1,
            t = o.document;
          if (t && "function" == typeof t.createElement)
            try {
              let n = t.createElement("iframe");
              (n.hidden = !0),
                t.head.appendChild(n),
                n.contentWindow &&
                  n.contentWindow.fetch &&
                  (e = l(n.contentWindow.fetch)),
                t.head.removeChild(n);
            } catch (e) {
              r.X &&
                a.kg.warn(
                  "Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ",
                  e
                );
            }
          return e;
        }
        function c() {
          return "ReportingObserver" in o;
        }
      },
      42206: function (e, t, n) {
        "use strict";
        function r(e, t) {
          let n = t && t.getDsn(),
            r = t && t.getOptions().tunnel;
          return (!!n && e.includes(n.host)) || (!!r && a(e) === a(r));
        }
        function a(e) {
          return "/" === e[e.length - 1] ? e.slice(0, -1) : e;
        }
        n.d(t, {
          W: function () {
            return r;
          },
        });
      },
      79769: function (e, t, n) {
        "use strict";
        n.d(t, {
          o: function () {
            return i;
          },
        });
        var r = n(94223),
          a = n(17986);
        function i(e) {
          if ("boolean" == typeof e) return Number(e);
          let t = "string" == typeof e ? parseFloat(e) : e;
          if ("number" != typeof t || isNaN(t) || t < 0 || t > 1) {
            r.X &&
              a.kg.warn(
                `[Tracing] Given sample rate is invalid. Sample rate must be a boolean or a number between 0 and 1. Got ${JSON.stringify(
                  e
                )} of type ${JSON.stringify(typeof e)}.`
              );
            return;
          }
          return t;
        }
      },
      2111: function (e, t, n) {
        "use strict";
        let r, a, i, o, s, l, u, c, d;
        n.r(t),
          n.d(t, {
            BrowserClient: function () {
              return eb;
            },
            ErrorBoundary: function () {
              return oz;
            },
            OpenFeatureIntegrationHook: function () {
              return oj;
            },
            Profiler: function () {
              return oq;
            },
            SDK_VERSION: function () {
              return f.J;
            },
            SEMANTIC_ATTRIBUTE_SENTRY_OP: function () {
              return tX.$J;
            },
            SEMANTIC_ATTRIBUTE_SENTRY_ORIGIN: function () {
              return tX.S3;
            },
            SEMANTIC_ATTRIBUTE_SENTRY_SAMPLE_RATE: function () {
              return tX.TE;
            },
            SEMANTIC_ATTRIBUTE_SENTRY_SOURCE: function () {
              return tX.Zj;
            },
            Scope: function () {
              return rh.s;
            },
            WINDOW: function () {
              return e_;
            },
            addBreadcrumb: function () {
              return eM.n;
            },
            addEventProcessor: function () {
              return m.Qy;
            },
            addIntegration: function () {
              return S;
            },
            addTracingExtensions: function () {
              return rR;
            },
            breadcrumbsIntegration: function () {
              return eH;
            },
            browserApiErrorsIntegration: function () {
              return eW;
            },
            browserProfilingIntegration: function () {
              return oN;
            },
            browserSessionIntegration: function () {
              return eY;
            },
            browserTracingIntegration: function () {
              return n7;
            },
            buildLaunchDarklyFlagUsedHandler: function () {
              return oF;
            },
            captureConsoleIntegration: function () {
              return rP;
            },
            captureEvent: function () {
              return m.eN;
            },
            captureException: function () {
              return m.Tb;
            },
            captureFeedback: function () {
              return rM;
            },
            captureMessage: function () {
              return m.uT;
            },
            captureRequestError: function () {
              return rC;
            },
            captureSession: function () {
              return m.cg;
            },
            captureUnderscoreErrorException: function () {
              return n5.u;
            },
            captureUserFeedback: function () {
              return tN;
            },
            chromeStackLineParser: function () {
              return ti;
            },
            close: function () {
              return m.xv;
            },
            contextLinesIntegration: function () {
              return as;
            },
            continueTrace: function () {
              return ni;
            },
            createReduxEnhancer: function () {
              return oQ;
            },
            createTransport: function () {
              return tT;
            },
            createUserFeedbackEnvelope: function () {
              return ey;
            },
            debugIntegration: function () {
              return rD;
            },
            dedupeIntegration: function () {
              return D;
            },
            defaultRequestInstrumentationOptions: function () {
              return nH;
            },
            defaultStackLineParsers: function () {
              return ty;
            },
            defaultStackParser: function () {
              return tb;
            },
            endSession: function () {
              return m.TM;
            },
            eventFromException: function () {
              return ed;
            },
            eventFromMessage: function () {
              return ep;
            },
            exceptionFromError: function () {
              return eo;
            },
            experimental_captureRequestError: function () {
              return rA;
            },
            extraErrorDataIntegration: function () {
              return r$;
            },
            featureFlagsIntegration: function () {
              return oO;
            },
            feedbackAsyncIntegration: function () {
              return oe;
            },
            feedbackIntegration: function () {
              return ot;
            },
            feedbackSyncIntegration: function () {
              return ot;
            },
            flush: function () {
              return m.yl;
            },
            forceLoad: function () {
              return tA;
            },
            functionToStringIntegration: function () {
              return P;
            },
            geckoStackLineParser: function () {
              return tu;
            },
            getActiveSpan: function () {
              return q.HN;
            },
            getClient: function () {
              return g.s3;
            },
            getCurrentHub: function () {
              return rF;
            },
            getCurrentScope: function () {
              return g.nZ;
            },
            getDefaultIntegrations: function () {
              return tI;
            },
            getFeedback: function () {
              return aY;
            },
            getGlobalScope: function () {
              return g.lW;
            },
            getIsolationScope: function () {
              return g.aF;
            },
            getReplay: function () {
              return al.T;
            },
            getRootSpan: function () {
              return q.Gx;
            },
            getSpanDescendants: function () {
              return q.Dp;
            },
            getSpanStatusFromHttpCode: function () {
              return ne.ix;
            },
            globalHandlersIntegration: function () {
              return e2;
            },
            httpClientIntegration: function () {
              return r8;
            },
            httpContextIntegration: function () {
              return e5;
            },
            inboundFiltersIntegration: function () {
              return I;
            },
            init: function () {
              return n2;
            },
            instrumentOutgoingRequests: function () {
              return nX;
            },
            isInitialized: function () {
              return m.dk;
            },
            lastEventId: function () {
              return m.eW;
            },
            launchDarklyIntegration: function () {
              return o$;
            },
            lazyLoadIntegration: function () {
              return r3;
            },
            linkedErrorsIntegration: function () {
              return e8;
            },
            makeBrowserOfflineTransport: function () {
              return oh;
            },
            makeFetchTransport: function () {
              return tk;
            },
            makeMultiplexedTransport: function () {
              return rj;
            },
            metrics: function () {
              return oc;
            },
            moduleMetadataIntegration: function () {
              return rG;
            },
            onLoad: function () {
              return tR;
            },
            openFeatureIntegration: function () {
              return oU;
            },
            opera10StackLineParser: function () {
              return tm;
            },
            opera11StackLineParser: function () {
              return tv;
            },
            parameterize: function () {
              return rq;
            },
            reactErrorHandler: function () {
              return oX;
            },
            reactRouterV3BrowserTracingIntegration: function () {
              return o0;
            },
            reactRouterV4BrowserTracingIntegration: function () {
              return o4;
            },
            reactRouterV5BrowserTracingIntegration: function () {
              return o5;
            },
            reactRouterV6BrowserTracingIntegration: function () {
              return su;
            },
            reactRouterV7BrowserTracingIntegration: function () {
              return sm;
            },
            registerSpanErrorInstrumentation: function () {
              return nL;
            },
            replayCanvasIntegration: function () {
              return aD;
            },
            replayIntegration: function () {
              return al.G;
            },
            reportingObserverIntegration: function () {
              return r6;
            },
            rewriteFramesIntegration: function () {
              return tU;
            },
            sendFeedback: function () {
              return aH;
            },
            sessionTimingIntegration: function () {
              return rV;
            },
            setContext: function () {
              return m.v;
            },
            setCurrentClient: function () {
              return j;
            },
            setExtra: function () {
              return m.sU;
            },
            setExtras: function () {
              return m.rJ;
            },
            setHttpStatus: function () {
              return ne.Q0;
            },
            setMeasurement: function () {
              return tB;
            },
            setTag: function () {
              return m.YA;
            },
            setTags: function () {
              return m.mG;
            },
            setUser: function () {
              return m.av;
            },
            showReportDialog: function () {
              return tC;
            },
            spanToBaggageHeader: function () {
              return W.uc;
            },
            spanToJSON: function () {
              return q.XU;
            },
            spanToTraceHeader: function () {
              return q.Hb;
            },
            spotlightBrowserIntegration: function () {
              return oM;
            },
            startBrowserTracingNavigationSpan: function () {
              return nY;
            },
            startBrowserTracingPageLoadSpan: function () {
              return nV;
            },
            startInactiveSpan: function () {
              return na;
            },
            startNewTrace: function () {
              return nl;
            },
            startSession: function () {
              return m.yj;
            },
            startSpan: function () {
              return nn;
            },
            startSpanManual: function () {
              return nr;
            },
            suppressTracing: function () {
              return ns;
            },
            tanstackRouterBrowserTracingIntegration: function () {
              return o3;
            },
            thirdPartyErrorFilterIntegration: function () {
              return rY;
            },
            useProfiler: function () {
              return oV;
            },
            winjsStackLineParser: function () {
              return tp;
            },
            withActiveSpan: function () {
              return no;
            },
            withErrorBoundary: function () {
              return oJ;
            },
            withIsolationScope: function () {
              return g.wi;
            },
            withProfiler: function () {
              return oZ;
            },
            withScope: function () {
              return g.$e;
            },
            withSentryConfig: function () {
              return n4;
            },
            withSentryReactRouterV6Routing: function () {
              return sh;
            },
            withSentryReactRouterV7Routing: function () {
              return s_;
            },
            withSentryRouting: function () {
              return o9;
            },
            withServerActionInstrumentation: function () {
              return rk;
            },
            wrapApiHandlerWithSentryVercelCrons: function () {
              return rS;
            },
            wrapAppGetInitialPropsWithSentry: function () {
              return rc;
            },
            wrapCreateBrowserRouter: function () {
              return sf;
            },
            wrapCreateBrowserRouterV6: function () {
              return sp;
            },
            wrapCreateBrowserRouterV7: function () {
              return sg;
            },
            wrapDocumentGetInitialPropsWithSentry: function () {
              return rd;
            },
            wrapErrorGetInitialPropsWithSentry: function () {
              return rp;
            },
            wrapGenerationFunctionWithSentry: function () {
              return rx;
            },
            wrapGetInitialPropsWithSentry: function () {
              return ru;
            },
            wrapGetServerSidePropsWithSentry: function () {
              return rf;
            },
            wrapGetStaticPropsWithSentry: function () {
              return rs;
            },
            wrapMiddlewareWithSentry: function () {
              return rw;
            },
            wrapPageComponentWithSentry: function () {
              return rT;
            },
            wrapRouteHandlerWithSentry: function () {
              return rE;
            },
            wrapServerComponentWithSentry: function () {
              return rb;
            },
            wrapUseRoutes: function () {
              return sd;
            },
            wrapUseRoutesV6: function () {
              return sc;
            },
            wrapUseRoutesV7: function () {
              return sv;
            },
            zodErrorsIntegration: function () {
              return rQ;
            },
          });
        var p = n(13539),
          f = n(49889);
        function h(e, t, n = [t], r = "npm") {
          let a = e._metadata || {};
          a.sdk ||
            (a.sdk = {
              name: `sentry.javascript.${t}`,
              packages: n.map((e) => ({
                name: `${r}:@sentry/${e}`,
                version: f.J,
              })),
              version: f.J,
            }),
            (e._metadata = a);
        }
        var m = n(39424),
          _ = n(94223),
          g = n(26318),
          v = n(17986);
        let y = [];
        function b(e, t) {
          for (let n of t) n && n.afterAllSetup && n.afterAllSetup(e);
        }
        function E(e, t, n) {
          if (n[t.name]) {
            _.X &&
              v.kg.log(
                `Integration skipped because it was already installed: ${t.name}`
              );
            return;
          }
          if (
            ((n[t.name] = t),
            -1 === y.indexOf(t.name) &&
              "function" == typeof t.setupOnce &&
              (t.setupOnce(), y.push(t.name)),
            t.setup && "function" == typeof t.setup && t.setup(e),
            "function" == typeof t.preprocessEvent)
          ) {
            let n = t.preprocessEvent.bind(t);
            e.on("preprocessEvent", (t, r) => n(t, r, e));
          }
          if ("function" == typeof t.processEvent) {
            let n = t.processEvent.bind(t),
              r = Object.assign((t, r) => n(t, r, e), { id: t.name });
            e.addEventProcessor(r);
          }
          _.X && v.kg.log(`Integration installed: ${t.name}`);
        }
        function S(e) {
          let t = (0, g.s3)();
          if (!t) {
            _.X &&
              v.kg.warn(
                `Cannot add integration "${e.name}" because no SDK Client is available.`
              );
            return;
          }
          t.addIntegration(e);
        }
        var w = n(82305),
          T = n(50027);
        let x = [
            /^Script error\.?$/,
            /^Javascript error: Script error\.? on line 0$/,
            /^ResizeObserver loop completed with undelivered notifications.$/,
            /^Cannot redefine property: googletag$/,
            "undefined is not an object (evaluating 'a.L')",
            'can\'t redefine non-configurable property "solana"',
            "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
            "Can't find variable: _AutofillCallbackHandler",
            /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/,
          ],
          k = (e = {}) => ({
            name: "InboundFilters",
            processEvent(t, n, r) {
              var a;
              let i = r.getOptions(),
                o = (function (e = {}, t = {}) {
                  return {
                    allowUrls: [...(e.allowUrls || []), ...(t.allowUrls || [])],
                    denyUrls: [...(e.denyUrls || []), ...(t.denyUrls || [])],
                    ignoreErrors: [
                      ...(e.ignoreErrors || []),
                      ...(t.ignoreErrors || []),
                      ...(e.disableErrorDefaults ? [] : x),
                    ],
                    ignoreTransactions: [
                      ...(e.ignoreTransactions || []),
                      ...(t.ignoreTransactions || []),
                    ],
                    ignoreInternal:
                      void 0 === e.ignoreInternal || e.ignoreInternal,
                  };
                })(e, i);
              return (
                o.ignoreInternal &&
                (function (e) {
                  try {
                    return "SentryError" === e.exception.values[0].type;
                  } catch (e) {}
                  return !1;
                })(t)
                  ? (_.X &&
                      v.kg
                        .warn(`Event dropped due to being internal Sentry Error.
Event: ${(0, w.jH)(t)}`),
                    0)
                  : ((a = o.ignoreErrors),
                    !t.type &&
                      a &&
                      a.length &&
                      (function (e) {
                        let t;
                        let n = [];
                        e.message && n.push(e.message);
                        try {
                          t = e.exception.values[e.exception.values.length - 1];
                        } catch (e) {}
                        return (
                          t &&
                            t.value &&
                            (n.push(t.value),
                            t.type && n.push(`${t.type}: ${t.value}`)),
                          n
                        );
                      })(t).some((e) => (0, T.U0)(e, a)))
                  ? (_.X &&
                      v.kg
                        .warn(`Event dropped due to being matched by \`ignoreErrors\` option.
Event: ${(0, w.jH)(t)}`),
                    0)
                  : t.type ||
                    !t.exception ||
                    !t.exception.values ||
                    0 === t.exception.values.length ||
                    t.message ||
                    t.exception.values.some(
                      (e) =>
                        e.stacktrace ||
                        (e.type && "Error" !== e.type) ||
                        e.value
                    )
                  ? !(function (e, t) {
                      if ("transaction" !== e.type || !t || !t.length)
                        return !1;
                      let n = e.transaction;
                      return !!n && (0, T.U0)(n, t);
                    })(t, o.ignoreTransactions)
                    ? !(function (e, t) {
                        if (!t || !t.length) return !1;
                        let n = C(e);
                        return !!n && (0, T.U0)(n, t);
                      })(t, o.denyUrls)
                      ? (function (e, t) {
                          if (!t || !t.length) return !0;
                          let n = C(e);
                          return !n || (0, T.U0)(n, t);
                        })(t, o.allowUrls) ||
                        (_.X &&
                          v.kg
                            .warn(`Event dropped due to not being matched by \`allowUrls\` option.
Event: ${(0, w.jH)(t)}.
Url: ${C(t)}`),
                        0)
                      : (_.X &&
                          v.kg
                            .warn(`Event dropped due to being matched by \`denyUrls\` option.
Event: ${(0, w.jH)(t)}.
Url: ${C(t)}`),
                        0)
                    : (_.X &&
                        v.kg
                          .warn(`Event dropped due to being matched by \`ignoreTransactions\` option.
Event: ${(0, w.jH)(t)}`),
                      0)
                  : (_.X &&
                      v.kg
                        .warn(`Event dropped due to not having an error message, error type or stacktrace.
Event: ${(0, w.jH)(t)}`),
                    0)
              )
                ? t
                : null;
            },
          }),
          I = k;
        function C(e) {
          try {
            let t;
            try {
              t = e.exception.values[0].stacktrace.frames;
            } catch (e) {}
            return t
              ? (function (e = []) {
                  for (let t = e.length - 1; t >= 0; t--) {
                    let n = e[t];
                    if (
                      n &&
                      "<anonymous>" !== n.filename &&
                      "[native code]" !== n.filename
                    )
                      return n.filename || null;
                  }
                  return null;
                })(t)
              : null;
          } catch (t) {
            return (
              _.X && v.kg.error(`Cannot extract url for event ${(0, w.jH)(e)}`),
              null
            );
          }
        }
        var A = n(51150);
        let R = new WeakMap(),
          N = () => ({
            name: "FunctionToString",
            setupOnce() {
              r = Function.prototype.toString;
              try {
                Function.prototype.toString = function (...e) {
                  let t = (0, A.HK)(this),
                    n = R.has((0, g.s3)()) && void 0 !== t ? t : this;
                  return r.apply(n, e);
                };
              } catch (e) {}
            },
            setup(e) {
              R.set(e, !0);
            },
          }),
          P = N;
        var M = n(39649);
        let L = () => {
            let e;
            return {
              name: "Dedupe",
              processEvent(t) {
                if (t.type) return t;
                try {
                  var n;
                  if (
                    (n = e) &&
                    ((function (e, t) {
                      let n = e.message,
                        r = t.message;
                      return !!(
                        (n || r) &&
                        (!n || r) &&
                        (n || !r) &&
                        n === r &&
                        $(e, t) &&
                        O(e, t)
                      );
                    })(t, n) ||
                      (function (e, t) {
                        let n = F(t),
                          r = F(e);
                        return !!(
                          n &&
                          r &&
                          n.type === r.type &&
                          n.value === r.value &&
                          $(e, t) &&
                          O(e, t)
                        );
                      })(t, n))
                  )
                    return (
                      _.X &&
                        v.kg.warn(
                          "Event dropped due to being a duplicate of previously captured event."
                        ),
                      null
                    );
                } catch (e) {}
                return (e = t);
              },
            };
          },
          D = L;
        function O(e, t) {
          let n = (0, M.Fr)(e),
            r = (0, M.Fr)(t);
          if (!n && !r) return !0;
          if ((n && !r) || (!n && r) || r.length !== n.length) return !1;
          for (let e = 0; e < r.length; e++) {
            let t = r[e],
              a = n[e];
            if (
              t.filename !== a.filename ||
              t.lineno !== a.lineno ||
              t.colno !== a.colno ||
              t.function !== a.function
            )
              return !1;
          }
          return !0;
        }
        function $(e, t) {
          let n = e.fingerprint,
            r = t.fingerprint;
          if (!n && !r) return !0;
          if ((n && !r) || (!n && r)) return !1;
          try {
            return !(n.join("") !== r.join(""));
          } catch (e) {
            return !1;
          }
        }
        function F(e) {
          return e.exception && e.exception.values && e.exception.values[0];
        }
        var U = n(18409);
        function j(e) {
          (0, g.nZ)().setClient(e);
        }
        var H = n(48600);
        function X(e) {
          let t = e.protocol ? `${e.protocol}:` : "",
            n = e.port ? `:${e.port}` : "";
          return `${t}//${e.host}${n}${e.path ? `/${e.path}` : ""}/api/`;
        }
        function B(e, t, n) {
          return (
            t ||
            `${X(e)}${e.projectId}/envelope/?${(function (e, t) {
              let n = { sentry_version: "7" };
              return (
                e.publicKey && (n.sentry_key = e.publicKey),
                t && (n.sentry_client = `${t.name}/${t.version}`),
                new URLSearchParams(n).toString()
              );
            })(e, n)}`
          );
        }
        var W = n(72123),
          G = n(46975),
          q = n(81585),
          Z = n(10042),
          V = n(59943);
        class Y extends Error {
          constructor(e, t = "warn") {
            super(e),
              (this.message = e),
              (this.name = new.target.prototype.constructor.name),
              Object.setPrototypeOf(this, new.target.prototype),
              (this.logLevel = t);
          }
        }
        var z = n(24925),
          J = n(52340),
          K = n(79769),
          Q = n(5808);
        let ee = "Not capturing exception because it's already been captured.";
        class et {
          constructor(e) {
            if (
              ((this._options = e),
              (this._integrations = {}),
              (this._numProcessing = 0),
              (this._outcomes = {}),
              (this._hooks = {}),
              (this._eventProcessors = []),
              e.dsn
                ? (this._dsn = (0, H.vK)(e.dsn))
                : _.X &&
                  v.kg.warn("No DSN provided, client will not send events."),
              this._dsn)
            ) {
              let t = B(
                this._dsn,
                e.tunnel,
                e._metadata ? e._metadata.sdk : void 0
              );
              this._transport = e.transport({
                tunnel: this._options.tunnel,
                recordDroppedEvent: this.recordDroppedEvent.bind(this),
                ...e.transportOptions,
                url: t,
              });
            }
            let t = ["enableTracing", "tracesSampleRate", "tracesSampler"].find(
              (t) => t in e && void 0 == e[t]
            );
            t &&
              (0, v.Cf)(() => {
                console.warn(
                  `[Sentry] Deprecation warning: \`${t}\` is set to undefined, which leads to tracing being enabled. In v9, a value of \`undefined\` will result in tracing being disabled.`
                );
              });
          }
          captureException(e, t, n) {
            let r = (0, w.DM)();
            if ((0, w.YO)(e)) return _.X && v.kg.log(ee), r;
            let a = { event_id: r, ...t };
            return (
              this._process(
                this.eventFromException(e, a).then((e) =>
                  this._captureEvent(e, a, n)
                )
              ),
              a.event_id
            );
          }
          captureMessage(e, t, n, r) {
            let a = { event_id: (0, w.DM)(), ...n },
              i = (0, z.Le)(e) ? e : String(e),
              o = (0, z.pt)(e)
                ? this.eventFromMessage(i, t, a)
                : this.eventFromException(e, a);
            return (
              this._process(o.then((e) => this._captureEvent(e, a, r))),
              a.event_id
            );
          }
          captureEvent(e, t, n) {
            let r = (0, w.DM)();
            if (t && t.originalException && (0, w.YO)(t.originalException))
              return _.X && v.kg.log(ee), r;
            let a = { event_id: r, ...t },
              i = e.sdkProcessingMetadata || {},
              o = i.capturedSpanScope;
            return this._process(this._captureEvent(e, a, o || n)), a.event_id;
          }
          captureSession(e) {
            "string" != typeof e.release
              ? _.X &&
                v.kg.warn(
                  "Discarded session because of missing or non-string release"
                )
              : (this.sendSession(e), (0, Z.CT)(e, { init: !1 }));
          }
          getDsn() {
            return this._dsn;
          }
          getOptions() {
            return this._options;
          }
          getSdkMetadata() {
            return this._options._metadata;
          }
          getTransport() {
            return this._transport;
          }
          flush(e) {
            let t = this._transport;
            return t
              ? (this.emit("flush"),
                this._isClientDoneProcessing(e).then((n) =>
                  t.flush(e).then((e) => n && e)
                ))
              : (0, J.WD)(!0);
          }
          close(e) {
            return this.flush(e).then(
              (e) => ((this.getOptions().enabled = !1), this.emit("close"), e)
            );
          }
          getEventProcessors() {
            return this._eventProcessors;
          }
          addEventProcessor(e) {
            this._eventProcessors.push(e);
          }
          init() {
            (this._isEnabled() ||
              this._options.integrations.some(({ name: e }) =>
                e.startsWith("Spotlight")
              )) &&
              this._setupIntegrations();
          }
          getIntegrationByName(e) {
            return this._integrations[e];
          }
          addIntegration(e) {
            let t = this._integrations[e.name];
            E(this, e, this._integrations), t || b(this, [e]);
          }
          sendEvent(e, t = {}) {
            this.emit("beforeSendEvent", e, t);
            let n = (function (e, t, n, r) {
              var a, i;
              let o = (0, G.HY)(n),
                s = e.type && "replay_event" !== e.type ? e.type : "event";
              (a = e),
                (i = n && n.sdk) &&
                  ((a.sdk = a.sdk || {}),
                  (a.sdk.name = a.sdk.name || i.name),
                  (a.sdk.version = a.sdk.version || i.version),
                  (a.sdk.integrations = [
                    ...(a.sdk.integrations || []),
                    ...(i.integrations || []),
                  ]),
                  (a.sdk.packages = [
                    ...(a.sdk.packages || []),
                    ...(i.packages || []),
                  ]));
              let l = (0, G.Cd)(e, o, r, t);
              delete e.sdkProcessingMetadata;
              let u = [{ type: s }, e];
              return (0, G.Jd)(l, [u]);
            })(e, this._dsn, this._options._metadata, this._options.tunnel);
            for (let e of t.attachments || []) n = (0, G.BO)(n, (0, G.zQ)(e));
            let r = this.sendEnvelope(n);
            r && r.then((t) => this.emit("afterSendEvent", e, t), null);
          }
          sendSession(e) {
            let t = (function (e, t, n, r) {
              let a = (0, G.HY)(n),
                i = {
                  sent_at: new Date().toISOString(),
                  ...(a && { sdk: a }),
                  ...(!!r && t && { dsn: (0, H.RA)(t) }),
                },
                o =
                  "aggregates" in e
                    ? [{ type: "sessions" }, e]
                    : [{ type: "session" }, e.toJSON()];
              return (0, G.Jd)(i, [o]);
            })(e, this._dsn, this._options._metadata, this._options.tunnel);
            this.sendEnvelope(t);
          }
          recordDroppedEvent(e, t, n) {
            if (this._options.sendClientReports) {
              let r = "number" == typeof n ? n : 1,
                a = `${e}:${t}`;
              _.X &&
                v.kg.log(
                  `Recording outcome: "${a}"${r > 1 ? ` (${r} times)` : ""}`
                ),
                (this._outcomes[a] = (this._outcomes[a] || 0) + r);
            }
          }
          on(e, t) {
            let n = (this._hooks[e] = this._hooks[e] || []);
            return (
              n.push(t),
              () => {
                let e = n.indexOf(t);
                e > -1 && n.splice(e, 1);
              }
            );
          }
          emit(e, ...t) {
            let n = this._hooks[e];
            n && n.forEach((e) => e(...t));
          }
          sendEnvelope(e) {
            return (this.emit("beforeEnvelope", e),
            this._isEnabled() && this._transport)
              ? this._transport
                  .send(e)
                  .then(
                    null,
                    (e) => (
                      _.X && v.kg.error("Error while sending envelope:", e), e
                    )
                  )
              : (_.X && v.kg.error("Transport disabled"), (0, J.WD)({}));
          }
          _setupIntegrations() {
            let { integrations: e } = this._options;
            (this._integrations = (function (e, t) {
              let n = {};
              return (
                t.forEach((t) => {
                  t && E(e, t, n);
                }),
                n
              );
            })(this, e)),
              b(this, e);
          }
          _updateSessionFromEvent(e, t) {
            let n = !1,
              r = !1,
              a = t.exception && t.exception.values;
            if (a)
              for (let e of ((r = !0), a)) {
                let t = e.mechanism;
                if (t && !1 === t.handled) {
                  n = !0;
                  break;
                }
              }
            let i = "ok" === e.status,
              o = (i && 0 === e.errors) || (i && n);
            o &&
              ((0, Z.CT)(e, {
                ...(n && { status: "crashed" }),
                errors: e.errors || Number(r || n),
              }),
              this.captureSession(e));
          }
          _isClientDoneProcessing(e) {
            return new J.cW((t) => {
              let n = 0,
                r = setInterval(() => {
                  0 == this._numProcessing
                    ? (clearInterval(r), t(!0))
                    : ((n += 1), e && n >= e && (clearInterval(r), t(!1)));
                }, 1);
            });
          }
          _isEnabled() {
            return (
              !1 !== this.getOptions().enabled && void 0 !== this._transport
            );
          }
          _prepareEvent(e, t, n = (0, g.nZ)(), r = (0, g.aF)()) {
            let a = this.getOptions(),
              i = Object.keys(this._integrations);
            return (
              !t.integrations && i.length > 0 && (t.integrations = i),
              this.emit("preprocessEvent", e, t),
              e.type || r.setLastEventId(e.event_id || t.event_id),
              (0, Q.R)(a, e, t, n, this, r).then((e) => {
                if (null === e) return e;
                e.contexts = { trace: (0, g.XX)(n), ...e.contexts };
                let t = (0, W.CG)(this, n);
                return (
                  (e.sdkProcessingMetadata = {
                    dynamicSamplingContext: t,
                    ...e.sdkProcessingMetadata,
                  }),
                  e
                );
              })
            );
          }
          _captureEvent(e, t = {}, n) {
            return this._processEvent(e, t, n).then(
              (e) => e.event_id,
              (e) => {
                _.X &&
                  ("log" === e.logLevel ? v.kg.log(e.message) : v.kg.warn(e));
              }
            );
          }
          _processEvent(e, t, n) {
            let r = this.getOptions(),
              { sampleRate: a } = r,
              i = er(e),
              o = en(e),
              s = e.type || "error",
              l = `before send for type \`${s}\``,
              u = void 0 === a ? void 0 : (0, K.o)(a);
            if (o && "number" == typeof u && Math.random() > u)
              return (
                this.recordDroppedEvent("sample_rate", "error", e),
                (0, J.$2)(
                  new Y(
                    `Discarding event because it's not included in the random sample (sampling rate = ${a})`,
                    "log"
                  )
                )
              );
            let c = "replay_event" === s ? "replay" : s,
              d = e.sdkProcessingMetadata || {},
              p = d.capturedSpanIsolationScope;
            return this._prepareEvent(e, t, n, p)
              .then((n) => {
                if (null === n)
                  throw (
                    (this.recordDroppedEvent("event_processor", c, e),
                    new Y(
                      "An event processor returned `null`, will not send event.",
                      "log"
                    ))
                  );
                let a = t.data && !0 === t.data.__sentry__;
                if (a) return n;
                let i = (function (e, t, n, r) {
                  let {
                    beforeSend: a,
                    beforeSendTransaction: i,
                    beforeSendSpan: o,
                  } = t;
                  if (en(n) && a) return a(n, r);
                  if (er(n)) {
                    if (n.spans && o) {
                      let t = [];
                      for (let r of n.spans) {
                        let n = o(r);
                        n
                          ? t.push(n)
                          : ((0, q.R6)(),
                            e.recordDroppedEvent("before_send", "span"));
                      }
                      n.spans = t;
                    }
                    if (i) {
                      if (n.spans) {
                        let e = n.spans.length;
                        n.sdkProcessingMetadata = {
                          ...n.sdkProcessingMetadata,
                          spanCountBeforeProcessing: e,
                        };
                      }
                      return i(n, r);
                    }
                  }
                  return n;
                })(this, r, n, t);
                return (function (e, t) {
                  let n = `${t} must return \`null\` or a valid event.`;
                  if ((0, z.J8)(e))
                    return e.then(
                      (e) => {
                        if (!(0, z.PO)(e) && null !== e) throw new Y(n);
                        return e;
                      },
                      (e) => {
                        throw new Y(`${t} rejected with ${e}`);
                      }
                    );
                  if (!(0, z.PO)(e) && null !== e) throw new Y(n);
                  return e;
                })(i, l);
              })
              .then((r) => {
                if (null === r) {
                  if ((this.recordDroppedEvent("before_send", c, e), i)) {
                    let t = e.spans || [],
                      n = 1 + t.length;
                    this.recordDroppedEvent("before_send", "span", n);
                  }
                  throw new Y(
                    `${l} returned \`null\`, will not send event.`,
                    "log"
                  );
                }
                let a = n && n.getSession();
                if ((!i && a && this._updateSessionFromEvent(a, r), i)) {
                  let e =
                      (r.sdkProcessingMetadata &&
                        r.sdkProcessingMetadata.spanCountBeforeProcessing) ||
                      0,
                    t = r.spans ? r.spans.length : 0,
                    n = e - t;
                  n > 0 && this.recordDroppedEvent("before_send", "span", n);
                }
                let o = r.transaction_info;
                return (
                  i &&
                    o &&
                    r.transaction !== e.transaction &&
                    (r.transaction_info = { ...o, source: "custom" }),
                  this.sendEvent(r, t),
                  r
                );
              })
              .then(null, (e) => {
                if (e instanceof Y) throw e;
                throw (
                  (this.captureException(e, {
                    data: { __sentry__: !0 },
                    originalException: e,
                  }),
                  new Y(`Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.
Reason: ${e}`))
                );
              });
          }
          _process(e) {
            this._numProcessing++,
              e.then(
                (e) => (this._numProcessing--, e),
                (e) => (this._numProcessing--, e)
              );
          }
          _clearOutcomes() {
            let e = this._outcomes;
            return (
              (this._outcomes = {}),
              Object.entries(e).map(([e, t]) => {
                let [n, r] = e.split(":");
                return { reason: n, category: r, quantity: t };
              })
            );
          }
          _flushOutcomes() {
            _.X && v.kg.log("Flushing outcomes...");
            let e = this._clearOutcomes();
            if (0 === e.length) {
              _.X && v.kg.log("No outcomes to send");
              return;
            }
            if (!this._dsn) {
              _.X && v.kg.log("No dsn provided, will not send outcomes");
              return;
            }
            _.X && v.kg.log("Sending outcomes:", e);
            let t = (function (e, t, n) {
              let r = [
                { type: "client_report" },
                { timestamp: (0, V.yW)(), discarded_events: e },
              ];
              return (0, G.Jd)(t ? { dsn: t } : {}, [r]);
            })(e, this._options.tunnel && (0, H.RA)(this._dsn));
            this.sendEnvelope(t);
          }
        }
        function en(e) {
          return void 0 === e.type;
        }
        function er(e) {
          return "transaction" === e.type;
        }
        var ea = n(77256),
          ei = n(90059);
        function eo(e, t) {
          let n = el(e, t),
            r = {
              type: (function (e) {
                let t = e && e.name;
                if (!t && ec(e)) {
                  let t =
                    e.message &&
                    Array.isArray(e.message) &&
                    2 == e.message.length;
                  return t ? e.message[0] : "WebAssembly.Exception";
                }
                return t;
              })(t),
              value: (function (e) {
                let t = e && e.message;
                return t
                  ? t.error && "string" == typeof t.error.message
                    ? t.error.message
                    : ec(e) && Array.isArray(e.message) && 2 == e.message.length
                    ? e.message[1]
                    : t
                  : "No error message";
              })(t),
            };
          return (
            n.length && (r.stacktrace = { frames: n }),
            void 0 === r.type &&
              "" === r.value &&
              (r.value = "Unrecoverable error caught"),
            r
          );
        }
        function es(e, t) {
          return { exception: { values: [eo(e, t)] } };
        }
        function el(e, t) {
          let n = t.stacktrace || t.stack || "",
            r = t && eu.test(t.message) ? 1 : 0,
            a = "number" == typeof t.framesToPop ? t.framesToPop : 0;
          try {
            return e(n, r, a);
          } catch (e) {}
          return [];
        }
        let eu = /Minified React error #\d+;/i;
        function ec(e) {
          return (
            "undefined" != typeof WebAssembly &&
            void 0 !== WebAssembly.Exception &&
            e instanceof WebAssembly.Exception
          );
        }
        function ed(e, t, n, r) {
          let a = (n && n.syntheticException) || void 0,
            i = ef(e, t, a, r);
          return (
            (0, w.EG)(i),
            (i.level = "error"),
            n && n.event_id && (i.event_id = n.event_id),
            (0, J.WD)(i)
          );
        }
        function ep(e, t, n = "info", r, a) {
          let i = (r && r.syntheticException) || void 0,
            o = eh(e, t, i, a);
          return (
            (o.level = n),
            r && r.event_id && (o.event_id = r.event_id),
            (0, J.WD)(o)
          );
        }
        function ef(e, t, n, r, a) {
          let i;
          if ((0, z.VW)(t) && t.error) return es(e, t.error);
          if ((0, z.TX)(t) || (0, z.fm)(t)) {
            if ("stack" in t) i = es(e, t);
            else {
              let a = t.name || ((0, z.TX)(t) ? "DOMError" : "DOMException"),
                o = t.message ? `${a}: ${t.message}` : a;
              (i = eh(e, o, n, r)), (0, w.Db)(i, o);
            }
            return (
              "code" in t &&
                (i.tags = { ...i.tags, "DOMException.code": `${t.code}` }),
              i
            );
          }
          return (0, z.VZ)(t)
            ? es(e, t)
            : (0, z.PO)(t) || (0, z.cO)(t)
            ? ((i = (function (e, t, n, r) {
                let a = (0, g.s3)(),
                  i = a && a.getOptions().normalizeDepth,
                  o = (function (e) {
                    for (let t in e)
                      if (Object.prototype.hasOwnProperty.call(e, t)) {
                        let n = e[t];
                        if (n instanceof Error) return n;
                      }
                  })(t),
                  s = { __serialized__: (0, ei.Qy)(t, i) };
                if (o) return { exception: { values: [eo(e, o)] }, extra: s };
                let l = {
                  exception: {
                    values: [
                      {
                        type: (0, z.cO)(t)
                          ? t.constructor.name
                          : r
                          ? "UnhandledRejection"
                          : "Error",
                        value: (function (e, { isUnhandledRejection: t }) {
                          let n = (0, A.zf)(e),
                            r = t ? "promise rejection" : "exception";
                          if ((0, z.VW)(e))
                            return `Event \`ErrorEvent\` captured as ${r} with message \`${e.message}\``;
                          if ((0, z.cO)(e)) {
                            let t = (function (e) {
                              try {
                                let t = Object.getPrototypeOf(e);
                                return t ? t.constructor.name : void 0;
                              } catch (e) {}
                            })(e);
                            return `Event \`${t}\` (type=${e.type}) captured as ${r}`;
                          }
                          return `Object captured as ${r} with keys: ${n}`;
                        })(t, { isUnhandledRejection: r }),
                      },
                    ],
                  },
                  extra: s,
                };
                if (n) {
                  let t = el(e, n);
                  t.length &&
                    (l.exception.values[0].stacktrace = { frames: t });
                }
                return l;
              })(e, t, n, a)),
              (0, w.EG)(i, { synthetic: !0 }),
              i)
            : ((i = eh(e, t, n, r)),
              (0, w.Db)(i, `${t}`, void 0),
              (0, w.EG)(i, { synthetic: !0 }),
              i);
        }
        function eh(e, t, n, r) {
          let a = {};
          if (r && n) {
            let r = el(e, n);
            r.length &&
              (a.exception = {
                values: [{ value: t, stacktrace: { frames: r } }],
              });
          }
          if ((0, z.Le)(t)) {
            let {
              __sentry_template_string__: e,
              __sentry_template_values__: n,
            } = t;
            return (a.logentry = { message: e, params: n }), a;
          }
          return (a.message = t), a;
        }
        var em = n(33280);
        let e_ = em.n,
          eg = 0;
        function ev(e, t = {}) {
          if ("function" != typeof e) return e;
          try {
            let t = e.__sentry_wrapped__;
            if (t) {
              if ("function" == typeof t) return t;
              return e;
            }
            if ((0, A.HK)(e)) return e;
          } catch (t) {
            return e;
          }
          let n = function (...n) {
            try {
              let r = n.map((e) => ev(e, t));
              return e.apply(this, r);
            } catch (e) {
              throw (
                (eg++,
                setTimeout(() => {
                  eg--;
                }),
                (0, g.$e)((r) => {
                  r.addEventProcessor(
                    (e) => (
                      t.mechanism &&
                        ((0, w.Db)(e, void 0, void 0),
                        (0, w.EG)(e, t.mechanism)),
                      (e.extra = { ...e.extra, arguments: n }),
                      e
                    )
                  ),
                    (0, m.Tb)(e);
                }),
                e)
              );
            }
          };
          try {
            for (let t in e)
              Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
          } catch (e) {}
          (0, A.$Q)(n, e), (0, A.xp)(e, "__sentry_wrapped__", n);
          try {
            let t = Object.getOwnPropertyDescriptor(n, "name");
            t.configurable &&
              Object.defineProperty(n, "name", { get: () => e.name });
          } catch (e) {}
          return n;
        }
        function ey(e, { metadata: t, tunnel: n, dsn: r }) {
          let a = {
            event_id: e.event_id,
            sent_at: new Date().toISOString(),
            ...(t &&
              t.sdk && { sdk: { name: t.sdk.name, version: t.sdk.version } }),
            ...(!!n && !!r && { dsn: (0, H.RA)(r) }),
          };
          return (0, G.Jd)(a, [[{ type: "user_report" }, e]]);
        }
        class eb extends et {
          constructor(e) {
            let t = { parentSpanIsAlwaysRootSpan: !0, ...e },
              n = e_.SENTRY_SDK_SOURCE || (0, ea.S)();
            h(t, "browser", ["browser"], n),
              super(t),
              t.sendClientReports &&
                e_.document &&
                e_.document.addEventListener("visibilitychange", () => {
                  "hidden" === e_.document.visibilityState &&
                    this._flushOutcomes();
                });
          }
          eventFromException(e, t) {
            return ed(
              this._options.stackParser,
              e,
              t,
              this._options.attachStacktrace
            );
          }
          eventFromMessage(e, t = "info", n) {
            return ep(
              this._options.stackParser,
              e,
              t,
              n,
              this._options.attachStacktrace
            );
          }
          captureUserFeedback(e) {
            if (!this._isEnabled()) return;
            let t = ey(e, {
              metadata: this.getSdkMetadata(),
              dsn: this.getDsn(),
              tunnel: this.getOptions().tunnel,
            });
            this.sendEnvelope(t);
          }
          _prepareEvent(e, t, n) {
            return (
              (e.platform = e.platform || "javascript"),
              super._prepareEvent(e, t, n)
            );
          }
        }
        var eE = n(25460),
          eS = n(67127),
          ew = n(42886),
          eT = n(84105);
        function ex(e) {
          let t = "console";
          (0, eT.Hj)(t, e), (0, eT.D2)(t, ek);
        }
        function ek() {
          "console" in em.n &&
            v.RU.forEach(function (e) {
              e in em.n.console &&
                (0, A.hl)(em.n.console, e, function (t) {
                  return (
                    (v.LD[e] = t),
                    function (...t) {
                      (0, eT.rK)("console", { args: t, level: e });
                      let n = v.LD[e];
                      n && n.apply(em.n.console, t);
                    }
                  );
                });
            });
        }
        function eI(e, t) {
          let n = "fetch";
          (0, eT.Hj)(n, e), (0, eT.D2)(n, () => eC(void 0, t));
        }
        function eC(e, t = !1) {
          (!t || (0, U.t$)()) &&
            (0, A.hl)(em.n, "fetch", function (t) {
              return function (...n) {
                let { method: r, url: a } = (function (e) {
                    if (0 === e.length) return { method: "GET", url: "" };
                    if (2 === e.length) {
                      let [t, n] = e;
                      return {
                        url: eP(t),
                        method: eN(n, "method")
                          ? String(n.method).toUpperCase()
                          : "GET",
                      };
                    }
                    let t = e[0];
                    return {
                      url: eP(t),
                      method: eN(t, "method")
                        ? String(t.method).toUpperCase()
                        : "GET",
                    };
                  })(n),
                  i = {
                    args: n,
                    fetchData: { method: r, url: a },
                    startTimestamp: 1e3 * (0, V.ph)(),
                  };
                e || (0, eT.rK)("fetch", { ...i });
                let o = Error().stack;
                return t.apply(em.n, n).then(
                  async (t) => (
                    e
                      ? e(t)
                      : (0, eT.rK)("fetch", {
                          ...i,
                          endTimestamp: 1e3 * (0, V.ph)(),
                          response: t,
                        }),
                    t
                  ),
                  (e) => {
                    throw (
                      ((0, eT.rK)("fetch", {
                        ...i,
                        endTimestamp: 1e3 * (0, V.ph)(),
                        error: e,
                      }),
                      (0, z.VZ)(e) &&
                        void 0 === e.stack &&
                        ((e.stack = o), (0, A.xp)(e, "framesToPop", 1)),
                      e)
                    );
                  }
                );
              };
            });
        }
        async function eA(e, t) {
          if (e && e.body) {
            let n = e.body,
              r = n.getReader(),
              a = setTimeout(() => {
                n.cancel().then(null, () => {});
              }, 9e4),
              i = !0;
            for (; i; ) {
              let e;
              try {
                e = setTimeout(() => {
                  n.cancel().then(null, () => {});
                }, 5e3);
                let { done: a } = await r.read();
                clearTimeout(e), a && (t(), (i = !1));
              } catch (e) {
                i = !1;
              } finally {
                clearTimeout(e);
              }
            }
            clearTimeout(a), r.releaseLock(), n.cancel().then(null, () => {});
          }
        }
        function eR(e) {
          let t;
          try {
            t = e.clone();
          } catch (e) {
            return;
          }
          eA(t, () => {
            (0, eT.rK)("fetch-body-resolved", {
              endTimestamp: 1e3 * (0, V.ph)(),
              response: e,
            });
          });
        }
        function eN(e, t) {
          return !!e && "object" == typeof e && !!e[t];
        }
        function eP(e) {
          return "string" == typeof e
            ? e
            : e
            ? eN(e, "url")
              ? e.url
              : e.toString
              ? e.toString()
              : ""
            : "";
        }
        var eM = n(37895),
          eL = n(70428),
          eD = n(49597);
        function eO(e) {
          if (void 0 !== e)
            return e >= 400 && e < 500
              ? "warning"
              : e >= 500
              ? "error"
              : void 0;
        }
        function e$(e) {
          if (!e) return {};
          let t = e.match(
            /^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/
          );
          if (!t) return {};
          let n = t[6] || "",
            r = t[8] || "";
          return {
            host: t[4],
            path: t[5],
            protocol: t[2],
            search: n,
            hash: r,
            relative: t[5] + n + r,
          };
        }
        function eF(e) {
          return e.split(/[?#]/, 1)[0];
        }
        function eU(e) {
          return e.split(/\\?\//).filter((e) => e.length > 0 && "," !== e)
            .length;
        }
        let ej = (e = {}) => {
            let t = {
              console: !0,
              dom: !0,
              fetch: !0,
              history: !0,
              sentry: !0,
              xhr: !0,
              ...e,
            };
            return {
              name: "Breadcrumbs",
              setup(e) {
                var n;
                t.console &&
                  ex(function (t) {
                    if ((0, g.s3)() !== e) return;
                    let n = {
                      category: "console",
                      data: { arguments: t.args, logger: "console" },
                      level: (0, eD.V)(t.level),
                      message: (0, T.nK)(t.args, " "),
                    };
                    if ("assert" === t.level) {
                      if (!1 !== t.args[0]) return;
                      (n.message = `Assertion failed: ${
                        (0, T.nK)(t.args.slice(1), " ") || "console.assert"
                      }`),
                        (n.data.arguments = t.args.slice(1));
                    }
                    (0, eM.n)(n, { input: t.args, level: t.level });
                  }),
                  t.dom &&
                    (0, eE.O)(
                      ((n = t.dom),
                      function (t) {
                        let r, a;
                        if ((0, g.s3)() !== e) return;
                        let i =
                            "object" == typeof n
                              ? n.serializeAttribute
                              : void 0,
                          o =
                            "object" == typeof n &&
                            "number" == typeof n.maxStringLength
                              ? n.maxStringLength
                              : void 0;
                        o && o > 1024 && (o = 1024),
                          "string" == typeof i && (i = [i]);
                        try {
                          let e = t.event,
                            n = e && e.target ? e.target : e;
                          (r = (0, eL.Rt)(n, {
                            keyAttrs: i,
                            maxStringLength: o,
                          })),
                            (a = (0, eL.iY)(n));
                        } catch (e) {
                          r = "<unknown>";
                        }
                        if (0 === r.length) return;
                        let s = { category: `ui.${t.name}`, message: r };
                        a && (s.data = { "ui.component_name": a }),
                          (0, eM.n)(s, {
                            event: t.event,
                            name: t.name,
                            global: t.global,
                          });
                      })
                    ),
                  t.xhr &&
                    (0, eS.UK)(function (t) {
                      if ((0, g.s3)() !== e) return;
                      let { startTimestamp: n, endTimestamp: r } = t,
                        a = t.xhr[eS.xU];
                      if (!n || !r || !a) return;
                      let { method: i, url: o, status_code: s, body: l } = a,
                        u = {
                          xhr: t.xhr,
                          input: l,
                          startTimestamp: n,
                          endTimestamp: r,
                        },
                        c = eO(s);
                      (0,
                      eM.n)({ category: "xhr", data: { method: i, url: o, status_code: s }, type: "http", level: c }, u);
                    }),
                  t.fetch &&
                    eI(function (t) {
                      if ((0, g.s3)() !== e) return;
                      let { startTimestamp: n, endTimestamp: r } = t;
                      if (
                        !(
                          !r ||
                          (t.fetchData.url.match(/sentry_key/) &&
                            "POST" === t.fetchData.method)
                        )
                      ) {
                        if (t.error) {
                          let e = t.fetchData,
                            a = {
                              data: t.error,
                              input: t.args,
                              startTimestamp: n,
                              endTimestamp: r,
                            };
                          (0, eM.n)(
                            {
                              category: "fetch",
                              data: e,
                              level: "error",
                              type: "http",
                            },
                            a
                          );
                        } else {
                          let e = t.response,
                            a = { ...t.fetchData, status_code: e && e.status },
                            i = {
                              input: t.args,
                              response: e,
                              startTimestamp: n,
                              endTimestamp: r,
                            },
                            o = eO(a.status_code);
                          (0, eM.n)(
                            {
                              category: "fetch",
                              data: a,
                              type: "http",
                              level: o,
                            },
                            i
                          );
                        }
                      }
                    }),
                  t.history &&
                    (0, ew.a)(function (t) {
                      if ((0, g.s3)() !== e) return;
                      let n = t.from,
                        r = t.to,
                        a = e$(e_.location.href),
                        i = n ? e$(n) : void 0,
                        o = e$(r);
                      (i && i.path) || (i = a),
                        a.protocol === o.protocol &&
                          a.host === o.host &&
                          (r = o.relative),
                        a.protocol === i.protocol &&
                          a.host === i.host &&
                          (n = i.relative),
                        (0, eM.n)({
                          category: "navigation",
                          data: { from: n, to: r },
                        });
                    }),
                  t.sentry &&
                    e.on("beforeSendEvent", function (t) {
                      (0, g.s3)() === e &&
                        (0, eM.n)(
                          {
                            category: `sentry.${
                              "transaction" === t.type ? "transaction" : "event"
                            }`,
                            event_id: t.event_id,
                            level: t.level,
                            message: (0, w.jH)(t),
                          },
                          { event: t }
                        );
                    });
              },
            };
          },
          eH = ej,
          eX = [
            "EventTarget",
            "Window",
            "Node",
            "ApplicationCache",
            "AudioTrackList",
            "BroadcastChannel",
            "ChannelMergerNode",
            "CryptoOperation",
            "EventSource",
            "FileReader",
            "HTMLUnknownElement",
            "IDBDatabase",
            "IDBRequest",
            "IDBTransaction",
            "KeyOperation",
            "MediaController",
            "MessagePort",
            "ModalWindow",
            "Notification",
            "SVGElementInstance",
            "Screen",
            "SharedWorker",
            "TextTrack",
            "TextTrackCue",
            "TextTrackList",
            "WebSocket",
            "WebSocketWorker",
            "Worker",
            "XMLHttpRequest",
            "XMLHttpRequestEventTarget",
            "XMLHttpRequestUpload",
          ],
          eB = (e = {}) => {
            let t = {
              XMLHttpRequest: !0,
              eventTarget: !0,
              requestAnimationFrame: !0,
              setInterval: !0,
              setTimeout: !0,
              ...e,
            };
            return {
              name: "BrowserApiErrors",
              setupOnce() {
                t.setTimeout && (0, A.hl)(e_, "setTimeout", eG),
                  t.setInterval && (0, A.hl)(e_, "setInterval", eG),
                  t.requestAnimationFrame &&
                    (0, A.hl)(e_, "requestAnimationFrame", eq),
                  t.XMLHttpRequest &&
                    "XMLHttpRequest" in e_ &&
                    (0, A.hl)(XMLHttpRequest.prototype, "send", eZ);
                let e = t.eventTarget;
                if (e) {
                  let t = Array.isArray(e) ? e : eX;
                  t.forEach(eV);
                }
              },
            };
          },
          eW = eB;
        function eG(e) {
          return function (...t) {
            let n = t[0];
            return (
              (t[0] = ev(n, {
                mechanism: {
                  data: { function: (0, M.$P)(e) },
                  handled: !1,
                  type: "instrument",
                },
              })),
              e.apply(this, t)
            );
          };
        }
        function eq(e) {
          return function (t) {
            return e.apply(this, [
              ev(t, {
                mechanism: {
                  data: {
                    function: "requestAnimationFrame",
                    handler: (0, M.$P)(e),
                  },
                  handled: !1,
                  type: "instrument",
                },
              }),
            ]);
          };
        }
        function eZ(e) {
          return function (...t) {
            let n = this;
            return (
              ["onload", "onerror", "onprogress", "onreadystatechange"].forEach(
                (e) => {
                  e in n &&
                    "function" == typeof n[e] &&
                    (0, A.hl)(n, e, function (t) {
                      let n = {
                          mechanism: {
                            data: { function: e, handler: (0, M.$P)(t) },
                            handled: !1,
                            type: "instrument",
                          },
                        },
                        r = (0, A.HK)(t);
                      return (
                        r && (n.mechanism.data.handler = (0, M.$P)(r)), ev(t, n)
                      );
                    });
                }
              ),
              e.apply(this, t)
            );
          };
        }
        function eV(e) {
          let t = e_[e],
            n = t && t.prototype;
          n &&
            n.hasOwnProperty &&
            n.hasOwnProperty("addEventListener") &&
            ((0, A.hl)(n, "addEventListener", function (t) {
              return function (n, r, a) {
                try {
                  "function" == typeof r.handleEvent &&
                    (r.handleEvent = ev(r.handleEvent, {
                      mechanism: {
                        data: {
                          function: "handleEvent",
                          handler: (0, M.$P)(r),
                          target: e,
                        },
                        handled: !1,
                        type: "instrument",
                      },
                    }));
                } catch (e) {}
                return t.apply(this, [
                  n,
                  ev(r, {
                    mechanism: {
                      data: {
                        function: "addEventListener",
                        handler: (0, M.$P)(r),
                        target: e,
                      },
                      handled: !1,
                      type: "instrument",
                    },
                  }),
                  a,
                ]);
              };
            }),
            (0, A.hl)(n, "removeEventListener", function (e) {
              return function (t, n, r) {
                try {
                  let a = n.__sentry_wrapped__;
                  a && e.call(this, t, a, r);
                } catch (e) {}
                return e.call(this, t, n, r);
              };
            }));
        }
        let eY = () => ({
            name: "BrowserSession",
            setupOnce() {
              void 0 !== e_.document &&
                ((0, m.yj)({ ignoreDuration: !0 }),
                (0, m.cg)(),
                (0, ew.a)(({ from: e, to: t }) => {
                  void 0 !== e &&
                    e !== t &&
                    ((0, m.yj)({ ignoreDuration: !0 }), (0, m.cg)());
                }));
            },
          }),
          ez = null;
        function eJ(e) {
          let t = "error";
          (0, eT.Hj)(t, e), (0, eT.D2)(t, eK);
        }
        function eK() {
          (ez = em.n.onerror),
            (em.n.onerror = function (e, t, n, r, a) {
              return (
                (0, eT.rK)("error", {
                  column: r,
                  error: a,
                  line: n,
                  msg: e,
                  url: t,
                }),
                !!ez && ez.apply(this, arguments)
              );
            }),
            (em.n.onerror.__SENTRY_INSTRUMENTED__ = !0);
        }
        let eQ = null;
        function e0(e) {
          let t = "unhandledrejection";
          (0, eT.Hj)(t, e), (0, eT.D2)(t, e1);
        }
        function e1() {
          (eQ = em.n.onunhandledrejection),
            (em.n.onunhandledrejection = function (e) {
              return (
                (0, eT.rK)("unhandledrejection", e),
                !eQ || eQ.apply(this, arguments)
              );
            }),
            (em.n.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0);
        }
        let e3 = (e = {}) => {
            let t = { onerror: !0, onunhandledrejection: !0, ...e };
            return {
              name: "GlobalHandlers",
              setupOnce() {
                Error.stackTraceLimit = 50;
              },
              setup(e) {
                t.onerror &&
                  eJ((t) => {
                    let { stackParser: n, attachStacktrace: r } = e4();
                    if ((0, g.s3)() !== e || eg > 0) return;
                    let { msg: a, url: i, line: o, column: s, error: l } = t,
                      u = (function (e, t, n, r) {
                        let a = (e.exception = e.exception || {}),
                          i = (a.values = a.values || []),
                          o = (i[0] = i[0] || {}),
                          s = (o.stacktrace = o.stacktrace || {}),
                          l = (s.frames = s.frames || []),
                          u = (0, z.HD)(t) && t.length > 0 ? t : (0, eL.l4)();
                        return (
                          0 === l.length &&
                            l.push({
                              colno: r,
                              filename: u,
                              function: M.Fi,
                              in_app: !0,
                              lineno: n,
                            }),
                          e
                        );
                      })(ef(n, l || a, void 0, r, !1), i, o, s);
                    (u.level = "error"),
                      (0, m.eN)(u, {
                        originalException: l,
                        mechanism: { handled: !1, type: "onerror" },
                      });
                  }),
                  t.onunhandledrejection &&
                    e0((t) => {
                      let { stackParser: n, attachStacktrace: r } = e4();
                      if ((0, g.s3)() !== e || eg > 0) return;
                      let a = (function (e) {
                          if ((0, z.pt)(e)) return e;
                          try {
                            if ("reason" in e) return e.reason;
                            if ("detail" in e && "reason" in e.detail)
                              return e.detail.reason;
                          } catch (e) {}
                          return e;
                        })(t),
                        i = (0, z.pt)(a)
                          ? {
                              exception: {
                                values: [
                                  {
                                    type: "UnhandledRejection",
                                    value: `Non-Error promise rejection captured with value: ${String(
                                      a
                                    )}`,
                                  },
                                ],
                              },
                            }
                          : ef(n, a, void 0, r, !0);
                      (i.level = "error"),
                        (0, m.eN)(i, {
                          originalException: a,
                          mechanism: {
                            handled: !1,
                            type: "onunhandledrejection",
                          },
                        });
                    });
              },
            };
          },
          e2 = e3;
        function e4() {
          let e = (0, g.s3)(),
            t = (e && e.getOptions()) || {
              stackParser: () => [],
              attachStacktrace: !1,
            };
          return t;
        }
        let e5 = () => ({
          name: "HttpContext",
          preprocessEvent(e) {
            if (!e_.navigator && !e_.location && !e_.document) return;
            let t =
                (e.request && e.request.url) ||
                (e_.location && e_.location.href),
              { referrer: n } = e_.document || {},
              { userAgent: r } = e_.navigator || {},
              a = {
                ...(e.request && e.request.headers),
                ...(n && { Referer: n }),
                ...(r && { "User-Agent": r }),
              },
              i = { ...e.request, ...(t && { url: t }), headers: a };
            e.request = i;
          },
        });
        function e6(e, t) {
          (e.mechanism = e.mechanism || { type: "generic", handled: !0 }),
            (e.mechanism = {
              ...e.mechanism,
              ...("AggregateError" === e.type && { is_exception_group: !0 }),
              exception_id: t,
            });
        }
        function e9(e, t, n, r) {
          (e.mechanism = e.mechanism || { type: "generic", handled: !0 }),
            (e.mechanism = {
              ...e.mechanism,
              type: "chained",
              source: t,
              exception_id: n,
              parent_id: r,
            });
        }
        let e7 = (e = {}) => {
            let t = e.limit || 5,
              n = e.key || "cause";
            return {
              name: "LinkedErrors",
              preprocessEvent(e, r, a) {
                let i = a.getOptions();
                !(function (e, t, n = 250, r, a, i, o) {
                  if (
                    !i.exception ||
                    !i.exception.values ||
                    !o ||
                    !(0, z.V9)(o.originalException, Error)
                  )
                    return;
                  let s =
                    i.exception.values.length > 0
                      ? i.exception.values[i.exception.values.length - 1]
                      : void 0;
                  s &&
                    (i.exception.values = (function e(t, n, r, a, i, o, s, l) {
                      if (o.length >= r + 1) return o;
                      let u = [...o];
                      if ((0, z.V9)(a[i], Error)) {
                        e6(s, l);
                        let o = t(n, a[i]),
                          c = u.length;
                        e9(o, i, c, l),
                          (u = e(t, n, r, a[i], i, [o, ...u], o, c));
                      }
                      return (
                        Array.isArray(a.errors) &&
                          a.errors.forEach((a, o) => {
                            if ((0, z.V9)(a, Error)) {
                              e6(s, l);
                              let c = t(n, a),
                                d = u.length;
                              e9(c, `errors[${o}]`, d, l),
                                (u = e(t, n, r, a, i, [c, ...u], c, d));
                            }
                          }),
                        u
                      );
                    })(
                      e,
                      t,
                      a,
                      o.originalException,
                      r,
                      i.exception.values,
                      s,
                      0
                    ).map(
                      (e) => (e.value && (e.value = (0, T.$G)(e.value, n)), e)
                    ));
                })(eo, i.stackParser, i.maxValueLength, n, t, e, r);
              },
            };
          },
          e8 = e7;
        function te(e, t, n, r) {
          let a = {
            filename: e,
            function: "<anonymous>" === t ? M.Fi : t,
            in_app: !0,
          };
          return (
            void 0 !== n && (a.lineno = n), void 0 !== r && (a.colno = r), a
          );
        }
        let tt = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
          tn =
            /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
          tr = /\((\S*)(?::(\d+))(?::(\d+))\)/,
          ta = (e) => {
            let t = tt.exec(e);
            if (t) {
              let [, e, n, r] = t;
              return te(e, M.Fi, +n, +r);
            }
            let n = tn.exec(e);
            if (n) {
              let e = n[2] && 0 === n[2].indexOf("eval");
              if (e) {
                let e = tr.exec(n[2]);
                e && ((n[2] = e[1]), (n[3] = e[2]), (n[4] = e[3]));
              }
              let [t, r] = tE(n[1] || M.Fi, n[2]);
              return te(r, t, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0);
            }
          },
          ti = [30, ta],
          to =
            /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
          ts = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
          tl = (e) => {
            let t = to.exec(e);
            if (t) {
              let e = t[3] && t[3].indexOf(" > eval") > -1;
              if (e) {
                let e = ts.exec(t[3]);
                e &&
                  ((t[1] = t[1] || "eval"),
                  (t[3] = e[1]),
                  (t[4] = e[2]),
                  (t[5] = ""));
              }
              let n = t[3],
                r = t[1] || M.Fi;
              return (
                ([r, n] = tE(r, n)),
                te(n, r, t[4] ? +t[4] : void 0, t[5] ? +t[5] : void 0)
              );
            }
          },
          tu = [50, tl],
          tc =
            /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:[-a-z]+):.*?):(\d+)(?::(\d+))?\)?\s*$/i,
          td = (e) => {
            let t = tc.exec(e);
            return t
              ? te(t[2], t[1] || M.Fi, +t[3], t[4] ? +t[4] : void 0)
              : void 0;
          },
          tp = [40, td],
          tf = / line (\d+).*script (?:in )?(\S+)(?:: in function (\S+))?$/i,
          th = (e) => {
            let t = tf.exec(e);
            return t ? te(t[2], t[3] || M.Fi, +t[1]) : void 0;
          },
          tm = [10, th],
          t_ =
            / line (\d+), column (\d+)\s*(?:in (?:<anonymous function: ([^>]+)>|([^)]+))\(.*\))? in (.*):\s*$/i,
          tg = (e) => {
            let t = t_.exec(e);
            return t ? te(t[5], t[3] || t[4] || M.Fi, +t[1], +t[2]) : void 0;
          },
          tv = [20, tg],
          ty = [ti, tu],
          tb = (0, M.pE)(...ty),
          tE = (e, t) => {
            let n = -1 !== e.indexOf("safari-extension"),
              r = -1 !== e.indexOf("safari-web-extension");
            return n || r
              ? [
                  -1 !== e.indexOf("@") ? e.split("@")[0] : M.Fi,
                  n ? `safari-extension:${t}` : `safari-web-extension:${t}`,
                ]
              : [e, t];
          };
        var tS = n(39877),
          tw = n(26444);
        function tT(
          e,
          t,
          n = (function (e) {
            let t = [];
            function n(e) {
              return t.splice(t.indexOf(e), 1)[0] || Promise.resolve(void 0);
            }
            return {
              $: t,
              add: function (r) {
                if (!(void 0 === e || t.length < e))
                  return (0, J.$2)(
                    new Y(
                      "Not adding Promise because buffer limit was reached."
                    )
                  );
                let a = r();
                return (
                  -1 === t.indexOf(a) && t.push(a),
                  a
                    .then(() => n(a))
                    .then(null, () => n(a).then(null, () => {})),
                  a
                );
              },
              drain: function (e) {
                return new J.cW((n, r) => {
                  let a = t.length;
                  if (!a) return n(!0);
                  let i = setTimeout(() => {
                    e && e > 0 && n(!1);
                  }, e);
                  t.forEach((e) => {
                    (0, J.WD)(e).then(() => {
                      --a || (clearTimeout(i), n(!0));
                    }, r);
                  });
                });
              },
            };
          })(e.bufferSize || 64)
        ) {
          let r = {},
            a = (e) => n.drain(e);
          return {
            send: function (a) {
              let i = [];
              if (
                ((0, G.gv)(a, (t, n) => {
                  let a = (0, G.mL)(n);
                  if ((0, tw.Q)(r, a)) {
                    let r = tx(t, n);
                    e.recordDroppedEvent("ratelimit_backoff", a, r);
                  } else i.push(t);
                }),
                0 === i.length)
              )
                return (0, J.WD)({});
              let o = (0, G.Jd)(a[0], i),
                s = (t) => {
                  (0, G.gv)(o, (n, r) => {
                    let a = tx(n, r);
                    e.recordDroppedEvent(t, (0, G.mL)(r), a);
                  });
                },
                l = () =>
                  t({ body: (0, G.V$)(o) }).then(
                    (e) => (
                      void 0 !== e.statusCode &&
                        (e.statusCode < 200 || e.statusCode >= 300) &&
                        _.X &&
                        v.kg.warn(
                          `Sentry responded with status code ${e.statusCode} to sent event.`
                        ),
                      (r = (0, tw.WG)(r, e)),
                      e
                    ),
                    (e) => {
                      throw (s("network_error"), e);
                    }
                  );
              return n.add(l).then(
                (e) => e,
                (e) => {
                  if (e instanceof Y)
                    return (
                      _.X &&
                        v.kg.error(
                          "Skipped sending event because buffer is full."
                        ),
                      s("queue_overflow"),
                      (0, J.WD)({})
                    );
                  throw e;
                }
              );
            },
            flush: a,
          };
        }
        function tx(e, t) {
          if ("event" === t || "transaction" === t)
            return Array.isArray(e) ? e[1] : void 0;
        }
        function tk(e, t = (0, tS.L2)("fetch")) {
          let n = 0,
            r = 0;
          return tT(e, function (a) {
            let i = a.body.length;
            (n += i), r++;
            let o = {
              body: a.body,
              method: "POST",
              referrerPolicy: "origin",
              headers: e.headers,
              keepalive: n <= 6e4 && r < 15,
              ...e.fetchOptions,
            };
            if (!t)
              return (
                (0, tS._6)("fetch"),
                (0, J.$2)("No fetch implementation available")
              );
            try {
              return t(e.url, o).then(
                (e) => (
                  (n -= i),
                  r--,
                  {
                    statusCode: e.status,
                    headers: {
                      "x-sentry-rate-limits": e.headers.get(
                        "X-Sentry-Rate-Limits"
                      ),
                      "retry-after": e.headers.get("Retry-After"),
                    },
                  }
                )
              );
            } catch (e) {
              return (0, tS._6)("fetch"), (n -= i), r--, (0, J.$2)(e);
            }
          });
        }
        function tI(e) {
          let t = [I(), P(), eW(), eH(), e2(), e8(), D(), e5()];
          return !1 !== e.autoSessionTracking && t.push(eY()), t;
        }
        function tC(e = {}) {
          if (!e_.document) return;
          let t = (0, g.nZ)(),
            n = t.getClient(),
            r = n && n.getDsn();
          if (!r) return;
          if ((t && (e.user = { ...t.getUser(), ...e.user }), !e.eventId)) {
            let t = (0, m.eW)();
            t && (e.eventId = t);
          }
          let a = e_.document.createElement("script");
          (a.async = !0),
            (a.crossOrigin = "anonymous"),
            (a.src = (function (e, t) {
              let n = (0, H.vK)(e);
              if (!n) return "";
              let r = `${X(n)}embed/error-page/`,
                a = `dsn=${(0, H.RA)(n)}`;
              for (let e in t)
                if ("dsn" !== e && "onClose" !== e) {
                  if ("user" === e) {
                    let e = t.user;
                    if (!e) continue;
                    e.name && (a += `&name=${encodeURIComponent(e.name)}`),
                      e.email && (a += `&email=${encodeURIComponent(e.email)}`);
                  } else
                    a += `&${encodeURIComponent(e)}=${encodeURIComponent(
                      t[e]
                    )}`;
                }
              return `${r}?${a}`;
            })(r, e)),
            e.onLoad && (a.onload = e.onLoad);
          let { onClose: i } = e;
          if (i) {
            let e = (t) => {
              if ("__sentry_reportdialog_closed__" === t.data)
                try {
                  i();
                } finally {
                  e_.removeEventListener("message", e);
                }
            };
            e_.addEventListener("message", e);
          }
          let o = e_.document.head || e_.document.body;
          o && o.appendChild(a);
        }
        function tA() {}
        function tR(e) {
          e();
        }
        function tN(e) {
          let t = (0, g.s3)();
          t && t.captureUserFeedback(e);
        }
        var tP = n(67294),
          tM = n(83454);
        function tL(e) {
          return (
            (0, z.VZ)(e) &&
            ["NEXT_NOT_FOUND", "NEXT_HTTP_ERROR_FALLBACK;404"].includes(
              e.digest
            )
          );
        }
        function tD(e) {
          return (
            (0, z.VZ)(e) &&
            "string" == typeof e.digest &&
            e.digest.startsWith("NEXT_REDIRECT;")
          );
        }
        let tO =
          /^(\S+:\\|\/?)([\s\S]*?)((?:\.{1,2}|[^/\\]+?|)(\.[^./\\]*|))(?:[/\\]*)$/;
        function t$(...e) {
          let t = "",
            n = !1;
          for (let r = e.length - 1; r >= -1 && !n; r--) {
            let a = r >= 0 ? e[r] : "/";
            a && ((t = `${a}/${t}`), (n = "/" === a.charAt(0)));
          }
          return (
            (t = (function (e, t) {
              let n = 0;
              for (let t = e.length - 1; t >= 0; t--) {
                let r = e[t];
                "." === r
                  ? e.splice(t, 1)
                  : ".." === r
                  ? (e.splice(t, 1), n++)
                  : n && (e.splice(t, 1), n--);
              }
              if (t) for (; n--; n) e.unshift("..");
              return e;
            })(
              t.split("/").filter((e) => !!e),
              !n
            ).join("/")),
            (n ? "/" : "") + t || "."
          );
        }
        function tF(e) {
          let t = 0;
          for (; t < e.length && "" === e[t]; t++);
          let n = e.length - 1;
          for (; n >= 0 && "" === e[n]; n--);
          return t > n ? [] : e.slice(t, n - t + 1);
        }
        let tU = (e = {}) => {
            let t = e.root,
              n = e.prefix || "app:///",
              r = "window" in em.n && void 0 !== em.n.window,
              a =
                e.iteratee ||
                (function ({ isBrowser: e, root: t, prefix: n }) {
                  return (r) => {
                    if (!r.filename) return r;
                    let a =
                        /^[a-zA-Z]:\\/.test(r.filename) ||
                        (r.filename.includes("\\") &&
                          !r.filename.includes("/")),
                      i = /^\//.test(r.filename);
                    if (e) {
                      if (t) {
                        let e = r.filename;
                        0 === e.indexOf(t) && (r.filename = e.replace(t, n));
                      }
                    } else if (a || i) {
                      var o;
                      let e;
                      let i = a
                          ? r.filename
                              .replace(/^[a-zA-Z]:/, "")
                              .replace(/\\/g, "/")
                          : r.filename,
                        s = t
                          ? (function (e, t) {
                              (e = t$(e).slice(1)), (t = t$(t).slice(1));
                              let n = tF(e.split("/")),
                                r = tF(t.split("/")),
                                a = Math.min(n.length, r.length),
                                i = a;
                              for (let e = 0; e < a; e++)
                                if (n[e] !== r[e]) {
                                  i = e;
                                  break;
                                }
                              let o = [];
                              for (let e = i; e < n.length; e++) o.push("..");
                              return (o = o.concat(r.slice(i))).join("/");
                            })(t, i)
                          : ((e =
                              (function (e) {
                                let t =
                                    e.length > 1024
                                      ? `<truncated>${e.slice(-1024)}`
                                      : e,
                                  n = tO.exec(t);
                                return n ? n.slice(1) : [];
                              })(i)[2] || ""),
                            o &&
                              e.slice(-1 * o.length) === o &&
                              (e = e.slice(0, e.length - o.length)),
                            e);
                      r.filename = `${n}${s}`;
                    }
                    return r;
                  };
                })({ isBrowser: r, root: t, prefix: n });
            return {
              name: "RewriteFrames",
              processEvent(e) {
                let t = e;
                return (
                  e.exception &&
                    Array.isArray(e.exception.values) &&
                    (t = (function (e) {
                      try {
                        return {
                          ...e,
                          exception: {
                            ...e.exception,
                            values: e.exception.values.map((e) => {
                              var t;
                              return {
                                ...e,
                                ...(e.stacktrace && {
                                  stacktrace: {
                                    ...(t = e.stacktrace),
                                    frames:
                                      t &&
                                      t.frames &&
                                      t.frames.map((e) => a(e)),
                                  },
                                }),
                              };
                            }),
                          },
                        };
                      } catch (t) {
                        return e;
                      }
                    })(t)),
                  t
                );
              },
            };
          },
          tj = ({ assetPrefixPath: e }) => {
            let t = tU({
              iteratee: (t) => {
                try {
                  let { origin: n } = new URL(t.filename);
                  t.filename = (0, p.x)([
                    t,
                    "access",
                    (e) => e.filename,
                    "optionalAccess",
                    (e) => e.replace,
                    "call",
                    (e) => e(n, "app://"),
                    "access",
                    (e) => e.replace,
                    "call",
                    (t) => t(e, ""),
                  ]);
                } catch (e) {}
                return (
                  t.filename &&
                    t.filename.startsWith("app:///_next") &&
                    (t.filename = decodeURI(t.filename)),
                  t.filename &&
                    t.filename.match(
                      /^app:\/\/\/_next\/static\/chunks\/(main-|main-app-|polyfills-|webpack-|framework-|framework\.)[0-9a-f]+\.js$/
                    ) &&
                    (t.in_app = !1),
                  t
                );
              },
            });
            return { ...t, name: "NextjsClientStackFrameNormalization" };
          };
        var tH = n(3e4),
          tX = n(31218);
        function tB(e, t, n, r = (0, q.HN)()) {
          let a = r && (0, q.Gx)(r);
          a &&
            (_.X &&
              v.kg.log(
                `[Measurement] Setting measurement on root span: ${e} = ${t} ${n}`
              ),
            a.addEvent(e, { [tX.Wb]: t, [tX.E1]: n }));
        }
        function tW(e) {
          if (!e || 0 === e.length) return;
          let t = {};
          return (
            e.forEach((e) => {
              let n = e.attributes || {},
                r = n[tX.E1],
                a = n[tX.Wb];
              "string" == typeof r &&
                "number" == typeof a &&
                (t[e.name] = { value: a, unit: r });
            }),
            t
          );
        }
        var tG = n(23039),
          tq = n(12016),
          tZ = n(22480),
          tV = n(13533),
          tY = n(60811),
          tz = n(51824),
          tJ = n(94801);
        function tK(e, t, n = () => {}) {
          var r;
          let a;
          try {
            a = e();
          } catch (e) {
            throw (t(e), n(), e);
          }
          return (
            (r = a),
            (0, z.J8)(r)
              ? r.then(
                  (e) => (n(), e),
                  (e) => {
                    throw (t(e), n(), e);
                  }
                )
              : (n(), r)
          );
        }
        var tQ = n(67973),
          t0 = n(89366);
        class t1 {
          constructor(e = {}) {
            (this._traceId = e.traceId || (0, tz.Ht)()),
              (this._spanId = e.spanId || (0, tz.M)());
          }
          spanContext() {
            return {
              spanId: this._spanId,
              traceId: this._traceId,
              traceFlags: q.ve,
            };
          }
          end(e) {}
          setAttribute(e, t) {
            return this;
          }
          setAttributes(e) {
            return this;
          }
          setStatus(e) {
            return this;
          }
          updateName(e) {
            return this;
          }
          isRecording() {
            return !1;
          }
          addEvent(e, t, n) {
            return this;
          }
          addLink(e) {
            return this;
          }
          addLinks(e) {
            return this;
          }
          recordException(e, t) {}
        }
        var t3 = n(72751);
        let t2 = "_sentryScope",
          t4 = "_sentryIsolationScope";
        function t5(e, t, n) {
          e && ((0, A.xp)(e, t4, n), (0, A.xp)(e, t2, t));
        }
        function t6(e) {
          return { scope: e[t2], isolationScope: e[t4] };
        }
        class t9 {
          constructor(e = {}) {
            (this._traceId = e.traceId || (0, tz.Ht)()),
              (this._spanId = e.spanId || (0, tz.M)()),
              (this._startTime = e.startTimestamp || (0, V.ph)()),
              (this._attributes = {}),
              this.setAttributes({
                [tX.S3]: "manual",
                [tX.$J]: e.op,
                ...e.attributes,
              }),
              (this._name = e.name),
              e.parentSpanId && (this._parentSpanId = e.parentSpanId),
              "sampled" in e && (this._sampled = e.sampled),
              e.endTimestamp && (this._endTime = e.endTimestamp),
              (this._events = []),
              (this._isStandaloneSpan = e.isStandalone),
              this._endTime && this._onSpanEnded();
          }
          addLink(e) {
            return this;
          }
          addLinks(e) {
            return this;
          }
          recordException(e, t) {}
          spanContext() {
            let { _spanId: e, _traceId: t, _sampled: n } = this;
            return { spanId: e, traceId: t, traceFlags: n ? q.i0 : q.ve };
          }
          setAttribute(e, t) {
            return (
              void 0 === t
                ? delete this._attributes[e]
                : (this._attributes[e] = t),
              this
            );
          }
          setAttributes(e) {
            return (
              Object.keys(e).forEach((t) => this.setAttribute(t, e[t])), this
            );
          }
          updateStartTime(e) {
            this._startTime = (0, q.$k)(e);
          }
          setStatus(e) {
            return (this._status = e), this;
          }
          updateName(e) {
            return (this._name = e), this.setAttribute(tX.Zj, "custom"), this;
          }
          end(e) {
            this._endTime ||
              ((this._endTime = (0, q.$k)(e)),
              (function (e) {
                if (!_.X) return;
                let {
                    description: t = "< unknown name >",
                    op: n = "< unknown op >",
                  } = (0, q.XU)(e),
                  { spanId: r } = e.spanContext(),
                  a = (0, q.Gx)(e),
                  i = `[Tracing] Finishing "${n}" ${
                    a === e ? "root " : ""
                  }span "${t}" with ID ${r}`;
                v.kg.log(i);
              })(this),
              this._onSpanEnded());
          }
          getSpanJSON() {
            return (0, A.Jr)({
              data: this._attributes,
              description: this._name,
              op: this._attributes[tX.$J],
              parent_span_id: this._parentSpanId,
              span_id: this._spanId,
              start_timestamp: this._startTime,
              status: (0, q._4)(this._status),
              timestamp: this._endTime,
              trace_id: this._traceId,
              origin: this._attributes[tX.S3],
              _metrics_summary: (0, t3.y)(this),
              profile_id: this._attributes[tX.p6],
              exclusive_time: this._attributes[tX.JQ],
              measurements: tW(this._events),
              is_segment:
                (this._isStandaloneSpan && (0, q.Gx)(this) === this) || void 0,
              segment_id: this._isStandaloneSpan
                ? (0, q.Gx)(this).spanContext().spanId
                : void 0,
            });
          }
          isRecording() {
            return !this._endTime && !!this._sampled;
          }
          addEvent(e, t, n) {
            _.X && v.kg.log("[Tracing] Adding an event to span:", e);
            let r = t7(t) ? t : n || (0, V.ph)(),
              a = t7(t) ? {} : t || {},
              i = { name: e, time: (0, q.$k)(r), attributes: a };
            return this._events.push(i), this;
          }
          isStandaloneSpan() {
            return !!this._isStandaloneSpan;
          }
          _onSpanEnded() {
            let e = (0, g.s3)();
            e && e.emit("spanEnd", this);
            let t = this._isStandaloneSpan || this === (0, q.Gx)(this);
            if (!t) return;
            if (this._isStandaloneSpan) {
              this._sampled
                ? (function (e) {
                    let t = (0, g.s3)();
                    if (!t) return;
                    let n = e[1];
                    if (!n || 0 === n.length) {
                      t.recordDroppedEvent("before_send", "span");
                      return;
                    }
                    t.sendEnvelope(e);
                  })(
                    (function (e, t) {
                      let n = (0, W.jC)(e[0]),
                        r = t && t.getDsn(),
                        a = t && t.getOptions().tunnel,
                        i = {
                          sent_at: new Date().toISOString(),
                          ...(!!n.trace_id && !!n.public_key && { trace: n }),
                          ...(!!a && r && { dsn: (0, H.RA)(r) }),
                        },
                        o = t && t.getOptions().beforeSendSpan,
                        s = o
                          ? (e) => {
                              let t = o((0, q.XU)(e));
                              return t || (0, q.R6)(), t;
                            }
                          : (e) => (0, q.XU)(e),
                        l = [];
                      for (let t of e) {
                        let e = s(t);
                        e && l.push((0, G.KQ)(e));
                      }
                      return (0, G.Jd)(i, l);
                    })([this], e)
                  )
                : (_.X &&
                    v.kg.log(
                      "[Tracing] Discarding standalone span because its trace was not chosen to be sampled."
                    ),
                  e && e.recordDroppedEvent("sample_rate", "span"));
              return;
            }
            let n = this._convertSpanToTransaction();
            if (n) {
              let e = t6(this).scope || (0, g.nZ)();
              e.captureEvent(n);
            }
          }
          _convertSpanToTransaction() {
            if (!t8((0, q.XU)(this))) return;
            this._name ||
              (_.X &&
                v.kg.warn(
                  "Transaction has no name, falling back to `<unlabeled transaction>`."
                ),
              (this._name = "<unlabeled transaction>"));
            let { scope: e, isolationScope: t } = t6(this),
              n = e || (0, g.nZ)(),
              r = n.getClient() || (0, g.s3)();
            if (!0 !== this._sampled) {
              _.X &&
                v.kg.log(
                  "[Tracing] Discarding transaction because its trace was not chosen to be sampled."
                ),
                r && r.recordDroppedEvent("sample_rate", "transaction");
              return;
            }
            let a = (0, q.Dp)(this).filter(
                (e) => e !== this && !(e instanceof t9 && e.isStandaloneSpan())
              ),
              i = a.map((e) => (0, q.XU)(e)).filter(t8),
              o = this._attributes[tX.Zj],
              s = {
                contexts: { trace: (0, q.HR)(this) },
                spans:
                  i.length > 1e3
                    ? i
                        .sort((e, t) => e.start_timestamp - t.start_timestamp)
                        .slice(0, 1e3)
                    : i,
                start_timestamp: this._startTime,
                timestamp: this._endTime,
                transaction: this._name,
                type: "transaction",
                sdkProcessingMetadata: {
                  capturedSpanScope: e,
                  capturedSpanIsolationScope: t,
                  ...(0, A.Jr)({ dynamicSamplingContext: (0, W.jC)(this) }),
                },
                _metrics_summary: (0, t3.y)(this),
                ...(o && { transaction_info: { source: o } }),
              },
              l = tW(this._events),
              u = l && Object.keys(l).length;
            return (
              u &&
                (_.X &&
                  v.kg.log(
                    "[Measurements] Adding measurements to transaction event",
                    JSON.stringify(l, void 0, 2)
                  ),
                (s.measurements = l)),
              s
            );
          }
        }
        function t7(e) {
          return (
            (e && "number" == typeof e) || e instanceof Date || Array.isArray(e)
          );
        }
        function t8(e) {
          return (
            !!e.start_timestamp && !!e.timestamp && !!e.span_id && !!e.trace_id
          );
        }
        var ne = n(69737);
        let nt = "__SENTRY_SUPPRESS_TRACING__";
        function nn(e, t) {
          let n = nd();
          if (n.startSpan) return n.startSpan(e, t);
          let r = nc(e),
            { forceTransaction: a, parentSpan: i } = e;
          return (0, g.$e)(e.scope, () => {
            let n = nh(i);
            return n(() => {
              let n = (0, g.nZ)(),
                i = nf(n),
                o = e.onlyIfParent && !i,
                s = o
                  ? new t1()
                  : nu({
                      parentSpan: i,
                      spanArguments: r,
                      forceTransaction: a,
                      scope: n,
                    });
              return (
                (0, t0.D)(n, s),
                tK(
                  () => t(s),
                  () => {
                    let { status: e } = (0, q.XU)(s);
                    s.isRecording() &&
                      (!e || "ok" === e) &&
                      s.setStatus({ code: ne.jt, message: "internal_error" });
                  },
                  () => s.end()
                )
              );
            });
          });
        }
        function nr(e, t) {
          let n = nd();
          if (n.startSpanManual) return n.startSpanManual(e, t);
          let r = nc(e),
            { forceTransaction: a, parentSpan: i } = e;
          return (0, g.$e)(e.scope, () => {
            let n = nh(i);
            return n(() => {
              let n = (0, g.nZ)(),
                i = nf(n),
                o = e.onlyIfParent && !i,
                s = o
                  ? new t1()
                  : nu({
                      parentSpan: i,
                      spanArguments: r,
                      forceTransaction: a,
                      scope: n,
                    });
              function l() {
                s.end();
              }
              return (
                (0, t0.D)(n, s),
                tK(
                  () => t(s, l),
                  () => {
                    let { status: e } = (0, q.XU)(s);
                    s.isRecording() &&
                      (!e || "ok" === e) &&
                      s.setStatus({ code: ne.jt, message: "internal_error" });
                  }
                )
              );
            });
          });
        }
        function na(e) {
          let t = nd();
          if (t.startInactiveSpan) return t.startInactiveSpan(e);
          let n = nc(e),
            { forceTransaction: r, parentSpan: a } = e,
            i = e.scope
              ? (t) => (0, g.$e)(e.scope, t)
              : void 0 !== a
              ? (e) => no(a, e)
              : (e) => e();
          return i(() => {
            let t = (0, g.nZ)(),
              a = nf(t),
              i = e.onlyIfParent && !a;
            return i
              ? new t1()
              : nu({
                  parentSpan: a,
                  spanArguments: n,
                  forceTransaction: r,
                  scope: t,
                });
          });
        }
        let ni = ({ sentryTrace: e, baggage: t }, n) =>
          (0, g.$e)((r) => {
            let a = (0, tJ.pT)(e, t);
            return r.setPropagationContext(a), n();
          });
        function no(e, t) {
          let n = nd();
          return n.withActiveSpan
            ? n.withActiveSpan(e, t)
            : (0, g.$e)((n) => ((0, t0.D)(n, e || void 0), t(n)));
        }
        function ns(e) {
          let t = nd();
          return t.suppressTracing
            ? t.suppressTracing(e)
            : (0, g.$e)((t) => (t.setSDKProcessingMetadata({ [nt]: !0 }), e()));
        }
        function nl(e) {
          return (0, g.$e)(
            (t) => (
              t.setPropagationContext({ traceId: (0, tz.Ht)() }),
              _.X &&
                v.kg.info(
                  `Starting a new trace with id ${
                    t.getPropagationContext().traceId
                  }`
                ),
              no(null, e)
            )
          );
        }
        function nu({
          parentSpan: e,
          spanArguments: t,
          forceTransaction: n,
          scope: r,
        }) {
          let a;
          if (!(0, tQ.z)()) return new t1();
          let i = (0, g.aF)();
          if (e && !n)
            (a = (function (e, t, n) {
              let { spanId: r, traceId: a } = e.spanContext(),
                i = !t.getScopeData().sdkProcessingMetadata[nt] && (0, q.Tt)(e),
                o = i
                  ? new t9({ ...n, parentSpanId: r, traceId: a, sampled: i })
                  : new t1({ traceId: a });
              (0, q.j5)(e, o);
              let s = (0, g.s3)();
              return (
                s &&
                  (s.emit("spanStart", o),
                  n.endTimestamp && s.emit("spanEnd", o)),
                o
              );
            })(e, r, t)),
              (0, q.j5)(e, a);
          else if (e) {
            let n = (0, W.jC)(e),
              { traceId: i, spanId: o } = e.spanContext(),
              s = (0, q.Tt)(e);
            (a = np({ traceId: i, parentSpanId: o, ...t }, r, s)),
              (0, W.Lh)(a, n);
          } else {
            let {
              traceId: e,
              dsc: n,
              parentSpanId: o,
              sampled: s,
            } = { ...i.getPropagationContext(), ...r.getPropagationContext() };
            (a = np({ traceId: e, parentSpanId: o, ...t }, r, s)),
              n && (0, W.Lh)(a, n);
          }
          return (
            (function (e) {
              if (!_.X) return;
              let {
                  description: t = "< unknown name >",
                  op: n = "< unknown op >",
                  parent_span_id: r,
                } = (0, q.XU)(e),
                { spanId: a } = e.spanContext(),
                i = (0, q.Tt)(e),
                o = (0, q.Gx)(e),
                s = o === e,
                l = `[Tracing] Starting ${i ? "sampled" : "unsampled"} ${
                  s ? "root " : ""
                }span`,
                u = [`op: ${n}`, `name: ${t}`, `ID: ${a}`];
              if ((r && u.push(`parent ID: ${r}`), !s)) {
                let { op: e, description: t } = (0, q.XU)(o);
                u.push(`root ID: ${o.spanContext().spanId}`),
                  e && u.push(`root op: ${e}`),
                  t && u.push(`root description: ${t}`);
              }
              v.kg.log(`${l}
  ${u.join("\n  ")}`);
            })(a),
            t5(a, r, i),
            a
          );
        }
        function nc(e) {
          let t = e.experimental || {},
            n = { isStandalone: t.standalone, ...e };
          if (e.startTime) {
            let t = { ...n };
            return (
              (t.startTimestamp = (0, q.$k)(e.startTime)), delete t.startTime, t
            );
          }
          return n;
        }
        function nd() {
          let e = (0, tV.c)();
          return (0, tY.G)(e);
        }
        function np(e, t, n) {
          let r = (0, g.s3)(),
            a = (r && r.getOptions()) || {},
            { name: i = "", attributes: o } = e,
            [s, l] = t.getScopeData().sdkProcessingMetadata[nt]
              ? [!1]
              : (function (e, t) {
                  let n;
                  if (!(0, tQ.z)(e)) return [!1];
                  n =
                    "function" == typeof e.tracesSampler
                      ? e.tracesSampler(t)
                      : void 0 !== t.parentSampled
                      ? t.parentSampled
                      : void 0 !== e.tracesSampleRate
                      ? e.tracesSampleRate
                      : 1;
                  let r = (0, K.o)(n);
                  return void 0 === r
                    ? (_.X &&
                        v.kg.warn(
                          "[Tracing] Discarding transaction because of invalid sample rate."
                        ),
                      [!1])
                    : r
                    ? Math.random() < r
                      ? [!0, r]
                      : (_.X &&
                          v.kg.log(
                            `[Tracing] Discarding transaction because it's not included in the random sample (sampling rate = ${Number(
                              n
                            )})`
                          ),
                        [!1, r])
                    : (_.X &&
                        v.kg.log(
                          `[Tracing] Discarding transaction because ${
                            "function" == typeof e.tracesSampler
                              ? "tracesSampler returned 0 or false"
                              : "a negative sampling decision was inherited or tracesSampleRate is set to 0"
                          }`
                        ),
                      [!1, r]);
                })(a, {
                  name: i,
                  parentSampled: n,
                  attributes: o,
                  transactionContext: { name: i, parentSampled: n },
                }),
            u = new t9({
              ...e,
              attributes: { [tX.Zj]: "custom", ...e.attributes },
              sampled: s,
            });
          return (
            void 0 !== l && u.setAttribute(tX.TE, l),
            r && r.emit("spanStart", u),
            u
          );
        }
        function nf(e) {
          let t = (0, t0.Y)(e);
          if (!t) return;
          let n = (0, g.s3)(),
            r = n ? n.getOptions() : {};
          return r.parentSpanIsAlwaysRootSpan ? (0, q.Gx)(t) : t;
        }
        function nh(e) {
          return void 0 !== e ? (t) => no(e, t) : (e) => e();
        }
        function nm(e) {
          return "number" == typeof e && isFinite(e);
        }
        function n_(e, t, n, { ...r }) {
          let a = (0, q.XU)(e).start_timestamp;
          return (
            a &&
              a > t &&
              "function" == typeof e.updateStartTime &&
              e.updateStartTime(t),
            no(e, () => {
              let e = na({ startTime: t, ...r });
              return e && e.end(n), e;
            })
          );
        }
        function ng(e) {
          let t;
          let n = (0, g.s3)();
          if (!n) return;
          let { name: r, transaction: a, attributes: i, startTime: o } = e,
            { release: s, environment: l } = n.getOptions(),
            u = n.getIntegrationByName("Replay"),
            c = u && u.getReplayId(),
            d = (0, g.nZ)(),
            p = d.getUser(),
            f = void 0 !== p ? p.email || p.id || p.ip_address : void 0;
          try {
            t = d.getScopeData().contexts.profile.profile_id;
          } catch (e) {}
          let h = {
            release: s,
            environment: l,
            user: f || void 0,
            profile_id: t || void 0,
            replay_id: c || void 0,
            transaction: a,
            "user_agent.original": tG.m.navigator && tG.m.navigator.userAgent,
            ...i,
          };
          return na({
            name: r,
            attributes: h,
            startTime: o,
            experimental: { standalone: !0 },
          });
        }
        function nv() {
          return tG.m && tG.m.addEventListener && tG.m.performance;
        }
        function ny(e) {
          return e / 1e3;
        }
        var nb = n(30378),
          nE = n(32599),
          nS = n(74181),
          nw = n(49250);
        let nT = 0,
          nx = {};
        function nk(e, t, n, r, a, i) {
          let o = i ? t[i] : t[`${n}End`],
            s = t[`${n}Start`];
          s &&
            o &&
            n_(e, r + ny(s), r + ny(o), {
              op: `browser.${a || n}`,
              name: t.name,
              attributes: { [tX.S3]: "auto.ui.browser.metrics" },
            });
        }
        function nI(e, t, n, r) {
          let a = t[n];
          null != a && a < 2147483647 && (e[r] = a);
        }
        let nC = [],
          nA = new Map(),
          nR = {
            click: "click",
            pointerdown: "click",
            pointerup: "click",
            mousedown: "click",
            mouseup: "click",
            touchstart: "click",
            touchend: "click",
            mouseover: "hover",
            mouseout: "hover",
            mouseenter: "hover",
            mouseleave: "hover",
            pointerover: "hover",
            pointerout: "hover",
            pointerenter: "hover",
            pointerleave: "hover",
            dragstart: "drag",
            dragend: "drag",
            drag: "drag",
            dragenter: "drag",
            dragleave: "drag",
            dragover: "drag",
            drop: "drag",
            keydown: "press",
            keyup: "press",
            keypress: "press",
            input: "press",
          },
          nN = { idleTimeout: 1e3, finalTimeout: 3e4, childSpanTimeout: 15e3 };
        function nP(e, t = {}) {
          let n;
          let r = new Map(),
            a = !1,
            i = "externalFinish",
            o = !t.disableAutoFinish,
            s = [],
            {
              idleTimeout: l = nN.idleTimeout,
              finalTimeout: u = nN.finalTimeout,
              childSpanTimeout: c = nN.childSpanTimeout,
              beforeSpanEnd: d,
            } = t,
            p = (0, g.s3)();
          if (!p || !(0, tQ.z)()) return new t1();
          let f = (0, g.nZ)(),
            h = (0, q.HN)(),
            m = (function (e) {
              let t = na(e);
              return (
                (0, t0.D)((0, g.nZ)(), t),
                _.X && v.kg.log("[Tracing] Started span is an idle span"),
                t
              );
            })(e);
          function y() {
            n && (clearTimeout(n), (n = void 0));
          }
          function b(e) {
            y(),
              (n = setTimeout(() => {
                !a && 0 === r.size && o && ((i = "idleTimeout"), m.end(e));
              }, l));
          }
          function E(e) {
            n = setTimeout(() => {
              !a && o && ((i = "heartbeatFailed"), m.end(e));
            }, c);
          }
          function S(e) {
            (a = !0), r.clear(), s.forEach((e) => e()), (0, t0.D)(f, h);
            let t = (0, q.XU)(m),
              { start_timestamp: n } = t;
            if (!n) return;
            let o = t.data || {};
            o[tX.ju] || m.setAttribute(tX.ju, i),
              v.kg.log(`[Tracing] Idle span "${t.op}" finished`);
            let c = (0, q.Dp)(m).filter((e) => e !== m),
              d = 0;
            c.forEach((t) => {
              t.isRecording() &&
                (t.setStatus({ code: ne.jt, message: "cancelled" }),
                t.end(e),
                _.X &&
                  v.kg.log(
                    "[Tracing] Cancelling span since span ended early",
                    JSON.stringify(t, void 0, 2)
                  ));
              let n = (0, q.XU)(t),
                { timestamp: r = 0, start_timestamp: a = 0 } = n,
                i = a <= e,
                o = r - a <= (u + l) / 1e3;
              if (_.X) {
                let e = JSON.stringify(t, void 0, 2);
                i
                  ? o ||
                    v.kg.log(
                      "[Tracing] Discarding span since it finished after idle span final timeout",
                      e
                    )
                  : v.kg.log(
                      "[Tracing] Discarding span since it happened after idle span was finished",
                      e
                    );
              }
              (!o || !i) && ((0, q.ed)(m, t), d++);
            }),
              d > 0 && m.setAttribute("sentry.idle_span_discarded_spans", d);
          }
          return (
            (m.end = new Proxy(m.end, {
              apply(e, t, n) {
                d && d(m);
                let [r, ...a] = n,
                  i = r || (0, V.ph)(),
                  o = (0, q.$k)(i),
                  s = (0, q.Dp)(m).filter((e) => e !== m);
                if (!s.length) return S(o), Reflect.apply(e, t, [o, ...a]);
                let l = s.map((e) => (0, q.XU)(e).timestamp).filter((e) => !!e),
                  c = l.length ? Math.max(...l) : void 0,
                  p = (0, q.XU)(m).start_timestamp,
                  f = Math.min(
                    p ? p + u / 1e3 : 1 / 0,
                    Math.max(p || -1 / 0, Math.min(o, c || 1 / 0))
                  );
                return S(f), Reflect.apply(e, t, [f, ...a]);
              },
            })),
            s.push(
              p.on("spanStart", (e) => {
                if (a || e === m || (0, q.XU)(e).timestamp) return;
                let t = (0, q.Dp)(m);
                t.includes(e) &&
                  (function (e) {
                    y(), r.set(e, !0);
                    let t = (0, V.ph)();
                    E(t + c / 1e3);
                  })(e.spanContext().spanId);
              })
            ),
            s.push(
              p.on("spanEnd", (e) => {
                a ||
                  (function (e) {
                    if ((r.has(e) && r.delete(e), 0 === r.size)) {
                      let e = (0, V.ph)();
                      b(e + l / 1e3);
                    }
                  })(e.spanContext().spanId);
              })
            ),
            s.push(
              p.on("idleSpanEnableAutoFinish", (e) => {
                e === m && ((o = !0), b(), r.size && E());
              })
            ),
            t.disableAutoFinish || b(),
            setTimeout(() => {
              a ||
                (m.setStatus({ code: ne.jt, message: "deadline_exceeded" }),
                (i = "finalTimeout"),
                m.end());
            }, u),
            m
          );
        }
        let nM = !1;
        function nL() {
          nM || ((nM = !0), eJ(nD), e0(nD));
        }
        function nD() {
          let e = (0, q.HN)(),
            t = e && (0, q.Gx)(e);
          if (t) {
            let e = "internal_error";
            _.X &&
              v.kg.log(`[Tracing] Root span: ${e} -> Global error occurred`),
              t.setStatus({ code: ne.jt, message: e });
          }
        }
        nD.tag = "sentry_tracingErrorCallback";
        var nO = n(98823);
        function n$(e = {}) {
          let t = (0, g.s3)();
          if (!(0, m._k)() || !t) return {};
          let n = (0, tV.c)(),
            r = (0, tY.G)(n);
          if (r.getTraceData) return r.getTraceData(e);
          let a = (0, g.nZ)(),
            i = e.span || (0, q.HN)(),
            o = i
              ? (0, q.Hb)(i)
              : (function (e) {
                  let {
                    traceId: t,
                    sampled: n,
                    spanId: r,
                  } = e.getPropagationContext();
                  return (0, tJ.$p)(t, r, n);
                })(a),
            s = i ? (0, W.jC)(i) : (0, W.CG)(t, a),
            l = (0, nO.IQ)(s),
            u = tJ.Ke.test(o);
          return u
            ? { "sentry-trace": o, baggage: l }
            : (v.kg.warn(
                "Invalid sentry-trace data. Cannot generate trace data"
              ),
              {});
        }
        function nF(e) {
          return e
            .split(",")
            .filter((e) => !e.split("=")[0].startsWith(nO.lq))
            .join(",");
        }
        let nU = new WeakMap(),
          nj = new Map(),
          nH = {
            traceFetch: !0,
            traceXHR: !0,
            enableHTTPTimings: !0,
            trackFetchStreamPerformance: !1,
          };
        function nX(e, t) {
          let {
              traceFetch: n,
              traceXHR: r,
              trackFetchStreamPerformance: a,
              shouldCreateSpanForRequest: i,
              enableHTTPTimings: o,
              tracePropagationTargets: s,
            } = {
              traceFetch: nH.traceFetch,
              traceXHR: nH.traceXHR,
              trackFetchStreamPerformance: nH.trackFetchStreamPerformance,
              ...t,
            },
            l = "function" == typeof i ? i : (e) => !0,
            u = (e) =>
              (function (e, t) {
                let n = e_.location && e_.location.href;
                if (n) {
                  let r, a;
                  try {
                    (r = new URL(e, n)), (a = new URL(n).origin);
                  } catch (e) {
                    return !1;
                  }
                  let i = r.origin === a;
                  return t
                    ? (0, T.U0)(r.toString(), t) ||
                        (i && (0, T.U0)(r.pathname, t))
                    : i;
                }
                {
                  let n = !!e.match(/^\/(?!\/)/);
                  return t ? (0, T.U0)(e, t) : n;
                }
              })(e, s),
            c = {};
          n &&
            (e.addEventProcessor(
              (e) => (
                "transaction" === e.type &&
                  e.spans &&
                  e.spans.forEach((e) => {
                    if ("http.client" === e.op) {
                      let t = nj.get(e.span_id);
                      t && ((e.timestamp = t / 1e3), nj.delete(e.span_id));
                    }
                  }),
                e
              )
            ),
            a &&
              (function (e) {
                let t = "fetch-body-resolved";
                (0, eT.Hj)(t, e), (0, eT.D2)(t, () => eC(eR));
              })((e) => {
                if (e.response) {
                  let t = nU.get(e.response);
                  t && e.endTimestamp && nj.set(t, e.endTimestamp);
                }
              }),
            eI((e) => {
              let t = (function (e, t, n, r, a = "auto.http.browser") {
                if (!e.fetchData) return;
                let i = (0, tQ.z)() && t(e.fetchData.url);
                if (e.endTimestamp && i) {
                  let t = e.fetchData.__span;
                  if (!t) return;
                  let n = r[t];
                  n &&
                    ((function (e, t) {
                      if (t.response) {
                        (0, ne.Q0)(e, t.response.status);
                        let n =
                          t.response &&
                          t.response.headers &&
                          t.response.headers.get("content-length");
                        if (n) {
                          let t = parseInt(n);
                          t > 0 &&
                            e.setAttribute("http.response_content_length", t);
                        }
                      } else
                        t.error &&
                          e.setStatus({
                            code: ne.jt,
                            message: "internal_error",
                          });
                      e.end();
                    })(n, e),
                    delete r[t]);
                  return;
                }
                let { method: o, url: s } = e.fetchData,
                  l = (function (e) {
                    try {
                      let t = new URL(e);
                      return t.href;
                    } catch (e) {
                      return;
                    }
                  })(s),
                  u = l ? e$(l).host : void 0,
                  c = !!(0, q.HN)(),
                  d =
                    i && c
                      ? na({
                          name: `${o} ${s}`,
                          attributes: {
                            url: s,
                            type: "fetch",
                            "http.method": o,
                            "http.url": l,
                            "server.address": u,
                            [tX.S3]: a,
                            [tX.$J]: "http.client",
                          },
                        })
                      : new t1();
                if (
                  ((e.fetchData.__span = d.spanContext().spanId),
                  (r[d.spanContext().spanId] = d),
                  n(e.fetchData.url))
                ) {
                  let t = e.args[0],
                    n = e.args[1] || {},
                    r = (function (e, t, n) {
                      let r = n$({ span: n }),
                        a = r["sentry-trace"],
                        i = r.baggage;
                      if (!a) return;
                      let o =
                        t.headers ||
                        ("undefined" != typeof Request && (0, z.V9)(e, Request)
                          ? e.headers
                          : void 0);
                      if (!o) return { ...r };
                      if (
                        "undefined" != typeof Headers &&
                        (0, z.V9)(o, Headers)
                      ) {
                        let e = new Headers(o);
                        if ((e.set("sentry-trace", a), i)) {
                          let t = e.get("baggage");
                          if (t) {
                            let n = nF(t);
                            e.set("baggage", n ? `${n},${i}` : i);
                          } else e.set("baggage", i);
                        }
                        return e;
                      }
                      if (Array.isArray(o)) {
                        let e = [
                          ...o
                            .filter(
                              (e) =>
                                !(Array.isArray(e) && "sentry-trace" === e[0])
                            )
                            .map((e) => {
                              if (
                                !Array.isArray(e) ||
                                "baggage" !== e[0] ||
                                "string" != typeof e[1]
                              )
                                return e;
                              {
                                let [t, n, ...r] = e;
                                return [t, nF(n), ...r];
                              }
                            }),
                          ["sentry-trace", a],
                        ];
                        return i && e.push(["baggage", i]), e;
                      }
                      {
                        let e = "baggage" in o ? o.baggage : void 0,
                          t = [];
                        return (
                          Array.isArray(e)
                            ? (t = e
                                .map((e) => ("string" == typeof e ? nF(e) : e))
                                .filter((e) => "" === e))
                            : e && t.push(nF(e)),
                          i && t.push(i),
                          {
                            ...o,
                            "sentry-trace": a,
                            baggage: t.length > 0 ? t.join(",") : void 0,
                          }
                        );
                      }
                    })(t, n, (0, tQ.z)() && c ? d : void 0);
                  r && ((e.args[1] = n), (n.headers = r));
                }
                return d;
              })(e, l, u, c);
              if (
                (e.response &&
                  e.fetchData.__span &&
                  nU.set(e.response, e.fetchData.__span),
                t)
              ) {
                let n = nG(e.fetchData.url),
                  r = n ? e$(n).host : void 0;
                t.setAttributes({ "http.url": n, "server.address": r });
              }
              o && t && nB(t);
            })),
            r &&
              (0, eS.UK)((e) => {
                let t = (function (e, t, n, r) {
                  let a = e.xhr,
                    i = a && a[eS.xU];
                  if (!a || a.__sentry_own_request__ || !i) return;
                  let o = (0, tQ.z)() && t(i.url);
                  if (e.endTimestamp && o) {
                    let e = a.__sentry_xhr_span_id__;
                    if (!e) return;
                    let t = r[e];
                    t &&
                      void 0 !== i.status_code &&
                      ((0, ne.Q0)(t, i.status_code), t.end(), delete r[e]);
                    return;
                  }
                  let s = nG(i.url),
                    l = s ? e$(s).host : void 0,
                    u = !!(0, q.HN)(),
                    c =
                      o && u
                        ? na({
                            name: `${i.method} ${i.url}`,
                            attributes: {
                              type: "xhr",
                              "http.method": i.method,
                              "http.url": s,
                              url: i.url,
                              "server.address": l,
                              [tX.S3]: "auto.http.browser",
                              [tX.$J]: "http.client",
                            },
                          })
                        : new t1();
                  return (
                    (a.__sentry_xhr_span_id__ = c.spanContext().spanId),
                    (r[a.__sentry_xhr_span_id__] = c),
                    n(i.url) &&
                      (function (e, t) {
                        let { "sentry-trace": n, baggage: r } = n$({ span: t });
                        n &&
                          (function (e, t, n) {
                            try {
                              e.setRequestHeader("sentry-trace", t),
                                n && e.setRequestHeader("baggage", n);
                            } catch (e) {}
                          })(e, n, r);
                      })(a, (0, tQ.z)() && u ? c : void 0),
                    c
                  );
                })(e, l, u, c);
                o && t && nB(t);
              });
        }
        function nB(e) {
          let { url: t } = (0, q.XU)(e).data || {};
          if (!t || "string" != typeof t) return;
          let n = (0, tZ._j)("resource", ({ entries: r }) => {
            r.forEach((r) => {
              if (
                "resource" === r.entryType &&
                "initiatorType" in r &&
                "string" == typeof r.nextHopProtocol &&
                ("fetch" === r.initiatorType ||
                  "xmlhttprequest" === r.initiatorType) &&
                r.name.endsWith(t)
              ) {
                let t = (function (e) {
                  let { name: t, version: n } = (function (e) {
                      let t = "unknown",
                        n = "unknown",
                        r = "";
                      for (let a of e) {
                        if ("/" === a) {
                          [t, n] = e.split("/");
                          break;
                        }
                        if (!isNaN(Number(a))) {
                          (t = "h" === r ? "http" : r), (n = e.split(r)[1]);
                          break;
                        }
                        r += a;
                      }
                      return r === e && (t = r), { name: t, version: n };
                    })(e.nextHopProtocol),
                    r = [];
                  return (r.push(
                    ["network.protocol.version", n],
                    ["network.protocol.name", t]
                  ),
                  V.Z1)
                    ? [
                        ...r,
                        ["http.request.redirect_start", nW(e.redirectStart)],
                        ["http.request.fetch_start", nW(e.fetchStart)],
                        [
                          "http.request.domain_lookup_start",
                          nW(e.domainLookupStart),
                        ],
                        [
                          "http.request.domain_lookup_end",
                          nW(e.domainLookupEnd),
                        ],
                        ["http.request.connect_start", nW(e.connectStart)],
                        [
                          "http.request.secure_connection_start",
                          nW(e.secureConnectionStart),
                        ],
                        ["http.request.connection_end", nW(e.connectEnd)],
                        ["http.request.request_start", nW(e.requestStart)],
                        ["http.request.response_start", nW(e.responseStart)],
                        ["http.request.response_end", nW(e.responseEnd)],
                      ]
                    : r;
                })(r);
                t.forEach((t) => e.setAttribute(...t)), setTimeout(n);
              }
            });
          });
        }
        function nW(e = 0) {
          return ((V.Z1 || performance.timeOrigin) + e) / 1e3;
        }
        function nG(e) {
          try {
            let t = new URL(e, e_.location.origin);
            return t.href;
          } catch (e) {
            return;
          }
        }
        let nq = {
            ...nN,
            instrumentNavigation: !0,
            instrumentPageLoad: !0,
            markBackgroundSpan: !0,
            enableLongTask: !0,
            enableLongAnimationFrame: !0,
            enableInp: !0,
            _experiments: {},
            ...nH,
          },
          nZ = (e = {}) => {
            nL();
            let {
                enableInp: t,
                enableLongTask: n,
                enableLongAnimationFrame: r,
                _experiments: {
                  enableInteractions: o,
                  enableStandaloneClsSpans: s,
                },
                beforeStartSpan: l,
                idleTimeout: u,
                finalTimeout: c,
                childSpanTimeout: d,
                markBackgroundSpan: p,
                traceFetch: f,
                traceXHR: h,
                trackFetchStreamPerformance: m,
                shouldCreateSpanForRequest: _,
                enableHTTPTimings: y,
                instrumentPageLoad: b,
                instrumentNavigation: E,
              } = { ...nq, ...e },
              S = (function ({ recordClsStandaloneSpans: e }) {
                let t = nv();
                if (t && V.Z1) {
                  t.mark && tG.m.performance.mark("sentry-tracing-init");
                  let n = (0, tZ.to)(({ metric: e }) => {
                      let t = e.entries[e.entries.length - 1];
                      if (!t) return;
                      let n = ny(V.Z1),
                        r = ny(t.startTime);
                      (nx.fid = { value: e.value, unit: "millisecond" }),
                        (nx["mark.fid"] = { value: n + r, unit: "second" });
                    }),
                    r = (0, tZ.$A)(({ metric: e }) => {
                      let t = e.entries[e.entries.length - 1];
                      t &&
                        ((nx.lcp = { value: e.value, unit: "millisecond" }),
                        (a = t));
                    }, !0),
                    o = (0, tZ._4)(({ metric: e }) => {
                      let t = e.entries[e.entries.length - 1];
                      t && (nx.ttfb = { value: e.value, unit: "millisecond" });
                    }),
                    s = e
                      ? (function () {
                          let e,
                            t,
                            n = 0;
                          if (
                            !(function () {
                              try {
                                return PerformanceObserver.supportedEntryTypes.includes(
                                  "layout-shift"
                                );
                              } catch (e) {
                                return !1;
                              }
                            })()
                          )
                            return;
                          let r = !1;
                          function a() {
                            r ||
                              ((r = !0),
                              t &&
                                (function (e, t, n) {
                                  tq.X && v.kg.log(`Sending CLS span (${e})`);
                                  let r = ny(
                                      (V.Z1 || 0) + ((t && t.startTime) || 0)
                                    ),
                                    a = (0, g.nZ)().getScopeData()
                                      .transactionName,
                                    i = t
                                      ? (0, eL.Rt)(
                                          t.sources[0] && t.sources[0].node
                                        )
                                      : "Layout shift",
                                    o = (0, A.Jr)({
                                      [tX.S3]: "auto.http.browser.cls",
                                      [tX.$J]: "ui.webvital.cls",
                                      [tX.JQ]: (t && t.duration) || 0,
                                      "sentry.pageload.span_id": n,
                                    }),
                                    s = ng({
                                      name: i,
                                      transaction: a,
                                      attributes: o,
                                      startTime: r,
                                    });
                                  s &&
                                    (s.addEvent("cls", {
                                      [tX.E1]: "",
                                      [tX.Wb]: e,
                                    }),
                                    s.end(r));
                                })(n, e, t),
                              i());
                          }
                          let i = (0, tZ.PR)(({ metric: t }) => {
                            let r = t.entries[t.entries.length - 1];
                            r && ((n = t.value), (e = r));
                          }, !0);
                          (0, nb.u)(() => {
                            a();
                          }),
                            setTimeout(() => {
                              let e = (0, g.s3)();
                              if (!e) return;
                              let n = e.on("startNavigationSpan", () => {
                                  a(), n && n();
                                }),
                                r = (0, q.HN)(),
                                i = r && (0, q.Gx)(r),
                                o = i && (0, q.XU)(i);
                              o &&
                                "pageload" === o.op &&
                                (t = i.spanContext().spanId);
                            }, 0);
                        })()
                      : (0, tZ.PR)(({ metric: e }) => {
                          let t = e.entries[e.entries.length - 1];
                          t &&
                            ((nx.cls = { value: e.value, unit: "" }), (i = t));
                        }, !0);
                  return () => {
                    n(), r(), o(), s && s();
                  };
                }
                return () => void 0;
              })({ recordClsStandaloneSpans: s || !1 });
            t &&
              (function () {
                let e = nv();
                if (e && V.Z1) {
                  let e = (0, tZ.YF)(({ metric: e }) => {
                    if (void 0 == e.value) return;
                    let t = e.entries.find(
                      (t) => t.duration === e.value && nR[t.name]
                    );
                    if (!t) return;
                    let { interactionId: n } = t,
                      r = nR[t.name],
                      a = ny(V.Z1 + t.startTime),
                      i = ny(e.value),
                      o = (0, q.HN)(),
                      s = o ? (0, q.Gx)(o) : void 0,
                      l = null != n ? nA.get(n) : void 0,
                      u = l || s,
                      c = u
                        ? (0, q.XU)(u).description
                        : (0, g.nZ)().getScopeData().transactionName,
                      d = (0, eL.Rt)(t.target),
                      p = (0, A.Jr)({
                        [tX.S3]: "auto.http.browser.inp",
                        [tX.$J]: `ui.interaction.${r}`,
                        [tX.JQ]: t.duration,
                      }),
                      f = ng({
                        name: d,
                        transaction: c,
                        attributes: p,
                        startTime: a,
                      });
                    f &&
                      (f.addEvent("inp", {
                        [tX.E1]: "millisecond",
                        [tX.Wb]: e.value,
                      }),
                      f.end(a + i));
                  });
                }
              })(),
              r &&
              em.n.PerformanceObserver &&
              PerformanceObserver.supportedEntryTypes &&
              PerformanceObserver.supportedEntryTypes.includes(
                "long-animation-frame"
              )
                ? (function () {
                    let e = new PerformanceObserver((e) => {
                      let t = (0, q.HN)();
                      if (t)
                        for (let n of e.getEntries()) {
                          if (!n.scripts[0]) continue;
                          let e = ny(V.Z1 + n.startTime),
                            { start_timestamp: r, op: a } = (0, q.XU)(t);
                          if ("navigation" === a && r && e < r) continue;
                          let i = ny(n.duration),
                            o = { [tX.S3]: "auto.ui.browser.metrics" },
                            s = n.scripts[0],
                            {
                              invoker: l,
                              invokerType: u,
                              sourceURL: c,
                              sourceFunctionName: d,
                              sourceCharPosition: p,
                            } = s;
                          (o["browser.script.invoker"] = l),
                            (o["browser.script.invoker_type"] = u),
                            c && (o["code.filepath"] = c),
                            d && (o["code.function"] = d),
                            -1 !== p &&
                              (o["browser.script.source_char_position"] = p),
                            n_(t, e, e + i, {
                              name: "Main UI thread blocked",
                              op: "ui.long-animation-frame",
                              attributes: o,
                            });
                        }
                    });
                    e.observe({ type: "long-animation-frame", buffered: !0 });
                  })()
                : n &&
                  (0, tZ._j)("longtask", ({ entries: e }) => {
                    let t = (0, q.HN)();
                    if (!t) return;
                    let { op: n, start_timestamp: r } = (0, q.XU)(t);
                    for (let a of e) {
                      let e = ny(V.Z1 + a.startTime),
                        i = ny(a.duration);
                      ("navigation" === n && r && e < r) ||
                        n_(t, e, e + i, {
                          name: "Main UI thread blocked",
                          op: "ui.long-task",
                          attributes: { [tX.S3]: "auto.ui.browser.metrics" },
                        });
                    }
                  }),
              o &&
                (0, tZ._j)("event", ({ entries: e }) => {
                  let t = (0, q.HN)();
                  if (t) {
                    for (let n of e)
                      if ("click" === n.name) {
                        let e = ny(V.Z1 + n.startTime),
                          r = ny(n.duration),
                          a = {
                            name: (0, eL.Rt)(n.target),
                            op: `ui.interaction.${n.name}`,
                            startTime: e,
                            attributes: { [tX.S3]: "auto.ui.browser.metrics" },
                          },
                          i = (0, eL.iY)(n.target);
                        i && (a.attributes["ui.component_name"] = i),
                          n_(t, e, e + r, a);
                      }
                  }
                });
            let w = { name: void 0, source: void 0 };
            function T(e, t) {
              let n = "pageload" === t.op,
                r = l ? l(t) : t,
                o = r.attributes || {};
              t.name !== r.name && ((o[tX.Zj] = "custom"), (r.attributes = o)),
                (w.name = r.name),
                (w.source = o[tX.Zj]);
              let p = nP(r, {
                idleTimeout: u,
                finalTimeout: c,
                childSpanTimeout: d,
                disableAutoFinish: n,
                beforeSpanEnd: (e) => {
                  S(),
                    (function (e, t) {
                      let n = nv();
                      if (!n || !tG.m.performance.getEntries || !V.Z1) return;
                      let r = ny(V.Z1),
                        o = n.getEntries(),
                        { op: s, start_timestamp: l } = (0, q.XU)(e);
                      if (
                        (o.slice(nT).forEach((t) => {
                          let n = ny(t.startTime),
                            a = ny(Math.max(0, t.duration));
                          if ("navigation" !== s || !l || !(r + n < l))
                            switch (t.entryType) {
                              case "navigation":
                                [
                                  "unloadEvent",
                                  "redirect",
                                  "domContentLoadedEvent",
                                  "loadEvent",
                                  "connect",
                                ].forEach((n) => {
                                  nk(e, t, n, r);
                                }),
                                  nk(
                                    e,
                                    t,
                                    "secureConnection",
                                    r,
                                    "TLS/SSL",
                                    "connectEnd"
                                  ),
                                  nk(
                                    e,
                                    t,
                                    "fetch",
                                    r,
                                    "cache",
                                    "domainLookupStart"
                                  ),
                                  nk(e, t, "domainLookup", r, "DNS"),
                                  (function (e, t, n) {
                                    let r = n + ny(t.requestStart),
                                      a = n + ny(t.responseEnd),
                                      i = n + ny(t.responseStart);
                                    t.responseEnd &&
                                      (n_(e, r, a, {
                                        op: "browser.request",
                                        name: t.name,
                                        attributes: {
                                          [tX.S3]: "auto.ui.browser.metrics",
                                        },
                                      }),
                                      n_(e, i, a, {
                                        op: "browser.response",
                                        name: t.name,
                                        attributes: {
                                          [tX.S3]: "auto.ui.browser.metrics",
                                        },
                                      }));
                                  })(e, t, r);
                                break;
                              case "mark":
                              case "paint":
                              case "measure": {
                                (function (e, t, n, r, a) {
                                  let i = (0, nS.W)(!1),
                                    o = ny(i ? i.requestStart : 0),
                                    s = a + Math.max(n, o),
                                    l = a + n,
                                    u = {
                                      [tX.S3]: "auto.resource.browser.metrics",
                                    };
                                  s !== l &&
                                    ((u[
                                      "sentry.browser.measure_happened_before_request"
                                    ] = !0),
                                    (u["sentry.browser.measure_start_time"] =
                                      s)),
                                    n_(e, s, l + r, {
                                      name: t.name,
                                      op: t.entryType,
                                      attributes: u,
                                    });
                                })(e, t, n, a, r);
                                let i = (0, nw.Y)(),
                                  o = t.startTime < i.firstHiddenTime;
                                "first-paint" === t.name &&
                                  o &&
                                  (nx.fp = {
                                    value: t.startTime,
                                    unit: "millisecond",
                                  }),
                                  "first-contentful-paint" === t.name &&
                                    o &&
                                    (nx.fcp = {
                                      value: t.startTime,
                                      unit: "millisecond",
                                    });
                                break;
                              }
                              case "resource":
                                (function (e, t, n, r, a, i) {
                                  if (
                                    "xmlhttprequest" === t.initiatorType ||
                                    "fetch" === t.initiatorType
                                  )
                                    return;
                                  let o = e$(n),
                                    s = {
                                      [tX.S3]: "auto.resource.browser.metrics",
                                    };
                                  nI(
                                    s,
                                    t,
                                    "transferSize",
                                    "http.response_transfer_size"
                                  ),
                                    nI(
                                      s,
                                      t,
                                      "encodedBodySize",
                                      "http.response_content_length"
                                    ),
                                    nI(
                                      s,
                                      t,
                                      "decodedBodySize",
                                      "http.decoded_response_content_length"
                                    ),
                                    null != t.deliveryType &&
                                      (s["http.response_delivery_type"] =
                                        t.deliveryType),
                                    "renderBlockingStatus" in t &&
                                      (s["resource.render_blocking_status"] =
                                        t.renderBlockingStatus),
                                    o.protocol &&
                                      (s["url.scheme"] = o.protocol
                                        .split(":")
                                        .pop()),
                                    o.host && (s["server.address"] = o.host),
                                    (s["url.same_origin"] = n.includes(
                                      tG.m.location.origin
                                    ));
                                  let l = i + r;
                                  n_(e, l, l + a, {
                                    name: n.replace(tG.m.location.origin, ""),
                                    op: t.initiatorType
                                      ? `resource.${t.initiatorType}`
                                      : "resource.other",
                                    attributes: s,
                                  });
                                })(e, t, t.name, n, a, r);
                            }
                        }),
                        (nT = Math.max(o.length - 1, 0)),
                        (function (e) {
                          let t = tG.m.navigator;
                          if (!t) return;
                          let n = t.connection;
                          n &&
                            (n.effectiveType &&
                              e.setAttribute(
                                "effectiveConnectionType",
                                n.effectiveType
                              ),
                            n.type && e.setAttribute("connectionType", n.type),
                            nm(n.rtt) &&
                              (nx["connection.rtt"] = {
                                value: n.rtt,
                                unit: "millisecond",
                              })),
                            nm(t.deviceMemory) &&
                              e.setAttribute(
                                "deviceMemory",
                                `${t.deviceMemory} GB`
                              ),
                            nm(t.hardwareConcurrency) &&
                              e.setAttribute(
                                "hardwareConcurrency",
                                String(t.hardwareConcurrency)
                              );
                        })(e),
                        "pageload" === s)
                      ) {
                        (function (e) {
                          let t = (0, nS.W)(!1);
                          if (!t) return;
                          let { responseStart: n, requestStart: r } = t;
                          r <= n &&
                            (e["ttfb.requestTime"] = {
                              value: n - r,
                              unit: "millisecond",
                            });
                        })(nx);
                        let n = nx["mark.fid"];
                        n &&
                          nx.fid &&
                          (n_(e, n.value, n.value + ny(nx.fid.value), {
                            name: "first input delay",
                            op: "ui.action",
                            attributes: { [tX.S3]: "auto.ui.browser.metrics" },
                          }),
                          delete nx["mark.fid"]),
                          ("fcp" in nx && t.recordClsOnPageloadSpan) ||
                            delete nx.cls,
                          Object.entries(nx).forEach(([e, t]) => {
                            tB(e, t.value, t.unit);
                          }),
                          e.setAttribute("performance.timeOrigin", r),
                          e.setAttribute(
                            "performance.activationStart",
                            (0, nE.A)()
                          ),
                          a &&
                            (a.element &&
                              e.setAttribute(
                                "lcp.element",
                                (0, eL.Rt)(a.element)
                              ),
                            a.id && e.setAttribute("lcp.id", a.id),
                            a.url &&
                              e.setAttribute(
                                "lcp.url",
                                a.url.trim().slice(0, 200)
                              ),
                            null != a.loadTime &&
                              e.setAttribute("lcp.loadTime", a.loadTime),
                            null != a.renderTime &&
                              e.setAttribute("lcp.renderTime", a.renderTime),
                            e.setAttribute("lcp.size", a.size)),
                          i &&
                            i.sources &&
                            i.sources.forEach((t, n) =>
                              e.setAttribute(
                                `cls.source.${n + 1}`,
                                (0, eL.Rt)(t.node)
                              )
                            );
                      }
                      (a = void 0), (i = void 0), (nx = {});
                    })(e, { recordClsOnPageloadSpan: !s });
                },
              });
              function f() {
                ["interactive", "complete"].includes(e_.document.readyState) &&
                  e.emit("idleSpanEnableAutoFinish", p);
              }
              return (
                n &&
                  e_.document &&
                  (e_.document.addEventListener("readystatechange", () => {
                    f();
                  }),
                  f()),
                p
              );
            }
            return {
              name: "BrowserTracing",
              afterAllSetup(e) {
                let n;
                let r = e_.location && e_.location.href;
                function a() {
                  n && !(0, q.XU)(n).timestamp && n.end();
                }
                e.on("startNavigationSpan", (t) => {
                  (0, g.s3)() === e &&
                    (a(), (n = T(e, { op: "navigation", ...t })));
                }),
                  e.on("startPageLoadSpan", (t, r = {}) => {
                    if ((0, g.s3)() !== e) return;
                    a();
                    let i = r.sentryTrace || nz("sentry-trace"),
                      o = r.baggage || nz("baggage"),
                      s = (0, tJ.pT)(i, o);
                    (0, g.nZ)().setPropagationContext(s),
                      (n = T(e, { op: "pageload", ...t }));
                  }),
                  e.on("spanEnd", (e) => {
                    let t = (0, q.XU)(e).op;
                    if (
                      e !== (0, q.Gx)(e) ||
                      ("navigation" !== t && "pageload" !== t)
                    )
                      return;
                    let n = (0, g.nZ)(),
                      r = n.getPropagationContext();
                    n.setPropagationContext({
                      ...r,
                      sampled: void 0 !== r.sampled ? r.sampled : (0, q.Tt)(e),
                      dsc: r.dsc || (0, W.jC)(e),
                    });
                  }),
                  e_.location &&
                    (b &&
                      nV(e, {
                        name: e_.location.pathname,
                        startTime: V.Z1 ? V.Z1 / 1e3 : void 0,
                        attributes: {
                          [tX.Zj]: "url",
                          [tX.S3]: "auto.pageload.browser",
                        },
                      }),
                    E &&
                      (0, ew.a)(({ to: t, from: n }) => {
                        if (void 0 === n && r && -1 !== r.indexOf(t)) {
                          r = void 0;
                          return;
                        }
                        n !== t &&
                          ((r = void 0),
                          nY(e, {
                            name: e_.location.pathname,
                            attributes: {
                              [tX.Zj]: "url",
                              [tX.S3]: "auto.navigation.browser",
                            },
                          }));
                      })),
                  p &&
                    e_ &&
                    e_.document &&
                    e_.document.addEventListener("visibilitychange", () => {
                      let e = (0, q.HN)();
                      if (!e) return;
                      let t = (0, q.Gx)(e);
                      if (e_.document.hidden && t) {
                        let { op: e, status: n } = (0, q.XU)(t);
                        n || t.setStatus({ code: ne.jt, message: "cancelled" }),
                          t.setAttribute(
                            "sentry.cancellation_reason",
                            "document.hidden"
                          ),
                          t.end();
                      }
                    }),
                  o &&
                    (function (e, t, n, r) {
                      let a;
                      let i = () => {
                        let i = (0, q.HN)(),
                          o = i && (0, q.Gx)(i);
                        if (o) {
                          let e = (0, q.XU)(o).op;
                          if (["navigation", "pageload"].includes(e)) return;
                        }
                        a &&
                          (a.setAttribute(tX.ju, "interactionInterrupted"),
                          a.end(),
                          (a = void 0)),
                          r.name &&
                            (a = nP(
                              {
                                name: r.name,
                                op: "ui.action.click",
                                attributes: { [tX.Zj]: r.source || "url" },
                              },
                              {
                                idleTimeout: e,
                                finalTimeout: t,
                                childSpanTimeout: n,
                              }
                            ));
                      };
                      e_.document &&
                        addEventListener("click", i, { once: !1, capture: !0 });
                    })(u, c, d, w),
                  t &&
                    (function () {
                      let e = ({ entries: e }) => {
                        let t = (0, q.HN)(),
                          n = t && (0, q.Gx)(t);
                        e.forEach((e) => {
                          if (!(0, tZ.cN)(e) || !n) return;
                          let t = e.interactionId;
                          if (!(null == t || nA.has(t))) {
                            if (nC.length > 10) {
                              let e = nC.shift();
                              nA.delete(e);
                            }
                            nC.push(t), nA.set(t, n);
                          }
                        });
                      };
                      (0, tZ._j)("event", e), (0, tZ._j)("first-input", e);
                    })(),
                  nX(e, {
                    traceFetch: f,
                    traceXHR: h,
                    trackFetchStreamPerformance: m,
                    tracePropagationTargets:
                      e.getOptions().tracePropagationTargets,
                    shouldCreateSpanForRequest: _,
                    enableHTTPTimings: y,
                  });
              },
            };
          };
        function nV(e, t, n) {
          e.emit("startPageLoadSpan", t, n),
            (0, g.nZ)().setTransactionName(t.name);
          let r = (0, q.HN)(),
            a = r && (0, q.XU)(r).op;
          return "pageload" === a ? r : void 0;
        }
        function nY(e, t) {
          (0, g.aF)().setPropagationContext({ traceId: (0, tz.Ht)() }),
            (0, g.nZ)().setPropagationContext({ traceId: (0, tz.Ht)() }),
            e.emit("startNavigationSpan", t),
            (0, g.nZ)().setTransactionName(t.name);
          let n = (0, q.HN)(),
            r = n && (0, q.XU)(n).op;
          return "navigation" === r ? n : void 0;
        }
        function nz(e) {
          let t = (0, eL.qT)(`meta[name=${e}]`);
          return t ? t.getAttribute("content") : void 0;
        }
        let nJ = "incomplete-app-router-transaction",
          nK = em.n;
        function nQ(e) {
          try {
            return new URL(e, "http://some-random-base.com/").pathname;
          } catch (e) {
            return "/";
          }
        }
        var n0 = n(36096),
          n1 = n(83454);
        let n3 = em.n;
        function n2(e) {
          let t = {
            environment:
              (function (e) {
                let t = e ? tM.env.NEXT_PUBLIC_VERCEL_ENV : tM.env.VERCEL_ENV;
                return t ? `vercel-${t}` : void 0;
              })(!0) || "production",
            defaultIntegrations: (function (e) {
              let t = tI(e);
              return t.push(tj({ assetPrefixPath: "/portal" })), t;
            })(e),
            ...e,
          };
          (function (e) {
            let t =
              n1.env._sentryRewritesTunnelPath || n3._sentryRewritesTunnelPath;
            if (t && e.dsn) {
              let n = (0, H.U4)(e.dsn);
              if (!n) return;
              let r = n.host.match(
                /^o(\d+)\.ingest(?:\.([a-z]{2}))?\.sentry\.io$/
              );
              if (r) {
                let a = r[1],
                  i = r[2],
                  o = `${t}?o=${a}&p=${n.projectId}`;
                i && (o += `&r=${i}`),
                  (e.tunnel = o),
                  n0.X && v.kg.info(`Tunneling events to "${o}"`);
              } else
                n0.X &&
                  v.kg.warn(
                    "Provided DSN is not a Sentry SaaS DSN. Will not tunnel events."
                  );
            }
          })(t),
            h(t, "nextjs", ["nextjs", "react"]);
          let n = (function (e) {
              let t = { ...e };
              return (
                h(t, "react"),
                (0, m.v)("react", { version: tP.version }),
                (function (e = {}) {
                  let t = (function (e = {}) {
                    let t = {
                      defaultIntegrations: tI(e),
                      release:
                        "string" == typeof __SENTRY_RELEASE__
                          ? __SENTRY_RELEASE__
                          : e_.SENTRY_RELEASE && e_.SENTRY_RELEASE.id
                          ? e_.SENTRY_RELEASE.id
                          : void 0,
                      autoSessionTracking: !0,
                      sendClientReports: !0,
                    };
                    return (
                      null == e.defaultIntegrations &&
                        delete e.defaultIntegrations,
                      { ...t, ...e }
                    );
                  })(e);
                  if (
                    !t.skipBrowserExtensionCheck &&
                    (function () {
                      let e = void 0 !== e_.window && e_;
                      if (!e) return !1;
                      let t = e.chrome ? "chrome" : "browser",
                        n = e[t],
                        r = n && n.runtime && n.runtime.id,
                        a = (e_.location && e_.location.href) || "",
                        i =
                          !!r &&
                          e_ === e_.top &&
                          [
                            "chrome-extension:",
                            "moz-extension:",
                            "ms-browser-extension:",
                            "safari-web-extension:",
                          ].some((e) => a.startsWith(`${e}//`)),
                        o = void 0 !== e.nw;
                      return !!r && !i && !o;
                    })()
                  ) {
                    (0, v.Cf)(() => {
                      console.error(
                        "[Sentry] You cannot run Sentry this way in a browser extension, check: https://docs.sentry.io/platforms/javascript/best-practices/browser-extensions/"
                      );
                    });
                    return;
                  }
                  let n = {
                    ...t,
                    stackParser: (0, M.Sq)(t.stackParser || tb),
                    integrations: (function (e) {
                      let t;
                      let n = e.defaultIntegrations || [],
                        r = e.integrations;
                      if (
                        (n.forEach((e) => {
                          e.isDefaultInstance = !0;
                        }),
                        Array.isArray(r))
                      )
                        t = [...n, ...r];
                      else if ("function" == typeof r) {
                        let e = r(n);
                        t = Array.isArray(e) ? e : [e];
                      } else t = n;
                      let a = (function (e) {
                          let t = {};
                          return (
                            e.forEach((e) => {
                              let { name: n } = e,
                                r = t[n];
                              (r &&
                                !r.isDefaultInstance &&
                                e.isDefaultInstance) ||
                                (t[n] = e);
                            }),
                            Object.values(t)
                          );
                        })(t),
                        i = a.findIndex((e) => "Debug" === e.name);
                      if (i > -1) {
                        let [e] = a.splice(i, 1);
                        a.push(e);
                      }
                      return a;
                    })(t),
                    transport: t.transport || tk,
                  };
                  return (function (e, t) {
                    !0 === t.debug &&
                      (_.X
                        ? v.kg.enable()
                        : (0, v.Cf)(() => {
                            console.warn(
                              "[Sentry] Cannot initialize SDK with `debug` option using a non-debug bundle."
                            );
                          }));
                    let n = (0, g.nZ)();
                    n.update(t.initialScope);
                    let r = new e(t);
                    return j(r), r.init(), r;
                  })(eb, n);
                })(t)
              );
            })(t),
            r = (e) =>
              "transaction" === e.type && "/404" === e.transaction ? null : e;
          (r.id = "NextClient404Filter"), (0, m.Qy)(r);
          let a = (e) =>
            "transaction" === e.type && e.transaction === nJ ? null : e;
          (a.id = "IncompleteTransactionFilter"), (0, m.Qy)(a);
          let i = (e, t) =>
            tD((0, p.x)([t, "optionalAccess", (e) => e.originalException]))
              ? null
              : e;
          return (i.id = "NextRedirectErrorFilter"), (0, m.Qy)(i), n;
        }
        function n4(e) {
          return e;
        }
        var n5 = n(76828),
          n6 = n(11163);
        let n9 = n6.events ? n6 : n6.default;
        function n7(e = {}) {
          let t = nZ({
              ...e,
              instrumentNavigation: !1,
              instrumentPageLoad: !1,
            }),
            { instrumentPageLoad: n = !0, instrumentNavigation: r = !0 } = e;
          return {
            ...t,
            afterAllSetup(e) {
              r &&
                (function (e) {
                  let t = !e_.document.getElementById("__NEXT_DATA__");
                  t
                    ? !(function (e) {
                        let t;
                        e_.addEventListener("popstate", () => {
                          t && t.isRecording()
                            ? (t.updateName(e_.location.pathname),
                              t.setAttribute(tX.Zj, "url"))
                            : (t = nY(e, {
                                name: e_.location.pathname,
                                attributes: {
                                  [tX.$J]: "navigation",
                                  [tX.S3]:
                                    "auto.navigation.nextjs.app_router_instrumentation",
                                  [tX.Zj]: "url",
                                  "navigation.type": "browser.popstate",
                                },
                              }));
                        });
                        let n = !1,
                          r = 0,
                          a = setInterval(() => {
                            r++;
                            let i = (0, tH.h)(
                              (0, p.x)([
                                nK,
                                "optionalAccess",
                                (e) => e.next,
                                "optionalAccess",
                                (e) => e.router,
                              ]),
                              () =>
                                (0, p.x)([
                                  nK,
                                  "optionalAccess",
                                  (e) => e.nd,
                                  "optionalAccess",
                                  (e) => e.router,
                                ])
                            );
                            n || r > 500
                              ? clearInterval(a)
                              : i &&
                                (clearInterval(a),
                                (n = !0),
                                ["back", "forward", "push", "replace"].forEach(
                                  (n) => {
                                    (0, p.x)([
                                      i,
                                      "optionalAccess",
                                      (e) => e[n],
                                    ]) &&
                                      (i[n] = new Proxy(i[n], {
                                        apply(r, a, i) {
                                          let o = nY(e, {
                                            name: nJ,
                                            attributes: {
                                              [tX.$J]: "navigation",
                                              [tX.S3]:
                                                "auto.navigation.nextjs.app_router_instrumentation",
                                              [tX.Zj]: "url",
                                            },
                                          });
                                          return (
                                            (t = o),
                                            "push" === n
                                              ? ((0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.updateName,
                                                  "call",
                                                  (e) => e(nQ(i[0])),
                                                ]),
                                                (0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.setAttribute,
                                                  "call",
                                                  (e) => e(tX.Zj, "url"),
                                                ]),
                                                (0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.setAttribute,
                                                  "call",
                                                  (e) =>
                                                    e(
                                                      "navigation.type",
                                                      "router.push"
                                                    ),
                                                ]))
                                              : "replace" === n
                                              ? ((0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.updateName,
                                                  "call",
                                                  (e) => e(nQ(i[0])),
                                                ]),
                                                (0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.setAttribute,
                                                  "call",
                                                  (e) => e(tX.Zj, "url"),
                                                ]),
                                                (0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.setAttribute,
                                                  "call",
                                                  (e) =>
                                                    e(
                                                      "navigation.type",
                                                      "router.replace"
                                                    ),
                                                ]))
                                              : "back" === n
                                              ? (0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.setAttribute,
                                                  "call",
                                                  (e) =>
                                                    e(
                                                      "navigation.type",
                                                      "router.back"
                                                    ),
                                                ])
                                              : "forward" === n &&
                                                (0, p.x)([
                                                  o,
                                                  "optionalAccess",
                                                  (e) => e.setAttribute,
                                                  "call",
                                                  (e) =>
                                                    e(
                                                      "navigation.type",
                                                      "router.forward"
                                                    ),
                                                ]),
                                            r.apply(a, i)
                                          );
                                        },
                                      }));
                                  }
                                ));
                          }, 20);
                      })(e)
                    : n9.events.on("routeChangeStart", (t) => {
                        let n, r;
                        let a = eF(t),
                          i = (function (e) {
                            let t = (e_.__BUILD_MANIFEST || {}).sortedPages;
                            if (t)
                              return t.find((t) => {
                                let n = (function (e) {
                                  let t = e.split("/"),
                                    n = "";
                                  (0, p.x)([
                                    t,
                                    "access",
                                    (e) => e[t.length - 1],
                                    "optionalAccess",
                                    (e) => e.match,
                                    "call",
                                    (e) => e(/^\[\[\.\.\..+\]\]$/),
                                  ]) && (t.pop(), (n = "(?:/(.+?))?"));
                                  let r = t
                                    .map((e) =>
                                      e
                                        .replace(/^\[\.\.\..+\]$/, "(.+?)")
                                        .replace(/^\[.*\]$/, "([^/]+?)")
                                    )
                                    .join("/");
                                  return RegExp(`^${r}${n}(?:/)?$`);
                                })(t);
                                return e.match(n);
                              });
                          })(a);
                        i ? ((n = i), (r = "route")) : ((n = a), (r = "url")),
                          nY(e, {
                            name: n,
                            attributes: {
                              [tX.$J]: "navigation",
                              [tX.S3]:
                                "auto.navigation.nextjs.pages_router_instrumentation",
                              [tX.Zj]: r,
                            },
                          });
                      });
                })(e),
                t.afterAllSetup(e),
                n &&
                  (function (e) {
                    let t = !e_.document.getElementById("__NEXT_DATA__");
                    t
                      ? nV(e, {
                          name: e_.location.pathname,
                          startTime: V.Z1 ? V.Z1 / 1e3 : void 0,
                          attributes: {
                            [tX.$J]: "pageload",
                            [tX.S3]:
                              "auto.pageload.nextjs.app_router_instrumentation",
                            [tX.Zj]: "url",
                          },
                        })
                      : (function (e) {
                          let {
                              route: t,
                              params: n,
                              sentryTrace: r,
                              baggage: a,
                            } = (function () {
                              let e;
                              let t =
                                e_.document.getElementById("__NEXT_DATA__");
                              if (t && t.innerHTML)
                                try {
                                  e = JSON.parse(t.innerHTML);
                                } catch (e) {
                                  n0.X &&
                                    v.kg.warn(
                                      "Could not extract __NEXT_DATA__"
                                    );
                                }
                              if (!e) return {};
                              let n = {},
                                { page: r, query: a, props: i } = e;
                              return (
                                (n.route = r),
                                (n.params = a),
                                i &&
                                  i.pageProps &&
                                  ((n.sentryTrace =
                                    i.pageProps._sentryTraceData),
                                  (n.baggage = i.pageProps._sentryBaggage)),
                                n
                              );
                            })(),
                            i = (0, nO.XM)(a),
                            o = t || e_.location.pathname;
                          i &&
                            i["sentry-transaction"] &&
                            "/_error" === o &&
                            (o = (o = i["sentry-transaction"]).replace(
                              /^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|TRACE|CONNECT)\s+/i,
                              ""
                            )),
                            nV(
                              e,
                              {
                                name: o,
                                startTime: V.Z1 ? V.Z1 / 1e3 : void 0,
                                attributes: {
                                  [tX.$J]: "pageload",
                                  [tX.S3]:
                                    "auto.pageload.nextjs.pages_router_instrumentation",
                                  [tX.Zj]: t ? "route" : "url",
                                  ...(n &&
                                    e.getOptions().sendDefaultPii && { ...n }),
                                },
                              },
                              { sentryTrace: r, baggage: a }
                            );
                        })(e);
                  })(e);
            },
          };
        }
        var n8 = n(31365),
          re = n(83454);
        function rt() {
          return re.env.NEXT_PHASE === n8.PHASE_PRODUCTION_BUILD;
        }
        var rn = n(10454);
        let rr = "sentry.sentry_trace_backfill";
        function ra(e) {
          return async function (...t) {
            try {
              return await e.apply(this, t);
            } catch (e) {
              throw ((0, m.Tb)(e, { mechanism: { handled: !1 } }), e);
            }
          };
        }
        function ri(e, t, n, r) {
          return async function (...n) {
            let a = (0, rn.G)(t);
            (0, g.nZ)().setTransactionName(
              `${r.dataFetchingMethodName} (${r.dataFetcherRouteName})`
            ),
              (0, g.aF)().setSDKProcessingMetadata({ normalizedRequest: a });
            let i = (0, q.HN)();
            if (i && "/_error" !== r.requestedRouteName) {
              let e = (0, q.Gx)(i);
              e.setAttribute("sentry.route_backfill", r.requestedRouteName);
            }
            let { "sentry-trace": o, baggage: s } = n$();
            return { sentryTrace: o, baggage: s, data: await e.apply(this, n) };
          };
        }
        async function ro(e, t) {
          try {
            return await e(...t);
          } catch (e) {
            throw ((0, m.Tb)(e, { mechanism: { handled: !1 } }), e);
          }
        }
        function rs(e, t) {
          return new Proxy(e, {
            apply: async (e, t, n) => {
              if (rt()) return e.apply(t, n);
              let r = ra(e);
              return ro(r, n);
            },
          });
        }
        async function rl(e, t) {
          return (0, tH.h)(e, t);
        }
        function ru(e) {
          return new Proxy(e, {
            apply: async (e, t, n) => {
              if (rt()) return e.apply(t, n);
              let [r] = n,
                { req: a, res: i } = r,
                o = ra(e);
              if (!a || !i) return o.apply(t, n);
              {
                let e = ri(o, a, i, {
                    dataFetcherRouteName: r.pathname,
                    requestedRouteName: r.pathname,
                    dataFetchingMethodName: "getInitialProps",
                  }),
                  {
                    data: s,
                    baggage: l,
                    sentryTrace: u,
                  } = await rl(await e.apply(t, n), async () => ({}));
                return (
                  "object" == typeof s &&
                    null !== s &&
                    (u && (s._sentryTraceData = u),
                    l && (s._sentryBaggage = l)),
                  s
                );
              }
            },
          });
        }
        function rc(e) {
          return new Proxy(e, {
            apply: async (e, t, n) => {
              if (rt()) return e.apply(t, n);
              let [r] = n,
                { req: a, res: i } = r.ctx,
                o = ra(e);
              if (!a || !i) return o.apply(t, n);
              {
                let e = ri(o, a, i, {
                    dataFetcherRouteName: "/_app",
                    requestedRouteName: r.ctx.pathname,
                    dataFetchingMethodName: "getInitialProps",
                  }),
                  { data: s, sentryTrace: l, baggage: u } = await e.apply(t, n);
                return (
                  "object" == typeof s &&
                    null !== s &&
                    (s.pageProps || (s.pageProps = {}),
                    l && (s.pageProps._sentryTraceData = l),
                    u && (s.pageProps._sentryBaggage = u)),
                  s
                );
              }
            },
          });
        }
        function rd(e) {
          return new Proxy(e, {
            apply: async (e, t, n) => {
              if (rt()) return e.apply(t, n);
              let [r] = n,
                { req: a, res: i } = r,
                o = ra(e);
              if (!a || !i) return o.apply(t, n);
              {
                let e = ri(o, a, i, {
                    dataFetcherRouteName: "/_document",
                    requestedRouteName: r.pathname,
                    dataFetchingMethodName: "getInitialProps",
                  }),
                  { data: s } = await e.apply(t, n);
                return s;
              }
            },
          });
        }
        function rp(e) {
          return new Proxy(e, {
            apply: async (e, t, n) => {
              if (rt()) return e.apply(t, n);
              let [r] = n,
                { req: a, res: i } = r,
                o = ra(e);
              if (!a || !i) return o.apply(t, n);
              {
                let e = ri(o, a, i, {
                    dataFetcherRouteName: "/_error",
                    requestedRouteName: r.pathname,
                    dataFetchingMethodName: "getInitialProps",
                  }),
                  { data: s, baggage: l, sentryTrace: u } = await e.apply(t, n);
                return (
                  "object" == typeof s &&
                    null !== s &&
                    (u && (s._sentryTraceData = u),
                    l && (s._sentryBaggage = l)),
                  s
                );
              }
            },
          });
        }
        function rf(e, t) {
          return new Proxy(e, {
            apply: async (e, n, r) => {
              if (rt()) return e.apply(n, r);
              let [a] = r,
                { req: i, res: o } = a,
                s = ra(e),
                l = ri(s, i, o, {
                  dataFetcherRouteName: t,
                  requestedRouteName: t,
                  dataFetchingMethodName: "getServerSideProps",
                }),
                { data: u, baggage: c, sentryTrace: d } = await l.apply(n, r);
              return (
                "object" == typeof u &&
                  null !== u &&
                  "props" in u &&
                  (d && (u.props._sentryTraceData = d),
                  c && (u.props._sentryBaggage = c)),
                u
              );
            },
          });
        }
        var rh = n(43927),
          rm = n(93176),
          r_ = n(87881);
        let rg = new WeakMap(),
          rv = new WeakMap();
        function ry(e) {
          if ("object" != typeof e || !e) return new rh.s();
          {
            let t = rv.get(e);
            if (t) return t;
            {
              let t = new rh.s();
              return rv.set(e, t), t;
            }
          }
        }
        function rb(e, t) {
          let { componentRoute: n, componentType: r } = t;
          return new Proxy(e, {
            apply: (e, a, i) => {
              (0, p.x)([
                q.HN,
                "call",
                (e) => e(),
                "optionalAccess",
                (e) => e.spanContext,
                "call",
                (e) => e(),
                "access",
                (e) => e.traceId,
              ]);
              let o = ry(t.headers),
                s = (0, q.HN)();
              if (s) {
                let e = (0, q.Gx)(s),
                  { scope: t } = t6(e);
                t5(
                  e,
                  (0, tH.h)(t, () => new rh.s()),
                  o
                );
              }
              let l = t.headers ? (0, rn.Zm)(t.headers) : void 0;
              return (
                o.setSDKProcessingMetadata({
                  normalizedRequest: { headers: l },
                }),
                (0, g.wi)(o, () =>
                  (0, g.$e)((t) => {
                    t.setTransactionName(`${r} Server Component (${n})`);
                    let o = (0, q.HN)();
                    if (o) {
                      let e = (0, q.Gx)(o),
                        t = (0, p.x)([
                          l,
                          "optionalAccess",
                          (e) => e["sentry-trace"],
                        ]);
                      t && e.setAttribute(rr, t);
                    }
                    return nr(
                      {
                        op: "function.nextjs",
                        name: `${r} Server Component (${n})`,
                        attributes: {
                          [tX.Zj]: "component",
                          [tX.S3]: "auto.function.nextjs",
                        },
                      },
                      (t) =>
                        tK(
                          () => e.apply(a, i),
                          (e) => {
                            tL(e)
                              ? t.setStatus({
                                  code: ne.jt,
                                  message: "not_found",
                                })
                              : tD(e)
                              ? t.setStatus({ code: ne.OP })
                              : (t.setStatus({
                                  code: ne.jt,
                                  message: "internal_error",
                                }),
                                (0, m.Tb)(e, { mechanism: { handled: !1 } }));
                          },
                          () => {
                            t.end(), (0, rm.q)((0, r_.R)());
                          }
                        )
                    );
                  })
                )
              );
            },
          });
        }
        function rE(e, t) {
          let { method: n, parameterizedRoute: r, headers: a } = t;
          return new Proxy(e, {
            apply: async (e, t, a) => {
              let i = (0, q.HN)(),
                o = i ? (0, q.Gx)(i) : void 0;
              return (0, g.wi)((0, g.aF)(), () =>
                (0, g.$e)(async (s) => {
                  s.setTransactionName(`${n} ${r}`);
                  let l = await tK(
                    () => e.apply(t, a),
                    (e) => {
                      tD(e) ||
                        (tL(e)
                          ? (i && (0, ne.Q0)(i, 404), o && (0, ne.Q0)(o, 404))
                          : (0, m.Tb)(e, { mechanism: { handled: !1 } }));
                    }
                  );
                  try {
                    l.status &&
                      (i && (0, ne.Q0)(i, l.status),
                      o && (0, ne.Q0)(o, l.status));
                  } catch (e) {}
                  return l;
                })
              );
            },
          });
        }
        function rS(e, t) {
          return new Proxy(e, {
            apply: (e, n, r) => {
              let a;
              if (!r || !r[0]) return e.apply(n, r);
              let [i] = r,
                o = "nextUrl" in i ? i.nextUrl.pathname : i.url,
                s =
                  "nextUrl" in i
                    ? i.headers.get("user-agent")
                    : i.headers["user-agent"];
              if (
                !t ||
                !(0, p.x)([
                  s,
                  "optionalAccess",
                  (e) => e.includes,
                  "call",
                  (e) => e("vercel-cron"),
                ])
              )
                return e.apply(n, r);
              let l = t.find((e) => e.path === o);
              if (!l || !l.path || !l.schedule) return e.apply(n, r);
              let u = l.path,
                c = (0, m.c)(
                  { monitorSlug: u, status: "in_progress" },
                  {
                    maxRuntime: 720,
                    schedule: { type: "crontab", value: l.schedule },
                  }
                ),
                d = Date.now() / 1e3,
                f = () => {
                  (0, m.c)({
                    checkInId: c,
                    monitorSlug: u,
                    status: "error",
                    duration: Date.now() / 1e3 - d,
                  });
                };
              try {
                a = e.apply(n, r);
              } catch (e) {
                throw (f(), e);
              }
              return "object" == typeof a && null !== a && "then" in a
                ? (Promise.resolve(a).then(
                    () => {
                      (0, m.c)({
                        checkInId: c,
                        monitorSlug: u,
                        status: "ok",
                        duration: Date.now() / 1e3 - d,
                      });
                    },
                    () => {
                      f();
                    }
                  ),
                  a)
                : ((0, m.c)({
                    checkInId: c,
                    monitorSlug: u,
                    status: "ok",
                    duration: Date.now() / 1e3 - d,
                  }),
                  a);
            },
          });
        }
        function rw(e) {
          return new Proxy(e, {
            apply: async (e, t, n) =>
              (0, g.wi)((r) => {
                let a, i;
                let o = n[0],
                  s = (0, g.nZ)();
                o instanceof Request
                  ? (r.setSDKProcessingMetadata({
                      normalizedRequest: (0, rn.se)(o),
                    }),
                    (a = `middleware ${o.method} ${new URL(o.url).pathname}`),
                    (i = "url"))
                  : ((a = "middleware"), (i = "component")),
                  s.setTransactionName(a);
                let l = (0, q.HN)();
                if (l) {
                  (a = "middleware"), (i = "component");
                  let e = (0, q.Gx)(l);
                  e && t5(e, s, r);
                }
                return nn(
                  {
                    name: a,
                    op: "http.server.middleware",
                    attributes: {
                      [tX.Zj]: i,
                      [tX.S3]: "auto.function.nextjs.wrapMiddlewareWithSentry",
                    },
                  },
                  () =>
                    tK(
                      () => e.apply(t, n),
                      (e) => {
                        (0, m.Tb)(e, {
                          mechanism: { type: "instrument", handled: !1 },
                        });
                      },
                      () => {
                        (0, rm.q)((0, r_.R)());
                      }
                    )
                );
              }),
          });
        }
        function rT(e) {
          return "function" == typeof e &&
            (0, p.x)([
              e,
              "optionalAccess",
              (e) => e.prototype,
              "optionalAccess",
              (e) => e.isReactComponent,
            ])
            ? class extends e {
                render(...e) {
                  return (0, g.wi)(() => {
                    let t = (0, g.nZ)(),
                      n =
                        "object" == typeof this.props &&
                        null !== this.props &&
                        "_sentryTraceData" in this.props &&
                        "string" == typeof this.props._sentryTraceData
                          ? this.props._sentryTraceData
                          : void 0;
                    if (n) {
                      let e = (0, tJ.qG)(n);
                      t.setContext("trace", {
                        span_id: (0, p.x)([
                          e,
                          "optionalAccess",
                          (e) => e.parentSpanId,
                        ]),
                        trace_id: (0, p.x)([
                          e,
                          "optionalAccess",
                          (e) => e.traceId,
                        ]),
                      });
                    }
                    try {
                      return super.render(...e);
                    } catch (e) {
                      throw ((0, m.Tb)(e, { mechanism: { handled: !1 } }), e);
                    }
                  });
                }
              }
            : "function" == typeof e
            ? new Proxy(e, {
                apply: (e, t, n) =>
                  (0, g.wi)(() => {
                    let r = (0, g.nZ)(),
                      a = (0, p.x)([
                        n,
                        "optionalAccess",
                        (e) => e[0],
                        "optionalAccess",
                        (e) => e._sentryTraceData,
                      ]);
                    if (a) {
                      let e = (0, tJ.qG)(a);
                      r.setContext("trace", {
                        span_id: (0, p.x)([
                          e,
                          "optionalAccess",
                          (e) => e.parentSpanId,
                        ]),
                        trace_id: (0, p.x)([
                          e,
                          "optionalAccess",
                          (e) => e.traceId,
                        ]),
                      });
                    }
                    try {
                      return e.apply(t, n);
                    } catch (e) {
                      throw ((0, m.Tb)(e, { mechanism: { handled: !1 } }), e);
                    }
                  }),
              })
            : e;
        }
        function rx(e, t) {
          let {
            requestAsyncStorage: n,
            componentRoute: r,
            componentType: a,
            generationFunctionIdentifier: i,
          } = t;
          return new Proxy(e, {
            apply: (e, t, o) => {
              let s, l;
              let u = (0, p.x)([
                q.HN,
                "call",
                (e) => e(),
                "optionalAccess",
                (e) => e.spanContext,
                "call",
                (e) => e(),
                "access",
                (e) => e.traceId,
              ]);
              try {
                s = (0, p.x)([
                  n,
                  "optionalAccess",
                  (e) => e.getStore,
                  "call",
                  (e) => e(),
                  "optionalAccess",
                  (e) => e.headers,
                ]);
              } catch (e) {}
              let c = ry(s),
                d = (0, q.HN)();
              if (d) {
                let e = (0, q.Gx)(d),
                  { scope: t } = t6(e);
                t5(
                  e,
                  (0, tH.h)(t, () => new rh.s()),
                  c
                );
              }
              if (
                (0, p.x)([
                  g.s3,
                  "call",
                  (e) => e(),
                  "optionalAccess",
                  (e) => e.getOptions,
                  "call",
                  (e) => e(),
                  "access",
                  (e) => e.sendDefaultPii,
                ])
              ) {
                let e = o[0],
                  t =
                    e && "object" == typeof e && "params" in e
                      ? e.params
                      : void 0,
                  n =
                    e && "object" == typeof e && "searchParams" in e
                      ? e.searchParams
                      : void 0;
                l = { params: t, searchParams: n };
              }
              let f = s ? (0, rn.Zm)(s) : void 0;
              return (0, g.wi)(c, () =>
                (0, g.$e)((n) => {
                  n.setTransactionName(`${a}.${i} (${r})`),
                    c.setSDKProcessingMetadata({
                      normalizedRequest: { headers: f },
                    });
                  let d = (0, q.HN)();
                  if (d) {
                    let e = (0, q.Gx)(d),
                      t = (0, p.x)([
                        f,
                        "optionalAccess",
                        (e) => e["sentry-trace"],
                      ]);
                    t && e.setAttribute(rr, t);
                  }
                  let h = (function (e, t) {
                    if ("object" != typeof e || !e) return t;
                    {
                      let n = rg.get(e);
                      return n || (rg.set(e, t), t);
                    }
                  })(
                    s,
                    (0, p.x)([f, "optionalAccess", (e) => e["sentry-trace"]])
                      ? (0, tJ.pT)(f["sentry-trace"], f.baggage)
                      : { traceId: u || (0, tz.Ht)(), spanId: (0, tz.M)() }
                  );
                  return (
                    n.setPropagationContext(h),
                    n.setExtra("route_data", l),
                    nr(
                      {
                        op: "function.nextjs",
                        name: `${a}.${i} (${r})`,
                        attributes: {
                          [tX.Zj]: "route",
                          [tX.S3]: "auto.function.nextjs",
                        },
                      },
                      (n) =>
                        tK(
                          () => e.apply(t, o),
                          (e) => {
                            tL(e)
                              ? (n.setStatus({
                                  code: ne.jt,
                                  message: "not_found",
                                }),
                                (0, q.Gx)(n).setStatus({
                                  code: ne.jt,
                                  message: "not_found",
                                }))
                              : tD(e)
                              ? n.setStatus({ code: ne.OP })
                              : (n.setStatus({
                                  code: ne.jt,
                                  message: "internal_error",
                                }),
                                (0, q.Gx)(n).setStatus({
                                  code: ne.jt,
                                  message: "internal_error",
                                }),
                                (0, m.Tb)(e, { mechanism: { handled: !1 } }));
                          },
                          () => {
                            n.end();
                          }
                        )
                    )
                  );
                })
              );
            },
          });
        }
        function rk(...e) {
          if ("function" == typeof e[1]) {
            let [t, n] = e;
            return rI(t, {}, n);
          }
          {
            let [t, n, r] = e;
            return rI(t, n, r);
          }
        }
        async function rI(e, t, n) {
          return (0, g.wi)(async (r) => {
            let a, i;
            let o = (0, p.x)([
                g.s3,
                "call",
                (e) => e(),
                "optionalAccess",
                (e) => e.getOptions,
                "call",
                (e) => e(),
                "access",
                (e) => e.sendDefaultPii,
              ]),
              s = {};
            try {
              let e = await t.headers;
              (a = (0, tH.h)(
                (0, p.x)([
                  e,
                  "optionalAccess",
                  (e) => e.get,
                  "call",
                  (e) => e("sentry-trace"),
                ]),
                () => void 0
              )),
                (i = (0, p.x)([
                  e,
                  "optionalAccess",
                  (e) => e.get,
                  "call",
                  (e) => e("baggage"),
                ])),
                (0, p.x)([
                  e,
                  "optionalAccess",
                  (e) => e.forEach,
                  "call",
                  (e) =>
                    e((e, t) => {
                      s[t] = e;
                    }),
                ]);
            } catch (e) {
              n0.X &&
                v.kg.warn(
                  "Sentry wasn't able to extract the tracing headers for a server action. Will not trace this request."
                );
            }
            return (
              r.setTransactionName(`serverAction/${e}`),
              r.setSDKProcessingMetadata({ normalizedRequest: { headers: s } }),
              ni({ sentryTrace: a, baggage: i }, async () => {
                try {
                  return await nn(
                    {
                      op: "function.server_action",
                      name: `serverAction/${e}`,
                      forceTransaction: !0,
                      attributes: { [tX.Zj]: "route" },
                    },
                    async (e) => {
                      let r = await tK(n, (t) => {
                        tL(t)
                          ? e.setStatus({ code: ne.jt, message: "not_found" })
                          : tD(t) ||
                            (e.setStatus({
                              code: ne.jt,
                              message: "internal_error",
                            }),
                            (0, m.Tb)(t, { mechanism: { handled: !1 } }));
                      });
                      return (
                        (void 0 !== t.recordResponse ? t.recordResponse : o) &&
                          (0, g.aF)().setExtra("server_action_result", r),
                        t.formData &&
                          t.formData.forEach((e, t) => {
                            (0, g.aF)().setExtra(
                              `server_action_form_data.${t}`,
                              "string" == typeof e ? e : "[non-string value]"
                            );
                          }),
                        r
                      );
                    }
                  );
                } finally {
                  (0, rm.q)((0, r_.R)());
                }
              })
            );
          });
        }
        function rC(e, t, n) {
          (0, g.$e)((r) => {
            r.setSDKProcessingMetadata({
              normalizedRequest: {
                headers: (0, rn.RR)(t.headers),
                method: t.method,
              },
            }),
              r.setContext("nextjs", {
                request_path: t.path,
                router_kind: n.routerKind,
                router_path: n.routePath,
                route_type: n.routeType,
              }),
              r.setTransactionName(n.routePath),
              (0, m.Tb)(e, { mechanism: { handled: !1 } });
          });
        }
        let rA = rC;
        function rR() {
          nL();
        }
        let rN = (e = {}) => {
            let t = e.levels || v.RU;
            return {
              name: "CaptureConsole",
              setup(e) {
                "console" in em.n &&
                  ex(({ args: n, level: r }) => {
                    (0, g.s3)() === e &&
                      t.includes(r) &&
                      (function (e, t) {
                        let n = {
                          level: (0, eD.V)(t),
                          extra: { arguments: e },
                        };
                        (0, g.$e)((r) => {
                          if (
                            (r.addEventProcessor(
                              (e) => (
                                (e.logger = "console"),
                                (0, w.EG)(e, { handled: !1, type: "console" }),
                                e
                              )
                            ),
                            "assert" === t)
                          ) {
                            if (!e[0]) {
                              let t = `Assertion failed: ${
                                (0, T.nK)(e.slice(1), " ") || "console.assert"
                              }`;
                              r.setExtra("arguments", e.slice(1)),
                                (0, m.uT)(t, n);
                            }
                            return;
                          }
                          let a = e.find((e) => e instanceof Error);
                          if (a) {
                            (0, m.Tb)(a, n);
                            return;
                          }
                          let i = (0, T.nK)(e, " ");
                          (0, m.uT)(i, n);
                        });
                      })(n, r);
                  });
              },
            };
          },
          rP = rN;
        function rM(e, t = {}, n = (0, g.nZ)()) {
          let {
              message: r,
              name: a,
              email: i,
              url: o,
              source: s,
              associatedEventId: l,
              tags: u,
            } = e,
            c = {
              contexts: {
                feedback: (0, A.Jr)({
                  contact_email: i,
                  name: a,
                  message: r,
                  url: o,
                  source: s,
                  associated_event_id: l,
                }),
              },
              type: "feedback",
              level: "info",
              tags: u,
            },
            d = (n && n.getClient()) || (0, g.s3)();
          d && d.emit("beforeSendFeedback", c, t);
          let p = n.captureEvent(c, t);
          return p;
        }
        let rL = (e = {}) => {
            let t = { debugger: !1, stringify: !1, ...e };
            return {
              name: "Debug",
              setup(e) {
                e.on("beforeSendEvent", (e, n) => {
                  t.debugger,
                    (0, v.Cf)(() => {
                      t.stringify
                        ? (console.log(JSON.stringify(e, null, 2)),
                          n &&
                            Object.keys(n).length &&
                            console.log(JSON.stringify(n, null, 2)))
                        : (console.log(e),
                          n && Object.keys(n).length && console.log(n));
                    });
                });
              },
            };
          },
          rD = rL,
          rO = (e = {}) => {
            let { depth: t = 3, captureErrorCause: n = !0 } = e;
            return {
              name: "ExtraErrorData",
              processEvent(e, r, a) {
                let { maxValueLength: i = 250 } = a.getOptions();
                return (function (e, t = {}, n, r, a) {
                  if (!t.originalException || !(0, z.VZ)(t.originalException))
                    return e;
                  let i =
                      t.originalException.name ||
                      t.originalException.constructor.name,
                    o = (function (e, t, n) {
                      try {
                        let r = [
                            "name",
                            "message",
                            "stack",
                            "line",
                            "column",
                            "fileName",
                            "lineNumber",
                            "columnNumber",
                            "toJSON",
                          ],
                          a = {};
                        for (let t of Object.keys(e)) {
                          if (-1 !== r.indexOf(t)) continue;
                          let i = e[t];
                          a[t] =
                            (0, z.VZ)(i) || "string" == typeof i
                              ? (0, T.$G)(`${i}`, n)
                              : i;
                        }
                        if (
                          (t &&
                            void 0 !== e.cause &&
                            (a.cause = (0, z.VZ)(e.cause)
                              ? e.cause.toString()
                              : e.cause),
                          "function" == typeof e.toJSON)
                        ) {
                          let t = e.toJSON();
                          for (let e of Object.keys(t)) {
                            let n = t[e];
                            a[e] = (0, z.VZ)(n) ? n.toString() : n;
                          }
                        }
                        return a;
                      } catch (e) {
                        _.X &&
                          v.kg.error(
                            "Unable to extract extra data from the Error object:",
                            e
                          );
                      }
                      return null;
                    })(t.originalException, r, a);
                  if (o) {
                    let t = { ...e.contexts },
                      r = (0, ei.Fv)(o, n);
                    return (
                      (0, z.PO)(r) &&
                        ((0, A.xp)(r, "__sentry_skip_normalization__", !0),
                        (t[i] = r)),
                      { ...e, contexts: t }
                    );
                  }
                  return e;
                })(e, r, t, n, i);
              },
            };
          },
          r$ = rO,
          rF = function () {
            return {
              bindClient(e) {
                let t = (0, g.nZ)();
                t.setClient(e);
              },
              withScope: g.$e,
              getClient: () => (0, g.s3)(),
              getScope: g.nZ,
              getIsolationScope: g.aF,
              captureException: (e, t) => (0, g.nZ)().captureException(e, t),
              captureMessage: (e, t, n) => (0, g.nZ)().captureMessage(e, t, n),
              captureEvent: m.eN,
              addBreadcrumb: eM.n,
              setUser: m.av,
              setTags: m.mG,
              setTag: m.YA,
              setExtra: m.sU,
              setExtras: m.rJ,
              setContext: m.v,
              getIntegration(e) {
                let t = (0, g.s3)();
                return (t && t.getIntegrationByName(e.id)) || null;
              },
              startSession: m.yj,
              endSession: m.TM,
              captureSession(e) {
                if (e) return (0, m.TM)();
                (function () {
                  let e = (0, g.nZ)(),
                    t = (0, g.s3)(),
                    n = e.getSession();
                  t && n && t.captureSession(n);
                })();
              },
            };
          };
        function rU(e, t) {
          let n;
          return (
            (0, G.gv)(
              e,
              (e, r) => (
                t.includes(r) && (n = Array.isArray(e) ? e[1] : void 0), !!n
              )
            ),
            n
          );
        }
        function rj(e, t) {
          return (n) => {
            let r = e(n),
              a = new Map();
            function i(t, r) {
              let i = r ? `${t}:${r}` : t,
                o = a.get(i);
              if (!o) {
                let s = (0, H.U4)(t);
                if (!s) return;
                let l = B(s, n.tunnel);
                (o = r
                  ? ((t) => {
                      let n = e(t);
                      return {
                        ...n,
                        send: async (e) => {
                          let t = rU(e, [
                            "event",
                            "transaction",
                            "profile",
                            "replay_event",
                          ]);
                          return t && (t.release = r), n.send(e);
                        },
                      };
                    })({ ...n, url: l })
                  : e({ ...n, url: l })),
                  a.set(i, o);
              }
              return [t, o];
            }
            return {
              send: async function (e) {
                let n = t({
                    envelope: e,
                    getEvent: function (t) {
                      let n = t && t.length ? t : ["event"];
                      return rU(e, n);
                    },
                  })
                    .map((e) =>
                      "string" == typeof e ? i(e, void 0) : i(e.dsn, e.release)
                    )
                    .filter((e) => !!e),
                  a = n.length ? n : [["", r]],
                  o = await Promise.all(
                    a.map(([t, n]) =>
                      n.send((0, G.Jd)(t ? { ...e[0], dsn: t } : e[0], e[1]))
                    )
                  );
                return o[0];
              },
              flush: async function (e) {
                let t = [...a.values(), r],
                  n = await Promise.all(t.map((t) => t.flush(e)));
                return n.every((e) => e);
              },
            };
          };
        }
        let rH = new Map(),
          rX = new Set();
        function rB(e, t) {
          try {
            t.exception.values.forEach((t) => {
              if (t.stacktrace)
                for (let r of t.stacktrace.frames || []) {
                  var n;
                  if (!r.filename || r.module_metadata) continue;
                  let t =
                    ((n = r.filename),
                    (function (e) {
                      if (em.n._sentryModuleMetadata)
                        for (let t of Object.keys(em.n._sentryModuleMetadata)) {
                          let n = em.n._sentryModuleMetadata[t];
                          if (rX.has(t)) continue;
                          rX.add(t);
                          let r = e(t);
                          for (let e of r.reverse())
                            if (e.filename) {
                              rH.set(e.filename, n);
                              break;
                            }
                        }
                    })(e),
                    rH.get(n));
                  t && (r.module_metadata = t);
                }
            });
          } catch (e) {}
        }
        function rW(e) {
          try {
            e.exception.values.forEach((e) => {
              if (e.stacktrace)
                for (let t of e.stacktrace.frames || [])
                  delete t.module_metadata;
            });
          } catch (e) {}
        }
        let rG = () => ({
          name: "ModuleMetadata",
          setup(e) {
            e.on("beforeEnvelope", (e) => {
              (0, G.gv)(e, (e, t) => {
                if ("event" === t) {
                  let t = Array.isArray(e) ? e[1] : void 0;
                  t && (rW(t), (e[1] = t));
                }
              });
            }),
              e.on("applyFrameMetadata", (t) => {
                if (t.type) return;
                let n = e.getOptions().stackParser;
                rB(n, t);
              });
          },
        });
        function rq(e, ...t) {
          let n = new String(String.raw(e, ...t));
          return (
            (n.__sentry_template_string__ = e
              .join("\x00")
              .replace(/%/g, "%%")
              .replace(/\0/g, "%s")),
            (n.__sentry_template_values__ = t),
            n
          );
        }
        let rZ = () => {
            let e = 1e3 * (0, V.ph)();
            return {
              name: "SessionTiming",
              processEvent(t) {
                let n = 1e3 * (0, V.ph)();
                return {
                  ...t,
                  extra: {
                    ...t.extra,
                    "session:start": e,
                    "session:duration": n - e,
                    "session:end": n,
                  },
                };
              },
            };
          },
          rV = rZ,
          rY = (e) => ({
            name: "ThirdPartyErrorsFilter",
            setup(e) {
              e.on("beforeEnvelope", (e) => {
                (0, G.gv)(e, (e, t) => {
                  if ("event" === t) {
                    let t = Array.isArray(e) ? e[1] : void 0;
                    t && (rW(t), (e[1] = t));
                  }
                });
              }),
                e.on("applyFrameMetadata", (t) => {
                  if (t.type) return;
                  let n = e.getOptions().stackParser;
                  rB(n, t);
                });
            },
            processEvent(t) {
              let n = (function (e) {
                let t = (0, M.Fr)(e);
                if (t)
                  return t
                    .filter((e) => !!e.filename)
                    .map((e) =>
                      e.module_metadata
                        ? Object.keys(e.module_metadata)
                            .filter((e) => e.startsWith(rz))
                            .map((e) => e.slice(rz.length))
                        : []
                    );
              })(t);
              if (n) {
                let r =
                    "drop-error-if-contains-third-party-frames" ===
                      e.behaviour ||
                    "apply-tag-if-contains-third-party-frames" === e.behaviour
                      ? "some"
                      : "every",
                  a = n[r]((t) => !t.some((t) => e.filterKeys.includes(t)));
                if (a) {
                  let n =
                    "drop-error-if-contains-third-party-frames" ===
                      e.behaviour ||
                    "drop-error-if-exclusively-contains-third-party-frames" ===
                      e.behaviour;
                  if (n) return null;
                  t.tags = { ...t.tags, third_party_code: !0 };
                }
              }
              return t;
            },
          }),
          rz = "_sentryBundlerPluginAppKey:";
        function rJ(e) {
          return {
            ...e,
            path:
              "path" in e && Array.isArray(e.path) ? e.path.join(".") : void 0,
            keys: "keys" in e ? JSON.stringify(e.keys) : void 0,
            unionErrors:
              "unionErrors" in e ? JSON.stringify(e.unionErrors) : void 0,
          };
        }
        let rK = (e = {}) => {
            let t = e.limit || 10;
            return {
              name: "ZodErrors",
              processEvent(e, n) {
                var r;
                let a =
                  e.exception &&
                  e.exception.values &&
                  n &&
                  n.originalException &&
                  ((r = n.originalException),
                  (0, z.VZ)(r) &&
                    "ZodError" === r.name &&
                    Array.isArray(r.errors)) &&
                  0 !== n.originalException.issues.length
                    ? {
                        ...e,
                        exception: {
                          ...e.exception,
                          values: [
                            {
                              ...e.exception.values[0],
                              value: (function (e) {
                                let t = new Set();
                                for (let n of e.issues)
                                  n.path && n.path[0] && t.add(n.path[0]);
                                let n = Array.from(t);
                                return `Failed to validate keys: ${(0, T.$G)(
                                  n.join(", "),
                                  100
                                )}`;
                              })(n.originalException),
                            },
                            ...e.exception.values.slice(1),
                          ],
                        },
                        extra: {
                          ...e.extra,
                          "zoderror.issues": n.originalException.errors
                            .slice(0, t)
                            .map(rJ),
                        },
                      }
                    : e;
                return a;
              },
            };
          },
          rQ = rK,
          r0 = {
            replayIntegration: "replay",
            replayCanvasIntegration: "replay-canvas",
            feedbackIntegration: "feedback",
            feedbackModalIntegration: "feedback-modal",
            feedbackScreenshotIntegration: "feedback-screenshot",
            captureConsoleIntegration: "captureconsole",
            contextLinesIntegration: "contextlines",
            linkedErrorsIntegration: "linkederrors",
            debugIntegration: "debug",
            dedupeIntegration: "dedupe",
            extraErrorDataIntegration: "extraerrordata",
            httpClientIntegration: "httpclient",
            reportingObserverIntegration: "reportingobserver",
            rewriteFramesIntegration: "rewriteframes",
            sessionTimingIntegration: "sessiontiming",
            browserProfilingIntegration: "browserprofiling",
            moduleMetadataIntegration: "modulemetadata",
          },
          r1 = e_;
        async function r3(e, t) {
          let n = r0[e],
            r = (r1.Sentry = r1.Sentry || {});
          if (!n) throw Error(`Cannot lazy load integration: ${e}`);
          let a = r[e];
          if ("function" == typeof a && !("_isShim" in a)) return a;
          let i = (function (e) {
              let t = (0, g.s3)(),
                n = t && t.getOptions(),
                r = (n && n.cdnBaseUrl) || "https://browser.sentry-cdn.com";
              return new URL(`/${f.J}/${e}.min.js`, r).toString();
            })(n),
            o = e_.document.createElement("script");
          (o.src = i),
            (o.crossOrigin = "anonymous"),
            (o.referrerPolicy = "origin"),
            t && o.setAttribute("nonce", t);
          let s = new Promise((e, t) => {
              o.addEventListener("load", () => e()),
                o.addEventListener("error", t);
            }),
            l = e_.document.currentScript,
            u = e_.document.body || e_.document.head || (l && l.parentElement);
          if (u) u.appendChild(o);
          else
            throw Error(
              `Could not find parent element to insert lazy-loaded ${e} script`
            );
          try {
            await s;
          } catch (t) {
            throw Error(`Error when loading integration: ${e}`);
          }
          let c = r[e];
          if ("function" != typeof c)
            throw Error(`Could not load integration: ${e}`);
          return c;
        }
        let r2 = em.n,
          r4 = new WeakMap(),
          r5 = (e = {}) => {
            let t = e.types || ["crash", "deprecation", "intervention"];
            function n(e) {
              if (r4.has((0, g.s3)()))
                for (let t of e)
                  (0, g.$e)((e) => {
                    e.setExtra("url", t.url);
                    let n = `ReportingObserver [${t.type}]`,
                      r = "No details available";
                    if (t.body) {
                      let n = {};
                      for (let e in t.body) n[e] = t.body[e];
                      if ((e.setExtra("body", n), "crash" === t.type)) {
                        let e = t.body;
                        r =
                          [e.crashId || "", e.reason || ""].join(" ").trim() ||
                          r;
                      } else {
                        let e = t.body;
                        r = e.message || r;
                      }
                    }
                    (0, m.uT)(`${n}: ${r}`);
                  });
            }
            return {
              name: "ReportingObserver",
              setupOnce() {
                if (!(0, U.zb)()) return;
                let e = new r2.ReportingObserver(n, { buffered: !0, types: t });
                e.observe();
              },
              setup(e) {
                r4.set(e, !0);
              },
            };
          },
          r6 = r5;
        var r9 = n(42206);
        let r7 = (e = {}) => {
            let t = {
              failedRequestStatusCodes: [[500, 599]],
              failedRequestTargets: [/.*/],
              ...e,
            };
            return {
              name: "HttpClient",
              setup(e) {
                (0, U.t$)() &&
                  eI((n) => {
                    if ((0, g.s3)() !== e) return;
                    let { response: r, args: a } = n,
                      [i, o] = a;
                    r &&
                      (function (e, t, n, r) {
                        if (an(e, n.status, n.url)) {
                          let e, a, i, o;
                          let s =
                            (!r && t instanceof Request) ||
                            (t instanceof Request && t.bodyUsed)
                              ? t
                              : new Request(t, r);
                          aa() &&
                            (([e, i] = ae("Cookie", s)),
                            ([a, o] = ae("Set-Cookie", n)));
                          let l = ar({
                            url: s.url,
                            method: s.method,
                            status: n.status,
                            requestHeaders: e,
                            responseHeaders: a,
                            requestCookies: i,
                            responseCookies: o,
                          });
                          (0, m.eN)(l);
                        }
                      })(t, i, r, o);
                  }),
                  "XMLHttpRequest" in em.n &&
                    (0, eS.UK)((n) => {
                      if ((0, g.s3)() !== e) return;
                      let r = n.xhr,
                        a = r[eS.xU];
                      if (!a) return;
                      let { method: i, request_headers: o } = a;
                      try {
                        !(function (e, t, n, r) {
                          if (an(e, t.status, t.responseURL)) {
                            let e, a, i;
                            if (aa()) {
                              try {
                                let e =
                                  t.getResponseHeader("Set-Cookie") ||
                                  t.getResponseHeader("set-cookie") ||
                                  void 0;
                                e && (a = at(e));
                              } catch (e) {}
                              try {
                                i = (function (e) {
                                  let t = e.getAllResponseHeaders();
                                  return t
                                    ? t.split("\r\n").reduce((e, t) => {
                                        let [n, r] = t.split(": ");
                                        return n && r && (e[n] = r), e;
                                      }, {})
                                    : {};
                                })(t);
                              } catch (e) {}
                              e = r;
                            }
                            let o = ar({
                              url: t.responseURL,
                              method: n,
                              status: t.status,
                              requestHeaders: e,
                              responseHeaders: i,
                              responseCookies: a,
                            });
                            (0, m.eN)(o);
                          }
                        })(t, r, i, o);
                      } catch (e) {}
                    });
              },
            };
          },
          r8 = r7;
        function ae(e, t) {
          let n;
          let r = (function (e) {
            let t = {};
            return (
              e.forEach((e, n) => {
                t[n] = e;
              }),
              t
            );
          })(t.headers);
          try {
            let t = r[e] || r[e.toLowerCase()] || void 0;
            t && (n = at(t));
          } catch (e) {}
          return [r, n];
        }
        function at(e) {
          return e.split("; ").reduce((e, t) => {
            let [n, r] = t.split("=");
            return n && r && (e[n] = r), e;
          }, {});
        }
        function an(e, t, n) {
          return (
            e.failedRequestStatusCodes.some((e) =>
              "number" == typeof e ? e === t : t >= e[0] && t <= e[1]
            ) &&
            e.failedRequestTargets.some((e) =>
              "string" == typeof e ? n.includes(e) : e.test(n)
            ) &&
            !(0, r9.W)(n, (0, g.s3)())
          );
        }
        function ar(e) {
          let t = `HTTP Client Error with status code: ${e.status}`,
            n = {
              message: t,
              exception: { values: [{ type: "Error", value: t }] },
              request: {
                url: e.url,
                method: e.method,
                headers: e.requestHeaders,
                cookies: e.requestCookies,
              },
              contexts: {
                response: {
                  status_code: e.status,
                  headers: e.responseHeaders,
                  cookies: e.responseCookies,
                  body_size: (function (e) {
                    if (e) {
                      let t = e["Content-Length"] || e["content-length"];
                      if (t) return parseInt(t, 10);
                    }
                  })(e.responseHeaders),
                },
              },
            };
          return (0, w.EG)(n, { type: "http.client", handled: !1 }), n;
        }
        function aa() {
          let e = (0, g.s3)();
          return !!e && Boolean(e.getOptions().sendDefaultPii);
        }
        let ai = em.n,
          ao = (e = {}) => {
            let t = null != e.frameContextLines ? e.frameContextLines : 7;
            return {
              name: "ContextLines",
              processEvent: (e) =>
                (function (e, t) {
                  let n = ai.document,
                    r = ai.location && eF(ai.location.href);
                  if (!n || !r) return e;
                  let a = e.exception && e.exception.values;
                  if (!a || !a.length) return e;
                  let i = n.documentElement.innerHTML;
                  if (!i) return e;
                  let o = [
                    "<!DOCTYPE html>",
                    "<html>",
                    ...i.split("\n"),
                    "</html>",
                  ];
                  return (
                    a.forEach((e) => {
                      let n = e.stacktrace;
                      n &&
                        n.frames &&
                        (n.frames = n.frames.map(
                          (e) => (
                            e.filename === r &&
                              e.lineno &&
                              o.length &&
                              (0, w.go)(o, e, t),
                            e
                          )
                        ));
                    }),
                    e
                  );
                })(e, t),
            };
          },
          as = ao;
        var al = n(69821);
        function au(e, t, n = 1 / 0, r = 0) {
          return !e || e.nodeType !== e.ELEMENT_NODE || r > n
            ? -1
            : t(e)
            ? r
            : au(e.parentNode, t, n, r + 1);
        }
        function ac(e, t) {
          return (n) => {
            if (null === n) return !1;
            try {
              if (e) {
                if ("string" == typeof e) {
                  if (n.matches(`.${e}`)) return !0;
                } else if (
                  (function (e, t) {
                    for (let n = e.classList.length; n--; ) {
                      let r = e.classList[n];
                      if (t.test(r)) return !0;
                    }
                    return !1;
                  })(n, e)
                )
                  return !0;
              }
              if (t && n.matches(t)) return !0;
              return !1;
            } catch (e) {
              return !1;
            }
          };
        }
        ((az = aK || (aK = {}))[(az.Document = 0)] = "Document"),
          (az[(az.DocumentType = 1)] = "DocumentType"),
          (az[(az.Element = 2)] = "Element"),
          (az[(az.Text = 3)] = "Text"),
          (az[(az.CDATA = 4)] = "CDATA"),
          (az[(az.Comment = 5)] = "Comment");
        let ad =
            "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
          ap = {
            map: {},
            getId: () => (console.error(ad), -1),
            getNode: () => (console.error(ad), null),
            removeNodeFromMap() {
              console.error(ad);
            },
            has: () => (console.error(ad), !1),
            reset() {
              console.error(ad);
            },
          };
        function af(e, t, n, r, a = window) {
          let i = a.Object.getOwnPropertyDescriptor(e, t);
          return (
            a.Object.defineProperty(
              e,
              t,
              r
                ? n
                : {
                    set(e) {
                      ay(() => {
                        n.set.call(this, e);
                      }, 0),
                        i && i.set && i.set.call(this, e);
                    },
                  }
            ),
            () => af(e, t, i || {}, !0)
          );
        }
        function ah(e, t, n) {
          try {
            if (!(t in e)) return () => {};
            let r = e[t],
              a = n(r);
            return (
              "function" == typeof a &&
                ((a.prototype = a.prototype || {}),
                Object.defineProperties(a, {
                  __rrweb_original__: { enumerable: !1, value: r },
                })),
              (e[t] = a),
              () => {
                e[t] = r;
              }
            );
          } catch (e) {
            return () => {};
          }
        }
        function am(e, t, n, r, a) {
          if (!e) return !1;
          let i = (function (e) {
            if (!e) return null;
            let t = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
            return t;
          })(e);
          if (!i) return !1;
          let o = ac(t, n),
            s = au(i, o),
            l = -1;
          return (
            !(s < 0) &&
            (r && (l = au(i, ac(null, r))), (s > -1 && l < 0) || s < l)
          );
        }
        "undefined" != typeof window &&
          window.Proxy &&
          window.Reflect &&
          (ap = new Proxy(ap, {
            get: (e, t, n) => (
              "map" === t && console.error(ad), Reflect.get(e, t, n)
            ),
          })),
          /[1-9][0-9]{12}/.test(Date.now().toString());
        let a_ = {};
        function ag(e) {
          let t = a_[e];
          if (t) return t;
          let n = window.document,
            r = window[e];
          if (n && "function" == typeof n.createElement)
            try {
              let t = n.createElement("iframe");
              (t.hidden = !0), n.head.appendChild(t);
              let a = t.contentWindow;
              a && a[e] && (r = a[e]), n.head.removeChild(t);
            } catch (e) {}
          return (a_[e] = r.bind(window));
        }
        function av(...e) {
          return ag("requestAnimationFrame")(...e);
        }
        function ay(...e) {
          return ag("setTimeout")(...e);
        }
        var ab =
          (((aJ = ab || {})[(aJ["2D"] = 0)] = "2D"),
          (aJ[(aJ.WebGL = 1)] = "WebGL"),
          (aJ[(aJ.WebGL2 = 2)] = "WebGL2"),
          aJ);
        let aE = (e) => {
          if (!o) return e;
          let t = (...t) => {
            try {
              return e(...t);
            } catch (e) {
              if (o && !0 === o(e)) return () => {};
              throw e;
            }
          };
          return t;
        };
        for (
          var aS =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
            aw = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256),
            aT = 0;
          aT < aS.length;
          aT++
        )
          aw[aS.charCodeAt(aT)] = aT;
        var ax = function (e) {
          var t,
            n = new Uint8Array(e),
            r = n.length,
            a = "";
          for (t = 0; t < r; t += 3)
            a +=
              aS[n[t] >> 2] +
              aS[((3 & n[t]) << 4) | (n[t + 1] >> 4)] +
              aS[((15 & n[t + 1]) << 2) | (n[t + 2] >> 6)] +
              aS[63 & n[t + 2]];
          return (
            r % 3 == 2
              ? (a = a.substring(0, a.length - 1) + "=")
              : r % 3 == 1 && (a = a.substring(0, a.length - 2) + "=="),
            a
          );
        };
        let ak = new Map(),
          aI = (e, t, n) => {
            let r;
            if (!e || !(aA(e, t) || "object" == typeof e)) return;
            let a = e.constructor.name,
              i =
                ((r = ak.get(n)) || ((r = new Map()), ak.set(n, r)),
                r.has(a) || r.set(a, []),
                r.get(a)),
              o = i.indexOf(e);
            return -1 === o && ((o = i.length), i.push(e)), o;
          },
          aC = (e, t, n) =>
            e.map((e) =>
              (function e(t, n, r) {
                if (t instanceof Array) return t.map((t) => e(t, n, r));
                if (null === t);
                else if (
                  t instanceof Float32Array ||
                  t instanceof Float64Array ||
                  t instanceof Int32Array ||
                  t instanceof Uint32Array ||
                  t instanceof Uint8Array ||
                  t instanceof Uint16Array ||
                  t instanceof Int16Array ||
                  t instanceof Int8Array ||
                  t instanceof Uint8ClampedArray
                ) {
                  let e = t.constructor.name;
                  return { rr_type: e, args: [Object.values(t)] };
                } else if (t instanceof ArrayBuffer) {
                  let e = t.constructor.name,
                    n = ax(t);
                  return { rr_type: e, base64: n };
                } else if (t instanceof DataView) {
                  let a = t.constructor.name;
                  return {
                    rr_type: a,
                    args: [e(t.buffer, n, r), t.byteOffset, t.byteLength],
                  };
                } else if (t instanceof HTMLImageElement) {
                  let e = t.constructor.name,
                    { src: n } = t;
                  return { rr_type: e, src: n };
                } else if (t instanceof HTMLCanvasElement) {
                  let e = t.toDataURL();
                  return { rr_type: "HTMLImageElement", src: e };
                } else if (t instanceof ImageData) {
                  let a = t.constructor.name;
                  return {
                    rr_type: a,
                    args: [e(t.data, n, r), t.width, t.height],
                  };
                } else if (aA(t, n) || "object" == typeof t) {
                  let e = t.constructor.name,
                    a = aI(t, n, r);
                  return { rr_type: e, index: a };
                }
                return t;
              })(e, t, n)
            ),
          aA = (e, t) => {
            let n = [
              "WebGLActiveInfo",
              "WebGLBuffer",
              "WebGLFramebuffer",
              "WebGLProgram",
              "WebGLRenderbuffer",
              "WebGLShader",
              "WebGLShaderPrecisionFormat",
              "WebGLTexture",
              "WebGLUniformLocation",
              "WebGLVertexArrayObject",
              "WebGLVertexArrayObjectOES",
            ].filter((e) => "function" == typeof t[e]);
            return Boolean(n.find((n) => e instanceof t[n]));
          };
        function aR(e, t, n, r, a) {
          let i = [];
          try {
            let o = ah(
              e.HTMLCanvasElement.prototype,
              "getContext",
              function (e) {
                return function (i, ...o) {
                  if (!am(this, t, n, r, !0)) {
                    let e = "experimental-webgl" === i ? "webgl" : i;
                    if (
                      ("__context" in this || (this.__context = e),
                      a && ["webgl", "webgl2"].includes(e))
                    ) {
                      if (o[0] && "object" == typeof o[0]) {
                        let e = o[0];
                        e.preserveDrawingBuffer ||
                          (e.preserveDrawingBuffer = !0);
                      } else o.splice(0, 1, { preserveDrawingBuffer: !0 });
                    }
                  }
                  return e.apply(this, [i, ...o]);
                };
              }
            );
            i.push(o);
          } catch (e) {
            console.error(
              "failed to patch HTMLCanvasElement.prototype.getContext"
            );
          }
          return () => {
            i.forEach((e) => e());
          };
        }
        function aN(e, t, n, r, a, i, o, s) {
          let l = [],
            u = Object.getOwnPropertyNames(e);
          for (let o of u)
            if (
              ![
                "isContextLost",
                "canvas",
                "drawingBufferWidth",
                "drawingBufferHeight",
              ].includes(o)
            )
              try {
                if ("function" != typeof e[o]) continue;
                let u = ah(e, o, function (e) {
                  return function (...l) {
                    let u = e.apply(this, l);
                    if (
                      (aI(u, s, this),
                      "tagName" in this.canvas && !am(this.canvas, r, a, i, !0))
                    ) {
                      let e = aC(l, s, this),
                        r = { type: t, property: o, args: e };
                      n(this.canvas, r);
                    }
                    return u;
                  };
                });
                l.push(u);
              } catch (a) {
                let r = af(e, o, {
                  set(e) {
                    n(this.canvas, {
                      type: t,
                      property: o,
                      args: [e],
                      setter: !0,
                    });
                  },
                });
                l.push(r);
              }
          return l;
        }
        class aP {
          reset() {
            this.pendingCanvasMutations.clear(),
              this.restoreHandlers.forEach((e) => {
                try {
                  e();
                } catch (e) {}
              }),
              (this.restoreHandlers = []),
              (this.windowsSet = new WeakSet()),
              (this.windows = []),
              (this.shadowDoms = new Set()),
              (0, p.x)([
                this,
                "access",
                (e) => e.worker,
                "optionalAccess",
                (e) => e.terminate,
                "call",
                (e) => e(),
              ]),
              (this.worker = null),
              (this.snapshotInProgressMap = new Map());
          }
          freeze() {
            this.frozen = !0;
          }
          unfreeze() {
            this.frozen = !1;
          }
          lock() {
            this.locked = !0;
          }
          unlock() {
            this.locked = !1;
          }
          constructor(e) {
            (this.pendingCanvasMutations = new Map()),
              (this.rafStamps = { latestId: 0, invokeId: null }),
              (this.shadowDoms = new Set()),
              (this.windowsSet = new WeakSet()),
              (this.windows = []),
              (this.restoreHandlers = []),
              (this.frozen = !1),
              (this.locked = !1),
              (this.snapshotInProgressMap = new Map()),
              (this.worker = null),
              (this.processMutation = (e, t) => {
                let n =
                  this.rafStamps.invokeId &&
                  this.rafStamps.latestId !== this.rafStamps.invokeId;
                (n || !this.rafStamps.invokeId) &&
                  (this.rafStamps.invokeId = this.rafStamps.latestId),
                  this.pendingCanvasMutations.has(e) ||
                    this.pendingCanvasMutations.set(e, []),
                  this.pendingCanvasMutations.get(e).push(t);
              });
            let {
              sampling: t = "all",
              win: n,
              blockClass: r,
              blockSelector: a,
              unblockSelector: i,
              maxCanvasSize: s,
              recordCanvas: l,
              dataURLOptions: u,
              errorHandler: c,
            } = e;
            if (
              ((this.mutationCb = e.mutationCb),
              (this.mirror = e.mirror),
              (this.options = e),
              c && (o = c),
              ((l && "number" == typeof t) || e.enableManualSnapshot) &&
                (this.worker = this.initFPSWorker()),
              this.addWindow(n),
              e.enableManualSnapshot)
            )
              return;
            aE(() => {
              l &&
                "all" === t &&
                (this.startRAFTimestamping(),
                this.startPendingCanvasMutationFlusher()),
                l &&
                  "number" == typeof t &&
                  this.initCanvasFPSObserver(t, r, a, i, s, {
                    dataURLOptions: u,
                  });
            })();
          }
          addWindow(e) {
            let {
              sampling: t = "all",
              blockClass: n,
              blockSelector: r,
              unblockSelector: a,
              recordCanvas: i,
              enableManualSnapshot: o,
            } = this.options;
            if (!this.windowsSet.has(e)) {
              if (o) {
                this.windowsSet.add(e), this.windows.push(new WeakRef(e));
                return;
              }
              aE(() => {
                if (
                  (i &&
                    "all" === t &&
                    this.initCanvasMutationObserver(e, n, r, a),
                  i && "number" == typeof t)
                ) {
                  let t = aR(e, n, r, a, !0);
                  this.restoreHandlers.push(() => {
                    t();
                  });
                }
              })(),
                this.windowsSet.add(e),
                this.windows.push(new WeakRef(e));
            }
          }
          addShadowRoot(e) {
            this.shadowDoms.add(new WeakRef(e));
          }
          resetShadowRoots() {
            this.shadowDoms = new Set();
          }
          initFPSWorker() {
            let e = new Worker(
              (function () {
                let e = new Blob([
                  'for(var e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",t="undefined"==typeof Uint8Array?[]:new Uint8Array(256),a=0;a<64;a++)t[e.charCodeAt(a)]=a;var n=function(t){var a,n=new Uint8Array(t),r=n.length,s="";for(a=0;a<r;a+=3)s+=e[n[a]>>2],s+=e[(3&n[a])<<4|n[a+1]>>4],s+=e[(15&n[a+1])<<2|n[a+2]>>6],s+=e[63&n[a+2]];return r%3==2?s=s.substring(0,s.length-1)+"=":r%3==1&&(s=s.substring(0,s.length-2)+"=="),s};const r=new Map,s=new Map;const i=self;i.onmessage=async function(e){if(!("OffscreenCanvas"in globalThis))return i.postMessage({id:e.data.id});{const{id:t,bitmap:a,width:o,height:f,maxCanvasSize:c,dataURLOptions:g}=e.data,u=async function(e,t,a){const r=e+"-"+t;if("OffscreenCanvas"in globalThis){if(s.has(r))return s.get(r);const i=new OffscreenCanvas(e,t);i.getContext("2d");const o=await i.convertToBlob(a),f=await o.arrayBuffer(),c=n(f);return s.set(r,c),c}return""}(o,f,g),[h,d]=function(e,t,a){if(!a)return[e,t];const[n,r]=a;if(e<=n&&t<=r)return[e,t];let s=e,i=t;return s>n&&(i=Math.floor(n*t/e),s=n),i>r&&(s=Math.floor(r*e/t),i=r),[s,i]}(o,f,c),l=new OffscreenCanvas(h,d),w=l.getContext("bitmaprenderer"),p=h===o&&d===f?a:await createImageBitmap(a,{resizeWidth:h,resizeHeight:d,resizeQuality:"low"});w.transferFromImageBitmap(p),a.close();const y=await l.convertToBlob(g),v=y.type,b=await y.arrayBuffer(),m=n(b);if(p.close(),!r.has(t)&&await u===m)return r.set(t,m),i.postMessage({id:t});if(r.get(t)===m)return i.postMessage({id:t});i.postMessage({id:t,type:v,base64:m,width:o,height:f}),r.set(t,m)}};',
                ]);
                return URL.createObjectURL(e);
              })()
            );
            return (
              (e.onmessage = (e) => {
                let t = e.data,
                  { id: n } = t;
                if ((this.snapshotInProgressMap.set(n, !1), !("base64" in t)))
                  return;
                let { base64: r, type: a, width: i, height: o } = t;
                this.mutationCb({
                  id: n,
                  type: ab["2D"],
                  commands: [
                    { property: "clearRect", args: [0, 0, i, o] },
                    {
                      property: "drawImage",
                      args: [
                        {
                          rr_type: "ImageBitmap",
                          args: [
                            {
                              rr_type: "Blob",
                              data: [{ rr_type: "ArrayBuffer", base64: r }],
                              type: a,
                            },
                          ],
                        },
                        0,
                        0,
                        i,
                        o,
                      ],
                    },
                  ],
                });
              }),
              e
            );
          }
          initCanvasFPSObserver(e, t, n, r, a, i) {
            let o = this.takeSnapshot(!1, e, t, n, r, a, i.dataURLOptions);
            this.restoreHandlers.push(() => {
              cancelAnimationFrame(o);
            });
          }
          initCanvasMutationObserver(e, t, n, r) {
            let a = aR(e, t, n, r, !1),
              i = (function (e, t, n, r, a) {
                let i = [],
                  o = Object.getOwnPropertyNames(
                    t.CanvasRenderingContext2D.prototype
                  );
                for (let s of o)
                  try {
                    if (
                      "function" !=
                      typeof t.CanvasRenderingContext2D.prototype[s]
                    )
                      continue;
                    let o = ah(
                      t.CanvasRenderingContext2D.prototype,
                      s,
                      function (i) {
                        return function (...o) {
                          return (
                            am(this.canvas, n, r, a, !0) ||
                              ay(() => {
                                let n = aC(o, t, this);
                                e(this.canvas, {
                                  type: ab["2D"],
                                  property: s,
                                  args: n,
                                });
                              }, 0),
                            i.apply(this, o)
                          );
                        };
                      }
                    );
                    i.push(o);
                  } catch (r) {
                    let n = af(t.CanvasRenderingContext2D.prototype, s, {
                      set(t) {
                        e(this.canvas, {
                          type: ab["2D"],
                          property: s,
                          args: [t],
                          setter: !0,
                        });
                      },
                    });
                    i.push(n);
                  }
                return () => {
                  i.forEach((e) => e());
                };
              })(this.processMutation.bind(this), e, t, n, r),
              o = (function (e, t, n, r, a, i) {
                let o = [];
                return (
                  o.push(
                    ...aN(
                      t.WebGLRenderingContext.prototype,
                      ab.WebGL,
                      e,
                      n,
                      r,
                      a,
                      i,
                      t
                    )
                  ),
                  void 0 !== t.WebGL2RenderingContext &&
                    o.push(
                      ...aN(
                        t.WebGL2RenderingContext.prototype,
                        ab.WebGL2,
                        e,
                        n,
                        r,
                        a,
                        i,
                        t
                      )
                    ),
                  () => {
                    o.forEach((e) => e());
                  }
                );
              })(this.processMutation.bind(this), e, t, n, r, this.mirror);
            this.restoreHandlers.push(() => {
              a(), i(), o();
            });
          }
          snapshot(e) {
            let { options: t } = this,
              n = this.takeSnapshot(
                !0,
                "all" === t.sampling ? 2 : t.sampling || 2,
                t.blockClass,
                t.blockSelector,
                t.unblockSelector,
                t.maxCanvasSize,
                t.dataURLOptions,
                e
              );
            this.restoreHandlers.push(() => {
              cancelAnimationFrame(n);
            });
          }
          takeSnapshot(e, t, n, r, a, i, o, s) {
            let l = 1e3 / t,
              u = 0,
              c = (e) => {
                if (e) return [e];
                let t = [],
                  i = (e) => {
                    e.querySelectorAll("canvas").forEach((e) => {
                      am(e, n, r, a) || t.push(e);
                    });
                  };
                for (let e of this.windows) {
                  let t = e.deref();
                  t && i(t.document);
                }
                for (let e of this.shadowDoms) {
                  let t = e.deref();
                  t && i(t);
                }
                return t;
              },
              d = (t) => {
                if (this.windows.length) {
                  if (u && t - u < l) {
                    av(d);
                    return;
                  }
                  (u = t),
                    c(s).forEach((t) => {
                      if (!this.mirror.hasNode(t)) return;
                      let n = this.mirror.getId(t);
                      if (
                        !this.snapshotInProgressMap.get(n) &&
                        t.width &&
                        t.height
                      ) {
                        if (
                          (this.snapshotInProgressMap.set(n, !0),
                          !e && ["webgl", "webgl2"].includes(t.__context))
                        ) {
                          let e = t.getContext(t.__context);
                          !1 ===
                            (0, p.x)([
                              e,
                              "optionalAccess",
                              (e) => e.getContextAttributes,
                              "call",
                              (e) => e(),
                              "optionalAccess",
                              (e) => e.preserveDrawingBuffer,
                            ]) && e.clear(e.COLOR_BUFFER_BIT);
                        }
                        createImageBitmap(t)
                          .then((e) => {
                            (0, p.x)([
                              this,
                              "access",
                              (e) => e.worker,
                              "optionalAccess",
                              (e) => e.postMessage,
                              "call",
                              (r) =>
                                r(
                                  {
                                    id: n,
                                    bitmap: e,
                                    width: t.width,
                                    height: t.height,
                                    dataURLOptions: o,
                                    maxCanvasSize: i,
                                  },
                                  [e]
                                ),
                            ]);
                          })
                          .catch((e) => {
                            aE(() => {
                              throw e;
                            })();
                          });
                      }
                    }),
                    e || av(d);
                }
              };
            return av(d);
          }
          startPendingCanvasMutationFlusher() {
            av(() => this.flushPendingCanvasMutations());
          }
          startRAFTimestamping() {
            let e = (t) => {
              (this.rafStamps.latestId = t), av(e);
            };
            av(e);
          }
          flushPendingCanvasMutations() {
            this.pendingCanvasMutations.forEach((e, t) => {
              let n = this.mirror.getId(t);
              this.flushPendingCanvasMutationFor(t, n);
            }),
              av(() => this.flushPendingCanvasMutations());
          }
          flushPendingCanvasMutationFor(e, t) {
            if (this.frozen || this.locked) return;
            let n = this.pendingCanvasMutations.get(e);
            if (!n || -1 === t) return;
            let r = n.map((e) => {
                let { type: t, ...n } = e;
                return n;
              }),
              { type: a } = n[0];
            this.mutationCb({ id: t, type: a, commands: r }),
              this.pendingCanvasMutations.delete(e);
          }
        }
        let aM = {
            low: {
              sampling: { canvas: 1 },
              dataURLOptions: { type: "image/webp", quality: 0.25 },
            },
            medium: {
              sampling: { canvas: 2 },
              dataURLOptions: { type: "image/webp", quality: 0.4 },
            },
            high: {
              sampling: { canvas: 4 },
              dataURLOptions: { type: "image/webp", quality: 0.5 },
            },
          },
          aL = (e = {}) => {
            let t;
            let [n, r] = e.maxCanvasSize || [],
              a = {
                quality: e.quality || "medium",
                enableManualSnapshot: e.enableManualSnapshot,
                maxCanvasSize: [
                  n ? Math.min(n, 1280) : 1280,
                  r ? Math.min(r, 1280) : 1280,
                ],
              },
              i = new Promise((e) => (t = e));
            return {
              name: "ReplayCanvas",
              getOptions() {
                let {
                  quality: e,
                  enableManualSnapshot: n,
                  maxCanvasSize: r,
                } = a;
                return {
                  enableManualSnapshot: n,
                  recordCanvas: !0,
                  getCanvasManager: (e) => {
                    let a = new aP({
                      ...e,
                      enableManualSnapshot: n,
                      maxCanvasSize: r,
                      errorHandler: (e) => {
                        try {
                          "object" == typeof e && (e.__rrweb__ = !0);
                        } catch (e) {}
                      },
                    });
                    return t(a), a;
                  },
                  ...(aM[e || "medium"] || aM.medium),
                };
              },
              async snapshot(e) {
                let t = await i;
                t.snapshot(e);
              },
            };
          },
          aD = aL;
        var aO = n(13185);
        let a$ = em.n,
          aF = a$.document,
          aU = a$.navigator,
          aj = "Report a Bug",
          aH = (e, t = { includeReplay: !0 }) => {
            if (!e.message)
              throw Error("Unable to submit feedback with empty message");
            let n = (0, g.s3)();
            if (!n) throw Error("No client setup, cannot send feedback.");
            e.tags && Object.keys(e.tags).length && (0, g.nZ)().setTags(e.tags);
            let r = rM({ source: "api", url: (0, eL.l4)(), ...e }, t);
            return new Promise((e, t) => {
              let a = setTimeout(
                  () =>
                    t("Unable to determine if Feedback was correctly sent."),
                  5e3
                ),
                i = n.on("afterSendEvent", (n, o) =>
                  n.event_id !== r
                    ? void 0
                    : (clearTimeout(a),
                      i(),
                      o &&
                        "number" == typeof o.statusCode &&
                        o.statusCode >= 200 &&
                        o.statusCode < 300 &&
                        e(r),
                      o &&
                        "number" == typeof o.statusCode &&
                        0 === o.statusCode)
                    ? t(
                        "Unable to send Feedback. This is because of network issues, or because you are using an ad-blocker."
                      )
                    : o &&
                      "number" == typeof o.statusCode &&
                      403 === o.statusCode
                    ? t(
                        "Unable to send Feedback. This could be because this domain is not in your list of allowed domains."
                      )
                    : t(
                        "Unable to send Feedback. This could be because of network issues, or because you are using an ad-blocker"
                      )
                );
            });
          };
        function aX(e, t) {
          return {
            ...e,
            ...t,
            tags: { ...e.tags, ...t.tags },
            onFormOpen: () => {
              t.onFormOpen && t.onFormOpen(), e.onFormOpen && e.onFormOpen();
            },
            onFormClose: () => {
              t.onFormClose && t.onFormClose(),
                e.onFormClose && e.onFormClose();
            },
            onSubmitSuccess: (n) => {
              t.onSubmitSuccess && t.onSubmitSuccess(n),
                e.onSubmitSuccess && e.onSubmitSuccess(n);
            },
            onSubmitError: (n) => {
              t.onSubmitError && t.onSubmitError(n),
                e.onSubmitError && e.onSubmitError(n);
            },
            onFormSubmitted: () => {
              t.onFormSubmitted && t.onFormSubmitted(),
                e.onFormSubmitted && e.onFormSubmitted();
            },
            themeDark: { ...e.themeDark, ...t.themeDark },
            themeLight: { ...e.themeLight, ...t.themeLight },
          };
        }
        function aB(e, t) {
          return (
            Object.entries(t).forEach(([t, n]) => {
              e.setAttributeNS(null, t, n);
            }),
            e
          );
        }
        let aW = "rgba(88, 74, 192, 1)",
          aG = {
            foreground: "#2b2233",
            background: "#ffffff",
            accentForeground: "white",
            accentBackground: aW,
            successColor: "#268d75",
            errorColor: "#df3338",
            border: "1.5px solid rgba(41, 35, 47, 0.13)",
            boxShadow: "0px 4px 24px 0px rgba(43, 34, 51, 0.12)",
            outline: "1px auto var(--accent-background)",
            interactiveFilter: "brightness(95%)",
          },
          aq = {
            foreground: "#ebe6ef",
            background: "#29232f",
            accentForeground: "white",
            accentBackground: aW,
            successColor: "#2da98c",
            errorColor: "#f55459",
            border: "1.5px solid rgba(235, 230, 239, 0.15)",
            boxShadow: "0px 4px 24px 0px rgba(43, 34, 51, 0.12)",
            outline: "1px auto var(--accent-background)",
            interactiveFilter: "brightness(150%)",
          };
        function aZ(e) {
          return `
  --foreground: ${e.foreground};
  --background: ${e.background};
  --accent-foreground: ${e.accentForeground};
  --accent-background: ${e.accentBackground};
  --success-color: ${e.successColor};
  --error-color: ${e.errorColor};
  --border: ${e.border};
  --box-shadow: ${e.boxShadow};
  --outline: ${e.outline};
  --interactive-filter: ${e.interactiveFilter};
  `;
        }
        let aV = ({
          lazyLoadIntegration: e,
          getModalIntegration: t,
          getScreenshotIntegration: n,
        }) => {
          let r = ({
            id: r = "sentry-feedback",
            autoInject: a = !0,
            showBranding: i = !0,
            isEmailRequired: o = !1,
            isNameRequired: s = !1,
            showEmail: l = !0,
            showName: u = !0,
            enableScreenshot: c = !0,
            useSentryUser: d = { email: "email", name: "username" },
            tags: p,
            styleNonce: f,
            scriptNonce: h,
            colorScheme: m = "system",
            themeLight: _ = {},
            themeDark: v = {},
            addScreenshotButtonLabel: y = "Add a screenshot",
            cancelButtonLabel: b = "Cancel",
            confirmButtonLabel: E = "Confirm",
            emailLabel: S = "Email",
            emailPlaceholder: w = "your.email@example.org",
            formTitle: T = "Report a Bug",
            isRequiredLabel: x = "(required)",
            messageLabel: k = "Description",
            messagePlaceholder: I = "What's the bug? What did you expect?",
            nameLabel: C = "Name",
            namePlaceholder: A = "Your Name",
            removeScreenshotButtonLabel: R = "Remove screenshot",
            submitButtonLabel: N = "Send Bug Report",
            successMessageText: P = "Thank you for your report!",
            triggerLabel: M = aj,
            triggerAriaLabel: L = "",
            onFormOpen: D,
            onFormClose: O,
            onSubmitSuccess: $,
            onSubmitError: F,
            onFormSubmitted: U,
          } = {}) => {
            let j = {
                id: r,
                autoInject: a,
                showBranding: i,
                isEmailRequired: o,
                isNameRequired: s,
                showEmail: l,
                showName: u,
                enableScreenshot: c,
                useSentryUser: d,
                tags: p,
                styleNonce: f,
                scriptNonce: h,
                colorScheme: m,
                themeDark: v,
                themeLight: _,
                triggerLabel: M,
                triggerAriaLabel: L,
                cancelButtonLabel: b,
                submitButtonLabel: N,
                confirmButtonLabel: E,
                formTitle: T,
                emailLabel: S,
                emailPlaceholder: w,
                messageLabel: k,
                messagePlaceholder: I,
                nameLabel: C,
                namePlaceholder: A,
                successMessageText: P,
                isRequiredLabel: x,
                addScreenshotButtonLabel: y,
                removeScreenshotButtonLabel: R,
                onFormClose: O,
                onFormOpen: D,
                onSubmitError: F,
                onSubmitSuccess: $,
                onFormSubmitted: U,
              },
              H = null,
              X = [],
              B = (e) => {
                if (!H) {
                  let t = aF.createElement("div");
                  (t.id = String(e.id)),
                    aF.body.appendChild(t),
                    (H = t.attachShadow({ mode: "open" })).appendChild(
                      (function ({
                        colorScheme: e,
                        themeDark: t,
                        themeLight: n,
                        styleNonce: r,
                      }) {
                        let a = aF.createElement("style");
                        return (
                          (a.textContent = `
:host {
  --font-family: system-ui, 'Helvetica Neue', Arial, sans-serif;
  --font-size: 14px;
  --z-index: 100000;

  --page-margin: 16px;
  --inset: auto 0 0 auto;
  --actor-inset: var(--inset);

  font-family: var(--font-family);
  font-size: var(--font-size);

  ${"system" !== e ? "color-scheme: only light;" : ""}

  ${aZ("dark" === e ? { ...aq, ...t } : { ...aG, ...n })}
}

${
  "system" === e
    ? `
@media (prefers-color-scheme: dark) {
  :host {
    ${aZ({ ...aq, ...t })}
  }
}`
    : ""
}
}
`),
                          r && a.setAttribute("nonce", r),
                          a
                        );
                      })(e)
                    );
                }
                return H;
              },
              W = async (t, n, r) => {
                let a = (0, g.s3)(),
                  i = a && a.getIntegrationByName(t);
                if (i) return i;
                let o = (n && n()) || (await e(r, h)),
                  s = o();
                return a && a.addIntegration(s), s;
              },
              G = async (e) => {
                let r =
                    e.enableScreenshot &&
                    !(
                      /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
                        aU.userAgent
                      ) ||
                      (/Macintosh/i.test(aU.userAgent) &&
                        aU.maxTouchPoints &&
                        aU.maxTouchPoints > 1)
                    ) &&
                    !!isSecureContext,
                  [a, i] = await Promise.all([
                    W("FeedbackModal", t, "feedbackModalIntegration"),
                    r
                      ? W(
                          "FeedbackScreenshot",
                          n,
                          "feedbackScreenshotIntegration"
                        )
                      : void 0,
                  ]);
                if (!a)
                  throw Error("[Feedback] Missing feedback modal integration!");
                let o = a.createDialog({
                  options: {
                    ...e,
                    onFormClose: () => {
                      o && o.close(), e.onFormClose && e.onFormClose();
                    },
                    onFormSubmitted: () => {
                      o && o.close(), e.onFormSubmitted && e.onFormSubmitted();
                    },
                  },
                  screenshotIntegration: r ? i : void 0,
                  sendFeedback: aH,
                  shadow: B(e),
                });
                return o;
              },
              q = (e, t = {}) => {
                let n = aX(j, t),
                  r =
                    "string" == typeof e
                      ? aF.querySelector(e)
                      : "function" == typeof e.addEventListener
                      ? e
                      : null;
                if (!r) throw Error("Unable to attach to target element");
                let a = null,
                  i = async () => {
                    a ||
                      (a = await G({
                        ...n,
                        onFormSubmitted: () => {
                          a && a.removeFromDom(),
                            n.onFormSubmitted && n.onFormSubmitted();
                        },
                      })),
                      a.appendToDom(),
                      a.open();
                  };
                r.addEventListener("click", i);
                let o = () => {
                  (X = X.filter((e) => e !== o)),
                    a && a.removeFromDom(),
                    (a = null),
                    r.removeEventListener("click", i);
                };
                return X.push(o), o;
              },
              Z = (e = {}) => {
                let t = aX(j, e),
                  n = B(t),
                  r = (function ({
                    triggerLabel: e,
                    triggerAriaLabel: t,
                    shadow: n,
                    styleNonce: r,
                  }) {
                    let a = aF.createElement("button");
                    if (
                      ((a.type = "button"),
                      (a.className = "widget__actor"),
                      (a.ariaHidden = "false"),
                      (a.ariaLabel = t || e || aj),
                      a.appendChild(
                        (function () {
                          let e = (e) =>
                              a$.document.createElementNS(
                                "http://www.w3.org/2000/svg",
                                e
                              ),
                            t = aB(e("svg"), {
                              width: "20",
                              height: "20",
                              viewBox: "0 0 20 20",
                              fill: "var(--actor-color, var(--foreground))",
                            }),
                            n = aB(e("g"), { clipPath: "url(#clip0_57_80)" }),
                            r = aB(e("path"), {
                              "fill-rule": "evenodd",
                              "clip-rule": "evenodd",
                              d: "M15.6622 15H12.3997C12.2129 14.9959 12.031 14.9396 11.8747 14.8375L8.04965 12.2H7.49956V19.1C7.4875 19.3348 7.3888 19.5568 7.22256 19.723C7.05632 19.8892 6.83435 19.9879 6.59956 20H2.04956C1.80193 19.9968 1.56535 19.8969 1.39023 19.7218C1.21511 19.5467 1.1153 19.3101 1.11206 19.0625V12.2H0.949652C0.824431 12.2017 0.700142 12.1783 0.584123 12.1311C0.468104 12.084 0.362708 12.014 0.274155 11.9255C0.185602 11.8369 0.115689 11.7315 0.0685419 11.6155C0.0213952 11.4995 -0.00202913 11.3752 -0.00034808 11.25V3.75C-0.00900498 3.62067 0.0092504 3.49095 0.0532651 3.36904C0.0972798 3.24712 0.166097 3.13566 0.255372 3.04168C0.344646 2.94771 0.452437 2.87327 0.571937 2.82307C0.691437 2.77286 0.82005 2.74798 0.949652 2.75H8.04965L11.8747 0.1625C12.031 0.0603649 12.2129 0.00407221 12.3997 0H15.6622C15.9098 0.00323746 16.1464 0.103049 16.3215 0.278167C16.4966 0.453286 16.5964 0.689866 16.5997 0.9375V3.25269C17.3969 3.42959 18.1345 3.83026 18.7211 4.41679C19.5322 5.22788 19.9878 6.32796 19.9878 7.47502C19.9878 8.62209 19.5322 9.72217 18.7211 10.5333C18.1345 11.1198 17.3969 11.5205 16.5997 11.6974V14.0125C16.6047 14.1393 16.5842 14.2659 16.5395 14.3847C16.4948 14.5035 16.4268 14.6121 16.3394 14.7042C16.252 14.7962 16.147 14.8698 16.0307 14.9206C15.9144 14.9714 15.7891 14.9984 15.6622 15ZM1.89695 10.325H1.88715V4.625H8.33715C8.52423 4.62301 8.70666 4.56654 8.86215 4.4625L12.6872 1.875H14.7247V13.125H12.6872L8.86215 10.4875C8.70666 10.3835 8.52423 10.327 8.33715 10.325H2.20217C2.15205 10.3167 2.10102 10.3125 2.04956 10.3125C1.9981 10.3125 1.94708 10.3167 1.89695 10.325ZM2.98706 12.2V18.1625H5.66206V12.2H2.98706ZM16.5997 9.93612V5.01393C16.6536 5.02355 16.7072 5.03495 16.7605 5.04814C17.1202 5.13709 17.4556 5.30487 17.7425 5.53934C18.0293 5.77381 18.2605 6.06912 18.4192 6.40389C18.578 6.73866 18.6603 7.10452 18.6603 7.47502C18.6603 7.84552 18.578 8.21139 18.4192 8.54616C18.2605 8.88093 18.0293 9.17624 17.7425 9.41071C17.4556 9.64518 17.1202 9.81296 16.7605 9.90191C16.7072 9.91509 16.6536 9.9265 16.5997 9.93612Z",
                            });
                          t.appendChild(n).appendChild(r);
                          let a = e("defs"),
                            i = aB(e("clipPath"), { id: "clip0_57_80" }),
                            o = aB(e("rect"), {
                              width: "20",
                              height: "20",
                              fill: "white",
                            });
                          return (
                            i.appendChild(o),
                            a.appendChild(i),
                            t.appendChild(a).appendChild(i).appendChild(o),
                            t
                          );
                        })()
                      ),
                      e)
                    ) {
                      let t = aF.createElement("span");
                      t.appendChild(aF.createTextNode(e)), a.appendChild(t);
                    }
                    let i = (function (e) {
                      let t = aF.createElement("style");
                      return (
                        (t.textContent = `
.widget__actor {
  position: fixed;
  z-index: var(--z-index);
  margin: var(--page-margin);
  inset: var(--actor-inset);

  display: flex;
  align-items: center;
  gap: 8px;
  padding: 16px;

  font-family: inherit;
  font-size: var(--font-size);
  font-weight: 600;
  line-height: 1.14em;
  text-decoration: none;

  background: var(--actor-background, var(--background));
  border-radius: var(--actor-border-radius, 1.7em/50%);
  border: var(--actor-border, var(--border));
  box-shadow: var(--actor-box-shadow, var(--box-shadow));
  color: var(--actor-color, var(--foreground));
  fill: var(--actor-color, var(--foreground));
  cursor: pointer;
  opacity: 1;
  transition: transform 0.2s ease-in-out;
  transform: translate(0, 0) scale(1);
}
.widget__actor[aria-hidden="true"] {
  opacity: 0;
  pointer-events: none;
  visibility: hidden;
  transform: translate(0, 16px) scale(0.98);
}

.widget__actor:hover {
  background: var(--actor-hover-background, var(--background));
  filter: var(--interactive-filter);
}

.widget__actor svg {
  width: 1.14em;
  height: 1.14em;
}

@media (max-width: 600px) {
  .widget__actor span {
    display: none;
  }
}
`),
                        e && t.setAttribute("nonce", e),
                        t
                      );
                    })(r);
                    return {
                      el: a,
                      appendToDom() {
                        n.appendChild(i), n.appendChild(a);
                      },
                      removeFromDom() {
                        n.removeChild(a), n.removeChild(i);
                      },
                      show() {
                        a.ariaHidden = "false";
                      },
                      hide() {
                        a.ariaHidden = "true";
                      },
                    };
                  })({
                    triggerLabel: t.triggerLabel,
                    triggerAriaLabel: t.triggerAriaLabel,
                    shadow: n,
                    styleNonce: f,
                  });
                return (
                  q(r.el, {
                    ...t,
                    onFormOpen() {
                      r.hide();
                    },
                    onFormClose() {
                      r.show();
                    },
                    onFormSubmitted() {
                      r.show();
                    },
                  }),
                  r
                );
              };
            return {
              name: "Feedback",
              setupOnce() {
                (0, aO.j)() &&
                  j.autoInject &&
                  ("loading" === aF.readyState
                    ? aF.addEventListener("DOMContentLoaded", () =>
                        Z().appendToDom()
                      )
                    : Z().appendToDom());
              },
              attachTo: q,
              createWidget(e = {}) {
                let t = Z(aX(j, e));
                return t.appendToDom(), t;
              },
              createForm: async (e = {}) => G(aX(j, e)),
              remove() {
                H && (H.parentElement && H.parentElement.remove(), (H = null)),
                  X.forEach((e) => e()),
                  (X = []);
              },
            };
          };
          return r;
        };
        function aY() {
          let e = (0, g.s3)();
          return e && e.getIntegrationByName("Feedback");
        }
        var az,
          aJ,
          aK,
          aQ,
          a0,
          a1,
          a3,
          a2,
          a4,
          a5,
          a6 = {},
          a9 = [],
          a7 =
            /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
          a8 = Array.isArray;
        function ie(e, t) {
          for (var n in t) e[n] = t[n];
          return e;
        }
        function it(e) {
          var t = e.parentNode;
          t && t.removeChild(e);
        }
        function ir(e, t, n) {
          var r,
            a,
            i,
            o = {};
          for (i in t)
            "key" == i ? (r = t[i]) : "ref" == i ? (a = t[i]) : (o[i] = t[i]);
          if (
            (arguments.length > 2 &&
              (o.children = arguments.length > 3 ? aQ.call(arguments, 2) : n),
            "function" == typeof e && null != e.defaultProps)
          )
            for (i in e.defaultProps)
              void 0 === o[i] && (o[i] = e.defaultProps[i]);
          return ia(e, o, r, a, null);
        }
        function ia(e, t, n, r, a) {
          var i = {
            type: e,
            props: t,
            key: n,
            ref: r,
            __k: null,
            __: null,
            __b: 0,
            __e: null,
            __d: void 0,
            __c: null,
            constructor: void 0,
            __v: null == a ? ++a1 : a,
            __i: -1,
            __u: 0,
          };
          return null == a && null != a0.vnode && a0.vnode(i), i;
        }
        function ii(e) {
          return e.children;
        }
        function io(e, t) {
          (this.props = e), (this.context = t);
        }
        function is(e, t) {
          if (null == t) return e.__ ? is(e.__, e.__i + 1) : null;
          for (var n; t < e.__k.length; t++)
            if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
          return "function" == typeof e.type ? is(e) : null;
        }
        function il(e) {
          ((!e.__d && (e.__d = !0) && a3.push(e) && !iu.__r++) ||
            a2 !== a0.debounceRendering) &&
            ((a2 = a0.debounceRendering) || a4)(iu);
        }
        function iu() {
          var e,
            t,
            n,
            r = [],
            a = [];
          for (a3.sort(a5); (e = a3.shift()); )
            e.__d &&
              ((n = a3.length),
              (t =
                (function (e, t, n) {
                  var r,
                    a = e.__v,
                    i = a.__e,
                    o = e.__P;
                  if (o)
                    return (
                      ((r = ie({}, a)).__v = a.__v + 1),
                      a0.vnode && a0.vnode(r),
                      i_(
                        o,
                        r,
                        a,
                        e.__n,
                        void 0 !== o.ownerSVGElement,
                        32 & a.__u ? [i] : null,
                        t,
                        null == i ? is(a) : i,
                        !!(32 & a.__u),
                        n
                      ),
                      (r.__.__k[r.__i] = r),
                      (r.__d = void 0),
                      r.__e != i &&
                        (function e(t) {
                          var n, r;
                          if (null != (t = t.__) && null != t.__c) {
                            for (
                              t.__e = t.__c.base = null, n = 0;
                              n < t.__k.length;
                              n++
                            )
                              if (null != (r = t.__k[n]) && null != r.__e) {
                                t.__e = t.__c.base = r.__e;
                                break;
                              }
                            return e(t);
                          }
                        })(r),
                      r
                    );
                })(e, r, a) || t),
              0 === n || a3.length > n
                ? (ig(r, t, a),
                  (a.length = r.length = 0),
                  (t = void 0),
                  a3.sort(a5))
                : t && a0.__c && a0.__c(t, a9));
          t && ig(r, t, a), (iu.__r = 0);
        }
        function ic(e, t, n, r, a, i, o, s, l, u, c) {
          var d,
            p,
            f,
            h,
            m,
            _ = (r && r.__k) || a9,
            g = t.length;
          for (
            n.__d = l,
              (function (e, t, n) {
                var r,
                  a,
                  i,
                  o,
                  s,
                  l = t.length,
                  u = n.length,
                  c = u,
                  d = 0;
                for (e.__k = [], r = 0; r < l; r++)
                  null !=
                  (a = e.__k[r] =
                    null == (a = t[r]) ||
                    "boolean" == typeof a ||
                    "function" == typeof a
                      ? null
                      : "string" == typeof a ||
                        "number" == typeof a ||
                        "bigint" == typeof a ||
                        a.constructor == String
                      ? ia(null, a, null, null, a)
                      : a8(a)
                      ? ia(ii, { children: a }, null, null, null)
                      : void 0 === a.constructor && a.__b > 0
                      ? ia(a.type, a.props, a.key, a.ref ? a.ref : null, a.__v)
                      : a)
                    ? ((a.__ = e),
                      (a.__b = e.__b + 1),
                      (s = (function (e, t, n, r) {
                        var a = e.key,
                          i = e.type,
                          o = n - 1,
                          s = n + 1,
                          l = t[n];
                        if (null === l || (l && a == l.key && i === l.type))
                          return n;
                        if (r > (null != l && 0 == (131072 & l.__u) ? 1 : 0))
                          for (; o >= 0 || s < t.length; ) {
                            if (o >= 0) {
                              if (
                                (l = t[o]) &&
                                0 == (131072 & l.__u) &&
                                a == l.key &&
                                i === l.type
                              )
                                return o;
                              o--;
                            }
                            if (s < t.length) {
                              if (
                                (l = t[s]) &&
                                0 == (131072 & l.__u) &&
                                a == l.key &&
                                i === l.type
                              )
                                return s;
                              s++;
                            }
                          }
                        return -1;
                      })(a, n, (o = r + d), c)),
                      (a.__i = s),
                      (i = null),
                      -1 !== s && (c--, (i = n[s]) && (i.__u |= 131072)),
                      null == i || null === i.__v
                        ? (-1 == s && d--,
                          "function" != typeof a.type && (a.__u |= 65536))
                        : s !== o &&
                          (s === o + 1
                            ? d++
                            : s > o
                            ? c > l - o
                              ? (d += s - o)
                              : d--
                            : (d = s < o && s == o - 1 ? s - o : 0),
                          s !== r + d && (a.__u |= 65536)))
                    : (i = n[r]) &&
                      null == i.key &&
                      i.__e &&
                      (i.__e == e.__d && (e.__d = is(i)),
                      iy(i, i, !1),
                      (n[r] = null),
                      c--);
                if (c)
                  for (r = 0; r < u; r++)
                    null != (i = n[r]) &&
                      0 == (131072 & i.__u) &&
                      (i.__e == e.__d && (e.__d = is(i)), iy(i, i));
              })(n, t, _),
              l = n.__d,
              d = 0;
            d < g;
            d++
          )
            null != (f = n.__k[d]) &&
              "boolean" != typeof f &&
              "function" != typeof f &&
              ((p = -1 === f.__i ? a6 : _[f.__i] || a6),
              (f.__i = d),
              i_(e, f, p, a, i, o, s, l, u, c),
              (h = f.__e),
              f.ref &&
                p.ref != f.ref &&
                (p.ref && iv(p.ref, null, f), c.push(f.ref, f.__c || h, f)),
              null == m && null != h && (m = h),
              65536 & f.__u || p.__k === f.__k
                ? (l = (function e(t, n, r) {
                    var a, i;
                    if ("function" == typeof t.type) {
                      for (a = t.__k, i = 0; a && i < a.length; i++)
                        a[i] && ((a[i].__ = t), (n = e(a[i], n, r)));
                      return n;
                    }
                    t.__e != n &&
                      (r.insertBefore(t.__e, n || null), (n = t.__e));
                    do n = n && n.nextSibling;
                    while (null != n && 8 === n.nodeType);
                    return n;
                  })(f, l, e))
                : "function" == typeof f.type && void 0 !== f.__d
                ? (l = f.__d)
                : h && (l = h.nextSibling),
              (f.__d = void 0),
              (f.__u &= -196609));
          (n.__d = l), (n.__e = m);
        }
        function id(e, t, n) {
          "-" === t[0]
            ? e.setProperty(t, null == n ? "" : n)
            : (e[t] =
                null == n
                  ? ""
                  : "number" != typeof n || a7.test(t)
                  ? n
                  : n + "px");
        }
        function ip(e, t, n, r, a) {
          var i;
          e: if ("style" === t) {
            if ("string" == typeof n) e.style.cssText = n;
            else {
              if (("string" == typeof r && (e.style.cssText = r = ""), r))
                for (t in r) (n && t in n) || id(e.style, t, "");
              if (n) for (t in n) (r && n[t] === r[t]) || id(e.style, t, n[t]);
            }
          } else if ("o" === t[0] && "n" === t[1])
            (i = t !== (t = t.replace(/(PointerCapture)$|Capture$/i, "$1"))),
              (t =
                t.toLowerCase() in e ? t.toLowerCase().slice(2) : t.slice(2)),
              e.l || (e.l = {}),
              (e.l[t + i] = n),
              n
                ? r
                  ? (n.u = r.u)
                  : ((n.u = Date.now()), e.addEventListener(t, i ? im : ih, i))
                : e.removeEventListener(t, i ? im : ih, i);
          else {
            if (a) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
            else if (
              "width" !== t &&
              "height" !== t &&
              "href" !== t &&
              "list" !== t &&
              "form" !== t &&
              "tabIndex" !== t &&
              "download" !== t &&
              "rowSpan" !== t &&
              "colSpan" !== t &&
              "role" !== t &&
              t in e
            )
              try {
                e[t] = null == n ? "" : n;
                break e;
              } catch (e) {}
            "function" == typeof n ||
              (null == n || (!1 === n && "-" !== t[4])
                ? e.removeAttribute(t)
                : e.setAttribute(t, n));
          }
        }
        function ih(e) {
          if (this.l) {
            var t = this.l[e.type + !1];
            if (e.t) {
              if (e.t <= t.u) return;
            } else e.t = Date.now();
            return t(a0.event ? a0.event(e) : e);
          }
        }
        function im(e) {
          if (this.l) return this.l[e.type + !0](a0.event ? a0.event(e) : e);
        }
        function i_(e, t, n, r, a, i, o, s, l, u) {
          var c,
            d,
            p,
            f,
            h,
            m,
            _,
            g,
            v,
            y,
            b,
            E,
            S,
            w,
            T,
            x = t.type;
          if (void 0 !== t.constructor) return null;
          128 & n.__u && ((l = !!(32 & n.__u)), (i = [(s = t.__e = n.__e)])),
            (c = a0.__b) && c(t);
          e: if ("function" == typeof x)
            try {
              if (
                ((g = t.props),
                (v = (c = x.contextType) && r[c.__c]),
                (y = c ? (v ? v.props.value : c.__) : r),
                n.__c
                  ? (_ = (d = t.__c = n.__c).__ = d.__E)
                  : ("prototype" in x && x.prototype.render
                      ? (t.__c = d = new x(g, y))
                      : ((t.__c = d = new io(g, y)),
                        (d.constructor = x),
                        (d.render = ib)),
                    v && v.sub(d),
                    (d.props = g),
                    d.state || (d.state = {}),
                    (d.context = y),
                    (d.__n = r),
                    (p = d.__d = !0),
                    (d.__h = []),
                    (d._sb = [])),
                null == d.__s && (d.__s = d.state),
                null != x.getDerivedStateFromProps &&
                  (d.__s == d.state && (d.__s = ie({}, d.__s)),
                  ie(d.__s, x.getDerivedStateFromProps(g, d.__s))),
                (f = d.props),
                (h = d.state),
                (d.__v = t),
                p)
              )
                null == x.getDerivedStateFromProps &&
                  null != d.componentWillMount &&
                  d.componentWillMount(),
                  null != d.componentDidMount &&
                    d.__h.push(d.componentDidMount);
              else {
                if (
                  (null == x.getDerivedStateFromProps &&
                    g !== f &&
                    null != d.componentWillReceiveProps &&
                    d.componentWillReceiveProps(g, y),
                  !d.__e &&
                    ((null != d.shouldComponentUpdate &&
                      !1 === d.shouldComponentUpdate(g, d.__s, y)) ||
                      t.__v === n.__v))
                ) {
                  for (
                    t.__v !== n.__v &&
                      ((d.props = g), (d.state = d.__s), (d.__d = !1)),
                      t.__e = n.__e,
                      t.__k = n.__k,
                      t.__k.forEach(function (e) {
                        e && (e.__ = t);
                      }),
                      b = 0;
                    b < d._sb.length;
                    b++
                  )
                    d.__h.push(d._sb[b]);
                  (d._sb = []), d.__h.length && o.push(d);
                  break e;
                }
                null != d.componentWillUpdate &&
                  d.componentWillUpdate(g, d.__s, y),
                  null != d.componentDidUpdate &&
                    d.__h.push(function () {
                      d.componentDidUpdate(f, h, m);
                    });
              }
              if (
                ((d.context = y),
                (d.props = g),
                (d.__P = e),
                (d.__e = !1),
                (E = a0.__r),
                (S = 0),
                "prototype" in x && x.prototype.render)
              ) {
                for (
                  d.state = d.__s,
                    d.__d = !1,
                    E && E(t),
                    c = d.render(d.props, d.state, d.context),
                    w = 0;
                  w < d._sb.length;
                  w++
                )
                  d.__h.push(d._sb[w]);
                d._sb = [];
              } else
                do
                  (d.__d = !1),
                    E && E(t),
                    (c = d.render(d.props, d.state, d.context)),
                    (d.state = d.__s);
                while (d.__d && ++S < 25);
              (d.state = d.__s),
                null != d.getChildContext &&
                  (r = ie(ie({}, r), d.getChildContext())),
                p ||
                  null == d.getSnapshotBeforeUpdate ||
                  (m = d.getSnapshotBeforeUpdate(f, h)),
                ic(
                  e,
                  a8(
                    (T =
                      null != c && c.type === ii && null == c.key
                        ? c.props.children
                        : c)
                  )
                    ? T
                    : [T],
                  t,
                  n,
                  r,
                  a,
                  i,
                  o,
                  s,
                  l,
                  u
                ),
                (d.base = t.__e),
                (t.__u &= -161),
                d.__h.length && o.push(d),
                _ && (d.__E = d.__ = null);
            } catch (e) {
              (t.__v = null),
                l || null != i
                  ? ((t.__e = s),
                    (t.__u |= l ? 160 : 32),
                    (i[i.indexOf(s)] = null))
                  : ((t.__e = n.__e), (t.__k = n.__k)),
                a0.__e(e, t, n);
            }
          else
            null == i && t.__v === n.__v
              ? ((t.__k = n.__k), (t.__e = n.__e))
              : (t.__e = (function (e, t, n, r, a, i, o, s, l) {
                  var u,
                    c,
                    d,
                    p,
                    f,
                    h,
                    m,
                    _ = n.props,
                    g = t.props,
                    v = t.type;
                  if (("svg" === v && (a = !0), null != i)) {
                    for (u = 0; u < i.length; u++)
                      if (
                        (f = i[u]) &&
                        "setAttribute" in f == !!v &&
                        (v ? f.localName === v : 3 === f.nodeType)
                      ) {
                        (e = f), (i[u] = null);
                        break;
                      }
                  }
                  if (null == e) {
                    if (null === v) return document.createTextNode(g);
                    (e = a
                      ? document.createElementNS(
                          "http://www.w3.org/2000/svg",
                          v
                        )
                      : document.createElement(v, g.is && g)),
                      (i = null),
                      (s = !1);
                  }
                  if (null === v)
                    _ === g || (s && e.data === g) || (e.data = g);
                  else {
                    if (
                      ((i = i && aQ.call(e.childNodes)),
                      (_ = n.props || a6),
                      !s && null != i)
                    )
                      for (_ = {}, u = 0; u < e.attributes.length; u++)
                        _[(f = e.attributes[u]).name] = f.value;
                    for (u in _)
                      (f = _[u]),
                        "children" == u ||
                          ("dangerouslySetInnerHTML" == u
                            ? (d = f)
                            : "key" === u || u in g || ip(e, u, null, f, a));
                    for (u in g)
                      (f = g[u]),
                        "children" == u
                          ? (p = f)
                          : "dangerouslySetInnerHTML" == u
                          ? (c = f)
                          : "value" == u
                          ? (h = f)
                          : "checked" == u
                          ? (m = f)
                          : "key" === u ||
                            (s && "function" != typeof f) ||
                            _[u] === f ||
                            ip(e, u, f, _[u], a);
                    if (c)
                      s ||
                        (d &&
                          (c.__html === d.__html ||
                            c.__html === e.innerHTML)) ||
                        (e.innerHTML = c.__html),
                        (t.__k = []);
                    else if (
                      (d && (e.innerHTML = ""),
                      ic(
                        e,
                        a8(p) ? p : [p],
                        t,
                        n,
                        r,
                        a && "foreignObject" !== v,
                        i,
                        o,
                        i ? i[0] : n.__k && is(n, 0),
                        s,
                        l
                      ),
                      null != i)
                    )
                      for (u = i.length; u--; ) null != i[u] && it(i[u]);
                    s ||
                      ((u = "value"),
                      void 0 === h ||
                        (h === e[u] &&
                          ("progress" !== v || h) &&
                          ("option" !== v || h === _[u])) ||
                        ip(e, u, h, _[u], !1),
                      (u = "checked"),
                      void 0 !== m && m !== e[u] && ip(e, u, m, _[u], !1));
                  }
                  return e;
                })(n.__e, t, n, r, a, i, o, l, u));
          (c = a0.diffed) && c(t);
        }
        function ig(e, t, n) {
          for (var r = 0; r < n.length; r++) iv(n[r], n[++r], n[++r]);
          a0.__c && a0.__c(t, e),
            e.some(function (t) {
              try {
                (e = t.__h),
                  (t.__h = []),
                  e.some(function (e) {
                    e.call(t);
                  });
              } catch (e) {
                a0.__e(e, t.__v);
              }
            });
        }
        function iv(e, t, n) {
          try {
            "function" == typeof e ? e(t) : (e.current = t);
          } catch (e) {
            a0.__e(e, n);
          }
        }
        function iy(e, t, n) {
          var r, a;
          if (
            (a0.unmount && a0.unmount(e),
            (r = e.ref) &&
              ((r.current && r.current !== e.__e) || iv(r, null, t)),
            null != (r = e.__c))
          ) {
            if (r.componentWillUnmount)
              try {
                r.componentWillUnmount();
              } catch (e) {
                a0.__e(e, t);
              }
            (r.base = r.__P = null), (e.__c = void 0);
          }
          if ((r = e.__k))
            for (a = 0; a < r.length; a++)
              r[a] && iy(r[a], t, n || "function" != typeof e.type);
          n || null == e.__e || it(e.__e), (e.__ = e.__e = e.__d = void 0);
        }
        function ib(e, t, n) {
          return this.constructor(e, n);
        }
        (aQ = a9.slice),
          (a0 = {
            __e: function (e, t, n, r) {
              for (var a, i, o; (t = t.__); )
                if ((a = t.__c) && !a.__)
                  try {
                    if (
                      ((i = a.constructor) &&
                        null != i.getDerivedStateFromError &&
                        (a.setState(i.getDerivedStateFromError(e)),
                        (o = a.__d)),
                      null != a.componentDidCatch &&
                        (a.componentDidCatch(e, r || {}), (o = a.__d)),
                      o)
                    )
                      return (a.__E = a);
                  } catch (t) {
                    e = t;
                  }
              throw e;
            },
          }),
          (a1 = 0),
          (io.prototype.setState = function (e, t) {
            var n;
            (n =
              null != this.__s && this.__s !== this.state
                ? this.__s
                : (this.__s = ie({}, this.state))),
              "function" == typeof e && (e = e(ie({}, n), this.props)),
              e && ie(n, e),
              null != e && this.__v && (t && this._sb.push(t), il(this));
          }),
          (io.prototype.forceUpdate = function (e) {
            this.__v && ((this.__e = !0), e && this.__h.push(e), il(this));
          }),
          (io.prototype.render = ii),
          (a3 = []),
          (a4 =
            "function" == typeof Promise
              ? Promise.prototype.then.bind(Promise.resolve())
              : setTimeout),
          (a5 = function (e, t) {
            return e.__v.__b - t.__v.__b;
          }),
          (iu.__r = 0);
        var iE,
          iS,
          iw,
          iT,
          ix = 0,
          ik = [],
          iI = [],
          iC = a0,
          iA = iC.__b,
          iR = iC.__r,
          iN = iC.diffed,
          iP = iC.__c,
          iM = iC.unmount,
          iL = iC.__;
        function iD(e, t) {
          iC.__h && iC.__h(iS, e, ix || t), (ix = 0);
          var n = iS.__H || (iS.__H = { __: [], __h: [] });
          return e >= n.__.length && n.__.push({ __V: iI }), n.__[e];
        }
        function iO(e) {
          return (ix = 1), i$(iZ, e);
        }
        function i$(e, t, n) {
          var r = iD(iE++, 2);
          if (
            ((r.t = e),
            !r.__c &&
              ((r.__ = [
                n ? n(t) : iZ(void 0, t),
                function (e) {
                  var t = r.__N ? r.__N[0] : r.__[0],
                    n = r.t(t, e);
                  t !== n && ((r.__N = [n, r.__[1]]), r.__c.setState({}));
                },
              ]),
              (r.__c = iS),
              !iS.u))
          ) {
            var a = function (e, t, n) {
              if (!r.__c.__H) return !0;
              var a = r.__c.__H.__.filter(function (e) {
                return !!e.__c;
              });
              if (
                a.every(function (e) {
                  return !e.__N;
                })
              )
                return !i || i.call(this, e, t, n);
              var o = !1;
              return (
                a.forEach(function (e) {
                  if (e.__N) {
                    var t = e.__[0];
                    (e.__ = e.__N), (e.__N = void 0), t !== e.__[0] && (o = !0);
                  }
                }),
                !(!o && r.__c.props === e) && (!i || i.call(this, e, t, n))
              );
            };
            iS.u = !0;
            var i = iS.shouldComponentUpdate,
              o = iS.componentWillUpdate;
            (iS.componentWillUpdate = function (e, t, n) {
              if (this.__e) {
                var r = i;
                (i = void 0), a(e, t, n), (i = r);
              }
              o && o.call(this, e, t, n);
            }),
              (iS.shouldComponentUpdate = a);
          }
          return r.__N || r.__;
        }
        function iF(e, t) {
          var n = iD(iE++, 4);
          !iC.__s && iq(n.__H, t) && ((n.__ = e), (n.i = t), iS.__h.push(n));
        }
        function iU(e, t) {
          var n = iD(iE++, 7);
          return iq(n.__H, t)
            ? ((n.__V = e()), (n.i = t), (n.__h = e), n.__V)
            : n.__;
        }
        function ij(e, t) {
          return (
            (ix = 8),
            iU(function () {
              return e;
            }, t)
          );
        }
        function iH() {
          for (var e; (e = ik.shift()); )
            if (e.__P && e.__H)
              try {
                e.__H.__h.forEach(iW), e.__H.__h.forEach(iG), (e.__H.__h = []);
              } catch (t) {
                (e.__H.__h = []), iC.__e(t, e.__v);
              }
        }
        (iC.__b = function (e) {
          (iS = null), iA && iA(e);
        }),
          (iC.__ = function (e, t) {
            t.__k && t.__k.__m && (e.__m = t.__k.__m), iL && iL(e, t);
          }),
          (iC.__r = function (e) {
            iR && iR(e), (iE = 0);
            var t = (iS = e.__c).__H;
            t &&
              (iw === iS
                ? ((t.__h = []),
                  (iS.__h = []),
                  t.__.forEach(function (e) {
                    e.__N && (e.__ = e.__N),
                      (e.__V = iI),
                      (e.__N = e.i = void 0);
                  }))
                : (t.__h.forEach(iW),
                  t.__h.forEach(iG),
                  (t.__h = []),
                  (iE = 0))),
              (iw = iS);
          }),
          (iC.diffed = function (e) {
            iN && iN(e);
            var t = e.__c;
            t &&
              t.__H &&
              (t.__H.__h.length &&
                ((1 !== ik.push(t) && iT === iC.requestAnimationFrame) ||
                  ((iT = iC.requestAnimationFrame) || iB)(iH)),
              t.__H.__.forEach(function (e) {
                e.i && (e.__H = e.i),
                  e.__V !== iI && (e.__ = e.__V),
                  (e.i = void 0),
                  (e.__V = iI);
              })),
              (iw = iS = null);
          }),
          (iC.__c = function (e, t) {
            t.some(function (e) {
              try {
                e.__h.forEach(iW),
                  (e.__h = e.__h.filter(function (e) {
                    return !e.__ || iG(e);
                  }));
              } catch (n) {
                t.some(function (e) {
                  e.__h && (e.__h = []);
                }),
                  (t = []),
                  iC.__e(n, e.__v);
              }
            }),
              iP && iP(e, t);
          }),
          (iC.unmount = function (e) {
            iM && iM(e);
            var t,
              n = e.__c;
            n &&
              n.__H &&
              (n.__H.__.forEach(function (e) {
                try {
                  iW(e);
                } catch (e) {
                  t = e;
                }
              }),
              (n.__H = void 0),
              t && iC.__e(t, n.__v));
          });
        var iX = "function" == typeof requestAnimationFrame;
        function iB(e) {
          var t,
            n = function () {
              clearTimeout(r), iX && cancelAnimationFrame(t), setTimeout(e);
            },
            r = setTimeout(n, 100);
          iX && (t = requestAnimationFrame(n));
        }
        function iW(e) {
          var t = iS,
            n = e.__c;
          "function" == typeof n && ((e.__c = void 0), n()), (iS = t);
        }
        function iG(e) {
          var t = iS;
          (e.__c = e.__()), (iS = t);
        }
        function iq(e, t) {
          return (
            !e ||
            e.length !== t.length ||
            t.some(function (t, n) {
              return t !== e[n];
            })
          );
        }
        function iZ(e, t) {
          return "function" == typeof t ? t(e) : t;
        }
        let iV = {
          __proto__: null,
          useCallback: ij,
          useContext: function (e) {
            var t = iS.context[e.__c],
              n = iD(iE++, 9);
            return (
              (n.c = e),
              t
                ? (null == n.__ && ((n.__ = !0), t.sub(iS)), t.props.value)
                : e.__
            );
          },
          useDebugValue: function (e, t) {
            iC.useDebugValue && iC.useDebugValue(t ? t(e) : e);
          },
          useEffect: function (e, t) {
            var n = iD(iE++, 3);
            !iC.__s &&
              iq(n.__H, t) &&
              ((n.__ = e), (n.i = t), iS.__H.__h.push(n));
          },
          useErrorBoundary: function (e) {
            var t = iD(iE++, 10),
              n = iO();
            return (
              (t.__ = e),
              iS.componentDidCatch ||
                (iS.componentDidCatch = function (e, r) {
                  t.__ && t.__(e, r), n[1](e);
                }),
              [
                n[0],
                function () {
                  n[1](void 0);
                },
              ]
            );
          },
          useId: function () {
            var e = iD(iE++, 11);
            if (!e.__) {
              for (var t = iS.__v; null !== t && !t.__m && null !== t.__; )
                t = t.__;
              var n = t.__m || (t.__m = [0, 0]);
              e.__ = "P" + n[0] + "-" + n[1]++;
            }
            return e.__;
          },
          useImperativeHandle: function (e, t, n) {
            (ix = 6),
              iF(
                function () {
                  return "function" == typeof e
                    ? (e(t()),
                      function () {
                        return e(null);
                      })
                    : e
                    ? ((e.current = t()),
                      function () {
                        return (e.current = null);
                      })
                    : void 0;
                },
                null == n ? n : n.concat(e)
              );
          },
          useLayoutEffect: iF,
          useMemo: iU,
          useReducer: i$,
          useRef: function (e) {
            return (
              (ix = 5),
              iU(function () {
                return { current: e };
              }, [])
            );
          },
          useState: iO,
        };
        function iY({ options: e }) {
          let t = iU(
            () => ({
              __html: (function () {
                let e = (e) =>
                    aF.createElementNS("http://www.w3.org/2000/svg", e),
                  t = aB(e("svg"), {
                    width: "32",
                    height: "30",
                    viewBox: "0 0 72 66",
                    fill: "inherit",
                  }),
                  n = aB(e("path"), {
                    transform: "translate(11, 11)",
                    d: "M29,2.26a4.67,4.67,0,0,0-8,0L14.42,13.53A32.21,32.21,0,0,1,32.17,40.19H27.55A27.68,27.68,0,0,0,12.09,17.47L6,28a15.92,15.92,0,0,1,9.23,12.17H4.62A.76.76,0,0,1,4,39.06l2.94-5a10.74,10.74,0,0,0-3.36-1.9l-2.91,5a4.54,4.54,0,0,0,1.69,6.24A4.66,4.66,0,0,0,4.62,44H19.15a19.4,19.4,0,0,0-8-17.31l2.31-4A23.87,23.87,0,0,1,23.76,44H36.07a35.88,35.88,0,0,0-16.41-31.8l4.67-8a.77.77,0,0,1,1.05-.27c.53.29,20.29,34.77,20.66,35.17a.76.76,0,0,1-.68,1.13H40.6q.09,1.91,0,3.81h4.78A4.59,4.59,0,0,0,50,39.43a4.49,4.49,0,0,0-.62-2.28Z",
                  });
                return t.appendChild(n), t;
              })().outerHTML,
            }),
            []
          );
          return ir(
            "h2",
            { class: "dialog__header" },
            ir("span", { class: "dialog__title" }, e.formTitle),
            e.showBranding
              ? ir("a", {
                  class: "brand-link",
                  target: "_blank",
                  href: "https://sentry.io/welcome/",
                  title: "Powered by Sentry",
                  rel: "noopener noreferrer",
                  dangerouslySetInnerHTML: t,
                })
              : null
          );
        }
        function iz(e, t) {
          let n = e.get(t);
          return "string" == typeof n ? n.trim() : "";
        }
        function iJ({
          options: e,
          defaultEmail: t,
          defaultName: n,
          onFormClose: r,
          onSubmit: a,
          onSubmitSuccess: i,
          onSubmitError: o,
          showEmail: s,
          showName: l,
          screenshotInput: u,
        }) {
          let {
              tags: c,
              addScreenshotButtonLabel: d,
              removeScreenshotButtonLabel: p,
              cancelButtonLabel: f,
              emailLabel: h,
              emailPlaceholder: m,
              isEmailRequired: _,
              isNameRequired: g,
              messageLabel: v,
              messagePlaceholder: y,
              nameLabel: b,
              namePlaceholder: E,
              submitButtonLabel: S,
              isRequiredLabel: w,
            } = e,
            [T, x] = iO(null),
            [k, I] = iO(!1),
            C = u && u.input,
            [A, R] = iO(null),
            N = ij((e) => {
              R(e), I(!1);
            }, []),
            P = ij(
              (e) => {
                let t = (function (e, t) {
                  let n = [];
                  return (
                    t.isNameRequired && !e.name && n.push(t.nameLabel),
                    t.isEmailRequired && !e.email && n.push(t.emailLabel),
                    e.message || n.push(t.messageLabel),
                    n
                  );
                })(e, {
                  emailLabel: h,
                  isEmailRequired: _,
                  isNameRequired: g,
                  messageLabel: v,
                  nameLabel: b,
                });
                return (
                  t.length > 0
                    ? x(
                        `Please enter in the following required fields: ${t.join(
                          ", "
                        )}`
                      )
                    : x(null),
                  0 === t.length
                );
              },
              [h, _, g, v, b]
            ),
            M = ij(
              async (e) => {
                try {
                  if (
                    (e.preventDefault(), !(e.target instanceof HTMLFormElement))
                  )
                    return;
                  let t = new FormData(e.target),
                    n = await (u && k ? u.value() : void 0),
                    r = {
                      name: iz(t, "name"),
                      email: iz(t, "email"),
                      message: iz(t, "message"),
                      attachments: n ? [n] : void 0,
                    };
                  if (!P(r)) return;
                  try {
                    await a(
                      {
                        name: r.name,
                        email: r.email,
                        message: r.message,
                        source: "widget",
                        tags: c,
                      },
                      { attachments: r.attachments }
                    ),
                      i(r);
                  } catch (e) {
                    x(e), o(e);
                  }
                } catch (e) {}
              },
              [u && k, i, o]
            );
          return ir(
            "form",
            { class: "form", onSubmit: M },
            C && k ? ir(C, { onError: N }) : null,
            ir(
              "div",
              { class: "form__right", "data-sentry-feedback": !0 },
              ir(
                "div",
                { class: "form__top" },
                T ? ir("div", { class: "form__error-container" }, T) : null,
                l
                  ? ir(
                      "label",
                      { for: "name", class: "form__label" },
                      ir(iK, { label: b, isRequiredLabel: w, isRequired: g }),
                      ir("input", {
                        class: "form__input",
                        defaultValue: n,
                        id: "name",
                        name: "name",
                        placeholder: E,
                        required: g,
                        type: "text",
                      })
                    )
                  : ir("input", {
                      "aria-hidden": !0,
                      value: n,
                      name: "name",
                      type: "hidden",
                    }),
                s
                  ? ir(
                      "label",
                      { for: "email", class: "form__label" },
                      ir(iK, { label: h, isRequiredLabel: w, isRequired: _ }),
                      ir("input", {
                        class: "form__input",
                        defaultValue: t,
                        id: "email",
                        name: "email",
                        placeholder: m,
                        required: _,
                        type: "email",
                      })
                    )
                  : ir("input", {
                      "aria-hidden": !0,
                      value: t,
                      name: "email",
                      type: "hidden",
                    }),
                ir(
                  "label",
                  { for: "message", class: "form__label" },
                  ir(iK, { label: v, isRequiredLabel: w, isRequired: !0 }),
                  ir("textarea", {
                    autoFocus: !0,
                    class: "form__input form__input--textarea",
                    id: "message",
                    name: "message",
                    placeholder: y,
                    required: !0,
                    rows: 5,
                  })
                ),
                C
                  ? ir(
                      "label",
                      { for: "screenshot", class: "form__label" },
                      ir(
                        "button",
                        {
                          class: "btn btn--default",
                          type: "button",
                          onClick: () => {
                            R(null), I((e) => !e);
                          },
                        },
                        k ? p : d
                      ),
                      A
                        ? ir(
                            "div",
                            { class: "form__error-container" },
                            A.message
                          )
                        : null
                    )
                  : null
              ),
              ir(
                "div",
                { class: "btn-group" },
                ir("button", { class: "btn btn--primary", type: "submit" }, S),
                ir(
                  "button",
                  { class: "btn btn--default", type: "button", onClick: r },
                  f
                )
              )
            )
          );
        }
        function iK({ label: e, isRequired: t, isRequiredLabel: n }) {
          return ir(
            "span",
            { class: "form__label__text" },
            e,
            t && ir("span", { class: "form__label__text--required" }, n)
          );
        }
        function iQ({ open: e, onFormSubmitted: t, ...n }) {
          let r = n.options,
            a = iU(
              () => ({
                __html: (function () {
                  let e = (e) =>
                      a$.document.createElementNS(
                        "http://www.w3.org/2000/svg",
                        e
                      ),
                    t = aB(e("svg"), {
                      width: "16",
                      height: "17",
                      viewBox: "0 0 16 17",
                      fill: "inherit",
                    }),
                    n = aB(e("g"), { clipPath: "url(#clip0_57_156)" }),
                    r = aB(e("path"), {
                      "fill-rule": "evenodd",
                      "clip-rule": "evenodd",
                      d: "M3.55544 15.1518C4.87103 16.0308 6.41775 16.5 8 16.5C10.1217 16.5 12.1566 15.6571 13.6569 14.1569C15.1571 12.6566 16 10.6217 16 8.5C16 6.91775 15.5308 5.37103 14.6518 4.05544C13.7727 2.73985 12.5233 1.71447 11.0615 1.10897C9.59966 0.503466 7.99113 0.34504 6.43928 0.653721C4.88743 0.962403 3.46197 1.72433 2.34315 2.84315C1.22433 3.96197 0.462403 5.38743 0.153721 6.93928C-0.15496 8.49113 0.00346625 10.0997 0.608967 11.5615C1.21447 13.0233 2.23985 14.2727 3.55544 15.1518ZM4.40546 3.1204C5.46945 2.40946 6.72036 2.03 8 2.03C9.71595 2.03 11.3616 2.71166 12.575 3.92502C13.7883 5.13838 14.47 6.78405 14.47 8.5C14.47 9.77965 14.0905 11.0306 13.3796 12.0945C12.6687 13.1585 11.6582 13.9878 10.476 14.4775C9.29373 14.9672 7.99283 15.0953 6.73777 14.8457C5.48271 14.596 4.32987 13.9798 3.42502 13.075C2.52018 12.1701 1.90397 11.0173 1.65432 9.76224C1.40468 8.50718 1.5328 7.20628 2.0225 6.02404C2.5122 4.8418 3.34148 3.83133 4.40546 3.1204Z",
                    }),
                    a = aB(e("path"), {
                      d: "M6.68775 12.4297C6.78586 12.4745 6.89218 12.4984 7 12.5C7.11275 12.4955 7.22315 12.4664 7.32337 12.4145C7.4236 12.3627 7.51121 12.2894 7.58 12.2L12 5.63999C12.0848 5.47724 12.1071 5.28902 12.0625 5.11098C12.0178 4.93294 11.9095 4.77744 11.7579 4.67392C11.6064 4.57041 11.4221 4.52608 11.24 4.54931C11.0579 4.57254 10.8907 4.66173 10.77 4.79999L6.88 10.57L5.13 8.56999C5.06508 8.49566 4.98613 8.43488 4.89768 8.39111C4.80922 8.34735 4.713 8.32148 4.61453 8.31498C4.51605 8.30847 4.41727 8.32147 4.32382 8.35322C4.23038 8.38497 4.14413 8.43484 4.07 8.49999C3.92511 8.63217 3.83692 8.81523 3.82387 9.01092C3.81083 9.2066 3.87393 9.39976 4 9.54999L6.43 12.24C6.50187 12.3204 6.58964 12.385 6.68775 12.4297Z",
                    });
                  t.appendChild(n).append(a, r);
                  let i = e("defs"),
                    o = aB(e("clipPath"), { id: "clip0_57_156" }),
                    s = aB(e("rect"), {
                      width: "16",
                      height: "16",
                      fill: "white",
                      transform: "translate(0 0.5)",
                    });
                  return (
                    o.appendChild(s),
                    i.appendChild(o),
                    t.appendChild(i).appendChild(o).appendChild(s),
                    t
                  );
                })().outerHTML,
              }),
              []
            ),
            [i, o] = iO(null),
            s = ij(() => {
              i && (clearTimeout(i), o(null)), t();
            }, [i]),
            l = ij(
              (e) => {
                n.onSubmitSuccess(e),
                  o(
                    setTimeout(() => {
                      t(), o(null);
                    }, 5e3)
                  );
              },
              [t]
            );
          return ir(
            ii,
            null,
            i
              ? ir(
                  "div",
                  { class: "success__position", onClick: s },
                  ir(
                    "div",
                    { class: "success__content" },
                    r.successMessageText,
                    ir("span", {
                      class: "success__icon",
                      dangerouslySetInnerHTML: a,
                    })
                  )
                )
              : ir(
                  "dialog",
                  { class: "dialog", onClick: r.onFormClose, open: e },
                  ir(
                    "div",
                    { class: "dialog__position" },
                    ir(
                      "div",
                      {
                        class: "dialog__content",
                        onClick: (e) => {
                          e.stopPropagation();
                        },
                      },
                      ir(iY, { options: r }),
                      ir(iJ, { ...n, onSubmitSuccess: l })
                    )
                  )
                )
          );
        }
        let i0 = `
.dialog {
  position: fixed;
  z-index: var(--z-index);
  margin: 0;
  inset: 0;

  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  height: 100vh;
  width: 100vw;

  color: var(--dialog-color, var(--foreground));
  fill: var(--dialog-color, var(--foreground));
  line-height: 1.75em;

  background-color: rgba(0, 0, 0, 0.05);
  border: none;
  inset: 0;
  opacity: 1;
  transition: opacity 0.2s ease-in-out;
}

.dialog__position {
  position: fixed;
  z-index: var(--z-index);
  inset: var(--dialog-inset);
  padding: var(--page-margin);
  display: flex;
  max-height: calc(100vh - (2 * var(--page-margin)));
}
@media (max-width: 600px) {
  .dialog__position {
    inset: var(--page-margin);
    padding: 0;
  }
}

.dialog__position:has(.editor) {
  inset: var(--page-margin);
  padding: 0;
}

.dialog:not([open]) {
  opacity: 0;
  pointer-events: none;
  visibility: hidden;
}
.dialog:not([open]) .dialog__content {
  transform: translate(0, -16px) scale(0.98);
}

.dialog__content {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: var(--dialog-padding, 24px);
  max-width: 100%;
  width: 100%;
  max-height: 100%;
  overflow: auto;

  background: var(--dialog-background, var(--background));
  border-radius: var(--dialog-border-radius, 20px);
  border: var(--dialog-border, var(--border));
  box-shadow: var(--dialog-box-shadow, var(--box-shadow));
  transform: translate(0, 0) scale(1);
  transition: transform 0.2s ease-in-out;
}

`,
          i1 = `
.dialog__header {
  display: flex;
  gap: 4px;
  justify-content: space-between;
  font-weight: var(--dialog-header-weight, 600);
  margin: 0;
}
.dialog__title {
  align-self: center;
  width: var(--form-width, 272px);
}

@media (max-width: 600px) {
  .dialog__title {
    width: auto;
  }
}

.dialog__position:has(.editor) .dialog__title {
  width: auto;
}


.brand-link {
  display: inline-flex;
}
.brand-link:focus-visible {
  outline: var(--outline);
}
`,
          i3 = `
.form {
  display: flex;
  overflow: auto;
  flex-direction: row;
  gap: 16px;
  flex: 1 0;
}

.form__right {
  flex: 0 0 auto;
  display: flex;
  overflow: auto;
  flex-direction: column;
  justify-content: space-between;
  gap: 20px;
  width: var(--form-width, 100%);
}

.dialog__position:has(.editor) .form__right {
  width: var(--form-width, 272px);
}

.form__top {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form__error-container {
  color: var(--error-color);
  fill: var(--error-color);
}

.form__label {
  display: flex;
  flex-direction: column;
  gap: 4px;
  margin: 0px;
}

.form__label__text {
  display: flex;
  gap: 4px;
  align-items: center;
}

.form__label__text--required {
  font-size: 0.85em;
}

.form__input {
  font-family: inherit;
  line-height: inherit;
  background: transparent;
  box-sizing: border-box;
  border: var(--input-border, var(--border));
  border-radius: var(--input-border-radius, 6px);
  color: var(--input-color, inherit);
  fill: var(--input-color, inherit);
  font-size: var(--input-font-size, inherit);
  font-weight: var(--input-font-weight, 500);
  padding: 6px 12px;
}

.form__input::placeholder {
  opacity: 0.65;
  color: var(--input-placeholder-color, inherit);
  filter: var(--interactive-filter);
}

.form__input:focus-visible {
  outline: var(--input-focus-outline, var(--outline));
}

.form__input--textarea {
  font-family: inherit;
  resize: vertical;
}

.error {
  color: var(--error-color);
  fill: var(--error-color);
}
`,
          i2 = `
.btn-group {
  display: grid;
  gap: 8px;
}

.btn {
  line-height: inherit;
  border: var(--button-border, var(--border));
  border-radius: var(--button-border-radius, 6px);
  cursor: pointer;
  font-family: inherit;
  font-size: var(--button-font-size, inherit);
  font-weight: var(--button-font-weight, 600);
  padding: var(--button-padding, 6px 16px);
}
.btn[disabled] {
  opacity: 0.6;
  pointer-events: none;
}

.btn--primary {
  color: var(--button-primary-color, var(--accent-foreground));
  fill: var(--button-primary-color, var(--accent-foreground));
  background: var(--button-primary-background, var(--accent-background));
  border: var(--button-primary-border, var(--border));
  border-radius: var(--button-primary-border-radius, 6px);
  font-weight: var(--button-primary-font-weight, 500);
}
.btn--primary:hover {
  color: var(--button-primary-hover-color, var(--accent-foreground));
  fill: var(--button-primary-hover-color, var(--accent-foreground));
  background: var(--button-primary-hover-background, var(--accent-background));
  filter: var(--interactive-filter);
}
.btn--primary:focus-visible {
  background: var(--button-primary-hover-background, var(--accent-background));
  filter: var(--interactive-filter);
  outline: var(--button-primary-focus-outline, var(--outline));
}

.btn--default {
  color: var(--button-color, var(--foreground));
  fill: var(--button-color, var(--foreground));
  background: var(--button-background, var(--background));
  border: var(--button-border, var(--border));
  border-radius: var(--button-border-radius, 6px);
  font-weight: var(--button-font-weight, 500);
}
.btn--default:hover {
  color: var(--button-color, var(--foreground));
  fill: var(--button-color, var(--foreground));
  background: var(--button-hover-background, var(--background));
  filter: var(--interactive-filter);
}
.btn--default:focus-visible {
  background: var(--button-hover-background, var(--background));
  filter: var(--interactive-filter);
  outline: var(--button-focus-outline, var(--outline));
}
`,
          i4 = `
.success__position {
  position: fixed;
  inset: var(--dialog-inset);
  padding: var(--page-margin);
  z-index: var(--z-index);
}
.success__content {
  background: var(--success-background, var(--background));
  border: var(--success-border, var(--border));
  border-radius: var(--success-border-radius, 1.7em/50%);
  box-shadow: var(--success-box-shadow, var(--box-shadow));
  font-weight: var(--success-font-weight, 600);
  color: var(--success-color);
  fill: var(--success-color);
  padding: 12px 24px;
  line-height: 1.75em;

  display: grid;
  align-items: center;
  grid-auto-flow: column;
  gap: 6px;
  cursor: default;
}

.success__icon {
  display: flex;
}
`,
          i5 = () => ({
            name: "FeedbackModal",
            setupOnce() {},
            createDialog: ({
              options: e,
              screenshotIntegration: t,
              sendFeedback: n,
              shadow: r,
            }) => {
              let a = e.useSentryUser,
                i = (function () {
                  let e = (0, g.nZ)().getUser(),
                    t = (0, g.aF)().getUser(),
                    n = (0, g.lW)().getUser();
                  return e && Object.keys(e).length
                    ? e
                    : t && Object.keys(t).length
                    ? t
                    : n;
                })(),
                o = aF.createElement("div"),
                s = (function (e) {
                  let t = aF.createElement("style");
                  return (
                    (t.textContent = `
:host {
  --dialog-inset: var(--inset);
}

${i0}
${i1}
${i3}
${i2}
${i4}
`),
                    e && t.setAttribute("nonce", e),
                    t
                  );
                })(e.styleNonce),
                l = "",
                u = {
                  get el() {
                    return o;
                  },
                  appendToDom() {
                    r.contains(s) ||
                      r.contains(o) ||
                      (r.appendChild(s), r.appendChild(o));
                  },
                  removeFromDom() {
                    r.removeChild(o),
                      r.removeChild(s),
                      (aF.body.style.overflow = l);
                  },
                  open() {
                    d(!0),
                      e.onFormOpen && e.onFormOpen(),
                      (l = aF.body.style.overflow),
                      (aF.body.style.overflow = "hidden");
                  },
                  close() {
                    d(!1), (aF.body.style.overflow = l);
                  },
                },
                c =
                  t &&
                  t.createInput({ h: ir, hooks: iV, dialog: u, options: e }),
                d = (t) => {
                  var r, s, l, u, p, f;
                  (r = ir(iQ, {
                    options: e,
                    screenshotInput: c,
                    showName: e.showName || e.isNameRequired,
                    showEmail: e.showEmail || e.isEmailRequired,
                    defaultName: (a && i && i[a.name]) || "",
                    defaultEmail: (a && i && i[a.email]) || "",
                    onFormClose: () => {
                      d(!1), e.onFormClose && e.onFormClose();
                    },
                    onSubmit: n,
                    onSubmitSuccess: (t) => {
                      d(!1), e.onSubmitSuccess && e.onSubmitSuccess(t);
                    },
                    onSubmitError: (t) => {
                      e.onSubmitError && e.onSubmitError(t);
                    },
                    onFormSubmitted: () => {
                      e.onFormSubmitted && e.onFormSubmitted();
                    },
                    open: t,
                  })),
                    a0.__ && a0.__(r, o),
                    (u = (l = "function" == typeof s) ? null : o.__k),
                    (p = []),
                    (f = []),
                    i_(
                      o,
                      (r = ((!l && s) || o).__k = ir(ii, null, [r])),
                      u || a6,
                      a6,
                      void 0 !== o.ownerSVGElement,
                      !l && s
                        ? [s]
                        : u
                        ? null
                        : o.firstChild
                        ? aQ.call(o.childNodes)
                        : null,
                      p,
                      !l && s ? s : u ? u.__e : o.firstChild,
                      l,
                      f
                    ),
                    (r.__d = void 0),
                    ig(p, r, f);
                };
              return u;
            },
          }),
          i6 = a$.devicePixelRatio,
          i9 = (e) => ({
            x: Math.min(e.startX, e.endX),
            y: Math.min(e.startY, e.endY),
            width: Math.abs(e.startX - e.endX),
            height: Math.abs(e.startY - e.endY),
          }),
          i7 = (e) => {
            let t = e.clientHeight,
              n = e.clientWidth,
              r = e.width / e.height,
              a = t * r,
              i = t;
            a > n && ((a = n), (i = n / r));
            let o = (n - a) / 2,
              s = (t - i) / 2;
            return { startX: o, startY: s, endX: a + o, endY: i + s };
          },
          i8 = () => ({
            name: "FeedbackScreenshot",
            setupOnce() {},
            createInput: ({ h: e, hooks: t, dialog: n, options: r }) => {
              let a = aF.createElement("canvas");
              return {
                input: (function ({
                  h: e,
                  hooks: t,
                  imageBuffer: n,
                  dialog: r,
                  options: a,
                }) {
                  let i = (function ({ hooks: e }) {
                    return function ({
                      onBeforeScreenshot: t,
                      onScreenshot: n,
                      onAfterScreenshot: r,
                      onError: a,
                    }) {
                      e.useEffect(() => {
                        let e = async () => {
                          t();
                          let e = await aU.mediaDevices.getDisplayMedia({
                              video: {
                                width: a$.innerWidth * a$.devicePixelRatio,
                                height: a$.innerHeight * a$.devicePixelRatio,
                              },
                              audio: !1,
                              monitorTypeSurfaces: "exclude",
                              preferCurrentTab: !0,
                              selfBrowserSurface: "include",
                              surfaceSwitching: "exclude",
                            }),
                            a = aF.createElement("video");
                          await new Promise((t, r) => {
                            (a.srcObject = e),
                              (a.onloadedmetadata = () => {
                                n(a),
                                  e.getTracks().forEach((e) => e.stop()),
                                  t();
                              }),
                              a.play().catch(r);
                          }),
                            r();
                        };
                        e().catch(a);
                      }, []);
                    };
                  })({ hooks: t });
                  return function ({ onError: o }) {
                    let s = t.useMemo(
                        () => ({
                          __html: (function (e) {
                            let t = aF.createElement("style"),
                              n = "#1A141F",
                              r = "#302735";
                            return (
                              (t.textContent = `
.editor {
  padding: 10px;
  padding-top: 65px;
  padding-bottom: 65px;
  flex-grow: 1;

  background-color: ${n};
  background-image: repeating-linear-gradient(
      -145deg,
      transparent,
      transparent 8px,
      ${n} 8px,
      ${n} 11px
    ),
    repeating-linear-gradient(
      -45deg,
      transparent,
      transparent 15px,
      ${r} 15px,
      ${r} 16px
    );
}

.editor__canvas-container {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.editor__canvas-container canvas {
  object-fit: contain;
  position: relative;
}

.editor__crop-btn-group {
  padding: 8px;
  gap: 8px;
  border-radius: var(--menu-border-radius, 6px);
  background: var(--button-primary-background, var(--background));
  width: 175px;
  position: absolute;
}

.editor__crop-corner {
  width: 30px;
  height: 30px;
  position: absolute;
  background: none;
  border: 3px solid #ffffff;
}

.editor__crop-corner--top-left {
  cursor: nwse-resize;
  border-right: none;
  border-bottom: none;
}
.editor__crop-corner--top-right {
  cursor: nesw-resize;
  border-left: none;
  border-bottom: none;
}
.editor__crop-corner--bottom-left {
  cursor: nesw-resize;
  border-right: none;
  border-top: none;
}
.editor__crop-corner--bottom-right {
  cursor: nwse-resize;
  border-left: none;
  border-top: none;
}
`),
                              e && t.setAttribute("nonce", e),
                              t
                            );
                          })(a.styleNonce).innerText,
                        }),
                        []
                      ),
                      l = (function ({ h: e }) {
                        return function ({
                          top: t,
                          left: n,
                          corner: r,
                          onGrabButton: a,
                        }) {
                          return e("button", {
                            class: `editor__crop-corner editor__crop-corner--${r} `,
                            style: { top: t, left: n },
                            onMouseDown: (e) => {
                              e.preventDefault(), a(e, r);
                            },
                            onClick: (e) => {
                              e.preventDefault();
                            },
                          });
                        };
                      })({ h: e }),
                      u = t.useRef(null),
                      c = t.useRef(null),
                      d = t.useRef(null),
                      [p, f] = t.useState({
                        startX: 0,
                        startY: 0,
                        endX: 0,
                        endY: 0,
                      }),
                      [h, m] = t.useState(!1),
                      [_, g] = t.useState(!1);
                    function v() {
                      let e = d.current,
                        t = i9(i7(n));
                      if (e) {
                        (e.width = t.width * i6),
                          (e.height = t.height * i6),
                          (e.style.width = `${t.width}px`),
                          (e.style.height = `${t.height}px`);
                        let n = e.getContext("2d");
                        n && n.scale(i6, i6);
                      }
                      let r = c.current;
                      r &&
                        ((r.style.width = `${t.width}px`),
                        (r.style.height = `${t.height}px`)),
                        f({
                          startX: 0,
                          startY: 0,
                          endX: t.width,
                          endY: t.height,
                        });
                    }
                    function y(e, t) {
                      m(!1), g(!0);
                      let n = b(t),
                        r = () => {
                          aF.removeEventListener("mousemove", n),
                            aF.removeEventListener("mouseup", r),
                            m(!0),
                            g(!1);
                        };
                      aF.addEventListener("mouseup", r),
                        aF.addEventListener("mousemove", n);
                    }
                    t.useEffect(() => {
                      a$.addEventListener("resize", v, !1);
                    }, []),
                      t.useEffect(() => {
                        let e = d.current;
                        if (!e) return;
                        let t = e.getContext("2d");
                        if (!t) return;
                        let r = i9(i7(n)),
                          a = i9(p);
                        t.clearRect(0, 0, r.width, r.height),
                          (t.fillStyle = "rgba(0, 0, 0, 0.5)"),
                          t.fillRect(0, 0, r.width, r.height),
                          t.clearRect(a.x, a.y, a.width, a.height),
                          (t.strokeStyle = "#ffffff"),
                          (t.lineWidth = 3),
                          t.strokeRect(
                            a.x + 1,
                            a.y + 1,
                            a.width - 2,
                            a.height - 2
                          ),
                          (t.strokeStyle = "#000000"),
                          (t.lineWidth = 1),
                          t.strokeRect(
                            a.x + 3,
                            a.y + 3,
                            a.width - 6,
                            a.height - 6
                          );
                      }, [p]);
                    let b = t.useCallback(
                        (e) =>
                          function (t) {
                            if (!d.current) return;
                            let n = d.current,
                              r = n.getBoundingClientRect(),
                              a = t.clientX - r.x,
                              i = t.clientY - r.y;
                            switch (e) {
                              case "top-left":
                                f((e) => ({
                                  ...e,
                                  startX: Math.min(Math.max(0, a), e.endX - 33),
                                  startY: Math.min(Math.max(0, i), e.endY - 33),
                                }));
                                break;
                              case "top-right":
                                f((e) => ({
                                  ...e,
                                  endX: Math.max(
                                    Math.min(a, n.width / i6),
                                    e.startX + 33
                                  ),
                                  startY: Math.min(Math.max(0, i), e.endY - 33),
                                }));
                                break;
                              case "bottom-left":
                                f((e) => ({
                                  ...e,
                                  startX: Math.min(Math.max(0, a), e.endX - 33),
                                  endY: Math.max(
                                    Math.min(i, n.height / i6),
                                    e.startY + 33
                                  ),
                                }));
                                break;
                              case "bottom-right":
                                f((e) => ({
                                  ...e,
                                  endX: Math.max(
                                    Math.min(a, n.width / i6),
                                    e.startX + 33
                                  ),
                                  endY: Math.max(
                                    Math.min(i, n.height / i6),
                                    e.startY + 33
                                  ),
                                }));
                            }
                          },
                        []
                      ),
                      E = t.useRef({ initialX: 0, initialY: 0 });
                    return (
                      i({
                        onBeforeScreenshot: t.useCallback(() => {
                          r.el.style.display = "none";
                        }, []),
                        onScreenshot: t.useCallback(
                          (e) => {
                            let t = n.getContext("2d");
                            if (!t) throw Error("Could not get canvas context");
                            (n.width = e.videoWidth),
                              (n.height = e.videoHeight),
                              (n.style.width = "100%"),
                              (n.style.height = "100%"),
                              t.drawImage(e, 0, 0);
                          },
                          [n]
                        ),
                        onAfterScreenshot: t.useCallback(() => {
                          r.el.style.display = "block";
                          let e = u.current;
                          e && e.appendChild(n), v();
                        }, []),
                        onError: t.useCallback((e) => {
                          (r.el.style.display = "block"), o(e);
                        }, []),
                      }),
                      e(
                        "div",
                        { class: "editor" },
                        e("style", {
                          nonce: a.styleNonce,
                          dangerouslySetInnerHTML: s,
                        }),
                        e(
                          "div",
                          { class: "editor__canvas-container", ref: u },
                          e(
                            "div",
                            {
                              class: "editor__crop-container",
                              style: { position: "absolute", zIndex: 1 },
                              ref: c,
                            },
                            e("canvas", {
                              onMouseDown: function (e) {
                                if (_) return;
                                E.current = {
                                  initialX: e.clientX,
                                  initialY: e.clientY,
                                };
                                let t = (e) => {
                                    let t = d.current;
                                    if (!t) return;
                                    let n = e.clientX - E.current.initialX,
                                      r = e.clientY - E.current.initialY;
                                    f((a) => {
                                      let i = Math.max(
                                          0,
                                          Math.min(
                                            a.startX + n,
                                            t.width / i6 - (a.endX - a.startX)
                                          )
                                        ),
                                        o = Math.max(
                                          0,
                                          Math.min(
                                            a.startY + r,
                                            t.height / i6 - (a.endY - a.startY)
                                          )
                                        ),
                                        s = i + (a.endX - a.startX),
                                        l = o + (a.endY - a.startY);
                                      return (
                                        (E.current.initialX = e.clientX),
                                        (E.current.initialY = e.clientY),
                                        {
                                          startX: i,
                                          startY: o,
                                          endX: s,
                                          endY: l,
                                        }
                                      );
                                    });
                                  },
                                  n = () => {
                                    aF.removeEventListener("mousemove", t),
                                      aF.removeEventListener("mouseup", n);
                                  };
                                aF.addEventListener("mousemove", t),
                                  aF.addEventListener("mouseup", n);
                              },
                              style: {
                                position: "absolute",
                                cursor: h ? "move" : "auto",
                              },
                              ref: d,
                            }),
                            e(l, {
                              left: p.startX - 3,
                              top: p.startY - 3,
                              onGrabButton: y,
                              corner: "top-left",
                            }),
                            e(l, {
                              left: p.endX - 30 + 3,
                              top: p.startY - 3,
                              onGrabButton: y,
                              corner: "top-right",
                            }),
                            e(l, {
                              left: p.startX - 3,
                              top: p.endY - 30 + 3,
                              onGrabButton: y,
                              corner: "bottom-left",
                            }),
                            e(l, {
                              left: p.endX - 30 + 3,
                              top: p.endY - 30 + 3,
                              onGrabButton: y,
                              corner: "bottom-right",
                            }),
                            e(
                              "div",
                              {
                                style: {
                                  left: Math.max(0, p.endX - 191),
                                  top: Math.max(0, p.endY + 8),
                                  display: h ? "flex" : "none",
                                },
                                class: "editor__crop-btn-group",
                              },
                              e(
                                "button",
                                {
                                  onClick: (e) => {
                                    e.preventDefault(),
                                      d.current &&
                                        f({
                                          startX: 0,
                                          startY: 0,
                                          endX: d.current.width / i6,
                                          endY: d.current.height / i6,
                                        }),
                                      m(!1);
                                  },
                                  class: "btn btn--default",
                                },
                                a.cancelButtonLabel
                              ),
                              e(
                                "button",
                                {
                                  onClick: (e) => {
                                    e.preventDefault(),
                                      (function () {
                                        let e = aF.createElement("canvas"),
                                          t = i9(i7(n)),
                                          r = i9(p);
                                        (e.width = r.width * i6),
                                          (e.height = r.height * i6);
                                        let a = e.getContext("2d");
                                        a &&
                                          n &&
                                          a.drawImage(
                                            n,
                                            (r.x / t.width) * n.width,
                                            (r.y / t.height) * n.height,
                                            (r.width / t.width) * n.width,
                                            (r.height / t.height) * n.height,
                                            0,
                                            0,
                                            e.width,
                                            e.height
                                          );
                                        let i = n.getContext("2d");
                                        i &&
                                          (i.clearRect(0, 0, n.width, n.height),
                                          (n.width = e.width),
                                          (n.height = e.height),
                                          (n.style.width = `${r.width}px`),
                                          (n.style.height = `${r.height}px`),
                                          i.drawImage(e, 0, 0),
                                          v());
                                      })(),
                                      m(!1);
                                  },
                                  class: "btn btn--primary",
                                },
                                a.confirmButtonLabel
                              )
                            )
                          )
                        )
                      )
                    );
                  };
                })({ h: e, hooks: t, imageBuffer: a, dialog: n, options: r }),
                value: async () => {
                  let e = await new Promise((e) => {
                    a.toBlob(e, "image/png");
                  });
                  if (e) {
                    let t = new Uint8Array(await e.arrayBuffer());
                    return {
                      data: t,
                      filename: "screenshot.png",
                      contentType: "application/png",
                    };
                  }
                },
              };
            },
          }),
          oe = aV({ lazyLoadIntegration: r3 }),
          ot = aV({
            lazyLoadIntegration: r3,
            getModalIntegration: () => i5,
            getScreenshotIntegration: () => i8,
          });
        function on(e, t) {
          let n = (0, em.Y)("globalMetricsAggregators", () => new WeakMap()),
            r = n.get(e);
          if (r) return r;
          let a = new t(e);
          return (
            e.on("flush", () => a.flush()),
            e.on("close", () => a.close()),
            n.set(e, a),
            a
          );
        }
        function or(e, t, n, r, a = {}) {
          let i = a.client || (0, g.s3)();
          if (!i) return;
          let o = (0, q.HN)(),
            s = o ? (0, q.Gx)(o) : void 0,
            l = s && (0, q.XU)(s).description,
            { unit: u, tags: c, timestamp: d } = a,
            { release: p, environment: f } = i.getOptions(),
            h = {};
          p && (h.release = p),
            f && (h.environment = f),
            l && (h.transaction = l),
            _.X && v.kg.log(`Adding value of ${r} to ${t} metric ${n}`);
          let m = on(i, e);
          m.add(t, n, r, u, { ...h, ...c }, d);
        }
        function oa(e, t, n, r) {
          or(e, "d", t, oo(n), r);
        }
        let oi = {
          increment: function (e, t, n = 1, r) {
            or(e, "c", t, oo(n), r);
          },
          distribution: oa,
          set: function (e, t, n, r) {
            or(e, "s", t, n, r);
          },
          gauge: function (e, t, n, r) {
            or(e, "g", t, oo(n), r);
          },
          timing: function (e, t, n, r = "second", a) {
            if ("function" == typeof n) {
              let r = (0, V.ph)();
              return nr(
                {
                  op: "metrics.timing",
                  name: t,
                  startTime: r,
                  onlyIfParent: !0,
                },
                (i) =>
                  tK(
                    () => n(),
                    () => {},
                    () => {
                      let n = (0, V.ph)();
                      oa(e, t, n - r, { ...a, unit: "second" }), i.end(n);
                    }
                  )
              );
            }
            oa(e, t, n, { ...a, unit: r });
          },
          getMetricsAggregatorForClient: on,
        };
        function oo(e) {
          return "string" == typeof e ? parseInt(e) : e;
        }
        let os = [
            ["\n", "\\n"],
            ["\r", "\\r"],
            ["	", "\\t"],
            ["\\", "\\\\"],
            ["|", "\\u{7c}"],
            [",", "\\u{2c}"],
          ],
          ol = {
            c: class {
              constructor(e) {
                this._value = e;
              }
              get weight() {
                return 1;
              }
              add(e) {
                this._value += e;
              }
              toString() {
                return `${this._value}`;
              }
            },
            g: class {
              constructor(e) {
                (this._last = e),
                  (this._min = e),
                  (this._max = e),
                  (this._sum = e),
                  (this._count = 1);
              }
              get weight() {
                return 5;
              }
              add(e) {
                (this._last = e),
                  e < this._min && (this._min = e),
                  e > this._max && (this._max = e),
                  (this._sum += e),
                  this._count++;
              }
              toString() {
                return `${this._last}:${this._min}:${this._max}:${this._sum}:${this._count}`;
              }
            },
            d: class {
              constructor(e) {
                this._value = [e];
              }
              get weight() {
                return this._value.length;
              }
              add(e) {
                this._value.push(e);
              }
              toString() {
                return this._value.join(":");
              }
            },
            s: class {
              constructor(e) {
                (this.first = e), (this._value = new Set([e]));
              }
              get weight() {
                return this._value.size;
              }
              add(e) {
                this._value.add(e);
              }
              toString() {
                return Array.from(this._value)
                  .map((e) =>
                    "string" == typeof e
                      ? (function (e) {
                          let t = 0;
                          for (let n = 0; n < e.length; n++) {
                            let r = e.charCodeAt(n);
                            (t = (t << 5) - t + r), (t &= t);
                          }
                          return t >>> 0;
                        })(e)
                      : e
                  )
                  .join(":");
              }
            },
          };
        class ou {
          constructor(e) {
            (this._client = e),
              (this._buckets = new Map()),
              (this._interval = setInterval(() => this.flush(), 5e3));
          }
          add(e, t, n, r = "none", a = {}, i = (0, V.ph)()) {
            let o = Math.floor(i),
              s = t.replace(/[^\w\-.]+/gi, "_"),
              l = (function (e) {
                let t = {};
                for (let n in e)
                  if (Object.prototype.hasOwnProperty.call(e, n)) {
                    let r = n.replace(/[^\w\-./]+/gi, "");
                    t[r] = [...String(e[n])].reduce(
                      (e, t) =>
                        e +
                        (function (e) {
                          for (let [t, n] of os) if (e === t) return n;
                          return e;
                        })(t),
                      ""
                    );
                  }
                return t;
              })(a),
              u = r.replace(/[^\w]+/gi, "_"),
              c = (function (e, t, n, r) {
                let a = Object.entries((0, A.Jr)(r)).sort((e, t) =>
                  e[0].localeCompare(t[0])
                );
                return `${e}${t}${n}${a}`;
              })(e, s, u, l),
              d = this._buckets.get(c),
              p = d && "s" === e ? d.metric.weight : 0;
            d
              ? (d.metric.add(n), d.timestamp < o && (d.timestamp = o))
              : ((d = {
                  metric: new ol[e](n),
                  timestamp: o,
                  metricType: e,
                  name: s,
                  unit: u,
                  tags: l,
                }),
                this._buckets.set(c, d));
            let f = "string" == typeof n ? d.metric.weight - p : n;
            (0, q.yc)(e, s, f, u, a, c);
          }
          flush() {
            if (0 === this._buckets.size) return;
            let e = Array.from(this._buckets.values());
            (function (e, t) {
              v.kg.log(
                `Flushing aggregated metrics, number of metrics: ${t.length}`
              );
              let n = e.getDsn(),
                r = e.getSdkMetadata(),
                a = e.getOptions().tunnel,
                i = (function (e, t, n, r) {
                  let a = { sent_at: new Date().toISOString() };
                  n &&
                    n.sdk &&
                    (a.sdk = { name: n.sdk.name, version: n.sdk.version }),
                    r && t && (a.dsn = (0, H.RA)(t));
                  let i = (function (e) {
                    let t = (function (e) {
                        let t = "";
                        for (let n of e) {
                          let e = Object.entries(n.tags),
                            r =
                              e.length > 0
                                ? `|#${e
                                    .map(([e, t]) => `${e}:${t}`)
                                    .join(",")}`
                                : "";
                          t += `${n.name}@${n.unit}:${n.metric}|${n.metricType}${r}|T${n.timestamp}
`;
                        }
                        return t;
                      })(e),
                      n = { type: "statsd", length: t.length };
                    return [n, t];
                  })(e);
                  return (0, G.Jd)(a, [i]);
                })(t, n, r, a);
              e.sendEnvelope(i);
            })(this._client, e),
              this._buckets.clear();
          }
          close() {
            clearInterval(this._interval), this.flush();
          }
        }
        let oc = {
          increment: function (e, t = 1, n) {
            oi.increment(ou, e, t, n);
          },
          distribution: function (e, t, n) {
            oi.distribution(ou, e, t, n);
          },
          set: function (e, t, n) {
            oi.set(ou, e, t, n);
          },
          gauge: function (e, t, n) {
            oi.gauge(ou, e, t, n);
          },
          timing: function (e, t, n = "second", r) {
            return oi.timing(ou, e, t, n, r);
          },
        };
        function od(e) {
          return new Promise((t, n) => {
            (e.oncomplete = e.onsuccess = () => t(e.result)),
              (e.onabort = e.onerror = () => n(e.error));
          });
        }
        function op(e) {
          return od(e.getAllKeys());
        }
        function of(e) {
          let t;
          function n() {
            return (
              void 0 == t &&
                (t = (function (e, t) {
                  let n = indexedDB.open(e);
                  n.onupgradeneeded = () => n.result.createObjectStore(t);
                  let r = od(n);
                  return (e) =>
                    r.then((n) =>
                      e(n.transaction(t, "readwrite").objectStore(t))
                    );
                })(e.dbName || "sentry-offline", e.storeName || "queue")),
              t
            );
          }
          return {
            push: async (t) => {
              try {
                var r, a;
                let i = await (0, G.V$)(t);
                await ((r = n()),
                (a = e.maxQueueSize || 30),
                r((e) =>
                  op(e).then((t) => {
                    if (!(t.length >= a))
                      return e.put(i, Math.max(...t, 0) + 1), od(e.transaction);
                  })
                ));
              } catch (e) {}
            },
            unshift: async (t) => {
              try {
                var r, a;
                let i = await (0, G.V$)(t);
                await ((r = n()),
                (a = e.maxQueueSize || 30),
                r((e) =>
                  op(e).then((t) => {
                    if (!(t.length >= a))
                      return e.put(i, Math.min(...t, 0) - 1), od(e.transaction);
                  })
                ));
              } catch (e) {}
            },
            shift: async () => {
              try {
                let e = await n()((e) =>
                  op(e).then((t) => {
                    let n = t[0];
                    if (null != n)
                      return od(e.get(n)).then(
                        (t) => (e.delete(n), od(e.transaction).then(() => t))
                      );
                  })
                );
                if (e) return (0, G.f4)(e);
              } catch (e) {}
            },
          };
        }
        function oh(e = tk) {
          var t;
          return (
            (t = (function (e) {
              function t(...e) {
                _.X && v.kg.info("[Offline]:", ...e);
              }
              return (n) => {
                let r;
                let a = e(n);
                if (!n.createStore)
                  throw Error("No `createStore` function was provided");
                let i = n.createStore(n),
                  o = 5e3;
                function s(e) {
                  r && clearTimeout(r),
                    "number" !=
                      typeof (r = setTimeout(async () => {
                        r = void 0;
                        let e = await i.shift();
                        e &&
                          (t("Attempting to send previously queued event"),
                          (e[0].sent_at = new Date().toISOString()),
                          u(e, !0).catch((e) => {
                            t("Failed to retry sending", e);
                          }));
                      }, e)) &&
                      r.unref &&
                      r.unref();
                }
                function l() {
                  r || (s(o), (o = Math.min(2 * o, 36e5)));
                }
                async function u(e, r = !1) {
                  if (!r && (0, G.R)(e, ["replay_event", "replay_recording"]))
                    return await i.push(e), s(100), {};
                  try {
                    let t = await a.send(e),
                      n = 100;
                    if (t) {
                      if (t.headers && t.headers["retry-after"])
                        n = (0, tw.JY)(t.headers["retry-after"]);
                      else if (t.headers && t.headers["x-sentry-rate-limits"])
                        n = 6e4;
                      else if ((t.statusCode || 0) >= 400) return t;
                    }
                    return s(n), (o = 5e3), t;
                  } catch (a) {
                    var u;
                    if (
                      await ((u = o),
                      !(0, G.R)(e, ["client_report"]) &&
                        (!n.shouldStore || n.shouldStore(e, a, u)))
                    )
                      return (
                        r ? await i.unshift(e) : await i.push(e),
                        l(),
                        t("Error sending. Event queued.", a),
                        {}
                      );
                    throw a;
                  }
                }
                return (
                  n.flushAtStartup && l(), { send: u, flush: (e) => a.flush(e) }
                );
              };
            })(e)),
            (e) => t({ ...e, createStore: of })
          );
        }
        var om = n(73243),
          o_ = n(62538);
        let og = String(0),
          ov = "",
          oy = "",
          ob = "",
          oE = (e_.navigator && e_.navigator.userAgent) || "",
          oS = "",
          ow =
            (e_.navigator && e_.navigator.language) ||
            (e_.navigator &&
              e_.navigator.languages &&
              e_.navigator.languages[0]) ||
            "",
          oT = e_.navigator && e_.navigator.userAgentData;
        function ox(e) {
          return "pageload" === (0, q.XU)(e).op;
        }
        "object" == typeof oT &&
          null !== oT &&
          "getHighEntropyValues" in oT &&
          oT
            .getHighEntropyValues([
              "architecture",
              "model",
              "platform",
              "platformVersion",
              "fullVersionList",
            ])
            .then((e) => {
              if (
                ((ov = e.platform || ""),
                (ob = e.architecture || ""),
                (oS = e.model || ""),
                (oy = e.platformVersion || ""),
                e.fullVersionList && e.fullVersionList.length > 0)
              ) {
                let t = e.fullVersionList[e.fullVersionList.length - 1];
                oE = `${t.brand} ${t.version}`;
              }
            })
            .catch((e) => void 0);
        let ok = !1;
        function oI(e) {
          if (ok || !e.isRecording()) return !1;
          let t = (0, g.s3)(),
            n = t && t.getOptions();
          if (!n) return !1;
          let r = n.profilesSampleRate;
          return (
            !(
              ("number" != typeof r && "boolean" != typeof r) ||
              ("number" == typeof r && isNaN(r))
            ) &&
            (!0 === r || !1 === r || (!(r < 0) && !(r > 1))) &&
            !!r &&
            !!(!0 === r || Math.random() < r)
          );
        }
        let oC = new Map();
        function oA(e) {
          let t;
          ox(e) && (t = 1e3 * (0, V.ph)());
          let n = (function () {
            let e = e_.Profiler;
            if ("function" == typeof e)
              try {
                return new e({
                  sampleInterval: 10,
                  maxBufferSize: Math.floor(3e3),
                });
              } catch (e) {
                ok = !0;
              }
          })();
          if (!n) return;
          let r = (0, w.DM)();
          async function a() {
            if (e && n)
              return n
                .stop()
                .then((e) => {
                  i && (e_.clearTimeout(i), (i = void 0)),
                    e &&
                      (function (e, t) {
                        if ((oC.set(e, t), oC.size > 30)) {
                          let e = oC.keys().next().value;
                          oC.delete(e);
                        }
                      })(r, e);
                })
                .catch((e) => {});
          }
          (0, g.nZ)().setContext("profile", {
            profile_id: r,
            start_timestamp: t,
          });
          let i = e_.setTimeout(() => {
              a();
            }, 3e4),
            o = e.end.bind(e);
          e.end = function () {
            return e
              ? (a().then(
                  () => {
                    o();
                  },
                  () => {
                    o();
                  }
                ),
                e)
              : o();
          };
        }
        let oR = () => ({
            name: "BrowserProfiling",
            setup(e) {
              let t = (0, q.HN)(),
                n = t && (0, q.Gx)(t);
              n && ox(n) && oI(n) && oA(n),
                e.on("spanStart", (e) => {
                  e === (0, q.Gx)(e) && oI(e) && oA(e);
                }),
                e.on("beforeEnvelope", (e) => {
                  if (!oC.size) return;
                  let t = (function (e) {
                    let t = [];
                    return (
                      (0, G.gv)(e, (e, n) => {
                        if ("transaction" === n)
                          for (let n = 1; n < e.length; n++) {
                            let r = e[n];
                            r &&
                              r.contexts &&
                              r.contexts.profile &&
                              r.contexts.profile.profile_id &&
                              t.push(e[n]);
                          }
                      }),
                      t
                    );
                  })(e);
                  if (!t.length) return;
                  let n = [];
                  for (let e of t) {
                    var r, a, i, o;
                    let t = e && e.contexts,
                      s = t && t.profile && t.profile.profile_id,
                      l = t && t.profile && t.profile.start_timestamp;
                    if ("string" != typeof s || !s) continue;
                    t && t.profile && delete t.profile;
                    let u = (function (e) {
                      let t = oC.get(e);
                      return t && oC.delete(e), t;
                    })(s);
                    if (!u) continue;
                    let c =
                      ((r = s),
                      (a = l),
                      (i = u),
                      (o = e),
                      !(i.samples.length < 2) && i.frames.length
                        ? (function (e, t, n, r) {
                            if ("transaction" !== r.type)
                              throw TypeError(
                                "Profiling events may only be attached to transactions, this should never occur."
                              );
                            if (null == n)
                              throw TypeError(
                                `Cannot construct profiling event envelope without a valid profile. Got ${n} instead.`
                              );
                            let a = (function (e) {
                                let t =
                                  e &&
                                  e.contexts &&
                                  e.contexts.trace &&
                                  e.contexts.trace.trace_id;
                                return ("string" == typeof t && t.length,
                                "string" != typeof t)
                                  ? ""
                                  : t;
                              })(r),
                              i =
                                "thread_metadata" in n
                                  ? n
                                  : (function (e) {
                                      let t;
                                      let n = 0,
                                        r = {
                                          samples: [],
                                          stacks: [],
                                          frames: [],
                                          thread_metadata: {
                                            [og]: { name: "main" },
                                          },
                                        },
                                        a = e.samples[0];
                                      if (!a) return r;
                                      let i = a.timestamp,
                                        o =
                                          "number" ==
                                          typeof performance.timeOrigin
                                            ? performance.timeOrigin
                                            : V.Z1 || 0,
                                        s = o - (V.Z1 || o);
                                      return (
                                        e.samples.forEach((a, o) => {
                                          if (void 0 === a.stackId) {
                                            void 0 === t &&
                                              ((t = n),
                                              (r.stacks[t] = []),
                                              n++),
                                              (r.samples[o] = {
                                                elapsed_since_start_ns: (
                                                  (a.timestamp + s - i) *
                                                  1e6
                                                ).toFixed(0),
                                                stack_id: t,
                                                thread_id: og,
                                              });
                                            return;
                                          }
                                          let l = e.stacks[a.stackId],
                                            u = [];
                                          for (; l; ) {
                                            u.push(l.frameId);
                                            let t = e.frames[l.frameId];
                                            t &&
                                              void 0 === r.frames[l.frameId] &&
                                              (r.frames[l.frameId] = {
                                                function: t.name,
                                                abs_path:
                                                  "number" ==
                                                  typeof t.resourceId
                                                    ? e.resources[t.resourceId]
                                                    : void 0,
                                                lineno: t.line,
                                                colno: t.column,
                                              }),
                                              (l =
                                                void 0 === l.parentId
                                                  ? void 0
                                                  : e.stacks[l.parentId]);
                                          }
                                          let c = {
                                            elapsed_since_start_ns: (
                                              (a.timestamp + s - i) *
                                              1e6
                                            ).toFixed(0),
                                            stack_id: n,
                                            thread_id: og,
                                          };
                                          (r.stacks[n] = u),
                                            (r.samples[o] = c),
                                            n++;
                                        }),
                                        r
                                      );
                                    })(n),
                              o =
                                t ||
                                ("number" == typeof r.start_timestamp
                                  ? 1e3 * r.start_timestamp
                                  : 1e3 * (0, V.ph)()),
                              s =
                                "number" == typeof r.timestamp
                                  ? 1e3 * r.timestamp
                                  : 1e3 * (0, V.ph)(),
                              l = {
                                event_id: e,
                                timestamp: new Date(o).toISOString(),
                                platform: "javascript",
                                version: "1",
                                release: r.release || "",
                                environment: r.environment || om.J,
                                runtime: {
                                  name: "javascript",
                                  version: e_.navigator.userAgent,
                                },
                                os: { name: ov, version: oy, build_number: oE },
                                device: {
                                  locale: ow,
                                  model: oS,
                                  manufacturer: oE,
                                  architecture: ob,
                                  is_emulator: !1,
                                },
                                debug_meta: {
                                  images: (function (e) {
                                    let t = (0, g.s3)(),
                                      n = t && t.getOptions(),
                                      r = n && n.stackParser;
                                    return r ? (0, o_.v)(r, e) : [];
                                  })(n.resources),
                                },
                                profile: i,
                                transactions: [
                                  {
                                    name: r.transaction || "",
                                    id: r.event_id || (0, w.DM)(),
                                    trace_id: a,
                                    active_thread_id: og,
                                    relative_start_ns: "0",
                                    relative_end_ns: ((s - o) * 1e6).toFixed(0),
                                  },
                                ],
                              };
                            return l;
                          })(r, a, i, o)
                        : null);
                    c && n.push(c);
                  }
                  !(function (e, t) {
                    if (t.length)
                      for (let n of t) e[1].push([{ type: "profile" }, n]);
                  })(e, n);
                });
            },
          }),
          oN = oR,
          oP = (e = {}) => {
            let t = e.sidecarUrl || "http://localhost:8969/stream";
            return {
              name: "SpotlightBrowser",
              setup: () => {},
              processEvent: (e) =>
                Boolean(
                  "transaction" === e.type &&
                    e.spans &&
                    e.contexts &&
                    e.contexts.trace &&
                    "ui.action.click" === e.contexts.trace.op &&
                    e.spans.some(
                      ({ description: e }) =>
                        e && e.includes("#sentry-spotlight")
                    )
                )
                  ? null
                  : e,
              afterAllSetup: (e) => {
                (function (e, t) {
                  let n = (0, tS.L2)("fetch"),
                    r = 0;
                  e.on("beforeEnvelope", (e) => {
                    if (r > 3) {
                      v.kg.warn(
                        "[Spotlight] Disabled Sentry -> Spotlight integration due to too many failed requests:",
                        r
                      );
                      return;
                    }
                    n(t, {
                      method: "POST",
                      body: (0, G.V$)(e),
                      headers: {
                        "Content-Type": "application/x-sentry-envelope",
                      },
                      mode: "cors",
                    }).then(
                      (e) => {
                        e.status >= 200 && e.status < 400 && (r = 0);
                      },
                      (e) => {
                        r++,
                          v.kg.error(
                            "Sentry SDK can't connect to Sidecar is it running? See: https://spotlightjs.com/sidecar/npx/",
                            e
                          );
                      }
                    );
                  });
                })(e, t);
              },
            };
          },
          oM = oP;
        function oL(e) {
          let t = (0, g.nZ)(),
            n = t.getScopeData().contexts.flags,
            r = n ? n.values : [];
          return (
            r.length &&
              (void 0 === e.contexts && (e.contexts = {}),
              (e.contexts.flags = { values: [...r] })),
            e
          );
        }
        function oD(e, t, n = 100) {
          let r = (0, g.nZ)().getScopeData().contexts;
          r.flags || (r.flags = { values: [] });
          let a = r.flags.values;
          (function (e, t, n, r) {
            if ("boolean" != typeof n || e.length > r) return;
            let a = e.findIndex((e) => e.flag === t);
            -1 !== a && e.splice(a, 1),
              e.length === r && e.shift(),
              e.push({ flag: t, result: n });
          })(a, e, t, n);
        }
        let oO = () => ({
            name: "FeatureFlags",
            processEvent: (e, t, n) => oL(e),
            addFeatureFlag(e, t) {
              oD(e, t);
            },
          }),
          o$ = () => ({
            name: "LaunchDarkly",
            processEvent: (e, t, n) => oL(e),
          });
        function oF() {
          return {
            name: "sentry-flag-auditor",
            type: "flag-used",
            synchronous: !0,
            method: (e, t, n) => {
              oD(e, t.value);
            },
          };
        }
        let oU = () => ({
          name: "OpenFeature",
          processEvent: (e, t, n) => oL(e),
        });
        class oj {
          after(e, t) {
            oD(t.flagKey, t.value);
          }
          error(e, t, n) {
            oD(e.flagKey, e.defaultValue);
          }
        }
        function oH(e, { componentStack: t }, n) {
          if (
            (function (e) {
              let t = e.match(/^([^.]+)/);
              return null !== t && parseInt(t[0]) >= 17;
            })(tP.version) &&
            (0, z.VZ)(e) &&
            t
          ) {
            let n = Error(e.message);
            (n.name = `React ErrorBoundary ${e.name}`),
              (n.stack = t),
              (function (e, t) {
                let n = new WeakSet();
                !(function e(t, r) {
                  if (!n.has(t)) {
                    if (t.cause) return n.add(t), e(t.cause, r);
                    t.cause = r;
                  }
                })(e, t);
              })(e, n);
          }
          return (0, m.Tb)(e, {
            ...n,
            captureContext: { contexts: { react: { componentStack: t } } },
          });
        }
        function oX(e) {
          return (t, n) => {
            let r = oH(t, n);
            e && e(t, n, r);
          };
        }
        var oB = n(8679);
        let oW = "ui.react.render",
          oG = "ui.react.mount";
        class oq extends tP.Component {
          static __initStatic() {
            this.defaultProps = {
              disabled: !1,
              includeRender: !0,
              includeUpdates: !0,
            };
          }
          constructor(e) {
            super(e);
            let { name: t, disabled: n = !1 } = this.props;
            if (n) return;
            this._mountSpan = na({
              name: `<${t}>`,
              onlyIfParent: !0,
              op: oG,
              attributes: {
                [tX.S3]: "auto.ui.react.profiler",
                "ui.component_name": t,
              },
            });
          }
          componentDidMount() {
            this._mountSpan && this._mountSpan.end();
          }
          shouldComponentUpdate({ updateProps: e, includeUpdates: t = !0 }) {
            if (t && this._mountSpan && e !== this.props.updateProps) {
              let t = Object.keys(e).filter(
                (t) => e[t] !== this.props.updateProps[t]
              );
              if (t.length > 0) {
                let e = (0, V.ph)();
                this._updateSpan = no(this._mountSpan, () =>
                  na({
                    name: `<${this.props.name}>`,
                    onlyIfParent: !0,
                    op: "ui.react.update",
                    startTime: e,
                    attributes: {
                      [tX.S3]: "auto.ui.react.profiler",
                      "ui.component_name": this.props.name,
                      "ui.react.changed_props": t,
                    },
                  })
                );
              }
            }
            return !0;
          }
          componentDidUpdate() {
            this._updateSpan &&
              (this._updateSpan.end(), (this._updateSpan = void 0));
          }
          componentWillUnmount() {
            let e = (0, V.ph)(),
              { name: t, includeRender: n = !0 } = this.props;
            if (this._mountSpan && n) {
              let n = (0, q.XU)(this._mountSpan).timestamp;
              no(this._mountSpan, () => {
                let r = na({
                  onlyIfParent: !0,
                  name: `<${t}>`,
                  op: oW,
                  startTime: n,
                  attributes: {
                    [tX.S3]: "auto.ui.react.profiler",
                    "ui.component_name": t,
                  },
                });
                r && r.end(e);
              });
            }
          }
          render() {
            return this.props.children;
          }
        }
        function oZ(e, t) {
          let n = (t && t.name) || e.displayName || e.name || "unknown",
            r = (r) =>
              tP.createElement(
                oq,
                { ...t, name: n, updateProps: r },
                tP.createElement(e, { ...r })
              );
          return (r.displayName = `profiler(${n})`), oB(r, e), r;
        }
        function oV(e, t = { disabled: !1, hasRenderSpan: !0 }) {
          let [n] = tP.useState(() => {
            if (!t || !t.disabled)
              return na({
                name: `<${e}>`,
                onlyIfParent: !0,
                op: oG,
                attributes: {
                  [tX.S3]: "auto.ui.react.profiler",
                  "ui.component_name": e,
                },
              });
          });
          tP.useEffect(
            () => (
              n && n.end(),
              () => {
                if (n && t.hasRenderSpan) {
                  let t = (0, q.XU)(n).timestamp,
                    r = (0, V.ph)(),
                    a = na({
                      name: `<${e}>`,
                      onlyIfParent: !0,
                      op: oW,
                      startTime: t,
                      attributes: {
                        [tX.S3]: "auto.ui.react.profiler",
                        "ui.component_name": e,
                      },
                    });
                  a && a.end(r);
                }
              }
            ),
            []
          );
        }
        oq.__initStatic();
        let oY = { componentStack: null, error: null, eventId: null };
        class oz extends tP.Component {
          constructor(e) {
            super(e),
              oz.prototype.__init.call(this),
              (this.state = oY),
              (this._openFallbackReportDialog = !0);
            let t = (0, g.s3)();
            t &&
              e.showDialog &&
              ((this._openFallbackReportDialog = !1),
              (this._cleanupHook = t.on("afterSendEvent", (t) => {
                !t.type &&
                  this._lastEventId &&
                  t.event_id === this._lastEventId &&
                  tC({ ...e.dialogOptions, eventId: this._lastEventId });
              })));
          }
          componentDidCatch(e, t) {
            let { componentStack: n } = t,
              r = null == n ? void 0 : n,
              {
                beforeCapture: a,
                onError: i,
                showDialog: o,
                dialogOptions: s,
              } = this.props;
            (0, g.$e)((l) => {
              a && a(l, e, r);
              let u = oH(e, t, {
                mechanism: { handled: !!this.props.fallback },
              });
              i && i(e, r, u),
                o &&
                  ((this._lastEventId = u),
                  this._openFallbackReportDialog && tC({ ...s, eventId: u })),
                this.setState({ error: e, componentStack: n, eventId: u });
            });
          }
          componentDidMount() {
            let { onMount: e } = this.props;
            e && e();
          }
          componentWillUnmount() {
            let { error: e, componentStack: t, eventId: n } = this.state,
              { onUnmount: r } = this.props;
            r && r(e, t, n),
              this._cleanupHook &&
                (this._cleanupHook(), (this._cleanupHook = void 0));
          }
          __init() {
            this.resetErrorBoundary = () => {
              let { onReset: e } = this.props,
                { error: t, componentStack: n, eventId: r } = this.state;
              e && e(t, n, r), this.setState(oY);
            };
          }
          render() {
            let { fallback: e, children: t } = this.props,
              n = this.state;
            if (n.error) {
              let t;
              return ((t =
                "function" == typeof e
                  ? tP.createElement(e, {
                      error: n.error,
                      componentStack: n.componentStack,
                      resetError: this.resetErrorBoundary,
                      eventId: n.eventId,
                    })
                  : e),
              tP.isValidElement(t))
                ? t
                : null;
            }
            return "function" == typeof t ? t() : t;
          }
        }
        function oJ(e, t) {
          let n = e.displayName || e.name || "unknown",
            r = (n) =>
              tP.createElement(oz, { ...t }, tP.createElement(e, { ...n }));
          return (r.displayName = `errorBoundary(${n})`), oB(r, e), r;
        }
        let oK = {
          attachReduxState: !0,
          actionTransformer: (e) => e,
          stateTransformer: (e) => e || null,
        };
        function oQ(e) {
          let t = { ...oK, ...e };
          return (e) => (n, r) => {
            t.attachReduxState &&
              (0, g.lW)().addEventProcessor((e, t) => {
                try {
                  void 0 === e.type &&
                    "redux" === e.contexts.state.state.type &&
                    (t.attachments = [
                      ...(t.attachments || []),
                      {
                        filename: "redux_state.json",
                        data: JSON.stringify(e.contexts.state.state.value),
                      },
                    ]);
                } catch (e) {}
                return e;
              });
            let a = (e, r) => {
              let a = n(e, r),
                i = (0, g.nZ)(),
                o = t.actionTransformer(r);
              null != o &&
                (0, eM.n)({ category: "redux.action", data: o, type: "info" });
              let s = t.stateTransformer(a);
              if (null != s) {
                let e = (0, g.s3)(),
                  t = e && e.getOptions(),
                  n = (t && t.normalizeDepth) || 3,
                  r = { state: { type: "redux", value: s } };
                (0, A.xp)(r, "__sentry_override_normalization_depth__", 3 + n),
                  i.setContext("state", r);
              } else i.setContext("state", null);
              let { configureScopeWithState: l } = t;
              return "function" == typeof l && l(i, a), a;
            };
            return e(a, r);
          };
        }
        function o0(e) {
          let t = nZ({
              ...e,
              instrumentPageLoad: !1,
              instrumentNavigation: !1,
            }),
            {
              history: n,
              routes: r,
              match: a,
              instrumentPageLoad: i = !0,
              instrumentNavigation: o = !0,
            } = e;
          return {
            ...t,
            afterAllSetup(e) {
              t.afterAllSetup(e),
                i &&
                  e_ &&
                  e_.location &&
                  o1(r, e_.location, a, (t, n = "url") => {
                    nV(e, {
                      name: t,
                      attributes: {
                        [tX.$J]: "pageload",
                        [tX.S3]: "auto.pageload.react.reactrouter_v3",
                        [tX.Zj]: n,
                      },
                    });
                  }),
                o &&
                  n.listen &&
                  n.listen((t) => {
                    ("PUSH" === t.action || "POP" === t.action) &&
                      o1(r, t, a, (t, n = "url") => {
                        nY(e, {
                          name: t,
                          attributes: {
                            [tX.$J]: "navigation",
                            [tX.S3]: "auto.navigation.react.reactrouter_v3",
                            [tX.Zj]: n,
                          },
                        });
                      });
                  });
            },
          };
        }
        function o1(e, t, n, r) {
          let a = t.pathname;
          n({ location: t, routes: e }, (e, t, n) => {
            if (e || !n) return r(a);
            let i = (function (e) {
              if (!Array.isArray(e) || 0 === e.length) return "";
              let t = e.filter((e) => !!e.path),
                n = -1;
              for (let e = t.length - 1; e >= 0; e--) {
                let r = t[e];
                if (r.path && r.path.startsWith("/")) {
                  n = e;
                  break;
                }
              }
              return t
                .slice(n)
                .filter(({ path: e }) => !!e)
                .map(({ path: e }) => e)
                .join("");
            })(n.routes || []);
            return 0 === i.length || "/*" === i ? r(a) : r((a = i), "route");
          });
        }
        function o3(e, t = {}) {
          let n = nZ({
              ...t,
              instrumentNavigation: !1,
              instrumentPageLoad: !1,
            }),
            { instrumentPageLoad: r = !0, instrumentNavigation: a = !0 } = t;
          return {
            ...n,
            afterAllSetup(t) {
              n.afterAllSetup(t);
              let i = e_.location;
              if (r && i) {
                let n = e.matchRoutes(
                    i.pathname,
                    e.options.parseSearch(i.search),
                    { preload: !1, throwOnError: !1 }
                  ),
                  r = n[n.length - 1];
                nV(t, {
                  name: r ? r.routeId : i.pathname,
                  attributes: {
                    [tX.$J]: "pageload",
                    [tX.S3]: "auto.pageload.react.tanstack_router",
                    [tX.Zj]: r ? "route" : "url",
                    ...o2(r),
                  },
                });
              }
              a &&
                e.subscribe("onBeforeNavigate", (n) => {
                  if (n.toLocation.state === n.fromLocation.state) return;
                  let r = e.matchRoutes(
                      n.toLocation.pathname,
                      n.toLocation.search,
                      { preload: !1, throwOnError: !1 }
                    ),
                    a = r[r.length - 1],
                    i = e_.location,
                    o = nY(t, {
                      name: a ? a.routeId : i.pathname,
                      attributes: {
                        [tX.$J]: "navigation",
                        [tX.S3]: "auto.navigation.react.tanstack_router",
                        [tX.Zj]: a ? "route" : "url",
                      },
                    }),
                    s = e.subscribe("onResolved", (t) => {
                      if ((s(), o)) {
                        let n = e.matchRoutes(
                            t.toLocation.pathname,
                            t.toLocation.search,
                            { preload: !1, throwOnError: !1 }
                          ),
                          r = n[n.length - 1];
                        r &&
                          (o.updateName(r.routeId),
                          o.setAttribute(tX.Zj, "route"),
                          o.setAttributes(o2(r)));
                      }
                    });
                });
            },
          };
        }
        function o2(e) {
          if (!e) return {};
          let t = {};
          return (
            Object.entries(e.params).forEach(([e, n]) => {
              t[`url.path.params.${e}`] = n;
            }),
            t
          );
        }
        function o4(e) {
          let t = nZ({
              ...e,
              instrumentPageLoad: !1,
              instrumentNavigation: !1,
            }),
            {
              history: n,
              routes: r,
              matchPath: a,
              instrumentPageLoad: i = !0,
              instrumentNavigation: o = !0,
            } = e;
          return {
            ...t,
            afterAllSetup(e) {
              t.afterAllSetup(e), o6(e, i, o, n, "reactrouter_v4", r, a);
            },
          };
        }
        function o5(e) {
          let t = nZ({
              ...e,
              instrumentPageLoad: !1,
              instrumentNavigation: !1,
            }),
            {
              history: n,
              routes: r,
              matchPath: a,
              instrumentPageLoad: i = !0,
              instrumentNavigation: o = !0,
            } = e;
          return {
            ...t,
            afterAllSetup(e) {
              t.afterAllSetup(e), o6(e, i, o, n, "reactrouter_v5", r, a);
            },
          };
        }
        function o6(e, t, n, r, a, i = [], o) {
          function s(e) {
            if (0 === i.length || !o) return [e, "url"];
            let t = (function e(t, n, r, a = []) {
              return (
                t.some((t) => {
                  let i = t.path
                    ? r(n, t)
                    : a.length
                    ? a[a.length - 1].match
                    : { path: "/", url: "/", params: {}, isExact: "/" === n };
                  return (
                    i &&
                      (a.push({ route: t, match: i }),
                      t.routes && e(t.routes, n, r, a)),
                    !!i
                  );
                }),
                a
              );
            })(i, e, o);
            for (let e of t)
              if (e.match.isExact) return [e.match.path, "route"];
            return [e, "url"];
          }
          if (t) {
            let t =
              r && r.location
                ? r.location.pathname
                : e_ && e_.location
                ? e_.location.pathname
                : void 0;
            if (t) {
              let [n, r] = s(t);
              nV(e, {
                name: n,
                attributes: {
                  [tX.$J]: "pageload",
                  [tX.S3]: `auto.pageload.react.${a}`,
                  [tX.Zj]: r,
                },
              });
            }
          }
          n &&
            r.listen &&
            r.listen((t, n) => {
              if (n && ("PUSH" === n || "POP" === n)) {
                let [n, r] = s(t.pathname);
                nY(e, {
                  name: n,
                  attributes: {
                    [tX.$J]: "navigation",
                    [tX.S3]: `auto.navigation.react.${a}`,
                    [tX.Zj]: r,
                  },
                });
              }
            });
        }
        function o9(e) {
          let t = e.displayName || e.name,
            n = (t) => {
              if (t && t.computedMatch && t.computedMatch.isExact) {
                let e = t.computedMatch.path,
                  n = (function () {
                    let e = (0, q.HN)(),
                      t = e && (0, q.Gx)(e);
                    if (!t) return;
                    let n = (0, q.XU)(t).op;
                    return "navigation" === n || "pageload" === n ? t : void 0;
                  })();
                (0, g.nZ)().setTransactionName(e),
                  n && (n.updateName(e), n.setAttribute(tX.Zj, "route"));
              }
              return tP.createElement(e, { ...t });
            };
          return (n.displayName = `sentryRoute(${t})`), oB(n, e), n;
        }
        let o7 = !1,
          o8 = new WeakSet();
        function se(e, t) {
          return s && l && u && d
            ? function (n, r) {
                let a = e(n, r),
                  i = r && r.basename,
                  o = sl();
                return (
                  "POP" === a.state.historyAction &&
                    o &&
                    so(o, a.state.location, n, void 0, i),
                  a.subscribe((e) => {
                    let r = e.location;
                    ("PUSH" === e.historyAction || "POP" === e.historyAction) &&
                      sr(r, n, e.historyAction, t, void 0, i);
                  }),
                  a
                );
              }
            : e;
        }
        function st(e, t) {
          let n = nZ({
              ...e,
              instrumentPageLoad: !1,
              instrumentNavigation: !1,
            }),
            {
              useEffect: r,
              useLocation: a,
              useNavigationType: i,
              createRoutesFromChildren: o,
              matchRoutes: p,
              stripBasename: f,
              instrumentPageLoad: h = !0,
              instrumentNavigation: m = !0,
            } = e;
          return {
            ...n,
            setup() {
              (s = r), (l = a), (u = i), (d = p), (c = o), (o7 = f || !1);
            },
            afterAllSetup(e) {
              n.afterAllSetup(e);
              let r = e_ && e_.location && e_.location.pathname;
              h &&
                r &&
                nV(e, {
                  name: r,
                  attributes: {
                    [tX.Zj]: "url",
                    [tX.$J]: "pageload",
                    [tX.S3]: `auto.pageload.react.reactrouter_v${t}`,
                  },
                }),
                m && o8.add(e);
            },
          };
        }
        function sn(e, t) {
          if (!s || !l || !u || !d) return e;
          let n = !0,
            r = (r) => {
              let { routes: a, locationArg: i } = r,
                o = e(a, i),
                c = l(),
                d = u(),
                p = "string" == typeof i || (i && i.pathname) ? i : c;
              return (
                s(() => {
                  let e = "string" == typeof p ? { pathname: p } : p;
                  n ? (so(sl(), e, a), (n = !1)) : sr(e, a, d, t);
                }, [d, p]),
                o
              );
            };
          return (e, t) => tP.createElement(r, { routes: e, locationArg: t });
        }
        function sr(e, t, n, r, a, i) {
          let o = Array.isArray(a) ? a : d(t, e, i),
            s = (0, g.s3)();
          if (s && o8.has(s) && ("PUSH" === n || "POP" === n) && o) {
            let [n, a] = si(t, e, o, i);
            nY(s, {
              name: n,
              attributes: {
                [tX.Zj]: a,
                [tX.$J]: "navigation",
                [tX.S3]: `auto.navigation.react.reactrouter_v${r}`,
              },
            });
          }
        }
        function sa(e, t) {
          if (!t || "/" === t || !e.toLowerCase().startsWith(t.toLowerCase()))
            return e;
          let n = t.endsWith("/") ? t.length - 1 : t.length,
            r = e.charAt(n);
          return r && "/" !== r ? e : e.slice(n) || "/";
        }
        function si(e, t, n, r = "") {
          if (!e || 0 === e.length)
            return [o7 ? sa(t.pathname, r) : t.pathname, "url"];
          let a = "";
          if (n)
            for (let e of n) {
              let n = e.route;
              if (n) {
                var i, o, s;
                if (n.index)
                  return (function (e, t, n) {
                    let r = e || o7 ? sa(t, n) : t,
                      a =
                        "/" === r[r.length - 1]
                          ? r.slice(0, -1)
                          : "/*" === r.slice(-2)
                          ? r.slice(0, -1)
                          : r;
                    return [a, "route"];
                  })(a, e.pathname, r);
                let l = n.path;
                if (
                  l &&
                  ((i = e),
                  "*" !== l ||
                    !i.route.children ||
                    !(i.route.children.length > 0))
                ) {
                  let n = "/" === l[0] || "/" === a[a.length - 1] ? l : `/${l}`;
                  if (((a += n), r + e.pathname === t.pathname)) {
                    if (eU(a) !== eU(e.pathname) && "/*" !== a.slice(-2))
                      return [(o7 ? "" : r) + n, "route"];
                    return (
                      (o = a),
                      (s = e),
                      "/*" === o.slice(-2) &&
                        s.route.children &&
                        s.route.children.length > 0 &&
                        (a = a.slice(0, -1)),
                      [(o7 ? "" : r) + a, "route"]
                    );
                  }
                }
              }
            }
          return [o7 ? sa(t.pathname, r) : t.pathname, "url"];
        }
        function so(e, t, n, r, a) {
          let i = Array.isArray(r) ? r : d(n, t, a);
          if (i) {
            let [r, o] = si(n, t, i, a);
            (0, g.nZ)().setTransactionName(r),
              e && (e.updateName(r), e.setAttribute(tX.Zj, o));
          }
        }
        function ss(e, t) {
          if (!s || !l || !u || !c || !d) return e;
          let n = !0,
            r = (r) => {
              let a = l(),
                i = u();
              return (
                s(() => {
                  let e = c(r.children);
                  n ? (so(sl(), a, e), (n = !1)) : sr(a, e, i, t);
                }, [a, i]),
                tP.createElement(e, { ...r })
              );
            };
          return oB(r, e), r;
        }
        function sl() {
          let e = (0, q.HN)(),
            t = e ? (0, q.Gx)(e) : void 0;
          if (!t) return;
          let n = (0, q.XU)(t).op;
          return "navigation" === n || "pageload" === n ? t : void 0;
        }
        function su(e) {
          return st(e, "6");
        }
        function sc(e) {
          return sn(e, "6");
        }
        let sd = sc;
        function sp(e) {
          return se(e, "6");
        }
        let sf = sp;
        function sh(e) {
          return ss(e, "6");
        }
        function sm(e) {
          return st(e, "7");
        }
        function s_(e) {
          return ss(e, "7");
        }
        function sg(e) {
          return se(e, "7");
        }
        function sv(e) {
          return sn(e, "7");
        }
      },
    },
  ]);
