!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "c2b3b243-2eec-42c8-96d7-20e161b0b7ab"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-c2b3b243-2eec-42c8-96d7-20e161b0b7ab"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [22824, 94838],
    {
      54509: function (e, t, n) {
        "use strict";
        n.d(t, {
          V: function () {
            return B;
          },
          Z: function () {
            return j;
          },
        });
        var i = n(85893),
          r = n(67294),
          o = n(94838),
          s = n(39424),
          a = n(47210),
          l = n(74040),
          c = n(50319),
          u = n(73359),
          d = n(37899),
          h = n(26579),
          _ = n(23180),
          y = n(19167),
          x = n(8697),
          p = n(33209),
          m = n(92114),
          g = n(63922),
          C = n(1986),
          f = n(59039);
        let B = r.createContext({
            loginHasStarted: !1,
            setLoginHasStarted: () => {},
            setMessage: () => {},
            logout: async () => {},
            triggerLogin: async () => !0,
            loading: !1,
            setLoading: () => {},
          }),
          w = (e) => {
            let {
                setUser: t,
                setIsNewUser: n,
                setLoadingUser: w,
              } = r.useContext(l.S),
              { openDrawer: j } = r.useContext(_.s9),
              { locale: z } = r.useContext(x.Z),
              [v, F] = r.useState(!1),
              { analyticsService: b, crazyAnalyticsService: k } = r.useContext(
                d.Z
              ).services,
              { countryCode: Z } = r.useContext(h.Z),
              [D, L] = (0, r.useState)(),
              [S, M] = (0, r.useState)(!1),
              [P] = (0, c.D)(g.lX),
              [U] = (0, u.t)(g.Qt),
              [E] = (0, c.D)(g.ub),
              T = async (e) => {
                L(void 0),
                  y.Z.Instance.setItem(m.c, "true"),
                  y.Z.Instance.setItem(m.v, "true");
                let t = !1,
                  i = (0, a.gK)(e);
                if (i && i.isNewUser) {
                  n("yes"),
                    await U(),
                    Z &&
                      (await E({ variables: { input: { countryCode: Z } } })),
                    (t = !0);
                  let i = (function (e) {
                    for (let t of e.providerData)
                      if ("facebook.com" === t.providerId) return !0;
                    return !1;
                  })(e.user);
                  i && (await o.firebaseAuth.currentUser?.reload());
                } else n("no");
                return (
                  P(),
                  t
                    ? (j("authUsernameSelector"),
                      k.userAction("authentication", "auth_success", "new"),
                      b.trackSignIn(!0))
                    : (j(null),
                      k.userAction(
                        "authentication",
                        "auth_success",
                        "returning"
                      ),
                      b.trackSignIn(!1)),
                  !0
                );
              };
            (0, r.useEffect)(() => {
              let e = (0, a.Aj)(o.firebaseAuth, async (e) => {
                k.firebaseLoaded(!!o.firebaseAuth.currentUser),
                  e
                    ? ((0, C.YO)(e),
                      (0, s.av)({ id: e.uid }),
                      S &&
                        e?.metadata.lastSignInTime ===
                          e?.metadata.creationTime &&
                        (await U()),
                      t(e),
                      b.setUserLoggedIn(e.uid),
                      S || n("no"))
                    : (t(null), n("unknown"), (0, C.YO)(), (0, s.av)(null)),
                  w(!1);
              });
              return function () {
                e();
              };
            }, [t, n, S, b, w, k, U]),
              (0, r.useEffect)(() => {
                if (!z) return;
                let e = (0, p.xi)(z);
                o.firebaseAuth.languageCode = e;
              }, [z]);
            let I = {
              errorMessage: D,
              loading: v,
              setLoading: F,
              setMessage: L,
              triggerLogin: T,
              logout: f.k,
              loginHasStarted: S,
              setLoginHasStarted: M,
            };
            return (0, i.jsx)(B.Provider, { value: I, children: e.children });
          };
        var j = w;
      },
      94838: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            FACEBOOK_DOMAIN: function () {
              return h;
            },
            GOOGLE_DOMAIN: function () {
              return _;
            },
            facebookProvider: function () {
              return d;
            },
            firebaseAuth: function () {
              return c;
            },
            googleProvider: function () {
              return u;
            },
          });
        var i = n(25816),
          r = n(47210),
          o = n(46313),
          s = n(74864);
        let a = {
            apiKey: o.Z.Instance.data.firebase.apiKey,
            authDomain: o.Z.Instance.data.firebase.authDomain,
            projectId: o.Z.Instance.data.firebase.projectId,
            storageBucket: o.Z.Instance.data.firebase.storageBucket,
            messagingSenderId: o.Z.Instance.data.firebase.messagingSenderId,
            appId: o.Z.Instance.data.firebase.appId,
          },
          l = (0, i.ZF)(a),
          c = (0, s.initializeAuth)(l, {
            persistence: [s.browserLocalPersistence],
            popupRedirectResolver: s.browserPopupRedirectResolver,
            errorMap: s.prodErrorMap,
          }),
          u = new r.hJ(),
          d = new r._O(),
          h = "facebook.com",
          _ = "google.com";
      },
      25827: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return _;
          },
        });
        var i = n(85893),
          r = n(2734),
          o = n(67294),
          s = n(95914);
        let a = o.memo((e) =>
          (0, i.jsx)(s.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M16.7424 21.6699C16.3724 22.08 15.7401 22.1124 15.3301 21.7424L7.0186 14.2424C5.66045 13.0169 5.66046 10.9831 7.0186 9.75758L15.3301 2.25758C15.7401 1.88758 16.3724 1.92003 16.7424 2.33006C17.1124 2.74009 17.08 3.37242 16.6699 3.74241L8.35847 11.2424C7.8805 11.6737 7.8805 12.3263 8.35847 12.7576L16.6699 20.2576C17.08 20.6276 17.1124 21.2599 16.7424 21.6699Z",
            }),
          })
        );
        var l = n(43740),
          c = n(31601),
          u = n(23180),
          d = n(17305);
        let h = (e) => {
          let {
              onClose: t,
              onBack: n,
              title: s,
              subtitle: h,
              customTitleStyles: _,
              customLeftIcon: y,
            } = e,
            { openDrawer: x } = o.useContext(u.s9),
            { spacing: p } = (0, r.Z)();
          return (0, i.jsxs)(d.MU, {
            children: [
              (0, i.jsxs)(d.Zw, {
                children: [
                  y && y,
                  n &&
                    !y &&
                    (0, i.jsx)(c.Qh, {
                      color: "white",
                      onClick: n,
                      sx: { ml: 1 },
                      children: (0, i.jsx)(a, {}),
                    }),
                ],
              }),
              (0, i.jsxs)("div", {
                style: {
                  display: "flex",
                  width: "100%",
                  paddingLeft: p(),
                  paddingRight: p(),
                  zIndex: 1,
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                },
                children: [
                  (0, i.jsx)("h1", {
                    style: {
                      fontSize: 16,
                      whiteSpace: "nowrap",
                      textOverflow: "ellipsis",
                      overflow: "hidden",
                      textAlign: "center",
                      ..._,
                    },
                    children: s,
                  }),
                  h && (0, i.jsx)(d.TK, { children: h }),
                ],
              }),
              (0, i.jsx)(d.Zw, {
                children: (0, i.jsx)(c.Qh, {
                  color: "white",
                  onClick: t || (() => x(null)),
                  sx: { mr: 1 },
                  children: (0, i.jsx)(l.Z, {}),
                }),
              }),
            ],
          });
        };
        var _ = h;
      },
      4978: function (e, t, n) {
        "use strict";
        var i = n(85893),
          r = n(98456);
        n(67294);
        var o = n(3411);
        let s = () =>
          (0, i.jsx)("div", {
            style: {
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: "100%",
              height: "100%",
              backgroundColor: o.D.black[80],
              opacity: 0.7,
              position: "absolute",
              top: 0,
              left: 0,
              zIndex: 1,
            },
            children: (0, i.jsx)(r.Z, { style: { color: "white" }, size: 65 }),
          });
        t.Z = s;
      },
      34003: function (e, t, n) {
        "use strict";
        var i = n(85893),
          r = n(67294),
          o = n(54509),
          s = n(17305);
        let a = () => {
          let { errorMessage: e } = r.useContext(o.V);
          return e ? (0, i.jsx)(s.mU, { children: e }) : null;
        };
        t.Z = a;
      },
      79495: function (e, t, n) {
        "use strict";
        var i = n(85893),
          r = n(2734),
          o = n(67294),
          s = n(17305),
          a = n(25827),
          l = n(23180);
        let c = (e) => {
          let {
              title: t,
              onBack: n,
              children: c,
              contentPadding: u,
              fixHeader: d,
              customTitleStyles: h,
            } = e,
            _ = (0, r.Z)(),
            { openDrawer: y } = o.useContext(l.s9);
          return (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(a.Z, {
                onBack: n,
                onClose: () => {
                  y(null);
                },
                title: t,
                customTitleStyles: h,
              }),
              (0, i.jsx)("div", {
                style: {
                  display: "flex",
                  flexDirection: "row",
                  padding: _.spacing(2),
                  ...(d && { height: "100%", overflow: "hidden" }),
                },
                children: (0, i.jsx)(s.Ng, {
                  fixHeader: !!d,
                  contentPadding: u,
                  children: c,
                }),
              }),
            ],
          });
        };
        t.Z = c;
      },
      17305: function (e, t, n) {
        "use strict";
        n.d(t, {
          Bg: function () {
            return h;
          },
          Fd: function () {
            return p;
          },
          Hz: function () {
            return j;
          },
          I8: function () {
            return k;
          },
          Jn: function () {
            return y;
          },
          MU: function () {
            return g;
          },
          NF: function () {
            return D;
          },
          Ng: function () {
            return x;
          },
          Q4: function () {
            return v;
          },
          S$: function () {
            return z;
          },
          Sz: function () {
            return F;
          },
          TK: function () {
            return m;
          },
          X0: function () {
            return w;
          },
          Zw: function () {
            return C;
          },
          dA: function () {
            return M;
          },
          gu: function () {
            return f;
          },
          iI: function () {
            return S;
          },
          mH: function () {
            return B;
          },
          mU: function () {
            return b;
          },
          pU: function () {
            return L;
          },
          qt: function () {
            return Z;
          },
        });
        var i = n(66697),
          r = n(1011),
          o = n(6496),
          s = n(90948),
          a = n(41796),
          l = n(66836),
          c = n(72268),
          u = n(3411),
          d = n(32350);
        let h = 1200,
          _ = (e, t, n, s, a) => {
            let { palette: l, dimensions: c, spacing: h } = e,
              _ = t
                ? "99.9%"
                : a
                ? `calc(100% - ${c.header.height}px - ${h(2)})`
                : void 0,
              y = !t && a ? `calc(${c.header.height}px + ${h()})` : void 0;
            return {
              [`& .${i.Z.paper}`]: {
                width: t ? "100%" : c.drawer.width,
                maxWidth: n ? "375px" : void 0,
                overflow: "hidden overlay",
                background: l.primary.main,
                ...(0, d.no)(4),
                height: _,
                top: y,
                ...(t && { boxShadow: "none" }),
                scrollbarGutter: "stable",
                borderLeft: 0,
                ...(a && { marginRight: h(), borderRadius: 8 }),
              },
              ...(s && { [`&.${r.Z.root}`]: { zIndex: s } }),
              height: _,
              top: y,
              [`& .${o.Z.root}`]: { opacity: "0 !important" },
              "& hr": { width: "100%", borderColor: u.D.black[60] },
            };
          },
          y = (0, s.ZP)(c.ZP, {
            shouldForwardProp: (e) =>
              "isMobile" !== e && "zIndex" !== e && "underHeaderMode" !== e,
          })((e) => {
            let {
              theme: t,
              isMobile: n,
              isLandscape: i,
              zIndex: r,
              underHeaderMode: o,
            } = e;
            return { ..._(t, n, !!i, r, o) };
          }),
          x = (0, s.ZP)("div", {
            shouldForwardProp: (e) =>
              "fixHeader" !== e && "contentPadding" !== e,
          })((e) => {
            let {
              theme: { breakpoints: t },
              fixHeader: n,
              contentPadding: i,
            } = e;
            return {
              width: "100%",
              position: "relative",
              ...(n && { overflowY: "overlay", ...(0, d.no)(4) }),
              padding: i || 0,
              [t.up("sm")]: { padding: i || 2 },
            };
          }),
          p = (0, s.ZP)("h2")(() => ({
            fontSize: 20,
            fontWeight: 700,
            marginBlockEnd: 4,
          })),
          m = (0, s.ZP)("div")(() => ({
            fontSize: 16,
            fontWeight: 400,
            color: u.D.white[50],
            "& svg": { width: 20, height: 20, marginBottom: -3 },
          })),
          g = (0, s.ZP)("div")(() => ({
            width: "100%",
            height: 60,
            minHeight: 60,
            display: "flex",
            alignItems: "center",
            zIndex: 2,
          })),
          C = (0, s.ZP)("div")(() => ({
            zIndex: 2,
            minWidth: 56,
            "& svg": { width: 24, height: 24 },
          })),
          f = (0, s.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              position: "absolute",
              top: 0,
              right: 0,
              zIndex: 2,
              margin: t(),
            };
          }),
          B = (0, s.ZP)("div")(() => ({ fontSize: 24, fontWeight: 700 })),
          w = (0, s.ZP)("div")(() => ({
            fontSize: d.CH.h5,
            color: u.D.white[50],
            textAlign: "center",
          })),
          j = (0, s.ZP)("div")(() => ({
            fontSize: d.CH.button,
            fontWeight: 400,
            color: u.D.white[50],
            textAlign: "center",
          })),
          z = (0, s.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              marginTop: t(),
              padding: t(2),
              width: "100%",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              textAlign: "center",
            };
          }),
          v = (0, s.ZP)("div")((e) => {
            let { theme: t } = e;
            return {
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: "100%",
              padding: t.spacing(),
              ...(0, d.no)(4),
              [t.breakpoints.down("sm")]: {
                padding: 0,
                paddingBottom: t.spacing(),
              },
            };
          }),
          F = (0, s.ZP)("div")((e) => {
            let {
              theme: { palette: t, spacing: n },
            } = e;
            return {
              color: t.secondary.contrastText,
              fontSize: d.CH.button,
              fontWeight: 700,
              display: "flex",
              "& a": {
                marginLeft: n(2),
                color: u.D.brand[80],
                "&:hover": {
                  cursor: "pointer",
                  color: (0, a._j)(u.D.brand[80], 0.2),
                },
              },
            };
          }),
          b = (0, s.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              textAlign: "center",
              marginLeft: t(-1),
              padding: t(1.5),
              color: u.D.alert[100],
              fontWeight: 700,
            };
          }),
          k = (0, s.ZP)(l.Z)((e) => {
            let {
              theme: { palette: t, spacing: n },
            } = e;
            return {
              color: t.primary.contrastText,
              marginRight: 0,
              marginBottom: n(),
              "& a": (0, d.GC)(),
              "& span": { fontSize: "0.8em", fontFamily: d.I8 },
            };
          }),
          Z = (0, s.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              overflowY: "auto",
              overflowX: "hidden",
              display: "flex",
              ...(0, d.no)(4),
              paddingTop: t(),
            };
          }),
          D = (0, s.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              fontSize: d.CH.button,
              textAlign: "center",
              color: u.D.white[50],
              marginBottom: t(2),
            };
          }),
          L = (0, s.ZP)("label")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "block",
              fontSize: 16,
              fontWeight: 700,
              color: u.D.white[80],
              marginTop: t(1.5),
              marginBottom: t(1.5),
            };
          }),
          S = (0, s.ZP)("div")({
            fontWeight: 900,
            fontSize: 16,
            color: u.D.white[100],
          }),
          M = (0, s.ZP)("div")({
            fontWeight: 400,
            fontSize: 14,
            color: u.D.white[60],
          });
      },
      79282: function (e, t, n) {
        "use strict";
        var i = n(85893),
          r = n(67294),
          o = n(95914);
        let s = r.memo((e) =>
          (0, i.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4ZM2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM12 7C12.5523 7 13 7.44772 13 8V11.5858L15.7071 14.2929C16.0976 14.6834 16.0976 15.3166 15.7071 15.7071C15.3166 16.0976 14.6834 16.0976 14.2929 15.7071L11.2929 12.7071C11.1054 12.5196 11 12.2652 11 12V8C11 7.44772 11.4477 7 12 7Z",
            }),
          })
        );
        t.Z = s;
      },
      29874: function (e, t, n) {
        "use strict";
        var i = n(85893),
          r = n(67294),
          o = n(95914);
        let s = r.memo((e) =>
          (0, i.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M10.1051 3.90453C10.1051 2.84042 10.9755 2 12.0215 2H12.1183C13.7773 2 15.1446 3.33088 15.1446 5V9H18.9711C21.2014 9 22.6959 11.3321 21.6755 13.3463L18.1295 20.3463C17.6137 21.3646 16.5645 22 15.4251 22H11.3546C11.1082 22 10.8627 21.9702 10.6236 21.9112L6.93101 21H5.02628C3.36726 21 2 19.6691 2 18V12C2 10.3309 3.36726 9 5.02628 9H7.19669L9.66081 5.35177C9.95107 4.92203 10.1051 4.41848 10.1051 3.90453ZM6.05257 11H5.02628C4.44713 11 4 11.46 4 12V18C4 18.54 4.44713 19 5.02628 19H6.05257V11ZM8.05257 19.2168V11.3061L11.3182 6.47121C11.8129 5.73871 12.0857 4.88122 12.1041 4H12.1183C12.6974 4 13.1446 4.45998 13.1446 5V9H12.1183C11.566 9 11.1183 9.44772 11.1183 10C11.1183 10.5523 11.566 11 12.1183 11H18.9711C19.7534 11 20.2183 11.7971 19.8914 12.4425L16.3454 19.4425C16.1747 19.7794 15.8207 20 15.4251 20H11.3546C11.2696 20 11.185 19.9897 11.1027 19.9694L8.05257 19.2168Z",
            }),
          })
        );
        t.Z = s;
      },
      2490: function (e, t, n) {
        "use strict";
        var i = n(37899),
          r = n(1982),
          o = n(72552),
          s = n(67294);
        let a = () => {
          let { crazyAnalyticsService: e } = (0, s.useContext)(i.Z).services,
            t = (0, s.useContext)(r.t),
            n = (0, o.Z)(t),
            a = (0, s.useCallback)(
              (t) => {
                e.sendModalEvent("with_friends_learn_more", t, "learn_more", n);
              },
              [e, n]
            );
          return a;
        };
        t.Z = a;
      },
      23500: function (e, t, n) {
        "use strict";
        var i = n(32350),
          r = n(46413),
          o = n(44038);
        async function s(e) {
          if (r.Z.isFullscreen()) return;
          let t = await e.getUserInfo(),
            s = (0, o.T)(
              t?.device,
              !!window.__NEXT_DATA__.props.forceIpad,
              !!window.__NEXT_DATA__.props.forceAndroidTablet
            );
          if (s.isLowEndDevice) return;
          let a = await n.e(39883).then(n.bind(n, 39883)),
            l = a.create(void 0, { resize: !0, useWorker: !0 });
          l({
            particleCount: 100,
            angle: 60,
            spread: 65,
            origin: { x: 0 },
            colors: i.eI,
            zIndex: 1305,
          }),
            l({
              particleCount: 100,
              angle: 120,
              spread: 65,
              origin: { x: 1 },
              colors: i.eI,
              zIndex: 1305,
            });
        }
        t.Z = s;
      },
      24086: function (e, t, n) {
        "use strict";
        var i = n(85893),
          r = n(98456);
        n(67294);
        var o = n(3411),
          s = n(31601);
        let a = (e) => {
          let { loading: t = !1, children: n, ...a } = e;
          return t
            ? (0, i.jsx)(s.V$, {
                ...a,
                disabled: !0,
                variant: "contained",
                color: "grey",
                children: (0, i.jsx)(r.Z, {
                  id: "loadingSpinner",
                  disableShrink: !0,
                  size: 16,
                  variant: "indeterminate",
                  sx: { color: o.D.white[40] },
                }),
              })
            : (0, i.jsx)(s.Sn, { variant: "contained", ...a, children: n });
        };
        t.Z = a;
      },
      42381: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return c;
          },
        });
        var i = n(85893);
        n(67294);
        var r = n(90512),
          o = n(9979),
          s = n.n(o);
        let a = (e) => {
            let {
              id: t,
              isMultiline: n,
              error: o,
              value: a,
              rowsNo: l,
              type: c,
              readOnly: u,
              autoComplete: d,
              autoFocus: h,
              required: _,
              label: y,
              onChange: x,
              className: p,
            } = e;
            return (0, i.jsxs)(i.Fragment, {
              children: [
                n
                  ? (0, i.jsx)("textarea", {
                      id: t,
                      className: (0, r.Z)(
                        s().textField,
                        s().isTextarea,
                        y && s().hasLabel,
                        o && s().hasError,
                        p
                      ),
                      required: _,
                      rows: l,
                      value: a,
                      readOnly: u,
                      autoComplete: d,
                      autoFocus: h,
                      placeholder: " ",
                      onChange: x,
                    })
                  : (0, i.jsx)("input", {
                      id: t,
                      className: (0, r.Z)(
                        s().textField,
                        y && s().hasLabel,
                        o && s().hasError,
                        p
                      ),
                      required: _,
                      readOnly: u,
                      autoComplete: d,
                      autoFocus: h,
                      type: c,
                      value: a,
                      placeholder: " ",
                      onChange: x,
                    }),
                y && (0, i.jsx)("label", { className: s().label, children: y }),
              ],
            });
          },
          l = (e) => {
            let {
              label: t,
              type: n,
              multiline: o,
              rows: l,
              onChange: c,
              onClick: u,
              value: d,
              error: h,
              readOnly: _,
              id: y,
              helperText: x,
              autoComplete: p,
              autoFocus: m,
              required: g,
              className: C,
            } = e;
            return (0, i.jsxs)("div", {
              className: (0, r.Z)(s().wrapper, u && s().hasOnClick),
              onClick: u,
              children: [
                (0, i.jsx)(a, {
                  id: y,
                  className: C,
                  autoFocus: m,
                  value: d,
                  onChange: c,
                  label: t,
                  type: n,
                  isMultiline: o,
                  rowsNo: l,
                  readOnly: _,
                  autoComplete: p,
                  required: g,
                  error: h,
                }),
                x &&
                  (0, i.jsx)("div", {
                    style: {
                      fontSize: 12,
                      textAlign: "left",
                      paddingTop: 4,
                      paddingLeft: 2,
                      opacity: 0.7,
                    },
                    children: x,
                  }),
              ],
            });
          };
        var c = l;
      },
      66511: function (e, t, n) {
        "use strict";
        n.d(t, {
          Y: function () {
            return c;
          },
          i: function () {
            return u;
          },
        });
        var i = n(79136),
          r = n(90852),
          o = n(40044),
          s = n(90948),
          a = n(3411),
          l = n(32350);
        let c = (0, s.ZP)(i.Z)((e) => {
            let {
              theme: { palette: t, spacing: n },
            } = e;
            return {
              height: 40,
              justifyContent: "space-around",
              padding: n(0, 3),
              borderBottom: `1px solid ${a.D.black[50]}`,
              [`& .${r.Z.indicator}`]: {
                backgroundColor: t.secondary.main,
                height: 3,
                borderRadius: 4,
              },
            };
          }),
          u = (0, s.ZP)(o.Z)((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginBottom: t(),
              textTransform: "capitalize",
              fontSize: l.CH.body,
              fontWeight: 700,
              color: a.D.white[10],
              flex: 1,
              "&.Mui-selected": { color: a.D.white[100] },
              "&.Mui-focusVisible": {
                backgroundColor: "rgba(100, 95, 228, 0.32)",
              },
              "&:hover:not(.Mui-selected)": { color: a.D.white[30] },
            };
          });
      },
      43016: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return v;
          },
        });
        var i = n(85893),
          r = n(94745),
          o = n(67294);
        let s =
          "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        async function a() {
          let { adjectives: e, nouns: t } = await n
              .e(50295)
              .then(n.t.bind(n, 50295, 19)),
            i = e[Math.floor(Math.random() * e.length)],
            r = t[Math.floor(Math.random() * t.length)],
            o = (function () {
              let e = "",
                t = s.length;
              for (let n = 0; n < 4; n++)
                e += s.charAt(Math.floor(Math.random() * t));
              return e;
            })(),
            a = `${i}${r}.${o}`;
          return { adjective: i, noun: r, rnd: o, username: a };
        }
        var l = n(3411),
          c = n(24086),
          u = n(46313);
        let d = u.Z.Instance.data.minimumPlayStreakForUsername ?? 2;
        var h = n(2734),
          _ = n(83514),
          y = n(13592),
          x = n(82702),
          p = n(88296),
          m = n(42381),
          g = n(11264),
          C = n.n(g),
          f = n(4388),
          B = n(75007),
          w = n(23180),
          j = n(63306);
        let z = (e) => {
          let {
              onUsernameUpdate: t,
              onUsernameGenerate: n,
              isUserRegistering: s,
            } = e,
            { data: u, loading: g } = x._W(),
            z = u?.statProfile,
            [v, { loading: F }] = x.Fl(),
            [b, { loading: k }] = x.js(),
            [Z, D] = o.useState(null),
            [L, S] = (0, o.useState)(!1),
            [M, P] = (0, o.useState)(!1),
            [U, E] = (0, o.useState)(""),
            [T, I] = (0, o.useState)(""),
            { i18n: G } = (0, r.mV)(),
            { spacing: W } = (0, h.Z)(),
            { pageUrlHelper: H } = o.useContext(_.t),
            { crazyRouterChange: A } = o.useContext(y.R),
            N = z && z?.playStreak >= d,
            { openDrawer: O } = o.useContext(w.s9),
            R = o.useContext(j.Z).routeHelper,
            V = H.isProfilePage();
          (0, o.useEffect)(() => {
            u?.username && I(u.username);
          }, [u?.username]);
          let q = async () => {
              let e = T;
              if (s && T === u?.username) {
                t?.();
                return;
              }
              if (T.length < 6) {
                E(
                  G._({
                    id: "common.upDrawer.changeUsername.error.tooShort",
                    values: { minLength: 6 },
                  })
                );
                return;
              }
              if (
                (function (e) {
                  if (!/^[a-zA-Z0-9._]+$/.test(e)) return !0;
                  let t = (e.match(/[\.\_]/g) || []).length >= 5;
                  if (t) return !0;
                  let n = e.match(/[\.\_]{2}/);
                  return !!n;
                })(T)
              ) {
                E(
                  G._({
                    id: "common.upDrawer.changeUsername.error.invalidCharacters",
                  })
                );
                return;
              }
              try {
                if (N) await v(T);
                else if (Z) {
                  let { username: t, ...n } = Z;
                  (e = t), await b(n.noun, n.adjective, n.rnd);
                }
                V &&
                  (A(R.profilePageLink(e).as, void 0, void 0, !0),
                  O("editProfile", { isExiting: !0 })),
                  P(!0),
                  t?.();
              } catch (t) {
                let e = t?.graphQLErrors?.[0]?.extensions?.code;
                switch (e) {
                  case "usernameViolatesGuidelines":
                    E(
                      G._({
                        id: "common.upDrawer.changeUsername.error.violatesGuidelines",
                      })
                    );
                    break;
                  case "usernameInUse":
                    E(
                      G._({
                        id: "common.upDrawer.changeUsername.error.usernameTaken",
                      })
                    );
                    break;
                  case "usernameNotValid":
                    E(
                      G._({
                        id: "common.upDrawer.changeUsername.error.notValid",
                      })
                    );
                    break;
                  case "usernameRateLimitExceeded":
                    E(
                      G._({
                        id: "common.upDrawer.changeUsername.error.rateLimitExceeded",
                      })
                    );
                    break;
                  case "usernameChangeStrike":
                    E(
                      G._({
                        id: "common.upDrawer.changeUsername.error.usernameChangeStrike",
                      })
                    );
                    break;
                  default:
                    E(
                      G._({
                        id: "common.upDrawer.changeUsername.error.unkownError",
                      })
                    );
                }
              }
            },
            K = (e) => {
              let t = e.currentTarget.value.slice(0, 20);
              E(""), P(!1), I(t);
            },
            Q = async () => {
              if (L) return;
              S(!0);
              let e = await a();
              D(e), I(e.username.slice(0, 20)), S(!1), E(""), P(!1), n?.();
            };
          return g
            ? (0, i.jsx)(i.Fragment, {})
            : (0, i.jsxs)("div", {
                style: {
                  display: "flex",
                  flexDirection: "column",
                  gap: W(2),
                  textAlign: "center",
                  width: "100%",
                },
                children: [
                  s &&
                    (0, i.jsx)("div", {
                      style: {
                        fontSize: 14,
                        fontWeight: 400,
                        color: l.D.white[50],
                      },
                      children: (0, i.jsx)(r.cC, {
                        id: "auth.ui.usernameConfirm.reminderText",
                        values: {
                          icon: (0, i.jsx)(f.Z, {
                            sx: {
                              width: 19,
                              height: 19,
                              position: "relative",
                              top: 4,
                            },
                          }),
                        },
                      }),
                    }),
                  N
                    ? (0, i.jsxs)(i.Fragment, {
                        children: [
                          (0, i.jsx)(m.Z, { value: T, onChange: K }),
                          (0, i.jsxs)("div", {
                            style: {
                              display: "flex",
                              justifyContent: "center",
                            },
                            children: [
                              (0, i.jsx)(r.cC, {
                                id: "common.upDrawer.changeUsername.noIdea",
                              }),
                              (0, i.jsx)(p.Z, {
                                onClick: Q,
                                className: C().generateOneButton,
                                children: (0, i.jsx)(r.cC, {
                                  id: "common.upDrawer.changeUsername.generateOne",
                                }),
                              }),
                            ],
                          }),
                        ],
                      })
                    : (0, i.jsx)("div", {
                        style: {
                          background: "#0000004D",
                          borderRadius: 10,
                          outline: "1px solid #FFFFFF33",
                        },
                        children: (0, i.jsxs)("div", {
                          style: {
                            fontSize: 16,
                            color: l.D.white[80],
                            userSelect: "none",
                            height: 60,
                            display: "flex",
                            justifyContent: "left",
                            alignItems: "center",
                            marginLeft: 16,
                          },
                          children: [
                            T,
                            (0, i.jsx)(f.Z, {
                              onClick: Q,
                              sx: {
                                position: "absolute",
                                right: 16,
                                color: l.D.brand[60],
                                cursor: "pointer",
                              },
                            }),
                          ],
                        }),
                      }),
                  !!U &&
                    (0, i.jsx)("div", {
                      style: { color: l.D.alert[100] },
                      children: U,
                    }),
                  !s &&
                    M &&
                    (0, i.jsx)("div", {
                      style: { color: l.D.success[100] },
                      children: (0, i.jsx)(r.cC, {
                        id: "common.upDrawer.changeUsername.usernameUpdated",
                      }),
                    }),
                  (0, i.jsx)(c.Z, {
                    disabled: s ? !!U : !!U || T === u?.username,
                    loading: F || k,
                    onClick: q,
                    height: 50,
                    sx: { width: "100%" },
                    children: s
                      ? (0, i.jsx)(r.cC, { id: "auth.ui.button.continue" })
                      : (0, i.jsx)(r.cC, {
                          id: "common.upDrawer.changeUsername.saveUsername",
                        }),
                  }),
                  !N &&
                    (0, i.jsxs)("div", {
                      style: {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        gap: 6,
                      },
                      children: [
                        (0, i.jsx)("img", {
                          style: { width: 27, height: 38 },
                          src: (0, B.ZP)("icon/UnlockCustomIcon.svg", {}, !1),
                          loading: "lazy",
                          alt: "Unlock custom icon",
                        }),
                        (0, i.jsxs)("div", {
                          style: { textAlign: "start" },
                          children: [
                            (0, i.jsx)(r.cC, {
                              id: "common.upDrawer.changeUsername.wantYourOwnDesc",
                            }),
                            (0, i.jsx)("div", {
                              style: { color: "#FFC32C", fontWeight: 700 },
                              children: (0, i.jsx)(r.cC, {
                                id: "common.upDrawer.changeUsername.wantYourOwnHighlight",
                              }),
                            }),
                          ],
                        }),
                      ],
                    }),
                  N &&
                    (0, i.jsx)("div", {
                      style: {
                        color: l.D.white[10],
                        fontSize: 12,
                        textAlign: "left",
                      },
                      children: (0, i.jsx)(r.cC, {
                        id: "common.upDrawer.changeUsername.info",
                        values: {
                          permanentlyBan: (0, i.jsx)("strong", {
                            children: (0, i.jsx)("u", {
                              children: (0, i.jsx)(r.cC, {
                                id: "common.upDrawer.changeUsername.permanentlyBan",
                              }),
                            }),
                          }),
                          maxLength: 20,
                          minLength: 6,
                        },
                      }),
                    }),
                ],
              });
        };
        var v = z;
      },
      22824: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return tS;
            },
          });
        var i = n(85893),
          r = n(5152),
          o = n.n(r),
          s = n(67294),
          a = n(74040),
          l = n(34769),
          c = n(47210),
          u = n(94838),
          d = n(54509),
          h = n(46313),
          _ = n(26579),
          y = n(3708),
          x = n(69626),
          p = n(95129),
          m = n(19167),
          g = n(83514),
          C = n(42257),
          f = n(3992),
          B = n(58752),
          w = n(37899);
        let j = !1,
          z = () => {
            let {
                triggerLogin: e,
                setLoginHasStarted: t,
                setLoading: n,
                setMessage: i,
              } = (0, s.useContext)(d.V),
              { user: r, loadingUser: o } = (0, s.useContext)(a.S),
              { isMobile: z } = (0, s.useContext)(C.Z),
              { countryCode: v } = s.useContext(_.Z),
              { services: F } = s.useContext(w.Z),
              {
                isFirefox: b,
                isSafari: k,
                isChrome: Z,
                isIos: D,
              } = s.useContext(p.Z),
              { pageUrlHelper: L } = s.useContext(g.t),
              [S, M] = s.useState(!1);
            return (
              s.useEffect(() => {
                if (!v) return;
                let e = () => {
                    M(!0);
                  },
                  t = (0, y.Z)(v, L),
                  n = (0, x.a)();
                return (
                  t ? n.addConsentListener(e) : M(!0),
                  () => {
                    n.removeConsentListener(e);
                  }
                );
              }, [v, L]),
              s.useEffect(() => {
                if (j || o || r || !S) return;
                let s = async (r) => {
                    try {
                      n(!0), t(!0);
                      let i = r.credential,
                        o = c.hJ.credential(i);
                      F.crazyAnalyticsService.userAction(
                        "authentication",
                        "auth_started",
                        "one-tap"
                      );
                      let s = await (0, c.sB)(u.firebaseAuth, o);
                      await e(s), m.Z.Instance.removeItem(f.D);
                    } catch (t) {
                      let e = "Something went wrong";
                      t instanceof Error && t.message
                        ? (e = t.message)
                        : "string" == typeof t && t && (e = t),
                        F.crazyAnalyticsService.userAction(
                          "authentication",
                          "auth_failed",
                          "one-tap," + e.slice(0, 100)
                        ),
                        console.error("handleCredentialResponse Error", t),
                        i(e);
                    } finally {
                      n(!1);
                    }
                  },
                  a = () => {
                    let e = m.Z.Instance.getItem(f.D);
                    if (!e) return !0;
                    let t = Number(e),
                      n = new Date().getTime();
                    return n > t;
                  },
                  d = async () => {
                    await (0, l.Z)(
                      "https://accounts.google.com/gsi/client",
                      !0
                    );
                    let { google: e } = window;
                    void 0 !== e &&
                      (e.accounts.id.initialize({
                        client_id: h.Z.Instance.data.firebase.googleClientId,
                        callback: s,
                        cancel_on_tap_outside: !0,
                        auto_select: a(),
                        use_fedcm_for_prompt: !0,
                      }),
                      e.accounts.id.prompt());
                  };
                ((!b && !k && (!Z || !D) && !z) || (0, B.OQ)()) && d(),
                  (j = !0);
              }, [n, e, r, o, S, b, k, Z, D, z, F, i, t]),
              null
            );
          };
        var v = n(66252),
          F = n(50319),
          b = n(25689),
          k = n(13422);
        let Z = () => {
          let e = (0, v.x)(),
            [t, n] = s.useState(!1),
            [i, r] = s.useState(!1),
            { user: o, isNewUser: l } = s.useContext(a.S),
            { recent: c } = s.useContext(k.rh),
            [u, { data: d }] = (0, F.D)(b.ro),
            [h, { data: _ }] = (0, F.D)(b.gP),
            y = () => {
              let e = m.Z.Instance,
                t = e
                  .getAllKeys()
                  .filter((e) => e.startsWith("vote-"))
                  .map((e) => e.slice(5, e.length));
              return t;
            };
          return (
            s.useEffect(() => {
              if (o && d && !i) {
                if ((r(!0), 0 === c.length)) return;
                let t = c.map((e) => ({
                  id: e.id || "",
                  name: e.name,
                  slug: e.slug,
                  cover: e.cover,
                  videos: e.videos,
                  status: "PUBLISHED",
                  iosFriendly: !!e.mobileFriendly,
                  androidFriendly: !!e.mobileFriendly,
                  mobileFriendly: e.mobileFriendly,
                  gameThumbLabels: [],
                  playedTime: null,
                  __typename: "UserGame",
                }));
                e?.cache.updateQuery({ query: b.Gv }, (e) => ({
                  me: {
                    id: o.uid,
                    recentGames: [...(e?.me?.recentGames || []), ...t],
                    __typename: "User",
                  },
                }));
              }
            }, [o, d, i, e, c]),
            s.useEffect(() => {
              if (o && _?.addUserLikedGames && !t) {
                n(!0);
                let t = _.addUserLikedGames;
                e?.cache.updateQuery({ query: b.QA }, (e) => {
                  let n = t.map((e) => ({ ...e, __typename: "UserGame" }));
                  return {
                    me: {
                      id: o.uid,
                      likedGames: e ? [...(e?.me?.likedGames || []), ...n] : n,
                      __typename: "User",
                    },
                  };
                });
              }
            }, [o, _, t, e]),
            s.useEffect(() => {
              let t = async () => {
                  let t = e.readQuery({ query: b.Gv });
                  if (!t?.me?.recentGames)
                    try {
                      if (0 === c.length) return;
                      u({
                        variables: {
                          input: { games: c.map((e) => ({ slug: e.slug })) },
                        },
                      });
                    } catch (e) {
                      console.error("Recent games sync error: ", e);
                    }
                },
                n = async () => {
                  let t = e.readQuery({ query: b.QA });
                  if (!t?.me.likedGames)
                    try {
                      let e = y();
                      if (0 === e.length) return;
                      h({
                        variables: {
                          input: { games: e.map((e) => ({ slug: e })) },
                        },
                      });
                    } catch (e) {
                      console.error("Liked games sync error: ", e);
                    }
                };
              o &&
                "yes" === l &&
                e &&
                Promise.all([t(), n()]).catch((e) => {
                  console.error(e);
                });
            }, [c, u, h, l, o, e]),
            null
          );
        };
        var D = n(23180),
          L = n(17305),
          S = n(94745),
          M = n(2734),
          P = n(21519),
          U = n(43740),
          E = n(31601),
          T = n(4978),
          I = n(34003),
          G = n(90948);
        let W = (0, G.ZP)("div")(() => ({
            position: "relative",
            width: "100%",
            height: "100%",
            "& button": { width: "100%" },
          })),
          H = (0, G.ZP)("div", {
            shouldForwardProp: (e) => "isMobile" !== e && "sx" !== e,
          })((e) => {
            let {
              theme: { spacing: t, dimensions: n },
              isMobile: i,
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              alignContent: "center",
              alignItems: "center",
              padding: t(2),
              paddingTop: t(7),
              paddingBottom: i ? n.mobileBottom.drawerPlaceholder : 0,
            };
          });
        var A = n(24086),
          N = n(42381),
          O = n(89555),
          R = n(70768),
          V = n(12959),
          q = n(80822),
          K = n(88296),
          Q = n(90512),
          X = n(99439),
          Y = n.n(X);
        let $ = (e) => {
            let { i18n: t } = (0, S.mV)(),
              {
                triggerLogin: n,
                setLoginHasStarted: i,
                setMessage: r,
                setLoading: o,
              } = (0, s.useContext)(d.V),
              { crazyAnalyticsService: a } = (0, s.useContext)(w.Z).services,
              l = null;
            return async () => {
              try {
                o(!0),
                  i(!0),
                  a.userAction("authentication", "auth_started", e.providerId);
                let t = await (0, c.rh)(u.firebaseAuth, e);
                await n(t);
              } catch (n) {
                l = n;
                let e = (0, R.r)(n, t);
                e && r(e),
                  a.userAction("authentication", "auth_failed", n?.code);
              } finally {
                o(!1);
              }
              return l ? { error: l } : { success: !0 };
            };
          },
          J = (e) => {
            let { icon: t, provider: n, service: r, onClick: o } = e,
              { loading: a } = (0, s.useContext)(d.V),
              l = $(n);
            return (0, i.jsxs)(K.Z, {
              onClick: o || l,
              disabled: a,
              className: (0, Q.Z)(
                Y().authButton,
                "Facebook" === r && Y().isFacebook
              ),
              height: 40,
              children: [
                t,
                (0, i.jsx)(q.Z, {
                  sx: { ml: 0.5 },
                  children: (0, i.jsx)(S.cC, {
                    id: "auth.ui.login.socialBtn",
                    values: { service: r },
                  }),
                }),
              ],
            });
          };
        var ee = n(31555),
          et = n.n(ee);
        let en = (e) => {
            let { preSelectedEmail: t } = e,
              { openDrawer: n } = s.useContext(D.s9),
              { spacing: r } = (0, M.Z)(),
              [o, a] = (0, s.useState)(t ?? ""),
              l = (e) => a(e.target.value),
              {
                loading: h,
                setLoading: _,
                setMessage: y,
              } = (0, s.useContext)(d.V),
              { crazyAnalyticsService: x } = (0, s.useContext)(w.Z).services,
              p = $(u.facebookProvider),
              m = $(u.googleProvider),
              g = (e, t) => {
                if ("Google" === t) {
                  n("signInGoogle");
                  return;
                }
                e &&
                  "auth/popup-blocked" === e.code &&
                  y(
                    O.ag._(
                      "auth.ui.error.accountExistsWithDifferentCredential",
                      { provider: t }
                    )
                  );
              },
              C = async (e) => {
                _(!0);
                try {
                  e.preventDefault();
                  let t = await (0, c.Nr)(u.firebaseAuth, o),
                    i = t[0] || null;
                  switch (i) {
                    case "password":
                      n("signInEmail", { params: { preSelectedEmail: o } }),
                        x.userAction("authentication", "auth_started", "mail");
                      break;
                    case null:
                      n("signUpEmail", { params: { preSelectedEmail: o } }),
                        x.userAction("authentication", "auth_started", "mail");
                      break;
                    case u.GOOGLE_DOMAIN: {
                      u.googleProvider.setCustomParameters({
                        prompt: "select_account",
                        login_hint: o,
                      });
                      let { error: e } = await m();
                      g(e, "Google");
                      break;
                    }
                    case u.FACEBOOK_DOMAIN: {
                      let { error: e } = await p();
                      g(e, "Facebook");
                    }
                  }
                } finally {
                  _(!1);
                }
              };
            return (0, i.jsx)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                alignItems: "flex-start",
                flexDirection: "column",
                width: "100%",
              },
              children: (0, i.jsx)("div", {
                style: { width: "100%" },
                children: (0, i.jsxs)("form", {
                  onSubmit: C,
                  noValidate: !0,
                  style: { display: "flex", flexDirection: "column", gap: r() },
                  children: [
                    (0, i.jsx)(N.Z, {
                      required: !0,
                      label: O.ag._({ id: "auth.ui.label.enteremail" }),
                      onChange: l,
                      type: "email",
                      value: o,
                    }),
                    (0, i.jsx)("div", {
                      style: { marginTop: r(2) },
                      children: (0, i.jsx)(A.Z, {
                        type: "submit",
                        height: 50,
                        variant: "contained",
                        sx: { width: 1 },
                        disabled: !(0, V.o)(o) || h,
                        children: (0, i.jsx)(S.cC, {
                          id: "auth.ui.button.continue",
                        }),
                      }),
                    }),
                  ],
                }),
              }),
            });
          },
          ei = (e) => {
            let { preSelectedEmail: t } = e,
              { spacing: n } = (0, M.Z)(),
              [r, o] = (0, s.useState)(t || ""),
              [a, l] = (0, s.useState)(""),
              {
                setMessage: h,
                triggerLogin: _,
                setLoginHasStarted: y,
                loading: x,
                setLoading: p,
              } = (0, s.useContext)(d.V),
              { openDrawer: m } = s.useContext(D.s9),
              { crazyAnalyticsService: g } = (0, s.useContext)(w.Z).services,
              C = (e) => o(e.target.value),
              f = (e) => l(e.target.value),
              B = (e) => {
                let t = (0, R.r)(e, O.ag);
                return (
                  t ||
                  (e && e.message
                    ? e.message
                    : O.ag._({ id: "auth.ui.error.generic" }))
                );
              },
              j = async (e) => {
                e.preventDefault();
                try {
                  p(!0), y(!0);
                  let e = await (0, c.e5)(u.firebaseAuth, r, a),
                    t = await _(e);
                  t && m(null);
                } catch (t) {
                  let e = B(t);
                  h(e),
                    console.error(t),
                    g.userAction("authentication", "auth_failed", t?.code);
                } finally {
                  p(!1);
                }
              },
              z = () => {
                m("passwordReset", { params: { preSelectedEmail: r } });
              };
            return (0, i.jsx)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                alignItems: "flex-start",
                flexDirection: "column",
                width: "100%",
              },
              children: (0, i.jsx)("div", {
                style: { width: "100%" },
                children: (0, i.jsxs)("form", {
                  onSubmit: j,
                  noValidate: !0,
                  style: { display: "flex", flexDirection: "column", gap: n() },
                  children: [
                    (0, i.jsx)(N.Z, {
                      required: !0,
                      value: t || r,
                      readOnly: !!t,
                      label: O.ag._({ id: "auth.ui.label.email" }),
                      onChange: C,
                      type: "email",
                    }),
                    (0, i.jsx)(N.Z, {
                      required: !0,
                      type: "password",
                      label: O.ag._({ id: "auth.ui.label.password" }),
                      onChange: f,
                      autoComplete: "false",
                      autoFocus: !0,
                    }),
                    (0, i.jsx)(K.Z, {
                      type: "button",
                      onClick: z,
                      color: "purple",
                      className: et().forgotPasswordButton,
                      children: (0, i.jsx)(S.cC, {
                        id: "auth.ui.forgotPassword",
                      }),
                    }),
                    (0, i.jsx)("div", {
                      style: { marginTop: n(2) },
                      children: (0, i.jsx)(A.Z, {
                        type: "submit",
                        height: 50,
                        variant: "contained",
                        sx: { width: 1 },
                        disabled: !(r.length > 0 && a.length >= R.l) || x,
                        children: (0, i.jsx)(S.cC, {
                          id: "auth.ui.button.login",
                        }),
                      }),
                    }),
                  ],
                }),
              }),
            });
          },
          er = (e) => {
            let { customStyle: t } = e;
            return (0, i.jsx)("svg", {
              version: "1.1",
              enableBackground: "new 0 0 19 19",
              style: t,
              id: "Layer_1",
              xmlns: "http://www.w3.org/2000/svg",
              xmlnsXlink: "http://www.w3.org/1999/xlink",
              x: 0,
              y: 0,
              viewBox: "0 0 19 19",
              xmlSpace: "preserve",
              children: (0, i.jsxs)("g", {
                id: "logo_googleg_48dp",
                transform: "translate(15.000000, 15.000000)",
                children: [
                  (0, i.jsx)("path", {
                    id: "Shape",
                    className: "st0",
                    fill: "#4285F4",
                    d: "M3.31-5.13c0-0.64-0.06-1.25-0.16-1.84h-8.48v3.48h4.84c-0.21,1.12-0.84,2.08-1.8,2.72v2.26h2.91 C2.32-0.08,3.31-2.39,3.31-5.13L3.31-5.13z",
                  }),
                  (0, i.jsx)("path", {
                    id: "Shape_1_",
                    className: "st1",
                    fill: "#34A853",
                    d: "M-5.33,3.67c2.43,0,4.47-0.81,5.96-2.18l-2.91-2.26c-0.81,0.54-1.84,0.86-3.05,0.86 c-2.34,0-4.33-1.58-5.04-3.71h-3.01v2.33C-11.9,1.65-8.85,3.67-5.33,3.67L-5.33,3.67z",
                  }),
                  (0, i.jsx)("path", {
                    id: "Shape_2_",
                    className: "st2",
                    fill: "#FBBC05",
                    d: "M-10.37-3.62c-0.18-0.54-0.28-1.12-0.28-1.71s0.1-1.17,0.28-1.71v-2.33h-3.01 c-0.61,1.22-0.96,2.59-0.96,4.04s0.35,2.83,0.96,4.04L-10.37-3.62L-10.37-3.62z",
                  }),
                  (0, i.jsx)("path", {
                    id: "Shape_3_",
                    className: "st3",
                    fill: "#EA4335",
                    d: "M-5.33-10.75c1.32,0,2.51,0.45,3.44,1.35l2.58-2.58c-1.56-1.45-3.6-2.34-6.02-2.34 c-3.52,0-6.56,2.02-8.04,4.96l3.01,2.33C-9.66-9.17-7.68-10.75-5.33-10.75L-5.33-10.75z",
                  }),
                  (0, i.jsx)("path", {
                    id: "Shape_4_",
                    className: "st4",
                    fill: "none",
                    d: "M-14.33-14.33h18v18h-18V-14.33z",
                  }),
                ],
              }),
            });
          };
        var eo = n(8697),
          es = n(96201),
          ea = n(16075),
          el = n(73983),
          ec = n(65801);
        function eu() {
          return void 0 !== window.google;
        }
        let ed = [
            "Chrome WebView",
            "Instagram",
            "Sogou Explorer",
            "Baidu",
            "Snapchat",
            "LinkedIn",
            "Silk",
            "Facebook",
            null,
          ],
          eh = () => {
            let e = (0, S.mV)(),
              { openDrawer: t } = s.useContext(D.s9);
            return (0, s.useCallback)(
              (n) => () => {
                t("browserNotSupported", {
                  returnToDrawer: "signIn",
                  params: {
                    title: e._("auth.ui.login.socialBtn", { service: n }),
                  },
                });
              },
              [e, t]
            );
          },
          e_ = s.memo(() => {
            let e = s.useRef(null),
              { isMobile: t } = s.useContext(C.Z),
              { locale: n } = s.useContext(eo.Z),
              { innerWidth: r } = s.useContext(es.b),
              o = s.useRef(!1),
              a = s.useContext(p.Z),
              l = (0, el.E)(a),
              c = ed.includes(l.name),
              d = eh(),
              h = (0, ec.Z)();
            return (
              s.useEffect(() => {
                if (eu() && e.current && r) {
                  if (!t && o.current) return;
                  let n = t ? r - 32 : 368;
                  h && t && (n = 336),
                    window.google.accounts.id.renderButton(e.current, {
                      theme: "outline",
                      shape: "pill",
                      size: "large",
                      logo_alignment: "center",
                      width: n,
                    }),
                    (o.current = !0);
                }
              }, [e, t, n, r, h]),
              !c && eu()
                ? (0, i.jsx)("div", { ref: e, style: { height: 40 } })
                : (0, i.jsx)(J, {
                    icon: (0, i.jsx)(er, { customStyle: { width: 20 } }),
                    provider: u.googleProvider,
                    service: "Google",
                    onClick: c ? d("google") : void 0,
                  })
            );
          }),
          ey = s.memo(() => {
            let e = s.useContext(p.Z),
              t = (0, el.E)(e),
              n = ed.includes(t.name),
              r = eh();
            return (0, i.jsx)(J, {
              icon: (0, i.jsx)(ea.Z, {}),
              provider: u.facebookProvider,
              service: "Facebook",
              onClick: n ? r("facebook") : void 0,
            });
          }),
          ex = s.memo(() => {
            let { spacing: e } = (0, M.Z)();
            return (0, i.jsxs)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                width: "100%",
                marginTop: e(),
                flexDirection: "column",
              },
              children: [(0, i.jsx)(e_, {}), (0, i.jsx)(ey, {})],
            });
          });
        var ep = n(3411),
          em = n(95914);
        let eg = s.memo((e) =>
          (0, i.jsx)(em.Z, {
            ...e,
            viewBox: "0 0 20 20",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M10 4.16667C6.22312 4.16667 3.33334 6.8679 3.33334 10C3.33334 11.1265 3.69833 12.1825 4.34077 13.0826C4.50194 13.3084 4.54017 13.5995 4.44277 13.8593L3.80669 15.5555L6.29046 15.0587C6.46718 15.0234 6.65058 15.0463 6.81318 15.124C7.75679 15.5749 8.84153 15.8333 10 15.8333C13.7769 15.8333 16.6667 13.1321 16.6667 10C16.6667 6.8679 13.7769 4.16667 10 4.16667ZM1.66667 10C1.66667 5.7683 5.49261 2.5 10 2.5C14.5074 2.5 18.3333 5.7683 18.3333 10C18.3333 14.2317 14.5074 17.5 10 17.5C8.69562 17.5 7.45715 17.2301 6.35268 16.746L2.66343 17.4838C2.36673 17.5432 2.06118 17.437 1.86517 17.2065C1.66916 16.976 1.61349 16.6574 1.71973 16.3741L2.73227 13.6739C2.05649 12.5924 1.66667 11.3388 1.66667 10ZM5.83334 10C5.83334 9.53976 6.20643 9.16667 6.66667 9.16667H6.675C7.13524 9.16667 7.50834 9.53976 7.50834 10C7.50834 10.4602 7.13524 10.8333 6.675 10.8333H6.66667C6.20643 10.8333 5.83334 10.4602 5.83334 10ZM9.16667 10C9.16667 9.53976 9.53976 9.16667 10 9.16667H10.0083C10.4686 9.16667 10.8417 9.53976 10.8417 10C10.8417 10.4602 10.4686 10.8333 10.0083 10.8333H10C9.53976 10.8333 9.16667 10.4602 9.16667 10ZM12.5 10C12.5 9.53976 12.8731 9.16667 13.3333 9.16667H13.3417C13.8019 9.16667 14.175 9.53976 14.175 10C14.175 10.4602 13.8019 10.8333 13.3417 10.8333H13.3333C12.8731 10.8333 12.5 10.4602 12.5 10Z",
            }),
          })
        );
        var eC = n(76717),
          ef = n(16190),
          eB = n(88650),
          ew = n(33759);
        let ej = (0, G.ZP)("div")((e) => {
          let {
            theme: { spacing: t },
          } = e;
          return {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            flex: 1,
            justifyContent: "flex-end",
            marginTop: t(3),
            paddingBottom: t(3),
            "& .SidebarLinks": {
              maxWidth: 286,
              flexDirection: "row",
              flexWrap: "wrap",
              gap: "2px 7px",
              justifyContent: "center",
              "& span": { fontSize: 14 },
            },
          };
        });
        var ez = n(41489),
          ev = n.n(ez);
        let eF = () => {
            let { openMainFeedbackDrawer: e } = s.useContext(eB.l),
              { spacing: t } = (0, M.Z)();
            return (0, i.jsxs)(ej, {
              children: [
                (0, i.jsxs)(K.Z, {
                  className: ev().openFeedbackButton,
                  variant: "contained",
                  color: "grey",
                  height: 40,
                  onClick: () => {
                    e("sidebar");
                  },
                  children: [
                    (0, i.jsx)(eg, {}),
                    (0, i.jsx)(S.cC, { id: "common.quicknav.contact" }),
                  ],
                }),
                (0, i.jsx)("div", {
                  style: { width: 194, marginBottom: t() },
                  children: (0, i.jsx)(eC.Z, { keepMounted: !0 }),
                }),
                (0, i.jsx)(ef.Z, {}),
                (0, i.jsx)("div", {
                  style: {
                    display: "flex",
                    flexFlow: "row wrap",
                    rowGap: t(1),
                    marginLeft: t(1),
                  },
                  children: (0, i.jsx)(ew.Z, {}),
                }),
              ],
            });
          },
          eb = (e) => {
            let { preSelectedEmail: t } = e,
              { setMessage: n } = s.useContext(d.V),
              r = (0, M.Z)();
            return (
              s.useEffect(
                () => () => {
                  n(void 0);
                },
                [n]
              ),
              (0, i.jsxs)(i.Fragment, {
                children: [
                  (0, i.jsx)(ex, {}),
                  (0, i.jsxs)("div", {
                    style: {
                      fontSize: 16,
                      padding: r.spacing(2),
                      paddingTop: r.spacing(3),
                      display: "flex",
                      flexDirection: "row",
                      flexWrap: "nowrap",
                      alignItems: "center",
                      justifyContent: "space-between",
                      width: "100%",
                    },
                    children: [
                      (0, i.jsx)(P.Z, {
                        style: { borderColor: ep.D.black[40], flex: 1 },
                      }),
                      (0, i.jsx)("span", {
                        style: {
                          marginLeft: r.spacing(1),
                          marginRight: r.spacing(1),
                          textTransform: "uppercase",
                          fontWeight: 700,
                        },
                        children: (0, i.jsx)(S.cC, { id: "auth.ui.or" }),
                      }),
                      (0, i.jsx)(P.Z, {
                        style: { borderColor: ep.D.black[40], flex: 1 },
                      }),
                    ],
                  }),
                  (0, i.jsx)(en, { preSelectedEmail: t }),
                  (0, i.jsx)(I.Z, {}),
                ],
              })
            );
          },
          ek = (e) => {
            let { preSelectedEmail: t } = e,
              { loading: n } = s.useContext(d.V),
              { openDrawer: r } = s.useContext(D.s9),
              o = s.useContext(C.Z),
              a = !o.isDesktop,
              l = () => {
                r(null);
              };
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(L.gu, {
                  children: (0, i.jsx)(E.Qh, {
                    color: "white",
                    onClick: l,
                    children: (0, i.jsx)(U.Z, {}),
                  }),
                }),
                n && (0, i.jsx)(T.Z, {}),
                (0, i.jsx)(W, {
                  children: (0, i.jsxs)(H, {
                    isMobile: a,
                    sx: { height: "100%" },
                    children: [
                      (0, i.jsx)(L.mH, {
                        sx: { mt: 3, mb: 2 },
                        children: (0, i.jsx)(S.cC, {
                          id: "auth.ui.header.signinorsignup",
                        }),
                      }),
                      (0, i.jsx)(eb, { preSelectedEmail: t }),
                      o.isMobile && (0, i.jsx)(eF, {}),
                    ],
                  }),
                }),
              ],
            });
          };
        var eZ = n(75543),
          eD = n.n(eZ),
          eL = n(25827),
          eS = n(75007);
        let eM = s.memo(() => {
          let { openDrawer: e } = s.useContext(D.s9),
            t = s.useContext(C.Z),
            n = s.useCallback(() => e("signIn"), [e]);
          return (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(eL.Z, {
                onBack: n,
                onClose: () => {
                  e(null);
                },
                title: (0, i.jsx)(S.cC, {
                  id: "auth.ui.header.signinorsignup",
                }),
              }),
              (0, i.jsx)(W, {
                children: (0, i.jsx)(H, {
                  isMobile: t.isMobile,
                  sx: { height: "100%", pt: 0 },
                  children: (0, i.jsxs)("div", {
                    className: eD().hug,
                    children: [
                      (0, i.jsx)("img", {
                        height: "50",
                        width: "158",
                        src: (0, eS.ZP)("googleloginbanner.svg", {
                          width: 158,
                        }),
                        alt: "Google login Banner",
                      }),
                      (0, i.jsx)("div", {
                        className: eD().message,
                        children: (0, i.jsx)(S.cC, {
                          id: "common.error.accountalreadyassociated",
                          values: { provider: "Google" },
                        }),
                      }),
                      (0, i.jsx)(e_, {}),
                    ],
                  }),
                }),
              }),
            ],
          });
        });
        var eP = n(79495);
        let eU = (e) => {
          let { preSelectedEmail: t } = e,
            { openDrawer: n } = s.useContext(D.s9),
            r = s.useContext(C.Z),
            { setMessage: o, loading: a } = s.useContext(d.V),
            l = !r.isDesktop;
          return (
            s.useEffect(
              () => () => {
                o(void 0);
              },
              [o]
            ),
            (0, i.jsxs)(eP.Z, {
              onBack: () =>
                n("signIn", { isExiting: !0, params: { preSelectedEmail: t } }),
              title: (0, i.jsx)(S.cC, { id: "auth.ui.header.signin" }),
              fixHeader: !0,
              customTitleStyles: { fontWeight: 700, color: ep.D.white[10] },
              children: [
                a && (0, i.jsx)(T.Z, {}),
                (0, i.jsx)(W, {
                  children: (0, i.jsxs)(H, {
                    isMobile: l,
                    sx: { pt: 0, px: 0 },
                    children: [
                      (0, i.jsx)(L.mH, {
                        sx: { mb: 2, textAlign: "center" },
                        children: (0, i.jsx)(S.cC, {
                          id: "auth.ui.subheader.login",
                        }),
                      }),
                      (0, i.jsx)(ei, { preSelectedEmail: t }),
                      (0, i.jsx)(I.Z, {}),
                    ],
                  }),
                }),
              ],
            })
          );
        };
        var eE = n(54265),
          eT = n(14243),
          eI = n.n(eT);
        let eG = () => {
            let { openDrawer: e } = s.useContext(D.s9),
              { loading: t } = s.useContext(d.V),
              n = () => {
                e("signIn");
              };
            return (0, i.jsxs)(i.Fragment, {
              children: [
                t && (0, i.jsx)(T.Z, {}),
                (0, i.jsx)(ex, {}),
                (0, i.jsxs)(K.Z, {
                  onClick: () => {
                    e("signUpEmail");
                  },
                  className: eI().signUpEmailButton,
                  color: "purple",
                  variant: "contained",
                  fullWidth: !0,
                  height: 40,
                  children: [
                    (0, i.jsx)(eE.Z, {}),
                    " ",
                    (0, i.jsx)(q.Z, {
                      sx: { ml: 1 },
                      children: (0, i.jsx)(S.cC, {
                        id: "auth.ui.header.signupEmail",
                      }),
                    }),
                  ],
                }),
                (0, i.jsx)(I.Z, {}),
                (0, i.jsxs)(L.Sz, {
                  sx: { mt: 4, justifyContent: "center" },
                  children: [
                    (0, i.jsx)(S.cC, { id: "auth.ui.alreadyMemberLabel" }),
                    (0, i.jsx)(K.Z, {
                      onClick: n,
                      color: "purple",
                      variant: "link",
                      className: eI().alreadyMemberButton,
                      children: (0, i.jsx)(S.cC, {
                        id: "auth.ui.alreadyMemberAction",
                      }),
                    }),
                  ],
                }),
              ],
            });
          },
          eW = () => {
            let { openDrawer: e } = s.useContext(D.s9),
              t = s.useContext(C.Z),
              { setMessage: n } = s.useContext(d.V),
              r = !t.isDesktop,
              o = () => {
                e(null);
              };
            return (
              s.useEffect(
                () => () => {
                  n(void 0);
                },
                [n]
              ),
              (0, i.jsxs)(i.Fragment, {
                children: [
                  (0, i.jsx)(L.gu, {
                    children: (0, i.jsx)(E.Qh, {
                      color: "white",
                      onClick: o,
                      children: (0, i.jsx)(U.Z, {}),
                    }),
                  }),
                  (0, i.jsx)(W, {
                    children: (0, i.jsxs)(H, {
                      isMobile: r,
                      sx: { height: "100%" },
                      children: [
                        (0, i.jsx)(L.mH, {
                          sx: { mt: 3, mb: 2 },
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.button.signup",
                          }),
                        }),
                        (0, i.jsx)(eG, {}),
                        t.isMobile && (0, i.jsx)(eF, {}),
                      ],
                    }),
                  }),
                ],
              })
            );
          };
        var eH = n(69368),
          eA = n(63306),
          eN = n(42916),
          eO = n(2978);
        let eR = o()(() => n.e(34853).then(n.bind(n, 34853)), {
            loadableGenerated: { webpack: () => [34853] },
            loading: () => null,
            ssr: !1,
          }),
          eV = (e) => {
            let { preSelectedEmail: t } = e,
              { i18n: n } = (0, S.mV)(),
              [r, o] = s.useState(t || ""),
              [a, l] = s.useState(""),
              [_, y] = s.useState(""),
              [x, p] = s.useState(!1),
              { crazyAnalyticsService: m } = s.useContext(w.Z).services,
              {
                setMessage: g,
                triggerLogin: C,
                setLoginHasStarted: f,
                loading: B,
                setLoading: j,
              } = s.useContext(d.V),
              { spacing: z } = (0, M.Z)(),
              [v, k] = s.useState(!1),
              [Z] = (0, F.D)(b.Fb),
              { routeHelper: D } = s.useContext(eA.Z),
              P = (0, eN.Z)(a)
                ? ""
                : n._("auth.ui.helper.passwordConditions", {
                    numberOfChars: R.l,
                  }),
              U = (e) => {
                o(e.target.value);
              },
              E = (e) => {
                l(e.target.value);
              },
              T = (e) => {
                y(e.target.value);
              },
              I = (e) => {
                let t = (0, R.r)(e, n);
                return (
                  t ||
                  (e && e.message
                    ? e.message
                    : n._({ id: "auth.ui.error.generic" }))
                );
              },
              G = async () => {
                if (a !== _) {
                  g(n._("auth.ui.error.passwordMismatch"));
                  return;
                }
                j(!0);
                try {
                  f(!0);
                  let e = await (0, c.Xb)(u.firebaseAuth, r, a),
                    t = await C(e);
                  if (t) {
                    let e = new URL(window.location.href);
                    e.searchParams.set("crazyOriginLogic", "verifyEmail"),
                      await Z({
                        variables: { input: { redirectUrl: e.toString() } },
                      });
                  }
                } catch (t) {
                  let e = I(t);
                  g(e), m.userAction("authentication", "auth_failed", t?.code);
                } finally {
                  j(!1);
                }
              },
              W = D.termsAndConditionsPageLink(),
              H = D.privacyPolicyPageLink(),
              O = () =>
                (0, i.jsx)(eO.Z, {
                  ...W,
                  target: "_blank",
                  children: (0, i.jsx)(S.cC, {
                    id: "auth.ui.label.acceptTerms",
                  }),
                }),
              q = () =>
                (0, i.jsx)(eO.Z, {
                  ...H,
                  target: "_blank",
                  children: (0, i.jsx)(S.cC, {
                    id: "auth.ui.label.acceptPolicy",
                  }),
                });
            return (0, i.jsx)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
                width: "100%",
              },
              children: (0, i.jsxs)("div", {
                style: { width: "100%" },
                children: [
                  (0, i.jsxs)("form", {
                    style: {
                      textAlign: "center",
                      display: "flex",
                      flexDirection: "column",
                      gap: z(),
                    },
                    children: [
                      (0, i.jsx)(N.Z, {
                        required: !0,
                        label: n._({ id: "auth.ui.label.email" }),
                        onChange: U,
                        type: "email",
                        value: t || r,
                        readOnly: !!t,
                      }),
                      (0, i.jsx)(N.Z, {
                        required: !0,
                        type: "password",
                        label: n._({ id: "auth.ui.label.password" }),
                        onChange: E,
                        autoComplete: "false",
                        autoFocus: !!t,
                      }),
                      (0, i.jsx)(N.Z, {
                        required: !0,
                        helperText: P,
                        type: "password",
                        label: n._({ id: "auth.ui.label.passwordconfirm" }),
                        onChange: T,
                        autoComplete: "false",
                      }),
                      (0, i.jsx)(L.I8, {
                        sx: { my: 2, color: ep.D.white[50], textAlign: "left" },
                        control: (0, i.jsx)(eH.Z, {
                          color: "success",
                          checked: x,
                          onChange: () => p(!x),
                        }),
                        label: (0, i.jsx)(S.cC, {
                          id: "auth.ui.label.acceptTnC",
                          values: {
                            tncLink: (0, i.jsx)(O, {}),
                            privacyLink: (0, i.jsx)(q, {}),
                          },
                        }),
                      }),
                      !v &&
                        (0, i.jsx)("div", {
                          style: {
                            margin: "10px auto",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            height: 78,
                            width: 304,
                            boxShadow: `inset 0px 0px 0px 1px ${ep.D.black[60]}`,
                            background: "rgba(71, 73, 103, 0.10)",
                          },
                          children: (0, i.jsx)(eR, {
                            theme: "dark",
                            sitekey: h.Z.Instance.data.recaptchav2SiteKey,
                            onChange: () => {
                              k(!0);
                            },
                          }),
                        }),
                    ],
                  }),
                  (0, i.jsx)(A.Z, {
                    height: 50,
                    disabled:
                      !((0, V.o)(r) && (0, eN.Z)(a) && _ && x) || B || !v,
                    onClick: G,
                    children: (0, i.jsx)(S.cC, {
                      id: "auth.ui.button.continue",
                    }),
                  }),
                ],
              }),
            });
          },
          eq = (e) => {
            let { preSelectedEmail: t } = e,
              { openDrawer: n } = s.useContext(D.s9),
              r = s.useContext(C.Z),
              { setMessage: o, loading: a } = s.useContext(d.V),
              l = !r.isDesktop;
            return (
              s.useEffect(
                () => () => {
                  o(void 0);
                },
                [o]
              ),
              (0, i.jsxs)(eP.Z, {
                onBack: () =>
                  n("signIn", {
                    isExiting: !0,
                    params: { preSelectedEmail: t },
                  }),
                title: (0, i.jsx)(S.cC, { id: "auth.ui.button.signup" }),
                fixHeader: !0,
                children: [
                  a && (0, i.jsx)(T.Z, {}),
                  (0, i.jsx)(W, {
                    children: (0, i.jsxs)(H, {
                      isMobile: l,
                      sx: { pt: 0, px: 0 },
                      children: [
                        (0, i.jsx)(L.mH, {
                          sx: { mb: 2, textAlign: "center" },
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.header.signupEmail",
                          }),
                        }),
                        (0, i.jsx)(eV, { preSelectedEmail: t }),
                        (0, i.jsx)(I.Z, {}),
                      ],
                    }),
                  }),
                ],
              })
            );
          };
        var eK = () =>
            (0, i.jsxs)("svg", {
              width: "124",
              height: "80",
              viewBox: "0 0 124 80",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              children: [
                (0, i.jsx)("path", {
                  d: "M91.824 22.7351C92.2009 17.22 94.4377 8.55414 91.8294 6.15898C90.0215 3.87467 82.5047 4.6051 79.4445 7.31485C74.6908 4.71415 68.771 3.27356 61.5096 2.94732C54.2481 2.62108 48.2281 3.53065 43.266 5.68943C40.4506 2.71029 36.0882 -1.17195 34.0827 0.941035C30.4277 4.79326 29.6693 14.3672 29.5499 19.8994C27.7874 24.1506 26.7658 29.1604 26.5068 34.9244C25.9627 47.0359 29.0079 56.1583 35.55 62.0763C39.9566 66.0526 45.8369 68.4928 53.4235 69.4886C52.5118 69.8969 51.5683 70.293 50.5956 70.7419L47.7737 71.9792L46.1707 72.6812C44.6148 73.4124 43.0147 74.0496 41.2814 75.0165L40.8525 75.2191C40.7305 75.3003 40.6112 75.4411 40.5824 75.6021C40.5148 75.9077 40.7112 76.2088 41.0154 76.2657C42.5411 76.5671 44.0474 76.9379 45.5989 77.1429L46.7532 77.3247C47.1326 77.385 47.5179 77.4348 47.909 77.474L50.2341 77.7084C53.3522 77.9026 56.502 77.8709 59.6392 77.5193C62.7701 77.189 65.8654 76.4512 68.8579 75.3677C71.8343 74.2835 74.7037 72.8264 77.32 71.0115C82.5124 67.3204 86.6916 62.2251 89.3027 56.453C90.2577 54.3632 90.9961 52.1825 91.5587 49.9614C92.6495 46.4053 93.3032 42.3966 93.5037 37.9345C93.7617 32.1921 93.193 27.1216 91.8294 22.7354L91.824 22.7351Z",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("path", {
                  d: "M71.9289 68.826C68.0163 69.787 63.56 70.1497 58.4953 69.9222L58.4845 69.9217C58.0065 69.9002 57.5126 69.8726 57.0192 69.8342C56.0051 69.767 55.0244 69.6742 54.0662 69.5608C53.8467 69.5347 53.6272 69.5086 53.4185 69.483C52.507 69.8859 51.5633 70.2873 50.5905 70.7362L47.7687 71.9735C49.07 72.1186 50.6071 72.2851 51.9767 72.3466C60.0921 72.7112 66.6616 71.5503 71.9289 68.826Z",
                  fill: "#492EB3",
                }),
                (0, i.jsx)("path", {
                  d: "M57.4314 59.844C70.2729 59.3916 78.6934 55.4588 78.0679 37.706C77.7725 29.3241 75.655 23.7335 71.6181 20.6184C68.2008 17.9901 63.0598 16.8239 55.9244 17.0753C48.7891 17.3267 43.7425 18.8411 40.5191 21.7142C36.7005 25.1007 34.9928 30.8369 35.288 39.2134C35.9135 56.9661 44.5899 60.2965 57.4314 59.844Z",
                  fill: "white",
                }),
                (0, i.jsx)("rect", {
                  width: "9.62102",
                  height: "18.8689",
                  rx: "4.81051",
                  transform:
                    "matrix(0.998268 -0.0588294 0.0196847 0.999806 43.3587 29.7412)",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("rect", {
                  width: "9.62102",
                  height: "18.8689",
                  rx: "4.81051",
                  transform:
                    "matrix(0.99722 -0.0745197 0.0354039 0.999373 56.7994 29.455)",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("ellipse", {
                  cx: "2.8037",
                  cy: "2.82674",
                  rx: "2.8037",
                  ry: "2.82674",
                  transform:
                    "matrix(0.998588 -0.0531167 0.0548527 0.998494 48.5875 29.0398)",
                  fill: "white",
                }),
                (0, i.jsx)("ellipse", {
                  cx: "2.8037",
                  cy: "2.82674",
                  rx: "2.8037",
                  ry: "2.82674",
                  transform:
                    "matrix(0.998588 -0.0531167 0.0548527 0.998494 62.1684 29.0398)",
                  fill: "white",
                }),
                (0, i.jsxs)("g", {
                  "clip-path": "url(#clip0_3600_891)",
                  children: [
                    (0, i.jsx)("path", {
                      d: "M20.2218 29.7557C15.195 29.2517 10.7086 32.9114 10.1923 37.9369L9.62366 43.5402C9.5844 43.927 9.86618 44.2725 10.253 44.3117L13.0547 44.5961C13.4415 44.6353 13.7869 44.3535 13.8262 43.9667L14.3949 38.3635C14.6696 35.6556 17.0875 33.6833 19.7953 33.9581C22.5031 34.2329 24.4754 36.6508 24.2006 39.3586L23.6779 44.3117C23.6387 44.6986 23.9204 45.044 24.3073 45.0833L27.1089 45.3676C27.4957 45.4068 27.8411 45.1251 27.8804 44.7382L28.4031 39.7851C28.907 34.7583 25.2473 30.2719 20.2218 29.7557Z",
                      fill: "#BBBBBB",
                    }),
                    (0, i.jsx)("path", {
                      d: "M10.3952 42.9109L27.2051 44.6169C29.1392 44.8132 30.548 46.5402 30.3517 48.4743L29.0722 61.0817C28.8759 63.0159 27.1488 64.4247 25.2147 64.2284L8.40484 62.5224C6.47072 62.3261 5.06193 60.5991 5.25822 58.665L6.53773 46.0576C6.73403 44.1234 8.46107 42.7146 10.3952 42.9109Z",
                      fill: "#FFC107",
                    }),
                    (0, i.jsx)("path", {
                      d: "M10.1583 42.8868L25.8309 44.4774C27.6341 44.6604 28.9368 46.3767 28.7406 48.3108L27.461 60.9182C27.2647 62.8524 25.6438 64.2719 23.8405 64.0889L8.16791 62.4983C6.36464 62.3153 5.06193 60.599 5.25822 58.6649L6.53773 46.0575C6.73403 44.1233 8.355 42.7038 10.1583 42.8868Z",
                      fill: "url(#paint0_linear_3600_891)",
                    }),
                    (0, i.jsx)("path", {
                      d: "M21.5202 51.8239C21.7247 49.8906 20.3232 48.1576 18.3899 47.9531C16.4566 47.7487 14.7236 49.1502 14.5192 51.0835C14.3778 52.4198 15.0096 53.72 16.1476 54.4346L15.223 58.1619C15.13 58.5395 15.3606 58.9209 15.7381 59.0139C15.7701 59.0218 15.8026 59.0275 15.8354 59.0308L18.6371 59.3151C19.0235 59.3582 19.3716 59.0799 19.4147 58.6934C19.4186 58.6583 19.4199 58.623 19.4185 58.5877L19.2616 54.7506C20.5055 54.278 21.3784 53.1468 21.5202 51.8239Z",
                      fill: "#A3661E",
                    }),
                  ],
                }),
                (0, i.jsxs)("g", {
                  "clip-path": "url(#clip1_3600_891)",
                  children: [
                    (0, i.jsx)("path", {
                      d: "M100.233 48.5752C104.219 47.1515 108.605 49.222 110.038 53.2039L111.631 57.645C111.741 57.9516 111.582 58.2893 111.275 58.3993L109.054 59.1956C108.748 59.3056 108.41 59.1462 108.3 58.8396L106.707 54.3985C105.938 52.2522 103.574 51.1364 101.428 51.906C99.2817 52.6757 98.1658 55.0394 98.9355 57.1856L99.3263 58.4332C99.4363 58.7398 99.2768 59.0775 98.9702 59.1874L96.7497 59.9838C96.4431 60.0937 96.1054 59.9343 95.9955 59.6277L95.6046 58.3801C94.1809 54.3947 96.2514 50.0087 100.233 48.5752Z",
                      fill: "#A08979",
                    }),
                    (0, i.jsx)("path", {
                      d: "M110.877 57.289L97.5534 62.067C96.0204 62.6168 95.2234 64.3052 95.7731 65.8381L99.3566 75.8307C99.9064 77.3637 101.595 78.1607 103.128 77.611L116.451 72.8329C117.984 72.2832 118.781 70.5948 118.231 69.0618L114.648 59.0693C114.098 57.5363 112.41 56.7392 110.877 57.289Z",
                      fill: "#77543C",
                    }),
                    (0, i.jsx)("path", {
                      d: "M103.629 66.78C103.073 65.2493 103.863 63.5576 105.394 63.0014C106.924 62.4452 108.616 63.2351 109.172 64.7657C109.557 65.8238 109.305 67.0083 108.524 67.8189L110.028 70.663C110.18 70.9512 110.069 71.3078 109.781 71.4596C109.757 71.4725 109.731 71.4836 109.705 71.4929L107.485 72.2893C107.179 72.4022 106.84 72.2462 106.727 71.9407C106.717 71.9129 106.709 71.8845 106.703 71.8555L106.056 68.704C104.949 68.5707 104.012 67.827 103.629 66.78Z",
                      fill: "#3D2B1F",
                    }),
                  ],
                }),
                (0, i.jsx)("path", {
                  d: "M18.5761 34.1005C15.5991 34.2362 13.0758 31.9328 12.9401 28.9558C12.8045 25.9788 15.2102 25.7015 18.1872 25.5658C21.1642 25.4301 23.5851 25.4875 23.7208 28.4645C23.8564 31.4415 21.5531 33.9648 18.5761 34.1005Z",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("path", {
                  d: "M102.547 52.7457C99.57 52.8814 97.0467 50.5781 96.911 47.6011C96.7753 44.6241 99.181 44.3467 102.158 44.2111C105.135 44.0754 107.556 44.1328 107.692 47.1098C107.827 50.0868 105.524 52.6101 102.547 52.7457Z",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("path", {
                  d: "M1.68631 46.5222C1.74996 46.5639 1.8047 46.6179 1.84739 46.6809C1.89008 46.7439 1.91987 46.8147 1.93504 46.8893L2.19124 48.0211C2.24494 48.2034 2.49213 48.2515 2.60549 48.1017L3.26814 47.1484C3.35687 47.0244 3.4875 46.9368 3.63585 46.9018L4.27122 46.7629C4.31327 46.7525 4.35146 46.7303 4.38131 46.6989C4.41116 46.6675 4.43141 46.6282 4.43969 46.5857C4.44797 46.5432 4.44392 46.4992 4.42803 46.4589C4.41214 46.4186 4.38506 46.3837 4.34999 46.3583L3.81313 45.9912C3.68304 45.9052 3.59381 45.7716 3.56489 45.6242L3.30914 44.4875C3.25544 44.3052 3.00825 44.257 2.8949 44.4068L2.2313 45.365C2.14396 45.4893 2.01205 45.5749 1.86359 45.6116L1.22822 45.7505C1.18617 45.7609 1.14798 45.7831 1.11813 45.8145C1.08828 45.8459 1.06803 45.8852 1.05975 45.9277C1.05148 45.9702 1.05552 46.0142 1.07141 46.0545C1.0873 46.0948 1.11438 46.1297 1.14945 46.1551L1.68631 46.5222ZM4.01538 40.3221C3.97498 40.1178 3.86161 39.9434 3.70048 39.8238L3.02029 39.3281C2.97481 39.2919 2.94014 39.2439 2.92003 39.1894C2.89993 39.1348 2.89518 39.0758 2.90629 39.0188C2.91739 38.9617 2.94394 38.9088 2.98303 38.8658C3.02213 38.8228 3.07227 38.7913 3.12801 38.7748L3.9445 38.5705C4.13871 38.5201 4.30968 38.396 4.42332 38.2267L5.29602 36.9049C5.3296 36.8586 5.37568 36.8229 5.42884 36.802C5.48201 36.781 5.54005 36.7757 5.59615 36.7866C5.65224 36.7976 5.70404 36.8243 5.74547 36.8636C5.7869 36.903 5.81622 36.9534 5.83 37.0088L6.14256 38.5614C6.18165 38.761 6.29397 38.9388 6.45746 39.0597L7.13765 39.5554C7.18313 39.5916 7.2178 39.6396 7.23791 39.6941C7.25801 39.7487 7.26276 39.8077 7.25165 39.8648C7.24055 39.9218 7.214 39.9747 7.17491 40.0177C7.13581 40.0608 7.08567 40.0922 7.02993 40.1087L6.21345 40.313C6.01923 40.3634 5.84826 40.4875 5.73462 40.6568L4.86192 41.9786C4.82834 42.0249 4.78226 42.0606 4.7291 42.0815C4.67593 42.1025 4.61789 42.1078 4.5618 42.0969C4.5057 42.0859 4.4539 42.0592 4.41247 42.0199C4.37104 41.9805 4.34172 41.9301 4.32794 41.8747L4.01538 40.3221Z",
                  fill: "#FCB812",
                }),
                (0, i.jsxs)("defs", {
                  children: [
                    (0, i.jsxs)("linearGradient", {
                      id: "paint0_linear_3600_891",
                      x1: "17.9946",
                      y1: "43.6821",
                      x2: "16.0042",
                      y2: "63.2936",
                      gradientUnits: "userSpaceOnUse",
                      children: [
                        (0, i.jsx)("stop", { "stop-color": "#FFF1C6" }),
                        (0, i.jsx)("stop", {
                          offset: "1",
                          "stop-color": "#FFD452",
                        }),
                      ],
                    }),
                    (0, i.jsx)("clipPath", {
                      id: "clip0_3600_891",
                      children: (0, i.jsx)("rect", {
                        width: "33.7924",
                        height: "33.7924",
                        fill: "white",
                        transform: "translate(3.41193 28.0497) rotate(5.79505)",
                      }),
                    }),
                    (0, i.jsx)("clipPath", {
                      id: "clip1_3600_891",
                      children: (0, i.jsx)("rect", {
                        width: "28.3084",
                        height: "28.3084",
                        fill: "white",
                        transform:
                          "matrix(-0.941301 0.337569 0.337569 0.941301 113.557 43.7972)",
                      }),
                    }),
                  ],
                }),
              ],
            }),
          eQ = () =>
            (0, i.jsxs)("svg", {
              width: "93",
              height: "82",
              viewBox: "0 0 93 82",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              children: [
                (0, i.jsx)("path", {
                  d: "M68.6001 24.6399C69.0692 18.889 69.3163 8.83404 65.9293 4.43648C64.0738 2.02758 59.1225 5.59007 55.8915 8.37619C50.9659 5.59665 44.8073 4.01191 37.2331 3.57177C29.6588 3.13164 23.3634 3.99833 18.1549 6.18332C15.2575 3.03541 6.47928 -1.3249 4.35723 0.85287C0.489633 4.82321 3.8452 15.0536 3.64469 20.8258C1.74689 25.2385 0.611938 30.4532 0.262565 36.4654C-0.471543 49.0985 2.58154 58.6611 9.32815 64.9274C13.8727 69.1378 19.9763 71.7653 27.8807 72.9088C26.9235 73.3224 25.9334 73.7228 24.912 74.178L21.95 75.4306L20.2673 76.1413C18.6334 76.8831 16.9547 77.5262 15.1324 78.5115L14.682 78.7171C14.5535 78.8001 14.427 78.9454 14.3948 79.1131C14.3201 79.4311 14.5209 79.748 14.8376 79.8117C16.4258 80.1471 17.9928 80.5547 19.6093 80.79L20.8115 80.9956C21.2067 81.0638 21.6081 81.121 22.0157 81.1673L24.4392 81.4438C27.6908 81.6893 30.9786 81.6995 34.2577 81.3755C37.5299 81.0738 40.7706 80.3462 43.9087 79.2564C47.0299 78.1657 50.0446 76.6844 52.8002 74.8261C58.27 71.045 62.7017 65.7844 65.5061 59.7961C66.5314 57.6281 67.332 55.3622 67.9497 53.0518C69.1369 49.3554 69.8742 45.1806 70.1447 40.5263C70.4927 34.5365 69.9688 29.2368 68.6058 24.6402L68.6001 24.6399Z",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("path", {
                  d: "M47.2035 72.4712C43.1067 73.4204 38.4508 73.7378 33.1679 73.4308L33.1567 73.4302C32.6581 73.4012 32.143 73.3656 31.6286 73.3188C30.5711 73.2347 29.5488 73.1244 28.5503 72.9929C28.3216 72.9626 28.0929 72.9324 27.8754 72.9028C26.9186 73.3108 25.9281 73.7168 24.9067 74.172L21.9447 75.4246C23.3008 75.5939 24.9027 75.7887 26.3313 75.8717C34.7963 76.3636 41.6686 75.2421 47.2035 72.4712Z",
                  fill: "#492EB3",
                }),
                (0, i.jsx)("path", {
                  d: "M34.3233 61.6361C47.6804 62.8471 56.9146 59.8759 58.5888 41.4103C59.3793 32.6918 57.9177 26.6256 54.1448 22.8717C50.9498 19.703 45.7786 17.823 38.3567 17.15C30.9349 16.4771 25.5109 17.3852 21.7971 19.9388C17.3998 22.9463 14.8812 28.663 14.0912 37.3758C12.417 55.8414 20.9662 60.425 34.3233 61.6361Z",
                  fill: "white",
                }),
                (0, i.jsx)("rect", {
                  width: "11.201",
                  height: "19.7629",
                  rx: "5.60052",
                  transform:
                    "matrix(0.995769 0.0918955 -0.0901642 0.995927 27.108 29.3154)",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("rect", {
                  width: "10.2676",
                  height: "19.7629",
                  rx: "5.13381",
                  transform:
                    "matrix(0.994439 0.105316 -0.103587 0.99462 42.1038 30.7687)",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("ellipse", {
                  cx: "3.26697",
                  cy: "3.29382",
                  rx: "3.26697",
                  ry: "3.29382",
                  transform:
                    "matrix(0.988814 0.149153 -0.147434 0.989072 34.1736 30.037)",
                  fill: "white",
                }),
                (0, i.jsx)("ellipse", {
                  cx: "3.05457",
                  cy: "3.29382",
                  rx: "3.05457",
                  ry: "3.29382",
                  transform:
                    "matrix(0.994439 0.105316 -0.103587 0.99462 47.8252 31.2857)",
                  fill: "white",
                }),
                (0, i.jsx)("path", {
                  d: "M91.2917 66.8517C91.4127 67.3605 91.1004 67.873 90.5943 67.9964L50.7065 77.723C50.2004 77.8464 49.692 77.5339 49.5711 77.0252L43.9267 53.2801C43.8057 52.7713 44.118 52.2588 44.6241 52.1354L84.5118 42.4089C85.018 42.2855 85.5263 42.5979 85.6472 43.1067L91.2916 66.8517L91.2917 66.8517Z",
                  fill: "#FCC13A",
                }),
                (0, i.jsx)("path", {
                  d: "M85.6247 43.1084C85.5033 42.5986 84.993 42.2856 84.485 42.4093L82.0559 43.0004C82.564 42.8768 83.0743 43.1898 83.1957 43.6995L88.8618 67.4896C88.9832 67.9994 88.6698 68.5129 88.1617 68.6365L90.5908 68.0453C91.0988 67.9217 91.4123 67.4082 91.2909 66.8985L85.6247 43.1084Z",
                  fill: "#FFC250",
                }),
                (0, i.jsx)("path", {
                  d: "M62.7807 60.3672L50.5422 77.749C50.7061 77.7401 50.6408 77.736 52.4401 77.3025L63.8368 61.1162C64.044 60.8219 63.9755 60.4158 63.6839 60.209C63.3923 60.0021 62.9879 60.0729 62.7807 60.3672Z",
                  fill: "#F7B520",
                }),
                (0, i.jsx)("path", {
                  d: "M72.0694 58.1354C71.7531 57.9691 71.3612 58.0928 71.1943 58.4118C71.0273 58.7306 71.1485 59.124 71.4649 59.2902L88.8706 68.4374L90.5948 68.016C90.6528 68.0018 90.708 67.982 90.7607 67.9582L72.0694 58.1354Z",
                  fill: "#F7B520",
                }),
                (0, i.jsx)("path", {
                  d: "M86.3845 46.2628L68.3817 63.3329L44.6774 56.4284L43.9266 53.2716C43.8057 52.7632 44.1179 52.251 44.6238 52.1277L84.4987 42.4087C85.0047 42.2854 85.5128 42.5976 85.6337 43.106L86.3845 46.2628L86.3845 46.2628Z",
                  fill: "#FFE07D",
                }),
                (0, i.jsx)("path", {
                  d: "M72.4152 61.363C72.5447 61.908 72.0526 62.475 71.9698 62.9965C71.884 63.5371 72.1689 64.2275 71.8887 64.6875C71.6085 65.1474 70.8669 65.2068 70.4268 65.5296C70.0022 65.841 69.7236 66.5393 69.1816 66.6715C68.6396 66.8036 68.0779 66.3103 67.5599 66.2288C67.023 66.1442 66.3359 66.4333 65.8798 66.1529C65.4236 65.8725 65.3671 65.1264 65.0479 64.6846C64.7399 64.2584 64.0469 63.9804 63.9174 63.4355C63.7879 62.8905 64.28 62.3235 64.3628 61.802C64.4486 61.2614 64.1637 60.571 64.4439 60.111C64.7241 59.651 65.4657 59.5916 65.9058 59.2689C66.3304 58.9574 66.609 58.2592 67.151 58.127C67.693 57.9948 68.2547 58.4881 68.7727 58.5696C69.3096 58.6542 69.9967 58.3651 70.4528 58.6455C70.909 58.9259 70.9655 59.672 71.2847 60.1138C71.5927 60.5401 72.2857 60.8181 72.4152 61.363Z",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("path", {
                  d: "M68.7201 64.7352C67.437 65.049 66.1447 64.2563 65.8394 62.9683C65.534 61.6802 66.3294 60.377 67.6124 60.0633C68.8955 59.7496 70.1878 60.5423 70.4932 61.8304C70.7985 63.1184 70.0031 64.4215 68.7201 64.7352ZM67.9125 61.329C67.3246 61.4727 66.9602 62.0698 67.1001 62.6599C67.24 63.2501 67.8321 63.6132 68.42 63.4694C69.0078 63.3257 69.3723 62.7287 69.2324 62.1386C69.0924 61.5484 68.5003 61.1852 67.9125 61.329Z",
                  fill: "white",
                }),
                (0, i.jsx)("path", {
                  d: "M81.983 53.7231C81.0891 50.7438 82.7797 47.604 85.759 46.7101C88.7384 45.8162 89.6305 48.1811 90.5244 51.1605C91.4183 54.1398 91.9754 56.6052 88.9961 57.4991C86.0168 58.393 82.8769 56.7025 81.983 53.7231Z",
                  fill: "#6842FF",
                }),
                (0, i.jsx)("path", {
                  d: "M89.7581 15.8378C88.7325 13.1545 86.2661 12.2655 84.2535 13.8537C83.2279 11.1704 80.7614 10.2814 78.7488 11.8696C76.7296 13.4554 75.9232 16.9201 76.9488 19.6034C76.9488 19.6034 79.348 25.8897 81.2893 26.5895C83.2305 27.2892 87.9581 23.5717 87.9581 23.5717C89.9773 21.9859 90.7837 18.5212 89.7581 15.8378Z",
                  fill: "#FF637F",
                }),
              ],
            });
        let eX = (e) => {
            let { preSelectedEmail: t } = e,
              { openDrawer: n } = s.useContext(D.s9),
              r = s.useContext(C.Z),
              { user: o } = s.useContext(a.S),
              [l, c] = s.useState(o?.email ?? t ?? ""),
              [u, d] = s.useState(!1),
              h = s.useRef(0),
              _ = (0, M.Z)(),
              y = !r.isDesktop,
              [x, { data: p, loading: m, error: g }] = (0, F.D)(b.yT);
            s.useEffect(
              () =>
                function () {
                  h.current && window.clearTimeout(h.current);
                },
              []
            );
            let f = (e) => {
                let t = e.target.value;
                c(t);
              },
              B = async () => {
                x({
                  variables: {
                    input: { email: l, redirectUrl: window.location.href },
                  },
                }).catch((e) => {
                  let t = e?.graphQLErrors?.[0]?.extensions?.code;
                  "forgotPasswordRateLimitExceeded" === t &&
                    (d(!0),
                    h.current && window.clearTimeout(h.current),
                    (h.current = window.setTimeout(() => {
                      d(!1);
                    }, 6e4)));
                });
              },
              w = () => {
                o
                  ? n("editPassword", { isExiting: !0 })
                  : n("signInEmail", {
                      isExiting: !0,
                      params: { preSelectedEmail: l },
                    });
              },
              j = !!p,
              z = j
                ? (0, i.jsx)(L.Hz, {
                    sx: { p: 2 },
                    children: (0, i.jsx)(S.cC, {
                      id: "auth.ui.reset.confirmation",
                    }),
                  })
                : (0, i.jsx)(L.Hz, {
                    sx: { pt: 2, mb: 2 },
                    children: (0, i.jsx)(S.cC, {
                      id: "auth.ui.reset.mainText",
                    }),
                  });
            return (0, i.jsx)(eP.Z, {
              title: (0, i.jsx)(S.cC, {
                id: "auth.ui.header.forgotmypassword",
              }),
              onBack: w,
              fixHeader: !0,
              children: (0, i.jsx)(W, {
                children: (0, i.jsxs)(H, {
                  isMobile: y,
                  sx: { pt: 0 },
                  children: [
                    j ? (0, i.jsx)(eQ, {}) : (0, i.jsx)(eK, {}),
                    (0, i.jsx)(L.mH, {
                      children: j
                        ? (0, i.jsx)(S.cC, {
                            id: "auth.ui.header.resetConfirmation",
                          })
                        : (0, i.jsx)(S.cC, {
                            id: "auth.ui.header.resetpassword",
                          }),
                    }),
                    z,
                    (0, i.jsx)("div", {
                      style: { width: "100%" },
                      children:
                        (!p || g) &&
                        (0, i.jsx)(N.Z, {
                          value: l,
                          type: "email",
                          label: O.ag._({ id: "auth.ui.label.email" }),
                          onChange: f,
                        }),
                    }),
                    !!p &&
                      (0, i.jsx)("div", {
                        style: { width: "100%", marginTop: _.spacing(2) },
                        children: (0, i.jsx)(K.Z, {
                          height: 50,
                          variant: "contained",
                          onClick: w,
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.button.back",
                          }),
                        }),
                      }),
                    !p &&
                      (0, i.jsxs)(i.Fragment, {
                        children: [
                          (0, i.jsx)("div", {
                            style: { width: "100%", marginTop: _.spacing(2) },
                            children: (0, i.jsx)(A.Z, {
                              loading: m,
                              height: 50,
                              variant: "contained",
                              onClick: B,
                              disabled: !(0, V.o)(l),
                              children: (0, i.jsx)(S.cC, {
                                id: "auth.ui.button.passwordReset",
                              }),
                            }),
                          }),
                          u &&
                            (0, i.jsx)("div", {
                              style: {
                                width: "100%",
                                marginTop: _.spacing(2),
                                textAlign: "center",
                                color: ep.D.alert[100],
                              },
                              children: (0, i.jsx)(S.cC, {
                                id: "auth.ui.reset.rateLimited",
                              }),
                            }),
                        ],
                      }),
                  ],
                }),
              }),
            });
          },
          eY = s.memo((e) =>
            (0, i.jsxs)(em.Z, {
              ...e,
              viewBox: "0 0 85 85",
              children: [
                (0, i.jsx)("path", {
                  d: "M0 12V61.8605C0.00295291 63.7331 0.740383 65.528 2.05069 66.8521C3.361 68.1762 5.13731 68.9213 6.99036 68.9243H67.0096C68.8627 68.9213 70.639 68.1762 71.9493 66.8521C73.2596 65.528 73.997 63.7331 74 61.8605V12H0ZM16.8746 33.5386C23.4578 14.3571 50.1827 14.1778 57.0329 33.2584C62.0426 46.6732 51.5806 62.2067 36.9998 61.9538C22.5431 62.1994 12.0786 46.909 16.8746 33.5386ZM27.1157 48.4273C27.6905 51.9489 29.0063 55.3048 30.9743 58.2685C28.6087 57.4438 26.4308 56.1478 24.5696 54.4574C22.7084 52.767 21.2017 50.7165 20.1386 48.4273H27.1157ZM46.8843 48.4273H53.8614C52.7983 50.7165 51.2916 52.767 49.4304 54.4574C47.5692 56.1478 45.3913 57.4438 43.0257 58.2685C44.9937 55.3048 46.3095 51.9489 46.8843 48.4273ZM44.1754 48.4272C41.0044 62.7892 32.9966 62.7925 29.8246 48.4273L44.1754 48.4272ZM44.6246 45.7567H29.3754C28.9172 42.2332 28.9172 38.6644 29.3754 35.1409H44.6246C44.8578 36.9026 44.9726 38.6782 44.9682 40.4555C44.9726 42.2284 44.8578 43.9995 44.6246 45.7567ZM47.2939 35.1409H54.8657C55.87 38.6068 55.87 42.2909 54.8657 45.7567H47.2939C47.5097 43.9981 47.6156 42.2275 47.6111 40.4555C47.6152 38.679 47.5093 36.904 47.2939 35.1409ZM46.8843 32.4703C46.3099 28.9569 44.9939 25.6096 43.0257 22.6558C45.3895 23.4734 47.566 24.7638 49.4254 26.4501C51.2848 28.1363 52.789 30.1838 53.8482 32.4703H46.8843ZM29.8246 32.4704C32.9939 18.1434 41.0051 18.1402 44.1754 32.4703L29.8246 32.4704ZM27.1157 32.4703H20.1518C21.211 30.1838 22.7152 28.1363 24.5746 26.4501C26.434 24.7638 28.6105 23.4734 30.9743 22.6558C29.0061 25.6096 27.6901 28.9569 27.1157 32.4703ZM19.1343 45.7567C18.136 42.29 18.136 38.6076 19.1343 35.1409H26.7061C26.2831 38.6666 26.2831 42.231 26.7061 45.7567H19.1343Z",
                  fill: "url(#paint0_linear_3576_678)",
                }),
                (0, i.jsx)("path", {
                  d: "M67.0096 0H6.99036C5.13731 0.00298393 3.361 0.748161 2.05069 2.07223C0.740383 3.39631 0.00295291 5.19128 0 7.0638V12.405H74V7.0638C73.997 5.19128 73.2596 3.39631 71.9493 2.07223C70.639 0.748161 68.8627 0.00298393 67.0096 0ZM8.98571 8.11869C8.48913 8.11166 8.01524 7.90738 7.66654 7.55004C7.31784 7.1927 7.12236 6.71101 7.12237 6.20916C7.12238 5.70731 7.31788 5.22563 7.6666 4.8683C8.01531 4.51097 8.48921 4.30672 8.98579 4.2997C9.48238 4.30674 9.95626 4.51101 10.305 4.86836C10.6537 5.2257 10.8491 5.70739 10.8491 6.20924C10.8491 6.71109 10.6536 7.19277 10.3049 7.5501C9.95619 7.90743 9.4823 8.11168 8.98571 8.11869ZM16.6236 8.11869C16.127 8.11166 15.6531 7.90738 15.3044 7.55004C14.9557 7.1927 14.7602 6.71101 14.7602 6.20916C14.7602 5.70731 14.9557 5.22563 15.3045 4.8683C15.6532 4.51097 16.1271 4.30672 16.6236 4.2997C17.1202 4.30674 17.5941 4.51101 17.9428 4.86836C18.2915 5.2257 18.487 5.70739 18.487 6.20924C18.487 6.71109 18.2915 7.19277 17.9428 7.5501C17.5941 7.90743 17.1202 8.11168 16.6236 8.11869ZM24.2614 8.11869C23.7648 8.11166 23.291 7.90738 22.9423 7.55004C22.5936 7.1927 22.3981 6.71101 22.3981 6.20916C22.3981 5.70731 22.5936 5.22563 22.9423 4.8683C23.291 4.51097 23.7649 4.30672 24.2615 4.2997C24.7581 4.30674 25.232 4.51101 25.5807 4.86836C25.9294 5.2257 26.1249 5.70739 26.1249 6.20924C26.1248 6.71109 25.9293 7.19277 25.5806 7.5501C25.2319 7.90743 24.758 8.11168 24.2614 8.11869ZM66.2168 7.54451H60.0061C59.6587 7.5398 59.3271 7.39704 59.0831 7.14714C58.8391 6.89723 58.7023 6.56027 58.7023 6.2092C58.7023 5.85812 58.8391 5.52117 59.0831 5.27126C59.3271 5.02135 59.6587 4.8786 60.0061 4.87389H66.2168C66.5639 4.87909 66.895 5.02206 67.1386 5.27192C67.3822 5.52177 67.5188 5.85844 67.5188 6.2092C67.5188 6.55995 67.3822 6.89663 67.1386 7.14648C66.895 7.39634 66.5639 7.53931 66.2168 7.54451Z",
                  fill: "#6842FF",
                }),
                (0, i.jsxs)("g", {
                  filter: "url(#filter0_d_3576_678)",
                  children: [
                    (0, i.jsx)("circle", {
                      cx: "70",
                      cy: "59",
                      r: "15",
                      fill: "#6842FF",
                    }),
                    (0, i.jsx)("circle", {
                      cx: "70",
                      cy: "59",
                      r: "16",
                      fill: "#6842FF",
                      stroke: "white",
                      "stroke-width": "2",
                    }),
                  ],
                }),
                (0, i.jsx)("path", {
                  d: "M62 56.4987C62.2449 56.4987 62.4813 56.5887 62.6644 56.7514C62.8474 56.9142 62.9643 57.1384 62.993 57.3817L63 57.4987V58.4987C62.9999 60.0511 63.6016 61.5431 64.6785 62.6612C65.7554 63.7793 67.2237 64.4365 68.775 64.4947L69 64.4987H72.586L71.793 63.7057C71.6137 63.5257 71.5095 63.2843 71.5018 63.0303C71.494 62.7764 71.5832 62.529 71.7512 62.3384C71.9193 62.1479 72.1536 62.0284 72.4065 62.0043C72.6594 61.9802 72.912 62.0533 73.113 62.2087L73.207 62.2917L75.707 64.7917C75.8573 64.9421 75.9557 65.1365 75.988 65.3467L76 65.5087C75.9979 65.7285 75.9234 65.9415 75.788 66.1147L75.703 66.2097L73.207 68.7057C73.027 68.885 72.7856 68.9892 72.5316 68.9969C72.2777 69.0047 72.0303 68.9155 71.8397 68.7474C71.6492 68.5794 71.5297 68.3451 71.5056 68.0922C71.4815 67.8393 71.5546 67.5867 71.71 67.3857L71.793 67.2917L72.586 66.4987H69C66.9216 66.4987 64.9247 65.6898 63.4323 64.2432C61.9398 62.7967 61.069 60.8261 61.004 58.7487L61 58.4987V57.4987C61 57.2335 61.1054 56.9791 61.2929 56.7916C61.4804 56.6041 61.7348 56.4987 62 56.4987ZM66.793 50.2917C66.973 50.1123 67.2144 50.0082 67.4684 50.0005C67.7223 49.9927 67.9697 50.0819 68.1603 50.2499C68.3508 50.418 68.4703 50.6522 68.4944 50.9052C68.5185 51.1581 68.4454 51.4107 68.29 51.6117L68.207 51.7057L67.414 52.4987H71C73.0784 52.4987 75.0753 53.3076 76.5677 54.7542C78.0602 56.2007 78.931 58.1713 78.996 60.2487L79 60.4987V61.4987C78.9997 61.7536 78.9021 61.9987 78.7272 62.1841C78.5522 62.3694 78.313 62.4809 78.0586 62.4959C77.8042 62.5108 77.5536 62.428 77.3582 62.2644C77.1627 62.1008 77.0371 61.8688 77.007 61.6157L77 61.4987V60.4987C77.0001 58.9463 76.3984 57.4543 75.3215 56.3362C74.2446 55.2181 72.7763 54.5609 71.225 54.5027L71 54.4987H67.414L68.207 55.2917C68.3863 55.4717 68.4905 55.7131 68.4982 55.9671C68.506 56.221 68.4168 56.4684 68.2488 56.659C68.0807 56.8495 67.8464 56.969 67.5935 56.9931C67.3406 57.0172 67.088 56.9441 66.887 56.7887L66.793 56.7057L64.293 54.2057C64.1208 54.0335 64.0174 53.8044 64.0021 53.5614C63.9868 53.3183 64.0607 53.0781 64.21 52.8857L64.293 52.7917L66.793 50.2917Z",
                  fill: "#E7E7E7",
                }),
                (0, i.jsxs)("defs", {
                  children: [
                    (0, i.jsxs)("filter", {
                      id: "filter0_d_3576_678",
                      x: "29",
                      y: "23",
                      width: "82",
                      height: "82",
                      filterUnits: "userSpaceOnUse",
                      "color-interpolation-filters": "sRGB",
                      children: [
                        (0, i.jsx)("feFlood", {
                          "flood-opacity": "0",
                          result: "BackgroundImageFix",
                        }),
                        (0, i.jsx)("feColorMatrix", {
                          in: "SourceAlpha",
                          type: "matrix",
                          values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                          result: "hardAlpha",
                        }),
                        (0, i.jsx)("feOffset", { dy: "5" }),
                        (0, i.jsx)("feGaussianBlur", { stdDeviation: "12" }),
                        (0, i.jsx)("feComposite", {
                          in2: "hardAlpha",
                          operator: "out",
                        }),
                        (0, i.jsx)("feColorMatrix", {
                          type: "matrix",
                          values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.45 0",
                        }),
                        (0, i.jsx)("feBlend", {
                          mode: "normal",
                          in2: "BackgroundImageFix",
                          result: "effect1_dropShadow_3576_678",
                        }),
                        (0, i.jsx)("feBlend", {
                          mode: "normal",
                          in: "SourceGraphic",
                          in2: "effect1_dropShadow_3576_678",
                          result: "shape",
                        }),
                      ],
                    }),
                    (0, i.jsxs)("linearGradient", {
                      id: "paint0_linear_3576_678",
                      x1: "0",
                      y1: "40.4622",
                      x2: "74",
                      y2: "40.4622",
                      gradientUnits: "userSpaceOnUse",
                      children: [
                        (0, i.jsx)("stop", { "stop-color": "white" }),
                        (0, i.jsx)("stop", {
                          offset: "1",
                          "stop-color": "#E1E1E1",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            })
          );
        var e$ = n(81187),
          eJ = n.n(e$);
        let e0 = (e) => {
          let { title: t } = e,
            { openDrawer: n } = s.useContext(D.s9),
            r = s.useContext(C.Z),
            o = () => n("signIn");
          return (0, i.jsx)(i.Fragment, {
            children: (0, i.jsx)(eP.Z, {
              onBack: o,
              fixHeader: !0,
              children: (0, i.jsx)(W, {
                children: (0, i.jsxs)(H, {
                  isMobile: r.isMobile,
                  sx: {
                    display: "flex",
                    justifyContent: "space-between",
                    height: "100%",
                    pt: 0,
                  },
                  children: [
                    (0, i.jsx)(L.mH, { children: t }),
                    (0, i.jsxs)("div", {
                      className: eJ().content,
                      children: [
                        (0, i.jsx)(eY, {
                          style: {
                            color: ep.D.success[100],
                            width: 85,
                            height: 74,
                          },
                        }),
                        (0, i.jsx)(L.Fd, {
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.login.browsernotsupported",
                          }),
                        }),
                        (0, i.jsx)("div", {
                          className: eJ().text,
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.login.browsernotsupported.text",
                          }),
                        }),
                        (0, i.jsx)(K.Z, {
                          variant: "contained",
                          height: 50,
                          fullWidth: !0,
                          onClick: o,
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.button.gotit",
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            }),
          });
        };
        var e1 = n(23500);
        let e6 = () => {
          let { openDrawer: e } = s.useContext(D.s9),
            t = s.useContext(C.Z),
            { user: n } = s.useContext(a.S),
            { services: r } = s.useContext(w.Z),
            o = (0, M.Z)(),
            l = !t.isDesktop,
            c = () =>
              (0, i.jsx)("a", {
                onClick: (t) => {
                  t.preventDefault(),
                    e("privacyPreferences", {
                      isExiting: !1,
                      returnToDrawer: "accountConfirmation",
                    });
                },
                href: "#",
                style: { color: ep.D.brand[60] },
                children: (0, i.jsx)(S.cC, {
                  id: "auth.ui.privacyPreferences",
                }),
              }),
            u = () => {
              e(null);
            },
            d = () => {
              e(null);
            },
            h = () => {
              e("editProfile", {
                isExiting: !1,
                returnToDrawer: "accountConfirmation",
              });
            };
          return (
            s.useEffect(() => {
              (0, e1.Z)(r.userInfoService).catch((e) => {
                console.error(e);
              });
            }, [r]),
            (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(L.gu, {
                  children: (0, i.jsx)(E.Qh, {
                    color: "white",
                    onClick: d,
                    children: (0, i.jsx)(U.Z, {}),
                  }),
                }),
                (0, i.jsx)(W, {
                  children: (0, i.jsxs)(H, {
                    isMobile: l,
                    children: [
                      (0, i.jsx)("div", {
                        style: { height: 154 },
                        children: (0, i.jsx)("img", {
                          src: (0, eS.ZP)("userportal/ziggy_celebration.png"),
                          alt: "Ziggy celebration",
                        }),
                      }),
                      (0, i.jsx)(L.mH, {
                        sx: {
                          px: (e) => `${e.spacing(5)} !important`,
                          pt: 3,
                          textAlign: "center",
                        },
                        children: (0, i.jsx)(S.cC, {
                          id: "auth.ui.signupConfirm.title",
                        }),
                      }),
                      !n?.emailVerified &&
                        (0, i.jsx)(L.Hz, {
                          sx: { pt: 2, px: 3 },
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.signupConfirm.body",
                          }),
                        }),
                      (0, i.jsx)("div", {
                        style: {
                          width: "100%",
                          padding: o.spacing(1),
                          marginTop: o.spacing(),
                        },
                        children: (0, i.jsx)(K.Z, {
                          height: 50,
                          variant: "contained",
                          onClick: u,
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.button.ok",
                          }),
                        }),
                      }),
                      (0, i.jsx)("div", {
                        style: { width: "100%", padding: o.spacing(1) },
                        children: (0, i.jsx)(K.Z, {
                          height: 50,
                          variant: "outlined",
                          color: "white",
                          onClick: h,
                          children: (0, i.jsx)(S.cC, {
                            id: "auth.ui.button.customize",
                          }),
                        }),
                      }),
                      (0, i.jsx)("div", {
                        style: {
                          width: "100%",
                          color: ep.D.white[50],
                          textAlign: "center",
                          padding: o.spacing(1),
                          marginTop: o.spacing(),
                        },
                        children: (0, i.jsx)(S.cC, {
                          id: "auth.ui.privacySetting",
                          values: { privacyLink: (0, i.jsx)(c, {}) },
                        }),
                      }),
                    ],
                  }),
                }),
              ],
            })
          );
        };
        var e2 = n(43016);
        let e4 = () => {
            let { openDrawer: e } = s.useContext(D.s9),
              { crazyAnalyticsService: t } = s.useContext(w.Z).services;
            return (0, i.jsx)(i.Fragment, {
              children: (0, i.jsxs)(W, {
                children: [
                  (0, i.jsx)("div", {
                    style: {
                      display: "flex",
                      alignContent: "center",
                      alignItems: "center",
                      flexFlow: "row wrap",
                      justifyContent: "center",
                      marginBottom: 14,
                    },
                    children: (0, i.jsx)(L.mH, {
                      children: (0, i.jsx)(S.cC, {
                        id: "auth.ui.usernameConfirm.title",
                      }),
                    }),
                  }),
                  (0, i.jsx)(e2.Z, {
                    isUserRegistering: !0,
                    onUsernameUpdate: () => {
                      t.userAction("profile", "registration_completed", "true"),
                        e("aboutYou");
                    },
                  }),
                ],
              }),
            });
          },
          e7 = () =>
            (0, i.jsx)(eP.Z, {
              fixHeader: !0,
              customTitleStyles: { fontWeight: 700, color: ep.D.white[100] },
              title: (0, i.jsx)(S.cC, { id: "auth.ui.button.signup" }),
              children: (0, i.jsx)(e4, {}),
            });
        var e5 = n(38841),
          e3 = n.n(e5),
          e8 = n(2490);
        let e9 = s.memo(() => {
            let { openDrawer: e } = s.useContext(D.s9),
              t = (0, s.useCallback)(() => {
                e("signIn");
              }, [e]);
            return (0, i.jsxs)("div", {
              className: e3().loginPill,
              children: [
                (0, i.jsx)("div", {
                  className: e3().title,
                  children: (0, i.jsx)(S.cC, {
                    id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.loginFirst",
                  }),
                }),
                (0, i.jsx)("div", {
                  className: e3().text,
                  children: (0, i.jsx)(S.cC, {
                    id: "friends.playWithFriendsDrawer.signInMessage",
                  }),
                }),
                (0, i.jsx)(K.Z, {
                  fullWidth: !0,
                  variant: "contained",
                  onClick: t,
                  children: (0, i.jsx)(S.cC, { id: "auth.ui.button.login" }),
                }),
              ],
            });
          }),
          te = s.memo((e) => {
            let { title: t, children: n } = e;
            return (0, i.jsxs)("div", {
              className: e3().section,
              children: [
                (0, i.jsx)("div", { className: e3().title, children: t }),
                (0, i.jsx)("div", { className: e3().text, children: n }),
              ],
            });
          }),
          tt = s.memo(() => (0, i.jsx)("div", { className: e3().divider })),
          tn = s.memo(() => {
            let { user: e } = (0, s.useContext)(a.S),
              t = (0, eS.ZP)("frienditem.svg", {}, !1),
              n = (0, eS.ZP)("invitefriends.svg", {}, !1),
              r = (0, eS.ZP)("invitelist.svg", {}, !1),
              { openDrawer: o } = s.useContext(D.s9),
              l = (0, S.mV)(),
              c = (0, e8.Z)(),
              u = (0, s.useCallback)(() => {
                c("close"), o(null);
              }, [c, o]);
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(eL.Z, {
                  onClose: u,
                  title: l._(
                    "friends.playWithFriendsDrawer.howToPlayWithFriends"
                  ),
                }),
                (0, i.jsxs)(L.qt, {
                  className: e3().root,
                  children: [
                    !e && (0, i.jsx)(e9, {}),
                    (0, i.jsx)(te, {
                      title: l._("friends.upDrawer.friends.addFriends"),
                      children: (0, i.jsx)(S.cC, {
                        id: "friends.playWithFriendsDrawer.addFriends.instructions",
                      }),
                    }),
                    (0, i.jsx)(tt, {}),
                    (0, i.jsxs)(te, {
                      title: l._(
                        "friends.playWithFriendsDrawer.joinYourFriends"
                      ),
                      children: [
                        (0, i.jsx)(S.cC, {
                          id: "friends.playWithFriendsDrawer.joinYourFriends.instructions",
                        }),
                        (0, i.jsx)("img", {
                          src: t,
                          alt: l._("friends.playWithFriendsDrawer.joinExample"),
                        }),
                      ],
                    }),
                    (0, i.jsx)(tt, {}),
                    (0, i.jsxs)(te, {
                      title: l._(
                        "friends.playWithFriendsDrawer.inviteFriendsToPlay"
                      ),
                      children: [
                        (0, i.jsx)(S.cC, {
                          id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.instructions",
                        }),
                        (0, i.jsxs)("ol", {
                          className: e3().inviteSteps,
                          children: [
                            (0, i.jsx)("li", {
                              children: (0, i.jsx)(S.cC, {
                                id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.instructions.step1",
                              }),
                            }),
                            (0, i.jsx)("li", {
                              children: (0, i.jsx)(S.cC, {
                                id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.instructions.step2",
                              }),
                            }),
                            (0, i.jsxs)("li", {
                              children: [
                                (0, i.jsx)(S.cC, {
                                  id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.instructions.step3",
                                }),
                                (0, i.jsx)("img", {
                                  src: n,
                                  alt: l._(
                                    "friends.playWithFriendsDrawer.inviteFriendsButton"
                                  ),
                                }),
                              ],
                            }),
                            (0, i.jsx)("li", {
                              children: (0, i.jsx)(S.cC, {
                                id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.instructions.step4",
                              }),
                            }),
                          ],
                        }),
                        (0, i.jsx)("img", {
                          src: r,
                          alt: l._(
                            "friends.playWithFriendsDrawer.inviteFriendsList"
                          ),
                        }),
                        (0, i.jsx)(S.cC, {
                          id: "friends.playWithFriendsDrawer.inviteFriendsToPlay.instructions.step5",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            });
          });
        var ti = n(66511),
          tr = n(58362),
          to = n(56774);
        let ts = (0, G.ZP)("div", {
          shouldForwardProp: (e) => "isDesktop" !== e,
        })((e) => {
          let {
            theme: { breakpoints: t, spacing: n, dimensions: i },
            isDesktop: r,
          } = e;
          return {
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            columnGap: n(0.5),
            rowGap: n(0.5),
            width: "100%",
            maxWidth: r
              ? (i.gameThumb.width + 8) * 2
              : (i.gameThumb.mobileWidth + 8) * 2,
            [t.up("gp_x9")]: {
              maxWidth: r
                ? (i.gameThumb.width + 12) * 2
                : (i.gameThumb.mobileWidth + 12) * 2,
            },
          };
        });
        var ta = n(51491),
          tl = n(11163);
        let tc = (e) => {
            let { games: t, thumbIcon: n, thumbIconFn: r } = e,
              o = s.useContext(C.Z),
              a = (0, ta.Z)(),
              { openDrawer: l } = s.useContext(D.s9),
              c = (0, tl.useRouter)(),
              u = c.query.game,
              d = (0, s.useCallback)(() => l(null), [l]),
              h = t.map((e) => {
                let {
                  iosFriendly: t,
                  androidFriendly: n,
                  mobileFriendly: i,
                  ...r
                } = e;
                return {
                  ...r,
                  mobileFriendly: i || (a ? t : n),
                  iosFriendly: t,
                  androidFriendly: n,
                };
              });
            return (0, i.jsx)(ts, {
              isDesktop: o.isDesktop,
              children: h.map((e) =>
                (0, i.jsx)(
                  to.oZ,
                  {
                    game: e,
                    iconFn: () => {
                      r && r(e.id);
                    },
                    icon: n,
                    isResponsiveGrid: !0,
                    onClickAction: () => {
                      e.slug === u && d();
                    },
                  },
                  e.slug
                )
              ),
            });
          },
          tu = s.memo((e) => {
            let { plainFill: t, ...n } = e;
            return (0, i.jsxs)(em.Z, {
              ...n,
              width: "120",
              height: "120",
              viewBox: "0 0 120 120",
              fill: "none",
              children: [
                (0, i.jsx)("path", {
                  fillRule: "evenodd",
                  clipRule: "evenodd",
                  d: "M40.2223 15C33.318 15 27.6735 16.4827 23.1717 19.1231C18.6594 21.7698 15.571 25.4186 13.5457 29.3108C9.59151 36.9098 9.62884 45.499 10.593 50.4327C13.1027 63.2751 22.0972 76.7358 31.5186 86.7905C36.2887 91.8812 41.354 96.3 46.0789 99.4881C50.5575 102.51 55.5562 105 60.0001 105C64.444 105 69.4427 102.51 73.9213 99.4881C78.6462 96.3 83.7115 91.8812 88.4816 86.7905C97.903 76.7358 106.897 63.2751 109.407 50.4327C110.371 45.499 110.409 36.9098 106.455 29.3108C104.429 25.4186 101.341 21.7698 96.8285 19.1231C92.3267 16.4827 86.6822 15 79.7779 15C74.2905 15 69.5521 17.478 65.892 20.5653C63.6296 22.4736 61.6515 24.7163 60.0001 27.0366C58.3487 24.7163 56.3706 22.4736 54.1082 20.5653C50.4481 17.478 45.7097 15 40.2223 15Z",
                  fill: t ? "#2F3148" : "url(#paint0_linear_1861_3922)",
                }),
                (0, i.jsx)("defs", {
                  children: (0, i.jsxs)("linearGradient", {
                    id: "paint0_linear_1861_3922",
                    x1: "60.0001",
                    y1: "15",
                    x2: "60.0001",
                    y2: "105",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                      (0, i.jsx)("stop", { stopColor: "#B634C1" }),
                      (0, i.jsx)("stop", { offset: "1", stopColor: "#FF8BA7" }),
                    ],
                  }),
                }),
              ],
            });
          }),
          td = () => {
            let { favourites: e, removeFromFavourite: t } = s.useContext(tr.Q),
              { user: n } = s.useContext(a.S),
              { spacing: r } = (0, M.Z)();
            return e && e.length > 0
              ? (0, i.jsx)(L.Q4, {
                  children: (0, i.jsx)(tc, {
                    games: e,
                    thumbIconFn: t,
                    thumbIcon: (0, i.jsx)(U.Z, {}),
                  }),
                })
              : (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsxs)(L.S$, {
                      sx: { px: 7, pb: n ? void 0 : 0 },
                      children: [
                        (0, i.jsx)(tu, {
                          plainFill: !!n,
                          sx: { height: 50, width: 50, mb: 2 },
                        }),
                        n
                          ? (0, i.jsx)(L.TK, {
                              children: (0, i.jsx)(S.cC, {
                                id: "common.upDrawer.myGames.favourites.subtitleUser",
                              }),
                            })
                          : (0, i.jsx)(L.Fd, {
                              sx: { pb: 0 },
                              children: (0, i.jsx)(S.cC, {
                                id: "common.upDrawer.myGames.favourites.subtitle",
                              }),
                            }),
                      ],
                    }),
                    !n &&
                      (0, i.jsx)("div", {
                        style: { paddingLeft: r(2), paddingRight: r(2) },
                        children: (0, i.jsx)(eb, {}),
                      }),
                  ],
                });
          };
        var th = n(79282),
          t_ = n(4388),
          ty = n(1795),
          tx = n.n(ty);
        let tp = () => {
          let {
              recent: e,
              removeFromRecent: t,
              error: n,
              reload: r,
            } = s.useContext(k.rh),
            { spacing: o } = (0, M.Z)();
          return e && e.length > 0
            ? (0, i.jsx)(L.Q4, {
                children: (0, i.jsx)(tc, {
                  games: e,
                  thumbIconFn: e.length > 0 ? t : void 0,
                  thumbIcon: e.length > 0 ? (0, i.jsx)(U.Z, {}) : void 0,
                }),
              })
            : n
            ? (0, i.jsx)(L.S$, {
                children: (0, i.jsxs)("div", {
                  className: tx().recentMyGamesDrawerError,
                  children: [
                    (0, i.jsx)(L.TK, {
                      children: (0, i.jsx)(S.cC, {
                        id: "common.upDrawer.recentError",
                      }),
                    }),
                    (0, i.jsxs)(E.Sn, {
                      variant: "contained",
                      color: "purple",
                      onClick: r,
                      children: [
                        (0, i.jsx)(t_.Z, {}),
                        (0, i.jsx)(S.cC, {
                          id: "common.upDrawer.recentReload",
                        }),
                      ],
                    }),
                  ],
                }),
              })
            : (0, i.jsxs)(L.S$, {
                children: [
                  (0, i.jsx)("div", {
                    style: { height: 120 },
                    children: (0, i.jsx)(th.Z, {
                      sx: { color: ep.D.black[50], width: 120, height: 120 },
                    }),
                  }),
                  (0, i.jsx)("div", {
                    style: {
                      paddingLeft: o(4),
                      paddingRight: o(4),
                      marginTop: o(),
                    },
                    children: (0, i.jsx)(L.TK, {
                      children: (0, i.jsx)(S.cC, {
                        id: "common.upDrawer.recentEmpty",
                      }),
                    }),
                  }),
                ],
              });
        };
        var tm = n(29874),
          tg = n(86650);
        let tC = s.memo((e) => {
            let { plainFill: t, ...n } = e;
            return (0, i.jsxs)(em.Z, {
              ...n,
              width: "120",
              height: "120",
              viewBox: "0 0 120 120",
              fill: "none",
              children: [
                (0, i.jsx)("path", {
                  d: "M12 63.125C12 61.8939 12.2419 60.6748 12.7118 59.5373C13.1817 58.3999 13.8705 57.3664 14.7389 56.4959C15.6072 55.6253 16.638 54.9348 17.7725 54.4636C18.9071 53.9925 20.123 53.75 21.351 53.75C22.579 53.75 23.795 53.9925 24.9295 54.4636C26.064 54.9348 27.0949 55.6253 27.9632 56.4959C28.8315 57.3664 29.5203 58.3999 29.9902 59.5373C30.4602 60.6748 30.702 61.8939 30.702 63.125V100.625C30.702 103.111 29.7169 105.496 27.9632 107.254C26.2095 109.012 23.8311 110 21.351 110C18.871 110 16.4925 109.012 14.7389 107.254C12.9852 105.496 12 103.111 12 100.625V63.125ZM36.9361 62.0812V96.0187C36.935 98.3416 37.5795 100.619 38.7974 102.595C40.0153 104.571 41.7583 106.168 43.8309 107.206L44.1426 107.362C47.6018 109.096 51.4156 109.999 55.2828 110H89.0462C91.9296 110.001 94.7243 109 96.9544 107.168C99.1845 105.335 100.712 102.785 101.277 99.95L108.758 62.45C109.12 60.6367 109.075 58.7656 108.629 56.9715C108.182 55.1774 107.343 53.5051 106.174 52.0751C105.005 50.645 103.533 49.4929 101.866 48.7018C100.199 47.9107 98.3777 47.5002 96.5333 47.5H74.3402V22.5C74.3402 19.1848 73.0266 16.0054 70.6884 13.6612C68.3502 11.317 65.1789 10 61.8721 10C60.2188 10 58.6331 10.6585 57.464 11.8306C56.2949 13.0027 55.6381 14.5924 55.6381 16.25V20.4187C55.6381 25.828 53.8882 31.0913 50.6509 35.4187L41.9233 47.0812C38.686 51.4087 36.9361 56.672 36.9361 62.0812Z",
                  fill: t ? "#2F3148" : "url(#paint0_linear_1861_3955)",
                }),
                (0, i.jsx)("defs", {
                  children: (0, i.jsxs)("linearGradient", {
                    id: "paint0_linear_1861_3955",
                    x1: "60.5",
                    y1: "10",
                    x2: "60.5",
                    y2: "110",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                      (0, i.jsx)("stop", { stopColor: "#AA3FFF" }),
                      (0, i.jsx)("stop", { offset: "1", stopColor: "#7ED1FF" }),
                    ],
                  }),
                }),
              ],
            });
          }),
          tf = () => {
            let { liked: e } = s.useContext(tg.w3),
              { user: t } = s.useContext(a.S),
              { spacing: n } = (0, M.Z)();
            return e && e.length > 0
              ? (0, i.jsx)(L.Q4, { children: (0, i.jsx)(tc, { games: e }) })
              : (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsxs)(L.S$, {
                      sx: { px: 7, textAlign: "center", pb: t ? void 0 : 0 },
                      children: [
                        (0, i.jsx)(tC, {
                          plainFill: !!t,
                          sx: { height: 50, width: 50, mb: 2 },
                        }),
                        t
                          ? (0, i.jsx)(L.TK, {
                              children: (0, i.jsx)(S.cC, {
                                id: "common.upDrawer.myGames.liked.subtitleUser",
                                values: { icon: (0, i.jsx)(tm.Z, {}) },
                              }),
                            })
                          : (0, i.jsx)(L.Fd, {
                              children: (0, i.jsx)(S.cC, {
                                id: "common.upDrawer.myGames.liked.subtitle",
                              }),
                            }),
                      ],
                    }),
                    !t &&
                      (0, i.jsx)("div", {
                        style: { paddingLeft: n(2), paddingRight: n(2) },
                        children: (0, i.jsx)(eb, {}),
                      }),
                  ],
                });
          };
        var tB = n(94984);
        let tw = (e) => {
          let { defaultTab: t = "recent" } = e,
            [n, r] = s.useState(t);
          return (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)(eL.Z, {
                title: O.ag._({ id: "common.upDrawer.myGames.title" }),
              }),
              (0, i.jsx)("div", {
                style: { display: "flex" },
                children: (0, i.jsxs)(ti.Y, {
                  style: { width: "100%" },
                  value: n,
                  onChange: (e, t) => {
                    r(t);
                  },
                  centered: !0,
                  children: [
                    (0, i.jsx)(ti.i, {
                      label: O.ag._({ id: "common.upDrawer.recent" }),
                      value: "recent",
                    }),
                    (0, i.jsx)(ti.i, {
                      label: O.ag._({
                        id: "common.upDrawer.myGames.favourites",
                      }),
                      value: "favourites",
                    }),
                    (0, i.jsx)(ti.i, {
                      label: O.ag._({ id: "common.upDrawer.liked" }),
                      value: "liked",
                    }),
                  ],
                }),
              }),
              (0, i.jsx)(tB.H, {
                newClickOrigin: "userDrawer",
                children: (0, i.jsxs)(L.qt, {
                  children: [
                    (0, i.jsx)("div", {
                      hidden: "favourites" !== n,
                      style: { width: "100%" },
                      children: (0, i.jsx)(tB.H, {
                        newClickOrigin: "favourites",
                        children: (0, i.jsx)(td, {}),
                      }),
                    }),
                    (0, i.jsx)("div", {
                      hidden: "recent" !== n,
                      style: { width: "100%" },
                      children: (0, i.jsx)(tB.H, {
                        newClickOrigin: "recent",
                        children: (0, i.jsx)(tp, {}),
                      }),
                    }),
                    (0, i.jsx)("div", {
                      hidden: "liked" !== n,
                      style: { width: "100%" },
                      children: (0, i.jsx)(tB.H, {
                        newClickOrigin: "liked",
                        children: (0, i.jsx)(tf, {}),
                      }),
                    }),
                  ],
                }),
              }),
            ],
          });
        };
        var tj = n(44846);
        let tz = (e) => {
            let { underHeaderMode: t, onClick: n } = e,
              { openedDrawer: r } = s.useContext(D.rf);
            return (0, i.jsx)(tj._, {
              onClick: n,
              open: !!r,
              sx: { zIndex: L.Bg - 2 },
              underHeaderMode: t,
            });
          },
          tv = o()(
            () =>
              Promise.all([
                n.e(84275),
                n.e(12389),
                n.e(42298),
                n.e(74086),
                n.e(60961),
              ]).then(n.bind(n, 60961)),
            {
              loadableGenerated: { webpack: () => [60961] },
              loading: () => null,
              ssr: !0,
            }
          ),
          tF = o()(() => n.e(26656).then(n.bind(n, 26656)), {
            loadableGenerated: { webpack: () => [26656] },
            loading: () => null,
            ssr: !0,
          }),
          tb = s.memo((e) => {
            let { drawer: t } = e,
              { openedDrawer: n } = s.useContext(D.rf),
              { params: r } = n || {};
            switch (t) {
              case "signUp":
                return (0, i.jsx)(eW, {});
              case "signUpEmail":
                return (0, i.jsx)(eq, {
                  preSelectedEmail: r?.preSelectedEmail,
                });
              case "signIn":
                return (0, i.jsx)(ek, {
                  preSelectedEmail: r?.preSelectedEmail,
                });
              case "signInGoogle":
                return (0, i.jsx)(eM, {});
              case "signInEmail":
                return (0, i.jsx)(eU, {
                  preSelectedEmail: r?.preSelectedEmail,
                });
              case "passwordReset":
                return (0, i.jsx)(eX, {
                  preSelectedEmail: r?.preSelectedEmail,
                });
              case "accountConfirmation":
                return (0, i.jsx)(e6, {});
              case "authUsernameSelector":
                return (0, i.jsx)(e7, {});
              case "myGames":
                return (0, i.jsx)(tw, {});
              case "myGames-favourite":
                return (0, i.jsx)(tw, { defaultTab: "favourites" });
              case "browserNotSupported":
                return (0, i.jsx)(e0, { title: r?.title });
              case "main":
              case "settings":
              case "avatarSelector":
              case "coverSelector":
              case "usernameSelector":
              case "countrySelector":
              case "birthdaySelector":
              case "deleteAccount":
              case "editEmail":
              case "editPassword":
              case "editProfile":
              case "friends":
              case "aboutYou":
              case "friendsGuest":
              case "privacyPreferences":
              case "notificationPreferences":
              case "shareProfile":
              case "inviteFriends":
              case "notifications":
              case "progressStatus":
              case "progressDelete":
                return (0, i.jsx)(tv, { drawer: t });
              case "mainCrazygames":
              case "mainFeedback":
              case "suggestGame":
              case "businessInquiry":
              case "otherFeedback":
              case "genericThankYouFeedback":
              case "gameThankYouFeedback":
              case "searchGame":
              case "gameFeedback":
              case "feedbackRatelimit":
              case "previewReport":
                return (0, i.jsx)(tF, { drawer: t });
              case "playWithFriends":
                return (0, i.jsx)(tn, {});
              default:
                return null;
            }
          }),
          tk = s.memo((e) => {
            let { drawerType: t, anchor: n } = e,
              { openDrawer: r } = s.useContext(D.s9),
              { isMobile: o } = s.useContext(C.Z),
              a = (0, ec.Z)(),
              l = [
                "mainCrazygames",
                "mainFeedback",
                "suggestGame",
                "businessInquiry",
                "otherFeedback",
                "genericThankYouFeedback",
                "gameThankYouFeedback",
                "feedbackRatelimit",
                "searchGame",
                "gameFeedback",
                "previewReport",
              ].includes(t);
            return o
              ? (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsx)(L.Jn, {
                      anchor: n,
                      hideBackdrop: !a,
                      disablePortal: !1,
                      isMobile: !0,
                      isLandscape: "searchGame" != t && a,
                      open: !!t,
                      zIndex: L.Bg,
                      transitionDuration: 1,
                      onClose: () => r(null),
                      children: !!t && (0, i.jsx)(tb, { drawer: t }),
                    }),
                    a &&
                      (0, i.jsx)(tz, {
                        underHeaderMode: !1,
                        onClick: () => r(null),
                      }),
                  ],
                })
              : (0, i.jsxs)(i.Fragment, {
                  children: [
                    !!t &&
                      (0, i.jsx)(L.Jn, {
                        anchor: n,
                        onClose: () => {
                          r(null);
                        },
                        isMobile: !1,
                        underHeaderMode: !l,
                        open: !0,
                        transitionDuration: 0,
                        zIndex: L.Bg,
                        variant: l ? void 0 : "persistent",
                        children: (0, i.jsx)(tb, { drawer: t }),
                      }),
                    (0, i.jsx)(tz, {
                      underHeaderMode: !l,
                      onClick: () => r(null),
                    }),
                  ],
                });
          }),
          tZ = s.memo(() => {
            let { openedDrawer: e } = s.useContext(D.rf),
              [t, n] = s.useState();
            return (s.useEffect(() => {
              if (!e) {
                n(void 0);
                return;
              }
              if (t?.drawerType === e.drawer) return;
              let i = e?.section === "feedback" ? "left" : "right";
              n({ drawerType: e.drawer, anchor: i });
            }, [e]),
            t)
              ? (0, i.jsx)(tk, { drawerType: t.drawerType, anchor: t.anchor })
              : null;
          }),
          tD = o()(
            () =>
              Promise.all([
                n.e(84275),
                n.e(12389),
                n.e(42298),
                n.e(74086),
                n.e(60961),
              ]).then(n.bind(n, 60961)),
            {
              loadableGenerated: { webpack: () => [60961] },
              loading: () => null,
              ssr: !1,
            }
          ),
          tL = () => {
            let { user: e } = s.useContext(a.S);
            return (0, i.jsxs)(d.Z, {
              children: [
                (0, i.jsx)(tZ, {}),
                e && (0, i.jsx)(tD, {}),
                (0, i.jsx)(z, {}),
                (0, i.jsx)(Z, {}),
              ],
            });
          };
        var tS = tL;
      },
      73983: function (e, t, n) {
        "use strict";
        n.d(t, {
          E: function () {
            return o;
          },
        });
        var i = n(46313),
          r = n(55933);
        function o(e) {
          let { browser: t } = e,
            n = t && t.name ? t.name : null,
            o = t && t.version ? t.version : null;
          return {
            name: n,
            version: o,
            os: e.os || null,
            userAgent: window.navigator.userAgent,
            screenSize: `${screen.width} x ${screen.height}`,
            windowSize: `${window.innerWidth} x ${window.innerHeight}`,
            onPWA: `${!!(0, r.r)()}`,
            portalVersion: i.Z.Instance.version,
          };
        }
      },
      65801: function (e, t, n) {
        "use strict";
        var i = n(61730);
        let r = () =>
          (0, i.Z)("@media (orientation: landscape), (min-width: 481px)");
        t.Z = r;
      },
      12959: function (e, t, n) {
        "use strict";
        function i(e) {
          if (!e || 0 === e.length) return !1;
          let t = RegExp("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
          return t.test(e.toLowerCase());
        }
        n.d(t, {
          o: function () {
            return i;
          },
        });
      },
      70768: function (e, t, n) {
        "use strict";
        n.d(t, {
          l: function () {
            return r;
          },
          r: function () {
            return o;
          },
        });
        var i = n(33209);
        let r = 6;
        function o(e, t, n) {
          if (!e || !e.code) return null;
          let o = (function (e) {
            switch (e) {
              case "auth/invalid-email":
                return { id: "auth.ui.error.invalidEmail" };
              case "auth/requires-recent-login":
                return { id: "common.upDrawer.recentSignInRequired" };
              case "auth/weak-password":
                return {
                  id: "common.upDrawer.minPasswordLength",
                  variables: { ch: r },
                };
              case "auth/wrong-password":
                return { id: "auth.ui.error.wrongPassword" };
              case "auth/email-already-in-use":
              case "auth/account-exists-with-different-credential":
                return { id: "auth.ui.error.emailAlreadyInUse" };
              case "auth/invalid-credential":
                return { id: "common.error.invalid-credential" };
              case "auth/user-not-found":
                return { id: "auth.ui.error.userNotFound" };
              case "auth/invalid-action-code":
                return { id: "emailHandler.error.invalidLink", isShared: !0 };
              case "auth/expired-action-code":
                return { id: "emailHandler.error.expiredLink", isShared: !0 };
              case "auth/user-disabled":
                return { id: "common.error.user-disabled" };
              case "auth/popup-blocked":
                return { id: "common.error.popupBlocked" };
              default:
                return null;
            }
          })(e.code);
          if (!o) return null;
          let s =
            o.isShared && n
              ? (0, i.sN)(o.id, n, t)
              : t._({ id: o.id, values: o.variables });
          return s;
        }
      },
      46413: function (e, t) {
        "use strict";
        let n = new (class {
          fakeFullscreenListeners = [];
          eventKeys = [
            "fullscreenchange",
            "webkitfullscreenchange",
            "mozfullscreenchange",
            "MSFullscreenChange",
          ];
          isInFakeFullscreen = !1;
          removeFullscreenListener(e) {
            this.eventKeys.forEach((t) => {
              document.removeEventListener(t, e);
            });
          }
          addFullscreenListener(e) {
            this.eventKeys.forEach((t) => {
              document.addEventListener(t, e);
            });
          }
          addFakeFullscreenListener(e) {
            this.fakeFullscreenListeners.push(e);
          }
          removeFakeFullscreenListener(e) {
            this.fakeFullscreenListeners = this.fakeFullscreenListeners.filter(
              (t) => t !== e
            );
          }
          isFullscreen() {
            let e = window.document;
            return !!(
              e.fullscreenElement ||
              e.mozFullScreenElement ||
              e.webkitFullscreenElement ||
              e.msFullscreenElement
            );
          }
          isFakeFullscreen() {
            return this.isInFakeFullscreen;
          }
          enteredFakeFullscreen() {
            this.isInFakeFullscreen ||
              ((this.isInFakeFullscreen = !0),
              this.fakeFullscreenListeners.forEach((e) => e()));
          }
          exitFakeFullscreen() {
            this.isInFakeFullscreen &&
              ((this.isInFakeFullscreen = !1),
              this.fakeFullscreenListeners.forEach((e) => e()));
          }
          forceLockOrientation = async (e) => {
            if (
              e &&
              "BOTH" !== e &&
              "screen" in window &&
              window.screen &&
              window.screen.orientation &&
              window.screen.orientation.lock
            )
              try {
                await window.screen.orientation.lock(
                  "PORTRAIT" === e ? "portrait" : "landscape"
                );
              } catch (e) {}
          };
          exitNativeFullscreen() {
            let e = window.document,
              t =
                e.exitFullscreen ||
                e.mozCancelFullScreen ||
                e.webkitExitFullscreen ||
                e.msExitFullscreen;
            return !!t && (window.document.fullscreenElement && t.call(e), !0);
          }
        })();
        t.Z = n;
      },
      42916: function (e, t, n) {
        "use strict";
        var i = n(70768);
        let r = (e) => {
          let t = e.length >= i.l,
            n = /[0-9]/.test(e),
            r = /[^0-9]/.test(e);
          return t && n && r;
        };
        t.Z = r;
      },
      38841: function (e) {
        e.exports = {
          czyButton: "PlayWithFriendsDrawer_czyButton__Xnn2Z",
          "czyButton--contained--purple":
            "PlayWithFriendsDrawer_czyButton--contained--purple__KPpnz",
          "czyButton--contained--white":
            "PlayWithFriendsDrawer_czyButton--contained--white__e5LMj",
          "czyButton--contained--grey":
            "PlayWithFriendsDrawer_czyButton--contained--grey__MKKAA",
          "czyButton--contained--alert":
            "PlayWithFriendsDrawer_czyButton--contained--alert__ZLR0S",
          "czyButton--contained--success":
            "PlayWithFriendsDrawer_czyButton--contained--success__avVzJ",
          "czyButton--contained--black":
            "PlayWithFriendsDrawer_czyButton--contained--black__vlTxC",
          "czyButton--contained--green-gradient":
            "PlayWithFriendsDrawer_czyButton--contained--green-gradient__KgoS0",
          "czyButton--outlined--purple":
            "PlayWithFriendsDrawer_czyButton--outlined--purple__Ca97X",
          "czyButton--link--purple":
            "PlayWithFriendsDrawer_czyButton--link--purple__mPRlc",
          "czyButton--outlined--white":
            "PlayWithFriendsDrawer_czyButton--outlined--white__041V9",
          "czyButton--link--white":
            "PlayWithFriendsDrawer_czyButton--link--white__9wci1",
          "czyButton--outlined--grey":
            "PlayWithFriendsDrawer_czyButton--outlined--grey__ItwpB",
          "czyButton--link--grey":
            "PlayWithFriendsDrawer_czyButton--link--grey__L4wHT",
          "czyButton--outlined--alert":
            "PlayWithFriendsDrawer_czyButton--outlined--alert__WHfia",
          "czyButton--link--alert":
            "PlayWithFriendsDrawer_czyButton--link--alert__Nxpoo",
          "czyButton--outlined--success":
            "PlayWithFriendsDrawer_czyButton--outlined--success__d74dA",
          "czyButton--link--success":
            "PlayWithFriendsDrawer_czyButton--link--success__dhSYS",
          "czyButton--outlined":
            "PlayWithFriendsDrawer_czyButton--outlined__45aey",
          "czyButton--disabled":
            "PlayWithFriendsDrawer_czyButton--disabled__72sXy",
          "czyButton--height50":
            "PlayWithFriendsDrawer_czyButton--height50__ZF_yt",
          "czyButton--height34":
            "PlayWithFriendsDrawer_czyButton--height34__1n83H",
          "czyButton--fullWidth":
            "PlayWithFriendsDrawer_czyButton--fullWidth__w9qiZ",
          root: "PlayWithFriendsDrawer_root__oQjw2",
          title: "PlayWithFriendsDrawer_title__E_4hw",
          text: "PlayWithFriendsDrawer_text__4Xbk6",
          divider: "PlayWithFriendsDrawer_divider__9DyGN",
          section: "PlayWithFriendsDrawer_section__C0Xmn",
          loginPill: "PlayWithFriendsDrawer_loginPill__VZdoo",
          inviteSteps: "PlayWithFriendsDrawer_inviteSteps__qH44e",
        };
      },
      9979: function (e) {
        e.exports = {
          czyButton: "TextField_czyButton__al5M9",
          "czyButton--contained--purple":
            "TextField_czyButton--contained--purple__MiCD4",
          "czyButton--contained--white":
            "TextField_czyButton--contained--white__X3ZDt",
          "czyButton--contained--grey":
            "TextField_czyButton--contained--grey__xuVbl",
          "czyButton--contained--alert":
            "TextField_czyButton--contained--alert__Xr9kf",
          "czyButton--contained--success":
            "TextField_czyButton--contained--success__lfL9r",
          "czyButton--contained--black":
            "TextField_czyButton--contained--black__ke6di",
          "czyButton--contained--green-gradient":
            "TextField_czyButton--contained--green-gradient__gmbtF",
          "czyButton--outlined--purple":
            "TextField_czyButton--outlined--purple__40zmH",
          "czyButton--link--purple": "TextField_czyButton--link--purple__Hse2g",
          "czyButton--outlined--white":
            "TextField_czyButton--outlined--white__siM_p",
          "czyButton--link--white": "TextField_czyButton--link--white__4n33i",
          "czyButton--outlined--grey":
            "TextField_czyButton--outlined--grey__LP5nW",
          "czyButton--link--grey": "TextField_czyButton--link--grey__ONSzj",
          "czyButton--outlined--alert":
            "TextField_czyButton--outlined--alert__HQEDo",
          "czyButton--link--alert": "TextField_czyButton--link--alert__9o_9G",
          "czyButton--outlined--success":
            "TextField_czyButton--outlined--success__oNTvA",
          "czyButton--link--success":
            "TextField_czyButton--link--success___Naud",
          "czyButton--outlined": "TextField_czyButton--outlined__7EuDj",
          "czyButton--disabled": "TextField_czyButton--disabled__NK1vB",
          "czyButton--height50": "TextField_czyButton--height50__eRWGH",
          "czyButton--height34": "TextField_czyButton--height34__EfZXj",
          "czyButton--fullWidth": "TextField_czyButton--fullWidth__bmd2B",
          textField: "TextField_textField__HJdPL",
          label: "TextField_label__LgjXe",
          hasLabel: "TextField_hasLabel__DKIjB",
          isTextarea: "TextField_isTextarea__1wTRP",
          hasError: "TextField_hasError__VO_Fn",
          wrapper: "TextField_wrapper__2Rtl2",
          hasOnClick: "TextField_hasOnClick__57ywO",
        };
      },
      81187: function (e) {
        e.exports = {
          czyButton: "BrowserNotSupportedDrawer_czyButton__TGEky",
          "czyButton--contained--purple":
            "BrowserNotSupportedDrawer_czyButton--contained--purple__5NQlw",
          "czyButton--contained--white":
            "BrowserNotSupportedDrawer_czyButton--contained--white__T8ZKI",
          "czyButton--contained--grey":
            "BrowserNotSupportedDrawer_czyButton--contained--grey__lvJ9w",
          "czyButton--contained--alert":
            "BrowserNotSupportedDrawer_czyButton--contained--alert__Pxozx",
          "czyButton--contained--success":
            "BrowserNotSupportedDrawer_czyButton--contained--success__uqTlX",
          "czyButton--contained--black":
            "BrowserNotSupportedDrawer_czyButton--contained--black__06amo",
          "czyButton--contained--green-gradient":
            "BrowserNotSupportedDrawer_czyButton--contained--green-gradient__Jjjxo",
          "czyButton--outlined--purple":
            "BrowserNotSupportedDrawer_czyButton--outlined--purple__XcJOo",
          "czyButton--link--purple":
            "BrowserNotSupportedDrawer_czyButton--link--purple__X9pqH",
          "czyButton--outlined--white":
            "BrowserNotSupportedDrawer_czyButton--outlined--white__bJ1v9",
          "czyButton--link--white":
            "BrowserNotSupportedDrawer_czyButton--link--white__htFxE",
          "czyButton--outlined--grey":
            "BrowserNotSupportedDrawer_czyButton--outlined--grey__5qP_N",
          "czyButton--link--grey":
            "BrowserNotSupportedDrawer_czyButton--link--grey__nxdA4",
          "czyButton--outlined--alert":
            "BrowserNotSupportedDrawer_czyButton--outlined--alert__FsGIP",
          "czyButton--link--alert":
            "BrowserNotSupportedDrawer_czyButton--link--alert__OLBUl",
          "czyButton--outlined--success":
            "BrowserNotSupportedDrawer_czyButton--outlined--success__SxQgW",
          "czyButton--link--success":
            "BrowserNotSupportedDrawer_czyButton--link--success__rjPJC",
          "czyButton--outlined":
            "BrowserNotSupportedDrawer_czyButton--outlined__GQ9p6",
          "czyButton--disabled":
            "BrowserNotSupportedDrawer_czyButton--disabled__5MFfq",
          "czyButton--height50":
            "BrowserNotSupportedDrawer_czyButton--height50__Si8eU",
          "czyButton--height34":
            "BrowserNotSupportedDrawer_czyButton--height34__u4Ym1",
          "czyButton--fullWidth":
            "BrowserNotSupportedDrawer_czyButton--fullWidth__vRHxC",
          content: "BrowserNotSupportedDrawer_content__MeSaj",
          text: "BrowserNotSupportedDrawer_text__fQQQO",
        };
      },
      31555: function (e) {
        e.exports = {
          czyButton: "Forms_czyButton__KNdXw",
          "czyButton--contained--purple":
            "Forms_czyButton--contained--purple__HA6Kh",
          "czyButton--contained--white":
            "Forms_czyButton--contained--white__OO_1x",
          "czyButton--contained--grey":
            "Forms_czyButton--contained--grey__qPlR9",
          "czyButton--contained--alert":
            "Forms_czyButton--contained--alert__ourd3",
          "czyButton--contained--success":
            "Forms_czyButton--contained--success__yQIH3",
          "czyButton--contained--black":
            "Forms_czyButton--contained--black__l4OMq",
          "czyButton--contained--green-gradient":
            "Forms_czyButton--contained--green-gradient__x8bNp",
          "czyButton--outlined--purple":
            "Forms_czyButton--outlined--purple__LnFmP",
          "czyButton--link--purple": "Forms_czyButton--link--purple__Ag75_",
          "czyButton--outlined--white":
            "Forms_czyButton--outlined--white__gyIPV",
          "czyButton--link--white": "Forms_czyButton--link--white__O0hvt",
          "czyButton--outlined--grey": "Forms_czyButton--outlined--grey___CIos",
          "czyButton--link--grey": "Forms_czyButton--link--grey__rpvaU",
          "czyButton--outlined--alert":
            "Forms_czyButton--outlined--alert__hXh5m",
          "czyButton--link--alert": "Forms_czyButton--link--alert__ID0AH",
          "czyButton--outlined--success":
            "Forms_czyButton--outlined--success__veRA2",
          "czyButton--link--success": "Forms_czyButton--link--success__UlfvF",
          "czyButton--outlined": "Forms_czyButton--outlined__LJf9_",
          "czyButton--disabled": "Forms_czyButton--disabled__kdhE7",
          "czyButton--height50": "Forms_czyButton--height50__2iLHF",
          "czyButton--height34": "Forms_czyButton--height34__EfH9G",
          "czyButton--fullWidth": "Forms_czyButton--fullWidth__dHg55",
          forgotPasswordButton: "Forms_forgotPasswordButton__4xCC9",
        };
      },
      41489: function (e) {
        e.exports = {
          czyButton: "GuestUserFooter_czyButton__eqqte",
          "czyButton--contained--purple":
            "GuestUserFooter_czyButton--contained--purple__jPUQP",
          "czyButton--contained--white":
            "GuestUserFooter_czyButton--contained--white__iHnFp",
          "czyButton--contained--grey":
            "GuestUserFooter_czyButton--contained--grey__81j2C",
          "czyButton--contained--alert":
            "GuestUserFooter_czyButton--contained--alert__OT5RD",
          "czyButton--contained--success":
            "GuestUserFooter_czyButton--contained--success__zDv3d",
          "czyButton--contained--black":
            "GuestUserFooter_czyButton--contained--black__P1B7v",
          "czyButton--contained--green-gradient":
            "GuestUserFooter_czyButton--contained--green-gradient__luy2i",
          "czyButton--outlined--purple":
            "GuestUserFooter_czyButton--outlined--purple__uayP6",
          "czyButton--link--purple":
            "GuestUserFooter_czyButton--link--purple__hZA2k",
          "czyButton--outlined--white":
            "GuestUserFooter_czyButton--outlined--white__KldAn",
          "czyButton--link--white":
            "GuestUserFooter_czyButton--link--white__GFMFV",
          "czyButton--outlined--grey":
            "GuestUserFooter_czyButton--outlined--grey__r1ZzD",
          "czyButton--link--grey":
            "GuestUserFooter_czyButton--link--grey__t_REC",
          "czyButton--outlined--alert":
            "GuestUserFooter_czyButton--outlined--alert__kZTwG",
          "czyButton--link--alert":
            "GuestUserFooter_czyButton--link--alert__qEWuC",
          "czyButton--outlined--success":
            "GuestUserFooter_czyButton--outlined--success___em6y",
          "czyButton--link--success":
            "GuestUserFooter_czyButton--link--success__wwhWa",
          "czyButton--outlined": "GuestUserFooter_czyButton--outlined___rDmy",
          "czyButton--disabled": "GuestUserFooter_czyButton--disabled__LmCod",
          "czyButton--height50": "GuestUserFooter_czyButton--height50___ktNO",
          "czyButton--height34": "GuestUserFooter_czyButton--height34__z1GpS",
          "czyButton--fullWidth": "GuestUserFooter_czyButton--fullWidth__zZHLm",
          openFeedbackButton: "GuestUserFooter_openFeedbackButton__p8JpS",
        };
      },
      99439: function (e) {
        e.exports = {
          czyButton: "ProviderButtons_czyButton__snAsH",
          "czyButton--contained--purple":
            "ProviderButtons_czyButton--contained--purple__xxYJz",
          "czyButton--contained--white":
            "ProviderButtons_czyButton--contained--white__al6dq",
          "czyButton--contained--grey":
            "ProviderButtons_czyButton--contained--grey__VpDy9",
          "czyButton--contained--alert":
            "ProviderButtons_czyButton--contained--alert__Cu0XR",
          "czyButton--contained--success":
            "ProviderButtons_czyButton--contained--success__pURNh",
          "czyButton--contained--black":
            "ProviderButtons_czyButton--contained--black__b2F6W",
          "czyButton--contained--green-gradient":
            "ProviderButtons_czyButton--contained--green-gradient__QlEHw",
          "czyButton--outlined--purple":
            "ProviderButtons_czyButton--outlined--purple__bFAjc",
          "czyButton--link--purple":
            "ProviderButtons_czyButton--link--purple___h3cO",
          "czyButton--outlined--white":
            "ProviderButtons_czyButton--outlined--white__y8SBv",
          "czyButton--link--white":
            "ProviderButtons_czyButton--link--white__ikpKO",
          "czyButton--outlined--grey":
            "ProviderButtons_czyButton--outlined--grey__sMTsf",
          "czyButton--link--grey":
            "ProviderButtons_czyButton--link--grey__KLM_E",
          "czyButton--outlined--alert":
            "ProviderButtons_czyButton--outlined--alert__Efjtc",
          "czyButton--link--alert":
            "ProviderButtons_czyButton--link--alert__FCmrC",
          "czyButton--outlined--success":
            "ProviderButtons_czyButton--outlined--success__X0iOk",
          "czyButton--link--success":
            "ProviderButtons_czyButton--link--success__p_CmS",
          "czyButton--outlined": "ProviderButtons_czyButton--outlined__5XM6L",
          "czyButton--disabled": "ProviderButtons_czyButton--disabled__YLf4e",
          "czyButton--height50": "ProviderButtons_czyButton--height50__YVheK",
          "czyButton--height34": "ProviderButtons_czyButton--height34__RujsM",
          "czyButton--fullWidth": "ProviderButtons_czyButton--fullWidth__jcfqT",
          authButton: "ProviderButtons_authButton__hop8V",
          isFacebook: "ProviderButtons_isFacebook__eLT4u",
        };
      },
      75543: function (e) {
        e.exports = {
          hug: "SignInGoogleDrawer_hug__xXrgB",
          message: "SignInGoogleDrawer_message__GDYal",
        };
      },
      14243: function (e) {
        e.exports = {
          czyButton: "SignUpButtons_czyButton__7gBoT",
          "czyButton--contained--purple":
            "SignUpButtons_czyButton--contained--purple__3J_PU",
          "czyButton--contained--white":
            "SignUpButtons_czyButton--contained--white__B8whi",
          "czyButton--contained--grey":
            "SignUpButtons_czyButton--contained--grey__cm0C3",
          "czyButton--contained--alert":
            "SignUpButtons_czyButton--contained--alert__P2KOH",
          "czyButton--contained--success":
            "SignUpButtons_czyButton--contained--success__mFSsa",
          "czyButton--contained--black":
            "SignUpButtons_czyButton--contained--black__W8AzK",
          "czyButton--contained--green-gradient":
            "SignUpButtons_czyButton--contained--green-gradient__hoFKy",
          "czyButton--outlined--purple":
            "SignUpButtons_czyButton--outlined--purple__UT7ww",
          "czyButton--link--purple":
            "SignUpButtons_czyButton--link--purple__XzaSD",
          "czyButton--outlined--white":
            "SignUpButtons_czyButton--outlined--white__S6YYw",
          "czyButton--link--white":
            "SignUpButtons_czyButton--link--white__In7LQ",
          "czyButton--outlined--grey":
            "SignUpButtons_czyButton--outlined--grey__cjqWr",
          "czyButton--link--grey": "SignUpButtons_czyButton--link--grey__xoto0",
          "czyButton--outlined--alert":
            "SignUpButtons_czyButton--outlined--alert__ukVJW",
          "czyButton--link--alert":
            "SignUpButtons_czyButton--link--alert__hEo20",
          "czyButton--outlined--success":
            "SignUpButtons_czyButton--outlined--success___9_TT",
          "czyButton--link--success":
            "SignUpButtons_czyButton--link--success__8KEaw",
          "czyButton--outlined": "SignUpButtons_czyButton--outlined__M5Ylr",
          "czyButton--disabled": "SignUpButtons_czyButton--disabled__pRuwr",
          "czyButton--height50": "SignUpButtons_czyButton--height50__furK3",
          "czyButton--height34": "SignUpButtons_czyButton--height34__o0Z_9",
          "czyButton--fullWidth": "SignUpButtons_czyButton--fullWidth__iAC_I",
          signUpEmailButton: "SignUpButtons_signUpEmailButton__mn4LZ",
          alreadyMemberButton: "SignUpButtons_alreadyMemberButton__FDcUr",
        };
      },
      1795: function (e) {
        e.exports = {
          czyButton: "MyGamesDrawers_czyButton__Tjeuk",
          "czyButton--contained--purple":
            "MyGamesDrawers_czyButton--contained--purple__SsEZI",
          "czyButton--contained--white":
            "MyGamesDrawers_czyButton--contained--white__Fw0a6",
          "czyButton--contained--grey":
            "MyGamesDrawers_czyButton--contained--grey__mlaoK",
          "czyButton--contained--alert":
            "MyGamesDrawers_czyButton--contained--alert__ub21r",
          "czyButton--contained--success":
            "MyGamesDrawers_czyButton--contained--success__PvQ_x",
          "czyButton--contained--black":
            "MyGamesDrawers_czyButton--contained--black__Rz_rP",
          "czyButton--contained--green-gradient":
            "MyGamesDrawers_czyButton--contained--green-gradient__Ic9K3",
          "czyButton--outlined--purple":
            "MyGamesDrawers_czyButton--outlined--purple__MlvMt",
          "czyButton--link--purple":
            "MyGamesDrawers_czyButton--link--purple__6hZkD",
          "czyButton--outlined--white":
            "MyGamesDrawers_czyButton--outlined--white__eDeU3",
          "czyButton--link--white":
            "MyGamesDrawers_czyButton--link--white__edfGt",
          "czyButton--outlined--grey":
            "MyGamesDrawers_czyButton--outlined--grey__Hua2I",
          "czyButton--link--grey":
            "MyGamesDrawers_czyButton--link--grey__aVhm_",
          "czyButton--outlined--alert":
            "MyGamesDrawers_czyButton--outlined--alert__nb_R7",
          "czyButton--link--alert":
            "MyGamesDrawers_czyButton--link--alert__0LJI2",
          "czyButton--outlined--success":
            "MyGamesDrawers_czyButton--outlined--success__nwyWr",
          "czyButton--link--success":
            "MyGamesDrawers_czyButton--link--success__dvDL7",
          "czyButton--outlined": "MyGamesDrawers_czyButton--outlined__Rx9qa",
          "czyButton--disabled": "MyGamesDrawers_czyButton--disabled__vX_kL",
          "czyButton--height50": "MyGamesDrawers_czyButton--height50__WUPNq",
          "czyButton--height34": "MyGamesDrawers_czyButton--height34__b_4XD",
          "czyButton--fullWidth": "MyGamesDrawers_czyButton--fullWidth__lUH6C",
          recentMyGamesDrawerError:
            "MyGamesDrawers_recentMyGamesDrawerError__oCFOQ",
        };
      },
      11264: function (e) {
        e.exports = {
          czyButton: "UpdateUsernameForm_czyButton__MDgN4",
          "czyButton--contained--purple":
            "UpdateUsernameForm_czyButton--contained--purple__Hyrkw",
          "czyButton--contained--white":
            "UpdateUsernameForm_czyButton--contained--white__3vvcM",
          "czyButton--contained--grey":
            "UpdateUsernameForm_czyButton--contained--grey__VSMfE",
          "czyButton--contained--alert":
            "UpdateUsernameForm_czyButton--contained--alert__rjAYw",
          "czyButton--contained--success":
            "UpdateUsernameForm_czyButton--contained--success___cSmy",
          "czyButton--contained--black":
            "UpdateUsernameForm_czyButton--contained--black__yanlx",
          "czyButton--contained--green-gradient":
            "UpdateUsernameForm_czyButton--contained--green-gradient__stfM4",
          "czyButton--outlined--purple":
            "UpdateUsernameForm_czyButton--outlined--purple__yhuiy",
          "czyButton--link--purple":
            "UpdateUsernameForm_czyButton--link--purple__L6OxJ",
          "czyButton--outlined--white":
            "UpdateUsernameForm_czyButton--outlined--white__H9jxw",
          "czyButton--link--white":
            "UpdateUsernameForm_czyButton--link--white__a1Dht",
          "czyButton--outlined--grey":
            "UpdateUsernameForm_czyButton--outlined--grey__MEcM7",
          "czyButton--link--grey":
            "UpdateUsernameForm_czyButton--link--grey__RL7Bz",
          "czyButton--outlined--alert":
            "UpdateUsernameForm_czyButton--outlined--alert__BLVFe",
          "czyButton--link--alert":
            "UpdateUsernameForm_czyButton--link--alert__JqL4K",
          "czyButton--outlined--success":
            "UpdateUsernameForm_czyButton--outlined--success__NM5VB",
          "czyButton--link--success":
            "UpdateUsernameForm_czyButton--link--success__wJBmO",
          "czyButton--outlined":
            "UpdateUsernameForm_czyButton--outlined__h57F2",
          "czyButton--disabled":
            "UpdateUsernameForm_czyButton--disabled__BmfeN",
          "czyButton--height50":
            "UpdateUsernameForm_czyButton--height50__yYOns",
          "czyButton--height34":
            "UpdateUsernameForm_czyButton--height34__YfxN_",
          "czyButton--fullWidth":
            "UpdateUsernameForm_czyButton--fullWidth__lAXxo",
          generateOneButton: "UpdateUsernameForm_generateOneButton__cQT4b",
        };
      },
    },
  ]);
