!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "a14c6218-1760-453b-869b-486b0e3bca90"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-a14c6218-1760-453b-869b-486b0e3bca90"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [26845],
    {
      45889: function (e, t, n) {
        var r = n(63366),
          o = n(87462),
          a = n(67294),
          i = n(90512),
          l = n(94780),
          s = n(90948),
          d = n(71657),
          u = n(16628),
          c = n(6496),
          p = n(85893);
        let f = [
            "children",
            "className",
            "component",
            "components",
            "componentsProps",
            "invisible",
            "open",
            "slotProps",
            "slots",
            "TransitionComponent",
            "transitionDuration",
          ],
          m = (e) => {
            let { classes: t, invisible: n } = e;
            return (0, l.Z)({ root: ["root", n && "invisible"] }, c.s, t);
          },
          v = (0, s.ZP)("div", {
            name: "MuiBackdrop",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [t.root, n.invisible && t.invisible];
            },
          })(({ ownerState: e }) =>
            (0, o.Z)(
              {
                position: "fixed",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                right: 0,
                bottom: 0,
                top: 0,
                left: 0,
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                WebkitTapHighlightColor: "transparent",
              },
              e.invisible && { backgroundColor: "transparent" }
            )
          ),
          h = a.forwardRef(function (e, t) {
            var n, a, l;
            let s = (0, d.Z)({ props: e, name: "MuiBackdrop" }),
              {
                children: c,
                className: h,
                component: b = "div",
                components: y = {},
                componentsProps: g = {},
                invisible: Z = !1,
                open: x,
                slotProps: E = {},
                slots: k = {},
                TransitionComponent: w = u.Z,
                transitionDuration: R,
              } = s,
              M = (0, r.Z)(s, f),
              P = (0, o.Z)({}, s, { component: b, invisible: Z }),
              T = m(P),
              I = null != (n = E.root) ? n : g.root;
            return (0,
            p.jsx)(w, (0, o.Z)({ in: x, timeout: R }, M, { children: (0, p.jsx)(v, (0, o.Z)({ "aria-hidden": !0 }, I, { as: null != (a = null != (l = k.root) ? l : y.Root) ? a : b, className: (0, i.Z)(T.root, h, null == I ? void 0 : I.className), ownerState: (0, o.Z)({}, P, null == I ? void 0 : I.ownerState), classes: T, ref: t, children: c })) }));
          });
        t.Z = h;
      },
      72268: function (e, t, n) {
        n.d(t, {
          ZP: function () {
            return L;
          },
        });
        var r = n(63366),
          o = n(87462),
          a = n(67294),
          i = n(90512),
          l = n(94780),
          s = n(82056),
          d = n(63907),
          u = n(98885),
          c = n(57144),
          p = n(51705),
          f = n(2734),
          m = n(30577),
          v = n(5340),
          h = n(85893);
        let b = [
          "addEndListener",
          "appear",
          "children",
          "container",
          "direction",
          "easing",
          "in",
          "onEnter",
          "onEntered",
          "onEntering",
          "onExit",
          "onExited",
          "onExiting",
          "style",
          "timeout",
          "TransitionComponent",
        ];
        function y(e, t, n) {
          let r = "function" == typeof n ? n() : n,
            o = (function (e, t, n) {
              let r;
              let o = t.getBoundingClientRect(),
                a = n && n.getBoundingClientRect(),
                i = (0, v.Z)(t);
              if (t.fakeTransform) r = t.fakeTransform;
              else {
                let e = i.getComputedStyle(t);
                r =
                  e.getPropertyValue("-webkit-transform") ||
                  e.getPropertyValue("transform");
              }
              let l = 0,
                s = 0;
              if (r && "none" !== r && "string" == typeof r) {
                let e = r.split("(")[1].split(")")[0].split(",");
                (l = parseInt(e[4], 10)), (s = parseInt(e[5], 10));
              }
              return "left" === e
                ? a
                  ? `translateX(${a.right + l - o.left}px)`
                  : `translateX(${i.innerWidth + l - o.left}px)`
                : "right" === e
                ? a
                  ? `translateX(-${o.right - a.left - l}px)`
                  : `translateX(-${o.left + o.width - l}px)`
                : "up" === e
                ? a
                  ? `translateY(${a.bottom + s - o.top}px)`
                  : `translateY(${i.innerHeight + s - o.top}px)`
                : a
                ? `translateY(-${o.top - a.top + o.height - s}px)`
                : `translateY(-${o.top + o.height - s}px)`;
            })(e, t, r);
          o && ((t.style.webkitTransform = o), (t.style.transform = o));
        }
        let g = a.forwardRef(function (e, t) {
          let n = (0, f.Z)(),
            i = {
              enter: n.transitions.easing.easeOut,
              exit: n.transitions.easing.sharp,
            },
            l = {
              enter: n.transitions.duration.enteringScreen,
              exit: n.transitions.duration.leavingScreen,
            },
            {
              addEndListener: s,
              appear: d = !0,
              children: g,
              container: Z,
              direction: x = "down",
              easing: E = i,
              in: k,
              onEnter: w,
              onEntered: R,
              onEntering: M,
              onExit: P,
              onExited: T,
              onExiting: I,
              style: C,
              timeout: S = l,
              TransitionComponent: N = u.ZP,
            } = e,
            A = (0, r.Z)(e, b),
            D = a.useRef(null),
            L = (0, p.Z)(g.ref, D, t),
            $ = (e) => (t) => {
              e && (void 0 === t ? e(D.current) : e(D.current, t));
            },
            O = $((e, t) => {
              y(x, e, Z), (0, m.n)(e), w && w(e, t);
            }),
            B = $((e, t) => {
              let r = (0, m.C)(
                { timeout: S, style: C, easing: E },
                { mode: "enter" }
              );
              (e.style.webkitTransition = n.transitions.create(
                "-webkit-transform",
                (0, o.Z)({}, r)
              )),
                (e.style.transition = n.transitions.create(
                  "transform",
                  (0, o.Z)({}, r)
                )),
                (e.style.webkitTransform = "none"),
                (e.style.transform = "none"),
                M && M(e, t);
            }),
            _ = $(R),
            j = $(I),
            F = $((e) => {
              let t = (0, m.C)(
                { timeout: S, style: C, easing: E },
                { mode: "exit" }
              );
              (e.style.webkitTransition = n.transitions.create(
                "-webkit-transform",
                t
              )),
                (e.style.transition = n.transitions.create("transform", t)),
                y(x, e, Z),
                P && P(e);
            }),
            z = $((e) => {
              (e.style.webkitTransition = ""),
                (e.style.transition = ""),
                T && T(e);
            }),
            q = (e) => {
              s && s(D.current, e);
            },
            K = a.useCallback(() => {
              D.current && y(x, D.current, Z);
            }, [x, Z]);
          return (
            a.useEffect(() => {
              if (k || "down" === x || "right" === x) return;
              let e = (0, c.Z)(() => {
                  D.current && y(x, D.current, Z);
                }),
                t = (0, v.Z)(D.current);
              return (
                t.addEventListener("resize", e),
                () => {
                  e.clear(), t.removeEventListener("resize", e);
                }
              );
            }, [x, k, Z]),
            a.useEffect(() => {
              k || K();
            }, [k, K]),
            (0, h.jsx)(
              N,
              (0, o.Z)(
                {
                  nodeRef: D,
                  onEnter: O,
                  onEntered: _,
                  onEntering: B,
                  onExit: F,
                  onExited: z,
                  onExiting: j,
                  addEndListener: q,
                  appear: d,
                  in: k,
                  timeout: S,
                },
                A,
                {
                  children: (e, t) =>
                    a.cloneElement(
                      g,
                      (0, o.Z)(
                        {
                          ref: L,
                          style: (0, o.Z)(
                            {
                              visibility:
                                "exited" !== e || k ? void 0 : "hidden",
                            },
                            C,
                            g.props.style
                          ),
                        },
                        t
                      )
                    ),
                }
              )
            )
          );
        });
        var Z = n(90629),
          x = n(98216),
          E = n(71657),
          k = n(90948),
          w = n(14136),
          R = n(66697);
        let M = ["BackdropProps"],
          P = [
            "anchor",
            "BackdropProps",
            "children",
            "className",
            "elevation",
            "hideBackdrop",
            "ModalProps",
            "onClose",
            "open",
            "PaperProps",
            "SlideProps",
            "TransitionComponent",
            "transitionDuration",
            "variant",
          ],
          T = (e, t) => {
            let { ownerState: n } = e;
            return [
              t.root,
              ("permanent" === n.variant || "persistent" === n.variant) &&
                t.docked,
              t.modal,
            ];
          },
          I = (e) => {
            let { classes: t, anchor: n, variant: r } = e,
              o = {
                root: ["root"],
                docked: [("permanent" === r || "persistent" === r) && "docked"],
                modal: ["modal"],
                paper: [
                  "paper",
                  `paperAnchor${(0, x.Z)(n)}`,
                  "temporary" !== r && `paperAnchorDocked${(0, x.Z)(n)}`,
                ],
              };
            return (0, l.Z)(o, R.l, t);
          },
          C = (0, k.ZP)(d.Z, {
            name: "MuiDrawer",
            slot: "Root",
            overridesResolver: T,
          })(({ theme: e }) => ({ zIndex: (e.vars || e).zIndex.drawer })),
          S = (0, k.ZP)("div", {
            shouldForwardProp: w.Z,
            name: "MuiDrawer",
            slot: "Docked",
            skipVariantsResolver: !1,
            overridesResolver: T,
          })({ flex: "0 0 auto" }),
          N = (0, k.ZP)(Z.Z, {
            name: "MuiDrawer",
            slot: "Paper",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.paper,
                t[`paperAnchor${(0, x.Z)(n.anchor)}`],
                "temporary" !== n.variant &&
                  t[`paperAnchorDocked${(0, x.Z)(n.anchor)}`],
              ];
            },
          })(({ theme: e, ownerState: t }) =>
            (0, o.Z)(
              {
                overflowY: "auto",
                display: "flex",
                flexDirection: "column",
                height: "100%",
                flex: "1 0 auto",
                zIndex: (e.vars || e).zIndex.drawer,
                WebkitOverflowScrolling: "touch",
                position: "fixed",
                top: 0,
                outline: 0,
              },
              "left" === t.anchor && { left: 0 },
              "top" === t.anchor && {
                top: 0,
                left: 0,
                right: 0,
                height: "auto",
                maxHeight: "100%",
              },
              "right" === t.anchor && { right: 0 },
              "bottom" === t.anchor && {
                top: "auto",
                left: 0,
                bottom: 0,
                right: 0,
                height: "auto",
                maxHeight: "100%",
              },
              "left" === t.anchor &&
                "temporary" !== t.variant && {
                  borderRight: `1px solid ${(e.vars || e).palette.divider}`,
                },
              "top" === t.anchor &&
                "temporary" !== t.variant && {
                  borderBottom: `1px solid ${(e.vars || e).palette.divider}`,
                },
              "right" === t.anchor &&
                "temporary" !== t.variant && {
                  borderLeft: `1px solid ${(e.vars || e).palette.divider}`,
                },
              "bottom" === t.anchor &&
                "temporary" !== t.variant && {
                  borderTop: `1px solid ${(e.vars || e).palette.divider}`,
                }
            )
          ),
          A = { left: "right", right: "left", top: "down", bottom: "up" },
          D = a.forwardRef(function (e, t) {
            let n = (0, E.Z)({ props: e, name: "MuiDrawer" }),
              l = (0, f.Z)(),
              d = (0, s.V)(),
              u = {
                enter: l.transitions.duration.enteringScreen,
                exit: l.transitions.duration.leavingScreen,
              },
              {
                anchor: c = "left",
                BackdropProps: p,
                children: m,
                className: v,
                elevation: b = 16,
                hideBackdrop: y = !1,
                ModalProps: { BackdropProps: Z } = {},
                onClose: x,
                open: k = !1,
                PaperProps: w = {},
                SlideProps: R,
                TransitionComponent: T = g,
                transitionDuration: D = u,
                variant: L = "temporary",
              } = n,
              $ = (0, r.Z)(n.ModalProps, M),
              O = (0, r.Z)(n, P),
              B = a.useRef(!1);
            a.useEffect(() => {
              B.current = !0;
            }, []);
            let _ = (function ({ direction: e }, t) {
                return "rtl" === e && -1 !== ["left", "right"].indexOf(t)
                  ? A[t]
                  : t;
              })({ direction: d ? "rtl" : "ltr" }, c),
              j = (0, o.Z)(
                {},
                n,
                { anchor: c, elevation: b, open: k, variant: L },
                O
              ),
              F = I(j),
              z = (0, h.jsx)(
                N,
                (0, o.Z)(
                  { elevation: "temporary" === L ? b : 0, square: !0 },
                  w,
                  {
                    className: (0, i.Z)(F.paper, w.className),
                    ownerState: j,
                    children: m,
                  }
                )
              );
            if ("permanent" === L)
              return (0, h.jsx)(
                S,
                (0, o.Z)(
                  {
                    className: (0, i.Z)(F.root, F.docked, v),
                    ownerState: j,
                    ref: t,
                  },
                  O,
                  { children: z }
                )
              );
            let q = (0, h.jsx)(
              T,
              (0, o.Z)(
                { in: k, direction: A[_], timeout: D, appear: B.current },
                R,
                { children: z }
              )
            );
            return "persistent" === L
              ? (0, h.jsx)(
                  S,
                  (0, o.Z)(
                    {
                      className: (0, i.Z)(F.root, F.docked, v),
                      ownerState: j,
                      ref: t,
                    },
                    O,
                    { children: q }
                  )
                )
              : (0, h.jsx)(
                  C,
                  (0, o.Z)(
                    {
                      BackdropProps: (0, o.Z)({}, p, Z, {
                        transitionDuration: D,
                      }),
                      className: (0, i.Z)(F.root, F.modal, v),
                      open: k,
                      ownerState: j,
                      onClose: x,
                      hideBackdrop: y,
                      ref: t,
                    },
                    O,
                    $,
                    { children: q }
                  )
                );
          });
        var L = D;
      },
      66697: function (e, t, n) {
        n.d(t, {
          l: function () {
            return a;
          },
        });
        var r = n(1588),
          o = n(34867);
        function a(e) {
          return (0, o.ZP)("MuiDrawer", e);
        }
        let i = (0, r.Z)("MuiDrawer", [
          "root",
          "docked",
          "paper",
          "paperAnchorLeft",
          "paperAnchorRight",
          "paperAnchorTop",
          "paperAnchorBottom",
          "paperAnchorDockedLeft",
          "paperAnchorDockedRight",
          "paperAnchorDockedTop",
          "paperAnchorDockedBottom",
          "modal",
        ]);
        t.Z = i;
      },
      16628: function (e, t, n) {
        var r = n(87462),
          o = n(63366),
          a = n(67294),
          i = n(98885),
          l = n(2734),
          s = n(30577),
          d = n(51705),
          u = n(85893);
        let c = [
            "addEndListener",
            "appear",
            "children",
            "easing",
            "in",
            "onEnter",
            "onEntered",
            "onEntering",
            "onExit",
            "onExited",
            "onExiting",
            "style",
            "timeout",
            "TransitionComponent",
          ],
          p = { entering: { opacity: 1 }, entered: { opacity: 1 } },
          f = a.forwardRef(function (e, t) {
            let n = (0, l.Z)(),
              f = {
                enter: n.transitions.duration.enteringScreen,
                exit: n.transitions.duration.leavingScreen,
              },
              {
                addEndListener: m,
                appear: v = !0,
                children: h,
                easing: b,
                in: y,
                onEnter: g,
                onEntered: Z,
                onEntering: x,
                onExit: E,
                onExited: k,
                onExiting: w,
                style: R,
                timeout: M = f,
                TransitionComponent: P = i.ZP,
              } = e,
              T = (0, o.Z)(e, c),
              I = a.useRef(null),
              C = (0, d.Z)(I, h.ref, t),
              S = (e) => (t) => {
                if (e) {
                  let n = I.current;
                  void 0 === t ? e(n) : e(n, t);
                }
              },
              N = S(x),
              A = S((e, t) => {
                (0, s.n)(e);
                let r = (0, s.C)(
                  { style: R, timeout: M, easing: b },
                  { mode: "enter" }
                );
                (e.style.webkitTransition = n.transitions.create("opacity", r)),
                  (e.style.transition = n.transitions.create("opacity", r)),
                  g && g(e, t);
              }),
              D = S(Z),
              L = S(w),
              $ = S((e) => {
                let t = (0, s.C)(
                  { style: R, timeout: M, easing: b },
                  { mode: "exit" }
                );
                (e.style.webkitTransition = n.transitions.create("opacity", t)),
                  (e.style.transition = n.transitions.create("opacity", t)),
                  E && E(e);
              }),
              O = S(k),
              B = (e) => {
                m && m(I.current, e);
              };
            return (0,
            u.jsx)(P, (0, r.Z)({ appear: v, in: y, nodeRef: I, onEnter: A, onEntered: D, onEntering: N, onExit: $, onExited: O, onExiting: L, addEndListener: B, timeout: M }, T, { children: (e, t) => a.cloneElement(h, (0, r.Z)({ style: (0, r.Z)({ opacity: 0, visibility: "exited" !== e || y ? void 0 : "hidden" }, p[e], R, h.props.style), ref: C }, t)) }));
          });
        t.Z = f;
      },
      63907: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return A;
          },
        });
        var r = n(63366),
          o = n(87462),
          a = n(67294),
          i = n(90512),
          l = n(83265),
          s = n(33703),
          d = n(82690),
          u = n(59948),
          c = n(91476),
          p = n(74098),
          f = n(74161),
          m = n(29726);
        function v(e, t) {
          t
            ? e.setAttribute("aria-hidden", "true")
            : e.removeAttribute("aria-hidden");
        }
        function h(e) {
          return (
            parseInt((0, f.Z)(e).getComputedStyle(e).paddingRight, 10) || 0
          );
        }
        function b(e, t, n, r, o) {
          let a = [t, n, ...r];
          [].forEach.call(e.children, (e) => {
            let t = -1 === a.indexOf(e),
              n = !(function (e) {
                let t =
                    -1 !==
                    [
                      "TEMPLATE",
                      "SCRIPT",
                      "STYLE",
                      "LINK",
                      "MAP",
                      "META",
                      "NOSCRIPT",
                      "PICTURE",
                      "COL",
                      "COLGROUP",
                      "PARAM",
                      "SLOT",
                      "SOURCE",
                      "TRACK",
                    ].indexOf(e.tagName),
                  n =
                    "INPUT" === e.tagName &&
                    "hidden" === e.getAttribute("type");
                return t || n;
              })(e);
            t && n && v(e, o);
          });
        }
        function y(e, t) {
          let n = -1;
          return e.some((e, r) => !!t(e) && ((n = r), !0)), n;
        }
        let g = new (class {
          constructor() {
            (this.containers = void 0),
              (this.modals = void 0),
              (this.modals = []),
              (this.containers = []);
          }
          add(e, t) {
            let n = this.modals.indexOf(e);
            if (-1 !== n) return n;
            (n = this.modals.length),
              this.modals.push(e),
              e.modalRef && v(e.modalRef, !1);
            let r = (function (e) {
              let t = [];
              return (
                [].forEach.call(e.children, (e) => {
                  "true" === e.getAttribute("aria-hidden") && t.push(e);
                }),
                t
              );
            })(t);
            b(t, e.mount, e.modalRef, r, !0);
            let o = y(this.containers, (e) => e.container === t);
            return -1 !== o
              ? (this.containers[o].modals.push(e), n)
              : (this.containers.push({
                  modals: [e],
                  container: t,
                  restore: null,
                  hiddenSiblings: r,
                }),
                n);
          }
          mount(e, t) {
            let n = y(this.containers, (t) => -1 !== t.modals.indexOf(e)),
              r = this.containers[n];
            r.restore ||
              (r.restore = (function (e, t) {
                let n = [],
                  r = e.container;
                if (!t.disableScrollLock) {
                  let e;
                  if (
                    (function (e) {
                      let t = (0, d.Z)(e);
                      return t.body === e
                        ? (0, f.Z)(e).innerWidth > t.documentElement.clientWidth
                        : e.scrollHeight > e.clientHeight;
                    })(r)
                  ) {
                    let e = (0, m.Z)((0, d.Z)(r));
                    n.push({
                      value: r.style.paddingRight,
                      property: "padding-right",
                      el: r,
                    }),
                      (r.style.paddingRight = `${h(r) + e}px`);
                    let t = (0, d.Z)(r).querySelectorAll(".mui-fixed");
                    [].forEach.call(t, (t) => {
                      n.push({
                        value: t.style.paddingRight,
                        property: "padding-right",
                        el: t,
                      }),
                        (t.style.paddingRight = `${h(t) + e}px`);
                    });
                  }
                  if (r.parentNode instanceof DocumentFragment)
                    e = (0, d.Z)(r).body;
                  else {
                    let t = r.parentElement,
                      n = (0, f.Z)(r);
                    e =
                      (null == t ? void 0 : t.nodeName) === "HTML" &&
                      "scroll" === n.getComputedStyle(t).overflowY
                        ? t
                        : r;
                  }
                  n.push(
                    { value: e.style.overflow, property: "overflow", el: e },
                    { value: e.style.overflowX, property: "overflow-x", el: e },
                    { value: e.style.overflowY, property: "overflow-y", el: e }
                  ),
                    (e.style.overflow = "hidden");
                }
                let o = () => {
                  n.forEach(({ value: e, el: t, property: n }) => {
                    e ? t.style.setProperty(n, e) : t.style.removeProperty(n);
                  });
                };
                return o;
              })(r, t));
          }
          remove(e, t = !0) {
            let n = this.modals.indexOf(e);
            if (-1 === n) return n;
            let r = y(this.containers, (t) => -1 !== t.modals.indexOf(e)),
              o = this.containers[r];
            if (
              (o.modals.splice(o.modals.indexOf(e), 1),
              this.modals.splice(n, 1),
              0 === o.modals.length)
            )
              o.restore && o.restore(),
                e.modalRef && v(e.modalRef, t),
                b(o.container, e.mount, e.modalRef, o.hiddenSiblings, !1),
                this.containers.splice(r, 1);
            else {
              let e = o.modals[o.modals.length - 1];
              e.modalRef && v(e.modalRef, !1);
            }
            return n;
          }
          isTopModal(e) {
            return (
              this.modals.length > 0 &&
              this.modals[this.modals.length - 1] === e
            );
          }
        })();
        var Z = n(94780),
          x = n(90886),
          E = n(8173),
          k = n(90948),
          w = n(71657),
          R = n(45889),
          M = n(1011),
          P = n(85893);
        let T = [
            "BackdropComponent",
            "BackdropProps",
            "classes",
            "className",
            "closeAfterTransition",
            "children",
            "container",
            "component",
            "components",
            "componentsProps",
            "disableAutoFocus",
            "disableEnforceFocus",
            "disableEscapeKeyDown",
            "disablePortal",
            "disableRestoreFocus",
            "disableScrollLock",
            "hideBackdrop",
            "keepMounted",
            "onBackdropClick",
            "onClose",
            "onTransitionEnter",
            "onTransitionExited",
            "open",
            "slotProps",
            "slots",
            "theme",
          ],
          I = (e) => {
            let { open: t, exited: n, classes: r } = e;
            return (0, Z.Z)(
              { root: ["root", !t && n && "hidden"], backdrop: ["backdrop"] },
              M.x,
              r
            );
          },
          C = (0, k.ZP)("div", {
            name: "MuiModal",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [t.root, !n.open && n.exited && t.hidden];
            },
          })(({ theme: e, ownerState: t }) =>
            (0, o.Z)(
              {
                position: "fixed",
                zIndex: (e.vars || e).zIndex.modal,
                right: 0,
                bottom: 0,
                top: 0,
                left: 0,
              },
              !t.open && t.exited && { visibility: "hidden" }
            )
          ),
          S = (0, k.ZP)(R.Z, {
            name: "MuiModal",
            slot: "Backdrop",
            overridesResolver: (e, t) => t.backdrop,
          })({ zIndex: -1 }),
          N = a.forwardRef(function (e, t) {
            var n, f, m, h, b, y;
            let Z = (0, w.Z)({ name: "MuiModal", props: e }),
              {
                BackdropComponent: k = S,
                BackdropProps: R,
                className: M,
                closeAfterTransition: N = !1,
                children: A,
                container: D,
                component: L,
                components: $ = {},
                componentsProps: O = {},
                disableAutoFocus: B = !1,
                disableEnforceFocus: _ = !1,
                disableEscapeKeyDown: j = !1,
                disablePortal: F = !1,
                disableRestoreFocus: z = !1,
                disableScrollLock: q = !1,
                hideBackdrop: K = !1,
                keepMounted: Y = !1,
                onBackdropClick: G,
                open: U,
                slotProps: H,
                slots: W,
              } = Z,
              V = (0, r.Z)(Z, T),
              X = (0, o.Z)({}, Z, {
                closeAfterTransition: N,
                disableAutoFocus: B,
                disableEnforceFocus: _,
                disableEscapeKeyDown: j,
                disablePortal: F,
                disableRestoreFocus: z,
                disableScrollLock: q,
                hideBackdrop: K,
                keepMounted: Y,
              }),
              {
                getRootProps: Q,
                getBackdropProps: J,
                getTransitionProps: ee,
                portalRef: et,
                isTopModal: en,
                exited: er,
                hasTransition: eo,
              } = (function (e) {
                let {
                    container: t,
                    disableEscapeKeyDown: n = !1,
                    disableScrollLock: r = !1,
                    manager: i = g,
                    closeAfterTransition: l = !1,
                    onTransitionEnter: f,
                    onTransitionExited: m,
                    children: h,
                    onClose: b,
                    open: y,
                    rootRef: Z,
                  } = e,
                  x = a.useRef({}),
                  E = a.useRef(null),
                  k = a.useRef(null),
                  w = (0, s.Z)(k, Z),
                  [R, M] = a.useState(!y),
                  P = !!h && h.props.hasOwnProperty("in"),
                  T = !0;
                ("false" === e["aria-hidden"] || !1 === e["aria-hidden"]) &&
                  (T = !1);
                let I = () => (0, d.Z)(E.current),
                  C = () => (
                    (x.current.modalRef = k.current),
                    (x.current.mount = E.current),
                    x.current
                  ),
                  S = () => {
                    i.mount(C(), { disableScrollLock: r }),
                      k.current && (k.current.scrollTop = 0);
                  },
                  N = (0, u.Z)(() => {
                    let e = ("function" == typeof t ? t() : t) || I().body;
                    i.add(C(), e), k.current && S();
                  }),
                  A = a.useCallback(() => i.isTopModal(C()), [i]),
                  D = (0, u.Z)((e) => {
                    (E.current = e),
                      e && (y && A() ? S() : k.current && v(k.current, T));
                  }),
                  L = a.useCallback(() => {
                    i.remove(C(), T);
                  }, [T, i]);
                a.useEffect(
                  () => () => {
                    L();
                  },
                  [L]
                ),
                  a.useEffect(() => {
                    y ? N() : (P && l) || L();
                  }, [y, L, P, l, N]);
                let $ = (e) => (t) => {
                    var r;
                    null == (r = e.onKeyDown) || r.call(e, t),
                      "Escape" === t.key &&
                        229 !== t.which &&
                        A() &&
                        !n &&
                        (t.stopPropagation(), b && b(t, "escapeKeyDown"));
                  },
                  O = (e) => (t) => {
                    var n;
                    null == (n = e.onClick) || n.call(e, t),
                      t.target === t.currentTarget &&
                        b &&
                        b(t, "backdropClick");
                  },
                  B = (t = {}) => {
                    let n = (0, p._)(e);
                    delete n.onTransitionEnter, delete n.onTransitionExited;
                    let r = (0, o.Z)({}, n, t);
                    return (0, o.Z)({ role: "presentation" }, r, {
                      onKeyDown: $(r),
                      ref: w,
                    });
                  },
                  _ = (e = {}) =>
                    (0, o.Z)({ "aria-hidden": !0 }, e, {
                      onClick: O(e),
                      open: y,
                    }),
                  j = () => {
                    let e = () => {
                        M(!1), f && f();
                      },
                      t = () => {
                        M(!0), m && m(), l && L();
                      };
                    return {
                      onEnter: (0, c.Z)(
                        e,
                        null == h ? void 0 : h.props.onEnter
                      ),
                      onExited: (0, c.Z)(
                        t,
                        null == h ? void 0 : h.props.onExited
                      ),
                    };
                  };
                return {
                  getRootProps: B,
                  getBackdropProps: _,
                  getTransitionProps: j,
                  rootRef: w,
                  portalRef: D,
                  isTopModal: A,
                  exited: R,
                  hasTransition: P,
                };
              })((0, o.Z)({}, X, { rootRef: t })),
              ea = (0, o.Z)({}, X, { exited: er }),
              ei = I(ea),
              el = {};
            if ((void 0 === A.props.tabIndex && (el.tabIndex = "-1"), eo)) {
              let { onEnter: e, onExited: t } = ee();
              (el.onEnter = e), (el.onExited = t);
            }
            let es =
                null !=
                (n = null != (f = null == W ? void 0 : W.root) ? f : $.Root)
                  ? n
                  : C,
              ed =
                null !=
                (m =
                  null != (h = null == W ? void 0 : W.backdrop)
                    ? h
                    : $.Backdrop)
                  ? m
                  : k,
              eu = null != (b = null == H ? void 0 : H.root) ? b : O.root,
              ec =
                null != (y = null == H ? void 0 : H.backdrop) ? y : O.backdrop,
              ep = (0, l.y)({
                elementType: es,
                externalSlotProps: eu,
                externalForwardedProps: V,
                getSlotProps: Q,
                additionalProps: { ref: t, as: L },
                ownerState: ea,
                className: (0, i.Z)(
                  M,
                  null == eu ? void 0 : eu.className,
                  null == ei ? void 0 : ei.root,
                  !ea.open && ea.exited && (null == ei ? void 0 : ei.hidden)
                ),
              }),
              ef = (0, l.y)({
                elementType: ed,
                externalSlotProps: ec,
                additionalProps: R,
                getSlotProps: (e) =>
                  J(
                    (0, o.Z)({}, e, {
                      onClick: (t) => {
                        G && G(t), null != e && e.onClick && e.onClick(t);
                      },
                    })
                  ),
                className: (0, i.Z)(
                  null == ec ? void 0 : ec.className,
                  null == R ? void 0 : R.className,
                  null == ei ? void 0 : ei.backdrop
                ),
                ownerState: ea,
              });
            return Y || U || (eo && !er)
              ? (0, P.jsx)(E.h, {
                  ref: et,
                  container: D,
                  disablePortal: F,
                  children: (0, P.jsxs)(
                    es,
                    (0, o.Z)({}, ep, {
                      children: [
                        !K && k ? (0, P.jsx)(ed, (0, o.Z)({}, ef)) : null,
                        (0, P.jsx)(x.i, {
                          disableEnforceFocus: _,
                          disableAutoFocus: B,
                          disableRestoreFocus: z,
                          isEnabled: en,
                          open: U,
                          children: a.cloneElement(A, el),
                        }),
                      ],
                    })
                  ),
                })
              : null;
          });
        var A = N;
      },
      1011: function (e, t, n) {
        n.d(t, {
          x: function () {
            return a;
          },
        });
        var r = n(1588),
          o = n(34867);
        function a(e) {
          return (0, o.ZP)("MuiModal", e);
        }
        let i = (0, r.Z)("MuiModal", ["root", "hidden", "backdrop"]);
        t.Z = i;
      },
      90629: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return Z;
          },
        });
        var r = n(63366),
          o = n(87462),
          a = n(67294),
          i = n(90512),
          l = n(94780),
          s = n(2101),
          d = n(90948);
        let u = (e) =>
          (
            (e < 1 ? 5.11916 * e ** 2 : 4.5 * Math.log(e + 1) + 2) / 100
          ).toFixed(2);
        var c = n(71657),
          p = n(1588),
          f = n(34867);
        function m(e) {
          return (0, f.ZP)("MuiPaper", e);
        }
        (0, p.Z)("MuiPaper", [
          "root",
          "rounded",
          "outlined",
          "elevation",
          "elevation0",
          "elevation1",
          "elevation2",
          "elevation3",
          "elevation4",
          "elevation5",
          "elevation6",
          "elevation7",
          "elevation8",
          "elevation9",
          "elevation10",
          "elevation11",
          "elevation12",
          "elevation13",
          "elevation14",
          "elevation15",
          "elevation16",
          "elevation17",
          "elevation18",
          "elevation19",
          "elevation20",
          "elevation21",
          "elevation22",
          "elevation23",
          "elevation24",
        ]);
        var v = n(85893);
        let h = ["className", "component", "elevation", "square", "variant"],
          b = (e) => {
            let { square: t, elevation: n, variant: r, classes: o } = e,
              a = {
                root: [
                  "root",
                  r,
                  !t && "rounded",
                  "elevation" === r && `elevation${n}`,
                ],
              };
            return (0, l.Z)(a, m, o);
          },
          y = (0, d.ZP)("div", {
            name: "MuiPaper",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.root,
                t[n.variant],
                !n.square && t.rounded,
                "elevation" === n.variant && t[`elevation${n.elevation}`],
              ];
            },
          })(({ theme: e, ownerState: t }) => {
            var n;
            return (0, o.Z)(
              {
                backgroundColor: (e.vars || e).palette.background.paper,
                color: (e.vars || e).palette.text.primary,
                transition: e.transitions.create("box-shadow"),
              },
              !t.square && { borderRadius: e.shape.borderRadius },
              "outlined" === t.variant && {
                border: `1px solid ${(e.vars || e).palette.divider}`,
              },
              "elevation" === t.variant &&
                (0, o.Z)(
                  { boxShadow: (e.vars || e).shadows[t.elevation] },
                  !e.vars &&
                    "dark" === e.palette.mode && {
                      backgroundImage: `linear-gradient(${(0, s.Fq)(
                        "#fff",
                        u(t.elevation)
                      )}, ${(0, s.Fq)("#fff", u(t.elevation))})`,
                    },
                  e.vars && {
                    backgroundImage:
                      null == (n = e.vars.overlays) ? void 0 : n[t.elevation],
                  }
                )
            );
          }),
          g = a.forwardRef(function (e, t) {
            let n = (0, c.Z)({ props: e, name: "MuiPaper" }),
              {
                className: a,
                component: l = "div",
                elevation: s = 1,
                square: d = !1,
                variant: u = "elevation",
              } = n,
              p = (0, r.Z)(n, h),
              f = (0, o.Z)({}, n, {
                component: l,
                elevation: s,
                square: d,
                variant: u,
              }),
              m = b(f);
            return (0,
            v.jsx)(y, (0, o.Z)({ as: l, ownerState: f, className: (0, i.Z)(m.root, a), ref: t }, p));
          });
        var Z = g;
      },
      90886: function (e, t, n) {
        n.d(t, {
          i: function () {
            return d;
          },
        });
        var r = n(67294),
          o = n(33703),
          a = n(82690),
          i = n(85893);
        function l(e) {
          let t = [],
            n = [];
          return (
            Array.from(
              e.querySelectorAll(
                'input,select,textarea,a[href],button,[tabindex],audio[controls],video[controls],[contenteditable]:not([contenteditable="false"])'
              )
            ).forEach((e, r) => {
              let o = (function (e) {
                let t = parseInt(e.getAttribute("tabindex") || "", 10);
                return Number.isNaN(t)
                  ? "true" === e.contentEditable ||
                    (("AUDIO" === e.nodeName ||
                      "VIDEO" === e.nodeName ||
                      "DETAILS" === e.nodeName) &&
                      null === e.getAttribute("tabindex"))
                    ? 0
                    : e.tabIndex
                  : t;
              })(e);
              -1 === o ||
                e.disabled ||
                ("INPUT" === e.tagName && "hidden" === e.type) ||
                (function (e) {
                  if ("INPUT" !== e.tagName || "radio" !== e.type || !e.name)
                    return !1;
                  let t = (t) =>
                      e.ownerDocument.querySelector(`input[type="radio"]${t}`),
                    n = t(`[name="${e.name}"]:checked`);
                  return n || (n = t(`[name="${e.name}"]`)), n !== e;
                })(e) ||
                (0 === o
                  ? t.push(e)
                  : n.push({ documentOrder: r, tabIndex: o, node: e }));
            }),
            n
              .sort((e, t) =>
                e.tabIndex === t.tabIndex
                  ? e.documentOrder - t.documentOrder
                  : e.tabIndex - t.tabIndex
              )
              .map((e) => e.node)
              .concat(t)
          );
        }
        function s() {
          return !0;
        }
        function d(e) {
          let {
              children: t,
              disableAutoFocus: n = !1,
              disableEnforceFocus: d = !1,
              disableRestoreFocus: u = !1,
              getTabbable: c = l,
              isEnabled: p = s,
              open: f,
            } = e,
            m = r.useRef(!1),
            v = r.useRef(null),
            h = r.useRef(null),
            b = r.useRef(null),
            y = r.useRef(null),
            g = r.useRef(!1),
            Z = r.useRef(null),
            x = (0, o.Z)(t.ref, Z),
            E = r.useRef(null);
          r.useEffect(() => {
            f && Z.current && (g.current = !n);
          }, [n, f]),
            r.useEffect(() => {
              if (!f || !Z.current) return;
              let e = (0, a.Z)(Z.current);
              return (
                !Z.current.contains(e.activeElement) &&
                  (Z.current.hasAttribute("tabIndex") ||
                    Z.current.setAttribute("tabIndex", "-1"),
                  g.current && Z.current.focus()),
                () => {
                  u ||
                    (b.current &&
                      b.current.focus &&
                      ((m.current = !0), b.current.focus()),
                    (b.current = null));
                }
              );
            }, [f]),
            r.useEffect(() => {
              if (!f || !Z.current) return;
              let e = (0, a.Z)(Z.current),
                t = (t) => {
                  (E.current = t),
                    !d &&
                      p() &&
                      "Tab" === t.key &&
                      e.activeElement === Z.current &&
                      t.shiftKey &&
                      ((m.current = !0), h.current && h.current.focus());
                },
                n = () => {
                  let t = Z.current;
                  if (null === t) return;
                  if (!e.hasFocus() || !p() || m.current) {
                    m.current = !1;
                    return;
                  }
                  if (
                    t.contains(e.activeElement) ||
                    (d &&
                      e.activeElement !== v.current &&
                      e.activeElement !== h.current)
                  )
                    return;
                  if (e.activeElement !== y.current) y.current = null;
                  else if (null !== y.current) return;
                  if (!g.current) return;
                  let n = [];
                  if (
                    ((e.activeElement === v.current ||
                      e.activeElement === h.current) &&
                      (n = c(Z.current)),
                    n.length > 0)
                  ) {
                    var r, o;
                    let e = Boolean(
                        (null == (r = E.current) ? void 0 : r.shiftKey) &&
                          (null == (o = E.current) ? void 0 : o.key) === "Tab"
                      ),
                      t = n[0],
                      a = n[n.length - 1];
                    "string" != typeof t &&
                      "string" != typeof a &&
                      (e ? a.focus() : t.focus());
                  } else t.focus();
                };
              e.addEventListener("focusin", n),
                e.addEventListener("keydown", t, !0);
              let r = setInterval(() => {
                e.activeElement && "BODY" === e.activeElement.tagName && n();
              }, 50);
              return () => {
                clearInterval(r),
                  e.removeEventListener("focusin", n),
                  e.removeEventListener("keydown", t, !0);
              };
            }, [n, d, u, p, f, c]);
          let k = (e) => {
              null === b.current && (b.current = e.relatedTarget),
                (g.current = !0),
                (y.current = e.target);
              let n = t.props.onFocus;
              n && n(e);
            },
            w = (e) => {
              null === b.current && (b.current = e.relatedTarget),
                (g.current = !0);
            };
          return (0, i.jsxs)(r.Fragment, {
            children: [
              (0, i.jsx)("div", {
                tabIndex: f ? 0 : -1,
                onFocus: w,
                ref: v,
                "data-testid": "sentinelStart",
              }),
              r.cloneElement(t, { ref: x, onFocus: k }),
              (0, i.jsx)("div", {
                tabIndex: f ? 0 : -1,
                onFocus: w,
                ref: h,
                "data-testid": "sentinelEnd",
              }),
            ],
          });
        }
      },
      61730: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return c;
          },
        });
        var r,
          o = n(67294),
          a = n(73546),
          i = n(20539),
          l = n(34168);
        function s(e, t, n, r, i) {
          let [l, s] = o.useState(() =>
            i && n ? n(e).matches : r ? r(e).matches : t
          );
          return (
            (0, a.Z)(() => {
              let t = !0;
              if (!n) return;
              let r = n(e),
                o = () => {
                  t && s(r.matches);
                };
              return (
                o(),
                r.addListener(o),
                () => {
                  (t = !1), r.removeListener(o);
                }
              );
            }, [e, n]),
            l
          );
        }
        let d = (r || (r = n.t(o, 2))).useSyncExternalStore;
        function u(e, t, n, r, a) {
          let i = o.useCallback(() => t, [t]),
            l = o.useMemo(() => {
              if (a && n) return () => n(e).matches;
              if (null !== r) {
                let { matches: t } = r(e);
                return () => t;
              }
              return i;
            }, [i, e, r, a, n]),
            [s, u] = o.useMemo(() => {
              if (null === n) return [i, () => () => {}];
              let t = n(e);
              return [
                () => t.matches,
                (e) => (
                  t.addListener(e),
                  () => {
                    t.removeListener(e);
                  }
                ),
              ];
            }, [i, n, e]),
            c = d(u, s, l);
          return c;
        }
        function c(e, t = {}) {
          let n = (0, l.Z)(),
            r = "undefined" != typeof window && void 0 !== window.matchMedia,
            {
              defaultMatches: o = !1,
              matchMedia: a = r ? window.matchMedia : null,
              ssrMatchMedia: c = null,
              noSsr: p = !1,
            } = (0, i.Z)({ name: "MuiUseMediaQuery", props: t, theme: n }),
            f = "function" == typeof e ? e(n) : e;
          f = f.replace(/^@media( ?)/m, "");
          let m = (void 0 !== d ? u : s)(f, o, a, c, p);
          return m;
        }
      },
      91476: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return r;
          },
        });
        function r(...e) {
          return e.reduce(
            (e, t) =>
              null == t
                ? e
                : function (...n) {
                    e.apply(this, n), t.apply(this, n);
                  },
            () => {}
          );
        }
      },
      29726: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return r;
          },
        });
        function r(e) {
          let t = e.documentElement.clientWidth;
          return Math.abs(window.innerWidth - t);
        }
      },
      74161: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return o;
          },
        });
        var r = n(82690);
        function o(e) {
          let t = (0, r.Z)(e);
          return t.defaultView || window;
        }
      },
      59948: function (e, t, n) {
        var r = n(67294),
          o = n(73546);
        t.Z = function (e) {
          let t = r.useRef(e);
          return (
            (0, o.Z)(() => {
              t.current = e;
            }),
            r.useRef((...e) => (0, t.current)(...e)).current
          );
        };
      },
    },
  ]);
