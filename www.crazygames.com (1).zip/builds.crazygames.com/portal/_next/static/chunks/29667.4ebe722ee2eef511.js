!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      a = new e.Error().stack;
    a &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[a] = "147cbe71-80fa-4f8b-a6d6-321cd42215f8"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-147cbe71-80fa-4f8b-a6d6-321cd42215f8"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [29667],
    {
      29667: function (e) {
        e.exports = {
          messages: JSON.parse(
            '{"tag.head.metaDescription":["Play the Best Online ",["title"]," for Free on CrazyGames, No Download or Installation Required. \uD83C\uDFAE Play ",["game"]," and Many More Right Now!"],"tag.head.title":[["title"]," \uD83D\uDD79️ Play on CrazyGames",["pageNumber","select",{"1":" ","other":[" - Page ",["pageNumber"]]}]],"tag.leftcolumn.top":["Top ",["title"]],"tag.leftcolumn.new":["New ",["title"]],"tag.leftcolumn.related":"Related Games","tag.fillergrid.title":"Popular games","tag.faq.faq":"FAQ","tag.faq.popular":["What are the most popular ",["title"],"?"],"tag.faq.mobile":["What are the best ",["title"]," to play on mobile phones and tablets?"],"tag.faq.whatAre":["What are ",["title"],"?"],"tag.faq.whatAreSomeUnderrated":["What are some underrated ",["title"],"?"]}'
          ),
        };
      },
    },
  ]);
