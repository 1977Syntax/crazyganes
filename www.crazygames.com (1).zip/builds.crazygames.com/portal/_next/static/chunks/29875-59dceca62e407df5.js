!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "84aebb94-a73d-4fa9-9196-0e4990f74557"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-84aebb94-a73d-4fa9-9196-0e4990f74557"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [29875],
    {
      57200: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(94745),
          r = n(67294),
          o = n(38711),
          s = n.n(o),
          l = n(90512);
        let c = (e) => {
          let { description: t, className: n } = e,
            o = r.useRef(null),
            [c, u] = r.useState(!1),
            [d, g] = r.useState(!1);
          return (
            r.useEffect(() => {
              let e = () => {
                if (!t) return;
                g(!1);
                let e = o.current;
                u(!!(e && e?.scrollHeight > e?.clientHeight));
              };
              return (
                e(),
                t && window.addEventListener("resize", e),
                function () {
                  t && window.removeEventListener("resize", e);
                }
              );
            }, [t]),
            (0, a.jsxs)("div", {
              className: (0, l.Z)(s().shortDescriptionContainer, n),
              children: [
                (0, a.jsx)("div", {
                  className: (0, l.Z)(
                    s().shortDescription,
                    d && s().expanded,
                    c && s().needsShowMoreInSubtitle
                  ),
                  ref: o,
                  dangerouslySetInnerHTML: { __html: t },
                }),
                c &&
                  !d &&
                  (0, a.jsx)("div", {
                    className: (0, l.Z)(s().showMoreLessContainer),
                    onClick: () => g(!0),
                    children: (0, a.jsx)(i.cC, { id: "common.showMore" }),
                  }),
                c &&
                  d &&
                  (0, a.jsx)("div", {
                    className: (0, l.Z)(
                      s().showMoreLessContainer,
                      s().expanded
                    ),
                    onClick: () => g(!1),
                    children: (0, a.jsx)(i.cC, { id: "common.showLess" }),
                  }),
              ],
            })
          );
        };
        t.Z = c;
      },
      74886: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return z;
          },
        });
        var a = n(85893),
          i = n(96682),
          r = n(89609),
          o = n(67294),
          s = n(94745),
          l = n(30954),
          c = n(88642),
          u = n(63306),
          d = n(19073),
          g = n(83514),
          f = n(13592);
        let p = (e) => {
          let { tag: t } = e,
            { pageUrlHelper: n } = o.useContext(g.t),
            { routeHelper: i } = o.useContext(u.Z),
            { crazyRouterChange: r } = o.useContext(f.R),
            p = i.tagOrCategoryPageLink(t.slug, t.isCategory, 1, c.sc),
            h = i.tagOrCategoryPageLink(t.slug, t.isCategory, 1, c.Fi),
            m = n.isNewGamesSorting(),
            y = () => (m ? c.Fi : c.sc),
            _ = (e, t) => {
              t === c.sc && p && r(p.href, p.as),
                t === c.Fi && h && r(h.href, h.as);
            };
          return (0, a.jsxs)(d.ZP, {
            value: y(),
            onChange: _,
            style: { minWidth: 190 },
            children: [
              (0, a.jsx)(l.Z, {
                value: c.sc,
                disabled: y() === c.sc,
                children: (0, a.jsx)(s.cC, { id: "common.links.top" }),
              }),
              (0, a.jsx)(l.Z, {
                value: c.Fi,
                disabled: y() === c.Fi,
                children: (0, a.jsx)(s.cC, { id: "common.links.new" }),
              }),
            ],
          });
        };
        var h = n(94834),
          m = n(13264),
          y = n(32350);
        let _ = (0, m.Z)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return { display: "flex", "& a": (0, y.GC)(), marginBottom: t() };
          }),
          x = (e) => {
            let { tag: t } = e,
              { hierarchy: n } = t,
              { spacing: r } = (0, i.Z)();
            return n.length <= 1
              ? null
              : (0, a.jsx)(_, {
                  children: n.map((e, t) =>
                    (0, a.jsxs)(
                      o.Fragment,
                      {
                        children: [
                          t !== n.length - 1 &&
                            (0, a.jsx)(
                              h.Z,
                              {
                                slug: e.slug,
                                isCategory: e.isCategory,
                                children: e.name,
                              },
                              t
                            ),
                          t < n.length - 2 &&
                            (0, a.jsx)("div", {
                              style: {
                                paddingTop: 0,
                                paddingBottom: 0,
                                paddingRight: r(0.5),
                                paddingLeft: r(0.5),
                              },
                              children: "\xbb",
                            }),
                        ],
                      },
                      t
                    )
                  ),
                });
          };
        var w = n(57200);
        let P = (e) => {
          let { tag: t, title: n, description: o, titleRightSlogan: s } = e,
            { spacing: l } = (0, i.Z)();
          return (0, a.jsxs)("div", {
            style: {
              display: "flex",
              alignItems: "flex-end",
              justifyContent: "space-between",
              paddingRight: l(4),
              flexDirection: "column",
              flexFlow: "row wrap",
            },
            children: [
              (0, a.jsxs)(r.Z, {
                sx: {
                  display: "flex",
                  flexDirection: s ? "row" : "column",
                  flexWrap: s ? "wrap" : void 0,
                  width: s ? void 0 : "100%",
                  px: 2,
                  pt: 2,
                  maxWidth: { md: "calc(100% - 190px)" },
                },
                children: [
                  t && (0, a.jsx)(x, { tag: t }),
                  (0, a.jsx)("h1", {
                    style: { marginRight: l(2) },
                    children: n,
                  }),
                  s,
                  o && (0, a.jsx)(w.Z, { description: o }),
                ],
              }),
              t &&
                (0, a.jsx)(r.Z, {
                  sx: { pl: { xs: 2, md: 0 }, mt: { xs: 2, md: 0 } },
                  children: (0, a.jsx)(p, { tag: t }),
                }),
            ],
          });
        };
        var z = P;
      },
      18288: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(9008),
          r = n.n(i);
        n(67294);
        var o = n(46313),
          s = n(75007),
          l = n(33209);
        let c = "favicons/manifest-icon-3.png",
          u = "favicons/favicon-transparent.png",
          d = (e) => {
            let {
                title: t,
                metaDescription: n,
                canonical: i,
                alternatives: d = [],
                children: g,
              } = e,
              f = d.find((e) => {
                let { locale: t } = e;
                return t === l.ZW;
              }),
              p = (e, t, n) =>
                (0, s.ZP)(e, { width: t, height: n, fit: "crop" }),
              h = "development" === o.Z.Instance.environment;
            return (0, a.jsxs)(r(), {
              children: [
                (0, a.jsx)("title", {
                  children: `${h ? "\uD83E\uDD99 - " : ""}${t}`,
                }),
                (0, a.jsx)("link", { rel: "manifest", href: "/manifest" }),
                (0, a.jsx)("meta", { httpEquiv: "Accept-CH", content: "DPR" }),
                (0, a.jsx)("meta", { name: "description", content: n }),
                i && (0, a.jsx)("link", { rel: "canonical", href: i }),
                d.map((e) => {
                  let { href: t, locale: n } = e,
                    i = (0, l.xi)(n);
                  return (0, a.jsx)(
                    "link",
                    { rel: "alternate", hrefLang: i, href: t },
                    i
                  );
                }),
                f &&
                  (0, a.jsx)("link", {
                    rel: "alternate",
                    href: f.href,
                    hrefLang: "x-default",
                  }),
                (0, a.jsx)("meta", { name: "theme-color", content: "#ffffff" }),
                (0, a.jsx)("meta", {
                  name: "HandheldFriendly",
                  content: "true",
                }),
                (0, a.jsx)("meta", {
                  name: "mobile-web-app-capable",
                  content: "yes",
                }),
                (0, a.jsx)("meta", {
                  name: "apple-mobile-web-app-capable",
                  content: "yes",
                }),
                (0, a.jsx)("meta", {
                  name: "apple-mobile-web-app-status-bar-style",
                  content: "default",
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  href: p(c, 120, 120),
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "152x152",
                  href: p(c, 152, 152),
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "167x167",
                  href: p(c, 167, 167),
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "180x180",
                  href: p(c, 180, 180),
                }),
                (0, a.jsx)("link", {
                  rel: "mask-icon",
                  href: (0, s.ZP)("favicons/safari-pinned-tab.svg", {}, !1),
                  color: "#6842ff",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: p(u, 16, 16),
                  sizes: "16x16",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: p(u, 32, 32),
                  sizes: "32x32",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: p(u, 48, 48),
                  sizes: "48x48",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: p(u, 196, 196),
                  sizes: "196x196",
                }),
                (0, a.jsx)("meta", {
                  name: "msapplication-TileColor",
                  content: "#603cba",
                }),
                (0, a.jsx)("meta", {
                  name: "msapplication-TileImage",
                  content: p(u, 144, 144),
                }),
                g,
              ],
            });
          };
        t.Z = d;
      },
      94834: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(67294),
          r = n(63306),
          o = n(1982),
          s = n(72552),
          l = n(2978);
        let c = (e) => {
          let { slug: t, isCategory: n, children: c, className: u } = e,
            { routeHelper: d } = i.useContext(r.Z),
            g = i.useContext(o.t),
            f = (0, s.Z)(g),
            p = d.tagOrCategoryPageDirectLink(t, !!n, {}, { origin: f });
          return (0, a.jsx)(l.Z, {
            ...p,
            prefetch: !0,
            className: u,
            children: c,
          });
        };
        t.Z = c;
      },
      26830: function (e, t, n) {
        "use strict";
        n.d(t, {
          $W: function () {
            return h;
          },
          LG: function () {
            return w;
          },
          Q6: function () {
            return m;
          },
          Qq: function () {
            return f;
          },
          U9: function () {
            return p;
          },
          _: function () {
            return _;
          },
          _Y: function () {
            return u;
          },
          _f: function () {
            return P;
          },
          bM: function () {
            return d;
          },
          et: function () {
            return x;
          },
          h7: function () {
            return y;
          },
          tO: function () {
            return g;
          },
        });
        var a = n(45703),
          i = n(75538),
          r = n(29338),
          o = n(46313),
          s = n(33209),
          l = n(88642);
        function c(e) {
          let t = o.Z.Instance.data.domains,
            n = t.map((t) => {
              let n = "en-US" === (0, s.Jx)(t.host),
                o = { ...i.t },
                l = new a.Z(o),
                c = l.generateHome({ page: e });
              if (!c) return null;
              let u = (0, r.Z)(t.host, c.as, {
                isMainDomain: n,
                locale: t.locale,
              }).toString();
              return { locale: t.locale, href: u.toString(), host: t.host };
            });
          return n.filter((e) => !!e);
        }
        function u(e) {
          return z((e) => e.generateCompetitions(), {}, e, "competitions");
        }
        function d(e) {
          return z((e) => e.generateScholarship(), {}, e, "scholarship");
        }
        function g(e) {
          return z((e) => e.generateRecent(), {}, e, "recent");
        }
        function f(e) {
          return z((e) => e.generateOriginals(), {}, e, "originals");
        }
        function p(e) {
          return z((e) => e.generateTags(), {}, e, "tags");
        }
        function h(e, t) {
          return z((e, t) => e.generateGame(t), { slug: e }, t, "game");
        }
        function m(e) {
          return z((e) => e.generatePrivacyPolicy(), {}, e, "privacyPolicy");
        }
        function y(e) {
          return z(
            (e) => e.generateTermsAndConditions(),
            {},
            e,
            "termsAndConditions"
          );
        }
        function _(e) {
          return z((e) => e.generateSearch(), {}, e, "search");
        }
        async function x(e, t, n, a, i) {
          if (i) return c(a);
          if (t && "hot" === t)
            return z(
              (e) => e.generatePaginatedHotGames({ page: a }),
              {},
              await n.getRouteProviderData("hotGames"),
              "hotGames"
            );
          switch (e) {
            case l.Fi:
              let r = await n.getRouteProviderData("newGames");
              return z(
                (e) => e.generatePaginatedNewGames({ page: a }),
                {},
                r,
                "newGames"
              );
            case l.sc:
            case l.K6:
              return z(
                (e) => e.generatePaginatedUpdatedGames({ page: a }),
                {},
                await n.getRouteProviderData("updatedGames"),
                "updatedGames"
              );
            default:
              return console.warn(`unexpected sorting in games ${e}`), c(a);
          }
        }
        async function w(e, t, n) {
          if (e.isCategory) {
            let a = await t.getRouteProviderData("category");
            return z(
              (e, t) => e.generateCategory(t),
              { slugTrl: e.slug, page: n },
              a,
              "category"
            );
          }
          {
            let a = await t.getRouteProviderData("tag");
            return z(
              (e, t) => e.generateTag(t),
              { slugTrl: e.slug, page: n },
              a,
              "tag"
            );
          }
        }
        function P(e, t) {
          return z((t) => t.generateAllGames(e), {}, t, "allGames");
        }
        function z(e, t, n, l) {
          let c = (function (e) {
              let t = o.Z.Instance.data.domains,
                n = e.map((e) => {
                  let n = t.find((t) => {
                    let n = (0, s.Ld)(t.locale);
                    return n === e.locale;
                  });
                  return { domain: n, routeData: e };
                });
              return n;
            })(n),
            u = c.map((n) => {
              let o = n.domain,
                c = "en-US" === (0, s.Jx)(o.host),
                u = o.locale,
                d = {
                  ...i.t,
                  [l]: n.routeData.route,
                  locale: n.routeData.locale,
                },
                g = new a.Z(d),
                f = e(g, t);
              if (!f || !n.domain) return null;
              let p = (0, r.Z)(n.domain.host, f.as, {
                isMainDomain: c,
                locale: u,
              }).toString();
              return {
                locale: n.domain.locale,
                href: p.toString(),
                host: n.domain.host,
              };
            });
          return u.filter((e) => !!e);
        }
      },
      44715: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(67294),
          r = n(83808);
        t.Z = function () {
          for (var e = arguments.length, t = Array(e), n = 0; n < e; n++)
            t[n] = arguments[n];
          return (e) =>
            class extends i.Component {
              static async getInitialProps(n) {
                let { trlService: a } = (0, r.b)(n);
                if (!n.req) {
                  let i = Promise.all(
                      t.map((e) => a.loadTrlMessagesToLingui(e))
                    ),
                    [r] = await Promise.all([
                      e.getInitialProps ? await e.getInitialProps(n) : {},
                      i,
                    ]);
                  return { ...r };
                }
                let i = Promise.all(t.map((e) => a.getTrlMessages(e))),
                  [o, s] = await Promise.all([
                    e.getInitialProps
                      ? e.getInitialProps(n)
                      : Promise.resolve({}),
                    i,
                  ]),
                  l = s.reduce((e, t) => Object.assign(e, t));
                return { messages: l, ...o };
              }
              render() {
                let { ...t } = this.props;
                return (0, a.jsx)(e, { ...t });
              }
            };
        };
      },
      75538: function (e, t, n) {
        "use strict";
        n.d(t, {
          P: function () {
            return a;
          },
          t: function () {
            return i;
          },
        });
        let a = [
            "newGames",
            "updatedGames",
            "hotGames",
            "tags",
            "category",
            "tag",
            "game",
            "preview",
            "termsAndConditions",
            "informationForParents",
            "privacyPolicy",
            "10-anniversary",
            "recent",
            "originals",
            "search",
            "scholarship",
            "competitions",
            "pwa",
            "pwaInstall",
            "allGames",
          ],
          i = {
            newGames: "",
            updatedGames: "",
            hotGames: "",
            tags: "",
            category: "",
            tag: "",
            game: "",
            preview: "",
            termsAndConditions: "",
            privacyPolicy: "",
            "10-anniversary": "",
            recent: "",
            originals: "",
            search: "",
            pwa: "",
            pwaInstall: "",
            allGames: "",
            locale: "",
          };
      },
      38711: function (e) {
        e.exports = {
          czyButton: "PageTitle_czyButton__swk3e",
          "czyButton--contained--purple":
            "PageTitle_czyButton--contained--purple__PBW0y",
          "czyButton--contained--white":
            "PageTitle_czyButton--contained--white__Yl_CC",
          "czyButton--contained--grey":
            "PageTitle_czyButton--contained--grey__iMrqd",
          "czyButton--contained--alert":
            "PageTitle_czyButton--contained--alert__a8p_s",
          "czyButton--contained--success":
            "PageTitle_czyButton--contained--success__VPU1c",
          "czyButton--contained--black":
            "PageTitle_czyButton--contained--black__vxe7C",
          "czyButton--contained--green-gradient":
            "PageTitle_czyButton--contained--green-gradient__rBciz",
          "czyButton--outlined--purple":
            "PageTitle_czyButton--outlined--purple__gh1Oq",
          "czyButton--link--purple": "PageTitle_czyButton--link--purple__f68t0",
          "czyButton--outlined--white":
            "PageTitle_czyButton--outlined--white__kkN49",
          "czyButton--link--white": "PageTitle_czyButton--link--white__K8io3",
          "czyButton--outlined--grey":
            "PageTitle_czyButton--outlined--grey__bbBmd",
          "czyButton--link--grey": "PageTitle_czyButton--link--grey__kAMf4",
          "czyButton--outlined--alert":
            "PageTitle_czyButton--outlined--alert__E9Mm_",
          "czyButton--link--alert": "PageTitle_czyButton--link--alert__RfFeN",
          "czyButton--outlined--success":
            "PageTitle_czyButton--outlined--success__WtBwW",
          "czyButton--link--success":
            "PageTitle_czyButton--link--success__mNPzT",
          "czyButton--outlined": "PageTitle_czyButton--outlined__o6yYn",
          "czyButton--disabled": "PageTitle_czyButton--disabled__3WkBW",
          "czyButton--height50": "PageTitle_czyButton--height50__0yjpi",
          "czyButton--height34": "PageTitle_czyButton--height34__rouPD",
          "czyButton--fullWidth": "PageTitle_czyButton--fullWidth__FQip1",
          shortDescriptionContainer:
            "PageTitle_shortDescriptionContainer__92SiZ",
          shortDescription: "PageTitle_shortDescription__FqfoL",
          expanded: "PageTitle_expanded__6YbJs",
          needsShowMoreInSubtitle: "PageTitle_needsShowMoreInSubtitle__HsxTl",
          showMoreLessContainer: "PageTitle_showMoreLessContainer__K1ec7",
        };
      },
    },
  ]);
