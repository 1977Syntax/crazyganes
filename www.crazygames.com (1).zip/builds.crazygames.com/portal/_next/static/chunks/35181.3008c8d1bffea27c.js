!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "ced89a7d-6274-4392-9e80-6f62003e21dc"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-ced89a7d-6274-4392-9e80-6f62003e21dc"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [35181],
    {
      35181: function (e, t, n) {
        n.r(t);
        var o = n(85893);
        n(67294);
        var r = n(44354),
          a = n(96224),
          d = n(44846),
          l = n(3411),
          i = n(43740);
        let s = (e) => {
          let { text: t, onClose: n, open: s } = e;
          return (0, o.jsx)(a.I2, {
            open: s,
            onClose: n,
            slots: { backdrop: d._ },
            children: (0, o.jsxs)(a.If, {
              sx: {
                backgroundColor: l.D.black[70],
                pt: 6,
                pl: 3,
                position: "relative",
              },
              children: [
                (0, o.jsx)(a.dD, {
                  onClick: n,
                  variant: "outlined",
                  color: "white",
                  sx: {
                    "& svg": { mr: 0 },
                    position: "absolute",
                    right: 8,
                    top: 8,
                    borderWidth: 0,
                  },
                  children: (0, o.jsx)(i.Z, {}),
                }),
                (0, o.jsx)(r.Ah, {
                  dangerouslySetInnerHTML: { __html: t },
                  sx: { overflow: "scroll", pr: 3 },
                  expanded: !0,
                }),
              ],
            }),
          });
        };
        t.default = s;
      },
      96224: function (e, t, n) {
        n.d(t, {
          I2: function () {
            return i;
          },
          If: function () {
            return u;
          },
          Jv: function () {
            return c;
          },
          _m: function () {
            return s;
          },
          dD: function () {
            return p;
          },
          l4: function () {
            return f;
          },
        });
        var o = n(86507),
          r = n(90948),
          a = n(3411),
          d = n(32350),
          l = n(31601);
        let i = (0, r.ZP)(o.Z)((e) => {
            let { theme: t } = e;
            return {
              padding: t.spacing(4),
              position: "fixed",
              zIndex: 1300,
              inset: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            };
          }),
          s = (0, r.ZP)("div")((e) => {
            let { theme: t } = e;
            return {
              position: "relative",
              padding: t.spacing(1),
              maxHeight: "calc(100% - 64px)",
              maxWidth: "100%",
              display: "flex",
              flexDirection: "column",
              outline: "none",
            };
          }),
          u = (0, r.ZP)("div")(() => ({
            ...(0, d.no)(7),
            overflowY: "auto",
            backgroundColor: a.D.black[70],
            color: a.D.white[10],
            borderRadius: 20,
            maxWidth: 600,
          })),
          c = (0, r.ZP)("h1")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginBottom: t(2),
              textAlign: "center",
              color: a.D.white[100],
              fontWeight: 800,
            };
          }),
          f = (0, r.ZP)("div")(() => ({
            position: "absolute",
            top: 16,
            right: 12,
            width: 38,
            height: 38,
            "& button": {
              backgroundColor: "transparent",
              color: a.D.white[10],
              "&:hover": {
                backgroundColor: "transparent",
                color: a.D.white[40],
              },
            },
            zIndex: 1,
          })),
          p = (0, r.ZP)(l.Sn)(() => ({
            padding: 0,
            width: 30,
            minWidth: 30,
            height: 30,
          }));
      },
    },
  ]);
