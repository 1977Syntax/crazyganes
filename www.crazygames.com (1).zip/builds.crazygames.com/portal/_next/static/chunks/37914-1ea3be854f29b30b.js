!(function () {
  try {
    var t =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      n = new t.Error().stack;
    n &&
      ((t._sentryDebugIds = t._sentryDebugIds || {}),
      (t._sentryDebugIds[n] = "6cf51a13-cb4b-478b-a5d4-bc800b4e72cc"),
      (t._sentryDebugIdIdentifier =
        "sentry-dbid-6cf51a13-cb4b-478b-a5d4-bc800b4e72cc"));
  } catch (t) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [37914],
    {
      8173: function (t, n, e) {
        e.d(n, {
          h: function () {
            return l;
          },
        });
        var i = e(67294),
          o = e(73935),
          r = e(33703),
          a = e(73546),
          s = e(27364),
          u = e(85893);
        let l = i.forwardRef(function (t, n) {
          let { children: e, container: l, disablePortal: d = !1 } = t,
            [p, c] = i.useState(null),
            f = (0, r.Z)(i.isValidElement(e) ? e.ref : null, n);
          return ((0, a.Z)(() => {
            !d && c(("function" == typeof l ? l() : l) || document.body);
          }, [l, d]),
          (0, a.Z)(() => {
            if (p && !d)
              return (
                (0, s.Z)(n, p),
                () => {
                  (0, s.Z)(n, null);
                }
              );
          }, [n, p, d]),
          d)
            ? i.isValidElement(e)
              ? i.cloneElement(e, { ref: f })
              : (0, u.jsx)(i.Fragment, { children: e })
            : (0, u.jsx)(i.Fragment, {
                children: p ? o.createPortal(e, p) : p,
              });
        });
      },
      83265: function (t, n, e) {
        e.d(n, {
          y: function () {
            return d;
          },
        });
        var i = e(87462),
          o = e(63366),
          r = e(33703),
          a = e(76591),
          s = e(3214),
          u = e(17488);
        let l = [
          "elementType",
          "externalSlotProps",
          "ownerState",
          "skipResolvingSlotProps",
        ];
        function d(t) {
          var n;
          let {
              elementType: e,
              externalSlotProps: d,
              ownerState: p,
              skipResolvingSlotProps: c = !1,
            } = t,
            f = (0, o.Z)(t, l),
            h = c ? {} : (0, u.x)(d, p),
            { props: E, internalRef: x } = (0, s.L)(
              (0, i.Z)({}, f, { externalSlotProps: h })
            ),
            b = (0, r.Z)(
              x,
              null == h ? void 0 : h.ref,
              null == (n = t.additionalProps) ? void 0 : n.ref
            ),
            m = (0, a.$)(e, (0, i.Z)({}, E, { ref: b }), p);
          return m;
        }
      },
      30577: function (t, n, e) {
        e.d(n, {
          C: function () {
            return o;
          },
          n: function () {
            return i;
          },
        });
        let i = (t) => t.scrollTop;
        function o(t, n) {
          var e, i;
          let { timeout: o, easing: r, style: a = {} } = t;
          return {
            duration:
              null != (e = a.transitionDuration)
                ? e
                : "number" == typeof o
                ? o
                : o[n.mode] || 0,
            easing:
              null != (i = a.transitionTimingFunction)
                ? i
                : "object" == typeof r
                ? r[n.mode]
                : r,
            delay: a.transitionDelay,
          };
        }
      },
      98885: function (t, n, e) {
        e.d(n, {
          ZP: function () {
            return b;
          },
        });
        var i = e(63366),
          o = e(94578),
          r = e(67294),
          a = e(73935),
          s = { disabled: !1 },
          u = e(220),
          l = e(59391),
          d = "unmounted",
          p = "exited",
          c = "entering",
          f = "entered",
          h = "exiting",
          E = (function (t) {
            function n(n, e) {
              i = t.call(this, n, e) || this;
              var i,
                o,
                r = e && !e.isMounting ? n.enter : n.appear;
              return (
                (i.appearStatus = null),
                n.in
                  ? r
                    ? ((o = p), (i.appearStatus = c))
                    : (o = f)
                  : (o = n.unmountOnExit || n.mountOnEnter ? d : p),
                (i.state = { status: o }),
                (i.nextCallback = null),
                i
              );
            }
            (0, o.Z)(n, t),
              (n.getDerivedStateFromProps = function (t, n) {
                return t.in && n.status === d ? { status: p } : null;
              });
            var e = n.prototype;
            return (
              (e.componentDidMount = function () {
                this.updateStatus(!0, this.appearStatus);
              }),
              (e.componentDidUpdate = function (t) {
                var n = null;
                if (t !== this.props) {
                  var e = this.state.status;
                  this.props.in
                    ? e !== c && e !== f && (n = c)
                    : (e === c || e === f) && (n = h);
                }
                this.updateStatus(!1, n);
              }),
              (e.componentWillUnmount = function () {
                this.cancelNextCallback();
              }),
              (e.getTimeouts = function () {
                var t,
                  n,
                  e,
                  i = this.props.timeout;
                return (
                  (t = n = e = i),
                  null != i &&
                    "number" != typeof i &&
                    ((t = i.exit),
                    (n = i.enter),
                    (e = void 0 !== i.appear ? i.appear : n)),
                  { exit: t, enter: n, appear: e }
                );
              }),
              (e.updateStatus = function (t, n) {
                if ((void 0 === t && (t = !1), null !== n)) {
                  if ((this.cancelNextCallback(), n === c)) {
                    if (this.props.unmountOnExit || this.props.mountOnEnter) {
                      var e = this.props.nodeRef
                        ? this.props.nodeRef.current
                        : a.findDOMNode(this);
                      e && (0, l.Q)(e);
                    }
                    this.performEnter(t);
                  } else this.performExit();
                } else
                  this.props.unmountOnExit &&
                    this.state.status === p &&
                    this.setState({ status: d });
              }),
              (e.performEnter = function (t) {
                var n = this,
                  e = this.props.enter,
                  i = this.context ? this.context.isMounting : t,
                  o = this.props.nodeRef ? [i] : [a.findDOMNode(this), i],
                  r = o[0],
                  u = o[1],
                  l = this.getTimeouts(),
                  d = i ? l.appear : l.enter;
                if ((!t && !e) || s.disabled) {
                  this.safeSetState({ status: f }, function () {
                    n.props.onEntered(r);
                  });
                  return;
                }
                this.props.onEnter(r, u),
                  this.safeSetState({ status: c }, function () {
                    n.props.onEntering(r, u),
                      n.onTransitionEnd(d, function () {
                        n.safeSetState({ status: f }, function () {
                          n.props.onEntered(r, u);
                        });
                      });
                  });
              }),
              (e.performExit = function () {
                var t = this,
                  n = this.props.exit,
                  e = this.getTimeouts(),
                  i = this.props.nodeRef ? void 0 : a.findDOMNode(this);
                if (!n || s.disabled) {
                  this.safeSetState({ status: p }, function () {
                    t.props.onExited(i);
                  });
                  return;
                }
                this.props.onExit(i),
                  this.safeSetState({ status: h }, function () {
                    t.props.onExiting(i),
                      t.onTransitionEnd(e.exit, function () {
                        t.safeSetState({ status: p }, function () {
                          t.props.onExited(i);
                        });
                      });
                  });
              }),
              (e.cancelNextCallback = function () {
                null !== this.nextCallback &&
                  (this.nextCallback.cancel(), (this.nextCallback = null));
              }),
              (e.safeSetState = function (t, n) {
                (n = this.setNextCallback(n)), this.setState(t, n);
              }),
              (e.setNextCallback = function (t) {
                var n = this,
                  e = !0;
                return (
                  (this.nextCallback = function (i) {
                    e && ((e = !1), (n.nextCallback = null), t(i));
                  }),
                  (this.nextCallback.cancel = function () {
                    e = !1;
                  }),
                  this.nextCallback
                );
              }),
              (e.onTransitionEnd = function (t, n) {
                this.setNextCallback(n);
                var e = this.props.nodeRef
                    ? this.props.nodeRef.current
                    : a.findDOMNode(this),
                  i = null == t && !this.props.addEndListener;
                if (!e || i) {
                  setTimeout(this.nextCallback, 0);
                  return;
                }
                if (this.props.addEndListener) {
                  var o = this.props.nodeRef
                      ? [this.nextCallback]
                      : [e, this.nextCallback],
                    r = o[0],
                    s = o[1];
                  this.props.addEndListener(r, s);
                }
                null != t && setTimeout(this.nextCallback, t);
              }),
              (e.render = function () {
                var t = this.state.status;
                if (t === d) return null;
                var n = this.props,
                  e = n.children,
                  o =
                    (n.in,
                    n.mountOnEnter,
                    n.unmountOnExit,
                    n.appear,
                    n.enter,
                    n.exit,
                    n.timeout,
                    n.addEndListener,
                    n.onEnter,
                    n.onEntering,
                    n.onEntered,
                    n.onExit,
                    n.onExiting,
                    n.onExited,
                    n.nodeRef,
                    (0, i.Z)(n, [
                      "children",
                      "in",
                      "mountOnEnter",
                      "unmountOnExit",
                      "appear",
                      "enter",
                      "exit",
                      "timeout",
                      "addEndListener",
                      "onEnter",
                      "onEntering",
                      "onEntered",
                      "onExit",
                      "onExiting",
                      "onExited",
                      "nodeRef",
                    ]));
                return r.createElement(
                  u.Z.Provider,
                  { value: null },
                  "function" == typeof e
                    ? e(t, o)
                    : r.cloneElement(r.Children.only(e), o)
                );
              }),
              n
            );
          })(r.Component);
        function x() {}
        (E.contextType = u.Z),
          (E.propTypes = {}),
          (E.defaultProps = {
            in: !1,
            mountOnEnter: !1,
            unmountOnExit: !1,
            appear: !1,
            enter: !0,
            exit: !0,
            onEnter: x,
            onEntering: x,
            onEntered: x,
            onExit: x,
            onExiting: x,
            onExited: x,
          }),
          (E.UNMOUNTED = d),
          (E.EXITED = p),
          (E.ENTERING = c),
          (E.ENTERED = f),
          (E.EXITING = h);
        var b = E;
      },
      59391: function (t, n, e) {
        e.d(n, {
          Q: function () {
            return i;
          },
        });
        var i = function (t) {
          return t.scrollTop;
        };
      },
    },
  ]);
