!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "65db4d4d-7f6c-458d-bda7-65e28dd49d0d"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-65db4d4d-7f6c-458d-bda7-65e28dd49d0d"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [38952],
    {
      47210: function (e, t, n) {
        "use strict";
        n.d(t, {
          $g: function () {
            return r.s;
          },
          A$: function () {
            return r.L;
          },
          AP: function () {
            return r.i;
          },
          Aj: function () {
            return r.y;
          },
          BV: function () {
            return r.U;
          },
          Bs: function () {
            return r.A;
          },
          C3: function () {
            return r.h;
          },
          C8: function () {
            return r.O;
          },
          F6: function () {
            return r.f;
          },
          F7: function () {
            return r.p;
          },
          Fb: function () {
            return r.q;
          },
          GH: function () {
            return r.Y;
          },
          H0: function () {
            return r.G;
          },
          H5: function () {
            return r.ar;
          },
          JB: function () {
            return r.ad;
          },
          JG: function () {
            return r.at;
          },
          Jw: function () {
            return r.n;
          },
          L6: function () {
            return r.l;
          },
          LG: function () {
            return r.a6;
          },
          LS: function () {
            return r.a5;
          },
          MI: function () {
            return r.M;
          },
          MX: function () {
            return r.w;
          },
          Nr: function () {
            return r.af;
          },
          O4: function () {
            return r.Z;
          },
          Ov: function () {
            return r.ah;
          },
          P6: function () {
            return r.ae;
          },
          RF: function () {
            return r.S;
          },
          RL: function () {
            return r.t;
          },
          RO: function () {
            return r.P;
          },
          Rv: function () {
            return r.u;
          },
          S$: function () {
            return r.K;
          },
          SF: function () {
            return r.B;
          },
          SP: function () {
            return r.T;
          },
          TX: function () {
            return r.a9;
          },
          VE: function () {
            return r._;
          },
          WV: function () {
            return r.g;
          },
          XB: function () {
            return r.a0;
          },
          Xb: function () {
            return r.aa;
          },
          ZJ: function () {
            return r.a2;
          },
          _O: function () {
            return r.W;
          },
          _p: function () {
            return r.a4;
          },
          a$: function () {
            return r.b;
          },
          aF: function () {
            return r.a3;
          },
          aT: function () {
            return r.a;
          },
          ag: function () {
            return r.ao;
          },
          bX: function () {
            return r.a8;
          },
          bc: function () {
            return r.e;
          },
          bu: function () {
            return r.H;
          },
          c4: function () {
            return r.$;
          },
          ck: function () {
            return r.ak;
          },
          cx: function () {
            return r.j;
          },
          e5: function () {
            return r.ab;
          },
          gK: function () {
            return r.aq;
          },
          gQ: function () {
            return r.am;
          },
          h6: function () {
            return r.D;
          },
          h8: function () {
            return r.E;
          },
          hJ: function () {
            return r.X;
          },
          iA: function () {
            return r.a7;
          },
          ic: function () {
            return r.z;
          },
          jX: function () {
            return r.F;
          },
          jh: function () {
            return r.N;
          },
          k9: function () {
            return r.d;
          },
          kq: function () {
            return r.I;
          },
          lI: function () {
            return r.R;
          },
          mP: function () {
            return r.Q;
          },
          n0: function () {
            return r.k;
          },
          ne: function () {
            return r.ai;
          },
          oo: function () {
            return r.ac;
          },
          p2: function () {
            return r.as;
          },
          qB: function () {
            return r.ap;
          },
          qh: function () {
            return r.x;
          },
          rh: function () {
            return r.c;
          },
          s: function () {
            return r.al;
          },
          sB: function () {
            return r.a1;
          },
          uJ: function () {
            return r.J;
          },
          uo: function () {
            return r.v;
          },
          uw: function () {
            return r.aj;
          },
          v0: function () {
            return r.o;
          },
          vY: function () {
            return r.r;
          },
          w$: function () {
            return r.ag;
          },
          w7: function () {
            return r.C;
          },
          w9: function () {
            return r.V;
          },
          wU: function () {
            return r.an;
          },
          ww: function () {
            return r.m;
          },
        });
        var r = n(92175);
        n(25816), n(74444), n(53333), n(8463);
      },
      74444: function (e, t, n) {
        "use strict";
        n.d(t, {
          BH: function () {
            return v;
          },
          L: function () {
            return c;
          },
          LL: function () {
            return D;
          },
          Pz: function () {
            return m;
          },
          ZR: function () {
            return A;
          },
          aH: function () {
            return b;
          },
          b$: function () {
            return _;
          },
          eu: function () {
            return S;
          },
          hl: function () {
            return C;
          },
          m9: function () {
            return $;
          },
          ne: function () {
            return R;
          },
          pd: function () {
            return T;
          },
          q4: function () {
            return g;
          },
          ru: function () {
            return E;
          },
          tV: function () {
            return l;
          },
          uI: function () {
            return w;
          },
          vZ: function () {
            return function e(t, n) {
              if (t === n) return !0;
              let r = Object.keys(t),
                i = Object.keys(n);
              for (let o of r) {
                if (!i.includes(o)) return !1;
                let r = t[o],
                  a = n[o];
                if (B(r) && B(a)) {
                  if (!e(r, a)) return !1;
                } else if (r !== a) return !1;
              }
              for (let e of i) if (!r.includes(e)) return !1;
              return !0;
            };
          },
          w1: function () {
            return I;
          },
          xO: function () {
            return P;
          },
          xb: function () {
            return L;
          },
          z$: function () {
            return y;
          },
          zd: function () {
            return M;
          },
        });
        var r = n(83454);
        /**
         * @license
         * Copyright 2017 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ let i = function (e) {
            let t = [],
              n = 0;
            for (let r = 0; r < e.length; r++) {
              let i = e.charCodeAt(r);
              i < 128
                ? (t[n++] = i)
                : i < 2048
                ? ((t[n++] = (i >> 6) | 192), (t[n++] = (63 & i) | 128))
                : (64512 & i) == 55296 &&
                  r + 1 < e.length &&
                  (64512 & e.charCodeAt(r + 1)) == 56320
                ? ((i =
                    65536 + ((1023 & i) << 10) + (1023 & e.charCodeAt(++r))),
                  (t[n++] = (i >> 18) | 240),
                  (t[n++] = ((i >> 12) & 63) | 128),
                  (t[n++] = ((i >> 6) & 63) | 128),
                  (t[n++] = (63 & i) | 128))
                : ((t[n++] = (i >> 12) | 224),
                  (t[n++] = ((i >> 6) & 63) | 128),
                  (t[n++] = (63 & i) | 128));
            }
            return t;
          },
          o = function (e) {
            let t = [],
              n = 0,
              r = 0;
            for (; n < e.length; ) {
              let i = e[n++];
              if (i < 128) t[r++] = String.fromCharCode(i);
              else if (i > 191 && i < 224) {
                let o = e[n++];
                t[r++] = String.fromCharCode(((31 & i) << 6) | (63 & o));
              } else if (i > 239 && i < 365) {
                let o = e[n++],
                  a = e[n++],
                  s = e[n++],
                  u =
                    (((7 & i) << 18) |
                      ((63 & o) << 12) |
                      ((63 & a) << 6) |
                      (63 & s)) -
                    65536;
                (t[r++] = String.fromCharCode(55296 + (u >> 10))),
                  (t[r++] = String.fromCharCode(56320 + (1023 & u)));
              } else {
                let o = e[n++],
                  a = e[n++];
                t[r++] = String.fromCharCode(
                  ((15 & i) << 12) | ((63 & o) << 6) | (63 & a)
                );
              }
            }
            return t.join("");
          },
          a = {
            byteToCharMap_: null,
            charToByteMap_: null,
            byteToCharMapWebSafe_: null,
            charToByteMapWebSafe_: null,
            ENCODED_VALS_BASE:
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
            get ENCODED_VALS() {
              return this.ENCODED_VALS_BASE + "+/=";
            },
            get ENCODED_VALS_WEBSAFE() {
              return this.ENCODED_VALS_BASE + "-_.";
            },
            HAS_NATIVE_SUPPORT: "function" == typeof atob,
            encodeByteArray(e, t) {
              if (!Array.isArray(e))
                throw Error("encodeByteArray takes an array as a parameter");
              this.init_();
              let n = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_,
                r = [];
              for (let t = 0; t < e.length; t += 3) {
                let i = e[t],
                  o = t + 1 < e.length,
                  a = o ? e[t + 1] : 0,
                  s = t + 2 < e.length,
                  u = s ? e[t + 2] : 0,
                  c = i >> 2,
                  l = ((3 & i) << 4) | (a >> 4),
                  f = ((15 & a) << 2) | (u >> 6),
                  h = 63 & u;
                s || ((h = 64), o || (f = 64)), r.push(n[c], n[l], n[f], n[h]);
              }
              return r.join("");
            },
            encodeString(e, t) {
              return this.HAS_NATIVE_SUPPORT && !t
                ? btoa(e)
                : this.encodeByteArray(i(e), t);
            },
            decodeString(e, t) {
              return this.HAS_NATIVE_SUPPORT && !t
                ? atob(e)
                : o(this.decodeStringToByteArray(e, t));
            },
            decodeStringToByteArray(e, t) {
              this.init_();
              let n = t ? this.charToByteMapWebSafe_ : this.charToByteMap_,
                r = [];
              for (let t = 0; t < e.length; ) {
                let i = n[e.charAt(t++)],
                  o = t < e.length,
                  a = o ? n[e.charAt(t)] : 0;
                ++t;
                let u = t < e.length,
                  c = u ? n[e.charAt(t)] : 64;
                ++t;
                let l = t < e.length,
                  f = l ? n[e.charAt(t)] : 64;
                if ((++t, null == i || null == a || null == c || null == f))
                  throw new s();
                let h = (i << 2) | (a >> 4);
                if ((r.push(h), 64 !== c)) {
                  let e = ((a << 4) & 240) | (c >> 2);
                  if ((r.push(e), 64 !== f)) {
                    let e = ((c << 6) & 192) | f;
                    r.push(e);
                  }
                }
              }
              return r;
            },
            init_() {
              if (!this.byteToCharMap_) {
                (this.byteToCharMap_ = {}),
                  (this.charToByteMap_ = {}),
                  (this.byteToCharMapWebSafe_ = {}),
                  (this.charToByteMapWebSafe_ = {});
                for (let e = 0; e < this.ENCODED_VALS.length; e++)
                  (this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e)),
                    (this.charToByteMap_[this.byteToCharMap_[e]] = e),
                    (this.byteToCharMapWebSafe_[e] =
                      this.ENCODED_VALS_WEBSAFE.charAt(e)),
                    (this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] =
                      e),
                    e >= this.ENCODED_VALS_BASE.length &&
                      ((this.charToByteMap_[
                        this.ENCODED_VALS_WEBSAFE.charAt(e)
                      ] = e),
                      (this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] =
                        e));
              }
            },
          };
        class s extends Error {
          constructor() {
            super(...arguments), (this.name = "DecodeBase64StringError");
          }
        }
        let u = function (e) {
            let t = i(e);
            return a.encodeByteArray(t, !0);
          },
          c = function (e) {
            return u(e).replace(/\./g, "");
          },
          l = function (e) {
            try {
              return a.decodeString(e, !0);
            } catch (e) {
              console.error("base64Decode failed: ", e);
            }
            return null;
          },
          f = () =>
            /**
             * @license
             * Copyright 2022 Google LLC
             *
             * Licensed under the Apache License, Version 2.0 (the "License");
             * you may not use this file except in compliance with the License.
             * You may obtain a copy of the License at
             *
             *   http://www.apache.org/licenses/LICENSE-2.0
             *
             * Unless required by applicable law or agreed to in writing, software
             * distributed under the License is distributed on an "AS IS" BASIS,
             * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
             * See the License for the specific language governing permissions and
             * limitations under the License.
             */ (function () {
              if ("undefined" != typeof self) return self;
              if ("undefined" != typeof window) return window;
              if (void 0 !== n.g) return n.g;
              throw Error("Unable to locate global object.");
            })().__FIREBASE_DEFAULTS__,
          h = () => {
            if (void 0 === r || void 0 === r.env) return;
            let e = r.env.__FIREBASE_DEFAULTS__;
            if (e) return JSON.parse(e);
          },
          d = () => {
            let e;
            if ("undefined" == typeof document) return;
            try {
              e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/);
            } catch (e) {
              return;
            }
            let t = e && l(e[1]);
            return t && JSON.parse(t);
          },
          p = () => {
            try {
              return f() || h() || d();
            } catch (e) {
              console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
              return;
            }
          },
          g = (e) => {
            var t, n;
            return null ===
              (n =
                null === (t = p()) || void 0 === t
                  ? void 0
                  : t.emulatorHosts) || void 0 === n
              ? void 0
              : n[e];
          },
          b = () => {
            var e;
            return null === (e = p()) || void 0 === e ? void 0 : e.config;
          },
          m = (e) => {
            var t;
            return null === (t = p()) || void 0 === t ? void 0 : t[`_${e}`];
          };
        /**
         * @license
         * Copyright 2017 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ class v {
          constructor() {
            (this.reject = () => {}),
              (this.resolve = () => {}),
              (this.promise = new Promise((e, t) => {
                (this.resolve = e), (this.reject = t);
              }));
          }
          wrapCallback(e) {
            return (t, n) => {
              t ? this.reject(t) : this.resolve(n),
                "function" == typeof e &&
                  (this.promise.catch(() => {}),
                  1 === e.length ? e(t) : e(t, n));
            };
          }
        }
        /**
         * @license
         * Copyright 2017 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ function y() {
          return "undefined" != typeof navigator &&
            "string" == typeof navigator.userAgent
            ? navigator.userAgent
            : "";
        }
        function w() {
          return (
            "undefined" != typeof window &&
            !!(window.cordova || window.phonegap || window.PhoneGap) &&
            /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(y())
          );
        }
        function E() {
          let e =
            "object" == typeof chrome
              ? chrome.runtime
              : "object" == typeof browser
              ? browser.runtime
              : void 0;
          return "object" == typeof e && void 0 !== e.id;
        }
        function _() {
          return (
            "object" == typeof navigator && "ReactNative" === navigator.product
          );
        }
        function I() {
          let e = y();
          return e.indexOf("MSIE ") >= 0 || e.indexOf("Trident/") >= 0;
        }
        function C() {
          try {
            return "object" == typeof indexedDB;
          } catch (e) {
            return !1;
          }
        }
        function S() {
          return new Promise((e, t) => {
            try {
              let n = !0,
                r = "validate-browser-context-for-indexeddb-analytics-module",
                i = self.indexedDB.open(r);
              (i.onsuccess = () => {
                i.result.close(), n || self.indexedDB.deleteDatabase(r), e(!0);
              }),
                (i.onupgradeneeded = () => {
                  n = !1;
                }),
                (i.onerror = () => {
                  var e;
                  t(
                    (null === (e = i.error) || void 0 === e
                      ? void 0
                      : e.message) || ""
                  );
                });
            } catch (e) {
              t(e);
            }
          });
        }
        class A extends Error {
          constructor(e, t, n) {
            super(t),
              (this.code = e),
              (this.customData = n),
              (this.name = "FirebaseError"),
              Object.setPrototypeOf(this, A.prototype),
              Error.captureStackTrace &&
                Error.captureStackTrace(this, D.prototype.create);
          }
        }
        class D {
          constructor(e, t, n) {
            (this.service = e), (this.serviceName = t), (this.errors = n);
          }
          create(e, ...t) {
            let n = t[0] || {},
              r = `${this.service}/${e}`,
              i = this.errors[e],
              o = i
                ? i.replace(O, (e, t) => {
                    let r = n[t];
                    return null != r ? String(r) : `<${t}?>`;
                  })
                : "Error",
              a = `${this.serviceName}: ${o} (${r}).`,
              s = new A(r, a, n);
            return s;
          }
        }
        let O = /\{\$([^}]+)}/g;
        function L(e) {
          for (let t in e)
            if (Object.prototype.hasOwnProperty.call(e, t)) return !1;
          return !0;
        }
        function B(e) {
          return null !== e && "object" == typeof e;
        }
        /**
         * @license
         * Copyright 2017 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ function P(e) {
          let t = [];
          for (let [n, r] of Object.entries(e))
            Array.isArray(r)
              ? r.forEach((e) => {
                  t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e));
                })
              : t.push(encodeURIComponent(n) + "=" + encodeURIComponent(r));
          return t.length ? "&" + t.join("&") : "";
        }
        function M(e) {
          let t = {},
            n = e.replace(/^\?/, "").split("&");
          return (
            n.forEach((e) => {
              if (e) {
                let [n, r] = e.split("=");
                t[decodeURIComponent(n)] = decodeURIComponent(r);
              }
            }),
            t
          );
        }
        function T(e) {
          let t = e.indexOf("?");
          if (!t) return "";
          let n = e.indexOf("#", t);
          return e.substring(t, n > 0 ? n : void 0);
        }
        function R(e, t) {
          let n = new k(e, t);
          return n.subscribe.bind(n);
        }
        class k {
          constructor(e, t) {
            (this.observers = []),
              (this.unsubscribes = []),
              (this.observerCount = 0),
              (this.task = Promise.resolve()),
              (this.finalized = !1),
              (this.onNoObservers = t),
              this.task
                .then(() => {
                  e(this);
                })
                .catch((e) => {
                  this.error(e);
                });
          }
          next(e) {
            this.forEachObserver((t) => {
              t.next(e);
            });
          }
          error(e) {
            this.forEachObserver((t) => {
              t.error(e);
            }),
              this.close(e);
          }
          complete() {
            this.forEachObserver((e) => {
              e.complete();
            }),
              this.close();
          }
          subscribe(e, t, n) {
            let r;
            if (void 0 === e && void 0 === t && void 0 === n)
              throw Error("Missing Observer.");
            void 0 ===
              (r = !(function (e, t) {
                if ("object" != typeof e || null === e) return !1;
                for (let n of t)
                  if (n in e && "function" == typeof e[n]) return !0;
                return !1;
              })(e, ["next", "error", "complete"])
                ? { next: e, error: t, complete: n }
                : e).next && (r.next = N),
              void 0 === r.error && (r.error = N),
              void 0 === r.complete && (r.complete = N);
            let i = this.unsubscribeOne.bind(this, this.observers.length);
            return (
              this.finalized &&
                this.task.then(() => {
                  try {
                    this.finalError ? r.error(this.finalError) : r.complete();
                  } catch (e) {}
                }),
              this.observers.push(r),
              i
            );
          }
          unsubscribeOne(e) {
            void 0 !== this.observers &&
              void 0 !== this.observers[e] &&
              (delete this.observers[e],
              (this.observerCount -= 1),
              0 === this.observerCount &&
                void 0 !== this.onNoObservers &&
                this.onNoObservers(this));
          }
          forEachObserver(e) {
            if (!this.finalized)
              for (let t = 0; t < this.observers.length; t++)
                this.sendOne(t, e);
          }
          sendOne(e, t) {
            this.task.then(() => {
              if (void 0 !== this.observers && void 0 !== this.observers[e])
                try {
                  t(this.observers[e]);
                } catch (e) {
                  "undefined" != typeof console &&
                    console.error &&
                    console.error(e);
                }
            });
          }
          close(e) {
            this.finalized ||
              ((this.finalized = !0),
              void 0 !== e && (this.finalError = e),
              this.task.then(() => {
                (this.observers = void 0), (this.onNoObservers = void 0);
              }));
          }
        }
        function N() {}
        /**
         * @license
         * Copyright 2021 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ function $(e) {
          return e && e._delegate ? e._delegate : e;
        }
      },
      83454: function (e, t, n) {
        "use strict";
        var r, i;
        e.exports =
          (null == (r = n.g.process) ? void 0 : r.env) &&
          "object" == typeof (null == (i = n.g.process) ? void 0 : i.env)
            ? n.g.process
            : n(77663);
      },
      77663: function (e) {
        !(function () {
          var t = {
              229: function (e) {
                var t,
                  n,
                  r,
                  i = (e.exports = {});
                function o() {
                  throw Error("setTimeout has not been defined");
                }
                function a() {
                  throw Error("clearTimeout has not been defined");
                }
                function s(e) {
                  if (t === setTimeout) return setTimeout(e, 0);
                  if ((t === o || !t) && setTimeout)
                    return (t = setTimeout), setTimeout(e, 0);
                  try {
                    return t(e, 0);
                  } catch (n) {
                    try {
                      return t.call(null, e, 0);
                    } catch (n) {
                      return t.call(this, e, 0);
                    }
                  }
                }
                !(function () {
                  try {
                    t = "function" == typeof setTimeout ? setTimeout : o;
                  } catch (e) {
                    t = o;
                  }
                  try {
                    n = "function" == typeof clearTimeout ? clearTimeout : a;
                  } catch (e) {
                    n = a;
                  }
                })();
                var u = [],
                  c = !1,
                  l = -1;
                function f() {
                  c &&
                    r &&
                    ((c = !1),
                    r.length ? (u = r.concat(u)) : (l = -1),
                    u.length && h());
                }
                function h() {
                  if (!c) {
                    var e = s(f);
                    c = !0;
                    for (var t = u.length; t; ) {
                      for (r = u, u = []; ++l < t; ) r && r[l].run();
                      (l = -1), (t = u.length);
                    }
                    (r = null),
                      (c = !1),
                      (function (e) {
                        if (n === clearTimeout) return clearTimeout(e);
                        if ((n === a || !n) && clearTimeout)
                          return (n = clearTimeout), clearTimeout(e);
                        try {
                          n(e);
                        } catch (t) {
                          try {
                            return n.call(null, e);
                          } catch (t) {
                            return n.call(this, e);
                          }
                        }
                      })(e);
                  }
                }
                function d(e, t) {
                  (this.fun = e), (this.array = t);
                }
                function p() {}
                (i.nextTick = function (e) {
                  var t = Array(arguments.length - 1);
                  if (arguments.length > 1)
                    for (var n = 1; n < arguments.length; n++)
                      t[n - 1] = arguments[n];
                  u.push(new d(e, t)), 1 !== u.length || c || s(h);
                }),
                  (d.prototype.run = function () {
                    this.fun.apply(null, this.array);
                  }),
                  (i.title = "browser"),
                  (i.browser = !0),
                  (i.env = {}),
                  (i.argv = []),
                  (i.version = ""),
                  (i.versions = {}),
                  (i.on = p),
                  (i.addListener = p),
                  (i.once = p),
                  (i.off = p),
                  (i.removeListener = p),
                  (i.removeAllListeners = p),
                  (i.emit = p),
                  (i.prependListener = p),
                  (i.prependOnceListener = p),
                  (i.listeners = function (e) {
                    return [];
                  }),
                  (i.binding = function (e) {
                    throw Error("process.binding is not supported");
                  }),
                  (i.cwd = function () {
                    return "/";
                  }),
                  (i.chdir = function (e) {
                    throw Error("process.chdir is not supported");
                  }),
                  (i.umask = function () {
                    return 0;
                  });
              },
            },
            n = {};
          function r(e) {
            var i = n[e];
            if (void 0 !== i) return i.exports;
            var o = (n[e] = { exports: {} }),
              a = !0;
            try {
              t[e](o, o.exports, r), (a = !1);
            } finally {
              a && delete n[e];
            }
            return o.exports;
          }
          r.ab = "//";
          var i = r(229);
          e.exports = i;
        })();
      },
      25816: function (e, t, n) {
        "use strict";
        let r, i;
        n.d(t, {
          Jn: function () {
            return $;
          },
          qX: function () {
            return T;
          },
          rh: function () {
            return R;
          },
          Xd: function () {
            return M;
          },
          Mq: function () {
            return H;
          },
          ZF: function () {
            return F;
          },
          KN: function () {
            return j;
          },
        });
        var o,
          a = n(8463),
          s = n(53333),
          u = n(74444);
        let c = (e, t) => t.some((t) => e instanceof t),
          l = new WeakMap(),
          f = new WeakMap(),
          h = new WeakMap(),
          d = new WeakMap(),
          p = new WeakMap(),
          g = {
            get(e, t, n) {
              if (e instanceof IDBTransaction) {
                if ("done" === t) return f.get(e);
                if ("objectStoreNames" === t)
                  return e.objectStoreNames || h.get(e);
                if ("store" === t)
                  return n.objectStoreNames[1]
                    ? void 0
                    : n.objectStore(n.objectStoreNames[0]);
              }
              return b(e[t]);
            },
            set: (e, t, n) => ((e[t] = n), !0),
            has: (e, t) =>
              (e instanceof IDBTransaction &&
                ("done" === t || "store" === t)) ||
              t in e,
          };
        function b(e) {
          var t;
          if (e instanceof IDBRequest)
            return (function (e) {
              let t = new Promise((t, n) => {
                let r = () => {
                    e.removeEventListener("success", i),
                      e.removeEventListener("error", o);
                  },
                  i = () => {
                    t(b(e.result)), r();
                  },
                  o = () => {
                    n(e.error), r();
                  };
                e.addEventListener("success", i),
                  e.addEventListener("error", o);
              });
              return (
                t
                  .then((t) => {
                    t instanceof IDBCursor && l.set(t, e);
                  })
                  .catch(() => {}),
                p.set(t, e),
                t
              );
            })(e);
          if (d.has(e)) return d.get(e);
          let n =
            "function" == typeof (t = e)
              ? t !== IDBDatabase.prototype.transaction ||
                "objectStoreNames" in IDBTransaction.prototype
                ? (
                    i ||
                    (i = [
                      IDBCursor.prototype.advance,
                      IDBCursor.prototype.continue,
                      IDBCursor.prototype.continuePrimaryKey,
                    ])
                  ).includes(t)
                  ? function (...e) {
                      return t.apply(m(this), e), b(l.get(this));
                    }
                  : function (...e) {
                      return b(t.apply(m(this), e));
                    }
                : function (e, ...n) {
                    let r = t.call(m(this), e, ...n);
                    return h.set(r, e.sort ? e.sort() : [e]), b(r);
                  }
              : (t instanceof IDBTransaction &&
                  (function (e) {
                    if (f.has(e)) return;
                    let t = new Promise((t, n) => {
                      let r = () => {
                          e.removeEventListener("complete", i),
                            e.removeEventListener("error", o),
                            e.removeEventListener("abort", o);
                        },
                        i = () => {
                          t(), r();
                        },
                        o = () => {
                          n(
                            e.error ||
                              new DOMException("AbortError", "AbortError")
                          ),
                            r();
                        };
                      e.addEventListener("complete", i),
                        e.addEventListener("error", o),
                        e.addEventListener("abort", o);
                    });
                    f.set(e, t);
                  })(t),
                c(
                  t,
                  r ||
                    (r = [
                      IDBDatabase,
                      IDBObjectStore,
                      IDBIndex,
                      IDBCursor,
                      IDBTransaction,
                    ])
                ))
              ? new Proxy(t, g)
              : t;
          return n !== e && (d.set(e, n), p.set(n, e)), n;
        }
        let m = (e) => p.get(e),
          v = ["get", "getKey", "getAll", "getAllKeys", "count"],
          y = ["put", "add", "delete", "clear"],
          w = new Map();
        function E(e, t) {
          if (!(e instanceof IDBDatabase && !(t in e) && "string" == typeof t))
            return;
          if (w.get(t)) return w.get(t);
          let n = t.replace(/FromIndex$/, ""),
            r = t !== n,
            i = y.includes(n);
          if (
            !(n in (r ? IDBIndex : IDBObjectStore).prototype) ||
            !(i || v.includes(n))
          )
            return;
          let o = async function (e, ...t) {
            let o = this.transaction(e, i ? "readwrite" : "readonly"),
              a = o.store;
            return (
              r && (a = a.index(t.shift())),
              (await Promise.all([a[n](...t), i && o.done]))[0]
            );
          };
          return w.set(t, o), o;
        }
        g = {
          ...(o = g),
          get: (e, t, n) => E(e, t) || o.get(e, t, n),
          has: (e, t) => !!E(e, t) || o.has(e, t),
        };
        /**
         * @license
         * Copyright 2019 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ class _ {
          constructor(e) {
            this.container = e;
          }
          getPlatformInfoString() {
            let e = this.container.getProviders();
            return e
              .map((e) => {
                if (
                  !(function (e) {
                    let t = e.getComponent();
                    return (null == t ? void 0 : t.type) === "VERSION";
                  })(e)
                )
                  return null;
                {
                  let t = e.getImmediate();
                  return `${t.library}/${t.version}`;
                }
              })
              .filter((e) => e)
              .join(" ");
          }
        }
        let I = "@firebase/app",
          C = "0.10.2",
          S = new s.Yd("@firebase/app"),
          A = "[DEFAULT]",
          D = {
            [I]: "fire-core",
            "@firebase/app-compat": "fire-core-compat",
            "@firebase/analytics": "fire-analytics",
            "@firebase/analytics-compat": "fire-analytics-compat",
            "@firebase/app-check": "fire-app-check",
            "@firebase/app-check-compat": "fire-app-check-compat",
            "@firebase/auth": "fire-auth",
            "@firebase/auth-compat": "fire-auth-compat",
            "@firebase/database": "fire-rtdb",
            "@firebase/database-compat": "fire-rtdb-compat",
            "@firebase/functions": "fire-fn",
            "@firebase/functions-compat": "fire-fn-compat",
            "@firebase/installations": "fire-iid",
            "@firebase/installations-compat": "fire-iid-compat",
            "@firebase/messaging": "fire-fcm",
            "@firebase/messaging-compat": "fire-fcm-compat",
            "@firebase/performance": "fire-perf",
            "@firebase/performance-compat": "fire-perf-compat",
            "@firebase/remote-config": "fire-rc",
            "@firebase/remote-config-compat": "fire-rc-compat",
            "@firebase/storage": "fire-gcs",
            "@firebase/storage-compat": "fire-gcs-compat",
            "@firebase/firestore": "fire-fst",
            "@firebase/firestore-compat": "fire-fst-compat",
            "fire-js": "fire-js",
            firebase: "fire-js-all",
          },
          O = new Map(),
          L = new Map(),
          B = new Map();
        function P(e, t) {
          try {
            e.container.addComponent(t);
          } catch (n) {
            S.debug(
              `Component ${t.name} failed to register with FirebaseApp ${e.name}`,
              n
            );
          }
        }
        function M(e) {
          let t = e.name;
          if (B.has(t))
            return (
              S.debug(
                `There were multiple attempts to register component ${t}.`
              ),
              !1
            );
          for (let n of (B.set(t, e), O.values())) P(n, e);
          for (let t of L.values()) P(t, e);
          return !0;
        }
        function T(e, t) {
          let n = e.container
            .getProvider("heartbeat")
            .getImmediate({ optional: !0 });
          return n && n.triggerHeartbeat(), e.container.getProvider(t);
        }
        function R(e) {
          return void 0 !== e.settings;
        }
        let k = new u.LL("app", "Firebase", {
          "no-app":
            "No Firebase App '{$appName}' has been created - call initializeApp() first",
          "bad-app-name": "Illegal App name: '{$appName}'",
          "duplicate-app":
            "Firebase App named '{$appName}' already exists with different options or config",
          "app-deleted": "Firebase App named '{$appName}' already deleted",
          "server-app-deleted": "Firebase Server App has been deleted",
          "no-options":
            "Need to provide options, when not being deployed to hosting via source.",
          "invalid-app-argument":
            "firebase.{$appName}() takes either no argument or a Firebase App instance.",
          "invalid-log-argument":
            "First argument to `onLog` must be null or a function.",
          "idb-open":
            "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
          "idb-get":
            "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
          "idb-set":
            "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
          "idb-delete":
            "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
          "finalization-registry-not-supported":
            "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
          "invalid-server-app-environment":
            "FirebaseServerApp is not for use in browser environments.",
        });
        /**
         * @license
         * Copyright 2019 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ class N {
          constructor(e, t, n) {
            (this._isDeleted = !1),
              (this._options = Object.assign({}, e)),
              (this._config = Object.assign({}, t)),
              (this._name = t.name),
              (this._automaticDataCollectionEnabled =
                t.automaticDataCollectionEnabled),
              (this._container = n),
              this.container.addComponent(
                new a.wA("app", () => this, "PUBLIC")
              );
          }
          get automaticDataCollectionEnabled() {
            return this.checkDestroyed(), this._automaticDataCollectionEnabled;
          }
          set automaticDataCollectionEnabled(e) {
            this.checkDestroyed(), (this._automaticDataCollectionEnabled = e);
          }
          get name() {
            return this.checkDestroyed(), this._name;
          }
          get options() {
            return this.checkDestroyed(), this._options;
          }
          get config() {
            return this.checkDestroyed(), this._config;
          }
          get container() {
            return this._container;
          }
          get isDeleted() {
            return this._isDeleted;
          }
          set isDeleted(e) {
            this._isDeleted = e;
          }
          checkDestroyed() {
            if (this.isDeleted)
              throw k.create("app-deleted", { appName: this._name });
          }
        }
        /**
         * @license
         * Copyright 2019 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ let $ = "10.11.1";
        function F(e, t = {}) {
          let n = e;
          if ("object" != typeof t) {
            let e = t;
            t = { name: e };
          }
          let r = Object.assign(
              { name: A, automaticDataCollectionEnabled: !1 },
              t
            ),
            i = r.name;
          if ("string" != typeof i || !i)
            throw k.create("bad-app-name", { appName: String(i) });
          if ((n || (n = (0, u.aH)()), !n)) throw k.create("no-options");
          let o = O.get(i);
          if (o) {
            if ((0, u.vZ)(n, o.options) && (0, u.vZ)(r, o.config)) return o;
            throw k.create("duplicate-app", { appName: i });
          }
          let s = new a.H0(i);
          for (let e of B.values()) s.addComponent(e);
          let c = new N(n, r, s);
          return O.set(i, c), c;
        }
        function H(e = A) {
          let t = O.get(e);
          if (!t && e === A && (0, u.aH)()) return F();
          if (!t) throw k.create("no-app", { appName: e });
          return t;
        }
        function j(e, t, n) {
          var r;
          let i = null !== (r = D[e]) && void 0 !== r ? r : e;
          n && (i += `-${n}`);
          let o = i.match(/\s|\//),
            s = t.match(/\s|\//);
          if (o || s) {
            let e = [`Unable to register library "${i}" with version "${t}":`];
            o &&
              e.push(
                `library name "${i}" contains illegal characters (whitespace or "/")`
              ),
              o && s && e.push("and"),
              s &&
                e.push(
                  `version name "${t}" contains illegal characters (whitespace or "/")`
                ),
              S.warn(e.join(" "));
            return;
          }
          M(
            new a.wA(
              `${i}-version`,
              () => ({ library: i, version: t }),
              "VERSION"
            )
          );
        }
        let x = "firebase-heartbeat-store",
          W = null;
        function V() {
          return (
            W ||
              (W = (function (
                e,
                t,
                { blocked: n, upgrade: r, blocking: i, terminated: o } = {}
              ) {
                let a = indexedDB.open(e, 1),
                  s = b(a);
                return (
                  r &&
                    a.addEventListener("upgradeneeded", (e) => {
                      r(
                        b(a.result),
                        e.oldVersion,
                        e.newVersion,
                        b(a.transaction),
                        e
                      );
                    }),
                  n &&
                    a.addEventListener("blocked", (e) =>
                      n(e.oldVersion, e.newVersion, e)
                    ),
                  s
                    .then((e) => {
                      o && e.addEventListener("close", () => o()),
                        i &&
                          e.addEventListener("versionchange", (e) =>
                            i(e.oldVersion, e.newVersion, e)
                          );
                    })
                    .catch(() => {}),
                  s
                );
              })("firebase-heartbeat-database", 0, {
                upgrade: (e, t) => {
                  if (0 === t)
                    try {
                      e.createObjectStore(x);
                    } catch (e) {
                      console.warn(e);
                    }
                },
              }).catch((e) => {
                throw k.create("idb-open", { originalErrorMessage: e.message });
              })),
            W
          );
        }
        async function U(e) {
          try {
            let t = await V(),
              n = t.transaction(x),
              r = await n.objectStore(x).get(G(e));
            return await n.done, r;
          } catch (e) {
            if (e instanceof u.ZR) S.warn(e.message);
            else {
              let t = k.create("idb-get", {
                originalErrorMessage: null == e ? void 0 : e.message,
              });
              S.warn(t.message);
            }
          }
        }
        async function z(e, t) {
          try {
            let n = await V(),
              r = n.transaction(x, "readwrite"),
              i = r.objectStore(x);
            await i.put(t, G(e)), await r.done;
          } catch (e) {
            if (e instanceof u.ZR) S.warn(e.message);
            else {
              let t = k.create("idb-set", {
                originalErrorMessage: null == e ? void 0 : e.message,
              });
              S.warn(t.message);
            }
          }
        }
        function G(e) {
          return `${e.name}!${e.options.appId}`;
        }
        class J {
          constructor(e) {
            (this.container = e), (this._heartbeatsCache = null);
            let t = this.container.getProvider("app").getImmediate();
            (this._storage = new q(t)),
              (this._heartbeatsCachePromise = this._storage
                .read()
                .then((e) => ((this._heartbeatsCache = e), e)));
          }
          async triggerHeartbeat() {
            var e, t;
            let n = this.container
                .getProvider("platform-logger")
                .getImmediate(),
              r = n.getPlatformInfoString(),
              i = X();
            return (null === (e = this._heartbeatsCache) || void 0 === e
              ? void 0
              : e.heartbeats) == null &&
              ((this._heartbeatsCache = await this._heartbeatsCachePromise),
              (null === (t = this._heartbeatsCache) || void 0 === t
                ? void 0
                : t.heartbeats) == null)
              ? void 0
              : this._heartbeatsCache.lastSentHeartbeatDate === i ||
                this._heartbeatsCache.heartbeats.some((e) => e.date === i)
              ? void 0
              : (this._heartbeatsCache.heartbeats.push({ date: i, agent: r }),
                (this._heartbeatsCache.heartbeats =
                  this._heartbeatsCache.heartbeats.filter((e) => {
                    let t = new Date(e.date).valueOf(),
                      n = Date.now();
                    return n - t <= 2592e6;
                  })),
                this._storage.overwrite(this._heartbeatsCache));
          }
          async getHeartbeatsHeader() {
            var e;
            if (
              (null === this._heartbeatsCache &&
                (await this._heartbeatsCachePromise),
              (null === (e = this._heartbeatsCache) || void 0 === e
                ? void 0
                : e.heartbeats) == null ||
                0 === this._heartbeatsCache.heartbeats.length)
            )
              return "";
            let t = X(),
              { heartbeatsToSend: n, unsentEntries: r } = (function (
                e,
                t = 1024
              ) {
                let n = [],
                  r = e.slice();
                for (let i of e) {
                  let e = n.find((e) => e.agent === i.agent);
                  if (e) {
                    if ((e.dates.push(i.date), Z(n) > t)) {
                      e.dates.pop();
                      break;
                    }
                  } else if (
                    (n.push({ agent: i.agent, dates: [i.date] }), Z(n) > t)
                  ) {
                    n.pop();
                    break;
                  }
                  r = r.slice(1);
                }
                return { heartbeatsToSend: n, unsentEntries: r };
              })(this._heartbeatsCache.heartbeats),
              i = (0, u.L)(JSON.stringify({ version: 2, heartbeats: n }));
            return (
              (this._heartbeatsCache.lastSentHeartbeatDate = t),
              r.length > 0
                ? ((this._heartbeatsCache.heartbeats = r),
                  await this._storage.overwrite(this._heartbeatsCache))
                : ((this._heartbeatsCache.heartbeats = []),
                  this._storage.overwrite(this._heartbeatsCache)),
              i
            );
          }
        }
        function X() {
          let e = new Date();
          return e.toISOString().substring(0, 10);
        }
        class q {
          constructor(e) {
            (this.app = e),
              (this._canUseIndexedDBPromise =
                this.runIndexedDBEnvironmentCheck());
          }
          async runIndexedDBEnvironmentCheck() {
            return (
              !!(0, u.hl)() &&
              (0, u.eu)()
                .then(() => !0)
                .catch(() => !1)
            );
          }
          async read() {
            let e = await this._canUseIndexedDBPromise;
            if (!e) return { heartbeats: [] };
            {
              let e = await U(this.app);
              return (null == e ? void 0 : e.heartbeats)
                ? e
                : { heartbeats: [] };
            }
          }
          async overwrite(e) {
            var t;
            let n = await this._canUseIndexedDBPromise;
            if (n) {
              let n = await this.read();
              return z(this.app, {
                lastSentHeartbeatDate:
                  null !== (t = e.lastSentHeartbeatDate) && void 0 !== t
                    ? t
                    : n.lastSentHeartbeatDate,
                heartbeats: e.heartbeats,
              });
            }
          }
          async add(e) {
            var t;
            let n = await this._canUseIndexedDBPromise;
            if (n) {
              let n = await this.read();
              return z(this.app, {
                lastSentHeartbeatDate:
                  null !== (t = e.lastSentHeartbeatDate) && void 0 !== t
                    ? t
                    : n.lastSentHeartbeatDate,
                heartbeats: [...n.heartbeats, ...e.heartbeats],
              });
            }
          }
        }
        function Z(e) {
          return (0, u.L)(JSON.stringify({ version: 2, heartbeats: e })).length;
        }
        M(new a.wA("platform-logger", (e) => new _(e), "PRIVATE")),
          M(new a.wA("heartbeat", (e) => new J(e), "PRIVATE")),
          j(I, C, ""),
          j(I, C, "esm2017"),
          j("fire-js", "");
      },
      9455: function (e, t, n) {
        "use strict";
        n.d(t, {
          _T: function () {
            return r;
          },
        });
        function r(e, t) {
          var n = {};
          for (var r in e)
            Object.prototype.hasOwnProperty.call(e, r) &&
              0 > t.indexOf(r) &&
              (n[r] = e[r]);
          if (null != e && "function" == typeof Object.getOwnPropertySymbols)
            for (
              var i = 0, r = Object.getOwnPropertySymbols(e);
              i < r.length;
              i++
            )
              0 > t.indexOf(r[i]) &&
                Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
                (n[r[i]] = e[r[i]]);
          return n;
        }
        "function" == typeof SuppressedError && SuppressedError;
      },
      8463: function (e, t, n) {
        "use strict";
        n.d(t, {
          H0: function () {
            return s;
          },
          wA: function () {
            return i;
          },
        });
        var r = n(74444);
        class i {
          constructor(e, t, n) {
            (this.name = e),
              (this.instanceFactory = t),
              (this.type = n),
              (this.multipleInstances = !1),
              (this.serviceProps = {}),
              (this.instantiationMode = "LAZY"),
              (this.onInstanceCreated = null);
          }
          setInstantiationMode(e) {
            return (this.instantiationMode = e), this;
          }
          setMultipleInstances(e) {
            return (this.multipleInstances = e), this;
          }
          setServiceProps(e) {
            return (this.serviceProps = e), this;
          }
          setInstanceCreatedCallback(e) {
            return (this.onInstanceCreated = e), this;
          }
        }
        /**
         * @license
         * Copyright 2019 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ let o = "[DEFAULT]";
        /**
         * @license
         * Copyright 2019 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ class a {
          constructor(e, t) {
            (this.name = e),
              (this.container = t),
              (this.component = null),
              (this.instances = new Map()),
              (this.instancesDeferred = new Map()),
              (this.instancesOptions = new Map()),
              (this.onInitCallbacks = new Map());
          }
          get(e) {
            let t = this.normalizeInstanceIdentifier(e);
            if (!this.instancesDeferred.has(t)) {
              let e = new r.BH();
              if (
                (this.instancesDeferred.set(t, e),
                this.isInitialized(t) || this.shouldAutoInitialize())
              )
                try {
                  let n = this.getOrInitializeService({
                    instanceIdentifier: t,
                  });
                  n && e.resolve(n);
                } catch (e) {}
            }
            return this.instancesDeferred.get(t).promise;
          }
          getImmediate(e) {
            var t;
            let n = this.normalizeInstanceIdentifier(
                null == e ? void 0 : e.identifier
              ),
              r =
                null !== (t = null == e ? void 0 : e.optional) &&
                void 0 !== t &&
                t;
            if (this.isInitialized(n) || this.shouldAutoInitialize())
              try {
                return this.getOrInitializeService({ instanceIdentifier: n });
              } catch (e) {
                if (r) return null;
                throw e;
              }
            else {
              if (r) return null;
              throw Error(`Service ${this.name} is not available`);
            }
          }
          getComponent() {
            return this.component;
          }
          setComponent(e) {
            if (e.name !== this.name)
              throw Error(
                `Mismatching Component ${e.name} for Provider ${this.name}.`
              );
            if (this.component)
              throw Error(
                `Component for ${this.name} has already been provided`
              );
            if (((this.component = e), this.shouldAutoInitialize())) {
              if ("EAGER" === e.instantiationMode)
                try {
                  this.getOrInitializeService({ instanceIdentifier: o });
                } catch (e) {}
              for (let [e, t] of this.instancesDeferred.entries()) {
                let n = this.normalizeInstanceIdentifier(e);
                try {
                  let e = this.getOrInitializeService({
                    instanceIdentifier: n,
                  });
                  t.resolve(e);
                } catch (e) {}
              }
            }
          }
          clearInstance(e = o) {
            this.instancesDeferred.delete(e),
              this.instancesOptions.delete(e),
              this.instances.delete(e);
          }
          async delete() {
            let e = Array.from(this.instances.values());
            await Promise.all([
              ...e
                .filter((e) => "INTERNAL" in e)
                .map((e) => e.INTERNAL.delete()),
              ...e.filter((e) => "_delete" in e).map((e) => e._delete()),
            ]);
          }
          isComponentSet() {
            return null != this.component;
          }
          isInitialized(e = o) {
            return this.instances.has(e);
          }
          getOptions(e = o) {
            return this.instancesOptions.get(e) || {};
          }
          initialize(e = {}) {
            let { options: t = {} } = e,
              n = this.normalizeInstanceIdentifier(e.instanceIdentifier);
            if (this.isInitialized(n))
              throw Error(`${this.name}(${n}) has already been initialized`);
            if (!this.isComponentSet())
              throw Error(`Component ${this.name} has not been registered yet`);
            let r = this.getOrInitializeService({
              instanceIdentifier: n,
              options: t,
            });
            for (let [e, t] of this.instancesDeferred.entries()) {
              let i = this.normalizeInstanceIdentifier(e);
              n === i && t.resolve(r);
            }
            return r;
          }
          onInit(e, t) {
            var n;
            let r = this.normalizeInstanceIdentifier(t),
              i =
                null !== (n = this.onInitCallbacks.get(r)) && void 0 !== n
                  ? n
                  : new Set();
            i.add(e), this.onInitCallbacks.set(r, i);
            let o = this.instances.get(r);
            return (
              o && e(o, r),
              () => {
                i.delete(e);
              }
            );
          }
          invokeOnInitCallbacks(e, t) {
            let n = this.onInitCallbacks.get(t);
            if (n)
              for (let r of n)
                try {
                  r(e, t);
                } catch (e) {}
          }
          getOrInitializeService({ instanceIdentifier: e, options: t = {} }) {
            let n = this.instances.get(e);
            if (
              !n &&
              this.component &&
              ((n = this.component.instanceFactory(this.container, {
                instanceIdentifier: e === o ? void 0 : e,
                options: t,
              })),
              this.instances.set(e, n),
              this.instancesOptions.set(e, t),
              this.invokeOnInitCallbacks(n, e),
              this.component.onInstanceCreated)
            )
              try {
                this.component.onInstanceCreated(this.container, e, n);
              } catch (e) {}
            return n || null;
          }
          normalizeInstanceIdentifier(e = o) {
            return this.component
              ? this.component.multipleInstances
                ? e
                : o
              : e;
          }
          shouldAutoInitialize() {
            return (
              !!this.component &&
              "EXPLICIT" !== this.component.instantiationMode
            );
          }
        }
        /**
         * @license
         * Copyright 2019 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ class s {
          constructor(e) {
            (this.name = e), (this.providers = new Map());
          }
          addComponent(e) {
            let t = this.getProvider(e.name);
            if (t.isComponentSet())
              throw Error(
                `Component ${e.name} has already been registered with ${this.name}`
              );
            t.setComponent(e);
          }
          addOrOverwriteComponent(e) {
            let t = this.getProvider(e.name);
            t.isComponentSet() && this.providers.delete(e.name),
              this.addComponent(e);
          }
          getProvider(e) {
            if (this.providers.has(e)) return this.providers.get(e);
            let t = new a(e, this);
            return this.providers.set(e, t), t;
          }
          getProviders() {
            return Array.from(this.providers.values());
          }
        }
      },
      53333: function (e, t, n) {
        "use strict";
        var r, i;
        n.d(t, {
          Yd: function () {
            return l;
          },
          in: function () {
            return r;
          },
        });
        /**
         * @license
         * Copyright 2017 Google LLC
         *
         * Licensed under the Apache License, Version 2.0 (the "License");
         * you may not use this file except in compliance with the License.
         * You may obtain a copy of the License at
         *
         *   http://www.apache.org/licenses/LICENSE-2.0
         *
         * Unless required by applicable law or agreed to in writing, software
         * distributed under the License is distributed on an "AS IS" BASIS,
         * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
         * See the License for the specific language governing permissions and
         * limitations under the License.
         */ let o = [];
        ((i = r || (r = {}))[(i.DEBUG = 0)] = "DEBUG"),
          (i[(i.VERBOSE = 1)] = "VERBOSE"),
          (i[(i.INFO = 2)] = "INFO"),
          (i[(i.WARN = 3)] = "WARN"),
          (i[(i.ERROR = 4)] = "ERROR"),
          (i[(i.SILENT = 5)] = "SILENT");
        let a = {
            debug: r.DEBUG,
            verbose: r.VERBOSE,
            info: r.INFO,
            warn: r.WARN,
            error: r.ERROR,
            silent: r.SILENT,
          },
          s = r.INFO,
          u = {
            [r.DEBUG]: "log",
            [r.VERBOSE]: "log",
            [r.INFO]: "info",
            [r.WARN]: "warn",
            [r.ERROR]: "error",
          },
          c = (e, t, ...n) => {
            if (t < e.logLevel) return;
            let r = new Date().toISOString(),
              i = u[t];
            if (i) console[i](`[${r}]  ${e.name}:`, ...n);
            else
              throw Error(
                `Attempted to log a message with an invalid logType (value: ${t})`
              );
          };
        class l {
          constructor(e) {
            (this.name = e),
              (this._logLevel = s),
              (this._logHandler = c),
              (this._userLogHandler = null),
              o.push(this);
          }
          get logLevel() {
            return this._logLevel;
          }
          set logLevel(e) {
            if (!(e in r))
              throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);
            this._logLevel = e;
          }
          setLogLevel(e) {
            this._logLevel = "string" == typeof e ? a[e] : e;
          }
          get logHandler() {
            return this._logHandler;
          }
          set logHandler(e) {
            if ("function" != typeof e)
              throw TypeError(
                "Value assigned to `logHandler` must be a function"
              );
            this._logHandler = e;
          }
          get userLogHandler() {
            return this._userLogHandler;
          }
          set userLogHandler(e) {
            this._userLogHandler = e;
          }
          debug(...e) {
            this._userLogHandler && this._userLogHandler(this, r.DEBUG, ...e),
              this._logHandler(this, r.DEBUG, ...e);
          }
          log(...e) {
            this._userLogHandler && this._userLogHandler(this, r.VERBOSE, ...e),
              this._logHandler(this, r.VERBOSE, ...e);
          }
          info(...e) {
            this._userLogHandler && this._userLogHandler(this, r.INFO, ...e),
              this._logHandler(this, r.INFO, ...e);
          }
          warn(...e) {
            this._userLogHandler && this._userLogHandler(this, r.WARN, ...e),
              this._logHandler(this, r.WARN, ...e);
          }
          error(...e) {
            this._userLogHandler && this._userLogHandler(this, r.ERROR, ...e),
              this._logHandler(this, r.ERROR, ...e);
          }
        }
      },
      74864: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            ActionCodeOperation: function () {
              return r.Bs;
            },
            ActionCodeURL: function () {
              return r.ne;
            },
            AuthCredential: function () {
              return r.A$;
            },
            AuthErrorCodes: function () {
              return r.kq;
            },
            EmailAuthCredential: function () {
              return r.MI;
            },
            EmailAuthProvider: function () {
              return r.w9;
            },
            FacebookAuthProvider: function () {
              return r._O;
            },
            FactorId: function () {
              return r.jX;
            },
            GithubAuthProvider: function () {
              return r.GH;
            },
            GoogleAuthProvider: function () {
              return r.hJ;
            },
            OAuthCredential: function () {
              return r.jh;
            },
            OAuthProvider: function () {
              return r.O4;
            },
            OperationType: function () {
              return r.C8;
            },
            PhoneAuthCredential: function () {
              return r.mP;
            },
            PhoneAuthProvider: function () {
              return r.RO;
            },
            PhoneMultiFactorGenerator: function () {
              return r.ww;
            },
            ProviderId: function () {
              return r.F7;
            },
            RecaptchaVerifier: function () {
              return r.lI;
            },
            SAMLAuthProvider: function () {
              return r.VE;
            },
            SignInMethod: function () {
              return r.RF;
            },
            TotpMultiFactorGenerator: function () {
              return r.SP;
            },
            TotpSecret: function () {
              return r.Jw;
            },
            TwitterAuthProvider: function () {
              return r.c4;
            },
            applyActionCode: function () {
              return r.iA;
            },
            beforeAuthStateChanged: function () {
              return r.qh;
            },
            browserLocalPersistence: function () {
              return r.a$;
            },
            browserPopupRedirectResolver: function () {
              return r.n0;
            },
            browserSessionPersistence: function () {
              return r.aT;
            },
            checkActionCode: function () {
              return r.bX;
            },
            confirmPasswordReset: function () {
              return r.LG;
            },
            connectAuthEmulator: function () {
              return r.S$;
            },
            createUserWithEmailAndPassword: function () {
              return r.Xb;
            },
            debugErrorMap: function () {
              return r.H0;
            },
            deleteUser: function () {
              return r.h8;
            },
            fetchSignInMethodsForEmail: function () {
              return r.Nr;
            },
            getAdditionalUserInfo: function () {
              return r.gK;
            },
            getAuth: function () {
              return r.v0;
            },
            getIdToken: function () {
              return r.wU;
            },
            getIdTokenResult: function () {
              return r.ag;
            },
            getMultiFactorResolver: function () {
              return r.p2;
            },
            getRedirectResult: function () {
              return r.cx;
            },
            inMemoryPersistence: function () {
              return r.BV;
            },
            indexedDBLocalPersistence: function () {
              return r.AP;
            },
            initializeAuth: function () {
              return r.uJ;
            },
            initializeRecaptchaConfig: function () {
              return r.RL;
            },
            isSignInWithEmailLink: function () {
              return r.JB;
            },
            linkWithCredential: function () {
              return r.ZJ;
            },
            linkWithPhoneNumber: function () {
              return r.L6;
            },
            linkWithPopup: function () {
              return r.k9;
            },
            linkWithRedirect: function () {
              return r.WV;
            },
            multiFactor: function () {
              return r.JG;
            },
            onAuthStateChanged: function () {
              return r.Aj;
            },
            onIdTokenChanged: function () {
              return r.MX;
            },
            parseActionCodeURL: function () {
              return r.uw;
            },
            prodErrorMap: function () {
              return r.bu;
            },
            reauthenticateWithCredential: function () {
              return r.aF;
            },
            reauthenticateWithPhoneNumber: function () {
              return r.vY;
            },
            reauthenticateWithPopup: function () {
              return r.bc;
            },
            reauthenticateWithRedirect: function () {
              return r.C3;
            },
            reload: function () {
              return r.H5;
            },
            revokeAccessToken: function () {
              return r.h6;
            },
            sendEmailVerification: function () {
              return r.w$;
            },
            sendPasswordResetEmail: function () {
              return r.LS;
            },
            sendSignInLinkToEmail: function () {
              return r.oo;
            },
            setPersistence: function () {
              return r.Fb;
            },
            signInAnonymously: function () {
              return r.XB;
            },
            signInWithCredential: function () {
              return r.sB;
            },
            signInWithCustomToken: function () {
              return r._p;
            },
            signInWithEmailAndPassword: function () {
              return r.e5;
            },
            signInWithEmailLink: function () {
              return r.P6;
            },
            signInWithPhoneNumber: function () {
              return r.$g;
            },
            signInWithPopup: function () {
              return r.rh;
            },
            signInWithRedirect: function () {
              return r.F6;
            },
            signOut: function () {
              return r.w7;
            },
            unlink: function () {
              return r.qB;
            },
            updateCurrentUser: function () {
              return r.SF;
            },
            updateEmail: function () {
              return r.s;
            },
            updatePassword: function () {
              return r.gQ;
            },
            updatePhoneNumber: function () {
              return r.Rv;
            },
            updateProfile: function () {
              return r.ck;
            },
            useDeviceLanguage: function () {
              return r.ic;
            },
            validatePassword: function () {
              return r.uo;
            },
            verifyBeforeUpdateEmail: function () {
              return r.Ov;
            },
            verifyPasswordResetCode: function () {
              return r.TX;
            },
          });
        var r = n(47210);
      },
    },
  ]);
