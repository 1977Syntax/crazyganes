!(function () {
  try {
    var t =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      e = new t.Error().stack;
    e &&
      ((t._sentryDebugIds = t._sentryDebugIds || {}),
      (t._sentryDebugIds[e] = "503a5fd1-d391-41df-bb35-3f4dd5d8cb62"),
      (t._sentryDebugIdIdentifier =
        "sentry-dbid-503a5fd1-d391-41df-bb35-3f4dd5d8cb62"));
  } catch (t) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [39424],
    {
      60811: function (t, e, n) {
        n.d(e, {
          G: function () {
            return d;
          },
        });
        var r = n(13533),
          i = n(43927),
          s = n(33280),
          o = n(24925);
        class u {
          constructor(t, e) {
            let n, r;
            (n = t || new i.s()),
              (r = e || new i.s()),
              (this._stack = [{ scope: n }]),
              (this._isolationScope = r);
          }
          withScope(t) {
            let e;
            let n = this._pushScope();
            try {
              e = t(n);
            } catch (t) {
              throw (this._popScope(), t);
            }
            return (0, o.J8)(e)
              ? e.then(
                  (t) => (this._popScope(), t),
                  (t) => {
                    throw (this._popScope(), t);
                  }
                )
              : (this._popScope(), e);
          }
          getClient() {
            return this.getStackTop().client;
          }
          getScope() {
            return this.getStackTop().scope;
          }
          getIsolationScope() {
            return this._isolationScope;
          }
          getStackTop() {
            return this._stack[this._stack.length - 1];
          }
          _pushScope() {
            let t = this.getScope().clone();
            return this._stack.push({ client: this.getClient(), scope: t }), t;
          }
          _popScope() {
            return !(this._stack.length <= 1) && !!this._stack.pop();
          }
        }
        function a() {
          let t = (0, r.c)(),
            e = (0, r.q)(t);
          return (e.stack =
            e.stack ||
            new u(
              (0, s.Y)("defaultCurrentScope", () => new i.s()),
              (0, s.Y)("defaultIsolationScope", () => new i.s())
            ));
        }
        function c(t) {
          return a().withScope(t);
        }
        function f(t, e) {
          let n = a();
          return n.withScope(() => ((n.getStackTop().scope = t), e(t)));
        }
        function l(t) {
          return a().withScope(() => t(a().getIsolationScope()));
        }
        function d(t) {
          let e = (0, r.q)(t);
          return e.acs
            ? e.acs
            : {
                withIsolationScope: l,
                withScope: c,
                withSetScope: f,
                withSetIsolationScope: (t, e) => l(e),
                getCurrentScope: () => a().getScope(),
                getIsolationScope: () => a().getIsolationScope(),
              };
        }
      },
      13533: function (t, e, n) {
        n.d(e, {
          c: function () {
            return s;
          },
          q: function () {
            return o;
          },
        });
        var r = n(49889),
          i = n(33280);
        function s() {
          return o(i.n), i.n;
        }
        function o(t) {
          let e = (t.__SENTRY__ = t.__SENTRY__ || {});
          return (e.version = e.version || r.J), (e[r.J] = e[r.J] || {});
        }
      },
      73243: function (t, e, n) {
        n.d(e, {
          J: function () {
            return r;
          },
        });
        let r = "production";
      },
      26318: function (t, e, n) {
        n.d(e, {
          $e: function () {
            return l;
          },
          XX: function () {
            return h;
          },
          aF: function () {
            return c;
          },
          lW: function () {
            return f;
          },
          nZ: function () {
            return a;
          },
          s3: function () {
            return p;
          },
          wi: function () {
            return d;
          },
        });
        var r = n(60811),
          i = n(13533),
          s = n(43927),
          o = n(51150),
          u = n(33280);
        function a() {
          let t = (0, i.c)(),
            e = (0, r.G)(t);
          return e.getCurrentScope();
        }
        function c() {
          let t = (0, i.c)(),
            e = (0, r.G)(t);
          return e.getIsolationScope();
        }
        function f() {
          return (0, u.Y)("globalScope", () => new s.s());
        }
        function l(...t) {
          let e = (0, i.c)(),
            n = (0, r.G)(e);
          if (2 === t.length) {
            let [e, r] = t;
            return e ? n.withSetScope(e, r) : n.withScope(r);
          }
          return n.withScope(t[0]);
        }
        function d(...t) {
          let e = (0, i.c)(),
            n = (0, r.G)(e);
          if (2 === t.length) {
            let [e, r] = t;
            return e ? n.withSetIsolationScope(e, r) : n.withIsolationScope(r);
          }
          return n.withIsolationScope(t[0]);
        }
        function p() {
          return a().getClient();
        }
        function h(t) {
          let e = t.getPropagationContext(),
            { traceId: n, spanId: r, parentSpanId: i } = e,
            s = (0, o.Jr)({ trace_id: n, span_id: r, parent_span_id: i });
          return s;
        }
      },
      94223: function (t, e, n) {
        n.d(e, {
          X: function () {
            return r;
          },
        });
        let r = !1;
      },
      39424: function (t, e, n) {
        n.d(e, {
          Qy: function () {
            return M;
          },
          TM: function () {
            return C;
          },
          Tb: function () {
            return l;
          },
          YA: function () {
            return y;
          },
          _k: function () {
            return w;
          },
          av: function () {
            return v;
          },
          c: function () {
            return x;
          },
          cg: function () {
            return j;
          },
          dk: function () {
            return k;
          },
          eN: function () {
            return p;
          },
          eW: function () {
            return b;
          },
          mG: function () {
            return m;
          },
          rJ: function () {
            return _;
          },
          sU: function () {
            return g;
          },
          uT: function () {
            return d;
          },
          v: function () {
            return h;
          },
          xv: function () {
            return E;
          },
          yj: function () {
            return D;
          },
          yl: function () {
            return S;
          },
        });
        var r = n(73243),
          i = n(26318),
          s = n(94223),
          o = n(10042),
          u = n(17986),
          a = n(82305),
          c = n(33280),
          f = n(5808);
        function l(t, e) {
          return (0, i.nZ)().captureException(t, (0, f.U0)(e));
        }
        function d(t, e) {
          return (0, i.nZ)().captureMessage(
            t,
            "string" == typeof e ? e : void 0,
            "string" != typeof e ? { captureContext: e } : void 0
          );
        }
        function p(t, e) {
          return (0, i.nZ)().captureEvent(t, e);
        }
        function h(t, e) {
          (0, i.aF)().setContext(t, e);
        }
        function _(t) {
          (0, i.aF)().setExtras(t);
        }
        function g(t, e) {
          (0, i.aF)().setExtra(t, e);
        }
        function m(t) {
          (0, i.aF)().setTags(t);
        }
        function y(t, e) {
          (0, i.aF)().setTag(t, e);
        }
        function v(t) {
          (0, i.aF)().setUser(t);
        }
        function b() {
          return (0, i.aF)().lastEventId();
        }
        function x(t, e) {
          let n = (0, i.nZ)(),
            r = (0, i.s3)();
          if (r) {
            if (r.captureCheckIn) return r.captureCheckIn(t, e, n);
            s.X &&
              u.kg.warn(
                "Cannot capture check-in. Client does not support sending check-ins."
              );
          } else
            s.X && u.kg.warn("Cannot capture check-in. No client defined.");
          return (0, a.DM)();
        }
        async function S(t) {
          let e = (0, i.s3)();
          return e
            ? e.flush(t)
            : (s.X && u.kg.warn("Cannot flush events. No client defined."),
              Promise.resolve(!1));
        }
        async function E(t) {
          let e = (0, i.s3)();
          return e
            ? e.close(t)
            : (s.X &&
                u.kg.warn(
                  "Cannot flush events and disable SDK. No client defined."
                ),
              Promise.resolve(!1));
        }
        function k() {
          return !!(0, i.s3)();
        }
        function w() {
          let t = (0, i.s3)();
          return !!t && !1 !== t.getOptions().enabled && !!t.getTransport();
        }
        function M(t) {
          (0, i.aF)().addEventProcessor(t);
        }
        function D(t) {
          let e = (0, i.s3)(),
            n = (0, i.aF)(),
            s = (0, i.nZ)(),
            { release: u, environment: a = r.J } = (e && e.getOptions()) || {},
            { userAgent: f } = c.n.navigator || {},
            l = (0, o.Hv)({
              release: u,
              environment: a,
              user: s.getUser() || n.getUser(),
              ...(f && { userAgent: f }),
              ...t,
            }),
            d = n.getSession();
          return (
            d && "ok" === d.status && (0, o.CT)(d, { status: "exited" }),
            C(),
            n.setSession(l),
            s.setSession(l),
            l
          );
        }
        function C() {
          let t = (0, i.aF)(),
            e = (0, i.nZ)(),
            n = e.getSession() || t.getSession();
          n && (0, o.RJ)(n), O(), t.setSession(), e.setSession();
        }
        function O() {
          let t = (0, i.aF)(),
            e = (0, i.nZ)(),
            n = (0, i.s3)(),
            r = e.getSession() || t.getSession();
          r && n && n.captureSession(r);
        }
        function j(t = !1) {
          if (t) {
            C();
            return;
          }
          O();
        }
      },
      72751: function (t, e, n) {
        n.d(e, {
          V: function () {
            return o;
          },
          y: function () {
            return s;
          },
        });
        var r = n(51150);
        let i = "_sentryMetrics";
        function s(t) {
          let e = t[i];
          if (!e) return;
          let n = {};
          for (let [, [t, i]] of e) {
            let e = n[t] || (n[t] = []);
            e.push((0, r.Jr)(i));
          }
          return n;
        }
        function o(t, e, n, r, s, o, u) {
          let a = t[i],
            c = a || (t[i] = new Map()),
            f = `${e}:${n}@${s}`,
            l = c.get(u);
          if (l) {
            let [, t] = l;
            c.set(u, [
              f,
              {
                min: Math.min(t.min, r),
                max: Math.max(t.max, r),
                count: (t.count += 1),
                sum: (t.sum += r),
                tags: t.tags,
              },
            ]);
          } else c.set(u, [f, { min: r, max: r, count: 1, sum: r, tags: o }]);
        }
      },
      43927: function (t, e, n) {
        n.d(e, {
          s: function () {
            return d;
          },
        });
        var r = n(10042),
          i = n(24925),
          s = n(17986),
          o = n(82305),
          u = n(51824),
          a = n(59943),
          c = n(3613),
          f = n(89366);
        class l {
          constructor() {
            (this._notifyingListeners = !1),
              (this._scopeListeners = []),
              (this._eventProcessors = []),
              (this._breadcrumbs = []),
              (this._attachments = []),
              (this._user = {}),
              (this._tags = {}),
              (this._extra = {}),
              (this._contexts = {}),
              (this._sdkProcessingMetadata = {}),
              (this._propagationContext = {
                traceId: (0, u.Ht)(),
                spanId: (0, u.M)(),
              });
          }
          clone() {
            let t = new l();
            return (
              (t._breadcrumbs = [...this._breadcrumbs]),
              (t._tags = { ...this._tags }),
              (t._extra = { ...this._extra }),
              (t._contexts = { ...this._contexts }),
              this._contexts.flags &&
                (t._contexts.flags = {
                  values: [...this._contexts.flags.values],
                }),
              (t._user = this._user),
              (t._level = this._level),
              (t._session = this._session),
              (t._transactionName = this._transactionName),
              (t._fingerprint = this._fingerprint),
              (t._eventProcessors = [...this._eventProcessors]),
              (t._requestSession = this._requestSession),
              (t._attachments = [...this._attachments]),
              (t._sdkProcessingMetadata = { ...this._sdkProcessingMetadata }),
              (t._propagationContext = { ...this._propagationContext }),
              (t._client = this._client),
              (t._lastEventId = this._lastEventId),
              (0, f.D)(t, (0, f.Y)(this)),
              t
            );
          }
          setClient(t) {
            this._client = t;
          }
          setLastEventId(t) {
            this._lastEventId = t;
          }
          getClient() {
            return this._client;
          }
          lastEventId() {
            return this._lastEventId;
          }
          addScopeListener(t) {
            this._scopeListeners.push(t);
          }
          addEventProcessor(t) {
            return this._eventProcessors.push(t), this;
          }
          setUser(t) {
            return (
              (this._user = t || {
                email: void 0,
                id: void 0,
                ip_address: void 0,
                username: void 0,
              }),
              this._session && (0, r.CT)(this._session, { user: t }),
              this._notifyScopeListeners(),
              this
            );
          }
          getUser() {
            return this._user;
          }
          getRequestSession() {
            return this._requestSession;
          }
          setRequestSession(t) {
            return (this._requestSession = t), this;
          }
          setTags(t) {
            return (
              (this._tags = { ...this._tags, ...t }),
              this._notifyScopeListeners(),
              this
            );
          }
          setTag(t, e) {
            return (
              (this._tags = { ...this._tags, [t]: e }),
              this._notifyScopeListeners(),
              this
            );
          }
          setExtras(t) {
            return (
              (this._extra = { ...this._extra, ...t }),
              this._notifyScopeListeners(),
              this
            );
          }
          setExtra(t, e) {
            return (
              (this._extra = { ...this._extra, [t]: e }),
              this._notifyScopeListeners(),
              this
            );
          }
          setFingerprint(t) {
            return (this._fingerprint = t), this._notifyScopeListeners(), this;
          }
          setLevel(t) {
            return (this._level = t), this._notifyScopeListeners(), this;
          }
          setTransactionName(t) {
            return (
              (this._transactionName = t), this._notifyScopeListeners(), this
            );
          }
          setContext(t, e) {
            return (
              null === e ? delete this._contexts[t] : (this._contexts[t] = e),
              this._notifyScopeListeners(),
              this
            );
          }
          setSession(t) {
            return (
              t ? (this._session = t) : delete this._session,
              this._notifyScopeListeners(),
              this
            );
          }
          getSession() {
            return this._session;
          }
          update(t) {
            if (!t) return this;
            let e = "function" == typeof t ? t(this) : t,
              [n, r] =
                e instanceof d
                  ? [e.getScopeData(), e.getRequestSession()]
                  : (0, i.PO)(e)
                  ? [t, t.requestSession]
                  : [],
              {
                tags: s,
                extra: o,
                user: u,
                contexts: a,
                level: c,
                fingerprint: f = [],
                propagationContext: l,
              } = n || {};
            return (
              (this._tags = { ...this._tags, ...s }),
              (this._extra = { ...this._extra, ...o }),
              (this._contexts = { ...this._contexts, ...a }),
              u && Object.keys(u).length && (this._user = u),
              c && (this._level = c),
              f.length && (this._fingerprint = f),
              l && (this._propagationContext = l),
              r && (this._requestSession = r),
              this
            );
          }
          clear() {
            return (
              (this._breadcrumbs = []),
              (this._tags = {}),
              (this._extra = {}),
              (this._user = {}),
              (this._contexts = {}),
              (this._level = void 0),
              (this._transactionName = void 0),
              (this._fingerprint = void 0),
              (this._requestSession = void 0),
              (this._session = void 0),
              (0, f.D)(this, void 0),
              (this._attachments = []),
              this.setPropagationContext({ traceId: (0, u.Ht)() }),
              this._notifyScopeListeners(),
              this
            );
          }
          addBreadcrumb(t, e) {
            let n = "number" == typeof e ? e : 100;
            if (n <= 0) return this;
            let r = { timestamp: (0, a.yW)(), ...t },
              i = this._breadcrumbs;
            return (
              i.push(r),
              (this._breadcrumbs = i.length > n ? i.slice(-n) : i),
              this._notifyScopeListeners(),
              this
            );
          }
          getLastBreadcrumb() {
            return this._breadcrumbs[this._breadcrumbs.length - 1];
          }
          clearBreadcrumbs() {
            return (this._breadcrumbs = []), this._notifyScopeListeners(), this;
          }
          addAttachment(t) {
            return this._attachments.push(t), this;
          }
          clearAttachments() {
            return (this._attachments = []), this;
          }
          getScopeData() {
            return {
              breadcrumbs: this._breadcrumbs,
              attachments: this._attachments,
              contexts: this._contexts,
              tags: this._tags,
              extra: this._extra,
              user: this._user,
              level: this._level,
              fingerprint: this._fingerprint || [],
              eventProcessors: this._eventProcessors,
              propagationContext: this._propagationContext,
              sdkProcessingMetadata: this._sdkProcessingMetadata,
              transactionName: this._transactionName,
              span: (0, f.Y)(this),
            };
          }
          setSDKProcessingMetadata(t) {
            return (
              (this._sdkProcessingMetadata = (0, c.T)(
                this._sdkProcessingMetadata,
                t,
                2
              )),
              this
            );
          }
          setPropagationContext(t) {
            return (
              (this._propagationContext = { spanId: (0, u.M)(), ...t }), this
            );
          }
          getPropagationContext() {
            return this._propagationContext;
          }
          captureException(t, e) {
            let n = e && e.event_id ? e.event_id : (0, o.DM)();
            if (!this._client)
              return (
                s.kg.warn(
                  "No client configured on scope - will not capture exception!"
                ),
                n
              );
            let r = Error("Sentry syntheticException");
            return (
              this._client.captureException(
                t,
                {
                  originalException: t,
                  syntheticException: r,
                  ...e,
                  event_id: n,
                },
                this
              ),
              n
            );
          }
          captureMessage(t, e, n) {
            let r = n && n.event_id ? n.event_id : (0, o.DM)();
            if (!this._client)
              return (
                s.kg.warn(
                  "No client configured on scope - will not capture message!"
                ),
                r
              );
            let i = Error(t);
            return (
              this._client.captureMessage(
                t,
                e,
                {
                  originalException: t,
                  syntheticException: i,
                  ...n,
                  event_id: r,
                },
                this
              ),
              r
            );
          }
          captureEvent(t, e) {
            let n = e && e.event_id ? e.event_id : (0, o.DM)();
            return this._client
              ? (this._client.captureEvent(t, { ...e, event_id: n }, this), n)
              : (s.kg.warn(
                  "No client configured on scope - will not capture event!"
                ),
                n);
          }
          _notifyScopeListeners() {
            this._notifyingListeners ||
              ((this._notifyingListeners = !0),
              this._scopeListeners.forEach((t) => {
                t(this);
              }),
              (this._notifyingListeners = !1));
          }
        }
        let d = l;
      },
      31218: function (t, e, n) {
        n.d(e, {
          $J: function () {
            return s;
          },
          E1: function () {
            return a;
          },
          JQ: function () {
            return l;
          },
          S3: function () {
            return o;
          },
          TE: function () {
            return i;
          },
          Wb: function () {
            return c;
          },
          Zj: function () {
            return r;
          },
          ju: function () {
            return u;
          },
          p6: function () {
            return f;
          },
        });
        let r = "sentry.source",
          i = "sentry.sample_rate",
          s = "sentry.op",
          o = "sentry.origin",
          u = "sentry.idle_span_finish_reason",
          a = "sentry.measurement_unit",
          c = "sentry.measurement_value",
          f = "sentry.profile_id",
          l = "sentry.exclusive_time";
      },
      10042: function (t, e, n) {
        n.d(e, {
          CT: function () {
            return u;
          },
          Hv: function () {
            return o;
          },
          RJ: function () {
            return a;
          },
        });
        var r = n(51150),
          i = n(59943),
          s = n(82305);
        function o(t) {
          let e = (0, i.ph)(),
            n = {
              sid: (0, s.DM)(),
              init: !0,
              timestamp: e,
              started: e,
              duration: 0,
              status: "ok",
              errors: 0,
              ignoreDuration: !1,
              toJSON: () =>
                (0, r.Jr)({
                  sid: `${n.sid}`,
                  init: n.init,
                  started: new Date(1e3 * n.started).toISOString(),
                  timestamp: new Date(1e3 * n.timestamp).toISOString(),
                  status: n.status,
                  errors: n.errors,
                  did:
                    "number" == typeof n.did || "string" == typeof n.did
                      ? `${n.did}`
                      : void 0,
                  duration: n.duration,
                  abnormal_mechanism: n.abnormal_mechanism,
                  attrs: {
                    release: n.release,
                    environment: n.environment,
                    ip_address: n.ipAddress,
                    user_agent: n.userAgent,
                  },
                }),
            };
          return t && u(n, t), n;
        }
        function u(t, e = {}) {
          if (
            (!e.user ||
              (!t.ipAddress &&
                e.user.ip_address &&
                (t.ipAddress = e.user.ip_address),
              t.did ||
                e.did ||
                (t.did = e.user.id || e.user.email || e.user.username)),
            (t.timestamp = e.timestamp || (0, i.ph)()),
            e.abnormal_mechanism &&
              (t.abnormal_mechanism = e.abnormal_mechanism),
            e.ignoreDuration && (t.ignoreDuration = e.ignoreDuration),
            e.sid && (t.sid = 32 === e.sid.length ? e.sid : (0, s.DM)()),
            void 0 !== e.init && (t.init = e.init),
            !t.did && e.did && (t.did = `${e.did}`),
            "number" == typeof e.started && (t.started = e.started),
            t.ignoreDuration)
          )
            t.duration = void 0;
          else if ("number" == typeof e.duration) t.duration = e.duration;
          else {
            let e = t.timestamp - t.started;
            t.duration = e >= 0 ? e : 0;
          }
          e.release && (t.release = e.release),
            e.environment && (t.environment = e.environment),
            !t.ipAddress && e.ipAddress && (t.ipAddress = e.ipAddress),
            !t.userAgent && e.userAgent && (t.userAgent = e.userAgent),
            "number" == typeof e.errors && (t.errors = e.errors),
            e.status && (t.status = e.status);
        }
        function a(t, e) {
          let n = {};
          e
            ? (n = { status: e })
            : "ok" === t.status && (n = { status: "exited" }),
            u(t, n);
        }
      },
      72123: function (t, e, n) {
        n.d(e, {
          CG: function () {
            return p;
          },
          Lh: function () {
            return l;
          },
          jC: function () {
            return h;
          },
          uc: function () {
            return _;
          },
        });
        var r = n(73243),
          i = n(26318),
          s = n(31218),
          o = n(98823),
          u = n(51150),
          a = n(67973),
          c = n(81585);
        let f = "_frozenDsc";
        function l(t, e) {
          (0, u.xp)(t, f, e);
        }
        function d(t, e) {
          let n = e.getOptions(),
            { publicKey: i } = e.getDsn() || {},
            s = (0, u.Jr)({
              environment: n.environment || r.J,
              release: n.release,
              public_key: i,
              trace_id: t,
            });
          return e.emit("createDsc", s), s;
        }
        function p(t, e) {
          let n = e.getPropagationContext();
          return n.dsc || d(n.traceId, t);
        }
        function h(t) {
          let e = (0, i.s3)();
          if (!e) return {};
          let n = (0, c.Gx)(t),
            r = n[f];
          if (r) return r;
          let u = n.spanContext().traceState,
            l = u && u.get("sentry.dsc"),
            p = l && (0, o.EN)(l);
          if (p) return p;
          let h = d(t.spanContext().traceId, e),
            _ = (0, c.XU)(n),
            g = _.data || {},
            m = g[s.TE];
          null != m && (h.sample_rate = `${m}`);
          let y = g[s.Zj],
            v = _.description;
          return (
            "url" !== y && v && (h.transaction = v),
            (0, a.z)() && (h.sampled = String((0, c.Tt)(n))),
            e.emit("createDsc", h, n),
            h
          );
        }
        function _(t) {
          let e = h(t);
          return (0, o.IQ)(e);
        }
      },
      69737: function (t, e, n) {
        n.d(e, {
          OP: function () {
            return i;
          },
          Q0: function () {
            return u;
          },
          ix: function () {
            return o;
          },
          jt: function () {
            return s;
          },
          pq: function () {
            return r;
          },
        });
        let r = 0,
          i = 1,
          s = 2;
        function o(t) {
          if (t < 400 && t >= 100) return { code: i };
          if (t >= 400 && t < 500)
            switch (t) {
              case 401:
                return { code: s, message: "unauthenticated" };
              case 403:
                return { code: s, message: "permission_denied" };
              case 404:
                return { code: s, message: "not_found" };
              case 409:
                return { code: s, message: "already_exists" };
              case 413:
                return { code: s, message: "failed_precondition" };
              case 429:
                return { code: s, message: "resource_exhausted" };
              case 499:
                return { code: s, message: "cancelled" };
              default:
                return { code: s, message: "invalid_argument" };
            }
          if (t >= 500 && t < 600)
            switch (t) {
              case 501:
                return { code: s, message: "unimplemented" };
              case 503:
                return { code: s, message: "unavailable" };
              case 504:
                return { code: s, message: "deadline_exceeded" };
              default:
                return { code: s, message: "internal_error" };
            }
          return { code: s, message: "unknown_error" };
        }
        function u(t, e) {
          t.setAttribute("http.response.status_code", e);
          let n = o(e);
          "unknown_error" !== n.message && t.setStatus(n);
        }
      },
      98823: function (t, e, n) {
        n.d(e, {
          EN: function () {
            return a;
          },
          IQ: function () {
            return c;
          },
          XM: function () {
            return f;
          },
          lq: function () {
            return o;
          },
        });
        var r = n(23187),
          i = n(24925),
          s = n(17986);
        let o = "sentry-",
          u = /^sentry-/;
        function a(t) {
          let e = f(t);
          if (!e) return;
          let n = Object.entries(e).reduce((t, [e, n]) => {
            if (e.match(u)) {
              let r = e.slice(o.length);
              t[r] = n;
            }
            return t;
          }, {});
          return Object.keys(n).length > 0 ? n : void 0;
        }
        function c(t) {
          if (!t) return;
          let e = Object.entries(t).reduce(
            (t, [e, n]) => (n && (t[`${o}${e}`] = n), t),
            {}
          );
          return (function (t) {
            if (0 !== Object.keys(t).length)
              return Object.entries(t).reduce((t, [e, n], i) => {
                let o = `${encodeURIComponent(e)}=${encodeURIComponent(n)}`,
                  u = 0 === i ? o : `${t},${o}`;
                return u.length > 8192
                  ? (r.X &&
                      s.kg.warn(
                        `Not adding key: ${e} with val: ${n} to baggage header due to exceeding baggage size limits.`
                      ),
                    t)
                  : u;
              }, "");
          })(e);
        }
        function f(t) {
          return t && ((0, i.HD)(t) || Array.isArray(t))
            ? Array.isArray(t)
              ? t.reduce((t, e) => {
                  let n = l(e);
                  return (
                    Object.entries(n).forEach(([e, n]) => {
                      t[e] = n;
                    }),
                    t
                  );
                }, {})
              : l(t)
            : void 0;
        }
        function l(t) {
          return t
            .split(",")
            .map((t) => t.split("=").map((t) => decodeURIComponent(t.trim())))
            .reduce((t, [e, n]) => (e && n && (t[e] = n), t), {});
        }
      },
      70428: function (t, e, n) {
        n.d(e, {
          Rt: function () {
            return o;
          },
          iY: function () {
            return c;
          },
          l4: function () {
            return u;
          },
          qT: function () {
            return a;
          },
        });
        var r = n(24925),
          i = n(33280);
        let s = i.n;
        function o(t, e = {}) {
          if (!t) return "<unknown>";
          try {
            let n,
              i = t,
              o = [],
              u = 0,
              a = 0,
              c = Array.isArray(e) ? e : e.keyAttrs,
              f = (!Array.isArray(e) && e.maxStringLength) || 80;
            for (
              ;
              i &&
              u++ < 5 &&
              ((n = (function (t, e) {
                let n = [];
                if (!t || !t.tagName) return "";
                if (s.HTMLElement && t instanceof HTMLElement && t.dataset) {
                  if (t.dataset.sentryComponent)
                    return t.dataset.sentryComponent;
                  if (t.dataset.sentryElement) return t.dataset.sentryElement;
                }
                n.push(t.tagName.toLowerCase());
                let i =
                  e && e.length
                    ? e
                        .filter((e) => t.getAttribute(e))
                        .map((e) => [e, t.getAttribute(e)])
                    : null;
                if (i && i.length)
                  i.forEach((t) => {
                    n.push(`[${t[0]}="${t[1]}"]`);
                  });
                else {
                  t.id && n.push(`#${t.id}`);
                  let e = t.className;
                  if (e && (0, r.HD)(e)) {
                    let t = e.split(/\s+/);
                    for (let e of t) n.push(`.${e}`);
                  }
                }
                for (let e of ["aria-label", "type", "name", "title", "alt"]) {
                  let r = t.getAttribute(e);
                  r && n.push(`[${e}="${r}"]`);
                }
                return n.join("");
              })(i, c)),
              "html" !== n &&
                (!(u > 1) || !(a + 3 * o.length + n.length >= f)));

            )
              o.push(n), (a += n.length), (i = i.parentNode);
            return o.reverse().join(" > ");
          } catch (t) {
            return "<unknown>";
          }
        }
        function u() {
          try {
            return s.document.location.href;
          } catch (t) {
            return "";
          }
        }
        function a(t) {
          return s.document && s.document.querySelector
            ? s.document.querySelector(t)
            : null;
        }
        function c(t) {
          if (!s.HTMLElement) return null;
          let e = t;
          for (let t = 0; t < 5 && e; t++) {
            if (e instanceof HTMLElement) {
              if (e.dataset.sentryComponent) return e.dataset.sentryComponent;
              if (e.dataset.sentryElement) return e.dataset.sentryElement;
            }
            e = e.parentNode;
          }
          return null;
        }
      },
      23187: function (t, e, n) {
        n.d(e, {
          X: function () {
            return r;
          },
        });
        let r = !1;
      },
      62538: function (t, e, n) {
        let r, i, s;
        n.d(e, {
          N: function () {
            return u;
          },
          v: function () {
            return a;
          },
        });
        var o = n(33280);
        function u(t) {
          let e = o.n._sentryDebugIds;
          if (!e) return {};
          let n = Object.keys(e);
          return s && n.length === i
            ? s
            : ((i = n.length),
              (s = n.reduce((n, i) => {
                r || (r = {});
                let s = r[i];
                if (s) n[s[0]] = s[1];
                else {
                  let s = t(i);
                  for (let t = s.length - 1; t >= 0; t--) {
                    let o = s[t],
                      u = o && o.filename,
                      a = e[i];
                    if (u && a) {
                      (n[u] = a), (r[i] = [u, a]);
                      break;
                    }
                  }
                }
                return n;
              }, {})));
        }
        function a(t, e) {
          let n = u(t);
          if (!n) return [];
          let r = [];
          for (let t of e)
            t &&
              n[t] &&
              r.push({ type: "sourcemap", code_file: t, debug_id: n[t] });
          return r;
        }
      },
      24925: function (t, e, n) {
        n.d(e, {
          Cy: function () {
            return m;
          },
          HD: function () {
            return c;
          },
          J8: function () {
            return g;
          },
          Kj: function () {
            return _;
          },
          Le: function () {
            return f;
          },
          PO: function () {
            return d;
          },
          TX: function () {
            return u;
          },
          V9: function () {
            return y;
          },
          VW: function () {
            return o;
          },
          VZ: function () {
            return i;
          },
          cO: function () {
            return p;
          },
          fm: function () {
            return a;
          },
          kK: function () {
            return h;
          },
          pt: function () {
            return l;
          },
          y1: function () {
            return v;
          },
        });
        let r = Object.prototype.toString;
        function i(t) {
          switch (r.call(t)) {
            case "[object Error]":
            case "[object Exception]":
            case "[object DOMException]":
            case "[object WebAssembly.Exception]":
              return !0;
            default:
              return y(t, Error);
          }
        }
        function s(t, e) {
          return r.call(t) === `[object ${e}]`;
        }
        function o(t) {
          return s(t, "ErrorEvent");
        }
        function u(t) {
          return s(t, "DOMError");
        }
        function a(t) {
          return s(t, "DOMException");
        }
        function c(t) {
          return s(t, "String");
        }
        function f(t) {
          return (
            "object" == typeof t &&
            null !== t &&
            "__sentry_template_string__" in t &&
            "__sentry_template_values__" in t
          );
        }
        function l(t) {
          return (
            null === t ||
            f(t) ||
            ("object" != typeof t && "function" != typeof t)
          );
        }
        function d(t) {
          return s(t, "Object");
        }
        function p(t) {
          return "undefined" != typeof Event && y(t, Event);
        }
        function h(t) {
          return "undefined" != typeof Element && y(t, Element);
        }
        function _(t) {
          return s(t, "RegExp");
        }
        function g(t) {
          return Boolean(t && t.then && "function" == typeof t.then);
        }
        function m(t) {
          return (
            d(t) &&
            "nativeEvent" in t &&
            "preventDefault" in t &&
            "stopPropagation" in t
          );
        }
        function y(t, e) {
          try {
            return t instanceof e;
          } catch (t) {
            return !1;
          }
        }
        function v(t) {
          return !!(
            "object" == typeof t &&
            null !== t &&
            (t.__isVue || t._isVue)
          );
        }
      },
      17986: function (t, e, n) {
        n.d(e, {
          Cf: function () {
            return u;
          },
          LD: function () {
            return o;
          },
          RU: function () {
            return s;
          },
          kg: function () {
            return a;
          },
        });
        var r = n(23187),
          i = n(33280);
        let s = ["debug", "info", "warn", "error", "log", "assert", "trace"],
          o = {};
        function u(t) {
          if (!("console" in i.n)) return t();
          let e = i.n.console,
            n = {},
            r = Object.keys(o);
          r.forEach((t) => {
            let r = o[t];
            (n[t] = e[t]), (e[t] = r);
          });
          try {
            return t();
          } finally {
            r.forEach((t) => {
              e[t] = n[t];
            });
          }
        }
        let a = (0, i.Y)("logger", function () {
          let t = !1,
            e = {
              enable: () => {
                t = !0;
              },
              disable: () => {
                t = !1;
              },
              isEnabled: () => t,
            };
          return (
            r.X
              ? s.forEach((n) => {
                  e[n] = (...e) => {
                    t &&
                      u(() => {
                        i.n.console[n](`Sentry Logger [${n}]:`, ...e);
                      });
                  };
                })
              : s.forEach((t) => {
                  e[t] = () => void 0;
                }),
            e
          );
        });
      },
      82305: function (t, e, n) {
        n.d(e, {
          DM: function () {
            return o;
          },
          Db: function () {
            return c;
          },
          EG: function () {
            return f;
          },
          YO: function () {
            return d;
          },
          go: function () {
            return l;
          },
          jH: function () {
            return a;
          },
        });
        var r = n(51150),
          i = n(50027),
          s = n(33280);
        function o() {
          let t = s.n,
            e = t.crypto || t.msCrypto,
            n = () => 16 * Math.random();
          try {
            if (e && e.randomUUID) return e.randomUUID().replace(/-/g, "");
            e &&
              e.getRandomValues &&
              (n = () => {
                let t = new Uint8Array(1);
                return e.getRandomValues(t), t[0];
              });
          } catch (t) {}
          return "10000000100040008000100000000000".replace(/[018]/g, (t) =>
            (t ^ ((15 & n()) >> (t / 4))).toString(16)
          );
        }
        function u(t) {
          return t.exception && t.exception.values
            ? t.exception.values[0]
            : void 0;
        }
        function a(t) {
          let { message: e, event_id: n } = t;
          if (e) return e;
          let r = u(t);
          return r
            ? r.type && r.value
              ? `${r.type}: ${r.value}`
              : r.type || r.value || n || "<unknown>"
            : n || "<unknown>";
        }
        function c(t, e, n) {
          let r = (t.exception = t.exception || {}),
            i = (r.values = r.values || []),
            s = (i[0] = i[0] || {});
          s.value || (s.value = e || ""), s.type || (s.type = n || "Error");
        }
        function f(t, e) {
          let n = u(t);
          if (!n) return;
          let r = n.mechanism;
          if (
            ((n.mechanism = { type: "generic", handled: !0, ...r, ...e }),
            e && "data" in e)
          ) {
            let t = { ...(r && r.data), ...e.data };
            n.mechanism.data = t;
          }
        }
        function l(t, e, n = 5) {
          if (void 0 === e.lineno) return;
          let r = t.length,
            s = Math.max(Math.min(r - 1, e.lineno - 1), 0);
          (e.pre_context = t
            .slice(Math.max(0, s - n), s)
            .map((t) => (0, i.JM)(t, 0))),
            (e.context_line = (0, i.JM)(t[Math.min(r - 1, s)], e.colno || 0)),
            (e.post_context = t
              .slice(Math.min(s + 1, r), s + 1 + n)
              .map((t) => (0, i.JM)(t, 0)));
        }
        function d(t) {
          if (
            (function (t) {
              try {
                return t.__sentry_captured__;
              } catch (t) {}
            })(t)
          )
            return !0;
          try {
            (0, r.xp)(t, "__sentry_captured__", !0);
          } catch (t) {}
          return !1;
        }
      },
      90059: function (t, e, n) {
        n.d(e, {
          Fv: function () {
            return o;
          },
          Qy: function () {
            return function t(e, n = 3, r = 102400) {
              let i = o(e, n);
              return ~-encodeURI(JSON.stringify(i)).split(/%..|./).length > r
                ? t(e, n - 1, r)
                : i;
            };
          },
        });
        var r = n(24925),
          i = n(51150),
          s = n(39649);
        function o(t, e = 100, n = Infinity) {
          try {
            return (function t(
              e,
              n,
              o = Infinity,
              u = Infinity,
              a = (function () {
                let t = "function" == typeof WeakSet,
                  e = t ? new WeakSet() : [];
                return [
                  function (n) {
                    if (t) return !!e.has(n) || (e.add(n), !1);
                    for (let t = 0; t < e.length; t++) {
                      let r = e[t];
                      if (r === n) return !0;
                    }
                    return e.push(n), !1;
                  },
                  function (n) {
                    if (t) e.delete(n);
                    else
                      for (let t = 0; t < e.length; t++)
                        if (e[t] === n) {
                          e.splice(t, 1);
                          break;
                        }
                  },
                ];
              })()
            ) {
              let [c, f] = a;
              if (
                null == n ||
                ["boolean", "string"].includes(typeof n) ||
                ("number" == typeof n && Number.isFinite(n))
              )
                return n;
              let l = (function (t, e) {
                try {
                  if ("domain" === t && e && "object" == typeof e && e._events)
                    return "[Domain]";
                  if ("domainEmitter" === t) return "[DomainEmitter]";
                  if ("undefined" != typeof global && e === global)
                    return "[Global]";
                  if ("undefined" != typeof window && e === window)
                    return "[Window]";
                  if ("undefined" != typeof document && e === document)
                    return "[Document]";
                  if ((0, r.y1)(e)) return "[VueViewModel]";
                  if ((0, r.Cy)(e)) return "[SyntheticEvent]";
                  if ("number" == typeof e && !Number.isFinite(e))
                    return `[${e}]`;
                  if ("function" == typeof e)
                    return `[Function: ${(0, s.$P)(e)}]`;
                  if ("symbol" == typeof e) return `[${String(e)}]`;
                  if ("bigint" == typeof e) return `[BigInt: ${String(e)}]`;
                  let n = (function (t) {
                    let e = Object.getPrototypeOf(t);
                    return e ? e.constructor.name : "null prototype";
                  })(e);
                  if (/^HTML(\w*)Element$/.test(n))
                    return `[HTMLElement: ${n}]`;
                  return `[object ${n}]`;
                } catch (t) {
                  return `**non-serializable** (${t})`;
                }
              })(e, n);
              if (!l.startsWith("[object ")) return l;
              if (n.__sentry_skip_normalization__) return n;
              let d =
                "number" == typeof n.__sentry_override_normalization_depth__
                  ? n.__sentry_override_normalization_depth__
                  : o;
              if (0 === d) return l.replace("object ", "");
              if (c(n)) return "[Circular ~]";
              if (n && "function" == typeof n.toJSON)
                try {
                  let e = n.toJSON();
                  return t("", e, d - 1, u, a);
                } catch (t) {}
              let p = Array.isArray(n) ? [] : {},
                h = 0,
                _ = (0, i.Sh)(n);
              for (let e in _) {
                if (!Object.prototype.hasOwnProperty.call(_, e)) continue;
                if (h >= u) {
                  p[e] = "[MaxProperties ~]";
                  break;
                }
                let n = _[e];
                (p[e] = t(e, n, d - 1, u, a)), h++;
              }
              return f(n), p;
            })("", t, e, n);
          } catch (t) {
            return { ERROR: `**non-serializable** (${t})` };
          }
        }
      },
      51150: function (t, e, n) {
        n.d(e, {
          $Q: function () {
            return f;
          },
          HK: function () {
            return l;
          },
          Jr: function () {
            return g;
          },
          Sh: function () {
            return d;
          },
          hl: function () {
            return a;
          },
          xp: function () {
            return c;
          },
          zf: function () {
            return _;
          },
        });
        var r = n(70428),
          i = n(23187),
          s = n(24925),
          o = n(17986),
          u = n(50027);
        function a(t, e, n) {
          if (!(e in t)) return;
          let r = t[e],
            s = n(r);
          "function" == typeof s && f(s, r);
          try {
            t[e] = s;
          } catch (n) {
            i.X && o.kg.log(`Failed to replace method "${e}" in object`, t);
          }
        }
        function c(t, e, n) {
          try {
            Object.defineProperty(t, e, {
              value: n,
              writable: !0,
              configurable: !0,
            });
          } catch (n) {
            i.X &&
              o.kg.log(
                `Failed to add non-enumerable property "${e}" to object`,
                t
              );
          }
        }
        function f(t, e) {
          try {
            let n = e.prototype || {};
            (t.prototype = e.prototype = n), c(t, "__sentry_original__", e);
          } catch (t) {}
        }
        function l(t) {
          return t.__sentry_original__;
        }
        function d(t) {
          if ((0, s.VZ)(t))
            return {
              message: t.message,
              name: t.name,
              stack: t.stack,
              ...h(t),
            };
          if (!(0, s.cO)(t)) return t;
          {
            let e = {
              type: t.type,
              target: p(t.target),
              currentTarget: p(t.currentTarget),
              ...h(t),
            };
            return (
              "undefined" != typeof CustomEvent &&
                (0, s.V9)(t, CustomEvent) &&
                (e.detail = t.detail),
              e
            );
          }
        }
        function p(t) {
          try {
            return (0, s.kK)(t)
              ? (0, r.Rt)(t)
              : Object.prototype.toString.call(t);
          } catch (t) {
            return "<unknown>";
          }
        }
        function h(t) {
          if ("object" != typeof t || null === t) return {};
          {
            let e = {};
            for (let n in t)
              Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
            return e;
          }
        }
        function _(t, e = 40) {
          let n = Object.keys(d(t));
          n.sort();
          let r = n[0];
          if (!r) return "[object has no keys]";
          if (r.length >= e) return (0, u.$G)(r, e);
          for (let t = n.length; t > 0; t--) {
            let r = n.slice(0, t).join(", ");
            if (!(r.length > e)) {
              if (t === n.length) return r;
              return (0, u.$G)(r, e);
            }
          }
          return "";
        }
        function g(t) {
          let e = new Map();
          return (function t(e, n) {
            if (
              (function (t) {
                if (!(0, s.PO)(t)) return !1;
                try {
                  let e = Object.getPrototypeOf(t).constructor.name;
                  return !e || "Object" === e;
                } catch (t) {
                  return !0;
                }
              })(e)
            ) {
              let r = n.get(e);
              if (void 0 !== r) return r;
              let i = {};
              for (let r of (n.set(e, i), Object.getOwnPropertyNames(e)))
                void 0 !== e[r] && (i[r] = t(e[r], n));
              return i;
            }
            if (Array.isArray(e)) {
              let r = n.get(e);
              if (void 0 !== r) return r;
              let i = [];
              return (
                n.set(e, i),
                e.forEach((e) => {
                  i.push(t(e, n));
                }),
                i
              );
            }
            return e;
          })(t, e);
        }
      },
      51824: function (t, e, n) {
        n.d(e, {
          Ht: function () {
            return i;
          },
          M: function () {
            return s;
          },
        });
        var r = n(82305);
        function i() {
          return (0, r.DM)();
        }
        function s() {
          return (0, r.DM)().substring(16);
        }
      },
      39649: function (t, e, n) {
        n.d(e, {
          $P: function () {
            return f;
          },
          Fi: function () {
            return r;
          },
          Fr: function () {
            return l;
          },
          Sq: function () {
            return u;
          },
          pE: function () {
            return o;
          },
        });
        let r = "?",
          i = /\(error: (.*)\)/,
          s = /captureMessage|captureException/;
        function o(...t) {
          let e = t.sort((t, e) => t[0] - e[0]).map((t) => t[1]);
          return (t, n = 0, o = 0) => {
            let u = [],
              c = t.split("\n");
            for (let t = n; t < c.length; t++) {
              let n = c[t];
              if (n.length > 1024) continue;
              let r = i.test(n) ? n.replace(i, "$1") : n;
              if (!r.match(/\S*Error: /)) {
                for (let t of e) {
                  let e = t(r);
                  if (e) {
                    u.push(e);
                    break;
                  }
                }
                if (u.length >= 50 + o) break;
              }
            }
            return (function (t) {
              if (!t.length) return [];
              let e = Array.from(t);
              return (
                /sentryWrapped/.test(a(e).function || "") && e.pop(),
                e.reverse(),
                s.test(a(e).function || "") &&
                  (e.pop(), s.test(a(e).function || "") && e.pop()),
                e
                  .slice(0, 50)
                  .map((t) => ({
                    ...t,
                    filename: t.filename || a(e).filename,
                    function: t.function || r,
                  }))
              );
            })(u.slice(o));
          };
        }
        function u(t) {
          return Array.isArray(t) ? o(...t) : t;
        }
        function a(t) {
          return t[t.length - 1] || {};
        }
        let c = "<anonymous>";
        function f(t) {
          try {
            if (!t || "function" != typeof t) return c;
            return t.name || c;
          } catch (t) {
            return c;
          }
        }
        function l(t) {
          let e = t.exception;
          if (e) {
            let t = [];
            try {
              return (
                e.values.forEach((e) => {
                  e.stacktrace.frames && t.push(...e.stacktrace.frames);
                }),
                t
              );
            } catch (t) {}
          }
        }
      },
      50027: function (t, e, n) {
        n.d(e, {
          $G: function () {
            return i;
          },
          JM: function () {
            return s;
          },
          U0: function () {
            return u;
          },
          nK: function () {
            return o;
          },
        });
        var r = n(24925);
        function i(t, e = 0) {
          return "string" != typeof t || 0 === e
            ? t
            : t.length <= e
            ? t
            : `${t.slice(0, e)}...`;
        }
        function s(t, e) {
          let n = t,
            r = n.length;
          if (r <= 150) return n;
          e > r && (e = r);
          let i = Math.max(e - 60, 0);
          i < 5 && (i = 0);
          let s = Math.min(i + 140, r);
          return (
            s > r - 5 && (s = r),
            s === r && (i = Math.max(s - 140, 0)),
            (n = n.slice(i, s)),
            i > 0 && (n = `'{snip} ${n}`),
            s < r && (n += " {snip}"),
            n
          );
        }
        function o(t, e) {
          if (!Array.isArray(t)) return "";
          let n = [];
          for (let e = 0; e < t.length; e++) {
            let i = t[e];
            try {
              (0, r.y1)(i) ? n.push("[VueViewModel]") : n.push(String(i));
            } catch (t) {
              n.push("[value cannot be serialized]");
            }
          }
          return n.join(e);
        }
        function u(t, e = [], n = !1) {
          return e.some((e) =>
            (function (t, e, n = !1) {
              return (
                !!(0, r.HD)(t) &&
                ((0, r.Kj)(e)
                  ? e.test(t)
                  : !!(0, r.HD)(e) && (n ? t === e : t.includes(e)))
              );
            })(t, e, n)
          );
        }
      },
      52340: function (t, e, n) {
        n.d(e, {
          $2: function () {
            return u;
          },
          WD: function () {
            return o;
          },
          cW: function () {
            return a;
          },
        });
        var r,
          i,
          s = n(24925);
        function o(t) {
          return new a((e) => {
            e(t);
          });
        }
        function u(t) {
          return new a((e, n) => {
            n(t);
          });
        }
        ((r = i || (i = {}))[(r.PENDING = 0)] = "PENDING"),
          (r[(r.RESOLVED = 1)] = "RESOLVED"),
          (r[(r.REJECTED = 2)] = "REJECTED");
        class a {
          constructor(t) {
            a.prototype.__init.call(this),
              a.prototype.__init2.call(this),
              a.prototype.__init3.call(this),
              a.prototype.__init4.call(this),
              (this._state = i.PENDING),
              (this._handlers = []);
            try {
              t(this._resolve, this._reject);
            } catch (t) {
              this._reject(t);
            }
          }
          then(t, e) {
            return new a((n, r) => {
              this._handlers.push([
                !1,
                (e) => {
                  if (t)
                    try {
                      n(t(e));
                    } catch (t) {
                      r(t);
                    }
                  else n(e);
                },
                (t) => {
                  if (e)
                    try {
                      n(e(t));
                    } catch (t) {
                      r(t);
                    }
                  else r(t);
                },
              ]),
                this._executeHandlers();
            });
          }
          catch(t) {
            return this.then((t) => t, t);
          }
          finally(t) {
            return new a((e, n) => {
              let r, i;
              return this.then(
                (e) => {
                  (i = !1), (r = e), t && t();
                },
                (e) => {
                  (i = !0), (r = e), t && t();
                }
              ).then(() => {
                if (i) {
                  n(r);
                  return;
                }
                e(r);
              });
            });
          }
          __init() {
            this._resolve = (t) => {
              this._setResult(i.RESOLVED, t);
            };
          }
          __init2() {
            this._reject = (t) => {
              this._setResult(i.REJECTED, t);
            };
          }
          __init3() {
            this._setResult = (t, e) => {
              if (this._state === i.PENDING) {
                if ((0, s.J8)(e)) {
                  e.then(this._resolve, this._reject);
                  return;
                }
                (this._state = t), (this._value = e), this._executeHandlers();
              }
            };
          }
          __init4() {
            this._executeHandlers = () => {
              if (this._state === i.PENDING) return;
              let t = this._handlers.slice();
              (this._handlers = []),
                t.forEach((t) => {
                  t[0] ||
                    (this._state === i.RESOLVED && t[1](this._value),
                    this._state === i.REJECTED && t[2](this._value),
                    (t[0] = !0));
                });
            };
          }
        }
      },
      59943: function (t, e, n) {
        n.d(e, {
          Z1: function () {
            return o;
          },
          ph: function () {
            return s;
          },
          yW: function () {
            return i;
          },
        });
        var r = n(33280);
        function i() {
          return Date.now() / 1e3;
        }
        let s = (function () {
            let { performance: t } = r.n;
            if (!t || !t.now) return i;
            let e = Date.now() - t.now(),
              n = void 0 == t.timeOrigin ? e : t.timeOrigin;
            return () => (n + t.now()) / 1e3;
          })(),
          o = (() => {
            let { performance: t } = r.n;
            if (!t || !t.now) return;
            let e = t.now(),
              n = Date.now(),
              i = t.timeOrigin ? Math.abs(t.timeOrigin + e - n) : 36e5,
              s = t.timing && t.timing.navigationStart,
              o = "number" == typeof s ? Math.abs(s + e - n) : 36e5;
            return i < 36e5 || o < 36e5 ? (i <= o ? t.timeOrigin : s) : n;
          })();
      },
      94801: function (t, e, n) {
        n.d(e, {
          $p: function () {
            return a;
          },
          Ke: function () {
            return s;
          },
          pT: function () {
            return u;
          },
          qG: function () {
            return o;
          },
        });
        var r = n(98823),
          i = n(51824);
        let s = RegExp(
          "^[ \\t]*([0-9a-f]{32})?-?([0-9a-f]{16})?-?([01])?[ \\t]*$"
        );
        function o(t) {
          let e;
          if (!t) return;
          let n = t.match(s);
          if (n)
            return (
              "1" === n[3] ? (e = !0) : "0" === n[3] && (e = !1),
              { traceId: n[1], parentSampled: e, parentSpanId: n[2] }
            );
        }
        function u(t, e) {
          let n = o(t),
            s = (0, r.EN)(e);
          if (!n || !n.traceId)
            return { traceId: (0, i.Ht)(), spanId: (0, i.M)() };
          let { traceId: u, parentSpanId: a, parentSampled: c } = n,
            f = (0, i.M)();
          return {
            traceId: u,
            parentSpanId: a,
            spanId: f,
            sampled: c,
            dsc: s || {},
          };
        }
        function a(t = (0, i.Ht)(), e = (0, i.M)(), n) {
          let r = "";
          return void 0 !== n && (r = n ? "-1" : "-0"), `${t}-${e}${r}`;
        }
      },
      49889: function (t, e, n) {
        n.d(e, {
          J: function () {
            return r;
          },
        });
        let r = "8.43.0";
      },
      33280: function (t, e, n) {
        n.d(e, {
          Y: function () {
            return s;
          },
          n: function () {
            return i;
          },
        });
        var r = n(49889);
        let i = globalThis;
        function s(t, e, n) {
          let s = n || i,
            o = (s.__SENTRY__ = s.__SENTRY__ || {}),
            u = (o[r.J] = o[r.J] || {});
          return u[t] || (u[t] = e());
        }
      },
      67973: function (t, e, n) {
        function r(t) {
          return !1;
        }
        n.d(e, {
          z: function () {
            return r;
          },
        }),
          n(26318);
      },
      3613: function (t, e, n) {
        n.d(e, {
          T: function () {
            return function t(e, n, r = 2) {
              if (!n || "object" != typeof n || r <= 0) return n;
              if (e && n && 0 === Object.keys(n).length) return e;
              let i = { ...e };
              for (let e in n)
                Object.prototype.hasOwnProperty.call(n, e) &&
                  (i[e] = t(i[e], n[e], r - 1));
              return i;
            };
          },
        });
      },
      5808: function (t, e, n) {
        n.d(e, {
          U0: function () {
            return S;
          },
          R: function () {
            return x;
          },
        });
        var r = n(73243),
          i = n(26318),
          s = n(94223),
          o = n(24925),
          u = n(17986),
          a = n(52340),
          c = n(43927),
          f = n(62538),
          l = n(82305),
          d = n(90059),
          p = n(50027),
          h = n(59943),
          _ = n(72123),
          g = n(51150),
          m = n(3613),
          y = n(81585);
        function v(t, e) {
          let {
            extra: n,
            tags: r,
            user: i,
            contexts: s,
            level: o,
            sdkProcessingMetadata: u,
            breadcrumbs: a,
            fingerprint: c,
            eventProcessors: f,
            attachments: l,
            propagationContext: d,
            transactionName: p,
            span: h,
          } = e;
          b(t, "extra", n),
            b(t, "tags", r),
            b(t, "user", i),
            b(t, "contexts", s),
            (t.sdkProcessingMetadata = (0, m.T)(t.sdkProcessingMetadata, u, 2)),
            o && (t.level = o),
            p && (t.transactionName = p),
            h && (t.span = h),
            a.length && (t.breadcrumbs = [...t.breadcrumbs, ...a]),
            c.length && (t.fingerprint = [...t.fingerprint, ...c]),
            f.length && (t.eventProcessors = [...t.eventProcessors, ...f]),
            l.length && (t.attachments = [...t.attachments, ...l]),
            (t.propagationContext = { ...t.propagationContext, ...d });
        }
        function b(t, e, n) {
          t[e] = (0, m.T)(t[e], n, 1);
        }
        function x(t, e, n, m, b, x) {
          var S;
          let { normalizeDepth: E = 3, normalizeMaxBreadth: k = 1e3 } = t,
            w = {
              ...e,
              event_id: e.event_id || n.event_id || (0, l.DM)(),
              timestamp: e.timestamp || (0, h.yW)(),
            },
            M = n.integrations || t.integrations.map((t) => t.name);
          (function (t, e) {
            let {
              environment: n,
              release: i,
              dist: s,
              maxValueLength: o = 250,
            } = e;
            (t.environment = t.environment || n || r.J),
              !t.release && i && (t.release = i),
              !t.dist && s && (t.dist = s),
              t.message && (t.message = (0, p.$G)(t.message, o));
            let u = t.exception && t.exception.values && t.exception.values[0];
            u && u.value && (u.value = (0, p.$G)(u.value, o));
            let a = t.request;
            a && a.url && (a.url = (0, p.$G)(a.url, o));
          })(w, t),
            (S = w),
            M.length > 0 &&
              ((S.sdk = S.sdk || {}),
              (S.sdk.integrations = [...(S.sdk.integrations || []), ...M])),
            b && b.emit("applyFrameMetadata", e),
            void 0 === e.type &&
              (function (t, e) {
                let n = (0, f.N)(e);
                try {
                  t.exception.values.forEach((t) => {
                    t.stacktrace.frames.forEach((t) => {
                      n && t.filename && (t.debug_id = n[t.filename]);
                    });
                  });
                } catch (t) {}
              })(w, t.stackParser);
          let D = (function (t, e) {
            if (!e) return t;
            let n = t ? t.clone() : new c.s();
            return n.update(e), n;
          })(m, n.captureContext);
          n.mechanism && (0, l.EG)(w, n.mechanism);
          let C = b ? b.getEventProcessors() : [],
            O = (0, i.lW)().getScopeData();
          if (x) {
            let t = x.getScopeData();
            v(O, t);
          }
          if (D) {
            let t = D.getScopeData();
            v(O, t);
          }
          let j = [...(n.attachments || []), ...O.attachments];
          j.length && (n.attachments = j),
            (function (t, e) {
              var n, r;
              let {
                fingerprint: i,
                span: s,
                breadcrumbs: o,
                sdkProcessingMetadata: u,
              } = e;
              (function (t, e) {
                let {
                    extra: n,
                    tags: r,
                    user: i,
                    contexts: s,
                    level: o,
                    transactionName: u,
                  } = e,
                  a = (0, g.Jr)(n);
                a && Object.keys(a).length && (t.extra = { ...a, ...t.extra });
                let c = (0, g.Jr)(r);
                c && Object.keys(c).length && (t.tags = { ...c, ...t.tags });
                let f = (0, g.Jr)(i);
                f && Object.keys(f).length && (t.user = { ...f, ...t.user });
                let l = (0, g.Jr)(s);
                l &&
                  Object.keys(l).length &&
                  (t.contexts = { ...l, ...t.contexts }),
                  o && (t.level = o),
                  u && "transaction" !== t.type && (t.transaction = u);
              })(t, e),
                s &&
                  (function (t, e) {
                    (t.contexts = { trace: (0, y.wy)(e), ...t.contexts }),
                      (t.sdkProcessingMetadata = {
                        dynamicSamplingContext: (0, _.jC)(e),
                        ...t.sdkProcessingMetadata,
                      });
                    let n = (0, y.Gx)(e),
                      r = (0, y.XU)(n).description;
                    r &&
                      !t.transaction &&
                      "transaction" === t.type &&
                      (t.transaction = r);
                  })(t, s),
                ((n = t).fingerprint = n.fingerprint
                  ? Array.isArray(n.fingerprint)
                    ? n.fingerprint
                    : [n.fingerprint]
                  : []),
                i && (n.fingerprint = n.fingerprint.concat(i)),
                n.fingerprint && !n.fingerprint.length && delete n.fingerprint,
                (function (t, e) {
                  let n = [...(t.breadcrumbs || []), ...e];
                  t.breadcrumbs = n.length ? n : void 0;
                })(t, o),
                ((r = t).sdkProcessingMetadata = {
                  ...r.sdkProcessingMetadata,
                  ...u,
                });
            })(w, O);
          let I = [...C, ...O.eventProcessors],
            $ = (function t(e, n, r, i = 0) {
              return new a.cW((a, c) => {
                let f = e[i];
                if (null === n || "function" != typeof f) a(n);
                else {
                  let l = f({ ...n }, r);
                  s.X &&
                    f.id &&
                    null === l &&
                    u.kg.log(`Event processor "${f.id}" dropped event`),
                    (0, o.J8)(l)
                      ? l.then((n) => t(e, n, r, i + 1).then(a)).then(null, c)
                      : t(e, l, r, i + 1)
                          .then(a)
                          .then(null, c);
                }
              });
            })(I, w, n);
          return $.then((t) =>
            (t &&
              (function (t) {
                let e = {};
                try {
                  t.exception.values.forEach((t) => {
                    t.stacktrace.frames.forEach((t) => {
                      t.debug_id &&
                        (t.abs_path
                          ? (e[t.abs_path] = t.debug_id)
                          : t.filename && (e[t.filename] = t.debug_id),
                        delete t.debug_id);
                    });
                  });
                } catch (t) {}
                if (0 === Object.keys(e).length) return;
                (t.debug_meta = t.debug_meta || {}),
                  (t.debug_meta.images = t.debug_meta.images || []);
                let n = t.debug_meta.images;
                Object.entries(e).forEach(([t, e]) => {
                  n.push({ type: "sourcemap", code_file: t, debug_id: e });
                });
              })(t),
            "number" == typeof E && E > 0)
              ? (function (t, e, n) {
                  if (!t) return null;
                  let r = {
                    ...t,
                    ...(t.breadcrumbs && {
                      breadcrumbs: t.breadcrumbs.map((t) => ({
                        ...t,
                        ...(t.data && { data: (0, d.Fv)(t.data, e, n) }),
                      })),
                    }),
                    ...(t.user && { user: (0, d.Fv)(t.user, e, n) }),
                    ...(t.contexts && {
                      contexts: (0, d.Fv)(t.contexts, e, n),
                    }),
                    ...(t.extra && { extra: (0, d.Fv)(t.extra, e, n) }),
                  };
                  return (
                    t.contexts &&
                      t.contexts.trace &&
                      r.contexts &&
                      ((r.contexts.trace = t.contexts.trace),
                      t.contexts.trace.data &&
                        (r.contexts.trace.data = (0, d.Fv)(
                          t.contexts.trace.data,
                          e,
                          n
                        ))),
                    t.spans &&
                      (r.spans = t.spans.map((t) => ({
                        ...t,
                        ...(t.data && { data: (0, d.Fv)(t.data, e, n) }),
                      }))),
                    t.contexts &&
                      t.contexts.flags &&
                      r.contexts &&
                      (r.contexts.flags = (0, d.Fv)(t.contexts.flags, 3, n)),
                    r
                  );
                })(t, E, k)
              : t
          );
        }
        function S(t) {
          return t
            ? t instanceof c.s ||
              "function" == typeof t ||
              Object.keys(t).some((t) => E.includes(t))
              ? { captureContext: t }
              : t
            : void 0;
        }
        let E = [
          "user",
          "level",
          "extra",
          "contexts",
          "tags",
          "fingerprint",
          "requestSession",
          "propagationContext",
        ];
      },
      89366: function (t, e, n) {
        n.d(e, {
          D: function () {
            return s;
          },
          Y: function () {
            return o;
          },
        });
        var r = n(51150);
        let i = "_sentrySpan";
        function s(t, e) {
          e ? (0, r.xp)(t, i, e) : delete t[i];
        }
        function o(t) {
          return t[i];
        }
      },
      81585: function (t, e, n) {
        n.d(e, {
          $k: function () {
            return x;
          },
          Dp: function () {
            return j;
          },
          Gx: function () {
            return I;
          },
          HN: function () {
            return $;
          },
          HR: function () {
            return y;
          },
          Hb: function () {
            return b;
          },
          R6: function () {
            return N;
          },
          Tt: function () {
            return k;
          },
          XU: function () {
            return E;
          },
          _4: function () {
            return w;
          },
          ed: function () {
            return O;
          },
          i0: function () {
            return g;
          },
          j5: function () {
            return C;
          },
          ve: function () {
            return _;
          },
          wy: function () {
            return v;
          },
          yc: function () {
            return P;
          },
        });
        var r = n(60811),
          i = n(13533),
          s = n(26318),
          o = n(72751),
          u = n(31218),
          a = n(69737),
          c = n(17986),
          f = n(51150),
          l = n(51824),
          d = n(59943),
          p = n(94801),
          h = n(89366);
        let _ = 0,
          g = 1,
          m = !1;
        function y(t) {
          let { spanId: e, traceId: n } = t.spanContext(),
            { data: r, op: i, parent_span_id: s, status: o, origin: u } = E(t);
          return (0, f.Jr)({
            parent_span_id: s,
            span_id: e,
            trace_id: n,
            data: r,
            op: i,
            status: o,
            origin: u,
          });
        }
        function v(t) {
          let { spanId: e, traceId: n, isRemote: r } = t.spanContext(),
            i = r ? e : E(t).parent_span_id,
            s = r ? (0, l.M)() : e;
          return (0, f.Jr)({ parent_span_id: i, span_id: s, trace_id: n });
        }
        function b(t) {
          let { traceId: e, spanId: n } = t.spanContext(),
            r = k(t);
          return (0, p.$p)(e, n, r);
        }
        function x(t) {
          return "number" == typeof t
            ? S(t)
            : Array.isArray(t)
            ? t[0] + t[1] / 1e9
            : t instanceof Date
            ? S(t.getTime())
            : (0, d.ph)();
        }
        function S(t) {
          return t > 9999999999 ? t / 1e3 : t;
        }
        function E(t) {
          if ("function" == typeof t.getSpanJSON) return t.getSpanJSON();
          try {
            let { spanId: e, traceId: n } = t.spanContext();
            if (
              t.attributes &&
              t.startTime &&
              t.name &&
              t.endTime &&
              t.status
            ) {
              let {
                attributes: r,
                startTime: i,
                name: s,
                endTime: a,
                parentSpanId: c,
                status: l,
              } = t;
              return (0, f.Jr)({
                span_id: e,
                trace_id: n,
                data: r,
                description: s,
                parent_span_id: c,
                start_timestamp: x(i),
                timestamp: x(a) || void 0,
                status: w(l),
                op: r[u.$J],
                origin: r[u.S3],
                _metrics_summary: (0, o.y)(t),
              });
            }
            return { span_id: e, trace_id: n };
          } catch (t) {
            return {};
          }
        }
        function k(t) {
          let { traceFlags: e } = t.spanContext();
          return e === g;
        }
        function w(t) {
          return t && t.code !== a.pq
            ? t.code === a.OP
              ? "ok"
              : t.message || "unknown_error"
            : void 0;
        }
        let M = "_sentryChildSpans",
          D = "_sentryRootSpan";
        function C(t, e) {
          let n = t[D] || t;
          (0, f.xp)(e, D, n),
            t[M] ? t[M].add(e) : (0, f.xp)(t, M, new Set([e]));
        }
        function O(t, e) {
          t[M] && t[M].delete(e);
        }
        function j(t) {
          let e = new Set();
          return (
            (function t(n) {
              if (!e.has(n) && k(n)) {
                e.add(n);
                let r = n[M] ? Array.from(n[M]) : [];
                for (let e of r) t(e);
              }
            })(t),
            Array.from(e)
          );
        }
        function I(t) {
          return t[D] || t;
        }
        function $() {
          let t = (0, i.c)(),
            e = (0, r.G)(t);
          return e.getActiveSpan ? e.getActiveSpan() : (0, h.Y)((0, s.nZ)());
        }
        function P(t, e, n, r, i, s) {
          let u = $();
          u && (0, o.V)(u, t, e, n, r, i, s);
        }
        function N() {
          m ||
            ((0, c.Cf)(() => {
              console.warn(
                "[Sentry] Deprecation warning: Returning null from `beforeSendSpan` will be disallowed from SDK version 9.0.0 onwards. The callback will only support mutating spans. To drop certain spans, configure the respective integrations directly."
              );
            }),
            (m = !0));
        }
      },
    },
  ]);
