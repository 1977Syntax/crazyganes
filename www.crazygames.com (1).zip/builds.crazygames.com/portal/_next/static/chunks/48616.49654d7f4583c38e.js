!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "516cf567-942c-43f0-bfea-2b3a284e0091"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-516cf567-942c-43f0-bfea-2b3a284e0091"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [48616],
    {
      40044: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return Z;
          },
        });
        var l = r(63366),
          o = r(87462),
          n = r(67294),
          i = r(90512),
          a = r(94780),
          s = r(49990),
          c = r(98216),
          d = r(71657),
          u = r(90948),
          f = r(1588),
          b = r(34867);
        function p(e) {
          return (0, b.ZP)("MuiTab", e);
        }
        let h = (0, f.Z)("MuiTab", [
          "root",
          "labelIcon",
          "textColorInherit",
          "textColorPrimary",
          "textColorSecondary",
          "selected",
          "disabled",
          "fullWidth",
          "wrapped",
          "iconWrapper",
        ]);
        var m = r(85893);
        let v = [
            "className",
            "disabled",
            "disableFocusRipple",
            "fullWidth",
            "icon",
            "iconPosition",
            "indicator",
            "label",
            "onChange",
            "onClick",
            "onFocus",
            "selected",
            "selectionFollowsFocus",
            "textColor",
            "value",
            "wrapped",
          ],
          y = (e) => {
            let {
                classes: t,
                textColor: r,
                fullWidth: l,
                wrapped: o,
                icon: n,
                label: i,
                selected: s,
                disabled: d,
              } = e,
              u = {
                root: [
                  "root",
                  n && i && "labelIcon",
                  `textColor${(0, c.Z)(r)}`,
                  l && "fullWidth",
                  o && "wrapped",
                  s && "selected",
                  d && "disabled",
                ],
                iconWrapper: ["iconWrapper"],
              };
            return (0, a.Z)(u, p, t);
          },
          S = (0, u.ZP)(s.Z, {
            name: "MuiTab",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                t.root,
                r.label && r.icon && t.labelIcon,
                t[`textColor${(0, c.Z)(r.textColor)}`],
                r.fullWidth && t.fullWidth,
                r.wrapped && t.wrapped,
                { [`& .${h.iconWrapper}`]: t.iconWrapper },
              ];
            },
          })(({ theme: e, ownerState: t }) =>
            (0, o.Z)(
              {},
              e.typography.button,
              {
                maxWidth: 360,
                minWidth: 90,
                position: "relative",
                minHeight: 48,
                flexShrink: 0,
                padding: "12px 16px",
                overflow: "hidden",
                whiteSpace: "normal",
                textAlign: "center",
              },
              t.label && {
                flexDirection:
                  "top" === t.iconPosition || "bottom" === t.iconPosition
                    ? "column"
                    : "row",
              },
              { lineHeight: 1.25 },
              t.icon &&
                t.label && {
                  minHeight: 72,
                  paddingTop: 9,
                  paddingBottom: 9,
                  [`& > .${h.iconWrapper}`]: (0, o.Z)(
                    {},
                    "top" === t.iconPosition && { marginBottom: 6 },
                    "bottom" === t.iconPosition && { marginTop: 6 },
                    "start" === t.iconPosition && { marginRight: e.spacing(1) },
                    "end" === t.iconPosition && { marginLeft: e.spacing(1) }
                  ),
                },
              "inherit" === t.textColor && {
                color: "inherit",
                opacity: 0.6,
                [`&.${h.selected}`]: { opacity: 1 },
                [`&.${h.disabled}`]: {
                  opacity: (e.vars || e).palette.action.disabledOpacity,
                },
              },
              "primary" === t.textColor && {
                color: (e.vars || e).palette.text.secondary,
                [`&.${h.selected}`]: {
                  color: (e.vars || e).palette.primary.main,
                },
                [`&.${h.disabled}`]: {
                  color: (e.vars || e).palette.text.disabled,
                },
              },
              "secondary" === t.textColor && {
                color: (e.vars || e).palette.text.secondary,
                [`&.${h.selected}`]: {
                  color: (e.vars || e).palette.secondary.main,
                },
                [`&.${h.disabled}`]: {
                  color: (e.vars || e).palette.text.disabled,
                },
              },
              t.fullWidth && {
                flexShrink: 1,
                flexGrow: 1,
                flexBasis: 0,
                maxWidth: "none",
              },
              t.wrapped && { fontSize: e.typography.pxToRem(12) }
            )
          ),
          g = n.forwardRef(function (e, t) {
            let r = (0, d.Z)({ props: e, name: "MuiTab" }),
              {
                className: a,
                disabled: s = !1,
                disableFocusRipple: c = !1,
                fullWidth: u,
                icon: f,
                iconPosition: b = "top",
                indicator: p,
                label: h,
                onChange: g,
                onClick: Z,
                onFocus: w,
                selected: x,
                selectionFollowsFocus: M,
                textColor: B = "inherit",
                value: C,
                wrapped: E = !1,
              } = r,
              I = (0, l.Z)(r, v),
              W = (0, o.Z)({}, r, {
                disabled: s,
                disableFocusRipple: c,
                selected: x,
                icon: !!f,
                iconPosition: b,
                label: !!h,
                fullWidth: u,
                textColor: B,
                wrapped: E,
              }),
              P = y(W),
              T =
                f && h && n.isValidElement(f)
                  ? n.cloneElement(f, {
                      className: (0, i.Z)(P.iconWrapper, f.props.className),
                    })
                  : f,
              R = (e) => {
                !x && g && g(e, C), Z && Z(e);
              },
              k = (e) => {
                M && !x && g && g(e, C), w && w(e);
              };
            return (0,
            m.jsxs)(S, (0, o.Z)({ focusRipple: !c, className: (0, i.Z)(P.root, a), ref: t, role: "tab", "aria-selected": x, disabled: s, onClick: R, onFocus: k, ownerState: W, tabIndex: x ? 0 : -1 }, I, { children: ["top" === b || "start" === b ? (0, m.jsxs)(n.Fragment, { children: [T, h] }) : (0, m.jsxs)(n.Fragment, { children: [h, T] }), p] }));
          });
        var Z = g;
      },
      79136: function (e, t, r) {
        let l;
        r.d(t, {
          Z: function () {
            return K;
          },
        });
        var o = r(63366),
          n = r(87462),
          i = r(67294);
        r(76607);
        var a = r(90512),
          s = r(83265),
          c = r(94780),
          d = r(82056),
          u = r(90948),
          f = r(71657),
          b = r(2734),
          p = r(57144);
        function h() {
          if (l) return l;
          let e = document.createElement("div"),
            t = document.createElement("div");
          return (
            (t.style.width = "10px"),
            (t.style.height = "1px"),
            e.appendChild(t),
            (e.dir = "rtl"),
            (e.style.fontSize = "14px"),
            (e.style.width = "4px"),
            (e.style.height = "1px"),
            (e.style.position = "absolute"),
            (e.style.top = "-1000px"),
            (e.style.overflow = "scroll"),
            document.body.appendChild(e),
            (l = "reverse"),
            e.scrollLeft > 0
              ? (l = "default")
              : ((e.scrollLeft = 1), 0 === e.scrollLeft && (l = "negative")),
            document.body.removeChild(e),
            l
          );
        }
        function m(e) {
          return (1 + Math.sin(Math.PI * e - Math.PI / 2)) / 2;
        }
        var v = r(58974),
          y = r(5340),
          S = r(85893);
        let g = ["onChange"],
          Z = {
            width: 99,
            height: 99,
            position: "absolute",
            top: -9999,
            overflow: "scroll",
          };
        var w = r(88169),
          x = (0, w.Z)(
            (0, S.jsx)("path", {
              d: "M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z",
            }),
            "KeyboardArrowLeft"
          ),
          M = (0, w.Z)(
            (0, S.jsx)("path", {
              d: "M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z",
            }),
            "KeyboardArrowRight"
          ),
          B = r(49990),
          C = r(1588),
          E = r(34867);
        function I(e) {
          return (0, E.ZP)("MuiTabScrollButton", e);
        }
        let W = (0, C.Z)("MuiTabScrollButton", [
            "root",
            "vertical",
            "horizontal",
            "disabled",
          ]),
          P = [
            "className",
            "slots",
            "slotProps",
            "direction",
            "orientation",
            "disabled",
          ],
          T = (e) => {
            let { classes: t, orientation: r, disabled: l } = e;
            return (0, c.Z)({ root: ["root", r, l && "disabled"] }, I, t);
          },
          R = (0, u.ZP)(B.Z, {
            name: "MuiTabScrollButton",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [t.root, r.orientation && t[r.orientation]];
            },
          })(({ ownerState: e }) =>
            (0, n.Z)(
              {
                width: 40,
                flexShrink: 0,
                opacity: 0.8,
                [`&.${W.disabled}`]: { opacity: 0 },
              },
              "vertical" === e.orientation && {
                width: "100%",
                height: 40,
                "& svg": { transform: `rotate(${e.isRtl ? -90 : 90}deg)` },
              }
            )
          ),
          k = i.forwardRef(function (e, t) {
            var r, l;
            let i = (0, f.Z)({ props: e, name: "MuiTabScrollButton" }),
              {
                className: c,
                slots: u = {},
                slotProps: b = {},
                direction: p,
              } = i,
              h = (0, o.Z)(i, P),
              m = (0, d.V)(),
              v = (0, n.Z)({ isRtl: m }, i),
              y = T(v),
              g = null != (r = u.StartScrollButtonIcon) ? r : x,
              Z = null != (l = u.EndScrollButtonIcon) ? l : M,
              w = (0, s.y)({
                elementType: g,
                externalSlotProps: b.startScrollButtonIcon,
                additionalProps: { fontSize: "small" },
                ownerState: v,
              }),
              B = (0, s.y)({
                elementType: Z,
                externalSlotProps: b.endScrollButtonIcon,
                additionalProps: { fontSize: "small" },
                ownerState: v,
              });
            return (0,
            S.jsx)(R, (0, n.Z)({ component: "div", className: (0, a.Z)(y.root, c), ref: t, role: null, ownerState: v, tabIndex: null }, h, { children: "left" === p ? (0, S.jsx)(g, (0, n.Z)({}, w)) : (0, S.jsx)(Z, (0, n.Z)({}, B)) }));
          });
        var N = r(2068),
          L = r(90852),
          _ = r(8038);
        let z = [
            "aria-label",
            "aria-labelledby",
            "action",
            "centered",
            "children",
            "className",
            "component",
            "allowScrollButtonsMobile",
            "indicatorColor",
            "onChange",
            "orientation",
            "ScrollButtonComponent",
            "scrollButtons",
            "selectionFollowsFocus",
            "slots",
            "slotProps",
            "TabIndicatorProps",
            "TabScrollButtonProps",
            "textColor",
            "value",
            "variant",
            "visibleScrollbar",
          ],
          A = (e, t) =>
            e === t
              ? e.firstChild
              : t && t.nextElementSibling
              ? t.nextElementSibling
              : e.firstChild,
          j = (e, t) =>
            e === t
              ? e.lastChild
              : t && t.previousElementSibling
              ? t.previousElementSibling
              : e.lastChild,
          $ = (e, t, r) => {
            let l = !1,
              o = r(e, t);
            for (; o; ) {
              if (o === e.firstChild) {
                if (l) return;
                l = !0;
              }
              let t = o.disabled || "true" === o.getAttribute("aria-disabled");
              if (!o.hasAttribute("tabindex") || t) o = r(e, o);
              else {
                o.focus();
                return;
              }
            }
          },
          H = (e) => {
            let {
              vertical: t,
              fixed: r,
              hideScrollbar: l,
              scrollableX: o,
              scrollableY: n,
              centered: i,
              scrollButtonsHideMobile: a,
              classes: s,
            } = e;
            return (0, c.Z)(
              {
                root: ["root", t && "vertical"],
                scroller: [
                  "scroller",
                  r && "fixed",
                  l && "hideScrollbar",
                  o && "scrollableX",
                  n && "scrollableY",
                ],
                flexContainer: [
                  "flexContainer",
                  t && "flexContainerVertical",
                  i && "centered",
                ],
                indicator: ["indicator"],
                scrollButtons: [
                  "scrollButtons",
                  a && "scrollButtonsHideMobile",
                ],
                scrollableX: [o && "scrollableX"],
                hideScrollbar: [l && "hideScrollbar"],
              },
              L.m,
              s
            );
          },
          D = (0, u.ZP)("div", {
            name: "MuiTabs",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                { [`& .${L.Z.scrollButtons}`]: t.scrollButtons },
                {
                  [`& .${L.Z.scrollButtons}`]:
                    r.scrollButtonsHideMobile && t.scrollButtonsHideMobile,
                },
                t.root,
                r.vertical && t.vertical,
              ];
            },
          })(({ ownerState: e, theme: t }) =>
            (0, n.Z)(
              {
                overflow: "hidden",
                minHeight: 48,
                WebkitOverflowScrolling: "touch",
                display: "flex",
              },
              e.vertical && { flexDirection: "column" },
              e.scrollButtonsHideMobile && {
                [`& .${L.Z.scrollButtons}`]: {
                  [t.breakpoints.down("sm")]: { display: "none" },
                },
              }
            )
          ),
          F = (0, u.ZP)("div", {
            name: "MuiTabs",
            slot: "Scroller",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                t.scroller,
                r.fixed && t.fixed,
                r.hideScrollbar && t.hideScrollbar,
                r.scrollableX && t.scrollableX,
                r.scrollableY && t.scrollableY,
              ];
            },
          })(({ ownerState: e }) =>
            (0, n.Z)(
              {
                position: "relative",
                display: "inline-block",
                flex: "1 1 auto",
                whiteSpace: "nowrap",
              },
              e.fixed && { overflowX: "hidden", width: "100%" },
              e.hideScrollbar && {
                scrollbarWidth: "none",
                "&::-webkit-scrollbar": { display: "none" },
              },
              e.scrollableX && { overflowX: "auto", overflowY: "hidden" },
              e.scrollableY && { overflowY: "auto", overflowX: "hidden" }
            )
          ),
          X = (0, u.ZP)("div", {
            name: "MuiTabs",
            slot: "FlexContainer",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                t.flexContainer,
                r.vertical && t.flexContainerVertical,
                r.centered && t.centered,
              ];
            },
          })(({ ownerState: e }) =>
            (0, n.Z)(
              { display: "flex" },
              e.vertical && { flexDirection: "column" },
              e.centered && { justifyContent: "center" }
            )
          ),
          O = (0, u.ZP)("span", {
            name: "MuiTabs",
            slot: "Indicator",
            overridesResolver: (e, t) => t.indicator,
          })(({ ownerState: e, theme: t }) =>
            (0, n.Z)(
              {
                position: "absolute",
                height: 2,
                bottom: 0,
                width: "100%",
                transition: t.transitions.create(),
              },
              "primary" === e.indicatorColor && {
                backgroundColor: (t.vars || t).palette.primary.main,
              },
              "secondary" === e.indicatorColor && {
                backgroundColor: (t.vars || t).palette.secondary.main,
              },
              e.vertical && { height: "100%", width: 2, right: 0 }
            )
          ),
          Y = (0, u.ZP)(function (e) {
            let { onChange: t } = e,
              r = (0, o.Z)(e, g),
              l = i.useRef(),
              a = i.useRef(null),
              s = () => {
                l.current = a.current.offsetHeight - a.current.clientHeight;
              };
            return (
              (0, v.Z)(() => {
                let e = (0, p.Z)(() => {
                    let e = l.current;
                    s(), e !== l.current && t(l.current);
                  }),
                  r = (0, y.Z)(a.current);
                return (
                  r.addEventListener("resize", e),
                  () => {
                    e.clear(), r.removeEventListener("resize", e);
                  }
                );
              }, [t]),
              i.useEffect(() => {
                s(), t(l.current);
              }, [t]),
              (0, S.jsx)("div", (0, n.Z)({ style: Z, ref: a }, r))
            );
          })({
            overflowX: "auto",
            overflowY: "hidden",
            scrollbarWidth: "none",
            "&::-webkit-scrollbar": { display: "none" },
          }),
          G = {},
          V = i.forwardRef(function (e, t) {
            let r = (0, f.Z)({ props: e, name: "MuiTabs" }),
              l = (0, b.Z)(),
              c = (0, d.V)(),
              {
                "aria-label": u,
                "aria-labelledby": v,
                action: g,
                centered: Z = !1,
                children: w,
                className: x,
                component: M = "div",
                allowScrollButtonsMobile: B = !1,
                indicatorColor: C = "primary",
                onChange: E,
                orientation: I = "horizontal",
                ScrollButtonComponent: W = k,
                scrollButtons: P = "auto",
                selectionFollowsFocus: T,
                slots: R = {},
                slotProps: L = {},
                TabIndicatorProps: V = {},
                TabScrollButtonProps: K = {},
                textColor: q = "primary",
                value: U,
                variant: J = "standard",
                visibleScrollbar: Q = !1,
              } = r,
              ee = (0, o.Z)(r, z),
              et = "scrollable" === J,
              er = "vertical" === I,
              el = er ? "scrollTop" : "scrollLeft",
              eo = er ? "top" : "left",
              en = er ? "bottom" : "right",
              ei = er ? "clientHeight" : "clientWidth",
              ea = er ? "height" : "width",
              es = (0, n.Z)({}, r, {
                component: M,
                allowScrollButtonsMobile: B,
                indicatorColor: C,
                orientation: I,
                vertical: er,
                scrollButtons: P,
                textColor: q,
                variant: J,
                visibleScrollbar: Q,
                fixed: !et,
                hideScrollbar: et && !Q,
                scrollableX: et && !er,
                scrollableY: et && er,
                centered: Z && !et,
                scrollButtonsHideMobile: !B,
              }),
              ec = H(es),
              ed = (0, s.y)({
                elementType: R.StartScrollButtonIcon,
                externalSlotProps: L.startScrollButtonIcon,
                ownerState: es,
              }),
              eu = (0, s.y)({
                elementType: R.EndScrollButtonIcon,
                externalSlotProps: L.endScrollButtonIcon,
                ownerState: es,
              }),
              [ef, eb] = i.useState(!1),
              [ep, eh] = i.useState(G),
              [em, ev] = i.useState(!1),
              [ey, eS] = i.useState(!1),
              [eg, eZ] = i.useState(!1),
              [ew, ex] = i.useState({ overflow: "hidden", scrollbarWidth: 0 }),
              eM = new Map(),
              eB = i.useRef(null),
              eC = i.useRef(null),
              eE = () => {
                let e, t;
                let r = eB.current;
                if (r) {
                  let t = r.getBoundingClientRect();
                  e = {
                    clientWidth: r.clientWidth,
                    scrollLeft: r.scrollLeft,
                    scrollTop: r.scrollTop,
                    scrollLeftNormalized: (function (e, t) {
                      let r = e.scrollLeft;
                      if ("rtl" !== t) return r;
                      let l = h();
                      switch (l) {
                        case "negative":
                          return e.scrollWidth - e.clientWidth + r;
                        case "reverse":
                          return e.scrollWidth - e.clientWidth - r;
                        default:
                          return r;
                      }
                    })(r, c ? "rtl" : "ltr"),
                    scrollWidth: r.scrollWidth,
                    top: t.top,
                    bottom: t.bottom,
                    left: t.left,
                    right: t.right,
                  };
                }
                if (r && !1 !== U) {
                  let e = eC.current.children;
                  if (e.length > 0) {
                    let r = e[eM.get(U)];
                    t = r ? r.getBoundingClientRect() : null;
                  }
                }
                return { tabsMeta: e, tabMeta: t };
              },
              eI = (0, N.Z)(() => {
                let e;
                let { tabsMeta: t, tabMeta: r } = eE(),
                  l = 0;
                if (er)
                  (e = "top"), r && t && (l = r.top - t.top + t.scrollTop);
                else if (((e = c ? "right" : "left"), r && t)) {
                  let o = c
                    ? t.scrollLeftNormalized + t.clientWidth - t.scrollWidth
                    : t.scrollLeft;
                  l = (c ? -1 : 1) * (r[e] - t[e] + o);
                }
                let o = { [e]: l, [ea]: r ? r[ea] : 0 };
                if (isNaN(ep[e]) || isNaN(ep[ea])) eh(o);
                else {
                  let t = Math.abs(ep[e] - o[e]),
                    r = Math.abs(ep[ea] - o[ea]);
                  (t >= 1 || r >= 1) && eh(o);
                }
              }),
              eW = (e, { animation: t = !0 } = {}) => {
                t
                  ? (function (e, t, r, l = {}, o = () => {}) {
                      let { ease: n = m, duration: i = 300 } = l,
                        a = null,
                        s = t[e],
                        c = !1,
                        d = () => {
                          c = !0;
                        },
                        u = (l) => {
                          if (c) {
                            o(Error("Animation cancelled"));
                            return;
                          }
                          null === a && (a = l);
                          let d = Math.min(1, (l - a) / i);
                          if (((t[e] = n(d) * (r - s) + s), d >= 1)) {
                            requestAnimationFrame(() => {
                              o(null);
                            });
                            return;
                          }
                          requestAnimationFrame(u);
                        };
                      return s === r
                        ? (o(Error("Element already at target position")), d)
                        : (requestAnimationFrame(u), d);
                    })(el, eB.current, e, {
                      duration: l.transitions.duration.standard,
                    })
                  : (eB.current[el] = e);
              },
              eP = (e) => {
                let t = eB.current[el];
                er
                  ? (t += e)
                  : ((t += e * (c ? -1 : 1)),
                    (t *= c && "reverse" === h() ? -1 : 1)),
                  eW(t);
              },
              eT = () => {
                let e = eB.current[ei],
                  t = 0,
                  r = Array.from(eC.current.children);
                for (let l = 0; l < r.length; l += 1) {
                  let o = r[l];
                  if (t + o[ei] > e) {
                    0 === l && (t = e);
                    break;
                  }
                  t += o[ei];
                }
                return t;
              },
              eR = () => {
                eP(-1 * eT());
              },
              ek = () => {
                eP(eT());
              },
              eN = i.useCallback((e) => {
                ex({ overflow: null, scrollbarWidth: e });
              }, []),
              eL = (0, N.Z)((e) => {
                let { tabsMeta: t, tabMeta: r } = eE();
                if (r && t) {
                  if (r[eo] < t[eo]) {
                    let l = t[el] + (r[eo] - t[eo]);
                    eW(l, { animation: e });
                  } else if (r[en] > t[en]) {
                    let l = t[el] + (r[en] - t[en]);
                    eW(l, { animation: e });
                  }
                }
              }),
              e_ = (0, N.Z)(() => {
                et && !1 !== P && eZ(!eg);
              });
            i.useEffect(() => {
              let e, t;
              let r = (0, p.Z)(() => {
                  eB.current && eI();
                }),
                l = (t) => {
                  t.forEach((t) => {
                    t.removedNodes.forEach((t) => {
                      var r;
                      null == (r = e) || r.unobserve(t);
                    }),
                      t.addedNodes.forEach((t) => {
                        var r;
                        null == (r = e) || r.observe(t);
                      });
                  }),
                    r(),
                    e_();
                },
                o = (0, y.Z)(eB.current);
              return (
                o.addEventListener("resize", r),
                "undefined" != typeof ResizeObserver &&
                  ((e = new ResizeObserver(r)),
                  Array.from(eC.current.children).forEach((t) => {
                    e.observe(t);
                  })),
                "undefined" != typeof MutationObserver &&
                  (t = new MutationObserver(l)).observe(eC.current, {
                    childList: !0,
                  }),
                () => {
                  var l, n;
                  r.clear(),
                    o.removeEventListener("resize", r),
                    null == (l = t) || l.disconnect(),
                    null == (n = e) || n.disconnect();
                }
              );
            }, [eI, e_]),
              i.useEffect(() => {
                let e = Array.from(eC.current.children),
                  t = e.length;
                if (
                  "undefined" != typeof IntersectionObserver &&
                  t > 0 &&
                  et &&
                  !1 !== P
                ) {
                  let r = e[0],
                    l = e[t - 1],
                    o = { root: eB.current, threshold: 0.99 },
                    n = (e) => {
                      ev(!e[0].isIntersecting);
                    },
                    i = new IntersectionObserver(n, o);
                  i.observe(r);
                  let a = (e) => {
                      eS(!e[0].isIntersecting);
                    },
                    s = new IntersectionObserver(a, o);
                  return (
                    s.observe(l),
                    () => {
                      i.disconnect(), s.disconnect();
                    }
                  );
                }
              }, [et, P, eg, null == w ? void 0 : w.length]),
              i.useEffect(() => {
                eb(!0);
              }, []),
              i.useEffect(() => {
                eI();
              }),
              i.useEffect(() => {
                eL(G !== ep);
              }, [eL, ep]),
              i.useImperativeHandle(
                g,
                () => ({ updateIndicator: eI, updateScrollButtons: e_ }),
                [eI, e_]
              );
            let ez = (0, S.jsx)(
                O,
                (0, n.Z)({}, V, {
                  className: (0, a.Z)(ec.indicator, V.className),
                  ownerState: es,
                  style: (0, n.Z)({}, ep, V.style),
                })
              ),
              eA = 0,
              ej = i.Children.map(w, (e) => {
                if (!i.isValidElement(e)) return null;
                let t = void 0 === e.props.value ? eA : e.props.value;
                eM.set(t, eA);
                let r = t === U;
                return (
                  (eA += 1),
                  i.cloneElement(
                    e,
                    (0, n.Z)(
                      {
                        fullWidth: "fullWidth" === J,
                        indicator: r && !ef && ez,
                        selected: r,
                        selectionFollowsFocus: T,
                        onChange: E,
                        textColor: q,
                        value: t,
                      },
                      1 !== eA || !1 !== U || e.props.tabIndex
                        ? {}
                        : { tabIndex: 0 }
                    )
                  )
                );
              }),
              e$ = (e) => {
                let t = eC.current,
                  r = (0, _.Z)(t).activeElement,
                  l = r.getAttribute("role");
                if ("tab" !== l) return;
                let o = "horizontal" === I ? "ArrowLeft" : "ArrowUp",
                  n = "horizontal" === I ? "ArrowRight" : "ArrowDown";
                switch (
                  ("horizontal" === I &&
                    c &&
                    ((o = "ArrowRight"), (n = "ArrowLeft")),
                  e.key)
                ) {
                  case o:
                    e.preventDefault(), $(t, r, j);
                    break;
                  case n:
                    e.preventDefault(), $(t, r, A);
                    break;
                  case "Home":
                    e.preventDefault(), $(t, null, A);
                    break;
                  case "End":
                    e.preventDefault(), $(t, null, j);
                }
              },
              eH = (() => {
                let e = {};
                e.scrollbarSizeListener = et
                  ? (0, S.jsx)(Y, {
                      onChange: eN,
                      className: (0, a.Z)(ec.scrollableX, ec.hideScrollbar),
                    })
                  : null;
                let t = et && (("auto" === P && (em || ey)) || !0 === P);
                return (
                  (e.scrollButtonStart = t
                    ? (0, S.jsx)(
                        W,
                        (0, n.Z)(
                          {
                            slots: {
                              StartScrollButtonIcon: R.StartScrollButtonIcon,
                            },
                            slotProps: { startScrollButtonIcon: ed },
                            orientation: I,
                            direction: c ? "right" : "left",
                            onClick: eR,
                            disabled: !em,
                          },
                          K,
                          { className: (0, a.Z)(ec.scrollButtons, K.className) }
                        )
                      )
                    : null),
                  (e.scrollButtonEnd = t
                    ? (0, S.jsx)(
                        W,
                        (0, n.Z)(
                          {
                            slots: {
                              EndScrollButtonIcon: R.EndScrollButtonIcon,
                            },
                            slotProps: { endScrollButtonIcon: eu },
                            orientation: I,
                            direction: c ? "left" : "right",
                            onClick: ek,
                            disabled: !ey,
                          },
                          K,
                          { className: (0, a.Z)(ec.scrollButtons, K.className) }
                        )
                      )
                    : null),
                  e
                );
              })();
            return (0,
            S.jsxs)(D, (0, n.Z)({ className: (0, a.Z)(ec.root, x), ownerState: es, ref: t, as: M }, ee, { children: [eH.scrollButtonStart, eH.scrollbarSizeListener, (0, S.jsxs)(F, { className: ec.scroller, ownerState: es, style: { overflow: ew.overflow, [er ? `margin${c ? "Left" : "Right"}` : "marginBottom"]: Q ? void 0 : -ew.scrollbarWidth }, ref: eB, children: [(0, S.jsx)(X, { "aria-label": u, "aria-labelledby": v, "aria-orientation": "vertical" === I ? "vertical" : null, className: ec.flexContainer, ownerState: es, onKeyDown: e$, ref: eC, role: "tablist", children: ej }), ef && ez] }), eH.scrollButtonEnd] }));
          });
        var K = V;
      },
      90852: function (e, t, r) {
        r.d(t, {
          m: function () {
            return n;
          },
        });
        var l = r(1588),
          o = r(34867);
        function n(e) {
          return (0, o.ZP)("MuiTabs", e);
        }
        let i = (0, l.Z)("MuiTabs", [
          "root",
          "vertical",
          "flexContainer",
          "flexContainerVertical",
          "centered",
          "scroller",
          "fixed",
          "scrollableX",
          "scrollableY",
          "hideScrollbar",
          "scrollButtons",
          "scrollButtonsHideMobile",
          "indicator",
        ]);
        t.Z = i;
      },
      63023: function (e, t) {
        Symbol.for("react.element"),
          Symbol.for("react.portal"),
          Symbol.for("react.fragment"),
          Symbol.for("react.strict_mode"),
          Symbol.for("react.profiler"),
          Symbol.for("react.provider"),
          Symbol.for("react.context"),
          Symbol.for("react.server_context"),
          Symbol.for("react.forward_ref"),
          Symbol.for("react.suspense"),
          Symbol.for("react.suspense_list"),
          Symbol.for("react.memo"),
          Symbol.for("react.lazy"),
          Symbol.for("react.offscreen"),
          Symbol.for("react.module.reference");
      },
      76607: function (e, t, r) {
        r(63023);
      },
      57144: function (e, t, r) {
        var l = r(39336);
        t.Z = l.Z;
      },
      8038: function (e, t, r) {
        var l = r(82690);
        t.Z = l.Z;
      },
      5340: function (e, t, r) {
        var l = r(74161);
        t.Z = l.Z;
      },
      58974: function (e, t, r) {
        var l = r(73546);
        t.Z = l.Z;
      },
      39336: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return l;
          },
        });
        function l(e, t = 166) {
          let r;
          function l(...o) {
            let n = () => {
              e.apply(this, o);
            };
            clearTimeout(r), (r = setTimeout(n, t));
          }
          return (
            (l.clear = () => {
              clearTimeout(r);
            }),
            l
          );
        }
      },
    },
  ]);
