!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "97df855f-1fbe-4c89-911a-09f62b7631dd"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-97df855f-1fbe-4c89-911a-09f62b7631dd"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [48649],
    {
      69368: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return $;
          },
        });
        var o = r(63366),
          a = r(87462),
          n = r(67294),
          l = r(90512),
          i = r(94780),
          s = r(2101),
          d = r(21964),
          c = r(88169),
          u = r(85893),
          p = (0, c.Z)(
            (0, u.jsx)("path", {
              d: "M19 5v14H5V5h14m0-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z",
            }),
            "CheckBoxOutlineBlank"
          ),
          h = (0, c.Z)(
            (0, u.jsx)("path", {
              d: "M19 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.11 0 2-.9 2-2V5c0-1.1-.89-2-2-2zm-9 14l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z",
            }),
            "CheckBox"
          ),
          m = (0, c.Z)(
            (0, u.jsx)("path", {
              d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10H7v-2h10v2z",
            }),
            "IndeterminateCheckBox"
          ),
          f = r(98216),
          b = r(71657),
          v = r(90948),
          Z = r(14136),
          g = r(1588),
          y = r(34867);
        function k(e) {
          return (0, y.ZP)("MuiCheckbox", e);
        }
        let x = (0, g.Z)("MuiCheckbox", [
            "root",
            "checked",
            "disabled",
            "indeterminate",
            "colorPrimary",
            "colorSecondary",
            "sizeSmall",
            "sizeMedium",
          ]),
          M = [
            "checkedIcon",
            "color",
            "icon",
            "indeterminate",
            "indeterminateIcon",
            "inputProps",
            "size",
            "className",
          ],
          P = (e) => {
            let { classes: t, indeterminate: r, color: o, size: n } = e,
              l = {
                root: [
                  "root",
                  r && "indeterminate",
                  `color${(0, f.Z)(o)}`,
                  `size${(0, f.Z)(n)}`,
                ],
              },
              s = (0, i.Z)(l, k, t);
            return (0, a.Z)({}, t, s);
          },
          w = (0, v.ZP)(d.Z, {
            shouldForwardProp: (e) => (0, Z.Z)(e) || "classes" === e,
            name: "MuiCheckbox",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                t.root,
                r.indeterminate && t.indeterminate,
                t[`size${(0, f.Z)(r.size)}`],
                "default" !== r.color && t[`color${(0, f.Z)(r.color)}`],
              ];
            },
          })(({ theme: e, ownerState: t }) =>
            (0, a.Z)(
              { color: (e.vars || e).palette.text.secondary },
              !t.disableRipple && {
                "&:hover": {
                  backgroundColor: e.vars
                    ? `rgba(${
                        "default" === t.color
                          ? e.vars.palette.action.activeChannel
                          : e.vars.palette[t.color].mainChannel
                      } / ${e.vars.palette.action.hoverOpacity})`
                    : (0, s.Fq)(
                        "default" === t.color
                          ? e.palette.action.active
                          : e.palette[t.color].main,
                        e.palette.action.hoverOpacity
                      ),
                  "@media (hover: none)": { backgroundColor: "transparent" },
                },
              },
              "default" !== t.color && {
                [`&.${x.checked}, &.${x.indeterminate}`]: {
                  color: (e.vars || e).palette[t.color].main,
                },
                [`&.${x.disabled}`]: {
                  color: (e.vars || e).palette.action.disabled,
                },
              }
            )
          ),
          C = (0, u.jsx)(h, {}),
          R = (0, u.jsx)(p, {}),
          S = (0, u.jsx)(m, {}),
          B = n.forwardRef(function (e, t) {
            var r, i;
            let s = (0, b.Z)({ props: e, name: "MuiCheckbox" }),
              {
                checkedIcon: d = C,
                color: c = "primary",
                icon: p = R,
                indeterminate: h = !1,
                indeterminateIcon: m = S,
                inputProps: f,
                size: v = "medium",
                className: Z,
              } = s,
              g = (0, o.Z)(s, M),
              y = h ? m : p,
              k = h ? m : d,
              x = (0, a.Z)({}, s, { color: c, indeterminate: h, size: v }),
              B = P(x);
            return (0,
            u.jsx)(w, (0, a.Z)({ type: "checkbox", inputProps: (0, a.Z)({ "data-indeterminate": h }, f), icon: n.cloneElement(y, { fontSize: null != (r = y.props.fontSize) ? r : v }), checkedIcon: n.cloneElement(k, { fontSize: null != (i = k.props.fontSize) ? i : v }), ownerState: x, ref: t, className: (0, l.Z)(B.root, Z) }, g, { classes: B }));
          });
        var $ = B;
      },
      47167: function (e, t, r) {
        var o = r(67294);
        let a = o.createContext(void 0);
        t.Z = a;
      },
      15704: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return o;
          },
        });
        function o({ props: e, states: t, muiFormControl: r }) {
          return t.reduce(
            (t, o) => ((t[o] = e[o]), r && void 0 === e[o] && (t[o] = r[o]), t),
            {}
          );
        }
      },
      74423: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return n;
          },
        });
        var o = r(67294),
          a = r(47167);
        function n() {
          return o.useContext(a.Z);
        }
      },
      66836: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return E;
          },
        });
        var o = r(63366),
          a = r(87462),
          n = r(67294),
          l = r(90512),
          i = r(94780),
          s = r(74423),
          d = r(4953),
          c = r(34867),
          u = r(13264),
          p = r(29628),
          h = r(39707),
          m = r(17172),
          f = r(95408),
          b = r(98700),
          v = r(85893);
        let Z = [
            "component",
            "direction",
            "spacing",
            "divider",
            "children",
            "className",
            "useFlexGap",
          ],
          g = (0, m.Z)(),
          y = (0, u.Z)("div", {
            name: "MuiStack",
            slot: "Root",
            overridesResolver: (e, t) => t.root,
          });
        function k(e) {
          return (0, p.Z)({ props: e, name: "MuiStack", defaultTheme: g });
        }
        let x = (e) =>
            ({
              row: "Left",
              "row-reverse": "Right",
              column: "Top",
              "column-reverse": "Bottom",
            }[e]),
          M = ({ ownerState: e, theme: t }) => {
            let r = (0, a.Z)(
              { display: "flex", flexDirection: "column" },
              (0, f.k9)(
                { theme: t },
                (0, f.P$)({
                  values: e.direction,
                  breakpoints: t.breakpoints.values,
                }),
                (e) => ({ flexDirection: e })
              )
            );
            if (e.spacing) {
              let o = (0, b.hB)(t),
                a = Object.keys(t.breakpoints.values).reduce(
                  (t, r) => (
                    (("object" == typeof e.spacing && null != e.spacing[r]) ||
                      ("object" == typeof e.direction &&
                        null != e.direction[r])) &&
                      (t[r] = !0),
                    t
                  ),
                  {}
                ),
                n = (0, f.P$)({ values: e.direction, base: a }),
                l = (0, f.P$)({ values: e.spacing, base: a });
              "object" == typeof n &&
                Object.keys(n).forEach((e, t, r) => {
                  let o = n[e];
                  if (!o) {
                    let o = t > 0 ? n[r[t - 1]] : "column";
                    n[e] = o;
                  }
                });
              let i = (t, r) =>
                e.useFlexGap
                  ? { gap: (0, b.NA)(o, t) }
                  : {
                      "& > :not(style):not(style)": { margin: 0 },
                      "& > :not(style) ~ :not(style)": {
                        [`margin${x(r ? n[r] : e.direction)}`]: (0, b.NA)(o, t),
                      },
                    };
              r = (0, d.Z)(r, (0, f.k9)({ theme: t }, l, i));
            }
            return (0, f.dt)(t.breakpoints, r);
          };
        var P = r(90948),
          w = r(71657);
        let C = (function (e = {}) {
          let {
              createStyledComponent: t = y,
              useThemeProps: r = k,
              componentName: s = "MuiStack",
            } = e,
            d = () => (0, i.Z)({ root: ["root"] }, (e) => (0, c.ZP)(s, e), {}),
            u = t(M),
            p = n.forwardRef(function (e, t) {
              let i = r(e),
                s = (0, h.Z)(i),
                {
                  component: c = "div",
                  direction: p = "column",
                  spacing: m = 0,
                  divider: f,
                  children: b,
                  className: g,
                  useFlexGap: y = !1,
                } = s,
                k = (0, o.Z)(s, Z),
                x = d();
              return (0, v.jsx)(
                u,
                (0, a.Z)(
                  {
                    as: c,
                    ownerState: { direction: p, spacing: m, useFlexGap: y },
                    ref: t,
                    className: (0, l.Z)(x.root, g),
                  },
                  k,
                  {
                    children: f
                      ? (function (e, t) {
                          let r = n.Children.toArray(e).filter(Boolean);
                          return r.reduce(
                            (e, o, a) => (
                              e.push(o),
                              a < r.length - 1 &&
                                e.push(
                                  n.cloneElement(t, { key: `separator-${a}` })
                                ),
                              e
                            ),
                            []
                          );
                        })(b, f)
                      : b,
                  }
                )
              );
            });
          return p;
        })({
          createStyledComponent: (0, P.ZP)("div", {
            name: "MuiStack",
            slot: "Root",
            overridesResolver: (e, t) => t.root,
          }),
          useThemeProps: (e) => (0, w.Z)({ props: e, name: "MuiStack" }),
        });
        var R = r(15861),
          S = r(98216),
          B = r(1588);
        function $(e) {
          return (0, c.ZP)("MuiFormControlLabel", e);
        }
        let j = (0, B.Z)("MuiFormControlLabel", [
          "root",
          "labelPlacementStart",
          "labelPlacementTop",
          "labelPlacementBottom",
          "disabled",
          "label",
          "error",
          "required",
          "asterisk",
        ]);
        var _ = r(15704);
        let z = [
            "checked",
            "className",
            "componentsProps",
            "control",
            "disabled",
            "disableTypography",
            "inputRef",
            "label",
            "labelPlacement",
            "name",
            "onChange",
            "required",
            "slotProps",
            "value",
          ],
          N = (e) => {
            let {
                classes: t,
                disabled: r,
                labelPlacement: o,
                error: a,
                required: n,
              } = e,
              l = {
                root: [
                  "root",
                  r && "disabled",
                  `labelPlacement${(0, S.Z)(o)}`,
                  a && "error",
                  n && "required",
                ],
                label: ["label", r && "disabled"],
                asterisk: ["asterisk", a && "error"],
              };
            return (0, i.Z)(l, $, t);
          },
          F = (0, P.ZP)("label", {
            name: "MuiFormControlLabel",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                { [`& .${j.label}`]: t.label },
                t.root,
                t[`labelPlacement${(0, S.Z)(r.labelPlacement)}`],
              ];
            },
          })(({ theme: e, ownerState: t }) =>
            (0, a.Z)(
              {
                display: "inline-flex",
                alignItems: "center",
                cursor: "pointer",
                verticalAlign: "middle",
                WebkitTapHighlightColor: "transparent",
                marginLeft: -11,
                marginRight: 16,
                [`&.${j.disabled}`]: { cursor: "default" },
              },
              "start" === t.labelPlacement && {
                flexDirection: "row-reverse",
                marginLeft: 16,
                marginRight: -11,
              },
              "top" === t.labelPlacement && {
                flexDirection: "column-reverse",
                marginLeft: 16,
              },
              "bottom" === t.labelPlacement && {
                flexDirection: "column",
                marginLeft: 16,
              },
              {
                [`& .${j.label}`]: {
                  [`&.${j.disabled}`]: {
                    color: (e.vars || e).palette.text.disabled,
                  },
                },
              }
            )
          ),
          I = (0, P.ZP)("span", {
            name: "MuiFormControlLabel",
            slot: "Asterisk",
            overridesResolver: (e, t) => t.asterisk,
          })(({ theme: e }) => ({
            [`&.${j.error}`]: { color: (e.vars || e).palette.error.main },
          })),
          L = n.forwardRef(function (e, t) {
            var r, i;
            let d = (0, w.Z)({ props: e, name: "MuiFormControlLabel" }),
              {
                className: c,
                componentsProps: u = {},
                control: p,
                disabled: h,
                disableTypography: m,
                label: f,
                labelPlacement: b = "end",
                required: Z,
                slotProps: g = {},
              } = d,
              y = (0, o.Z)(d, z),
              k = (0, s.Z)(),
              x =
                null != (r = null != h ? h : p.props.disabled)
                  ? r
                  : null == k
                  ? void 0
                  : k.disabled,
              M = null != Z ? Z : p.props.required,
              P = { disabled: x, required: M };
            ["checked", "name", "onChange", "value", "inputRef"].forEach(
              (e) => {
                void 0 === p.props[e] && void 0 !== d[e] && (P[e] = d[e]);
              }
            );
            let S = (0, _.Z)({
                props: d,
                muiFormControl: k,
                states: ["error"],
              }),
              B = (0, a.Z)({}, d, {
                disabled: x,
                labelPlacement: b,
                required: M,
                error: S.error,
              }),
              $ = N(B),
              j = null != (i = g.typography) ? i : u.typography,
              L = f;
            return (
              null == L ||
                L.type === R.Z ||
                m ||
                (L = (0, v.jsx)(
                  R.Z,
                  (0, a.Z)({ component: "span" }, j, {
                    className: (0, l.Z)(
                      $.label,
                      null == j ? void 0 : j.className
                    ),
                    children: L,
                  })
                )),
              (0, v.jsxs)(
                F,
                (0, a.Z)(
                  { className: (0, l.Z)($.root, c), ownerState: B, ref: t },
                  y,
                  {
                    children: [
                      n.cloneElement(p, P),
                      M
                        ? (0, v.jsxs)(C, {
                            display: "block",
                            children: [
                              L,
                              (0, v.jsxs)(I, {
                                ownerState: B,
                                "aria-hidden": !0,
                                className: $.asterisk,
                                children: [" ", "*"],
                              }),
                            ],
                          })
                        : L,
                    ],
                  }
                )
              )
            );
          });
        var E = L;
      },
      15861: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return M;
          },
        });
        var o = r(63366),
          a = r(87462),
          n = r(67294),
          l = r(90512),
          i = r(39707),
          s = r(94780),
          d = r(90948),
          c = r(71657),
          u = r(98216),
          p = r(1588),
          h = r(34867);
        function m(e) {
          return (0, h.ZP)("MuiTypography", e);
        }
        (0, p.Z)("MuiTypography", [
          "root",
          "h1",
          "h2",
          "h3",
          "h4",
          "h5",
          "h6",
          "subtitle1",
          "subtitle2",
          "body1",
          "body2",
          "inherit",
          "button",
          "caption",
          "overline",
          "alignLeft",
          "alignRight",
          "alignCenter",
          "alignJustify",
          "noWrap",
          "gutterBottom",
          "paragraph",
        ]);
        var f = r(85893);
        let b = [
            "align",
            "className",
            "component",
            "gutterBottom",
            "noWrap",
            "paragraph",
            "variant",
            "variantMapping",
          ],
          v = (e) => {
            let {
                align: t,
                gutterBottom: r,
                noWrap: o,
                paragraph: a,
                variant: n,
                classes: l,
              } = e,
              i = {
                root: [
                  "root",
                  n,
                  "inherit" !== e.align && `align${(0, u.Z)(t)}`,
                  r && "gutterBottom",
                  o && "noWrap",
                  a && "paragraph",
                ],
              };
            return (0, s.Z)(i, m, l);
          },
          Z = (0, d.ZP)("span", {
            name: "MuiTypography",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: r } = e;
              return [
                t.root,
                r.variant && t[r.variant],
                "inherit" !== r.align && t[`align${(0, u.Z)(r.align)}`],
                r.noWrap && t.noWrap,
                r.gutterBottom && t.gutterBottom,
                r.paragraph && t.paragraph,
              ];
            },
          })(({ theme: e, ownerState: t }) =>
            (0, a.Z)(
              { margin: 0 },
              "inherit" === t.variant && { font: "inherit" },
              "inherit" !== t.variant && e.typography[t.variant],
              "inherit" !== t.align && { textAlign: t.align },
              t.noWrap && {
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              },
              t.gutterBottom && { marginBottom: "0.35em" },
              t.paragraph && { marginBottom: 16 }
            )
          ),
          g = {
            h1: "h1",
            h2: "h2",
            h3: "h3",
            h4: "h4",
            h5: "h5",
            h6: "h6",
            subtitle1: "h6",
            subtitle2: "h6",
            body1: "p",
            body2: "p",
            inherit: "p",
          },
          y = {
            primary: "primary.main",
            textPrimary: "text.primary",
            secondary: "secondary.main",
            textSecondary: "text.secondary",
            error: "error.main",
          },
          k = (e) => y[e] || e,
          x = n.forwardRef(function (e, t) {
            let r = (0, c.Z)({ props: e, name: "MuiTypography" }),
              n = k(r.color),
              s = (0, i.Z)((0, a.Z)({}, r, { color: n })),
              {
                align: d = "inherit",
                className: u,
                component: p,
                gutterBottom: h = !1,
                noWrap: m = !1,
                paragraph: y = !1,
                variant: x = "body1",
                variantMapping: M = g,
              } = s,
              P = (0, o.Z)(s, b),
              w = (0, a.Z)({}, s, {
                align: d,
                color: n,
                className: u,
                component: p,
                gutterBottom: h,
                noWrap: m,
                paragraph: y,
                variant: x,
                variantMapping: M,
              }),
              C = p || (y ? "p" : M[x] || g[x]) || "span",
              R = v(w);
            return (0,
            f.jsx)(Z, (0, a.Z)({ as: C, ref: t, ownerState: w, className: (0, l.Z)(R.root, u) }, P));
          });
        var M = x;
      },
      21964: function (e, t, r) {
        r.d(t, {
          Z: function () {
            return M;
          },
        });
        var o = r(63366),
          a = r(87462),
          n = r(67294),
          l = r(90512),
          i = r(94780),
          s = r(98216),
          d = r(90948),
          c = r(14136),
          u = r(49299),
          p = r(74423),
          h = r(49990),
          m = r(1588),
          f = r(34867);
        function b(e) {
          return (0, f.ZP)("PrivateSwitchBase", e);
        }
        (0, m.Z)("PrivateSwitchBase", [
          "root",
          "checked",
          "disabled",
          "input",
          "edgeStart",
          "edgeEnd",
        ]);
        var v = r(85893);
        let Z = [
            "autoFocus",
            "checked",
            "checkedIcon",
            "className",
            "defaultChecked",
            "disabled",
            "disableFocusRipple",
            "edge",
            "icon",
            "id",
            "inputProps",
            "inputRef",
            "name",
            "onBlur",
            "onChange",
            "onFocus",
            "readOnly",
            "required",
            "tabIndex",
            "type",
            "value",
          ],
          g = (e) => {
            let { classes: t, checked: r, disabled: o, edge: a } = e,
              n = {
                root: [
                  "root",
                  r && "checked",
                  o && "disabled",
                  a && `edge${(0, s.Z)(a)}`,
                ],
                input: ["input"],
              };
            return (0, i.Z)(n, b, t);
          },
          y = (0, d.ZP)(h.Z)(({ ownerState: e }) =>
            (0, a.Z)(
              { padding: 9, borderRadius: "50%" },
              "start" === e.edge && {
                marginLeft: "small" === e.size ? -3 : -12,
              },
              "end" === e.edge && { marginRight: "small" === e.size ? -3 : -12 }
            )
          ),
          k = (0, d.ZP)("input", { shouldForwardProp: c.Z })({
            cursor: "inherit",
            position: "absolute",
            opacity: 0,
            width: "100%",
            height: "100%",
            top: 0,
            left: 0,
            margin: 0,
            padding: 0,
            zIndex: 1,
          }),
          x = n.forwardRef(function (e, t) {
            let {
                autoFocus: r,
                checked: n,
                checkedIcon: i,
                className: s,
                defaultChecked: d,
                disabled: c,
                disableFocusRipple: h = !1,
                edge: m = !1,
                icon: f,
                id: b,
                inputProps: x,
                inputRef: M,
                name: P,
                onBlur: w,
                onChange: C,
                onFocus: R,
                readOnly: S,
                required: B = !1,
                tabIndex: $,
                type: j,
                value: _,
              } = e,
              z = (0, o.Z)(e, Z),
              [N, F] = (0, u.Z)({
                controlled: n,
                default: Boolean(d),
                name: "SwitchBase",
                state: "checked",
              }),
              I = (0, p.Z)(),
              L = (e) => {
                R && R(e), I && I.onFocus && I.onFocus(e);
              },
              E = (e) => {
                w && w(e), I && I.onBlur && I.onBlur(e);
              },
              D = (e) => {
                if (e.nativeEvent.defaultPrevented) return;
                let t = e.target.checked;
                F(t), C && C(e, t);
              },
              G = c;
            I && void 0 === G && (G = I.disabled);
            let O = (0, a.Z)({}, e, {
                checked: N,
                disabled: G,
                disableFocusRipple: h,
                edge: m,
              }),
              T = g(O);
            return (0,
            v.jsxs)(y, (0, a.Z)({ component: "span", className: (0, l.Z)(T.root, s), centerRipple: !0, focusRipple: !h, disabled: G, tabIndex: null, role: void 0, onFocus: L, onBlur: E, ownerState: O, ref: t }, z, { children: [(0, v.jsx)(k, (0, a.Z)({ autoFocus: r, checked: n, defaultChecked: d, className: T.input, disabled: G, id: "checkbox" === j || "radio" === j ? b : void 0, name: P, onChange: D, readOnly: S, ref: M, required: B, ownerState: O, tabIndex: $, type: j }, "checkbox" === j && void 0 === _ ? {} : { value: _ }, x)), N ? i : f] }));
          });
        var M = x;
      },
      49299: function (e, t, r) {
        var o = r(19032);
        t.Z = o.Z;
      },
    },
  ]);
