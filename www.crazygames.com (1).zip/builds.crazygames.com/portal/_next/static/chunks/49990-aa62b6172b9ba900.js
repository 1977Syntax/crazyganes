!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "627a2689-9e43-4746-927e-8fc25191726d"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-627a2689-9e43-4746-927e-8fc25191726d"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [49990],
    {
      49990: function (e, t, n) {
        let r, o, i, a;
        n.d(t, {
          Z: function () {
            return S;
          },
        });
        var l = n(87462),
          u = n(63366),
          s = n(67294),
          c = n(90512),
          d = n(94780),
          p = n(90948),
          f = n(71657),
          h = n(51705),
          b = n(2068),
          m = n(79674),
          y = n(73350),
          v = n(70917),
          g = n(46271),
          M = n(85893),
          Z = n(1588);
        let x = (0, Z.Z)("MuiTouchRipple", [
            "root",
            "ripple",
            "rippleVisible",
            "ripplePulsate",
            "child",
            "childLeaving",
            "childPulsate",
          ]),
          E = ["center", "classes", "className"],
          R = (0, v.F4)(
            r ||
              (r = ((e) => e)`
  0% {
    transform: scale(0);
    opacity: 0.1;
  }

  100% {
    transform: scale(1);
    opacity: 0.3;
  }
`)
          ),
          k = (0, v.F4)(
            o ||
              (o = ((e) => e)`
  0% {
    opacity: 1;
  }

  100% {
    opacity: 0;
  }
`)
          ),
          w = (0, v.F4)(
            i ||
              (i = ((e) => e)`
  0% {
    transform: scale(1);
  }

  50% {
    transform: scale(0.92);
  }

  100% {
    transform: scale(1);
  }
`)
          ),
          P = (0, p.ZP)("span", { name: "MuiTouchRipple", slot: "Root" })({
            overflow: "hidden",
            pointerEvents: "none",
            position: "absolute",
            zIndex: 0,
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            borderRadius: "inherit",
          }),
          _ = (0, p.ZP)(
            function (e) {
              let {
                  className: t,
                  classes: n,
                  pulsate: r = !1,
                  rippleX: o,
                  rippleY: i,
                  rippleSize: a,
                  in: l,
                  onExited: u,
                  timeout: d,
                } = e,
                [p, f] = s.useState(!1),
                h = (0, c.Z)(
                  t,
                  n.ripple,
                  n.rippleVisible,
                  r && n.ripplePulsate
                ),
                b = (0, c.Z)(n.child, p && n.childLeaving, r && n.childPulsate);
              return (
                l || p || f(!0),
                s.useEffect(() => {
                  if (!l && null != u) {
                    let e = setTimeout(u, d);
                    return () => {
                      clearTimeout(e);
                    };
                  }
                }, [u, l, d]),
                (0, M.jsx)("span", {
                  className: h,
                  style: {
                    width: a,
                    height: a,
                    top: -(a / 2) + i,
                    left: -(a / 2) + o,
                  },
                  children: (0, M.jsx)("span", { className: b }),
                })
              );
            },
            { name: "MuiTouchRipple", slot: "Ripple" }
          )(
            a ||
              (a = ((e) => e)`
  opacity: 0;
  position: absolute;

  &.${0} {
    opacity: 0.3;
    transform: scale(1);
    animation-name: ${0};
    animation-duration: ${0}ms;
    animation-timing-function: ${0};
  }

  &.${0} {
    animation-duration: ${0}ms;
  }

  & .${0} {
    opacity: 1;
    display: block;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: currentColor;
  }

  & .${0} {
    opacity: 0;
    animation-name: ${0};
    animation-duration: ${0}ms;
    animation-timing-function: ${0};
  }

  & .${0} {
    position: absolute;
    /* @noflip */
    left: 0px;
    top: 0;
    animation-name: ${0};
    animation-duration: 2500ms;
    animation-timing-function: ${0};
    animation-iteration-count: infinite;
    animation-delay: 200ms;
  }
`),
            x.rippleVisible,
            R,
            550,
            ({ theme: e }) => e.transitions.easing.easeInOut,
            x.ripplePulsate,
            ({ theme: e }) => e.transitions.duration.shorter,
            x.child,
            x.childLeaving,
            k,
            550,
            ({ theme: e }) => e.transitions.easing.easeInOut,
            x.childPulsate,
            w,
            ({ theme: e }) => e.transitions.easing.easeInOut
          ),
          C = s.forwardRef(function (e, t) {
            let n = (0, f.Z)({ props: e, name: "MuiTouchRipple" }),
              { center: r = !1, classes: o = {}, className: i } = n,
              a = (0, u.Z)(n, E),
              [d, p] = s.useState([]),
              h = s.useRef(0),
              b = s.useRef(null);
            s.useEffect(() => {
              b.current && (b.current(), (b.current = null));
            }, [d]);
            let m = s.useRef(!1),
              v = (0, g.Z)(),
              Z = s.useRef(null),
              R = s.useRef(null),
              k = s.useCallback(
                (e) => {
                  let {
                    pulsate: t,
                    rippleX: n,
                    rippleY: r,
                    rippleSize: i,
                    cb: a,
                  } = e;
                  p((e) => [
                    ...e,
                    (0, M.jsx)(
                      _,
                      {
                        classes: {
                          ripple: (0, c.Z)(o.ripple, x.ripple),
                          rippleVisible: (0, c.Z)(
                            o.rippleVisible,
                            x.rippleVisible
                          ),
                          ripplePulsate: (0, c.Z)(
                            o.ripplePulsate,
                            x.ripplePulsate
                          ),
                          child: (0, c.Z)(o.child, x.child),
                          childLeaving: (0, c.Z)(
                            o.childLeaving,
                            x.childLeaving
                          ),
                          childPulsate: (0, c.Z)(
                            o.childPulsate,
                            x.childPulsate
                          ),
                        },
                        timeout: 550,
                        pulsate: t,
                        rippleX: n,
                        rippleY: r,
                        rippleSize: i,
                      },
                      h.current
                    ),
                  ]),
                    (h.current += 1),
                    (b.current = a);
                },
                [o]
              ),
              w = s.useCallback(
                (e = {}, t = {}, n = () => {}) => {
                  let o, i, a;
                  let {
                    pulsate: l = !1,
                    center: u = r || t.pulsate,
                    fakeElement: s = !1,
                  } = t;
                  if (
                    (null == e ? void 0 : e.type) === "mousedown" &&
                    m.current
                  ) {
                    m.current = !1;
                    return;
                  }
                  (null == e ? void 0 : e.type) === "touchstart" &&
                    (m.current = !0);
                  let c = s ? null : R.current,
                    d = c
                      ? c.getBoundingClientRect()
                      : { width: 0, height: 0, left: 0, top: 0 };
                  if (
                    !u &&
                    void 0 !== e &&
                    (0 !== e.clientX || 0 !== e.clientY) &&
                    (e.clientX || e.touches)
                  ) {
                    let { clientX: t, clientY: n } =
                      e.touches && e.touches.length > 0 ? e.touches[0] : e;
                    (o = Math.round(t - d.left)), (i = Math.round(n - d.top));
                  } else
                    (o = Math.round(d.width / 2)),
                      (i = Math.round(d.height / 2));
                  if (u)
                    (a = Math.sqrt((2 * d.width ** 2 + d.height ** 2) / 3)) %
                      2 ==
                      0 && (a += 1);
                  else {
                    let e =
                        2 * Math.max(Math.abs((c ? c.clientWidth : 0) - o), o) +
                        2,
                      t =
                        2 *
                          Math.max(Math.abs((c ? c.clientHeight : 0) - i), i) +
                        2;
                    a = Math.sqrt(e ** 2 + t ** 2);
                  }
                  null != e && e.touches
                    ? null === Z.current &&
                      ((Z.current = () => {
                        k({
                          pulsate: l,
                          rippleX: o,
                          rippleY: i,
                          rippleSize: a,
                          cb: n,
                        });
                      }),
                      v.start(80, () => {
                        Z.current && (Z.current(), (Z.current = null));
                      }))
                    : k({
                        pulsate: l,
                        rippleX: o,
                        rippleY: i,
                        rippleSize: a,
                        cb: n,
                      });
                },
                [r, k, v]
              ),
              C = s.useCallback(() => {
                w({}, { pulsate: !0 });
              }, [w]),
              T = s.useCallback(
                (e, t) => {
                  if (
                    (v.clear(),
                    (null == e ? void 0 : e.type) === "touchend" && Z.current)
                  ) {
                    Z.current(),
                      (Z.current = null),
                      v.start(0, () => {
                        T(e, t);
                      });
                    return;
                  }
                  (Z.current = null),
                    p((e) => (e.length > 0 ? e.slice(1) : e)),
                    (b.current = t);
                },
                [v]
              );
            return (
              s.useImperativeHandle(
                t,
                () => ({ pulsate: C, start: w, stop: T }),
                [C, w, T]
              ),
              (0, M.jsx)(
                P,
                (0, l.Z)(
                  { className: (0, c.Z)(x.root, o.root, i), ref: R },
                  a,
                  {
                    children: (0, M.jsx)(y.Z, {
                      component: null,
                      exit: !0,
                      children: d,
                    }),
                  }
                )
              )
            );
          });
        var T = n(34867);
        function j(e) {
          return (0, T.ZP)("MuiButtonBase", e);
        }
        let V = (0, Z.Z)("MuiButtonBase", ["root", "disabled", "focusVisible"]),
          D = [
            "action",
            "centerRipple",
            "children",
            "className",
            "component",
            "disabled",
            "disableRipple",
            "disableTouchRipple",
            "focusRipple",
            "focusVisibleClassName",
            "LinkComponent",
            "onBlur",
            "onClick",
            "onContextMenu",
            "onDragLeave",
            "onFocus",
            "onFocusVisible",
            "onKeyDown",
            "onKeyUp",
            "onMouseDown",
            "onMouseLeave",
            "onMouseUp",
            "onTouchEnd",
            "onTouchMove",
            "onTouchStart",
            "tabIndex",
            "TouchRippleProps",
            "touchRippleRef",
            "type",
          ],
          $ = (e) => {
            let {
                disabled: t,
                focusVisible: n,
                focusVisibleClassName: r,
                classes: o,
              } = e,
              i = (0, d.Z)(
                { root: ["root", t && "disabled", n && "focusVisible"] },
                j,
                o
              );
            return n && r && (i.root += ` ${r}`), i;
          },
          I = (0, p.ZP)("button", {
            name: "MuiButtonBase",
            slot: "Root",
            overridesResolver: (e, t) => t.root,
          })({
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            position: "relative",
            boxSizing: "border-box",
            WebkitTapHighlightColor: "transparent",
            backgroundColor: "transparent",
            outline: 0,
            border: 0,
            margin: 0,
            borderRadius: 0,
            padding: 0,
            cursor: "pointer",
            userSelect: "none",
            verticalAlign: "middle",
            MozAppearance: "none",
            WebkitAppearance: "none",
            textDecoration: "none",
            color: "inherit",
            "&::-moz-focus-inner": { borderStyle: "none" },
            [`&.${V.disabled}`]: { pointerEvents: "none", cursor: "default" },
            "@media print": { colorAdjust: "exact" },
          }),
          O = s.forwardRef(function (e, t) {
            let n = (0, f.Z)({ props: e, name: "MuiButtonBase" }),
              {
                action: r,
                centerRipple: o = !1,
                children: i,
                className: a,
                component: d = "button",
                disabled: p = !1,
                disableRipple: y = !1,
                disableTouchRipple: v = !1,
                focusRipple: g = !1,
                LinkComponent: Z = "a",
                onBlur: x,
                onClick: E,
                onContextMenu: R,
                onDragLeave: k,
                onFocus: w,
                onFocusVisible: P,
                onKeyDown: _,
                onKeyUp: T,
                onMouseDown: j,
                onMouseLeave: V,
                onMouseUp: O,
                onTouchEnd: S,
                onTouchMove: B,
                onTouchStart: F,
                tabIndex: L = 0,
                TouchRippleProps: N,
                touchRippleRef: G,
                type: z,
              } = n,
              A = (0, u.Z)(n, D),
              K = s.useRef(null),
              U = s.useRef(null),
              H = (0, h.Z)(U, G),
              {
                isFocusVisibleRef: W,
                onFocus: X,
                onBlur: q,
                ref: Y,
              } = (0, m.Z)(),
              [J, Q] = s.useState(!1);
            p && J && Q(!1),
              s.useImperativeHandle(
                r,
                () => ({
                  focusVisible: () => {
                    Q(!0), K.current.focus();
                  },
                }),
                []
              );
            let [ee, et] = s.useState(!1);
            function en(e, t, n = v) {
              return (0,
              b.Z)((r) => (t && t(r), !n && U.current && U.current[e](r), !0));
            }
            s.useEffect(() => {
              et(!0);
            }, []),
              s.useEffect(() => {
                J && g && !y && ee && U.current.pulsate();
              }, [y, g, J, ee]);
            let er = en("start", j),
              eo = en("stop", R),
              ei = en("stop", k),
              ea = en("stop", O),
              el = en("stop", (e) => {
                J && e.preventDefault(), V && V(e);
              }),
              eu = en("start", F),
              es = en("stop", S),
              ec = en("stop", B),
              ed = en(
                "stop",
                (e) => {
                  q(e), !1 === W.current && Q(!1), x && x(e);
                },
                !1
              ),
              ep = (0, b.Z)((e) => {
                K.current || (K.current = e.currentTarget),
                  X(e),
                  !0 === W.current && (Q(!0), P && P(e)),
                  w && w(e);
              }),
              ef = () => {
                let e = K.current;
                return d && "button" !== d && !("A" === e.tagName && e.href);
              },
              eh = s.useRef(!1),
              eb = (0, b.Z)((e) => {
                g &&
                  !eh.current &&
                  J &&
                  U.current &&
                  " " === e.key &&
                  ((eh.current = !0),
                  U.current.stop(e, () => {
                    U.current.start(e);
                  })),
                  e.target === e.currentTarget &&
                    ef() &&
                    " " === e.key &&
                    e.preventDefault(),
                  _ && _(e),
                  e.target === e.currentTarget &&
                    ef() &&
                    "Enter" === e.key &&
                    !p &&
                    (e.preventDefault(), E && E(e));
              }),
              em = (0, b.Z)((e) => {
                g &&
                  " " === e.key &&
                  U.current &&
                  J &&
                  !e.defaultPrevented &&
                  ((eh.current = !1),
                  U.current.stop(e, () => {
                    U.current.pulsate(e);
                  })),
                  T && T(e),
                  E &&
                    e.target === e.currentTarget &&
                    ef() &&
                    " " === e.key &&
                    !e.defaultPrevented &&
                    E(e);
              }),
              ey = d;
            "button" === ey && (A.href || A.to) && (ey = Z);
            let ev = {};
            "button" === ey
              ? ((ev.type = void 0 === z ? "button" : z), (ev.disabled = p))
              : (A.href || A.to || (ev.role = "button"),
                p && (ev["aria-disabled"] = p));
            let eg = (0, h.Z)(t, Y, K),
              eM = (0, l.Z)({}, n, {
                centerRipple: o,
                component: d,
                disabled: p,
                disableRipple: y,
                disableTouchRipple: v,
                focusRipple: g,
                tabIndex: L,
                focusVisible: J,
              }),
              eZ = $(eM);
            return (0,
            M.jsxs)(I, (0, l.Z)({ as: ey, className: (0, c.Z)(eZ.root, a), ownerState: eM, onBlur: ed, onClick: E, onContextMenu: eo, onFocus: ep, onKeyDown: eb, onKeyUp: em, onMouseDown: er, onMouseLeave: el, onMouseUp: ea, onDragLeave: ei, onTouchEnd: es, onTouchMove: ec, onTouchStart: eu, ref: eg, tabIndex: p ? -1 : L, type: z }, ev, A, { children: [i, !ee || y || p ? null : (0, M.jsx)(C, (0, l.Z)({ ref: H, center: o }, N))] }));
          });
        var S = O;
      },
      2068: function (e, t, n) {
        var r = n(59948);
        t.Z = r.Z;
      },
      51705: function (e, t, n) {
        var r = n(33703);
        t.Z = r.Z;
      },
      79674: function (e, t, n) {
        var r = n(36728);
        t.Z = r.Z;
      },
      73350: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return f;
          },
        });
        var r = n(63366),
          o = n(87462),
          i = n(97326),
          a = n(94578),
          l = n(67294),
          u = n(220);
        function s(e, t) {
          var n = Object.create(null);
          return (
            e &&
              l.Children.map(e, function (e) {
                return e;
              }).forEach(function (e) {
                n[e.key] = t && (0, l.isValidElement)(e) ? t(e) : e;
              }),
            n
          );
        }
        function c(e, t, n) {
          return null != n[t] ? n[t] : e.props[t];
        }
        var d =
            Object.values ||
            function (e) {
              return Object.keys(e).map(function (t) {
                return e[t];
              });
            },
          p = (function (e) {
            function t(t, n) {
              var r,
                o = (r = e.call(this, t, n) || this).handleExited.bind(
                  (0, i.Z)(r)
                );
              return (
                (r.state = {
                  contextValue: { isMounting: !0 },
                  handleExited: o,
                  firstRender: !0,
                }),
                r
              );
            }
            (0, a.Z)(t, e);
            var n = t.prototype;
            return (
              (n.componentDidMount = function () {
                (this.mounted = !0),
                  this.setState({ contextValue: { isMounting: !1 } });
              }),
              (n.componentWillUnmount = function () {
                this.mounted = !1;
              }),
              (t.getDerivedStateFromProps = function (e, t) {
                var n,
                  r,
                  o = t.children,
                  i = t.handleExited;
                return {
                  children: t.firstRender
                    ? s(e.children, function (t) {
                        return (0,
                        l.cloneElement)(t, { onExited: i.bind(null, t), in: !0, appear: c(t, "appear", e), enter: c(t, "enter", e), exit: c(t, "exit", e) });
                      })
                    : (Object.keys(
                        (r = (function (e, t) {
                          function n(n) {
                            return n in t ? t[n] : e[n];
                          }
                          (e = e || {}), (t = t || {});
                          var r,
                            o = Object.create(null),
                            i = [];
                          for (var a in e)
                            a in t
                              ? i.length && ((o[a] = i), (i = []))
                              : i.push(a);
                          var l = {};
                          for (var u in t) {
                            if (o[u])
                              for (r = 0; r < o[u].length; r++) {
                                var s = o[u][r];
                                l[o[u][r]] = n(s);
                              }
                            l[u] = n(u);
                          }
                          for (r = 0; r < i.length; r++) l[i[r]] = n(i[r]);
                          return l;
                        })(o, (n = s(e.children))))
                      ).forEach(function (t) {
                        var a = r[t];
                        if ((0, l.isValidElement)(a)) {
                          var u = t in o,
                            s = t in n,
                            d = o[t],
                            p = (0, l.isValidElement)(d) && !d.props.in;
                          s && (!u || p)
                            ? (r[t] = (0, l.cloneElement)(a, {
                                onExited: i.bind(null, a),
                                in: !0,
                                exit: c(a, "exit", e),
                                enter: c(a, "enter", e),
                              }))
                            : s || !u || p
                            ? s &&
                              u &&
                              (0, l.isValidElement)(d) &&
                              (r[t] = (0, l.cloneElement)(a, {
                                onExited: i.bind(null, a),
                                in: d.props.in,
                                exit: c(a, "exit", e),
                                enter: c(a, "enter", e),
                              }))
                            : (r[t] = (0, l.cloneElement)(a, { in: !1 }));
                        }
                      }),
                      r),
                  firstRender: !1,
                };
              }),
              (n.handleExited = function (e, t) {
                var n = s(this.props.children);
                e.key in n ||
                  (e.props.onExited && e.props.onExited(t),
                  this.mounted &&
                    this.setState(function (t) {
                      var n = (0, o.Z)({}, t.children);
                      return delete n[e.key], { children: n };
                    }));
              }),
              (n.render = function () {
                var e = this.props,
                  t = e.component,
                  n = e.childFactory,
                  o = (0, r.Z)(e, ["component", "childFactory"]),
                  i = this.state.contextValue,
                  a = d(this.state.children).map(n);
                return (delete o.appear,
                delete o.enter,
                delete o.exit,
                null === t)
                  ? l.createElement(u.Z.Provider, { value: i }, a)
                  : l.createElement(
                      u.Z.Provider,
                      { value: i },
                      l.createElement(t, o, a)
                    );
              }),
              t
            );
          })(l.Component);
        (p.propTypes = {}),
          (p.defaultProps = {
            component: "div",
            childFactory: function (e) {
              return e;
            },
          });
        var f = p;
      },
      220: function (e, t, n) {
        var r = n(67294);
        t.Z = r.createContext(null);
      },
      97326: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return r;
          },
        });
        function r(e) {
          if (void 0 === e)
            throw ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return e;
        }
      },
      94578: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return o;
          },
        });
        var r = n(89611);
        function o(e, t) {
          (e.prototype = Object.create(t.prototype)),
            (e.prototype.constructor = e),
            (0, r.Z)(e, t);
        }
      },
      89611: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return r;
          },
        });
        function r(e, t) {
          return (r = Object.setPrototypeOf
            ? Object.setPrototypeOf.bind()
            : function (e, t) {
                return (e.__proto__ = t), e;
              })(e, t);
        }
      },
    },
  ]);
