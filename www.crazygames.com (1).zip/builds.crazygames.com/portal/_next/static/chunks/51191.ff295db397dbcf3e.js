!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "7346e218-2646-4f8c-9206-60aeefb3119d"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-7346e218-2646-4f8c-9206-60aeefb3119d"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [51191],
    {
      10914: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.RawSha256 = void 0);
        var r = n(89945),
          o = (function () {
            function e() {
              (this.state = Int32Array.from(r.INIT)),
                (this.temp = new Int32Array(64)),
                (this.buffer = new Uint8Array(64)),
                (this.bufferLength = 0),
                (this.bytesHashed = 0),
                (this.finished = !1);
            }
            return (
              (e.prototype.update = function (e) {
                if (this.finished)
                  throw Error("Attempted to update an already finished hash.");
                var t = 0,
                  n = e.byteLength;
                if (
                  ((this.bytesHashed += n),
                  8 * this.bytesHashed > r.MAX_HASHABLE_LENGTH)
                )
                  throw Error("Cannot hash more than 2^53 - 1 bits");
                for (; n > 0; )
                  (this.buffer[this.bufferLength++] = e[t++]),
                    n--,
                    this.bufferLength === r.BLOCK_SIZE &&
                      (this.hashBuffer(), (this.bufferLength = 0));
              }),
              (e.prototype.digest = function () {
                if (!this.finished) {
                  var e = 8 * this.bytesHashed,
                    t = new DataView(
                      this.buffer.buffer,
                      this.buffer.byteOffset,
                      this.buffer.byteLength
                    ),
                    n = this.bufferLength;
                  if (
                    (t.setUint8(this.bufferLength++, 128),
                    n % r.BLOCK_SIZE >= r.BLOCK_SIZE - 8)
                  ) {
                    for (var o = this.bufferLength; o < r.BLOCK_SIZE; o++)
                      t.setUint8(o, 0);
                    this.hashBuffer(), (this.bufferLength = 0);
                  }
                  for (var o = this.bufferLength; o < r.BLOCK_SIZE - 8; o++)
                    t.setUint8(o, 0);
                  t.setUint32(r.BLOCK_SIZE - 8, Math.floor(e / 4294967296), !0),
                    t.setUint32(r.BLOCK_SIZE - 4, e),
                    this.hashBuffer(),
                    (this.finished = !0);
                }
                for (var i = new Uint8Array(r.DIGEST_LENGTH), o = 0; o < 8; o++)
                  (i[4 * o] = (this.state[o] >>> 24) & 255),
                    (i[4 * o + 1] = (this.state[o] >>> 16) & 255),
                    (i[4 * o + 2] = (this.state[o] >>> 8) & 255),
                    (i[4 * o + 3] = (this.state[o] >>> 0) & 255);
                return i;
              }),
              (e.prototype.hashBuffer = function () {
                for (
                  var e = this.buffer,
                    t = this.state,
                    n = t[0],
                    o = t[1],
                    i = t[2],
                    s = t[3],
                    a = t[4],
                    u = t[5],
                    c = t[6],
                    f = t[7],
                    l = 0;
                  l < r.BLOCK_SIZE;
                  l++
                ) {
                  if (l < 16)
                    this.temp[l] =
                      ((255 & e[4 * l]) << 24) |
                      ((255 & e[4 * l + 1]) << 16) |
                      ((255 & e[4 * l + 2]) << 8) |
                      (255 & e[4 * l + 3]);
                  else {
                    var p = this.temp[l - 2],
                      h =
                        ((p >>> 17) | (p << 15)) ^
                        ((p >>> 19) | (p << 13)) ^
                        (p >>> 10),
                      d =
                        (((p = this.temp[l - 15]) >>> 7) | (p << 25)) ^
                        ((p >>> 18) | (p << 14)) ^
                        (p >>> 3);
                    this.temp[l] =
                      ((h + this.temp[l - 7]) | 0) +
                      ((d + this.temp[l - 16]) | 0);
                  }
                  var y =
                      ((((((a >>> 6) | (a << 26)) ^
                        ((a >>> 11) | (a << 21)) ^
                        ((a >>> 25) | (a << 7))) +
                        ((a & u) ^ (~a & c))) |
                        0) +
                        ((f + ((r.KEY[l] + this.temp[l]) | 0)) | 0)) |
                      0,
                    v =
                      ((((n >>> 2) | (n << 30)) ^
                        ((n >>> 13) | (n << 19)) ^
                        ((n >>> 22) | (n << 10))) +
                        ((n & o) ^ (n & i) ^ (o & i))) |
                      0;
                  (f = c),
                    (c = u),
                    (u = a),
                    (a = (s + y) | 0),
                    (s = i),
                    (i = o),
                    (o = n),
                    (n = (y + v) | 0);
                }
                (t[0] += n),
                  (t[1] += o),
                  (t[2] += i),
                  (t[3] += s),
                  (t[4] += a),
                  (t[5] += u),
                  (t[6] += c),
                  (t[7] += f);
              }),
              e
            );
          })();
        t.RawSha256 = o;
      },
      89945: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.MAX_HASHABLE_LENGTH =
            t.INIT =
            t.KEY =
            t.DIGEST_LENGTH =
            t.BLOCK_SIZE =
              void 0),
          (t.BLOCK_SIZE = 64),
          (t.DIGEST_LENGTH = 32),
          (t.KEY = new Uint32Array([
            1116352408, 1899447441, 3049323471, 3921009573, 961987163,
            1508970993, 2453635748, 2870763221, 3624381080, 310598401,
            607225278, 1426881987, 1925078388, 2162078206, 2614888103,
            3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983,
            1249150122, 1555081692, 1996064986, 2554220882, 2821834349,
            2952996808, 3210313671, 3336571891, 3584528711, 113926993,
            338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700,
            1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
            3259730800, 3345764771, 3516065817, 3600352804, 4094571909,
            275423344, 430227734, 506948616, 659060556, 883997877, 958139571,
            1322822218, 1537002063, 1747873779, 1955562222, 2024104815,
            2227730452, 2361852424, 2428436474, 2756734187, 3204031479,
            3329325298,
          ])),
          (t.INIT = [
            1779033703, 3144134277, 1013904242, 2773480762, 1359893119,
            2600822924, 528734635, 1541459225,
          ]),
          (t.MAX_HASHABLE_LENGTH = 9007199254740991);
      },
      41938: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (0, n(70655).__exportStar)(n(65430), t);
      },
      65430: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.Sha256 = void 0);
        var r = n(70655),
          o = n(89945),
          i = n(10914),
          s = n(17658),
          a = (function () {
            function e(e) {
              if (((this.hash = new i.RawSha256()), e)) {
                this.outer = new i.RawSha256();
                var t = (function (e) {
                    var t = (0, s.convertToBuffer)(e);
                    if (t.byteLength > o.BLOCK_SIZE) {
                      var n = new i.RawSha256();
                      n.update(t), (t = n.digest());
                    }
                    var r = new Uint8Array(o.BLOCK_SIZE);
                    return r.set(t), r;
                  })(e),
                  n = new Uint8Array(o.BLOCK_SIZE);
                n.set(t);
                for (var r = 0; r < o.BLOCK_SIZE; r++)
                  (t[r] ^= 54), (n[r] ^= 92);
                this.hash.update(t), this.outer.update(n);
                for (var r = 0; r < t.byteLength; r++) t[r] = 0;
              }
            }
            return (
              (e.prototype.update = function (e) {
                if (!(0, s.isEmptyData)(e) && !this.error)
                  try {
                    this.hash.update((0, s.convertToBuffer)(e));
                  } catch (e) {
                    this.error = e;
                  }
              }),
              (e.prototype.digestSync = function () {
                if (this.error) throw this.error;
                return this.outer
                  ? (this.outer.finished ||
                      this.outer.update(this.hash.digest()),
                    this.outer.digest())
                  : this.hash.digest();
              }),
              (e.prototype.digest = function () {
                return (0, r.__awaiter)(this, void 0, void 0, function () {
                  return (0, r.__generator)(this, function (e) {
                    return [2, this.digestSync()];
                  });
                });
              }),
              e
            );
          })();
        t.Sha256 = a;
      },
      51106: function (e, t, n) {
        "use strict";
        var r = n(48764).lW;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.convertToBuffer = void 0);
        var o = n(19193),
          i =
            void 0 !== r && r.from
              ? function (e) {
                  return r.from(e, "utf8");
                }
              : o.fromUtf8;
        t.convertToBuffer = function (e) {
          return e instanceof Uint8Array
            ? e
            : "string" == typeof e
            ? i(e)
            : ArrayBuffer.isView(e)
            ? new Uint8Array(
                e.buffer,
                e.byteOffset,
                e.byteLength / Uint8Array.BYTES_PER_ELEMENT
              )
            : new Uint8Array(e);
        };
      },
      17658: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.uint32ArrayFrom =
            t.numToUint8 =
            t.isEmptyData =
            t.convertToBuffer =
              void 0);
        var r = n(51106);
        Object.defineProperty(t, "convertToBuffer", {
          enumerable: !0,
          get: function () {
            return r.convertToBuffer;
          },
        });
        var o = n(84304);
        Object.defineProperty(t, "isEmptyData", {
          enumerable: !0,
          get: function () {
            return o.isEmptyData;
          },
        });
        var i = n(22174);
        Object.defineProperty(t, "numToUint8", {
          enumerable: !0,
          get: function () {
            return i.numToUint8;
          },
        });
        var s = n(81558);
        Object.defineProperty(t, "uint32ArrayFrom", {
          enumerable: !0,
          get: function () {
            return s.uint32ArrayFrom;
          },
        });
      },
      84304: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.isEmptyData = void 0),
          (t.isEmptyData = function (e) {
            return "string" == typeof e ? 0 === e.length : 0 === e.byteLength;
          });
      },
      22174: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.numToUint8 = void 0),
          (t.numToUint8 = function (e) {
            return new Uint8Array([
              (4278190080 & e) >> 24,
              (16711680 & e) >> 16,
              (65280 & e) >> 8,
              255 & e,
            ]);
          });
      },
      81558: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.uint32ArrayFrom = void 0),
          (t.uint32ArrayFrom = function (e) {
            if (!Array.from) {
              for (var t = new Uint32Array(e.length); 0 < e.length; )
                t[0] = e[0];
              return t;
            }
            return Uint32Array.from(e);
          });
      },
      51389: function (e, t, n) {
        "use strict";
        n.d(t, {
          N: function () {
            return i;
          },
        });
        let r = {},
          o = {};
        for (let e = 0; e < 256; e++) {
          let t = e.toString(16).toLowerCase();
          1 === t.length && (t = `0${t}`), (r[e] = t), (o[t] = e);
        }
        function i(e) {
          let t = "";
          for (let n = 0; n < e.byteLength; n++) t += r[e[n]];
          return t;
        }
      },
      19193: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            fromUtf8: function () {
              return i;
            },
            toUtf8: function () {
              return s;
            },
          });
        let r = (e) => {
            let t = [];
            for (let n = 0, r = e.length; n < r; n++) {
              let r = e.charCodeAt(n);
              if (r < 128) t.push(r);
              else if (r < 2048) t.push((r >> 6) | 192, (63 & r) | 128);
              else if (
                n + 1 < e.length &&
                (64512 & r) == 55296 &&
                (64512 & e.charCodeAt(n + 1)) == 56320
              ) {
                let o = 65536 + ((1023 & r) << 10) + (1023 & e.charCodeAt(++n));
                t.push(
                  (o >> 18) | 240,
                  ((o >> 12) & 63) | 128,
                  ((o >> 6) & 63) | 128,
                  (63 & o) | 128
                );
              } else
                t.push((r >> 12) | 224, ((r >> 6) & 63) | 128, (63 & r) | 128);
            }
            return Uint8Array.from(t);
          },
          o = (e) => {
            let t = "";
            for (let n = 0, r = e.length; n < r; n++) {
              let r = e[n];
              if (r < 128) t += String.fromCharCode(r);
              else if (192 <= r && r < 224) {
                let o = e[++n];
                t += String.fromCharCode(((31 & r) << 6) | (63 & o));
              } else if (240 <= r && r < 365) {
                let o = [r, e[++n], e[++n], e[++n]],
                  i = "%" + o.map((e) => e.toString(16)).join("%");
                t += decodeURIComponent(i);
              } else
                t += String.fromCharCode(
                  ((15 & r) << 12) | ((63 & e[++n]) << 6) | (63 & e[++n])
                );
            }
            return t;
          },
          i = (e) =>
            "function" == typeof TextEncoder
              ? new TextEncoder().encode(e)
              : r(e),
          s = (e) =>
            "function" == typeof TextDecoder
              ? new TextDecoder("utf-8").decode(e)
              : o(e);
      },
      88976: function (e, t, n) {
        "use strict";
        var r,
          o,
          i,
          s =
            (this && this.__extends) ||
            ((o = function (e, t) {
              return (o =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
                })(e, t);
            }),
            function (e, t) {
              function n() {
                this.constructor = e;
              }
              o(e, t),
                (e.prototype =
                  null === t
                    ? Object.create(t)
                    : ((n.prototype = t.prototype), new n()));
            }),
          a =
            (this && this.__assign) ||
            function () {
              return (a =
                Object.assign ||
                function (e) {
                  for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var o in (t = arguments[n]))
                      Object.prototype.hasOwnProperty.call(t, o) &&
                        (e[o] = t[o]);
                  return e;
                }).apply(this, arguments);
            },
          u =
            (this && this.__awaiter) ||
            function (e, t, n, r) {
              return new (n || (n = Promise))(function (o, i) {
                function s(e) {
                  try {
                    u(r.next(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function a(e) {
                  try {
                    u(r.throw(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function u(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value) instanceof n
                        ? t
                        : new n(function (e) {
                            e(t);
                          })
                      ).then(s, a);
                }
                u((r = r.apply(e, t || [])).next());
              });
            },
          c =
            (this && this.__generator) ||
            function (e, t) {
              var n,
                r,
                o,
                i,
                s = {
                  label: 0,
                  sent: function () {
                    if (1 & o[0]) throw o[1];
                    return o[1];
                  },
                  trys: [],
                  ops: [],
                };
              return (
                (i = { next: a(0), throw: a(1), return: a(2) }),
                "function" == typeof Symbol &&
                  (i[Symbol.iterator] = function () {
                    return this;
                  }),
                i
              );
              function a(i) {
                return function (a) {
                  return (function (i) {
                    if (n) throw TypeError("Generator is already executing.");
                    for (; s; )
                      try {
                        if (
                          ((n = 1),
                          r &&
                            (o =
                              2 & i[0]
                                ? r.return
                                : i[0]
                                ? r.throw || ((o = r.return) && o.call(r), 0)
                                : r.next) &&
                            !(o = o.call(r, i[1])).done)
                        )
                          return o;
                        switch (
                          ((r = 0), o && (i = [2 & i[0], o.value]), i[0])
                        ) {
                          case 0:
                          case 1:
                            o = i;
                            break;
                          case 4:
                            return s.label++, { value: i[1], done: !1 };
                          case 5:
                            s.label++, (r = i[1]), (i = [0]);
                            continue;
                          case 7:
                            (i = s.ops.pop()), s.trys.pop();
                            continue;
                          default:
                            if (
                              !(o =
                                (o = s.trys).length > 0 && o[o.length - 1]) &&
                              (6 === i[0] || 2 === i[0])
                            ) {
                              s = 0;
                              continue;
                            }
                            if (
                              3 === i[0] &&
                              (!o || (i[1] > o[0] && i[1] < o[3]))
                            ) {
                              s.label = i[1];
                              break;
                            }
                            if (6 === i[0] && s.label < o[1]) {
                              (s.label = o[1]), (o = i);
                              break;
                            }
                            if (o && s.label < o[2]) {
                              (s.label = o[2]), s.ops.push(i);
                              break;
                            }
                            o[2] && s.ops.pop(), s.trys.pop();
                            continue;
                        }
                        i = t.call(e, s);
                      } catch (e) {
                        (i = [6, e]), (r = 0);
                      } finally {
                        n = o = 0;
                      }
                    if (5 & i[0]) throw i[1];
                    return { value: i[0] ? i[1] : void 0, done: !0 };
                  })([i, a]);
                };
              }
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        /*!
         * Copyright 2017-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
         * SPDX-License-Identifier: Apache-2.0
         */ var f = n(34153),
          l = n(16918),
          p = n(58273),
          h = n(11987),
          d = n(80394),
          y = n(48910);
        (t.USER_AGENT_HEADER = "x-amz-user-agent"),
          (t.USER_AGENT =
            "aws-amplify/" + y.version + (d.userAgent && " ") + d.userAgent),
          ((r = i = t.AUTH_TYPE || (t.AUTH_TYPE = {})).NONE = "NONE"),
          (r.API_KEY = "API_KEY"),
          (r.AWS_IAM = "AWS_IAM"),
          (r.AMAZON_COGNITO_USER_POOLS = "AMAZON_COGNITO_USER_POOLS"),
          (r.OPENID_CONNECT = "OPENID_CONNECT"),
          (r.AWS_LAMBDA = "AWS_LAMBDA");
        var v = (function (e) {
          function n(n) {
            var r = e.call(this) || this;
            return (r.link = t.authLink(n)), r;
          }
          return (
            s(n, e),
            (n.prototype.request = function (e, t) {
              return this.link.request(e, t);
            }),
            n
          );
        })(f.ApolloLink);
        t.AuthLink = v;
        var g = function (e, n, r) {
            var o = void 0 === e ? { header: "", value: "" } : e,
              i = o.header,
              s = o.value;
            return u(void 0, void 0, void 0, function () {
              var e, o, u, f, l, p;
              return c(this, function (c) {
                switch (c.label) {
                  case 0:
                    if (
                      ((o = a(
                        a({}, (e = n.getContext()).headers),
                        (((l = {})[t.USER_AGENT_HEADER] = t.USER_AGENT), l)
                      )),
                      !(i && s))
                    )
                      return [3, 5];
                    if ("function" != typeof s) return [3, 2];
                    return [4, s.call(void 0)];
                  case 1:
                    return (f = c.sent()), [3, 4];
                  case 2:
                    return [4, s];
                  case 3:
                    (f = c.sent()), (c.label = 4);
                  case 4:
                    (u = f), (o = a((((p = {})[i] = u), p), o)), (c.label = 5);
                  case 5:
                    return n.setContext(a(a({}, e), { headers: o })), [2, r(n)];
                }
              });
            });
          },
          m = function (e, n, r) {
            var o = e.credentials,
              i = e.region,
              s = e.url;
            return u(void 0, void 0, void 0, function () {
              var e, u, f, l, d, y, v, g, m, b, E, T, O;
              return c(this, function (c) {
                switch (c.label) {
                  case 0:
                    if (
                      ((e = "appsync"),
                      (u = n.getContext()),
                      !(
                        (f = "function" == typeof o ? o.call() : o || {}) &&
                        "function" == typeof f.getPromise
                      ))
                    )
                      return [3, 2];
                    return [4, f.getPromise()];
                  case 1:
                    c.sent(), (c.label = 2);
                  case 2:
                    return [4, f];
                  case 3:
                    return (
                      (d = (l = c.sent()).accessKeyId),
                      (y = l.secretAccessKey),
                      (v = l.sessionToken),
                      (m = (g = h.parse(s)).host),
                      (b = g.path),
                      (E = a(a({}, _(n, {})), {
                        service: e,
                        region: i,
                        url: s,
                        host: m,
                        path: b,
                      })),
                      (T = p.Signer.sign(E, {
                        access_key: d,
                        secret_key: y,
                        session_token: v,
                      }).headers),
                      n.setContext(
                        a(a({}, u), {
                          headers: a(
                            a(a({}, u.headers), T),
                            (((O = {})[t.USER_AGENT_HEADER] = t.USER_AGENT), O)
                          ),
                        })
                      ),
                      [2, r(n)]
                    );
                }
              });
            });
          };
        t.authLink = function (e) {
          var t = e.url,
            n = e.region,
            r = e.auth,
            o = (void 0 === r ? {} : r).type,
            s = e.auth;
          return new f.ApolloLink(function (e, r) {
            return new f.Observable(function (a) {
              switch (o) {
                case i.NONE:
                  c = g(void 0, e, r);
                  break;
                case i.AWS_IAM:
                  var u,
                    c,
                    f = s.credentials;
                  c = m(
                    { credentials: void 0 === f ? {} : f, region: n, url: t },
                    e,
                    r
                  );
                  break;
                case i.API_KEY:
                  var l = s.apiKey;
                  c = g(
                    { header: "X-Api-Key", value: void 0 === l ? "" : l },
                    e,
                    r
                  );
                  break;
                case i.AMAZON_COGNITO_USER_POOLS:
                case i.OPENID_CONNECT:
                  var p = s.jwtToken;
                  c = g(
                    { header: "Authorization", value: void 0 === p ? "" : p },
                    e,
                    r
                  );
                  break;
                case i.AWS_LAMBDA:
                  var h = s.token;
                  c = g(
                    { header: "Authorization", value: void 0 === h ? "" : h },
                    e,
                    r
                  );
                  break;
                default:
                  throw Error("Invalid AUTH_TYPE: " + s.type);
              }
              return (
                c.then(function (e) {
                  u = e.subscribe({
                    next: a.next.bind(a),
                    error: a.error.bind(a),
                    complete: a.complete.bind(a),
                  });
                }),
                function () {
                  u && u.unsubscribe();
                }
              );
            });
          });
        };
        var _ = function (e, t) {
            var n = e.operationName,
              r = e.variables,
              o = e.query;
            return a(
              a(
                {
                  body: JSON.stringify({
                    operationName: n,
                    variables: b(r),
                    query: l.print(o),
                  }),
                  method: "POST",
                },
                t
              ),
              {
                headers: a(
                  {
                    accept: "*/*",
                    "content-type": "application/json; charset=UTF-8",
                  },
                  t.headers
                ),
              }
            );
          },
          b = function (e) {
            return Object.keys(e)
              .filter(function (e) {
                return !e.startsWith("@@");
              })
              .reduce(function (t, n) {
                return (t[n] = e[n]), t;
              }, {});
          };
      },
      10638: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        var r = n(88976);
        (t.AuthLink = r.AuthLink),
          (t.AUTH_TYPE = r.AUTH_TYPE),
          (t.USER_AGENT_HEADER = r.USER_AGENT_HEADER),
          (t.USER_AGENT = r.USER_AGENT),
          (t.createAuthLink = function (e) {
            var t = e.url,
              n = e.region,
              o = e.auth;
            return new r.AuthLink({ url: t, region: n, auth: o });
          });
        var o = n(58273);
        t.Signer = o.Signer;
      },
      80394: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.userAgent = "");
      },
      58273: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          /*!
           * Copyright 2017-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
           * SPDX-License-Identifier: Apache-2.0
           */ (function (e) {
            for (var n in e) t.hasOwnProperty(n) || (t[n] = e[n]);
          })(n(73385));
      },
      73385: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (n.g.Buffer = n.g.Buffer || n(48764).lW);
        var r = n(11987),
          o = n(41938).Sha256,
          i = n(51389).N,
          s = function (e, t, n) {
            void 0 === n && (n = "");
            var r = new o(e);
            r.update(t);
            var s = r.digestSync();
            return "hex" === n ? i(s) : s;
          },
          a = function (e) {
            var t = new o();
            return t.update(e || ""), i(t.digestSync());
          },
          u = function (e) {
            return Object.keys(e)
              .map(function (e) {
                return e.toLowerCase();
              })
              .sort()
              .join(";");
          },
          c = function (e) {
            var t,
              n = r.parse(e.url);
            return [
              e.method || "/",
              n.path,
              n.query,
              (t = e.headers) && 0 !== Object.keys(t).length
                ? Object.keys(t)
                    .map(function (e) {
                      return {
                        key: e.toLowerCase(),
                        value: t[e] ? t[e].trim().replace(/\s+/g, " ") : "",
                      };
                    })
                    .sort(function (e, t) {
                      return e.key < t.key ? -1 : 1;
                    })
                    .map(function (e) {
                      return e.key + ":" + e.value;
                    })
                    .join("\n") + "\n"
                : "",
              u(e.headers),
              a(e.body),
            ].join("\n");
          },
          f = function (e) {
            var t = (
              r
                .parse(e.url)
                .host.match(/([^.]+)\.(?:([^.]*)\.)?amazonaws\.com$/) || []
            ).slice(1, 3);
            return (
              "es" === t[1] && (t = t.reverse()),
              { service: e.service || t[0], region: e.region || t[1] }
            );
          },
          l = function (e, t, n) {
            void 0 === e && (e = "");
            var r = s("AWS4" + e, t),
              o = s(r, n.region),
              i = s(o, n.service);
            return s(i, "aws4_request");
          },
          p = function (e, t, n) {
            void 0 === n && (n = null), (e.headers = e.headers || {});
            var o,
              i,
              p = new Date().toISOString().replace(/[:-]|\.\d{3}/g, ""),
              h = p.substr(0, 8),
              d = "AWS4-HMAC-SHA256",
              y = r.parse(e.url);
            (e.headers.host = y.host),
              (e.headers["x-amz-date"] = p),
              t.session_token &&
                (e.headers["X-Amz-Security-Token"] = t.session_token);
            var v = c(e),
              g = [h, (n = n || f(e)).region, n.service, "aws4_request"].join(
                "/"
              ),
              m = [d, p, g, a(v)].join("\n"),
              _ = l(t.secret_key, h, n),
              b = s(_, m, "hex"),
              E =
                ((o = t.access_key),
                (i = u(e.headers)),
                void 0 === o && (o = ""),
                [
                  d + " Credential=" + o + "/" + g,
                  "SignedHeaders=" + i,
                  "Signature=" + b,
                ].join(", "));
            return (e.headers.Authorization = E), e;
          },
          h = (function () {
            function e() {}
            return (e.sign = p), e;
          })();
        (t.Signer = h), (t.default = h);
      },
      51191: function (e, t, n) {
        "use strict";
        var r =
          (this && this.__rest) ||
          function (e, t) {
            var n = {};
            for (var r in e)
              Object.prototype.hasOwnProperty.call(e, r) &&
                0 > t.indexOf(r) &&
                (n[r] = e[r]);
            if (null != e && "function" == typeof Object.getOwnPropertySymbols)
              for (
                var o = 0, r = Object.getOwnPropertySymbols(e);
                o < r.length;
                o++
              )
                0 > t.indexOf(r[o]) &&
                  Object.prototype.propertyIsEnumerable.call(e, r[o]) &&
                  (n[r[o]] = e[r[o]]);
            return n;
          };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var o = n(85149);
        t.CONTROL_EVENTS_KEY = o.CONTROL_EVENTS_KEY;
        var i = n(34153),
          s = n(38802),
          a = n(10269),
          u = n(75171),
          c = n(41663);
        t.createSubscriptionHandshakeLink = function (e, t) {
          var n, f;
          if ("string" == typeof e)
            (n = t || s.createHttpLink({ uri: e })),
              (f = i.ApolloLink.from([
                new u.NonTerminatingLink("controlMessages", {
                  link: new i.ApolloLink(function (e, t) {
                    return new i.Observable(function (t) {
                      var n,
                        i = e.variables,
                        s = o.CONTROL_EVENTS_KEY,
                        a = i[s],
                        u = r(i, ["symbol" == typeof s ? s : s + ""]);
                      return (
                        void 0 !== a && (e.variables = u),
                        t.next((((n = {})[o.CONTROL_EVENTS_KEY] = a), n)),
                        function () {}
                      );
                    });
                  }),
                }),
                new u.NonTerminatingLink("subsInfo", { link: n }),
                new o.SubscriptionHandshakeLink("subsInfo"),
              ]));
          else {
            var l = e.url;
            (n = t || s.createHttpLink({ uri: l })),
              (f = new c.AppSyncRealTimeSubscriptionHandshakeLink(e));
          }
          return i.ApolloLink.split(
            function (e) {
              var t = e.query,
                n = a.getMainDefinition(t),
                r = n.kind,
                o = n.operation;
              return "OperationDefinition" === r && "subscription" === o;
            },
            f,
            n
          );
        };
      },
      75171: function (e, t, n) {
        "use strict";
        var r,
          o =
            (this && this.__extends) ||
            ((r = function (e, t) {
              return (r =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
                })(e, t);
            }),
            function (e, t) {
              function n() {
                this.constructor = e;
              }
              r(e, t),
                (e.prototype =
                  null === t
                    ? Object.create(t)
                    : ((n.prototype = t.prototype), new n()));
            }),
          i =
            (this && this.__assign) ||
            function () {
              return (i =
                Object.assign ||
                function (e) {
                  for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var o in (t = arguments[n]))
                      Object.prototype.hasOwnProperty.call(t, o) &&
                        (e[o] = t[o]);
                  return e;
                }).apply(this, arguments);
            },
          s =
            (this && this.__awaiter) ||
            function (e, t, n, r) {
              return new (n || (n = Promise))(function (o, i) {
                function s(e) {
                  try {
                    u(r.next(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function a(e) {
                  try {
                    u(r.throw(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function u(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value) instanceof n
                        ? t
                        : new n(function (e) {
                            e(t);
                          })
                      ).then(s, a);
                }
                u((r = r.apply(e, t || [])).next());
              });
            },
          a =
            (this && this.__generator) ||
            function (e, t) {
              var n,
                r,
                o,
                i,
                s = {
                  label: 0,
                  sent: function () {
                    if (1 & o[0]) throw o[1];
                    return o[1];
                  },
                  trys: [],
                  ops: [],
                };
              return (
                (i = { next: a(0), throw: a(1), return: a(2) }),
                "function" == typeof Symbol &&
                  (i[Symbol.iterator] = function () {
                    return this;
                  }),
                i
              );
              function a(i) {
                return function (a) {
                  return (function (i) {
                    if (n) throw TypeError("Generator is already executing.");
                    for (; s; )
                      try {
                        if (
                          ((n = 1),
                          r &&
                            (o =
                              2 & i[0]
                                ? r.return
                                : i[0]
                                ? r.throw || ((o = r.return) && o.call(r), 0)
                                : r.next) &&
                            !(o = o.call(r, i[1])).done)
                        )
                          return o;
                        switch (
                          ((r = 0), o && (i = [2 & i[0], o.value]), i[0])
                        ) {
                          case 0:
                          case 1:
                            o = i;
                            break;
                          case 4:
                            return s.label++, { value: i[1], done: !1 };
                          case 5:
                            s.label++, (r = i[1]), (i = [0]);
                            continue;
                          case 7:
                            (i = s.ops.pop()), s.trys.pop();
                            continue;
                          default:
                            if (
                              !(o =
                                (o = s.trys).length > 0 && o[o.length - 1]) &&
                              (6 === i[0] || 2 === i[0])
                            ) {
                              s = 0;
                              continue;
                            }
                            if (
                              3 === i[0] &&
                              (!o || (i[1] > o[0] && i[1] < o[3]))
                            ) {
                              s.label = i[1];
                              break;
                            }
                            if (6 === i[0] && s.label < o[1]) {
                              (s.label = o[1]), (o = i);
                              break;
                            }
                            if (o && s.label < o[2]) {
                              (s.label = o[2]), s.ops.push(i);
                              break;
                            }
                            o[2] && s.ops.pop(), s.trys.pop();
                            continue;
                        }
                        i = t.call(e, s);
                      } catch (e) {
                        (i = [6, e]), (r = 0);
                      } finally {
                        n = o = 0;
                      }
                    if (5 & i[0]) throw i[1];
                    return { value: i[0] ? i[1] : void 0, done: !0 };
                  })([i, a]);
                };
              }
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        /*!
         * Copyright 2017-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
         * SPDX-License-Identifier: Apache-2.0
         */ var u = n(34153),
          c = n(37865),
          f = (function (e) {
            function t(t, n) {
              var r = n.link,
                o = e.call(this) || this;
              return (o.contextKey = t), (o.link = r), o;
            }
            return (
              o(t, e),
              (t.prototype.request = function (e, t) {
                var n = this;
                return c
                  .setContext(function (t, r) {
                    return s(n, void 0, void 0, function () {
                      var t,
                        n,
                        o = this;
                      return a(this, function (s) {
                        switch (s.label) {
                          case 0:
                            return [
                              4,
                              new Promise(function (t, n) {
                                o.link
                                  .request(e)
                                  .subscribe({ next: t, error: n });
                              }),
                            ];
                          case 1:
                            return (
                              (t = s.sent()),
                              [
                                2,
                                i(
                                  i({}, r),
                                  (((n = {})[this.contextKey] = t), n)
                                ),
                              ]
                            );
                        }
                      });
                    });
                  })
                  .request(e, t);
              }),
              t
            );
          })(u.ApolloLink);
        t.NonTerminatingLink = f;
      },
      41663: function (e, t, n) {
        "use strict";
        var r,
          o = n(48764).lW,
          i =
            (this && this.__extends) ||
            ((r = function (e, t) {
              return (r =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
                })(e, t);
            }),
            function (e, t) {
              function n() {
                this.constructor = e;
              }
              r(e, t),
                (e.prototype =
                  null === t
                    ? Object.create(t)
                    : ((n.prototype = t.prototype), new n()));
            }),
          s =
            (this && this.__assign) ||
            function () {
              return (s =
                Object.assign ||
                function (e) {
                  for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var o in (t = arguments[n]))
                      Object.prototype.hasOwnProperty.call(t, o) &&
                        (e[o] = t[o]);
                  return e;
                }).apply(this, arguments);
            },
          a =
            (this && this.__awaiter) ||
            function (e, t, n, r) {
              return new (n || (n = Promise))(function (o, i) {
                function s(e) {
                  try {
                    u(r.next(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function a(e) {
                  try {
                    u(r.throw(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function u(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value) instanceof n
                        ? t
                        : new n(function (e) {
                            e(t);
                          })
                      ).then(s, a);
                }
                u((r = r.apply(e, t || [])).next());
              });
            },
          u =
            (this && this.__generator) ||
            function (e, t) {
              var n,
                r,
                o,
                i,
                s = {
                  label: 0,
                  sent: function () {
                    if (1 & o[0]) throw o[1];
                    return o[1];
                  },
                  trys: [],
                  ops: [],
                };
              return (
                (i = { next: a(0), throw: a(1), return: a(2) }),
                "function" == typeof Symbol &&
                  (i[Symbol.iterator] = function () {
                    return this;
                  }),
                i
              );
              function a(i) {
                return function (a) {
                  return (function (i) {
                    if (n) throw TypeError("Generator is already executing.");
                    for (; s; )
                      try {
                        if (
                          ((n = 1),
                          r &&
                            (o =
                              2 & i[0]
                                ? r.return
                                : i[0]
                                ? r.throw || ((o = r.return) && o.call(r), 0)
                                : r.next) &&
                            !(o = o.call(r, i[1])).done)
                        )
                          return o;
                        switch (
                          ((r = 0), o && (i = [2 & i[0], o.value]), i[0])
                        ) {
                          case 0:
                          case 1:
                            o = i;
                            break;
                          case 4:
                            return s.label++, { value: i[1], done: !1 };
                          case 5:
                            s.label++, (r = i[1]), (i = [0]);
                            continue;
                          case 7:
                            (i = s.ops.pop()), s.trys.pop();
                            continue;
                          default:
                            if (
                              !(o =
                                (o = s.trys).length > 0 && o[o.length - 1]) &&
                              (6 === i[0] || 2 === i[0])
                            ) {
                              s = 0;
                              continue;
                            }
                            if (
                              3 === i[0] &&
                              (!o || (i[1] > o[0] && i[1] < o[3]))
                            ) {
                              s.label = i[1];
                              break;
                            }
                            if (6 === i[0] && s.label < o[1]) {
                              (s.label = o[1]), (o = i);
                              break;
                            }
                            if (o && s.label < o[2]) {
                              (s.label = o[2]), s.ops.push(i);
                              break;
                            }
                            o[2] && s.ops.pop(), s.trys.pop();
                            continue;
                        }
                        i = t.call(e, s);
                      } catch (e) {
                        (i = [6, e]), (r = 0);
                      } finally {
                        n = o = 0;
                      }
                    if (5 & i[0]) throw i[1];
                    return { value: i[0] ? i[1] : void 0, done: !0 };
                  })([i, a]);
                };
              }
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        /*!
         * Copyright 2017-2021 Amazon.com, Inc. or its affiliates. All Rights Reserved.
         * SPDX-License-Identifier: Apache-2.0
         */ var c = n(34153),
          f = n(12801),
          l = n(10638),
          p = n(85955),
          h = n(11987),
          d = n(67429),
          y = n(14633),
          v = n(23979),
          g = f.rootLogger.extend("subscriptions");
        t.CONTROL_EVENTS_KEY = "@@controlEvents";
        var m = [400, 401, 403],
          _ = {
            accept: "application/json, text/javascript",
            "content-encoding": "amz-1.0",
            "content-type": "application/json; charset=UTF-8",
          },
          b =
            /^https:\/\/\w{26}\.appsync\-api\.\w{2}(?:(?:\-\w{2,})+)\-\d\.amazonaws.com\/graphql$/i,
          E = (function (e) {
            function n(t) {
              var n = t.url,
                r = t.region,
                o = t.auth,
                i = t.keepAliveTimeoutMs,
                s = e.call(this) || this;
              if (
                ((s.socketStatus = y.SOCKET_STATUS.CLOSED),
                (s.keepAliveTimeout = void 0),
                (s.subscriptionObserverMap = new Map()),
                (s.promiseArray = []),
                (s.url = n),
                (s.region = r),
                (s.auth = o),
                (s.keepAliveTimeout = i),
                s.keepAliveTimeout < 6e4)
              )
                throw Error(
                  "keepAliveTimeoutMs must be greater than or equal to 60000 (" +
                    s.keepAliveTimeout +
                    " used)."
                );
              return s;
            }
            return (
              i(n, e),
              (n.prototype.isCustomDomain = function (e) {
                return null === e.match(b);
              }),
              (n.prototype.request = function (e) {
                var n,
                  r = this,
                  o = e.query,
                  i = e.variables,
                  f = e.getContext(),
                  h = f.controlMessages,
                  v = t.CONTROL_EVENTS_KEY,
                  g = (
                    void 0 === h
                      ? (((n = {})[t.CONTROL_EVENTS_KEY] = void 0), n)
                      : h
                  )[v],
                  m = f.headers;
                return new c.Observable(function (e) {
                  if (r.url) {
                    var t = d.v4(),
                      n =
                        r.auth.type === l.AUTH_TYPE.AMAZON_COGNITO_USER_POOLS ||
                        r.auth.type === l.AUTH_TYPE.OPENID_CONNECT
                          ? r.auth.jwtToken
                          : null;
                    n =
                      r.auth.type === l.AUTH_TYPE.AWS_LAMBDA ? r.auth.token : n;
                    var c = {
                      appSyncGraphqlEndpoint: r.url,
                      authenticationType: r.auth.type,
                      query: p.print(o),
                      region: r.region,
                      graphql_headers: function () {
                        return m;
                      },
                      variables: i,
                      apiKey:
                        r.auth.type === l.AUTH_TYPE.API_KEY
                          ? r.auth.apiKey
                          : "",
                      credentials:
                        r.auth.type === l.AUTH_TYPE.AWS_IAM
                          ? r.auth.credentials
                          : null,
                      token: n,
                    };
                    return (
                      r._startSubscriptionWithAWSAppSyncRealTime({
                        options: c,
                        observer: e,
                        subscriptionId: t,
                      }),
                      function () {
                        return a(r, void 0, void 0, function () {
                          return u(this, function (e) {
                            try {
                              if (
                                (this._verifySubscriptionAlreadyStarted(t),
                                this.subscriptionObserverMap.get(t)
                                  .subscriptionState ===
                                  y.SUBSCRIPTION_STATUS.CONNECTED)
                              )
                                this._sendUnsubscriptionMessage(t);
                              else
                                throw Error(
                                  "Subscription has failed, starting to remove subscription."
                                );
                            } catch (e) {
                              this._removeSubscriptionObserver(t);
                            }
                            return [2];
                          });
                        });
                      }
                    );
                  }
                  e.error({
                    errors: [
                      s(
                        {},
                        new p.GraphQLError(
                          "Subscribe only available for AWS AppSync endpoint"
                        )
                      ),
                    ],
                  }),
                    e.complete();
                }).filter(function (e) {
                  var t = e.extensions,
                    n = (void 0 === t ? {} : t).controlMsgType;
                  return !0 === g || !(void 0 !== (void 0 === n ? void 0 : n));
                });
              }),
              (n.prototype._verifySubscriptionAlreadyStarted = function (e) {
                return a(this, void 0, void 0, function () {
                  var t = this;
                  return u(this, function (n) {
                    return this.subscriptionObserverMap.get(e)
                      .subscriptionState === y.SUBSCRIPTION_STATUS.PENDING
                      ? [
                          2,
                          new Promise(function (n, r) {
                            var o = t.subscriptionObserverMap.get(e),
                              i = o.observer,
                              s = o.subscriptionState,
                              a = o.variables,
                              u = o.query;
                            t.subscriptionObserverMap.set(e, {
                              observer: i,
                              subscriptionState: s,
                              variables: a,
                              query: u,
                              subscriptionReadyCallback: n,
                              subscriptionFailedCallback: r,
                            });
                          }),
                        ]
                      : [2];
                  });
                });
              }),
              (n.prototype._sendUnsubscriptionMessage = function (e) {
                try {
                  if (
                    this.awsRealTimeSocket &&
                    this.awsRealTimeSocket.readyState === WebSocket.OPEN &&
                    this.socketStatus === y.SOCKET_STATUS.READY
                  ) {
                    var t = { id: e, type: y.MESSAGE_TYPES.GQL_STOP },
                      n = JSON.stringify(t);
                    this.awsRealTimeSocket.send(n),
                      this._removeSubscriptionObserver(e);
                  }
                } catch (e) {
                  g({ err: e });
                }
              }),
              (n.prototype._removeSubscriptionObserver = function (e) {
                this.subscriptionObserverMap.delete(e),
                  setTimeout(this._closeSocketIfRequired.bind(this), 1e3);
              }),
              (n.prototype._closeSocketIfRequired = function () {
                if (!(this.subscriptionObserverMap.size > 0)) {
                  if (!this.awsRealTimeSocket) {
                    this.socketStatus = y.SOCKET_STATUS.CLOSED;
                    return;
                  }
                  this.awsRealTimeSocket.bufferedAmount > 0
                    ? setTimeout(this._closeSocketIfRequired.bind(this), 1e3)
                    : (g("closing WebSocket..."),
                      clearTimeout(this.keepAliveTimeoutId),
                      this.awsRealTimeSocket.close(1e3),
                      (this.awsRealTimeSocket = null),
                      (this.socketStatus = y.SOCKET_STATUS.CLOSED));
                }
              }),
              (n.prototype._startSubscriptionWithAWSAppSyncRealTime = function (
                e
              ) {
                var t = e.options,
                  n = e.observer,
                  r = e.subscriptionId;
                return a(this, void 0, void 0, function () {
                  var e,
                    o,
                    i,
                    a,
                    c,
                    f,
                    h,
                    d,
                    v,
                    g,
                    m,
                    _,
                    b,
                    E,
                    T,
                    O,
                    S,
                    A,
                    w,
                    I,
                    N,
                    C,
                    R,
                    M = this;
                  return u(this, function (u) {
                    switch (u.label) {
                      case 0:
                        return (
                          (e = t.appSyncGraphqlEndpoint),
                          (o = t.authenticationType),
                          (i = t.query),
                          (a = t.variables),
                          (c = t.apiKey),
                          (f = t.region),
                          (d =
                            void 0 === (h = t.graphql_headers)
                              ? function () {
                                  return {};
                                }
                              : h),
                          (v = t.credentials),
                          (g = t.token),
                          (m = y.SUBSCRIPTION_STATUS.PENDING),
                          (_ = { query: i, variables: a }),
                          this.subscriptionObserverMap.set(r, {
                            observer: n,
                            query: i,
                            variables: a,
                            subscriptionState: m,
                            startAckTimeoutId: null,
                          }),
                          (b = JSON.stringify(_)),
                          (T = [{}]),
                          [
                            4,
                            this._awsRealTimeHeaderBasedAuth({
                              apiKey: c,
                              appSyncGraphqlEndpoint: e,
                              authenticationType: o,
                              payload: b,
                              canonicalUri: "",
                              region: f,
                              credentials: v,
                              token: g,
                              graphql_headers: d,
                            }),
                          ]
                        );
                      case 1:
                        (E = s.apply(void 0, [
                          s.apply(void 0, T.concat([u.sent()])),
                          (((R = {})[l.USER_AGENT_HEADER] = l.USER_AGENT), R),
                        ])),
                          (O = JSON.stringify({
                            id: r,
                            payload: {
                              data: b,
                              extensions: { authorization: s({}, E) },
                            },
                            type: y.MESSAGE_TYPES.GQL_START,
                          })),
                          (u.label = 2);
                      case 2:
                        return (
                          u.trys.push([2, 4, , 5]),
                          [
                            4,
                            this._initializeWebSocketConnection({
                              apiKey: c,
                              appSyncGraphqlEndpoint: e,
                              authenticationType: o,
                              region: f,
                              credentials: v,
                              token: g,
                            }),
                          ]
                        );
                      case 3:
                        return u.sent(), [3, 5];
                      case 4:
                        return (
                          (A = void 0 === (S = u.sent().message) ? "" : S),
                          n.error({
                            errors: [
                              s(
                                {},
                                new p.GraphQLError("Connection failed: " + A)
                              ),
                            ],
                          }),
                          n.complete(),
                          "function" ==
                            typeof (w = (
                              this.subscriptionObserverMap.get(r) || {}
                            ).subscriptionFailedCallback) && w(),
                          [2]
                        );
                      case 5:
                        return (
                          (N = (I = this.subscriptionObserverMap.get(r) || {})
                            .subscriptionFailedCallback),
                          (C = I.subscriptionReadyCallback),
                          this.subscriptionObserverMap.set(r, {
                            observer: n,
                            subscriptionState: m,
                            variables: a,
                            query: i,
                            subscriptionReadyCallback: C,
                            subscriptionFailedCallback: N,
                            startAckTimeoutId: setTimeout(function () {
                              M._timeoutStartSubscriptionAck.call(M, r);
                            }, 15e3),
                          }),
                          this.awsRealTimeSocket &&
                            this.awsRealTimeSocket.send(O),
                          [2]
                        );
                    }
                  });
                });
              }),
              (n.prototype._initializeWebSocketConnection = function (e) {
                var t = this,
                  n = e.appSyncGraphqlEndpoint,
                  r = e.authenticationType,
                  i = e.apiKey,
                  s = e.region,
                  c = e.credentials,
                  f = e.token;
                if (this.socketStatus !== y.SOCKET_STATUS.READY)
                  return new Promise(function (e, l) {
                    return a(t, void 0, void 0, function () {
                      var t, a, p, h, d, v, m, _, b;
                      return u(this, function (u) {
                        switch (u.label) {
                          case 0:
                            if (
                              (this.promiseArray.push({ res: e, rej: l }),
                              this.socketStatus !== y.SOCKET_STATUS.CLOSED)
                            )
                              return [3, 5];
                            u.label = 1;
                          case 1:
                            return (
                              u.trys.push([1, 4, , 5]),
                              (this.socketStatus = y.SOCKET_STATUS.CONNECTING),
                              (t = "{}"),
                              (h = (p = JSON).stringify),
                              [
                                4,
                                this._awsRealTimeHeaderBasedAuth({
                                  authenticationType: r,
                                  payload: t,
                                  canonicalUri: "/connect",
                                  apiKey: i,
                                  appSyncGraphqlEndpoint: n,
                                  region: s,
                                  credentials: c,
                                  token: f,
                                  graphql_headers: function () {},
                                }),
                              ]
                            );
                          case 2:
                            return (
                              (a = h.apply(p, [u.sent()])),
                              (d = o.from(a).toString("base64")),
                              (v = o.from(t).toString("base64")),
                              (m = n),
                              (_ =
                                (m = (m = this.isCustomDomain(m)
                                  ? m.concat("/realtime")
                                  : m
                                      .replace(
                                        "appsync-api",
                                        "appsync-realtime-api"
                                      )
                                      .replace("gogi-beta", "grt-beta"))
                                  .replace("https://", "wss://")
                                  .replace("http://", "ws://")) +
                                "?header=" +
                                d +
                                "&payload=" +
                                v),
                              [
                                4,
                                this._initializeRetryableHandshake({
                                  awsRealTimeUrl: _,
                                }),
                              ]
                            );
                          case 3:
                            return (
                              u.sent(),
                              this.promiseArray.forEach(function (e) {
                                var t = e.res;
                                g("Notifying connection successful"), t();
                              }),
                              (this.socketStatus = y.SOCKET_STATUS.READY),
                              (this.promiseArray = []),
                              [3, 5]
                            );
                          case 4:
                            return (
                              (b = u.sent()),
                              this.promiseArray.forEach(function (e) {
                                return (0, e.rej)(b);
                              }),
                              (this.promiseArray = []),
                              this.awsRealTimeSocket &&
                                this.awsRealTimeSocket.readyState ===
                                  WebSocket.OPEN &&
                                this.awsRealTimeSocket.close(3001),
                              (this.awsRealTimeSocket = null),
                              (this.socketStatus = y.SOCKET_STATUS.CLOSED),
                              [3, 5]
                            );
                          case 5:
                            return [2];
                        }
                      });
                    });
                  });
              }),
              (n.prototype._awsRealTimeHeaderBasedAuth = function (e) {
                var t = e.authenticationType,
                  n = e.payload,
                  r = e.canonicalUri,
                  o = e.appSyncGraphqlEndpoint,
                  i = e.apiKey,
                  s = e.region,
                  c = e.credentials,
                  f = e.token,
                  l = e.graphql_headers;
                return a(this, void 0, void 0, function () {
                  var e, a;
                  return u(this, function (u) {
                    switch (u.label) {
                      case 0:
                        if (
                          "function" !=
                          typeof (e = {
                            API_KEY: this._awsRealTimeApiKeyHeader.bind(this),
                            AWS_IAM: this._awsRealTimeIAMHeader.bind(this),
                            OPENID_CONNECT:
                              this._awsRealTimeAuthorizationHeader.bind(this),
                            AMAZON_COGNITO_USER_POOLS:
                              this._awsRealTimeAuthorizationHeader.bind(this),
                            AWS_LAMBDA:
                              this._awsRealTimeAuthorizationHeader.bind(this),
                          }[t])
                        )
                          return (
                            g("Authentication type " + t + " not supported"),
                            [2, {}]
                          );
                        return (
                          (a = h.parse(o).host),
                          [
                            4,
                            e({
                              payload: n,
                              canonicalUri: r,
                              appSyncGraphqlEndpoint: o,
                              apiKey: i,
                              region: s,
                              host: a,
                              credentials: c,
                              token: f,
                              graphql_headers: l,
                            }),
                          ]
                        );
                      case 1:
                        return [2, u.sent()];
                    }
                  });
                });
              }),
              (n.prototype._awsRealTimeAuthorizationHeader = function (e) {
                var t = e.host,
                  n = e.token,
                  r = e.graphql_headers;
                return a(this, void 0, void 0, function () {
                  var e, o, i;
                  return u(this, function (a) {
                    switch (a.label) {
                      case 0:
                        if (((e = {}), "function" != typeof n)) return [3, 2];
                        return [4, n.call(void 0)];
                      case 1:
                        return (o = a.sent()), [3, 4];
                      case 2:
                        return [4, n];
                      case 3:
                        (o = a.sent()), (a.label = 4);
                      case 4:
                        return (
                          (i = [((e.Authorization = o), (e.host = t), e)]),
                          [4, r()]
                        );
                      case 5:
                        return [2, s.apply(void 0, i.concat([a.sent()]))];
                    }
                  });
                });
              }),
              (n.prototype._awsRealTimeApiKeyHeader = function (e) {
                var t = e.apiKey,
                  n = e.host,
                  r = e.graphql_headers;
                return a(this, void 0, void 0, function () {
                  var e;
                  return u(this, function (o) {
                    switch (o.label) {
                      case 0:
                        return (
                          (e = [
                            {
                              host: n,
                              "x-amz-date": new Date()
                                .toISOString()
                                .replace(/[:\-]|\.\d{3}/g, ""),
                              "x-api-key": t,
                            },
                          ]),
                          [4, r()]
                        );
                      case 1:
                        return [2, s.apply(void 0, e.concat([o.sent()]))];
                    }
                  });
                });
              }),
              (n.prototype._awsRealTimeIAMHeader = function (e) {
                var t = e.payload,
                  n = e.canonicalUri,
                  r = e.appSyncGraphqlEndpoint,
                  o = e.region,
                  i = e.credentials;
                return a(this, void 0, void 0, function () {
                  var e, a, c, f, p;
                  return u(this, function (u) {
                    switch (u.label) {
                      case 0:
                        if (
                          ((e = { region: o, service: "appsync" }),
                          !(
                            (a = "function" == typeof i ? i.call() : i || {}) &&
                            "function" == typeof a.getPromise
                          ))
                        )
                          return [3, 2];
                        return [4, a.getPromise()];
                      case 1:
                        u.sent(), (u.label = 2);
                      case 2:
                        if (!a) throw Error("No credentials");
                        return [4, a];
                      case 3:
                        return (
                          (f = {
                            access_key: (c = u.sent()).accessKeyId,
                            secret_key: c.secretAccessKey,
                            session_token: c.sessionToken,
                          }),
                          (p = {
                            url: "" + r + n,
                            body: t,
                            method: "POST",
                            headers: s({}, _),
                          }),
                          [2, l.Signer.sign(p, f, e).headers]
                        );
                    }
                  });
                });
              }),
              (n.prototype._initializeRetryableHandshake = function (e) {
                var t = e.awsRealTimeUrl;
                return a(this, void 0, void 0, function () {
                  return u(this, function (e) {
                    switch (e.label) {
                      case 0:
                        return (
                          g("Initializaling retryable Handshake"),
                          [
                            4,
                            v.jitteredExponentialRetry(
                              this._initializeHandshake.bind(this),
                              [{ awsRealTimeUrl: t }]
                            ),
                          ]
                        );
                      case 1:
                        return e.sent(), [2];
                    }
                  });
                });
              }),
              (n.prototype._initializeHandshake = function (e) {
                var t = e.awsRealTimeUrl;
                return a(this, void 0, void 0, function () {
                  var e,
                    r,
                    o,
                    i = this;
                  return u(this, function (s) {
                    switch (s.label) {
                      case 0:
                        g("Initializing handshake " + t), (s.label = 1);
                      case 1:
                        return (
                          s.trys.push([1, 4, , 5]),
                          [
                            4,
                            new Promise(function (e, r) {
                              var o = n.createWebSocket(t, "graphql-ws");
                              (o.onerror = function () {
                                g("WebSocket connection error");
                              }),
                                (o.onclose = function () {
                                  r(Error("Connection handshake error"));
                                }),
                                (o.onopen = function () {
                                  return (i.awsRealTimeSocket = o), e();
                                });
                            }),
                          ]
                        );
                      case 2:
                        return (
                          s.sent(),
                          [
                            4,
                            new Promise(function (e, t) {
                              var n = !1;
                              (i.awsRealTimeSocket.onerror = function (e) {
                                g("WebSocket closed " + JSON.stringify(e));
                              }),
                                (i.awsRealTimeSocket.onclose = function (e) {
                                  g("WebSocket closed " + e.reason),
                                    t(Error(JSON.stringify(e)));
                                }),
                                (i.awsRealTimeSocket.onmessage = function (r) {
                                  g(
                                    "subscription message from AWS AppSyncRealTime: " +
                                      r.data +
                                      " "
                                  );
                                  var o,
                                    s = JSON.parse(r.data),
                                    a = s.type,
                                    u = s.payload,
                                    c = (void 0 === u ? {} : u)
                                      .connectionTimeoutMs;
                                  if (
                                    a === y.MESSAGE_TYPES.GQL_CONNECTION_ACK
                                  ) {
                                    (n = !0),
                                      (i.keepAliveTimeout =
                                        null !== (o = i.keepAliveTimeout) &&
                                        void 0 !== o
                                          ? o
                                          : void 0 === c
                                          ? 3e5
                                          : c),
                                      (i.awsRealTimeSocket.onmessage =
                                        i._handleIncomingSubscriptionMessage.bind(
                                          i
                                        )),
                                      (i.awsRealTimeSocket.onerror = function (
                                        e
                                      ) {
                                        g(e),
                                          i._errorDisconnect(
                                            y.CONTROL_MSG.CONNECTION_CLOSED
                                          );
                                      }),
                                      (i.awsRealTimeSocket.onclose = function (
                                        e
                                      ) {
                                        g("WebSocket closed " + e.reason),
                                          i._errorDisconnect(
                                            y.CONTROL_MSG.CONNECTION_CLOSED
                                          );
                                      }),
                                      e(
                                        "Cool, connected to AWS AppSyncRealTime"
                                      );
                                    return;
                                  }
                                  if (
                                    a === y.MESSAGE_TYPES.GQL_CONNECTION_ERROR
                                  ) {
                                    var f = s.payload,
                                      l = (void 0 === f ? {} : f).errors,
                                      p = (void 0 === l ? [] : l)[0],
                                      h = void 0 === p ? {} : p,
                                      d = h.errorType,
                                      v = h.errorCode;
                                    t({
                                      errorType: void 0 === d ? "" : d,
                                      errorCode: void 0 === v ? 0 : v,
                                    });
                                  }
                                });
                              var r = {
                                type: y.MESSAGE_TYPES.GQL_CONNECTION_INIT,
                              };
                              i.awsRealTimeSocket.send(JSON.stringify(r)),
                                setTimeout(
                                  function () {
                                    n ||
                                      t(
                                        Error(
                                          "Connection timeout: ack from AWSRealTime was not received on 15000 ms"
                                        )
                                      );
                                  }.bind(i),
                                  15e3
                                );
                            }),
                          ]
                        );
                      case 3:
                        return s.sent(), [3, 5];
                      case 4:
                        if (
                          ((r = (e = s.sent()).errorType),
                          (o = e.errorCode),
                          m.indexOf(o) >= 0)
                        )
                          throw new v.NonRetryableError(r);
                        if (r) throw Error(r);
                        throw e;
                      case 5:
                        return [2];
                    }
                  });
                });
              }),
              (n.prototype._handleIncomingSubscriptionMessage = function (e) {
                g("subscription message from AWS AppSync RealTime: " + e.data);
                var t = JSON.parse(e.data),
                  n = t.id,
                  r = void 0 === n ? "" : n,
                  o = t.payload,
                  i = t.type,
                  a = this.subscriptionObserverMap.get(r) || {},
                  u = a.observer,
                  c = void 0 === u ? null : u,
                  f = a.query,
                  l = void 0 === f ? "" : f,
                  h = a.variables,
                  d = void 0 === h ? {} : h,
                  v = a.startAckTimeoutId,
                  m = void 0 === v ? 0 : v,
                  _ = a.subscriptionReadyCallback,
                  b = void 0 === _ ? null : _,
                  E = a.subscriptionFailedCallback,
                  T = void 0 === E ? null : E;
                if (
                  (g({ id: r, observer: c, query: l, variables: d }),
                  i === y.MESSAGE_TYPES.GQL_DATA && o && o.data)
                ) {
                  c ? c.next(o) : g("observer not found for id: " + r);
                  return;
                }
                if (i === y.MESSAGE_TYPES.GQL_START_ACK) {
                  g(
                    "subscription ready for " +
                      JSON.stringify({ query: l, variables: d })
                  ),
                    "function" == typeof b && b(),
                    clearTimeout(m),
                    c
                      ? c.next({
                          data: o,
                          extensions: { controlMsgType: "CONNECTED" },
                        })
                      : g("observer not found for id: " + r);
                  var O = y.SUBSCRIPTION_STATUS.CONNECTED;
                  this.subscriptionObserverMap.set(r, {
                    observer: c,
                    query: l,
                    variables: d,
                    startAckTimeoutId: null,
                    subscriptionState: O,
                    subscriptionReadyCallback: b,
                    subscriptionFailedCallback: T,
                  });
                  return;
                }
                if (i === y.MESSAGE_TYPES.GQL_CONNECTION_KEEP_ALIVE) {
                  clearTimeout(this.keepAliveTimeoutId),
                    (this.keepAliveTimeoutId = setTimeout(
                      this._errorDisconnect.bind(
                        this,
                        y.CONTROL_MSG.TIMEOUT_DISCONNECT
                      ),
                      this.keepAliveTimeout
                    ));
                  return;
                }
                if (i === y.MESSAGE_TYPES.GQL_ERROR) {
                  var O = y.SUBSCRIPTION_STATUS.FAILED;
                  this.subscriptionObserverMap.set(r, {
                    observer: c,
                    query: l,
                    variables: d,
                    startAckTimeoutId: m,
                    subscriptionReadyCallback: b,
                    subscriptionFailedCallback: T,
                    subscriptionState: O,
                  }),
                    clearTimeout(m),
                    c
                      ? (c.error({
                          errors: [
                            s(
                              {},
                              new p.GraphQLError(
                                "Connection failed: " + JSON.stringify(o)
                              )
                            ),
                          ],
                        }),
                        c.complete())
                      : g("observer not found for id: " + r),
                    "function" == typeof T && T();
                }
              }),
              (n.prototype._errorDisconnect = function (e) {
                g("Disconnect error: " + e),
                  this.subscriptionObserverMap.forEach(function (t) {
                    var n = t.observer;
                    n &&
                      !n.closed &&
                      n.error({ errors: [s({}, new p.GraphQLError(e))] });
                  }),
                  this.subscriptionObserverMap.clear(),
                  this.awsRealTimeSocket && this.awsRealTimeSocket.close(),
                  (this.socketStatus = y.SOCKET_STATUS.CLOSED);
              }),
              (n.prototype._timeoutStartSubscriptionAck = function (e) {
                var t = this.subscriptionObserverMap.get(e) || {},
                  n = t.observer,
                  r = t.query,
                  o = t.variables;
                n &&
                  (this.subscriptionObserverMap.set(e, {
                    observer: n,
                    query: r,
                    variables: o,
                    subscriptionState: y.SUBSCRIPTION_STATUS.FAILED,
                  }),
                  n &&
                    !n.closed &&
                    (n.error({
                      errors: [
                        s(
                          {},
                          new p.GraphQLError(
                            "Subscription timeout " +
                              JSON.stringify({ query: r, variables: o })
                          )
                        ),
                      ],
                    }),
                    n.complete()),
                  g(
                    "timeoutStartSubscription",
                    JSON.stringify({ query: r, variables: o })
                  ));
              }),
              (n.createWebSocket = function (e, t) {
                return new WebSocket(e, t);
              }),
              n
            );
          })(c.ApolloLink);
        t.AppSyncRealTimeSubscriptionHandshakeLink = E;
      },
      85149: function (e, t, n) {
        "use strict";
        var r,
          o =
            (this && this.__extends) ||
            ((r = function (e, t) {
              return (r =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
                })(e, t);
            }),
            function (e, t) {
              function n() {
                this.constructor = e;
              }
              r(e, t),
                (e.prototype =
                  null === t
                    ? Object.create(t)
                    : ((n.prototype = t.prototype), new n()));
            }),
          i =
            (this && this.__assign) ||
            function () {
              return (i =
                Object.assign ||
                function (e) {
                  for (var t, n = 1, r = arguments.length; n < r; n++)
                    for (var o in (t = arguments[n]))
                      Object.prototype.hasOwnProperty.call(t, o) &&
                        (e[o] = t[o]);
                  return e;
                }).apply(this, arguments);
            },
          s =
            (this && this.__awaiter) ||
            function (e, t, n, r) {
              return new (n || (n = Promise))(function (o, i) {
                function s(e) {
                  try {
                    u(r.next(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function a(e) {
                  try {
                    u(r.throw(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function u(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value) instanceof n
                        ? t
                        : new n(function (e) {
                            e(t);
                          })
                      ).then(s, a);
                }
                u((r = r.apply(e, t || [])).next());
              });
            },
          a =
            (this && this.__generator) ||
            function (e, t) {
              var n,
                r,
                o,
                i,
                s = {
                  label: 0,
                  sent: function () {
                    if (1 & o[0]) throw o[1];
                    return o[1];
                  },
                  trys: [],
                  ops: [],
                };
              return (
                (i = { next: a(0), throw: a(1), return: a(2) }),
                "function" == typeof Symbol &&
                  (i[Symbol.iterator] = function () {
                    return this;
                  }),
                i
              );
              function a(i) {
                return function (a) {
                  return (function (i) {
                    if (n) throw TypeError("Generator is already executing.");
                    for (; s; )
                      try {
                        if (
                          ((n = 1),
                          r &&
                            (o =
                              2 & i[0]
                                ? r.return
                                : i[0]
                                ? r.throw || ((o = r.return) && o.call(r), 0)
                                : r.next) &&
                            !(o = o.call(r, i[1])).done)
                        )
                          return o;
                        switch (
                          ((r = 0), o && (i = [2 & i[0], o.value]), i[0])
                        ) {
                          case 0:
                          case 1:
                            o = i;
                            break;
                          case 4:
                            return s.label++, { value: i[1], done: !1 };
                          case 5:
                            s.label++, (r = i[1]), (i = [0]);
                            continue;
                          case 7:
                            (i = s.ops.pop()), s.trys.pop();
                            continue;
                          default:
                            if (
                              !(o =
                                (o = s.trys).length > 0 && o[o.length - 1]) &&
                              (6 === i[0] || 2 === i[0])
                            ) {
                              s = 0;
                              continue;
                            }
                            if (
                              3 === i[0] &&
                              (!o || (i[1] > o[0] && i[1] < o[3]))
                            ) {
                              s.label = i[1];
                              break;
                            }
                            if (6 === i[0] && s.label < o[1]) {
                              (s.label = o[1]), (o = i);
                              break;
                            }
                            if (o && s.label < o[2]) {
                              (s.label = o[2]), s.ops.push(i);
                              break;
                            }
                            o[2] && s.ops.pop(), s.trys.pop();
                            continue;
                        }
                        i = t.call(e, s);
                      } catch (e) {
                        (i = [6, e]), (r = 0);
                      } finally {
                        n = o = 0;
                      }
                    if (5 & i[0]) throw i[1];
                    return { value: i[0] ? i[1] : void 0, done: !0 };
                  })([i, a]);
                };
              }
            },
          u =
            (this && this.__rest) ||
            function (e, t) {
              var n = {};
              for (var r in e)
                Object.prototype.hasOwnProperty.call(e, r) &&
                  0 > t.indexOf(r) &&
                  (n[r] = e[r]);
              if (
                null != e &&
                "function" == typeof Object.getOwnPropertySymbols
              )
                for (
                  var o = 0, r = Object.getOwnPropertySymbols(e);
                  o < r.length;
                  o++
                )
                  0 > t.indexOf(r[o]) &&
                    Object.prototype.propertyIsEnumerable.call(e, r[o]) &&
                    (n[r[o]] = e[r[o]]);
              return n;
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        /*!
         * Copyright 2017-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
         * SPDX-License-Identifier: Apache-2.0
         */ var c = n(34153),
          f = n(12801),
          l = n(9135),
          p = n(10269),
          h = f.rootLogger.extend("subscriptions"),
          d = h.extend("mqtt");
        t.CONTROL_EVENTS_KEY = "@@controlEvents";
        var y = (function (e) {
          function n(t) {
            var n = e.call(this) || this;
            return (
              (n.topicObservers = new Map()),
              (n.clientObservers = new Map()),
              (n.onMessage = function (e, t, r) {
                var o = JSON.parse(t),
                  s = n.topicObservers.get(e),
                  a = r.reduce(function (e, t) {
                    return (e[t] = e[t] || null), e;
                  }, o.data || {});
                h("Message received", { data: a, topic: e, observers: s }),
                  s.forEach(function (e) {
                    try {
                      e.next(i(i({}, o), { data: a }));
                    } catch (e) {
                      h(e);
                    }
                  });
              }),
              (n.subsInfoContextKey = t),
              n
            );
          }
          return (
            o(n, e),
            (n.prototype.request = function (e) {
              var n,
                r = this,
                o = e.getContext(),
                s = o[this.subsInfoContextKey],
                a = o.controlMessages,
                f = t.CONTROL_EVENTS_KEY,
                l = (
                  void 0 === a
                    ? (((n = {})[t.CONTROL_EVENTS_KEY] = void 0), n)
                    : a
                )[f],
                p = s.extensions,
                h = (
                  void 0 === p
                    ? {
                        subscription: {
                          newSubscriptions: {},
                          mqttConnections: [],
                        },
                      }
                    : p
                ).subscription,
                d = h.newSubscriptions,
                y = h.mqttConnections,
                v = s.errors,
                g = void 0 === v ? [] : v;
              if (g && g.length)
                return new c.Observable(function (e) {
                  return (
                    e.error(
                      new c.ApolloError({
                        errorMessage: "Error during subscription handshake",
                        extraInfo: { errors: g },
                        graphQLErrors: g,
                      })
                    ),
                    function () {}
                  );
                });
              var m = Object.keys(d).map(function (e) {
                  return d[e].topic;
                }),
                _ = new Set(
                  m.filter(function (e) {
                    return r.topicObservers.has(e);
                  })
                ),
                b = new Set(
                  m.filter(function (e) {
                    return !_.has(e);
                  })
                );
              return new c.Observable(function (t) {
                _.forEach(function (e) {
                  r.topicObservers.get(e).add(t);
                  var n = Array.from(r.topicObservers.get(e)).find(function () {
                      return !0;
                    }),
                    o = Array.from(r.clientObservers).find(function (e) {
                      return e[1].observers.has(n);
                    })[0];
                  r.clientObservers.get(o).observers.add(t);
                });
                var n = y
                  .filter(function (e) {
                    return e.topics.some(function (e) {
                      return b.has(e);
                    });
                  })
                  .map(function (e) {
                    var t = e.topics;
                    return i(i({}, u(e, ["topics"])), {
                      topics: t.filter(function (e) {
                        return b.has(e);
                      }),
                    });
                  });
                return (
                  r.connectNewClients(n, t, e),
                  function () {
                    Array.from(r.clientObservers)
                      .filter(function (e) {
                        return e[1].observers.has(t);
                      })
                      .forEach(function (e) {
                        var n = e[0];
                        return r.clientObservers.get(n).observers.delete(t);
                      }),
                      r.clientObservers.forEach(function (e) {
                        var t = e.observers,
                          n = e.client;
                        0 === t.size &&
                          (n.isConnected() && n.disconnect(),
                          r.clientObservers.delete(n.clientId));
                      }),
                      (r.clientObservers = new Map(
                        Array.from(r.clientObservers).filter(function (e) {
                          return e[1].observers.size > 0;
                        })
                      )),
                      r.topicObservers.forEach(function (e) {
                        return e.delete(t);
                      }),
                      (r.topicObservers = new Map(
                        Array.from(r.topicObservers).filter(function (e) {
                          return e[1].size > 0;
                        })
                      ));
                  }
                );
              }).filter(function (e) {
                var t = e.extensions,
                  n = (void 0 === t ? {} : t).controlMsgType;
                return !0 === l || !(void 0 !== (void 0 === n ? void 0 : n));
              });
            }),
            (n.prototype.connectNewClients = function (e, t, n) {
              return s(this, void 0, void 0, function () {
                var r,
                  o,
                  i,
                  s,
                  u = this;
                return a(this, function (a) {
                  return (
                    (r = n.query),
                    (o = p
                      .getMainDefinition(r)
                      .selectionSet.selections.map(function (e) {
                        return e.name.value;
                      })),
                    (i = Promise.all(
                      e.map(function (e) {
                        return u.connectNewClient(e, t, o);
                      })
                    )),
                    (s = o.reduce(function (e, t) {
                      return (e[t] = e[t] || null), e;
                    }, {})),
                    t.next({
                      data: s,
                      extensions: {
                        controlMsgType: "CONNECTED",
                        controlMsgInfo: { connectionInfo: e },
                      },
                    }),
                    [2, i]
                  );
                });
              });
            }),
            (n.prototype.connectNewClient = function (e, t, n) {
              return s(this, void 0, void 0, function () {
                var r,
                  o,
                  s,
                  c,
                  f = this;
                return a(this, function (a) {
                  switch (a.label) {
                    case 0:
                      return (
                        (r = e.client),
                        (o = e.url),
                        (s = e.topics),
                        ((c = new l.Client(o, r)).trace = d.bind(null, r)),
                        (c.onConnectionLost = function (e) {
                          var t = e.errorCode,
                            n = u(e, ["errorCode"]);
                          0 !== t &&
                            s.forEach(function (e) {
                              f.topicObservers.has(e) &&
                                f.topicObservers.get(e).forEach(function (e) {
                                  return e.error(
                                    i(i({}, n), { permanent: !0 })
                                  );
                                });
                            }),
                            s.forEach(function (e) {
                              return f.topicObservers.delete(e);
                            });
                        }),
                        (c.onMessageArrived = function (e) {
                          var t = e.destinationName,
                            r = e.payloadString;
                          return f.onMessage(t, r, n);
                        }),
                        [
                          4,
                          new Promise(function (e, t) {
                            c.connect({
                              useSSL: 0 === o.indexOf("wss://"),
                              mqttVersion: 3,
                              onSuccess: function () {
                                return e(c);
                              },
                              onFailure: t,
                            });
                          }),
                        ]
                      );
                    case 1:
                      return a.sent(), [4, this.subscribeToTopics(c, s, t)];
                    case 2:
                      return a.sent(), [2, c];
                  }
                });
              });
            }),
            (n.prototype.subscribeToTopics = function (e, t, n) {
              var r = this;
              return Promise.all(
                t.map(function (t) {
                  return r.subscribeToTopic(e, t, n);
                })
              );
            }),
            (n.prototype.subscribeToTopic = function (e, t, n) {
              var r = this;
              return new Promise(function (o, i) {
                e.subscribe(t, {
                  onSuccess: function () {
                    r.topicObservers.has(t) ||
                      r.topicObservers.set(t, new Set()),
                      r.clientObservers.has(e.clientId) ||
                        r.clientObservers.set(e.clientId, {
                          client: e,
                          observers: new Set(),
                        }),
                      r.topicObservers.get(t).add(n),
                      r.clientObservers.get(e.clientId).observers.add(n),
                      o(t);
                  },
                  onFailure: i,
                });
              });
            }),
            n
          );
        })(c.ApolloLink);
        t.SubscriptionHandshakeLink = y;
      },
      14633: function (e, t) {
        "use strict";
        var n, r, o, i;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          ((n = t.SUBSCRIPTION_STATUS || (t.SUBSCRIPTION_STATUS = {}))[
            (n.PENDING = 0)
          ] = "PENDING"),
          (n[(n.CONNECTED = 1)] = "CONNECTED"),
          (n[(n.FAILED = 2)] = "FAILED"),
          ((r = t.SOCKET_STATUS || (t.SOCKET_STATUS = {}))[(r.CLOSED = 0)] =
            "CLOSED"),
          (r[(r.READY = 1)] = "READY"),
          (r[(r.CONNECTING = 2)] = "CONNECTING"),
          ((o = t.MESSAGE_TYPES || (t.MESSAGE_TYPES = {})).GQL_CONNECTION_INIT =
            "connection_init"),
          (o.GQL_CONNECTION_ERROR = "connection_error"),
          (o.GQL_CONNECTION_ACK = "connection_ack"),
          (o.GQL_START = "start"),
          (o.GQL_START_ACK = "start_ack"),
          (o.GQL_DATA = "data"),
          (o.GQL_CONNECTION_KEEP_ALIVE = "ka"),
          (o.GQL_STOP = "stop"),
          (o.GQL_COMPLETE = "complete"),
          (o.GQL_ERROR = "error"),
          ((i = t.CONTROL_MSG || (t.CONTROL_MSG = {})).CONNECTION_CLOSED =
            "Connection closed"),
          (i.TIMEOUT_DISCONNECT = "Timeout disconnect"),
          (i.SUBSCRIPTION_ACK = "Subscription ack");
      },
      12801: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
        /*!
         * Copyright 2017-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
         * SPDX-License-Identifier: Apache-2.0
         */ var r = n(10397);
        t.rootLogger = r.default;
      },
      10397: function (e, t, n) {
        "use strict";
        var r =
          (this && this.__spreadArrays) ||
          function () {
            for (var e = 0, t = 0, n = arguments.length; t < n; t++)
              e += arguments[t].length;
            for (var r = Array(e), o = 0, t = 0; t < n; t++)
              for (var i = arguments[t], s = 0, a = i.length; s < a; s++, o++)
                r[o] = i[s];
            return r;
          };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var o = n(11227),
          i = o.default("aws-appsync"),
          s = function (e) {
            void 0 === e && (e = "");
            var t = e
                ? r(this.namespace.split(":"), [e]).join(":")
                : this.namespace,
              n = o.default(t);
            return (n.extend = s.bind(n)), n;
          };
        (i.extend = s.bind(i)), (t.default = i);
      },
      23979: function (e, t, n) {
        "use strict";
        var r,
          o =
            (this && this.__extends) ||
            ((r = function (e, t) {
              return (r =
                Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array &&
                  function (e, t) {
                    e.__proto__ = t;
                  }) ||
                function (e, t) {
                  for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
                })(e, t);
            }),
            function (e, t) {
              function n() {
                this.constructor = e;
              }
              r(e, t),
                (e.prototype =
                  null === t
                    ? Object.create(t)
                    : ((n.prototype = t.prototype), new n()));
            }),
          i =
            (this && this.__awaiter) ||
            function (e, t, n, r) {
              return new (n || (n = Promise))(function (o, i) {
                function s(e) {
                  try {
                    u(r.next(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function a(e) {
                  try {
                    u(r.throw(e));
                  } catch (e) {
                    i(e);
                  }
                }
                function u(e) {
                  var t;
                  e.done
                    ? o(e.value)
                    : ((t = e.value) instanceof n
                        ? t
                        : new n(function (e) {
                            e(t);
                          })
                      ).then(s, a);
                }
                u((r = r.apply(e, t || [])).next());
              });
            },
          s =
            (this && this.__generator) ||
            function (e, t) {
              var n,
                r,
                o,
                i,
                s = {
                  label: 0,
                  sent: function () {
                    if (1 & o[0]) throw o[1];
                    return o[1];
                  },
                  trys: [],
                  ops: [],
                };
              return (
                (i = { next: a(0), throw: a(1), return: a(2) }),
                "function" == typeof Symbol &&
                  (i[Symbol.iterator] = function () {
                    return this;
                  }),
                i
              );
              function a(i) {
                return function (a) {
                  return (function (i) {
                    if (n) throw TypeError("Generator is already executing.");
                    for (; s; )
                      try {
                        if (
                          ((n = 1),
                          r &&
                            (o =
                              2 & i[0]
                                ? r.return
                                : i[0]
                                ? r.throw || ((o = r.return) && o.call(r), 0)
                                : r.next) &&
                            !(o = o.call(r, i[1])).done)
                        )
                          return o;
                        switch (
                          ((r = 0), o && (i = [2 & i[0], o.value]), i[0])
                        ) {
                          case 0:
                          case 1:
                            o = i;
                            break;
                          case 4:
                            return s.label++, { value: i[1], done: !1 };
                          case 5:
                            s.label++, (r = i[1]), (i = [0]);
                            continue;
                          case 7:
                            (i = s.ops.pop()), s.trys.pop();
                            continue;
                          default:
                            if (
                              !(o =
                                (o = s.trys).length > 0 && o[o.length - 1]) &&
                              (6 === i[0] || 2 === i[0])
                            ) {
                              s = 0;
                              continue;
                            }
                            if (
                              3 === i[0] &&
                              (!o || (i[1] > o[0] && i[1] < o[3]))
                            ) {
                              s.label = i[1];
                              break;
                            }
                            if (6 === i[0] && s.label < o[1]) {
                              (s.label = o[1]), (o = i);
                              break;
                            }
                            if (o && s.label < o[2]) {
                              (s.label = o[2]), s.ops.push(i);
                              break;
                            }
                            o[2] && s.ops.pop(), s.trys.pop();
                            continue;
                        }
                        i = t.call(e, s);
                      } catch (e) {
                        (i = [6, e]), (r = 0);
                      } finally {
                        n = o = 0;
                      }
                    if (5 & i[0]) throw i[1];
                    return { value: i[0] ? i[1] : void 0, done: !0 };
                  })([i, a]);
                };
              }
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var a = n(12801).rootLogger.extend("retry"),
          u = (function (e) {
            function t(t) {
              var n = e.call(this, t) || this;
              return (n.nonRetryable = !0), n;
            }
            return o(t, e), t;
          })(Error);
        function c(e, t, n, r) {
          return (
            void 0 === r && (r = 1),
            i(this, void 0, void 0, function () {
              var o, i;
              return s(this, function (s) {
                switch (s.label) {
                  case 0:
                    a("Attempt #" + r + " for this vars: " + JSON.stringify(t)),
                      (s.label = 1);
                  case 1:
                    return s.trys.push([1, 3, , 8]), [4, e.apply(void 0, t)];
                  case 2:
                    return s.sent(), [3, 8];
                  case 3:
                    var u;
                    if (
                      (a("error " + (o = s.sent())), (u = o) && u.nonRetryable)
                    )
                      throw (a("non retryable error"), o);
                    if ((a("retryIn ", (i = n(r, t, o))), !(!1 !== i)))
                      return [3, 6];
                    return [
                      4,
                      new Promise(function (e) {
                        return setTimeout(e, i);
                      }),
                    ];
                  case 4:
                    return s.sent(), [4, c(e, t, n, r + 1)];
                  case 5:
                    return [2, s.sent()];
                  case 6:
                    throw o;
                  case 7:
                    return [3, 8];
                  case 8:
                    return [2];
                }
              });
            })
          );
        }
        (t.NonRetryableError = u),
          (t.retry = c),
          (t.jitteredExponentialRetry = function (e, t, n) {
            var r;
            return (
              void 0 === n && (n = 5e3),
              c(
                e,
                t,
                ((r = n),
                function (e) {
                  var t = 100 * Math.pow(2, e) + 100 * Math.random();
                  return !(t > r) && t;
                })
              )
            );
          });
      },
      9135: function (e, t, n) {
        var r;
        e.exports = r = (function (e) {
          var t,
            n =
              e.localStorage ||
              ((t = {}),
              {
                setItem: function (e, n) {
                  t[e] = n;
                },
                getItem: function (e) {
                  return t[e];
                },
                removeItem: function (e) {
                  delete t[e];
                },
              }),
            o = {
              CONNECT: 1,
              CONNACK: 2,
              PUBLISH: 3,
              PUBACK: 4,
              PUBREC: 5,
              PUBREL: 6,
              PUBCOMP: 7,
              SUBSCRIBE: 8,
              SUBACK: 9,
              UNSUBSCRIBE: 10,
              UNSUBACK: 11,
              PINGREQ: 12,
              PINGRESP: 13,
              DISCONNECT: 14,
            },
            i = function (e, t) {
              for (var n in e)
                if (e.hasOwnProperty(n)) {
                  if (t.hasOwnProperty(n)) {
                    if (typeof e[n] !== t[n])
                      throw Error(c(a.INVALID_TYPE, [typeof e[n], n]));
                  } else {
                    var r =
                      "Unknown property, " + n + ". Valid properties are:";
                    for (var o in t) t.hasOwnProperty(o) && (r = r + " " + o);
                    throw Error(r);
                  }
                }
            },
            s = function (e, t) {
              return function () {
                return e.apply(t, arguments);
              };
            },
            a = {
              OK: { code: 0, text: "AMQJSC0000I OK." },
              CONNECT_TIMEOUT: {
                code: 1,
                text: "AMQJSC0001E Connect timed out.",
              },
              SUBSCRIBE_TIMEOUT: {
                code: 2,
                text: "AMQJS0002E Subscribe timed out.",
              },
              UNSUBSCRIBE_TIMEOUT: {
                code: 3,
                text: "AMQJS0003E Unsubscribe timed out.",
              },
              PING_TIMEOUT: { code: 4, text: "AMQJS0004E Ping timed out." },
              INTERNAL_ERROR: {
                code: 5,
                text: "AMQJS0005E Internal error. Error Message: {0}, Stack trace: {1}",
              },
              CONNACK_RETURNCODE: {
                code: 6,
                text: "AMQJS0006E Bad Connack return code:{0} {1}.",
              },
              SOCKET_ERROR: { code: 7, text: "AMQJS0007E Socket error:{0}." },
              SOCKET_CLOSE: { code: 8, text: "AMQJS0008I Socket closed." },
              MALFORMED_UTF: {
                code: 9,
                text: "AMQJS0009E Malformed UTF data:{0} {1} {2}.",
              },
              UNSUPPORTED: {
                code: 10,
                text: "AMQJS0010E {0} is not supported by this browser.",
              },
              INVALID_STATE: {
                code: 11,
                text: "AMQJS0011E Invalid state {0}.",
              },
              INVALID_TYPE: {
                code: 12,
                text: "AMQJS0012E Invalid type {0} for {1}.",
              },
              INVALID_ARGUMENT: {
                code: 13,
                text: "AMQJS0013E Invalid argument {0} for {1}.",
              },
              UNSUPPORTED_OPERATION: {
                code: 14,
                text: "AMQJS0014E Unsupported operation.",
              },
              INVALID_STORED_DATA: {
                code: 15,
                text: "AMQJS0015E Invalid data in local storage key={0} value={1}.",
              },
              INVALID_MQTT_MESSAGE_TYPE: {
                code: 16,
                text: "AMQJS0016E Invalid MQTT message type {0}.",
              },
              MALFORMED_UNICODE: {
                code: 17,
                text: "AMQJS0017E Malformed Unicode string:{0} {1}.",
              },
              BUFFER_FULL: {
                code: 18,
                text: "AMQJS0018E Message buffer is full, maximum buffer size: {0}.",
              },
            },
            u = {
              0: "Connection Accepted",
              1: "Connection Refused: unacceptable protocol version",
              2: "Connection Refused: identifier rejected",
              3: "Connection Refused: server unavailable",
              4: "Connection Refused: bad user name or password",
              5: "Connection Refused: not authorized",
            },
            c = function (e, t) {
              var n,
                r,
                o = e.text;
              if (t) {
                for (var i = 0; i < t.length; i++)
                  if (((n = "{" + i + "}"), (r = o.indexOf(n)) > 0)) {
                    var s = o.substring(0, r),
                      a = o.substring(r + n.length);
                    o = s + t[i] + a;
                  }
              }
              return o;
            },
            f = [0, 6, 77, 81, 73, 115, 100, 112, 3],
            l = [0, 4, 77, 81, 84, 84, 4],
            p = function (e, t) {
              for (var n in ((this.type = e), t))
                t.hasOwnProperty(n) && (this[n] = t[n]);
            };
          function h(e, t, n) {
            return (t[n++] = e >> 8), (t[n++] = e % 256), n;
          }
          function d(e, t, n, r) {
            return (r = h(t, n, r)), g(e, n, r), r + t;
          }
          function y(e, t) {
            return 256 * e[t] + e[t + 1];
          }
          function v(e) {
            for (var t = 0, n = 0; n < e.length; n++) {
              var r = e.charCodeAt(n);
              r > 2047
                ? (55296 <= r && r <= 56319 && (n++, t++), (t += 3))
                : r > 127
                ? (t += 2)
                : t++;
            }
            return t;
          }
          function g(e, t, n) {
            for (var r = n, o = 0; o < e.length; o++) {
              var i = e.charCodeAt(o);
              if (55296 <= i && i <= 56319) {
                var s = e.charCodeAt(++o);
                if (isNaN(s)) throw Error(c(a.MALFORMED_UNICODE, [i, s]));
                i = ((i - 55296) << 10) + (s - 56320) + 65536;
              }
              i <= 127
                ? (t[r++] = i)
                : i <= 2047
                ? ((t[r++] = ((i >> 6) & 31) | 192), (t[r++] = (63 & i) | 128))
                : i <= 65535
                ? ((t[r++] = ((i >> 12) & 15) | 224),
                  (t[r++] = ((i >> 6) & 63) | 128),
                  (t[r++] = (63 & i) | 128))
                : ((t[r++] = ((i >> 18) & 7) | 240),
                  (t[r++] = ((i >> 12) & 63) | 128),
                  (t[r++] = ((i >> 6) & 63) | 128),
                  (t[r++] = (63 & i) | 128));
            }
            return t;
          }
          function m(e, t, n) {
            for (var r, o = "", i = t; i < t + n; ) {
              var s = e[i++];
              if (s < 128) r = s;
              else {
                var u = e[i++] - 128;
                if (u < 0)
                  throw Error(
                    c(a.MALFORMED_UTF, [s.toString(16), u.toString(16), ""])
                  );
                if (s < 224) r = 64 * (s - 192) + u;
                else {
                  var f = e[i++] - 128;
                  if (f < 0)
                    throw Error(
                      c(a.MALFORMED_UTF, [
                        s.toString(16),
                        u.toString(16),
                        f.toString(16),
                      ])
                    );
                  if (s < 240) r = 4096 * (s - 224) + 64 * u + f;
                  else {
                    var l = e[i++] - 128;
                    if (l < 0)
                      throw Error(
                        c(a.MALFORMED_UTF, [
                          s.toString(16),
                          u.toString(16),
                          f.toString(16),
                          l.toString(16),
                        ])
                      );
                    if (s < 248) r = 262144 * (s - 240) + 4096 * u + 64 * f + l;
                    else
                      throw Error(
                        c(a.MALFORMED_UTF, [
                          s.toString(16),
                          u.toString(16),
                          f.toString(16),
                          l.toString(16),
                        ])
                      );
                  }
                }
              }
              r > 65535 &&
                ((r -= 65536),
                (o += String.fromCharCode(55296 + (r >> 10))),
                (r = 56320 + (1023 & r))),
                (o += String.fromCharCode(r));
            }
            return o;
          }
          p.prototype.encode = function () {
            var e,
              t = (15 & this.type) << 4,
              n = 0,
              r = [],
              i = 0;
            switch (
              (void 0 !== this.messageIdentifier && (n += 2), this.type)
            ) {
              case o.CONNECT:
                switch (this.mqttVersion) {
                  case 3:
                    n += f.length + 3;
                    break;
                  case 4:
                    n += l.length + 3;
                }
                (n += v(this.clientId) + 2),
                  void 0 !== this.willMessage &&
                    ((n += v(this.willMessage.destinationName) + 2),
                    (e = this.willMessage.payloadBytes) instanceof Uint8Array ||
                      (e = new Uint8Array(a)),
                    (n += e.byteLength + 2)),
                  void 0 !== this.userName && (n += v(this.userName) + 2),
                  void 0 !== this.password && (n += v(this.password) + 2);
                break;
              case o.SUBSCRIBE:
                t |= 2;
                for (var s = 0; s < this.topics.length; s++)
                  (r[s] = v(this.topics[s])), (n += r[s] + 2);
                n += this.requestedQos.length;
                break;
              case o.UNSUBSCRIBE:
                t |= 2;
                for (var s = 0; s < this.topics.length; s++)
                  (r[s] = v(this.topics[s])), (n += r[s] + 2);
                break;
              case o.PUBREL:
                t |= 2;
                break;
              case o.PUBLISH:
                this.payloadMessage.duplicate && (t |= 8),
                  (t = t |= this.payloadMessage.qos << 1),
                  this.payloadMessage.retained && (t |= 1),
                  (n += (i = v(this.payloadMessage.destinationName)) + 2);
                var a = this.payloadMessage.payloadBytes;
                (n += a.byteLength),
                  a instanceof ArrayBuffer
                    ? (a = new Uint8Array(a))
                    : a instanceof Uint8Array || (a = new Uint8Array(a.buffer));
              case o.DISCONNECT:
            }
            var u = (function (e) {
                var t = [,],
                  n = 0;
                do {
                  var r = e % 128;
                  (e >>= 7) > 0 && (r |= 128), (t[n++] = r);
                } while (e > 0 && n < 4);
                return t;
              })(n),
              c = u.length + 1,
              p = new ArrayBuffer(n + c),
              y = new Uint8Array(p);
            if (((y[0] = t), y.set(u, 1), this.type == o.PUBLISH))
              c = d(this.payloadMessage.destinationName, i, y, c);
            else if (this.type == o.CONNECT) {
              switch (this.mqttVersion) {
                case 3:
                  y.set(f, c), (c += f.length);
                  break;
                case 4:
                  y.set(l, c), (c += l.length);
              }
              var g = 0;
              this.cleanSession && (g = 2),
                void 0 !== this.willMessage &&
                  ((g |= 4),
                  (g |= this.willMessage.qos << 3),
                  this.willMessage.retained && (g |= 32)),
                void 0 !== this.userName && (g |= 128),
                void 0 !== this.password && (g |= 64),
                (y[c++] = g),
                (c = h(this.keepAliveInterval, y, c));
            }
            switch (
              (void 0 !== this.messageIdentifier &&
                (c = h(this.messageIdentifier, y, c)),
              this.type)
            ) {
              case o.CONNECT:
                (c = d(this.clientId, v(this.clientId), y, c)),
                  void 0 !== this.willMessage &&
                    ((c = d(
                      this.willMessage.destinationName,
                      v(this.willMessage.destinationName),
                      y,
                      c
                    )),
                    (c = h(e.byteLength, y, c)),
                    y.set(e, c),
                    (c += e.byteLength)),
                  void 0 !== this.userName &&
                    (c = d(this.userName, v(this.userName), y, c)),
                  void 0 !== this.password &&
                    (c = d(this.password, v(this.password), y, c));
                break;
              case o.PUBLISH:
                y.set(a, c);
                break;
              case o.SUBSCRIBE:
                for (var s = 0; s < this.topics.length; s++)
                  (c = d(this.topics[s], r[s], y, c)),
                    (y[c++] = this.requestedQos[s]);
                break;
              case o.UNSUBSCRIBE:
                for (var s = 0; s < this.topics.length; s++)
                  c = d(this.topics[s], r[s], y, c);
            }
            return p;
          };
          var _ = function (e, t) {
              (this._client = e),
                (this._keepAliveInterval = 1e3 * t),
                (this.isReset = !1);
              var n = new p(o.PINGREQ).encode(),
                r = function (e) {
                  return function () {
                    return i.apply(e);
                  };
                },
                i = function () {
                  this.isReset
                    ? ((this.isReset = !1),
                      this._client._trace("Pinger.doPing", "send PINGREQ"),
                      this._client.socket.send(n),
                      (this.timeout = setTimeout(
                        r(this),
                        this._keepAliveInterval
                      )))
                    : (this._client._trace("Pinger.doPing", "Timed out"),
                      this._client._disconnected(
                        a.PING_TIMEOUT.code,
                        c(a.PING_TIMEOUT)
                      ));
                };
              (this.reset = function () {
                (this.isReset = !0),
                  clearTimeout(this.timeout),
                  this._keepAliveInterval > 0 &&
                    (this.timeout = setTimeout(
                      r(this),
                      this._keepAliveInterval
                    ));
              }),
                (this.cancel = function () {
                  clearTimeout(this.timeout);
                });
            },
            b = function (e, t, n, r) {
              t || (t = 30),
                (this.timeout = setTimeout(function () {
                  return n.apply(e, r);
                }, 1e3 * t)),
                (this.cancel = function () {
                  clearTimeout(this.timeout);
                });
            },
            E = function (t, r, o, i, s) {
              if (!("WebSocket" in e && null !== e.WebSocket))
                throw Error(c(a.UNSUPPORTED, ["WebSocket"]));
              if (!("ArrayBuffer" in e && null !== e.ArrayBuffer))
                throw Error(c(a.UNSUPPORTED, ["ArrayBuffer"]));
              for (var u in (this._trace("Paho.Client", t, r, o, i, s),
              (this.host = r),
              (this.port = o),
              (this.path = i),
              (this.uri = t),
              (this.clientId = s),
              (this._wsuri = null),
              (this._localKey =
                r + ":" + o + ("/mqtt" != i ? ":" + i : "") + ":" + s + ":"),
              (this._msg_queue = []),
              (this._buffered_msg_queue = []),
              (this._sentMessages = {}),
              (this._receivedMessages = {}),
              (this._notify_msg_sent = {}),
              (this._message_identifier = 1),
              (this._sequence = 0),
              n))
                (0 === u.indexOf("Sent:" + this._localKey) ||
                  0 === u.indexOf("Received:" + this._localKey)) &&
                  this.restore(u);
            };
          (E.prototype.host = null),
            (E.prototype.port = null),
            (E.prototype.path = null),
            (E.prototype.uri = null),
            (E.prototype.clientId = null),
            (E.prototype.socket = null),
            (E.prototype.connected = !1),
            (E.prototype.maxMessageIdentifier = 65536),
            (E.prototype.connectOptions = null),
            (E.prototype.hostIndex = null),
            (E.prototype.onConnected = null),
            (E.prototype.onConnectionLost = null),
            (E.prototype.onMessageDelivered = null),
            (E.prototype.onMessageArrived = null),
            (E.prototype.traceFunction = null),
            (E.prototype._msg_queue = null),
            (E.prototype._buffered_msg_queue = null),
            (E.prototype._connectTimeout = null),
            (E.prototype.sendPinger = null),
            (E.prototype.receivePinger = null),
            (E.prototype._reconnectInterval = 1),
            (E.prototype._reconnecting = !1),
            (E.prototype._reconnectTimeout = null),
            (E.prototype.disconnectedPublishing = !1),
            (E.prototype.disconnectedBufferSize = 5e3),
            (E.prototype.receiveBuffer = null),
            (E.prototype._traceBuffer = null),
            (E.prototype._MAX_TRACE_ENTRIES = 100),
            (E.prototype.connect = function (e) {
              var t = this._traceMask(e, "password");
              if (
                (this._trace("Client.connect", t, this.socket, this.connected),
                this.connected || this.socket)
              )
                throw Error(c(a.INVALID_STATE, ["already connected"]));
              this._reconnecting &&
                (this._reconnectTimeout.cancel(),
                (this._reconnectTimeout = null),
                (this._reconnecting = !1)),
                (this.connectOptions = e),
                (this._reconnectInterval = 1),
                (this._reconnecting = !1),
                e.uris
                  ? ((this.hostIndex = 0), this._doConnect(e.uris[0]))
                  : this._doConnect(this.uri);
            }),
            (E.prototype.subscribe = function (e, t) {
              if ((this._trace("Client.subscribe", e, t), !this.connected))
                throw Error(c(a.INVALID_STATE, ["not connected"]));
              var n = new p(o.SUBSCRIBE);
              (n.topics = [e]),
                void 0 !== t.qos
                  ? (n.requestedQos = [t.qos])
                  : (n.requestedQos = [0]),
                t.onSuccess &&
                  (n.onSuccess = function (e) {
                    t.onSuccess({
                      invocationContext: t.invocationContext,
                      grantedQos: e,
                    });
                  }),
                t.onFailure &&
                  (n.onFailure = function (e) {
                    t.onFailure({
                      invocationContext: t.invocationContext,
                      errorCode: e,
                      errorMessage: c(e),
                    });
                  }),
                t.timeout &&
                  (n.timeOut = new b(this, t.timeout, t.onFailure, [
                    {
                      invocationContext: t.invocationContext,
                      errorCode: a.SUBSCRIBE_TIMEOUT.code,
                      errorMessage: c(a.SUBSCRIBE_TIMEOUT),
                    },
                  ])),
                this._requires_ack(n),
                this._schedule_message(n);
            }),
            (E.prototype.unsubscribe = function (e, t) {
              if ((this._trace("Client.unsubscribe", e, t), !this.connected))
                throw Error(c(a.INVALID_STATE, ["not connected"]));
              var n = new p(o.UNSUBSCRIBE);
              (n.topics = [e]),
                t.onSuccess &&
                  (n.callback = function () {
                    t.onSuccess({ invocationContext: t.invocationContext });
                  }),
                t.timeout &&
                  (n.timeOut = new b(this, t.timeout, t.onFailure, [
                    {
                      invocationContext: t.invocationContext,
                      errorCode: a.UNSUBSCRIBE_TIMEOUT.code,
                      errorMessage: c(a.UNSUBSCRIBE_TIMEOUT),
                    },
                  ])),
                this._requires_ack(n),
                this._schedule_message(n);
            }),
            (E.prototype.send = function (e) {
              this._trace("Client.send", e);
              var t = new p(o.PUBLISH);
              if (((t.payloadMessage = e), this.connected))
                e.qos > 0
                  ? this._requires_ack(t)
                  : this.onMessageDelivered &&
                    (this._notify_msg_sent[t] = this.onMessageDelivered(
                      t.payloadMessage
                    )),
                  this._schedule_message(t);
              else if (this._reconnecting && this.disconnectedPublishing) {
                if (
                  Object.keys(this._sentMessages).length +
                    this._buffered_msg_queue.length >
                  this.disconnectedBufferSize
                )
                  throw Error(c(a.BUFFER_FULL, [this.disconnectedBufferSize]));
                e.qos > 0
                  ? this._requires_ack(t)
                  : ((t.sequence = ++this._sequence),
                    this._buffered_msg_queue.unshift(t));
              } else throw Error(c(a.INVALID_STATE, ["not connected"]));
            }),
            (E.prototype.disconnect = function () {
              if (
                (this._trace("Client.disconnect"),
                this._reconnecting &&
                  (this._reconnectTimeout.cancel(),
                  (this._reconnectTimeout = null),
                  (this._reconnecting = !1)),
                !this.socket)
              )
                throw Error(
                  c(a.INVALID_STATE, ["not connecting or connected"])
                );
              var e = new p(o.DISCONNECT);
              (this._notify_msg_sent[e] = s(this._disconnected, this)),
                this._schedule_message(e);
            }),
            (E.prototype.getTraceLog = function () {
              if (null !== this._traceBuffer) {
                for (var e in (this._trace("Client.getTraceLog", new Date()),
                this._trace(
                  "Client.getTraceLog in flight messages",
                  this._sentMessages.length
                ),
                this._sentMessages))
                  this._trace("_sentMessages ", e, this._sentMessages[e]);
                for (var e in this._receivedMessages)
                  this._trace(
                    "_receivedMessages ",
                    e,
                    this._receivedMessages[e]
                  );
                return this._traceBuffer;
              }
            }),
            (E.prototype.startTrace = function () {
              null === this._traceBuffer && (this._traceBuffer = []),
                this._trace(
                  "Client.startTrace",
                  new Date(),
                  "@VERSION@-@BUILDLEVEL@"
                );
            }),
            (E.prototype.stopTrace = function () {
              delete this._traceBuffer;
            }),
            (E.prototype._doConnect = function (e) {
              if (this.connectOptions.useSSL) {
                var t = e.split(":");
                (t[0] = "wss"), (e = t.join(":"));
              }
              (this._wsuri = e),
                (this.connected = !1),
                this.connectOptions.mqttVersion < 4
                  ? (this.socket = new WebSocket(e, ["mqttv3.1"]))
                  : (this.socket = new WebSocket(e, ["mqtt"])),
                (this.socket.binaryType = "arraybuffer"),
                (this.socket.onopen = s(this._on_socket_open, this)),
                (this.socket.onmessage = s(this._on_socket_message, this)),
                (this.socket.onerror = s(this._on_socket_error, this)),
                (this.socket.onclose = s(this._on_socket_close, this)),
                (this.sendPinger = new _(
                  this,
                  this.connectOptions.keepAliveInterval
                )),
                (this.receivePinger = new _(
                  this,
                  this.connectOptions.keepAliveInterval
                )),
                this._connectTimeout &&
                  (this._connectTimeout.cancel(),
                  (this._connectTimeout = null)),
                (this._connectTimeout = new b(
                  this,
                  this.connectOptions.timeout,
                  this._disconnected,
                  [a.CONNECT_TIMEOUT.code, c(a.CONNECT_TIMEOUT)]
                ));
            }),
            (E.prototype._schedule_message = function (e) {
              this._msg_queue.unshift(e),
                this.connected && this._process_queue();
            }),
            (E.prototype.store = function (e, t) {
              var r = {
                type: t.type,
                messageIdentifier: t.messageIdentifier,
                version: 1,
              };
              if (t.type === o.PUBLISH) {
                t.pubRecReceived && (r.pubRecReceived = !0),
                  (r.payloadMessage = {});
                for (
                  var i = "", s = t.payloadMessage.payloadBytes, u = 0;
                  u < s.length;
                  u++
                )
                  s[u] <= 15
                    ? (i = i + "0" + s[u].toString(16))
                    : (i += s[u].toString(16));
                (r.payloadMessage.payloadHex = i),
                  (r.payloadMessage.qos = t.payloadMessage.qos),
                  (r.payloadMessage.destinationName =
                    t.payloadMessage.destinationName),
                  t.payloadMessage.duplicate &&
                    (r.payloadMessage.duplicate = !0),
                  t.payloadMessage.retained && (r.payloadMessage.retained = !0),
                  0 === e.indexOf("Sent:") &&
                    (void 0 === t.sequence && (t.sequence = ++this._sequence),
                    (r.sequence = t.sequence));
              } else
                throw Error(
                  c(a.INVALID_STORED_DATA, [
                    e + this._localKey + t.messageIdentifier,
                    r,
                  ])
                );
              n.setItem(
                e + this._localKey + t.messageIdentifier,
                JSON.stringify(r)
              );
            }),
            (E.prototype.restore = function (e) {
              var t = n.getItem(e),
                i = JSON.parse(t),
                s = new p(i.type, i);
              if (i.type === o.PUBLISH) {
                for (
                  var u = i.payloadMessage.payloadHex,
                    f = new ArrayBuffer(u.length / 2),
                    l = new Uint8Array(f),
                    h = 0;
                  u.length >= 2;

                ) {
                  var d = parseInt(u.substring(0, 2), 16);
                  (u = u.substring(2, u.length)), (l[h++] = d);
                }
                var y = new r.Message(l);
                (y.qos = i.payloadMessage.qos),
                  (y.destinationName = i.payloadMessage.destinationName),
                  i.payloadMessage.duplicate && (y.duplicate = !0),
                  i.payloadMessage.retained && (y.retained = !0),
                  (s.payloadMessage = y);
              } else throw Error(c(a.INVALID_STORED_DATA, [e, t]));
              0 === e.indexOf("Sent:" + this._localKey)
                ? ((s.payloadMessage.duplicate = !0),
                  (this._sentMessages[s.messageIdentifier] = s))
                : 0 === e.indexOf("Received:" + this._localKey) &&
                  (this._receivedMessages[s.messageIdentifier] = s);
            }),
            (E.prototype._process_queue = function () {
              for (var e = null; (e = this._msg_queue.pop()); )
                this._socket_send(e),
                  this._notify_msg_sent[e] &&
                    (this._notify_msg_sent[e](),
                    delete this._notify_msg_sent[e]);
            }),
            (E.prototype._requires_ack = function (e) {
              var t = Object.keys(this._sentMessages).length;
              if (t > this.maxMessageIdentifier)
                throw Error("Too many messages:" + t);
              for (; void 0 !== this._sentMessages[this._message_identifier]; )
                this._message_identifier++;
              (e.messageIdentifier = this._message_identifier),
                (this._sentMessages[e.messageIdentifier] = e),
                e.type === o.PUBLISH && this.store("Sent:", e),
                this._message_identifier === this.maxMessageIdentifier &&
                  (this._message_identifier = 1);
            }),
            (E.prototype._on_socket_open = function () {
              var e = new p(o.CONNECT, this.connectOptions);
              (e.clientId = this.clientId), this._socket_send(e);
            }),
            (E.prototype._on_socket_message = function (e) {
              this._trace("Client._on_socket_message", e.data);
              for (
                var t = this._deframeMessages(e.data), n = 0;
                n < t.length;
                n += 1
              )
                this._handleMessage(t[n]);
            }),
            (E.prototype._deframeMessages = function (e) {
              var t = new Uint8Array(e),
                n = [];
              if (this.receiveBuffer) {
                var i = new Uint8Array(this.receiveBuffer.length + t.length);
                i.set(this.receiveBuffer),
                  i.set(t, this.receiveBuffer.length),
                  (t = i),
                  delete this.receiveBuffer;
              }
              try {
                for (var s = 0; s < t.length; ) {
                  var u = (function (e, t) {
                      var n,
                        i = t,
                        s = e[t],
                        a = s >> 4,
                        u = (s &= 15);
                      t += 1;
                      var c = 0,
                        f = 1;
                      do {
                        if (t == e.length) return [null, i];
                        (c += (127 & (n = e[t++])) * f), (f *= 128);
                      } while ((128 & n) != 0);
                      var l = t + c;
                      if (l > e.length) return [null, i];
                      var h = new p(a);
                      switch (a) {
                        case o.CONNACK:
                          1 & e[t++] && (h.sessionPresent = !0),
                            (h.returnCode = e[t++]);
                          break;
                        case o.PUBLISH:
                          var d = (u >> 1) & 3,
                            v = y(e, t),
                            g = m(e, (t += 2), v);
                          (t += v),
                            d > 0 &&
                              ((h.messageIdentifier = y(e, t)), (t += 2));
                          var _ = new r.Message(e.subarray(t, l));
                          (1 & u) == 1 && (_.retained = !0),
                            (8 & u) == 8 && (_.duplicate = !0),
                            (_.qos = d),
                            (_.destinationName = g),
                            (h.payloadMessage = _);
                          break;
                        case o.PUBACK:
                        case o.PUBREC:
                        case o.PUBREL:
                        case o.PUBCOMP:
                        case o.UNSUBACK:
                          h.messageIdentifier = y(e, t);
                          break;
                        case o.SUBACK:
                          (h.messageIdentifier = y(e, t)),
                            (t += 2),
                            (h.returnCode = e.subarray(t, l));
                      }
                      return [h, l];
                    })(t, s),
                    f = u[0];
                  if (((s = u[1]), null !== f)) n.push(f);
                  else break;
                }
                s < t.length && (this.receiveBuffer = t.subarray(s));
              } catch (e) {
                var l =
                  "undefined" == e.hasOwnProperty("stack")
                    ? e.stack.toString()
                    : "No Error Stack Available";
                this._disconnected(
                  a.INTERNAL_ERROR.code,
                  c(a.INTERNAL_ERROR, [e.message, l])
                );
                return;
              }
              return n;
            }),
            (E.prototype._handleMessage = function (e) {
              this._trace("Client._handleMessage", e);
              try {
                switch (e.type) {
                  case o.CONNACK:
                    if (
                      (this._connectTimeout.cancel(),
                      this._reconnectTimeout && this._reconnectTimeout.cancel(),
                      this.connectOptions.cleanSession)
                    ) {
                      for (var t in this._sentMessages) {
                        var r = this._sentMessages[t];
                        n.removeItem(
                          "Sent:" + this._localKey + r.messageIdentifier
                        );
                      }
                      for (var t in ((this._sentMessages = {}),
                      this._receivedMessages)) {
                        var i = this._receivedMessages[t];
                        n.removeItem(
                          "Received:" + this._localKey + i.messageIdentifier
                        );
                      }
                      this._receivedMessages = {};
                    }
                    if (0 === e.returnCode)
                      (this.connected = !0),
                        this.connectOptions.uris &&
                          (this.hostIndex = this.connectOptions.uris.length);
                    else {
                      this._disconnected(
                        a.CONNACK_RETURNCODE.code,
                        c(a.CONNACK_RETURNCODE, [e.returnCode, u[e.returnCode]])
                      );
                      break;
                    }
                    var s = [];
                    for (var f in this._sentMessages)
                      this._sentMessages.hasOwnProperty(f) &&
                        s.push(this._sentMessages[f]);
                    if (this._buffered_msg_queue.length > 0)
                      for (var l = null; (l = this._buffered_msg_queue.pop()); )
                        s.push(l),
                          this.onMessageDelivered &&
                            (this._notify_msg_sent[l] = this.onMessageDelivered(
                              l.payloadMessage
                            ));
                    for (
                      var s = s.sort(function (e, t) {
                          return e.sequence - t.sequence;
                        }),
                        h = 0,
                        d = s.length;
                      h < d;
                      h++
                    ) {
                      var r = s[h];
                      if (r.type == o.PUBLISH && r.pubRecReceived) {
                        var y = new p(o.PUBREL, {
                          messageIdentifier: r.messageIdentifier,
                        });
                        this._schedule_message(y);
                      } else this._schedule_message(r);
                    }
                    this.connectOptions.onSuccess &&
                      this.connectOptions.onSuccess({
                        invocationContext:
                          this.connectOptions.invocationContext,
                      });
                    var v = !1;
                    this._reconnecting &&
                      ((v = !0),
                      (this._reconnectInterval = 1),
                      (this._reconnecting = !1)),
                      this._connected(v, this._wsuri),
                      this._process_queue();
                    break;
                  case o.PUBLISH:
                    this._receivePublish(e);
                    break;
                  case o.PUBACK:
                    var r = this._sentMessages[e.messageIdentifier];
                    r &&
                      (delete this._sentMessages[e.messageIdentifier],
                      n.removeItem(
                        "Sent:" + this._localKey + e.messageIdentifier
                      ),
                      this.onMessageDelivered &&
                        this.onMessageDelivered(r.payloadMessage));
                    break;
                  case o.PUBREC:
                    var r = this._sentMessages[e.messageIdentifier];
                    if (r) {
                      r.pubRecReceived = !0;
                      var y = new p(o.PUBREL, {
                        messageIdentifier: e.messageIdentifier,
                      });
                      this.store("Sent:", r), this._schedule_message(y);
                    }
                    break;
                  case o.PUBREL:
                    var i = this._receivedMessages[e.messageIdentifier];
                    n.removeItem(
                      "Received:" + this._localKey + e.messageIdentifier
                    ),
                      i &&
                        (this._receiveMessage(i),
                        delete this._receivedMessages[e.messageIdentifier]);
                    var g = new p(o.PUBCOMP, {
                      messageIdentifier: e.messageIdentifier,
                    });
                    this._schedule_message(g);
                    break;
                  case o.PUBCOMP:
                    var r = this._sentMessages[e.messageIdentifier];
                    delete this._sentMessages[e.messageIdentifier],
                      n.removeItem(
                        "Sent:" + this._localKey + e.messageIdentifier
                      ),
                      this.onMessageDelivered &&
                        this.onMessageDelivered(r.payloadMessage);
                    break;
                  case o.SUBACK:
                    var r = this._sentMessages[e.messageIdentifier];
                    r &&
                      (r.timeOut && r.timeOut.cancel(),
                      128 === e.returnCode[0]
                        ? r.onFailure && r.onFailure(e.returnCode)
                        : r.onSuccess && r.onSuccess(e.returnCode),
                      delete this._sentMessages[e.messageIdentifier]);
                    break;
                  case o.UNSUBACK:
                    var r = this._sentMessages[e.messageIdentifier];
                    r &&
                      (r.timeOut && r.timeOut.cancel(),
                      r.callback && r.callback(),
                      delete this._sentMessages[e.messageIdentifier]);
                    break;
                  case o.PINGRESP:
                    this.sendPinger.reset();
                    break;
                  case o.DISCONNECT:
                  default:
                    this._disconnected(
                      a.INVALID_MQTT_MESSAGE_TYPE.code,
                      c(a.INVALID_MQTT_MESSAGE_TYPE, [e.type])
                    );
                }
              } catch (e) {
                var m =
                  "undefined" == e.hasOwnProperty("stack")
                    ? e.stack.toString()
                    : "No Error Stack Available";
                this._disconnected(
                  a.INTERNAL_ERROR.code,
                  c(a.INTERNAL_ERROR, [e.message, m])
                );
                return;
              }
            }),
            (E.prototype._on_socket_error = function (e) {
              this._reconnecting ||
                this._disconnected(
                  a.SOCKET_ERROR.code,
                  c(a.SOCKET_ERROR, [e.data])
                );
            }),
            (E.prototype._on_socket_close = function () {
              this._reconnecting ||
                this._disconnected(a.SOCKET_CLOSE.code, c(a.SOCKET_CLOSE));
            }),
            (E.prototype._socket_send = function (e) {
              if (1 == e.type) {
                var t = this._traceMask(e, "password");
                this._trace("Client._socket_send", t);
              } else this._trace("Client._socket_send", e);
              this.socket.send(e.encode()), this.sendPinger.reset();
            }),
            (E.prototype._receivePublish = function (e) {
              switch (e.payloadMessage.qos) {
                case "undefined":
                case 0:
                  this._receiveMessage(e);
                  break;
                case 1:
                  var t = new p(o.PUBACK, {
                    messageIdentifier: e.messageIdentifier,
                  });
                  this._schedule_message(t), this._receiveMessage(e);
                  break;
                case 2:
                  (this._receivedMessages[e.messageIdentifier] = e),
                    this.store("Received:", e);
                  var n = new p(o.PUBREC, {
                    messageIdentifier: e.messageIdentifier,
                  });
                  this._schedule_message(n);
                  break;
                default:
                  throw Error("Invaild qos=" + e.payloadMessage.qos);
              }
            }),
            (E.prototype._receiveMessage = function (e) {
              this.onMessageArrived && this.onMessageArrived(e.payloadMessage);
            }),
            (E.prototype._connected = function (e, t) {
              this.onConnected && this.onConnected(e, t);
            }),
            (E.prototype._reconnect = function () {
              this._trace("Client._reconnect"),
                this.connected ||
                  ((this._reconnecting = !0),
                  this.sendPinger.cancel(),
                  this.receivePinger.cancel(),
                  this._reconnectInterval < 128 &&
                    (this._reconnectInterval = 2 * this._reconnectInterval),
                  this.connectOptions.uris
                    ? ((this.hostIndex = 0),
                      this._doConnect(this.connectOptions.uris[0]))
                    : this._doConnect(this.uri));
            }),
            (E.prototype._disconnected = function (e, t) {
              if (
                (this._trace("Client._disconnected", e, t),
                void 0 !== e && this._reconnecting)
              ) {
                this._reconnectTimeout = new b(
                  this,
                  this._reconnectInterval,
                  this._reconnect
                );
                return;
              }
              if (
                (this.sendPinger.cancel(),
                this.receivePinger.cancel(),
                this._connectTimeout &&
                  (this._connectTimeout.cancel(),
                  (this._connectTimeout = null)),
                (this._msg_queue = []),
                (this._buffered_msg_queue = []),
                (this._notify_msg_sent = {}),
                this.socket &&
                  ((this.socket.onopen = null),
                  (this.socket.onmessage = null),
                  (this.socket.onerror = null),
                  (this.socket.onclose = null),
                  1 === this.socket.readyState && this.socket.close(),
                  delete this.socket),
                this.connectOptions.uris &&
                  this.hostIndex < this.connectOptions.uris.length - 1)
              )
                this.hostIndex++,
                  this._doConnect(this.connectOptions.uris[this.hostIndex]);
              else if (
                (void 0 === e && ((e = a.OK.code), (t = c(a.OK))),
                this.connected)
              ) {
                if (
                  ((this.connected = !1),
                  this.onConnectionLost &&
                    this.onConnectionLost({
                      errorCode: e,
                      errorMessage: t,
                      reconnect: this.connectOptions.reconnect,
                      uri: this._wsuri,
                    }),
                  e !== a.OK.code && this.connectOptions.reconnect)
                ) {
                  (this._reconnectInterval = 1), this._reconnect();
                  return;
                }
              } else
                4 === this.connectOptions.mqttVersion &&
                !1 === this.connectOptions.mqttVersionExplicit
                  ? (this._trace("Failed to connect V4, dropping back to V3"),
                    (this.connectOptions.mqttVersion = 3),
                    this.connectOptions.uris
                      ? ((this.hostIndex = 0),
                        this._doConnect(this.connectOptions.uris[0]))
                      : this._doConnect(this.uri))
                  : this.connectOptions.onFailure &&
                    this.connectOptions.onFailure({
                      invocationContext: this.connectOptions.invocationContext,
                      errorCode: e,
                      errorMessage: t,
                    });
            }),
            (E.prototype._trace = function () {
              if (this.traceFunction) {
                var e = Array.prototype.slice.call(arguments);
                for (var t in e)
                  void 0 !== e[t] && e.splice(t, 1, JSON.stringify(e[t]));
                var n = e.join("");
                this.traceFunction({ severity: "Debug", message: n });
              }
              if (null !== this._traceBuffer)
                for (var t = 0, r = arguments.length; t < r; t++)
                  this._traceBuffer.length == this._MAX_TRACE_ENTRIES &&
                    this._traceBuffer.shift(),
                    0 === t
                      ? this._traceBuffer.push(arguments[t])
                      : void 0 === arguments[t]
                      ? this._traceBuffer.push(arguments[t])
                      : this._traceBuffer.push(
                          "  " + JSON.stringify(arguments[t])
                        );
            }),
            (E.prototype._traceMask = function (e, t) {
              var n = {};
              for (var r in e)
                e.hasOwnProperty(r) &&
                  (r == t ? (n[r] = "******") : (n[r] = e[r]));
              return n;
            });
          var T = function (e) {
            if (
              "string" == typeof e ||
              e instanceof ArrayBuffer ||
              (ArrayBuffer.isView(e) && !(e instanceof DataView))
            )
              t = e;
            else throw c(a.INVALID_ARGUMENT, [e, "newPayload"]);
            var t,
              n,
              r = 0,
              o = !1,
              i = !1;
            Object.defineProperties(this, {
              payloadString: {
                enumerable: !0,
                get: function () {
                  return "string" == typeof t ? t : m(t, 0, t.length);
                },
              },
              payloadBytes: {
                enumerable: !0,
                get: function () {
                  if ("string" != typeof t) return t;
                  var e = new ArrayBuffer(v(t)),
                    n = new Uint8Array(e);
                  return g(t, n, 0), n;
                },
              },
              destinationName: {
                enumerable: !0,
                get: function () {
                  return n;
                },
                set: function (e) {
                  if ("string" == typeof e) n = e;
                  else
                    throw Error(
                      c(a.INVALID_ARGUMENT, [e, "newDestinationName"])
                    );
                },
              },
              qos: {
                enumerable: !0,
                get: function () {
                  return r;
                },
                set: function (e) {
                  if (0 === e || 1 === e || 2 === e) r = e;
                  else throw Error("Invalid argument:" + e);
                },
              },
              retained: {
                enumerable: !0,
                get: function () {
                  return o;
                },
                set: function (e) {
                  if ("boolean" == typeof e) o = e;
                  else throw Error(c(a.INVALID_ARGUMENT, [e, "newRetained"]));
                },
              },
              topic: {
                enumerable: !0,
                get: function () {
                  return n;
                },
                set: function (e) {
                  n = e;
                },
              },
              duplicate: {
                enumerable: !0,
                get: function () {
                  return i;
                },
                set: function (e) {
                  i = e;
                },
              },
            });
          };
          return {
            Client: function (e, t, n, r) {
              if ("string" != typeof e)
                throw Error(c(a.INVALID_TYPE, [typeof e, "host"]));
              if (2 == arguments.length) {
                r = t;
                var o,
                  s = (o = e).match(
                    /^(wss?):\/\/((\[(.+)\])|([^\/]+?))(:(\d+))?(\/.*)$/
                  );
                if (s) (e = s[4] || s[2]), (t = parseInt(s[7])), (n = s[8]);
                else throw Error(c(a.INVALID_ARGUMENT, [e, "host"]));
              } else {
                if (
                  (3 == arguments.length && ((r = n), (n = "/mqtt")),
                  "number" != typeof t || t < 0)
                )
                  throw Error(c(a.INVALID_TYPE, [typeof t, "port"]));
                if ("string" != typeof n)
                  throw Error(c(a.INVALID_TYPE, [typeof n, "path"]));
                o =
                  "ws://" +
                  (-1 !== e.indexOf(":") &&
                  "[" !== e.slice(0, 1) &&
                  "]" !== e.slice(-1)
                    ? "[" + e + "]"
                    : e) +
                  ":" +
                  t +
                  n;
              }
              for (var u = 0, f = 0; f < r.length; f++) {
                var l = r.charCodeAt(f);
                55296 <= l && l <= 56319 && f++, u++;
              }
              if ("string" != typeof r || u > 65535)
                throw Error(c(a.INVALID_ARGUMENT, [r, "clientId"]));
              var p = new E(o, e, t, n, r);
              Object.defineProperties(this, {
                host: {
                  get: function () {
                    return e;
                  },
                  set: function () {
                    throw Error(c(a.UNSUPPORTED_OPERATION));
                  },
                },
                port: {
                  get: function () {
                    return t;
                  },
                  set: function () {
                    throw Error(c(a.UNSUPPORTED_OPERATION));
                  },
                },
                path: {
                  get: function () {
                    return n;
                  },
                  set: function () {
                    throw Error(c(a.UNSUPPORTED_OPERATION));
                  },
                },
                uri: {
                  get: function () {
                    return o;
                  },
                  set: function () {
                    throw Error(c(a.UNSUPPORTED_OPERATION));
                  },
                },
                clientId: {
                  get: function () {
                    return p.clientId;
                  },
                  set: function () {
                    throw Error(c(a.UNSUPPORTED_OPERATION));
                  },
                },
                onConnected: {
                  get: function () {
                    return p.onConnected;
                  },
                  set: function (e) {
                    if ("function" == typeof e) p.onConnected = e;
                    else
                      throw Error(c(a.INVALID_TYPE, [typeof e, "onConnected"]));
                  },
                },
                disconnectedPublishing: {
                  get: function () {
                    return p.disconnectedPublishing;
                  },
                  set: function (e) {
                    p.disconnectedPublishing = e;
                  },
                },
                disconnectedBufferSize: {
                  get: function () {
                    return p.disconnectedBufferSize;
                  },
                  set: function (e) {
                    p.disconnectedBufferSize = e;
                  },
                },
                onConnectionLost: {
                  get: function () {
                    return p.onConnectionLost;
                  },
                  set: function (e) {
                    if ("function" == typeof e) p.onConnectionLost = e;
                    else
                      throw Error(
                        c(a.INVALID_TYPE, [typeof e, "onConnectionLost"])
                      );
                  },
                },
                onMessageDelivered: {
                  get: function () {
                    return p.onMessageDelivered;
                  },
                  set: function (e) {
                    if ("function" == typeof e) p.onMessageDelivered = e;
                    else
                      throw Error(
                        c(a.INVALID_TYPE, [typeof e, "onMessageDelivered"])
                      );
                  },
                },
                onMessageArrived: {
                  get: function () {
                    return p.onMessageArrived;
                  },
                  set: function (e) {
                    if ("function" == typeof e) p.onMessageArrived = e;
                    else
                      throw Error(
                        c(a.INVALID_TYPE, [typeof e, "onMessageArrived"])
                      );
                  },
                },
                trace: {
                  get: function () {
                    return p.traceFunction;
                  },
                  set: function (e) {
                    if ("function" == typeof e) p.traceFunction = e;
                    else throw Error(c(a.INVALID_TYPE, [typeof e, "onTrace"]));
                  },
                },
              }),
                (this.connect = function (e) {
                  if (
                    (i((e = e || {}), {
                      timeout: "number",
                      userName: "string",
                      password: "string",
                      willMessage: "object",
                      keepAliveInterval: "number",
                      cleanSession: "boolean",
                      useSSL: "boolean",
                      invocationContext: "object",
                      onSuccess: "function",
                      onFailure: "function",
                      hosts: "object",
                      ports: "object",
                      reconnect: "boolean",
                      mqttVersion: "number",
                      mqttVersionExplicit: "boolean",
                      uris: "object",
                    }),
                    void 0 === e.keepAliveInterval &&
                      (e.keepAliveInterval = 60),
                    e.mqttVersion > 4 || e.mqttVersion < 3)
                  )
                    throw Error(
                      c(a.INVALID_ARGUMENT, [
                        e.mqttVersion,
                        "connectOptions.mqttVersion",
                      ])
                    );
                  if (
                    (void 0 === e.mqttVersion
                      ? ((e.mqttVersionExplicit = !1), (e.mqttVersion = 4))
                      : (e.mqttVersionExplicit = !0),
                    void 0 !== e.password && void 0 === e.userName)
                  )
                    throw Error(
                      c(a.INVALID_ARGUMENT, [
                        e.password,
                        "connectOptions.password",
                      ])
                    );
                  if (e.willMessage) {
                    if (!(e.willMessage instanceof T))
                      throw Error(
                        c(a.INVALID_TYPE, [
                          e.willMessage,
                          "connectOptions.willMessage",
                        ])
                      );
                    if (
                      ((e.willMessage.stringPayload = null),
                      void 0 === e.willMessage.destinationName)
                    )
                      throw Error(
                        c(a.INVALID_TYPE, [
                          typeof e.willMessage.destinationName,
                          "connectOptions.willMessage.destinationName",
                        ])
                      );
                  }
                  if (
                    (void 0 === e.cleanSession && (e.cleanSession = !0),
                    e.hosts)
                  ) {
                    if (!(e.hosts instanceof Array) || e.hosts.length < 1)
                      throw Error(
                        c(a.INVALID_ARGUMENT, [e.hosts, "connectOptions.hosts"])
                      );
                    for (var t = !1, r = 0; r < e.hosts.length; r++) {
                      if ("string" != typeof e.hosts[r])
                        throw Error(
                          c(a.INVALID_TYPE, [
                            typeof e.hosts[r],
                            "connectOptions.hosts[" + r + "]",
                          ])
                        );
                      if (
                        /^(wss?):\/\/((\[(.+)\])|([^\/]+?))(:(\d+))?(\/.*)$/.test(
                          e.hosts[r]
                        )
                      ) {
                        if (0 === r) t = !0;
                        else if (!t)
                          throw Error(
                            c(a.INVALID_ARGUMENT, [
                              e.hosts[r],
                              "connectOptions.hosts[" + r + "]",
                            ])
                          );
                      } else if (t)
                        throw Error(
                          c(a.INVALID_ARGUMENT, [
                            e.hosts[r],
                            "connectOptions.hosts[" + r + "]",
                          ])
                        );
                    }
                    if (t) e.uris = e.hosts;
                    else {
                      if (
                        !e.ports ||
                        !(e.ports instanceof Array) ||
                        e.hosts.length !== e.ports.length
                      )
                        throw Error(
                          c(a.INVALID_ARGUMENT, [
                            e.ports,
                            "connectOptions.ports",
                          ])
                        );
                      e.uris = [];
                      for (var r = 0; r < e.hosts.length; r++) {
                        if ("number" != typeof e.ports[r] || e.ports[r] < 0)
                          throw Error(
                            c(a.INVALID_TYPE, [
                              typeof e.ports[r],
                              "connectOptions.ports[" + r + "]",
                            ])
                          );
                        var s = e.hosts[r],
                          u = e.ports[r];
                        (o =
                          "ws://" +
                          (-1 !== s.indexOf(":") ? "[" + s + "]" : s) +
                          ":" +
                          u +
                          n),
                          e.uris.push(o);
                      }
                    }
                  }
                  p.connect(e);
                }),
                (this.subscribe = function (e, t) {
                  if ("string" != typeof e)
                    throw Error("Invalid argument:" + e);
                  if (
                    (i((t = t || {}), {
                      qos: "number",
                      invocationContext: "object",
                      onSuccess: "function",
                      onFailure: "function",
                      timeout: "number",
                    }),
                    t.timeout && !t.onFailure)
                  )
                    throw Error(
                      "subscribeOptions.timeout specified with no onFailure callback."
                    );
                  if (
                    void 0 !== t.qos &&
                    !(0 === t.qos || 1 === t.qos || 2 === t.qos)
                  )
                    throw Error(
                      c(a.INVALID_ARGUMENT, [t.qos, "subscribeOptions.qos"])
                    );
                  p.subscribe(e, t);
                }),
                (this.unsubscribe = function (e, t) {
                  if ("string" != typeof e)
                    throw Error("Invalid argument:" + e);
                  if (
                    (i((t = t || {}), {
                      invocationContext: "object",
                      onSuccess: "function",
                      onFailure: "function",
                      timeout: "number",
                    }),
                    t.timeout && !t.onFailure)
                  )
                    throw Error(
                      "unsubscribeOptions.timeout specified with no onFailure callback."
                    );
                  p.unsubscribe(e, t);
                }),
                (this.send = function (e, t, n, r) {
                  var o;
                  if (0 == arguments.length)
                    throw Error("Invalid argument.length");
                  if (1 == arguments.length) {
                    if (!(e instanceof T) && "string" != typeof e)
                      throw Error("Invalid argument:" + typeof e);
                    if (void 0 === (o = e).destinationName)
                      throw Error(
                        c(a.INVALID_ARGUMENT, [
                          o.destinationName,
                          "Message.destinationName",
                        ])
                      );
                    p.send(o);
                  } else
                    ((o = new T(t)).destinationName = e),
                      arguments.length >= 3 && (o.qos = n),
                      arguments.length >= 4 && (o.retained = r),
                      p.send(o);
                }),
                (this.publish = function (e, t, n, r) {
                  var o;
                  if (0 == arguments.length)
                    throw Error("Invalid argument.length");
                  if (1 == arguments.length) {
                    if (!(e instanceof T) && "string" != typeof e)
                      throw Error("Invalid argument:" + typeof e);
                    if (void 0 === (o = e).destinationName)
                      throw Error(
                        c(a.INVALID_ARGUMENT, [
                          o.destinationName,
                          "Message.destinationName",
                        ])
                      );
                    p.send(o);
                  } else
                    ((o = new T(t)).destinationName = e),
                      arguments.length >= 3 && (o.qos = n),
                      arguments.length >= 4 && (o.retained = r),
                      p.send(o);
                }),
                (this.disconnect = function () {
                  p.disconnect();
                }),
                (this.getTraceLog = function () {
                  return p.getTraceLog();
                }),
                (this.startTrace = function () {
                  p.startTrace();
                }),
                (this.stopTrace = function () {
                  p.stopTrace();
                }),
                (this.isConnected = function () {
                  return p.connected;
                });
            },
            Message: T,
          };
        })(
          void 0 !== n.g
            ? n.g
            : "undefined" != typeof self
            ? self
            : "undefined" != typeof window
            ? window
            : {}
        );
      },
      79742: function (e, t) {
        "use strict";
        (t.byteLength = function (e) {
          var t = u(e),
            n = t[0],
            r = t[1];
          return ((n + r) * 3) / 4 - r;
        }),
          (t.toByteArray = function (e) {
            var t,
              n,
              i = u(e),
              s = i[0],
              a = i[1],
              c = new o(((s + a) * 3) / 4 - a),
              f = 0,
              l = a > 0 ? s - 4 : s;
            for (n = 0; n < l; n += 4)
              (t =
                (r[e.charCodeAt(n)] << 18) |
                (r[e.charCodeAt(n + 1)] << 12) |
                (r[e.charCodeAt(n + 2)] << 6) |
                r[e.charCodeAt(n + 3)]),
                (c[f++] = (t >> 16) & 255),
                (c[f++] = (t >> 8) & 255),
                (c[f++] = 255 & t);
            return (
              2 === a &&
                ((t =
                  (r[e.charCodeAt(n)] << 2) | (r[e.charCodeAt(n + 1)] >> 4)),
                (c[f++] = 255 & t)),
              1 === a &&
                ((t =
                  (r[e.charCodeAt(n)] << 10) |
                  (r[e.charCodeAt(n + 1)] << 4) |
                  (r[e.charCodeAt(n + 2)] >> 2)),
                (c[f++] = (t >> 8) & 255),
                (c[f++] = 255 & t)),
              c
            );
          }),
          (t.fromByteArray = function (e) {
            for (
              var t, r = e.length, o = r % 3, i = [], s = 0, a = r - o;
              s < a;
              s += 16383
            )
              i.push(
                (function (e, t, r) {
                  for (var o, i = [], s = t; s < r; s += 3)
                    i.push(
                      n[
                        ((o =
                          ((e[s] << 16) & 16711680) +
                          ((e[s + 1] << 8) & 65280) +
                          (255 & e[s + 2])) >>
                          18) &
                          63
                      ] +
                        n[(o >> 12) & 63] +
                        n[(o >> 6) & 63] +
                        n[63 & o]
                    );
                  return i.join("");
                })(e, s, s + 16383 > a ? a : s + 16383)
              );
            return (
              1 === o
                ? i.push(n[(t = e[r - 1]) >> 2] + n[(t << 4) & 63] + "==")
                : 2 === o &&
                  i.push(
                    n[(t = (e[r - 2] << 8) + e[r - 1]) >> 10] +
                      n[(t >> 4) & 63] +
                      n[(t << 2) & 63] +
                      "="
                  ),
              i.join("")
            );
          });
        for (
          var n = [],
            r = [],
            o = "undefined" != typeof Uint8Array ? Uint8Array : Array,
            i =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
            s = 0,
            a = i.length;
          s < a;
          ++s
        )
          (n[s] = i[s]), (r[i.charCodeAt(s)] = s);
        function u(e) {
          var t = e.length;
          if (t % 4 > 0)
            throw Error("Invalid string. Length must be a multiple of 4");
          var n = e.indexOf("=");
          -1 === n && (n = t);
          var r = n === t ? 0 : 4 - (n % 4);
          return [n, r];
        }
        (r["-".charCodeAt(0)] = 62), (r["_".charCodeAt(0)] = 63);
      },
      48764: function (e, t, n) {
        "use strict";
        /*!
         * The buffer module from node.js, for the browser.
         *
         * @author   Feross Aboukhadijeh <https://feross.org>
         * @license  MIT
         */ var r = n(79742),
          o = n(80645),
          i =
            "function" == typeof Symbol && "function" == typeof Symbol.for
              ? Symbol.for("nodejs.util.inspect.custom")
              : null;
        function s(e) {
          if (e > 2147483647)
            throw RangeError(
              'The value "' + e + '" is invalid for option "size"'
            );
          var t = new Uint8Array(e);
          return Object.setPrototypeOf(t, a.prototype), t;
        }
        function a(e, t, n) {
          if ("number" == typeof e) {
            if ("string" == typeof t)
              throw TypeError(
                'The "string" argument must be of type string. Received type number'
              );
            return f(e);
          }
          return u(e, t, n);
        }
        function u(e, t, n) {
          if ("string" == typeof e)
            return (function (e, t) {
              if (
                (("string" != typeof t || "" === t) && (t = "utf8"),
                !a.isEncoding(t))
              )
                throw TypeError("Unknown encoding: " + t);
              var n = 0 | h(e, t),
                r = s(n),
                o = r.write(e, t);
              return o !== n && (r = r.slice(0, o)), r;
            })(e, t);
          if (ArrayBuffer.isView(e)) return l(e);
          if (null == e)
            throw TypeError(
              "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
                typeof e
            );
          if (
            C(e, ArrayBuffer) ||
            (e && C(e.buffer, ArrayBuffer)) ||
            ("undefined" != typeof SharedArrayBuffer &&
              (C(e, SharedArrayBuffer) ||
                (e && C(e.buffer, SharedArrayBuffer))))
          )
            return (function (e, t, n) {
              var r;
              if (t < 0 || e.byteLength < t)
                throw RangeError('"offset" is outside of buffer bounds');
              if (e.byteLength < t + (n || 0))
                throw RangeError('"length" is outside of buffer bounds');
              return (
                Object.setPrototypeOf(
                  (r =
                    void 0 === t && void 0 === n
                      ? new Uint8Array(e)
                      : void 0 === n
                      ? new Uint8Array(e, t)
                      : new Uint8Array(e, t, n)),
                  a.prototype
                ),
                r
              );
            })(e, t, n);
          if ("number" == typeof e)
            throw TypeError(
              'The "value" argument must not be of type number. Received type number'
            );
          var r = e.valueOf && e.valueOf();
          if (null != r && r !== e) return a.from(r, t, n);
          var o = (function (e) {
            if (a.isBuffer(e)) {
              var t,
                n = 0 | p(e.length),
                r = s(n);
              return 0 === r.length || e.copy(r, 0, 0, n), r;
            }
            return void 0 !== e.length
              ? "number" != typeof e.length || (t = e.length) != t
                ? s(0)
                : l(e)
              : "Buffer" === e.type && Array.isArray(e.data)
              ? l(e.data)
              : void 0;
          })(e);
          if (o) return o;
          if (
            "undefined" != typeof Symbol &&
            null != Symbol.toPrimitive &&
            "function" == typeof e[Symbol.toPrimitive]
          )
            return a.from(e[Symbol.toPrimitive]("string"), t, n);
          throw TypeError(
            "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " +
              typeof e
          );
        }
        function c(e) {
          if ("number" != typeof e)
            throw TypeError('"size" argument must be of type number');
          if (e < 0)
            throw RangeError(
              'The value "' + e + '" is invalid for option "size"'
            );
        }
        function f(e) {
          return c(e), s(e < 0 ? 0 : 0 | p(e));
        }
        function l(e) {
          for (
            var t = e.length < 0 ? 0 : 0 | p(e.length), n = s(t), r = 0;
            r < t;
            r += 1
          )
            n[r] = 255 & e[r];
          return n;
        }
        function p(e) {
          if (e >= 2147483647)
            throw RangeError(
              "Attempt to allocate Buffer larger than maximum size: 0x7fffffff bytes"
            );
          return 0 | e;
        }
        function h(e, t) {
          if (a.isBuffer(e)) return e.length;
          if (ArrayBuffer.isView(e) || C(e, ArrayBuffer)) return e.byteLength;
          if ("string" != typeof e)
            throw TypeError(
              'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' +
                typeof e
            );
          var n = e.length,
            r = arguments.length > 2 && !0 === arguments[2];
          if (!r && 0 === n) return 0;
          for (var o = !1; ; )
            switch (t) {
              case "ascii":
              case "latin1":
              case "binary":
                return n;
              case "utf8":
              case "utf-8":
                return A(e).length;
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return 2 * n;
              case "hex":
                return n >>> 1;
              case "base64":
                return I(e).length;
              default:
                if (o) return r ? -1 : A(e).length;
                (t = ("" + t).toLowerCase()), (o = !0);
            }
        }
        function d(e, t, n) {
          var o,
            i,
            s = !1;
          if (
            ((void 0 === t || t < 0) && (t = 0),
            t > this.length ||
              ((void 0 === n || n > this.length) && (n = this.length),
              n <= 0 || (n >>>= 0) <= (t >>>= 0)))
          )
            return "";
          for (e || (e = "utf8"); ; )
            switch (e) {
              case "hex":
                return (function (e, t, n) {
                  var r = e.length;
                  (!t || t < 0) && (t = 0), (!n || n < 0 || n > r) && (n = r);
                  for (var o = "", i = t; i < n; ++i) o += R[e[i]];
                  return o;
                })(this, t, n);
              case "utf8":
              case "utf-8":
                return m(this, t, n);
              case "ascii":
                return (function (e, t, n) {
                  var r = "";
                  n = Math.min(e.length, n);
                  for (var o = t; o < n; ++o)
                    r += String.fromCharCode(127 & e[o]);
                  return r;
                })(this, t, n);
              case "latin1":
              case "binary":
                return (function (e, t, n) {
                  var r = "";
                  n = Math.min(e.length, n);
                  for (var o = t; o < n; ++o) r += String.fromCharCode(e[o]);
                  return r;
                })(this, t, n);
              case "base64":
                return (
                  (o = t),
                  (i = n),
                  0 === o && i === this.length
                    ? r.fromByteArray(this)
                    : r.fromByteArray(this.slice(o, i))
                );
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return (function (e, t, n) {
                  for (
                    var r = e.slice(t, n), o = "", i = 0;
                    i < r.length;
                    i += 2
                  )
                    o += String.fromCharCode(r[i] + 256 * r[i + 1]);
                  return o;
                })(this, t, n);
              default:
                if (s) throw TypeError("Unknown encoding: " + e);
                (e = (e + "").toLowerCase()), (s = !0);
            }
        }
        function y(e, t, n) {
          var r = e[t];
          (e[t] = e[n]), (e[n] = r);
        }
        function v(e, t, n, r, o) {
          var i;
          if (0 === e.length) return -1;
          if (
            ("string" == typeof n
              ? ((r = n), (n = 0))
              : n > 2147483647
              ? (n = 2147483647)
              : n < -2147483648 && (n = -2147483648),
            (i = n = +n) != i && (n = o ? 0 : e.length - 1),
            n < 0 && (n = e.length + n),
            n >= e.length)
          ) {
            if (o) return -1;
            n = e.length - 1;
          } else if (n < 0) {
            if (!o) return -1;
            n = 0;
          }
          if (("string" == typeof t && (t = a.from(t, r)), a.isBuffer(t)))
            return 0 === t.length ? -1 : g(e, t, n, r, o);
          if ("number" == typeof t)
            return ((t &= 255),
            "function" == typeof Uint8Array.prototype.indexOf)
              ? o
                ? Uint8Array.prototype.indexOf.call(e, t, n)
                : Uint8Array.prototype.lastIndexOf.call(e, t, n)
              : g(e, [t], n, r, o);
          throw TypeError("val must be string, number or Buffer");
        }
        function g(e, t, n, r, o) {
          var i,
            s = 1,
            a = e.length,
            u = t.length;
          if (
            void 0 !== r &&
            ("ucs2" === (r = String(r).toLowerCase()) ||
              "ucs-2" === r ||
              "utf16le" === r ||
              "utf-16le" === r)
          ) {
            if (e.length < 2 || t.length < 2) return -1;
            (s = 2), (a /= 2), (u /= 2), (n /= 2);
          }
          function c(e, t) {
            return 1 === s ? e[t] : e.readUInt16BE(t * s);
          }
          if (o) {
            var f = -1;
            for (i = n; i < a; i++)
              if (c(e, i) === c(t, -1 === f ? 0 : i - f)) {
                if ((-1 === f && (f = i), i - f + 1 === u)) return f * s;
              } else -1 !== f && (i -= i - f), (f = -1);
          } else
            for (n + u > a && (n = a - u), i = n; i >= 0; i--) {
              for (var l = !0, p = 0; p < u; p++)
                if (c(e, i + p) !== c(t, p)) {
                  l = !1;
                  break;
                }
              if (l) return i;
            }
          return -1;
        }
        function m(e, t, n) {
          n = Math.min(e.length, n);
          for (var r = [], o = t; o < n; ) {
            var i,
              s,
              a,
              u,
              c = e[o],
              f = null,
              l = c > 239 ? 4 : c > 223 ? 3 : c > 191 ? 2 : 1;
            if (o + l <= n)
              switch (l) {
                case 1:
                  c < 128 && (f = c);
                  break;
                case 2:
                  (192 & (i = e[o + 1])) == 128 &&
                    (u = ((31 & c) << 6) | (63 & i)) > 127 &&
                    (f = u);
                  break;
                case 3:
                  (i = e[o + 1]),
                    (s = e[o + 2]),
                    (192 & i) == 128 &&
                      (192 & s) == 128 &&
                      (u = ((15 & c) << 12) | ((63 & i) << 6) | (63 & s)) >
                        2047 &&
                      (u < 55296 || u > 57343) &&
                      (f = u);
                  break;
                case 4:
                  (i = e[o + 1]),
                    (s = e[o + 2]),
                    (a = e[o + 3]),
                    (192 & i) == 128 &&
                      (192 & s) == 128 &&
                      (192 & a) == 128 &&
                      (u =
                        ((15 & c) << 18) |
                        ((63 & i) << 12) |
                        ((63 & s) << 6) |
                        (63 & a)) > 65535 &&
                      u < 1114112 &&
                      (f = u);
              }
            null === f
              ? ((f = 65533), (l = 1))
              : f > 65535 &&
                ((f -= 65536),
                r.push(((f >>> 10) & 1023) | 55296),
                (f = 56320 | (1023 & f))),
              r.push(f),
              (o += l);
          }
          return (function (e) {
            var t = e.length;
            if (t <= 4096) return String.fromCharCode.apply(String, e);
            for (var n = "", r = 0; r < t; )
              n += String.fromCharCode.apply(String, e.slice(r, (r += 4096)));
            return n;
          })(r);
        }
        function _(e, t, n) {
          if (e % 1 != 0 || e < 0) throw RangeError("offset is not uint");
          if (e + t > n)
            throw RangeError("Trying to access beyond buffer length");
        }
        function b(e, t, n, r, o, i) {
          if (!a.isBuffer(e))
            throw TypeError('"buffer" argument must be a Buffer instance');
          if (t > o || t < i)
            throw RangeError('"value" argument is out of bounds');
          if (n + r > e.length) throw RangeError("Index out of range");
        }
        function E(e, t, n, r, o, i) {
          if (n + r > e.length || n < 0) throw RangeError("Index out of range");
        }
        function T(e, t, n, r, i) {
          return (
            (t = +t),
            (n >>>= 0),
            i || E(e, t, n, 4, 34028234663852886e22, -34028234663852886e22),
            o.write(e, t, n, r, 23, 4),
            n + 4
          );
        }
        function O(e, t, n, r, i) {
          return (
            (t = +t),
            (n >>>= 0),
            i || E(e, t, n, 8, 17976931348623157e292, -17976931348623157e292),
            o.write(e, t, n, r, 52, 8),
            n + 8
          );
        }
        (t.lW = a),
          (t.h2 = 50),
          (a.TYPED_ARRAY_SUPPORT = (function () {
            try {
              var e = new Uint8Array(1),
                t = {
                  foo: function () {
                    return 42;
                  },
                };
              return (
                Object.setPrototypeOf(t, Uint8Array.prototype),
                Object.setPrototypeOf(e, t),
                42 === e.foo()
              );
            } catch (e) {
              return !1;
            }
          })()),
          a.TYPED_ARRAY_SUPPORT ||
            "undefined" == typeof console ||
            "function" != typeof console.error ||
            console.error(
              "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
            ),
          Object.defineProperty(a.prototype, "parent", {
            enumerable: !0,
            get: function () {
              if (a.isBuffer(this)) return this.buffer;
            },
          }),
          Object.defineProperty(a.prototype, "offset", {
            enumerable: !0,
            get: function () {
              if (a.isBuffer(this)) return this.byteOffset;
            },
          }),
          (a.poolSize = 8192),
          (a.from = function (e, t, n) {
            return u(e, t, n);
          }),
          Object.setPrototypeOf(a.prototype, Uint8Array.prototype),
          Object.setPrototypeOf(a, Uint8Array),
          (a.alloc = function (e, t, n) {
            return (c(e), e <= 0)
              ? s(e)
              : void 0 !== t
              ? "string" == typeof n
                ? s(e).fill(t, n)
                : s(e).fill(t)
              : s(e);
          }),
          (a.allocUnsafe = function (e) {
            return f(e);
          }),
          (a.allocUnsafeSlow = function (e) {
            return f(e);
          }),
          (a.isBuffer = function (e) {
            return null != e && !0 === e._isBuffer && e !== a.prototype;
          }),
          (a.compare = function (e, t) {
            if (
              (C(e, Uint8Array) && (e = a.from(e, e.offset, e.byteLength)),
              C(t, Uint8Array) && (t = a.from(t, t.offset, t.byteLength)),
              !a.isBuffer(e) || !a.isBuffer(t))
            )
              throw TypeError(
                'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
              );
            if (e === t) return 0;
            for (
              var n = e.length, r = t.length, o = 0, i = Math.min(n, r);
              o < i;
              ++o
            )
              if (e[o] !== t[o]) {
                (n = e[o]), (r = t[o]);
                break;
              }
            return n < r ? -1 : r < n ? 1 : 0;
          }),
          (a.isEncoding = function (e) {
            switch (String(e).toLowerCase()) {
              case "hex":
              case "utf8":
              case "utf-8":
              case "ascii":
              case "latin1":
              case "binary":
              case "base64":
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return !0;
              default:
                return !1;
            }
          }),
          (a.concat = function (e, t) {
            if (!Array.isArray(e))
              throw TypeError('"list" argument must be an Array of Buffers');
            if (0 === e.length) return a.alloc(0);
            if (void 0 === t)
              for (n = 0, t = 0; n < e.length; ++n) t += e[n].length;
            var n,
              r = a.allocUnsafe(t),
              o = 0;
            for (n = 0; n < e.length; ++n) {
              var i = e[n];
              if ((C(i, Uint8Array) && (i = a.from(i)), !a.isBuffer(i)))
                throw TypeError('"list" argument must be an Array of Buffers');
              i.copy(r, o), (o += i.length);
            }
            return r;
          }),
          (a.byteLength = h),
          (a.prototype._isBuffer = !0),
          (a.prototype.swap16 = function () {
            var e = this.length;
            if (e % 2 != 0)
              throw RangeError("Buffer size must be a multiple of 16-bits");
            for (var t = 0; t < e; t += 2) y(this, t, t + 1);
            return this;
          }),
          (a.prototype.swap32 = function () {
            var e = this.length;
            if (e % 4 != 0)
              throw RangeError("Buffer size must be a multiple of 32-bits");
            for (var t = 0; t < e; t += 4)
              y(this, t, t + 3), y(this, t + 1, t + 2);
            return this;
          }),
          (a.prototype.swap64 = function () {
            var e = this.length;
            if (e % 8 != 0)
              throw RangeError("Buffer size must be a multiple of 64-bits");
            for (var t = 0; t < e; t += 8)
              y(this, t, t + 7),
                y(this, t + 1, t + 6),
                y(this, t + 2, t + 5),
                y(this, t + 3, t + 4);
            return this;
          }),
          (a.prototype.toString = function () {
            var e = this.length;
            return 0 === e
              ? ""
              : 0 == arguments.length
              ? m(this, 0, e)
              : d.apply(this, arguments);
          }),
          (a.prototype.toLocaleString = a.prototype.toString),
          (a.prototype.equals = function (e) {
            if (!a.isBuffer(e)) throw TypeError("Argument must be a Buffer");
            return this === e || 0 === a.compare(this, e);
          }),
          (a.prototype.inspect = function () {
            var e = "",
              n = t.h2;
            return (
              (e = this.toString("hex", 0, n)
                .replace(/(.{2})/g, "$1 ")
                .trim()),
              this.length > n && (e += " ... "),
              "<Buffer " + e + ">"
            );
          }),
          i && (a.prototype[i] = a.prototype.inspect),
          (a.prototype.compare = function (e, t, n, r, o) {
            if (
              (C(e, Uint8Array) && (e = a.from(e, e.offset, e.byteLength)),
              !a.isBuffer(e))
            )
              throw TypeError(
                'The "target" argument must be one of type Buffer or Uint8Array. Received type ' +
                  typeof e
              );
            if (
              (void 0 === t && (t = 0),
              void 0 === n && (n = e ? e.length : 0),
              void 0 === r && (r = 0),
              void 0 === o && (o = this.length),
              t < 0 || n > e.length || r < 0 || o > this.length)
            )
              throw RangeError("out of range index");
            if (r >= o && t >= n) return 0;
            if (r >= o) return -1;
            if (t >= n) return 1;
            if (((t >>>= 0), (n >>>= 0), (r >>>= 0), (o >>>= 0), this === e))
              return 0;
            for (
              var i = o - r,
                s = n - t,
                u = Math.min(i, s),
                c = this.slice(r, o),
                f = e.slice(t, n),
                l = 0;
              l < u;
              ++l
            )
              if (c[l] !== f[l]) {
                (i = c[l]), (s = f[l]);
                break;
              }
            return i < s ? -1 : s < i ? 1 : 0;
          }),
          (a.prototype.includes = function (e, t, n) {
            return -1 !== this.indexOf(e, t, n);
          }),
          (a.prototype.indexOf = function (e, t, n) {
            return v(this, e, t, n, !0);
          }),
          (a.prototype.lastIndexOf = function (e, t, n) {
            return v(this, e, t, n, !1);
          }),
          (a.prototype.write = function (e, t, n, r) {
            if (void 0 === t) (r = "utf8"), (n = this.length), (t = 0);
            else if (void 0 === n && "string" == typeof t)
              (r = t), (n = this.length), (t = 0);
            else if (isFinite(t))
              (t >>>= 0),
                isFinite(n)
                  ? ((n >>>= 0), void 0 === r && (r = "utf8"))
                  : ((r = n), (n = void 0));
            else
              throw Error(
                "Buffer.write(string, encoding, offset[, length]) is no longer supported"
              );
            var o,
              i,
              s,
              a,
              u,
              c,
              f,
              l,
              p,
              h,
              d,
              y,
              v = this.length - t;
            if (
              ((void 0 === n || n > v) && (n = v),
              (e.length > 0 && (n < 0 || t < 0)) || t > this.length)
            )
              throw RangeError("Attempt to write outside buffer bounds");
            r || (r = "utf8");
            for (var g = !1; ; )
              switch (r) {
                case "hex":
                  return (function (e, t, n, r) {
                    n = Number(n) || 0;
                    var o = e.length - n;
                    r ? (r = Number(r)) > o && (r = o) : (r = o);
                    var i = t.length;
                    r > i / 2 && (r = i / 2);
                    for (var s = 0; s < r; ++s) {
                      var a = parseInt(t.substr(2 * s, 2), 16);
                      if (a != a) break;
                      e[n + s] = a;
                    }
                    return s;
                  })(this, e, t, n);
                case "utf8":
                case "utf-8":
                  return (u = t), (c = n), N(A(e, this.length - u), this, u, c);
                case "ascii":
                  return (f = t), (l = n), N(w(e), this, f, l);
                case "latin1":
                case "binary":
                  return (
                    (o = this), (i = e), (s = t), (a = n), N(w(i), o, s, a)
                  );
                case "base64":
                  return (p = t), (h = n), N(I(e), this, p, h);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return (
                    (d = t),
                    (y = n),
                    N(
                      (function (e, t) {
                        for (
                          var n, r, o = [], i = 0;
                          i < e.length && !((t -= 2) < 0);
                          ++i
                        )
                          (r = (n = e.charCodeAt(i)) >> 8),
                            o.push(n % 256),
                            o.push(r);
                        return o;
                      })(e, this.length - d),
                      this,
                      d,
                      y
                    )
                  );
                default:
                  if (g) throw TypeError("Unknown encoding: " + r);
                  (r = ("" + r).toLowerCase()), (g = !0);
              }
          }),
          (a.prototype.toJSON = function () {
            return {
              type: "Buffer",
              data: Array.prototype.slice.call(this._arr || this, 0),
            };
          }),
          (a.prototype.slice = function (e, t) {
            var n = this.length;
            (e = ~~e),
              (t = void 0 === t ? n : ~~t),
              e < 0 ? (e += n) < 0 && (e = 0) : e > n && (e = n),
              t < 0 ? (t += n) < 0 && (t = 0) : t > n && (t = n),
              t < e && (t = e);
            var r = this.subarray(e, t);
            return Object.setPrototypeOf(r, a.prototype), r;
          }),
          (a.prototype.readUIntLE = function (e, t, n) {
            (e >>>= 0), (t >>>= 0), n || _(e, t, this.length);
            for (var r = this[e], o = 1, i = 0; ++i < t && (o *= 256); )
              r += this[e + i] * o;
            return r;
          }),
          (a.prototype.readUIntBE = function (e, t, n) {
            (e >>>= 0), (t >>>= 0), n || _(e, t, this.length);
            for (var r = this[e + --t], o = 1; t > 0 && (o *= 256); )
              r += this[e + --t] * o;
            return r;
          }),
          (a.prototype.readUInt8 = function (e, t) {
            return (e >>>= 0), t || _(e, 1, this.length), this[e];
          }),
          (a.prototype.readUInt16LE = function (e, t) {
            return (
              (e >>>= 0),
              t || _(e, 2, this.length),
              this[e] | (this[e + 1] << 8)
            );
          }),
          (a.prototype.readUInt16BE = function (e, t) {
            return (
              (e >>>= 0),
              t || _(e, 2, this.length),
              (this[e] << 8) | this[e + 1]
            );
          }),
          (a.prototype.readUInt32LE = function (e, t) {
            return (
              (e >>>= 0),
              t || _(e, 4, this.length),
              (this[e] | (this[e + 1] << 8) | (this[e + 2] << 16)) +
                16777216 * this[e + 3]
            );
          }),
          (a.prototype.readUInt32BE = function (e, t) {
            return (
              (e >>>= 0),
              t || _(e, 4, this.length),
              16777216 * this[e] +
                ((this[e + 1] << 16) | (this[e + 2] << 8) | this[e + 3])
            );
          }),
          (a.prototype.readIntLE = function (e, t, n) {
            (e >>>= 0), (t >>>= 0), n || _(e, t, this.length);
            for (var r = this[e], o = 1, i = 0; ++i < t && (o *= 256); )
              r += this[e + i] * o;
            return r >= (o *= 128) && (r -= Math.pow(2, 8 * t)), r;
          }),
          (a.prototype.readIntBE = function (e, t, n) {
            (e >>>= 0), (t >>>= 0), n || _(e, t, this.length);
            for (var r = t, o = 1, i = this[e + --r]; r > 0 && (o *= 256); )
              i += this[e + --r] * o;
            return i >= (o *= 128) && (i -= Math.pow(2, 8 * t)), i;
          }),
          (a.prototype.readInt8 = function (e, t) {
            return ((e >>>= 0), t || _(e, 1, this.length), 128 & this[e])
              ? -((255 - this[e] + 1) * 1)
              : this[e];
          }),
          (a.prototype.readInt16LE = function (e, t) {
            (e >>>= 0), t || _(e, 2, this.length);
            var n = this[e] | (this[e + 1] << 8);
            return 32768 & n ? 4294901760 | n : n;
          }),
          (a.prototype.readInt16BE = function (e, t) {
            (e >>>= 0), t || _(e, 2, this.length);
            var n = this[e + 1] | (this[e] << 8);
            return 32768 & n ? 4294901760 | n : n;
          }),
          (a.prototype.readInt32LE = function (e, t) {
            return (
              (e >>>= 0),
              t || _(e, 4, this.length),
              this[e] |
                (this[e + 1] << 8) |
                (this[e + 2] << 16) |
                (this[e + 3] << 24)
            );
          }),
          (a.prototype.readInt32BE = function (e, t) {
            return (
              (e >>>= 0),
              t || _(e, 4, this.length),
              (this[e] << 24) |
                (this[e + 1] << 16) |
                (this[e + 2] << 8) |
                this[e + 3]
            );
          }),
          (a.prototype.readFloatLE = function (e, t) {
            return (
              (e >>>= 0), t || _(e, 4, this.length), o.read(this, e, !0, 23, 4)
            );
          }),
          (a.prototype.readFloatBE = function (e, t) {
            return (
              (e >>>= 0), t || _(e, 4, this.length), o.read(this, e, !1, 23, 4)
            );
          }),
          (a.prototype.readDoubleLE = function (e, t) {
            return (
              (e >>>= 0), t || _(e, 8, this.length), o.read(this, e, !0, 52, 8)
            );
          }),
          (a.prototype.readDoubleBE = function (e, t) {
            return (
              (e >>>= 0), t || _(e, 8, this.length), o.read(this, e, !1, 52, 8)
            );
          }),
          (a.prototype.writeUIntLE = function (e, t, n, r) {
            if (((e = +e), (t >>>= 0), (n >>>= 0), !r)) {
              var o = Math.pow(2, 8 * n) - 1;
              b(this, e, t, n, o, 0);
            }
            var i = 1,
              s = 0;
            for (this[t] = 255 & e; ++s < n && (i *= 256); )
              this[t + s] = (e / i) & 255;
            return t + n;
          }),
          (a.prototype.writeUIntBE = function (e, t, n, r) {
            if (((e = +e), (t >>>= 0), (n >>>= 0), !r)) {
              var o = Math.pow(2, 8 * n) - 1;
              b(this, e, t, n, o, 0);
            }
            var i = n - 1,
              s = 1;
            for (this[t + i] = 255 & e; --i >= 0 && (s *= 256); )
              this[t + i] = (e / s) & 255;
            return t + n;
          }),
          (a.prototype.writeUInt8 = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 1, 255, 0),
              (this[t] = 255 & e),
              t + 1
            );
          }),
          (a.prototype.writeUInt16LE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 2, 65535, 0),
              (this[t] = 255 & e),
              (this[t + 1] = e >>> 8),
              t + 2
            );
          }),
          (a.prototype.writeUInt16BE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 2, 65535, 0),
              (this[t] = e >>> 8),
              (this[t + 1] = 255 & e),
              t + 2
            );
          }),
          (a.prototype.writeUInt32LE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 4, 4294967295, 0),
              (this[t + 3] = e >>> 24),
              (this[t + 2] = e >>> 16),
              (this[t + 1] = e >>> 8),
              (this[t] = 255 & e),
              t + 4
            );
          }),
          (a.prototype.writeUInt32BE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 4, 4294967295, 0),
              (this[t] = e >>> 24),
              (this[t + 1] = e >>> 16),
              (this[t + 2] = e >>> 8),
              (this[t + 3] = 255 & e),
              t + 4
            );
          }),
          (a.prototype.writeIntLE = function (e, t, n, r) {
            if (((e = +e), (t >>>= 0), !r)) {
              var o = Math.pow(2, 8 * n - 1);
              b(this, e, t, n, o - 1, -o);
            }
            var i = 0,
              s = 1,
              a = 0;
            for (this[t] = 255 & e; ++i < n && (s *= 256); )
              e < 0 && 0 === a && 0 !== this[t + i - 1] && (a = 1),
                (this[t + i] = (((e / s) >> 0) - a) & 255);
            return t + n;
          }),
          (a.prototype.writeIntBE = function (e, t, n, r) {
            if (((e = +e), (t >>>= 0), !r)) {
              var o = Math.pow(2, 8 * n - 1);
              b(this, e, t, n, o - 1, -o);
            }
            var i = n - 1,
              s = 1,
              a = 0;
            for (this[t + i] = 255 & e; --i >= 0 && (s *= 256); )
              e < 0 && 0 === a && 0 !== this[t + i + 1] && (a = 1),
                (this[t + i] = (((e / s) >> 0) - a) & 255);
            return t + n;
          }),
          (a.prototype.writeInt8 = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 1, 127, -128),
              e < 0 && (e = 255 + e + 1),
              (this[t] = 255 & e),
              t + 1
            );
          }),
          (a.prototype.writeInt16LE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 2, 32767, -32768),
              (this[t] = 255 & e),
              (this[t + 1] = e >>> 8),
              t + 2
            );
          }),
          (a.prototype.writeInt16BE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 2, 32767, -32768),
              (this[t] = e >>> 8),
              (this[t + 1] = 255 & e),
              t + 2
            );
          }),
          (a.prototype.writeInt32LE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 4, 2147483647, -2147483648),
              (this[t] = 255 & e),
              (this[t + 1] = e >>> 8),
              (this[t + 2] = e >>> 16),
              (this[t + 3] = e >>> 24),
              t + 4
            );
          }),
          (a.prototype.writeInt32BE = function (e, t, n) {
            return (
              (e = +e),
              (t >>>= 0),
              n || b(this, e, t, 4, 2147483647, -2147483648),
              e < 0 && (e = 4294967295 + e + 1),
              (this[t] = e >>> 24),
              (this[t + 1] = e >>> 16),
              (this[t + 2] = e >>> 8),
              (this[t + 3] = 255 & e),
              t + 4
            );
          }),
          (a.prototype.writeFloatLE = function (e, t, n) {
            return T(this, e, t, !0, n);
          }),
          (a.prototype.writeFloatBE = function (e, t, n) {
            return T(this, e, t, !1, n);
          }),
          (a.prototype.writeDoubleLE = function (e, t, n) {
            return O(this, e, t, !0, n);
          }),
          (a.prototype.writeDoubleBE = function (e, t, n) {
            return O(this, e, t, !1, n);
          }),
          (a.prototype.copy = function (e, t, n, r) {
            if (!a.isBuffer(e)) throw TypeError("argument should be a Buffer");
            if (
              (n || (n = 0),
              r || 0 === r || (r = this.length),
              t >= e.length && (t = e.length),
              t || (t = 0),
              r > 0 && r < n && (r = n),
              r === n || 0 === e.length || 0 === this.length)
            )
              return 0;
            if (t < 0) throw RangeError("targetStart out of bounds");
            if (n < 0 || n >= this.length)
              throw RangeError("Index out of range");
            if (r < 0) throw RangeError("sourceEnd out of bounds");
            r > this.length && (r = this.length),
              e.length - t < r - n && (r = e.length - t + n);
            var o = r - n;
            if (
              this === e &&
              "function" == typeof Uint8Array.prototype.copyWithin
            )
              this.copyWithin(t, n, r);
            else if (this === e && n < t && t < r)
              for (var i = o - 1; i >= 0; --i) e[i + t] = this[i + n];
            else Uint8Array.prototype.set.call(e, this.subarray(n, r), t);
            return o;
          }),
          (a.prototype.fill = function (e, t, n, r) {
            if ("string" == typeof e) {
              if (
                ("string" == typeof t
                  ? ((r = t), (t = 0), (n = this.length))
                  : "string" == typeof n && ((r = n), (n = this.length)),
                void 0 !== r && "string" != typeof r)
              )
                throw TypeError("encoding must be a string");
              if ("string" == typeof r && !a.isEncoding(r))
                throw TypeError("Unknown encoding: " + r);
              if (1 === e.length) {
                var o,
                  i = e.charCodeAt(0);
                (("utf8" === r && i < 128) || "latin1" === r) && (e = i);
              }
            } else
              "number" == typeof e
                ? (e &= 255)
                : "boolean" == typeof e && (e = Number(e));
            if (t < 0 || this.length < t || this.length < n)
              throw RangeError("Out of range index");
            if (n <= t) return this;
            if (
              ((t >>>= 0),
              (n = void 0 === n ? this.length : n >>> 0),
              e || (e = 0),
              "number" == typeof e)
            )
              for (o = t; o < n; ++o) this[o] = e;
            else {
              var s = a.isBuffer(e) ? e : a.from(e, r),
                u = s.length;
              if (0 === u)
                throw TypeError(
                  'The value "' + e + '" is invalid for argument "value"'
                );
              for (o = 0; o < n - t; ++o) this[o + t] = s[o % u];
            }
            return this;
          });
        var S = /[^+/0-9A-Za-z-_]/g;
        function A(e, t) {
          t = t || 1 / 0;
          for (var n, r = e.length, o = null, i = [], s = 0; s < r; ++s) {
            if ((n = e.charCodeAt(s)) > 55295 && n < 57344) {
              if (!o) {
                if (n > 56319 || s + 1 === r) {
                  (t -= 3) > -1 && i.push(239, 191, 189);
                  continue;
                }
                o = n;
                continue;
              }
              if (n < 56320) {
                (t -= 3) > -1 && i.push(239, 191, 189), (o = n);
                continue;
              }
              n = (((o - 55296) << 10) | (n - 56320)) + 65536;
            } else o && (t -= 3) > -1 && i.push(239, 191, 189);
            if (((o = null), n < 128)) {
              if ((t -= 1) < 0) break;
              i.push(n);
            } else if (n < 2048) {
              if ((t -= 2) < 0) break;
              i.push((n >> 6) | 192, (63 & n) | 128);
            } else if (n < 65536) {
              if ((t -= 3) < 0) break;
              i.push((n >> 12) | 224, ((n >> 6) & 63) | 128, (63 & n) | 128);
            } else if (n < 1114112) {
              if ((t -= 4) < 0) break;
              i.push(
                (n >> 18) | 240,
                ((n >> 12) & 63) | 128,
                ((n >> 6) & 63) | 128,
                (63 & n) | 128
              );
            } else throw Error("Invalid code point");
          }
          return i;
        }
        function w(e) {
          for (var t = [], n = 0; n < e.length; ++n)
            t.push(255 & e.charCodeAt(n));
          return t;
        }
        function I(e) {
          return r.toByteArray(
            (function (e) {
              if ((e = (e = e.split("=")[0]).trim().replace(S, "")).length < 2)
                return "";
              for (; e.length % 4 != 0; ) e += "=";
              return e;
            })(e)
          );
        }
        function N(e, t, n, r) {
          for (
            var o = 0;
            o < r && !(o + n >= t.length) && !(o >= e.length);
            ++o
          )
            t[o + n] = e[o];
          return o;
        }
        function C(e, t) {
          return (
            e instanceof t ||
            (null != e &&
              null != e.constructor &&
              null != e.constructor.name &&
              e.constructor.name === t.name)
          );
        }
        var R = (function () {
          for (var e = "0123456789abcdef", t = Array(256), n = 0; n < 16; ++n)
            for (var r = 16 * n, o = 0; o < 16; ++o) t[r + o] = e[n] + e[o];
          return t;
        })();
      },
      11227: function (e, t, n) {
        var r = n(83454);
        function o() {
          var e;
          try {
            e = t.storage.debug;
          } catch (e) {}
          return !e && void 0 !== r && "env" in r && (e = r.env.DEBUG), e;
        }
        ((t = e.exports = n(11658)).log = function () {
          return (
            "object" == typeof console &&
            console.log &&
            Function.prototype.apply.call(console.log, console, arguments)
          );
        }),
          (t.formatArgs = function (e) {
            var n = this.useColors;
            if (
              ((e[0] =
                (n ? "%c" : "") +
                this.namespace +
                (n ? " %c" : " ") +
                e[0] +
                (n ? "%c " : " ") +
                "+" +
                t.humanize(this.diff)),
              n)
            ) {
              var r = "color: " + this.color;
              e.splice(1, 0, r, "color: inherit");
              var o = 0,
                i = 0;
              e[0].replace(/%[a-zA-Z%]/g, function (e) {
                "%%" !== e && (o++, "%c" === e && (i = o));
              }),
                e.splice(i, 0, r);
            }
          }),
          (t.save = function (e) {
            try {
              null == e ? t.storage.removeItem("debug") : (t.storage.debug = e);
            } catch (e) {}
          }),
          (t.load = o),
          (t.useColors = function () {
            return (
              ("undefined" != typeof window &&
                !!window.process &&
                "renderer" === window.process.type) ||
              ("undefined" != typeof document &&
                document.documentElement &&
                document.documentElement.style &&
                document.documentElement.style.WebkitAppearance) ||
              ("undefined" != typeof window &&
                window.console &&
                (window.console.firebug ||
                  (window.console.exception && window.console.table))) ||
              ("undefined" != typeof navigator &&
                navigator.userAgent &&
                navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) &&
                parseInt(RegExp.$1, 10) >= 31) ||
              ("undefined" != typeof navigator &&
                navigator.userAgent &&
                navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/))
            );
          }),
          (t.storage =
            "undefined" != typeof chrome && void 0 !== chrome.storage
              ? chrome.storage.local
              : (function () {
                  try {
                    return window.localStorage;
                  } catch (e) {}
                })()),
          (t.colors = [
            "lightseagreen",
            "forestgreen",
            "goldenrod",
            "dodgerblue",
            "darkorchid",
            "crimson",
          ]),
          (t.formatters.j = function (e) {
            try {
              return JSON.stringify(e);
            } catch (e) {
              return "[UnexpectedJSONParseError]: " + e.message;
            }
          }),
          t.enable(o());
      },
      11658: function (e, t, n) {
        var r;
        function o(e) {
          function n() {
            if (n.enabled) {
              var e = n,
                o = +new Date(),
                i = o - (r || o);
              (e.diff = i), (e.prev = r), (e.curr = o), (r = o);
              for (var s = Array(arguments.length), a = 0; a < s.length; a++)
                s[a] = arguments[a];
              (s[0] = t.coerce(s[0])),
                "string" != typeof s[0] && s.unshift("%O");
              var u = 0;
              (s[0] = s[0].replace(/%([a-zA-Z%])/g, function (n, r) {
                if ("%%" === n) return n;
                u++;
                var o = t.formatters[r];
                if ("function" == typeof o) {
                  var i = s[u];
                  (n = o.call(e, i)), s.splice(u, 1), u--;
                }
                return n;
              })),
                t.formatArgs.call(e, s),
                (n.log || t.log || console.log.bind(console)).apply(e, s);
            }
          }
          return (
            (n.namespace = e),
            (n.enabled = t.enabled(e)),
            (n.useColors = t.useColors()),
            (n.color = (function (e) {
              var n,
                r = 0;
              for (n in e) r = ((r << 5) - r + e.charCodeAt(n)) | 0;
              return t.colors[Math.abs(r) % t.colors.length];
            })(e)),
            "function" == typeof t.init && t.init(n),
            n
          );
        }
        ((t = e.exports = o.debug = o.default = o).coerce = function (e) {
          return e instanceof Error ? e.stack || e.message : e;
        }),
          (t.disable = function () {
            t.enable("");
          }),
          (t.enable = function (e) {
            t.save(e), (t.names = []), (t.skips = []);
            for (
              var n = ("string" == typeof e ? e : "").split(/[\s,]+/),
                r = n.length,
                o = 0;
              o < r;
              o++
            )
              n[o] &&
                ("-" === (e = n[o].replace(/\*/g, ".*?"))[0]
                  ? t.skips.push(RegExp("^" + e.substr(1) + "$"))
                  : t.names.push(RegExp("^" + e + "$")));
          }),
          (t.enabled = function (e) {
            var n, r;
            for (n = 0, r = t.skips.length; n < r; n++)
              if (t.skips[n].test(e)) return !1;
            for (n = 0, r = t.names.length; n < r; n++)
              if (t.names[n].test(e)) return !0;
            return !1;
          }),
          (t.humanize = n(57363)),
          (t.names = []),
          (t.skips = []),
          (t.formatters = {});
      },
      50456: function (e, t, n) {
        "use strict";
        n.d(t, {
          ZP: function () {
            return g;
          },
          J9: function () {
            return y;
          },
          _t: function () {
            return h;
          },
          wO: function () {
            return d;
          },
          Ps: function () {
            return l;
          },
          HW: function () {
            return p;
          },
        });
        /*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ var r,
          o = function () {
            return (o =
              Object.assign ||
              function (e) {
                for (var t, n = 1, r = arguments.length; n < r; n++)
                  for (var o in (t = arguments[n]))
                    Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                return e;
              }).apply(this, arguments);
          },
          i = n(84275),
          s = new Map(),
          a = new Map(),
          u = !0,
          c = !1;
        function f(e) {
          return e.replace(/[\s,]+/g, " ").trim();
        }
        function l(e) {
          for (var t = [], n = 1; n < arguments.length; n++)
            t[n - 1] = arguments[n];
          "string" == typeof e && (e = [e]);
          var r = e[0];
          return (
            t.forEach(function (t, n) {
              t && "Document" === t.kind ? (r += t.loc.source.body) : (r += t),
                (r += e[n + 1]);
            }),
            (function (e) {
              var t = f(e);
              if (!s.has(t)) {
                var n,
                  r,
                  l,
                  p,
                  h,
                  d = (0, i.Qc)(e, {
                    experimentalFragmentVariables: c,
                    allowLegacyFragmentVariables: c,
                  });
                if (!d || "Document" !== d.kind)
                  throw Error("Not a valid GraphQL document.");
                s.set(
                  t,
                  ((n = new Set()),
                  (r = []),
                  d.definitions.forEach(function (e) {
                    if ("FragmentDefinition" === e.kind) {
                      var t,
                        o = e.name.value,
                        i = f(
                          (t = e.loc).source.body.substring(t.start, t.end)
                        ),
                        s = a.get(o);
                      s && !s.has(i)
                        ? u &&
                          console.warn(
                            "Warning: fragment with name " +
                              o +
                              " already exists.\ngraphql-tag enforces all fragment names across your application to be unique; read more about\nthis in the docs: http://dev.apollodata.com/core/fragments.html#unique-names"
                          )
                        : s || a.set(o, (s = new Set())),
                        s.add(i),
                        n.has(i) || (n.add(i), r.push(e));
                    } else r.push(e);
                  }),
                  (l = o(o({}, d), { definitions: r })),
                  (p = new Set(l.definitions)).forEach(function (e) {
                    e.loc && delete e.loc,
                      Object.keys(e).forEach(function (t) {
                        var n = e[t];
                        n && "object" == typeof n && p.add(n);
                      });
                  }),
                  (h = l.loc) && (delete h.startToken, delete h.endToken),
                  l)
                );
              }
              return s.get(t);
            })(r)
          );
        }
        function p() {
          s.clear(), a.clear();
        }
        function h() {
          u = !1;
        }
        function d() {
          c = !0;
        }
        function y() {
          c = !1;
        }
        var v = {
          gql: l,
          resetCaches: p,
          disableFragmentWarnings: h,
          enableExperimentalFragmentVariables: d,
          disableExperimentalFragmentVariables: y,
        };
        ((r = l || (l = {})).gql = v.gql),
          (r.resetCaches = v.resetCaches),
          (r.disableFragmentWarnings = v.disableFragmentWarnings),
          (r.enableExperimentalFragmentVariables =
            v.enableExperimentalFragmentVariables),
          (r.disableExperimentalFragmentVariables =
            v.disableExperimentalFragmentVariables),
          (l.default = l);
        var g = l;
      },
      80645: function (e, t) {
        (t.read = function (e, t, n, r, o) {
          var i,
            s,
            a = 8 * o - r - 1,
            u = (1 << a) - 1,
            c = u >> 1,
            f = -7,
            l = n ? o - 1 : 0,
            p = n ? -1 : 1,
            h = e[t + l];
          for (
            l += p, i = h & ((1 << -f) - 1), h >>= -f, f += a;
            f > 0;
            i = 256 * i + e[t + l], l += p, f -= 8
          );
          for (
            s = i & ((1 << -f) - 1), i >>= -f, f += r;
            f > 0;
            s = 256 * s + e[t + l], l += p, f -= 8
          );
          if (0 === i) i = 1 - c;
          else {
            if (i === u) return s ? NaN : (h ? -1 : 1) * (1 / 0);
            (s += Math.pow(2, r)), (i -= c);
          }
          return (h ? -1 : 1) * s * Math.pow(2, i - r);
        }),
          (t.write = function (e, t, n, r, o, i) {
            var s,
              a,
              u,
              c = 8 * i - o - 1,
              f = (1 << c) - 1,
              l = f >> 1,
              p = 23 === o ? 5960464477539062e-23 : 0,
              h = r ? 0 : i - 1,
              d = r ? 1 : -1,
              y = t < 0 || (0 === t && 1 / t < 0) ? 1 : 0;
            for (
              isNaN((t = Math.abs(t))) || t === 1 / 0
                ? ((a = isNaN(t) ? 1 : 0), (s = f))
                : ((s = Math.floor(Math.log(t) / Math.LN2)),
                  t * (u = Math.pow(2, -s)) < 1 && (s--, (u *= 2)),
                  s + l >= 1 ? (t += p / u) : (t += p * Math.pow(2, 1 - l)),
                  t * u >= 2 && (s++, (u /= 2)),
                  s + l >= f
                    ? ((a = 0), (s = f))
                    : s + l >= 1
                    ? ((a = (t * u - 1) * Math.pow(2, o)), (s += l))
                    : ((a = t * Math.pow(2, l - 1) * Math.pow(2, o)), (s = 0)));
              o >= 8;
              e[n + h] = 255 & a, h += d, a /= 256, o -= 8
            );
            for (
              s = (s << o) | a, c += o;
              c > 0;
              e[n + h] = 255 & s, h += d, s /= 256, c -= 8
            );
            e[n + h - d] |= 128 * y;
          });
      },
      57363: function (e) {
        function t(e, t, n) {
          return e < t
            ? void 0
            : e < 1.5 * t
            ? Math.floor(e / t) + " " + n
            : Math.ceil(e / t) + " " + n + "s";
        }
        e.exports = function (e, n) {
          n = n || {};
          var r = typeof e;
          if ("string" === r && e.length > 0)
            return (function (e) {
              if (!((e = String(e)).length > 100)) {
                var t =
                  /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(
                    e
                  );
                if (t) {
                  var n = parseFloat(t[1]);
                  switch ((t[2] || "ms").toLowerCase()) {
                    case "years":
                    case "year":
                    case "yrs":
                    case "yr":
                    case "y":
                      return 315576e5 * n;
                    case "days":
                    case "day":
                    case "d":
                      return 864e5 * n;
                    case "hours":
                    case "hour":
                    case "hrs":
                    case "hr":
                    case "h":
                      return 36e5 * n;
                    case "minutes":
                    case "minute":
                    case "mins":
                    case "min":
                    case "m":
                      return 6e4 * n;
                    case "seconds":
                    case "second":
                    case "secs":
                    case "sec":
                    case "s":
                      return 1e3 * n;
                    case "milliseconds":
                    case "millisecond":
                    case "msecs":
                    case "msec":
                    case "ms":
                      return n;
                    default:
                      return;
                  }
                }
              }
            })(e);
          if ("number" === r && !1 === isNaN(e))
            return n.long
              ? t(e, 864e5, "day") ||
                  t(e, 36e5, "hour") ||
                  t(e, 6e4, "minute") ||
                  t(e, 1e3, "second") ||
                  e + " ms"
              : e >= 864e5
              ? Math.round(e / 864e5) + "d"
              : e >= 36e5
              ? Math.round(e / 36e5) + "h"
              : e >= 6e4
              ? Math.round(e / 6e4) + "m"
              : e >= 1e3
              ? Math.round(e / 1e3) + "s"
              : e + "ms";
          throw Error(
            "val is not a non-empty string or a valid number. val=" +
              JSON.stringify(e)
          );
        };
      },
      11987: function (e, t, n) {
        !(function () {
          var t = {
              452: function (e) {
                "use strict";
                e.exports = n(97334);
              },
            },
            r = {};
          function o(e) {
            var n = r[e];
            if (void 0 !== n) return n.exports;
            var i = (r[e] = { exports: {} }),
              s = !0;
            try {
              t[e](i, i.exports, o), (s = !1);
            } finally {
              s && delete r[e];
            }
            return i.exports;
          }
          o.ab = "//";
          var i = {};
          (function () {
            var e,
              t = i,
              n =
                (e = o(452)) && "object" == typeof e && "default" in e
                  ? e.default
                  : e,
              r = /https?|ftp|gopher|file/;
            function s(e) {
              "string" == typeof e && (e = m(e));
              var t,
                o,
                i,
                s,
                a,
                u,
                c,
                f,
                l,
                p =
                  ((o = (t = e).auth),
                  (i = t.hostname),
                  (s = t.protocol || ""),
                  (a = t.pathname || ""),
                  (u = t.hash || ""),
                  (c = t.query || ""),
                  (f = !1),
                  (o = o
                    ? encodeURIComponent(o).replace(/%3A/i, ":") + "@"
                    : ""),
                  t.host
                    ? (f = o + t.host)
                    : i &&
                      ((f = o + (~i.indexOf(":") ? "[" + i + "]" : i)),
                      t.port && (f += ":" + t.port)),
                  c && "object" == typeof c && (c = n.encode(c)),
                  (l = t.search || (c && "?" + c) || ""),
                  s && ":" !== s.substr(-1) && (s += ":"),
                  t.slashes || ((!s || r.test(s)) && !1 !== f)
                    ? ((f = "//" + (f || "")),
                      a && "/" !== a[0] && (a = "/" + a))
                    : f || (f = ""),
                  u && "#" !== u[0] && (u = "#" + u),
                  l && "?" !== l[0] && (l = "?" + l),
                  {
                    protocol: s,
                    host: f,
                    pathname: (a = a.replace(/[?#]/g, encodeURIComponent)),
                    search: (l = l.replace("#", "%23")),
                    hash: u,
                  });
              return "" + p.protocol + p.host + p.pathname + p.search + p.hash;
            }
            var a = "http://",
              u = a + "w.w",
              c = /^([a-z0-9.+-]*:\/\/\/)([a-z0-9.+-]:\/*)?/i,
              f = /https?|ftp|gopher|file/;
            function l(e, t) {
              var n = "string" == typeof e ? m(e) : e;
              e = "object" == typeof e ? s(e) : e;
              var r = m(t),
                o = "";
              n.protocol &&
                !n.slashes &&
                ((o = n.protocol),
                (e = e.replace(n.protocol, "")),
                (o += "/" === t[0] || "/" === e[0] ? "/" : "")),
                o &&
                  r.protocol &&
                  ((o = ""),
                  r.slashes ||
                    ((o = r.protocol), (t = t.replace(r.protocol, ""))));
              var i = e.match(c);
              i &&
                !r.protocol &&
                ((e = e.substr((o = i[1] + (i[2] || "")).length)),
                /^\/\/[^/]/.test(t) && (o = o.slice(0, -1)));
              var l = new URL(e, u + "/"),
                p = new URL(t, l).toString().replace(u, ""),
                h = r.protocol || n.protocol;
              return (
                (h += n.slashes || r.slashes ? "//" : ""),
                !o && h ? (p = p.replace(a, h)) : o && (p = p.replace(a, "")),
                f.test(p) ||
                  ~t.indexOf(".") ||
                  "/" === e.slice(-1) ||
                  "/" === t.slice(-1) ||
                  "/" !== p.slice(-1) ||
                  (p = p.slice(0, -1)),
                o && (p = o + ("/" === p[0] ? p.substr(1) : p)),
                p
              );
            }
            function p() {}
            (p.prototype.parse = m),
              (p.prototype.format = s),
              (p.prototype.resolve = l),
              (p.prototype.resolveObject = l);
            var h = /^https?|ftp|gopher|file/,
              d = /^(.*?)([#?].*)/,
              y = /^([a-z0-9.+-]*:)(\/{0,3})(.*)/i,
              v = /^([a-z0-9.+-]*:)?\/\/\/*/i,
              g = /^([a-z0-9.+-]*:)(\/{0,2})\[(.*)\]$/i;
            function m(e, t, r) {
              if (
                (void 0 === t && (t = !1),
                void 0 === r && (r = !1),
                e && "object" == typeof e && e instanceof p)
              )
                return e;
              var o = (e = e.trim()).match(d);
              (e = o ? o[1].replace(/\\/g, "/") + o[2] : e.replace(/\\/g, "/")),
                g.test(e) && "/" !== e.slice(-1) && (e += "/");
              var i = !/(^javascript)/.test(e) && e.match(y),
                a = v.test(e),
                c = "";
              i &&
                (h.test(i[1]) ||
                  ((c = i[1].toLowerCase()), (e = "" + i[2] + i[3])),
                i[2] ||
                  ((a = !1),
                  h.test(i[1])
                    ? ((c = i[1]), (e = "" + i[3]))
                    : (e = "//" + i[3])),
                (3 !== i[2].length && 1 !== i[2].length) ||
                  ((c = i[1]), (e = "/" + i[3])));
              var f,
                l = (o ? o[1] : e).match(/^https?:\/\/[^/]+(:[0-9]+)(?=\/|$)/),
                m = l && l[1],
                _ = new p(),
                b = "",
                E = "";
              try {
                f = new URL(e);
              } catch (t) {
                (b = t),
                  c ||
                    r ||
                    !/^\/\//.test(e) ||
                    /^\/\/.+[@.]/.test(e) ||
                    ((E = "/"), (e = e.substr(1)));
                try {
                  f = new URL(e, u);
                } catch (e) {
                  return (_.protocol = c), (_.href = c), _;
                }
              }
              (_.slashes = a && !E),
                (_.host = "w.w" === f.host ? "" : f.host),
                (_.hostname =
                  "w.w" === f.hostname
                    ? ""
                    : f.hostname.replace(/(\[|\])/g, "")),
                (_.protocol = b ? c || null : f.protocol),
                (_.search = f.search.replace(/\\/g, "%5C")),
                (_.hash = f.hash.replace(/\\/g, "%5C"));
              var T = e.split("#");
              !_.search && ~T[0].indexOf("?") && (_.search = "?"),
                _.hash || "" !== T[1] || (_.hash = "#"),
                (_.query = t
                  ? n.decode(f.search.substr(1))
                  : _.search.substr(1)),
                (_.pathname =
                  E +
                  (i
                    ? f.pathname
                        .replace(/['^|`]/g, function (e) {
                          return (
                            "%" + e.charCodeAt().toString(16).toUpperCase()
                          );
                        })
                        .replace(/((?:%[0-9A-F]{2})+)/g, function (e, t) {
                          try {
                            return decodeURIComponent(t)
                              .split("")
                              .map(function (e) {
                                var t = e.charCodeAt();
                                return t > 256 || /^[a-z0-9]$/i.test(e)
                                  ? e
                                  : "%" + t.toString(16).toUpperCase();
                              })
                              .join("");
                          } catch (e) {
                            return t;
                          }
                        })
                    : f.pathname)),
                "about:" === _.protocol &&
                  "blank" === _.pathname &&
                  ((_.protocol = ""), (_.pathname = "")),
                b && "/" !== e[0] && (_.pathname = _.pathname.substr(1)),
                c &&
                  !h.test(c) &&
                  "/" !== e.slice(-1) &&
                  "/" === _.pathname &&
                  (_.pathname = ""),
                (_.path = _.pathname + _.search),
                (_.auth = [f.username, f.password]
                  .map(decodeURIComponent)
                  .filter(Boolean)
                  .join(":")),
                (_.port = f.port),
                m &&
                  !_.host.endsWith(m) &&
                  ((_.host += m), (_.port = m.slice(1))),
                (_.href = E ? "" + _.pathname + _.search + _.hash : s(_));
              var O = /^(file)/.test(_.href) ? ["host", "hostname"] : [];
              return (
                Object.keys(_).forEach(function (e) {
                  ~O.indexOf(e) || (_[e] = _[e] || null);
                }),
                _
              );
            }
            (t.parse = m),
              (t.format = s),
              (t.resolve = l),
              (t.resolveObject = function (e, t) {
                return m(l(e, t));
              }),
              (t.Url = p);
          })(),
            (e.exports = i);
        })();
      },
      97334: function (e) {
        !(function () {
          "use strict";
          var t,
            n = {
              815: function (e) {
                e.exports = function (e, n, r, o) {
                  (n = n || "&"), (r = r || "=");
                  var i = {};
                  if ("string" != typeof e || 0 === e.length) return i;
                  var s = /\+/g;
                  e = e.split(n);
                  var a = 1e3;
                  o && "number" == typeof o.maxKeys && (a = o.maxKeys);
                  var u = e.length;
                  a > 0 && u > a && (u = a);
                  for (var c = 0; c < u; ++c) {
                    var f,
                      l,
                      p,
                      h,
                      d = e[c].replace(s, "%20"),
                      y = d.indexOf(r);
                    (y >= 0
                      ? ((f = d.substr(0, y)), (l = d.substr(y + 1)))
                      : ((f = d), (l = "")),
                    (p = decodeURIComponent(f)),
                    (h = decodeURIComponent(l)),
                    Object.prototype.hasOwnProperty.call(i, p))
                      ? t(i[p])
                        ? i[p].push(h)
                        : (i[p] = [i[p], h])
                      : (i[p] = h);
                  }
                  return i;
                };
                var t =
                  Array.isArray ||
                  function (e) {
                    return (
                      "[object Array]" === Object.prototype.toString.call(e)
                    );
                  };
              },
              577: function (e) {
                var t = function (e) {
                  switch (typeof e) {
                    case "string":
                      return e;
                    case "boolean":
                      return e ? "true" : "false";
                    case "number":
                      return isFinite(e) ? e : "";
                    default:
                      return "";
                  }
                };
                e.exports = function (e, i, s, a) {
                  return ((i = i || "&"),
                  (s = s || "="),
                  null === e && (e = void 0),
                  "object" == typeof e)
                    ? r(o(e), function (o) {
                        var a = encodeURIComponent(t(o)) + s;
                        return n(e[o])
                          ? r(e[o], function (e) {
                              return a + encodeURIComponent(t(e));
                            }).join(i)
                          : a + encodeURIComponent(t(e[o]));
                      }).join(i)
                    : a
                    ? encodeURIComponent(t(a)) + s + encodeURIComponent(t(e))
                    : "";
                };
                var n =
                  Array.isArray ||
                  function (e) {
                    return (
                      "[object Array]" === Object.prototype.toString.call(e)
                    );
                  };
                function r(e, t) {
                  if (e.map) return e.map(t);
                  for (var n = [], r = 0; r < e.length; r++) n.push(t(e[r], r));
                  return n;
                }
                var o =
                  Object.keys ||
                  function (e) {
                    var t = [];
                    for (var n in e)
                      Object.prototype.hasOwnProperty.call(e, n) && t.push(n);
                    return t;
                  };
              },
            },
            r = {};
          function o(e) {
            var t = r[e];
            if (void 0 !== t) return t.exports;
            var i = (r[e] = { exports: {} }),
              s = !0;
            try {
              n[e](i, i.exports, o), (s = !1);
            } finally {
              s && delete r[e];
            }
            return i.exports;
          }
          o.ab = "//";
          var i = {};
          ((t = i).decode = t.parse = o(815)),
            (t.encode = t.stringify = o(577)),
            (e.exports = i);
        })();
      },
      70655: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            __assign: function () {
              return i;
            },
            __asyncDelegator: function () {
              return b;
            },
            __asyncGenerator: function () {
              return _;
            },
            __asyncValues: function () {
              return E;
            },
            __await: function () {
              return m;
            },
            __awaiter: function () {
              return f;
            },
            __classPrivateFieldGet: function () {
              return A;
            },
            __classPrivateFieldSet: function () {
              return w;
            },
            __createBinding: function () {
              return p;
            },
            __decorate: function () {
              return a;
            },
            __exportStar: function () {
              return h;
            },
            __extends: function () {
              return o;
            },
            __generator: function () {
              return l;
            },
            __importDefault: function () {
              return S;
            },
            __importStar: function () {
              return O;
            },
            __makeTemplateObject: function () {
              return T;
            },
            __metadata: function () {
              return c;
            },
            __param: function () {
              return u;
            },
            __read: function () {
              return y;
            },
            __rest: function () {
              return s;
            },
            __spread: function () {
              return v;
            },
            __spreadArrays: function () {
              return g;
            },
            __values: function () {
              return d;
            },
          });
        /*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ var r =
          function (e, t) {
            return (r =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
              })(e, t);
          };
        function o(e, t) {
          function n() {
            this.constructor = e;
          }
          r(e, t),
            (e.prototype =
              null === t
                ? Object.create(t)
                : ((n.prototype = t.prototype), new n()));
        }
        var i = function () {
          return (i =
            Object.assign ||
            function (e) {
              for (var t, n = 1, r = arguments.length; n < r; n++)
                for (var o in (t = arguments[n]))
                  Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
              return e;
            }).apply(this, arguments);
        };
        function s(e, t) {
          var n = {};
          for (var r in e)
            Object.prototype.hasOwnProperty.call(e, r) &&
              0 > t.indexOf(r) &&
              (n[r] = e[r]);
          if (null != e && "function" == typeof Object.getOwnPropertySymbols)
            for (
              var o = 0, r = Object.getOwnPropertySymbols(e);
              o < r.length;
              o++
            )
              0 > t.indexOf(r[o]) &&
                Object.prototype.propertyIsEnumerable.call(e, r[o]) &&
                (n[r[o]] = e[r[o]]);
          return n;
        }
        function a(e, t, n, r) {
          var o,
            i = arguments.length,
            s =
              i < 3
                ? t
                : null === r
                ? (r = Object.getOwnPropertyDescriptor(t, n))
                : r;
          if (
            "object" == typeof Reflect &&
            "function" == typeof Reflect.decorate
          )
            s = Reflect.decorate(e, t, n, r);
          else
            for (var a = e.length - 1; a >= 0; a--)
              (o = e[a]) &&
                (s = (i < 3 ? o(s) : i > 3 ? o(t, n, s) : o(t, n)) || s);
          return i > 3 && s && Object.defineProperty(t, n, s), s;
        }
        function u(e, t) {
          return function (n, r) {
            t(n, r, e);
          };
        }
        function c(e, t) {
          if (
            "object" == typeof Reflect &&
            "function" == typeof Reflect.metadata
          )
            return Reflect.metadata(e, t);
        }
        function f(e, t, n, r) {
          return new (n || (n = Promise))(function (o, i) {
            function s(e) {
              try {
                u(r.next(e));
              } catch (e) {
                i(e);
              }
            }
            function a(e) {
              try {
                u(r.throw(e));
              } catch (e) {
                i(e);
              }
            }
            function u(e) {
              var t;
              e.done
                ? o(e.value)
                : ((t = e.value) instanceof n
                    ? t
                    : new n(function (e) {
                        e(t);
                      })
                  ).then(s, a);
            }
            u((r = r.apply(e, t || [])).next());
          });
        }
        function l(e, t) {
          var n,
            r,
            o,
            i,
            s = {
              label: 0,
              sent: function () {
                if (1 & o[0]) throw o[1];
                return o[1];
              },
              trys: [],
              ops: [],
            };
          return (
            (i = { next: a(0), throw: a(1), return: a(2) }),
            "function" == typeof Symbol &&
              (i[Symbol.iterator] = function () {
                return this;
              }),
            i
          );
          function a(i) {
            return function (a) {
              return (function (i) {
                if (n) throw TypeError("Generator is already executing.");
                for (; s; )
                  try {
                    if (
                      ((n = 1),
                      r &&
                        (o =
                          2 & i[0]
                            ? r.return
                            : i[0]
                            ? r.throw || ((o = r.return) && o.call(r), 0)
                            : r.next) &&
                        !(o = o.call(r, i[1])).done)
                    )
                      return o;
                    switch (((r = 0), o && (i = [2 & i[0], o.value]), i[0])) {
                      case 0:
                      case 1:
                        o = i;
                        break;
                      case 4:
                        return s.label++, { value: i[1], done: !1 };
                      case 5:
                        s.label++, (r = i[1]), (i = [0]);
                        continue;
                      case 7:
                        (i = s.ops.pop()), s.trys.pop();
                        continue;
                      default:
                        if (
                          !(o = (o = s.trys).length > 0 && o[o.length - 1]) &&
                          (6 === i[0] || 2 === i[0])
                        ) {
                          s = 0;
                          continue;
                        }
                        if (
                          3 === i[0] &&
                          (!o || (i[1] > o[0] && i[1] < o[3]))
                        ) {
                          s.label = i[1];
                          break;
                        }
                        if (6 === i[0] && s.label < o[1]) {
                          (s.label = o[1]), (o = i);
                          break;
                        }
                        if (o && s.label < o[2]) {
                          (s.label = o[2]), s.ops.push(i);
                          break;
                        }
                        o[2] && s.ops.pop(), s.trys.pop();
                        continue;
                    }
                    i = t.call(e, s);
                  } catch (e) {
                    (i = [6, e]), (r = 0);
                  } finally {
                    n = o = 0;
                  }
                if (5 & i[0]) throw i[1];
                return { value: i[0] ? i[1] : void 0, done: !0 };
              })([i, a]);
            };
          }
        }
        function p(e, t, n, r) {
          void 0 === r && (r = n), (e[r] = t[n]);
        }
        function h(e, t) {
          for (var n in e)
            "default" === n || t.hasOwnProperty(n) || (t[n] = e[n]);
        }
        function d(e) {
          var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
          if (n) return n.call(e);
          if (e && "number" == typeof e.length)
            return {
              next: function () {
                return (
                  e && r >= e.length && (e = void 0),
                  { value: e && e[r++], done: !e }
                );
              },
            };
          throw TypeError(
            t ? "Object is not iterable." : "Symbol.iterator is not defined."
          );
        }
        function y(e, t) {
          var n = "function" == typeof Symbol && e[Symbol.iterator];
          if (!n) return e;
          var r,
            o,
            i = n.call(e),
            s = [];
          try {
            for (; (void 0 === t || t-- > 0) && !(r = i.next()).done; )
              s.push(r.value);
          } catch (e) {
            o = { error: e };
          } finally {
            try {
              r && !r.done && (n = i.return) && n.call(i);
            } finally {
              if (o) throw o.error;
            }
          }
          return s;
        }
        function v() {
          for (var e = [], t = 0; t < arguments.length; t++)
            e = e.concat(y(arguments[t]));
          return e;
        }
        function g() {
          for (var e = 0, t = 0, n = arguments.length; t < n; t++)
            e += arguments[t].length;
          for (var r = Array(e), o = 0, t = 0; t < n; t++)
            for (var i = arguments[t], s = 0, a = i.length; s < a; s++, o++)
              r[o] = i[s];
          return r;
        }
        function m(e) {
          return this instanceof m ? ((this.v = e), this) : new m(e);
        }
        function _(e, t, n) {
          if (!Symbol.asyncIterator)
            throw TypeError("Symbol.asyncIterator is not defined.");
          var r,
            o = n.apply(e, t || []),
            i = [];
          return (
            (r = {}),
            s("next"),
            s("throw"),
            s("return"),
            (r[Symbol.asyncIterator] = function () {
              return this;
            }),
            r
          );
          function s(e) {
            o[e] &&
              (r[e] = function (t) {
                return new Promise(function (n, r) {
                  i.push([e, t, n, r]) > 1 || a(e, t);
                });
              });
          }
          function a(e, t) {
            try {
              var n;
              (n = o[e](t)).value instanceof m
                ? Promise.resolve(n.value.v).then(u, c)
                : f(i[0][2], n);
            } catch (e) {
              f(i[0][3], e);
            }
          }
          function u(e) {
            a("next", e);
          }
          function c(e) {
            a("throw", e);
          }
          function f(e, t) {
            e(t), i.shift(), i.length && a(i[0][0], i[0][1]);
          }
        }
        function b(e) {
          var t, n;
          return (
            (t = {}),
            r("next"),
            r("throw", function (e) {
              throw e;
            }),
            r("return"),
            (t[Symbol.iterator] = function () {
              return this;
            }),
            t
          );
          function r(r, o) {
            t[r] = e[r]
              ? function (t) {
                  return (n = !n)
                    ? { value: m(e[r](t)), done: "return" === r }
                    : o
                    ? o(t)
                    : t;
                }
              : o;
          }
        }
        function E(e) {
          if (!Symbol.asyncIterator)
            throw TypeError("Symbol.asyncIterator is not defined.");
          var t,
            n = e[Symbol.asyncIterator];
          return n
            ? n.call(e)
            : ((e = d(e)),
              (t = {}),
              r("next"),
              r("throw"),
              r("return"),
              (t[Symbol.asyncIterator] = function () {
                return this;
              }),
              t);
          function r(n) {
            t[n] =
              e[n] &&
              function (t) {
                return new Promise(function (r, o) {
                  (function (e, t, n, r) {
                    Promise.resolve(r).then(function (t) {
                      e({ value: t, done: n });
                    }, t);
                  })(r, o, (t = e[n](t)).done, t.value);
                });
              };
          }
        }
        function T(e, t) {
          return (
            Object.defineProperty
              ? Object.defineProperty(e, "raw", { value: t })
              : (e.raw = t),
            e
          );
        }
        function O(e) {
          if (e && e.__esModule) return e;
          var t = {};
          if (null != e)
            for (var n in e) Object.hasOwnProperty.call(e, n) && (t[n] = e[n]);
          return (t.default = e), t;
        }
        function S(e) {
          return e && e.__esModule ? e : { default: e };
        }
        function A(e, t) {
          if (!t.has(e))
            throw TypeError("attempted to get private field on non-instance");
          return t.get(e);
        }
        function w(e, t, n) {
          if (!t.has(e))
            throw TypeError("attempted to set private field on non-instance");
          return t.set(e, n), n;
        }
      },
      67429: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          Object.defineProperty(t, "NIL", {
            enumerable: !0,
            get: function () {
              return a.default;
            },
          }),
          Object.defineProperty(t, "parse", {
            enumerable: !0,
            get: function () {
              return l.default;
            },
          }),
          Object.defineProperty(t, "stringify", {
            enumerable: !0,
            get: function () {
              return f.default;
            },
          }),
          Object.defineProperty(t, "v1", {
            enumerable: !0,
            get: function () {
              return r.default;
            },
          }),
          Object.defineProperty(t, "v3", {
            enumerable: !0,
            get: function () {
              return o.default;
            },
          }),
          Object.defineProperty(t, "v4", {
            enumerable: !0,
            get: function () {
              return i.default;
            },
          }),
          Object.defineProperty(t, "v5", {
            enumerable: !0,
            get: function () {
              return s.default;
            },
          }),
          Object.defineProperty(t, "validate", {
            enumerable: !0,
            get: function () {
              return c.default;
            },
          }),
          Object.defineProperty(t, "version", {
            enumerable: !0,
            get: function () {
              return u.default;
            },
          });
        var r = p(n(63990)),
          o = p(n(8237)),
          i = p(n(75355)),
          s = p(n(83764)),
          a = p(n(86314)),
          u = p(n(58464)),
          c = p(n(46435)),
          f = p(n(73990)),
          l = p(n(18222));
        function p(e) {
          return e && e.__esModule ? e : { default: e };
        }
      },
      94163: function (e, t) {
        "use strict";
        function n(e) {
          return (((e + 64) >>> 9) << 4) + 14 + 1;
        }
        function r(e, t) {
          let n = (65535 & e) + (65535 & t);
          return (((e >> 16) + (t >> 16) + (n >> 16)) << 16) | (65535 & n);
        }
        function o(e, t, n, o, i, s) {
          var a;
          return r(((a = r(r(t, e), r(o, s))) << i) | (a >>> (32 - i)), n);
        }
        function i(e, t, n, r, i, s, a) {
          return o((t & n) | (~t & r), e, t, i, s, a);
        }
        function s(e, t, n, r, i, s, a) {
          return o((t & r) | (n & ~r), e, t, i, s, a);
        }
        function a(e, t, n, r, i, s, a) {
          return o(t ^ n ^ r, e, t, i, s, a);
        }
        function u(e, t, n, r, i, s, a) {
          return o(n ^ (t | ~r), e, t, i, s, a);
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0),
          (t.default = function (e) {
            if ("string" == typeof e) {
              let t = unescape(encodeURIComponent(e));
              e = new Uint8Array(t.length);
              for (let n = 0; n < t.length; ++n) e[n] = t.charCodeAt(n);
            }
            return (function (e) {
              let t = [],
                n = 32 * e.length,
                r = "0123456789abcdef";
              for (let o = 0; o < n; o += 8) {
                let n = (e[o >> 5] >>> o % 32) & 255,
                  i = parseInt(r.charAt((n >>> 4) & 15) + r.charAt(15 & n), 16);
                t.push(i);
              }
              return t;
            })(
              (function (e, t) {
                (e[t >> 5] |= 128 << t % 32), (e[n(t) - 1] = t);
                let o = 1732584193,
                  c = -271733879,
                  f = -1732584194,
                  l = 271733878;
                for (let t = 0; t < e.length; t += 16) {
                  let n = o,
                    p = c,
                    h = f,
                    d = l;
                  (o = i(o, c, f, l, e[t], 7, -680876936)),
                    (l = i(l, o, c, f, e[t + 1], 12, -389564586)),
                    (f = i(f, l, o, c, e[t + 2], 17, 606105819)),
                    (c = i(c, f, l, o, e[t + 3], 22, -1044525330)),
                    (o = i(o, c, f, l, e[t + 4], 7, -176418897)),
                    (l = i(l, o, c, f, e[t + 5], 12, 1200080426)),
                    (f = i(f, l, o, c, e[t + 6], 17, -1473231341)),
                    (c = i(c, f, l, o, e[t + 7], 22, -45705983)),
                    (o = i(o, c, f, l, e[t + 8], 7, 1770035416)),
                    (l = i(l, o, c, f, e[t + 9], 12, -1958414417)),
                    (f = i(f, l, o, c, e[t + 10], 17, -42063)),
                    (c = i(c, f, l, o, e[t + 11], 22, -1990404162)),
                    (o = i(o, c, f, l, e[t + 12], 7, 1804603682)),
                    (l = i(l, o, c, f, e[t + 13], 12, -40341101)),
                    (f = i(f, l, o, c, e[t + 14], 17, -1502002290)),
                    (c = i(c, f, l, o, e[t + 15], 22, 1236535329)),
                    (o = s(o, c, f, l, e[t + 1], 5, -165796510)),
                    (l = s(l, o, c, f, e[t + 6], 9, -1069501632)),
                    (f = s(f, l, o, c, e[t + 11], 14, 643717713)),
                    (c = s(c, f, l, o, e[t], 20, -373897302)),
                    (o = s(o, c, f, l, e[t + 5], 5, -701558691)),
                    (l = s(l, o, c, f, e[t + 10], 9, 38016083)),
                    (f = s(f, l, o, c, e[t + 15], 14, -660478335)),
                    (c = s(c, f, l, o, e[t + 4], 20, -405537848)),
                    (o = s(o, c, f, l, e[t + 9], 5, 568446438)),
                    (l = s(l, o, c, f, e[t + 14], 9, -1019803690)),
                    (f = s(f, l, o, c, e[t + 3], 14, -187363961)),
                    (c = s(c, f, l, o, e[t + 8], 20, 1163531501)),
                    (o = s(o, c, f, l, e[t + 13], 5, -1444681467)),
                    (l = s(l, o, c, f, e[t + 2], 9, -51403784)),
                    (f = s(f, l, o, c, e[t + 7], 14, 1735328473)),
                    (c = s(c, f, l, o, e[t + 12], 20, -1926607734)),
                    (o = a(o, c, f, l, e[t + 5], 4, -378558)),
                    (l = a(l, o, c, f, e[t + 8], 11, -2022574463)),
                    (f = a(f, l, o, c, e[t + 11], 16, 1839030562)),
                    (c = a(c, f, l, o, e[t + 14], 23, -35309556)),
                    (o = a(o, c, f, l, e[t + 1], 4, -1530992060)),
                    (l = a(l, o, c, f, e[t + 4], 11, 1272893353)),
                    (f = a(f, l, o, c, e[t + 7], 16, -155497632)),
                    (c = a(c, f, l, o, e[t + 10], 23, -1094730640)),
                    (o = a(o, c, f, l, e[t + 13], 4, 681279174)),
                    (l = a(l, o, c, f, e[t], 11, -358537222)),
                    (f = a(f, l, o, c, e[t + 3], 16, -722521979)),
                    (c = a(c, f, l, o, e[t + 6], 23, 76029189)),
                    (o = a(o, c, f, l, e[t + 9], 4, -640364487)),
                    (l = a(l, o, c, f, e[t + 12], 11, -421815835)),
                    (f = a(f, l, o, c, e[t + 15], 16, 530742520)),
                    (c = a(c, f, l, o, e[t + 2], 23, -995338651)),
                    (o = u(o, c, f, l, e[t], 6, -198630844)),
                    (l = u(l, o, c, f, e[t + 7], 10, 1126891415)),
                    (f = u(f, l, o, c, e[t + 14], 15, -1416354905)),
                    (c = u(c, f, l, o, e[t + 5], 21, -57434055)),
                    (o = u(o, c, f, l, e[t + 12], 6, 1700485571)),
                    (l = u(l, o, c, f, e[t + 3], 10, -1894986606)),
                    (f = u(f, l, o, c, e[t + 10], 15, -1051523)),
                    (c = u(c, f, l, o, e[t + 1], 21, -2054922799)),
                    (o = u(o, c, f, l, e[t + 8], 6, 1873313359)),
                    (l = u(l, o, c, f, e[t + 15], 10, -30611744)),
                    (f = u(f, l, o, c, e[t + 6], 15, -1560198380)),
                    (c = u(c, f, l, o, e[t + 13], 21, 1309151649)),
                    (o = u(o, c, f, l, e[t + 4], 6, -145523070)),
                    (l = u(l, o, c, f, e[t + 11], 10, -1120210379)),
                    (f = u(f, l, o, c, e[t + 2], 15, 718787259)),
                    (c = u(c, f, l, o, e[t + 9], 21, -343485551)),
                    (o = r(o, n)),
                    (c = r(c, p)),
                    (f = r(f, h)),
                    (l = r(l, d));
                }
                return [o, c, f, l];
              })(
                (function (e) {
                  if (0 === e.length) return [];
                  let t = 8 * e.length,
                    r = new Uint32Array(n(t));
                  for (let n = 0; n < t; n += 8)
                    r[n >> 5] |= (255 & e[n / 8]) << n % 32;
                  return r;
                })(e),
                8 * e.length
              )
            );
          });
      },
      54790: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        let n =
          "undefined" != typeof crypto &&
          crypto.randomUUID &&
          crypto.randomUUID.bind(crypto);
        t.default = { randomUUID: n };
      },
      86314: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0),
          (t.default = "00000000-0000-0000-0000-000000000000");
      },
      18222: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var r,
          o = (r = n(46435)) && r.__esModule ? r : { default: r };
        t.default = function (e) {
          let t;
          if (!(0, o.default)(e)) throw TypeError("Invalid UUID");
          let n = new Uint8Array(16);
          return (
            (n[0] = (t = parseInt(e.slice(0, 8), 16)) >>> 24),
            (n[1] = (t >>> 16) & 255),
            (n[2] = (t >>> 8) & 255),
            (n[3] = 255 & t),
            (n[4] = (t = parseInt(e.slice(9, 13), 16)) >>> 8),
            (n[5] = 255 & t),
            (n[6] = (t = parseInt(e.slice(14, 18), 16)) >>> 8),
            (n[7] = 255 & t),
            (n[8] = (t = parseInt(e.slice(19, 23), 16)) >>> 8),
            (n[9] = 255 & t),
            (n[10] =
              ((t = parseInt(e.slice(24, 36), 16)) / 1099511627776) & 255),
            (n[11] = (t / 4294967296) & 255),
            (n[12] = (t >>> 24) & 255),
            (n[13] = (t >>> 16) & 255),
            (n[14] = (t >>> 8) & 255),
            (n[15] = 255 & t),
            n
          );
        };
      },
      70058: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0),
          (t.default =
            /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);
      },
      33319: function (e, t) {
        "use strict";
        let n;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function () {
            if (
              !n &&
              !(n =
                "undefined" != typeof crypto &&
                crypto.getRandomValues &&
                crypto.getRandomValues.bind(crypto))
            )
              throw Error(
                "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported"
              );
            return n(r);
          });
        let r = new Uint8Array(16);
      },
      93757: function (e, t) {
        "use strict";
        function n(e, t) {
          return (e << t) | (e >>> (32 - t));
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0),
          (t.default = function (e) {
            let t = [1518500249, 1859775393, 2400959708, 3395469782],
              r = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
            if ("string" == typeof e) {
              let t = unescape(encodeURIComponent(e));
              e = [];
              for (let n = 0; n < t.length; ++n) e.push(t.charCodeAt(n));
            } else Array.isArray(e) || (e = Array.prototype.slice.call(e));
            e.push(128);
            let o = e.length / 4 + 2,
              i = Math.ceil(o / 16),
              s = Array(i);
            for (let t = 0; t < i; ++t) {
              let n = new Uint32Array(16);
              for (let r = 0; r < 16; ++r)
                n[r] =
                  (e[64 * t + 4 * r] << 24) |
                  (e[64 * t + 4 * r + 1] << 16) |
                  (e[64 * t + 4 * r + 2] << 8) |
                  e[64 * t + 4 * r + 3];
              s[t] = n;
            }
            (s[i - 1][14] = ((e.length - 1) * 8) / 4294967296),
              (s[i - 1][14] = Math.floor(s[i - 1][14])),
              (s[i - 1][15] = ((e.length - 1) * 8) & 4294967295);
            for (let e = 0; e < i; ++e) {
              let o = new Uint32Array(80);
              for (let t = 0; t < 16; ++t) o[t] = s[e][t];
              for (let e = 16; e < 80; ++e)
                o[e] = n(o[e - 3] ^ o[e - 8] ^ o[e - 14] ^ o[e - 16], 1);
              let i = r[0],
                a = r[1],
                u = r[2],
                c = r[3],
                f = r[4];
              for (let e = 0; e < 80; ++e) {
                let r = Math.floor(e / 20),
                  s =
                    (n(i, 5) +
                      (function (e, t, n, r) {
                        switch (e) {
                          case 0:
                            return (t & n) ^ (~t & r);
                          case 1:
                          case 3:
                            return t ^ n ^ r;
                          case 2:
                            return (t & n) ^ (t & r) ^ (n & r);
                        }
                      })(r, a, u, c) +
                      f +
                      t[r] +
                      o[e]) >>>
                    0;
                (f = c), (c = u), (u = n(a, 30) >>> 0), (a = i), (i = s);
              }
              (r[0] = (r[0] + i) >>> 0),
                (r[1] = (r[1] + a) >>> 0),
                (r[2] = (r[2] + u) >>> 0),
                (r[3] = (r[3] + c) >>> 0),
                (r[4] = (r[4] + f) >>> 0);
            }
            return [
              (r[0] >> 24) & 255,
              (r[0] >> 16) & 255,
              (r[0] >> 8) & 255,
              255 & r[0],
              (r[1] >> 24) & 255,
              (r[1] >> 16) & 255,
              (r[1] >> 8) & 255,
              255 & r[1],
              (r[2] >> 24) & 255,
              (r[2] >> 16) & 255,
              (r[2] >> 8) & 255,
              255 & r[2],
              (r[3] >> 24) & 255,
              (r[3] >> 16) & 255,
              (r[3] >> 8) & 255,
              255 & r[3],
              (r[4] >> 24) & 255,
              (r[4] >> 16) & 255,
              (r[4] >> 8) & 255,
              255 & r[4],
            ];
          });
      },
      73990: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0),
          (t.unsafeStringify = s);
        var r,
          o = (r = n(46435)) && r.__esModule ? r : { default: r };
        let i = [];
        for (let e = 0; e < 256; ++e) i.push((e + 256).toString(16).slice(1));
        function s(e, t = 0) {
          return (
            i[e[t + 0]] +
            i[e[t + 1]] +
            i[e[t + 2]] +
            i[e[t + 3]] +
            "-" +
            i[e[t + 4]] +
            i[e[t + 5]] +
            "-" +
            i[e[t + 6]] +
            i[e[t + 7]] +
            "-" +
            i[e[t + 8]] +
            i[e[t + 9]] +
            "-" +
            i[e[t + 10]] +
            i[e[t + 11]] +
            i[e[t + 12]] +
            i[e[t + 13]] +
            i[e[t + 14]] +
            i[e[t + 15]]
          ).toLowerCase();
        }
        t.default = function (e, t = 0) {
          let n = s(e, t);
          if (!(0, o.default)(n))
            throw TypeError("Stringified UUID is invalid");
          return n;
        };
      },
      63990: function (e, t, n) {
        "use strict";
        let r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var i,
          s = (i = n(33319)) && i.__esModule ? i : { default: i },
          a = n(73990);
        let u = 0,
          c = 0;
        t.default = function (e, t, n) {
          let i = (t && n) || 0,
            f = t || Array(16),
            l = (e = e || {}).node || r,
            p = void 0 !== e.clockseq ? e.clockseq : o;
          if (null == l || null == p) {
            let t = e.random || (e.rng || s.default)();
            null == l && (l = r = [1 | t[0], t[1], t[2], t[3], t[4], t[5]]),
              null == p && (p = o = ((t[6] << 8) | t[7]) & 16383);
          }
          let h = void 0 !== e.msecs ? e.msecs : Date.now(),
            d = void 0 !== e.nsecs ? e.nsecs : c + 1,
            y = h - u + (d - c) / 1e4;
          if (
            (y < 0 && void 0 === e.clockseq && (p = (p + 1) & 16383),
            (y < 0 || h > u) && void 0 === e.nsecs && (d = 0),
            d >= 1e4)
          )
            throw Error("uuid.v1(): Can't create more than 10M uuids/sec");
          (u = h), (c = d), (o = p), (h += 122192928e5);
          let v = ((268435455 & h) * 1e4 + d) % 4294967296;
          (f[i++] = (v >>> 24) & 255),
            (f[i++] = (v >>> 16) & 255),
            (f[i++] = (v >>> 8) & 255),
            (f[i++] = 255 & v);
          let g = ((h / 4294967296) * 1e4) & 268435455;
          (f[i++] = (g >>> 8) & 255),
            (f[i++] = 255 & g),
            (f[i++] = ((g >>> 24) & 15) | 16),
            (f[i++] = (g >>> 16) & 255),
            (f[i++] = (p >>> 8) | 128),
            (f[i++] = 255 & p);
          for (let e = 0; e < 6; ++e) f[i + e] = l[e];
          return t || (0, a.unsafeStringify)(f);
        };
      },
      8237: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var r = i(n(17925)),
          o = i(n(94163));
        function i(e) {
          return e && e.__esModule ? e : { default: e };
        }
        let s = (0, r.default)("v3", 48, o.default);
        t.default = s;
      },
      17925: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.URL = t.DNS = void 0),
          (t.default = function (e, t, n) {
            function r(e, r, s, a) {
              var u;
              if (
                ("string" == typeof e &&
                  (e = (function (e) {
                    e = unescape(encodeURIComponent(e));
                    let t = [];
                    for (let n = 0; n < e.length; ++n) t.push(e.charCodeAt(n));
                    return t;
                  })(e)),
                "string" == typeof r && (r = (0, i.default)(r)),
                (null === (u = r) || void 0 === u ? void 0 : u.length) !== 16)
              )
                throw TypeError(
                  "Namespace must be array-like (16 iterable integer values, 0-255)"
                );
              let c = new Uint8Array(16 + e.length);
              if (
                (c.set(r),
                c.set(e, r.length),
                ((c = n(c))[6] = (15 & c[6]) | t),
                (c[8] = (63 & c[8]) | 128),
                s)
              ) {
                a = a || 0;
                for (let e = 0; e < 16; ++e) s[a + e] = c[e];
                return s;
              }
              return (0, o.unsafeStringify)(c);
            }
            try {
              r.name = e;
            } catch (e) {}
            return (r.DNS = s), (r.URL = a), r;
          });
        var r,
          o = n(73990),
          i = (r = n(18222)) && r.__esModule ? r : { default: r };
        let s = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
        t.DNS = s;
        let a = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
        t.URL = a;
      },
      75355: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var r = s(n(54790)),
          o = s(n(33319)),
          i = n(73990);
        function s(e) {
          return e && e.__esModule ? e : { default: e };
        }
        t.default = function (e, t, n) {
          if (r.default.randomUUID && !t && !e) return r.default.randomUUID();
          e = e || {};
          let s = e.random || (e.rng || o.default)();
          if (((s[6] = (15 & s[6]) | 64), (s[8] = (63 & s[8]) | 128), t)) {
            n = n || 0;
            for (let e = 0; e < 16; ++e) t[n + e] = s[e];
            return t;
          }
          return (0, i.unsafeStringify)(s);
        };
      },
      83764: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var r = i(n(17925)),
          o = i(n(93757));
        function i(e) {
          return e && e.__esModule ? e : { default: e };
        }
        let s = (0, r.default)("v5", 80, o.default);
        t.default = s;
      },
      46435: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var r,
          o = (r = n(70058)) && r.__esModule ? r : { default: r };
        t.default = function (e) {
          return "string" == typeof e && o.default.test(e);
        };
      },
      58464: function (e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var r,
          o = (r = n(46435)) && r.__esModule ? r : { default: r };
        t.default = function (e) {
          if (!(0, o.default)(e)) throw TypeError("Invalid UUID");
          return parseInt(e.slice(14, 15), 16);
        };
      },
      34153: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            ApolloCache: function () {
              return c.R;
            },
            ApolloClient: function () {
              return o.f;
            },
            ApolloError: function () {
              return u.cA;
            },
            ApolloLink: function () {
              return y.i;
            },
            Cache: function () {
              return r;
            },
            DocumentTransform: function () {
              return w.A;
            },
            HttpLink: function () {
              return E.HttpLink;
            },
            InMemoryCache: function () {
              return f.h;
            },
            MissingFieldError: function () {
              return l.y;
            },
            NetworkStatus: function () {
              return a.Ie;
            },
            Observable: function () {
              return I.y;
            },
            ObservableQuery: function () {
              return s.ue;
            },
            checkFetcher: function () {
              return E.checkFetcher;
            },
            concat: function () {
              return _;
            },
            createHttpLink: function () {
              return E.createHttpLink;
            },
            createSignalIfSupported: function () {
              return E.createSignalIfSupported;
            },
            defaultDataIdFromObject: function () {
              return p.uG;
            },
            defaultPrinter: function () {
              return E.defaultPrinter;
            },
            disableExperimentalFragmentVariables: function () {
              return R.J9;
            },
            disableFragmentWarnings: function () {
              return R._t;
            },
            empty: function () {
              return v;
            },
            enableExperimentalFragmentVariables: function () {
              return R.wO;
            },
            execute: function () {
              return b.h;
            },
            fallbackHttpConfig: function () {
              return E.fallbackHttpConfig;
            },
            from: function () {
              return g;
            },
            fromError: function () {
              return O.Q;
            },
            fromPromise: function () {
              return S.p;
            },
            gql: function () {
              return R.Ps;
            },
            isApolloError: function () {
              return u.MS;
            },
            isNetworkRequestSettled: function () {
              return a.Jp;
            },
            isReference: function () {
              return N.Yk;
            },
            makeReference: function () {
              return N.kQ;
            },
            makeVar: function () {
              return h.QS;
            },
            mergeOptions: function () {
              return i.J;
            },
            parseAndCheckHttpResponse: function () {
              return E.parseAndCheckHttpResponse;
            },
            resetCaches: function () {
              return R.HW;
            },
            rewriteURIForGET: function () {
              return E.rewriteURIForGET;
            },
            selectHttpOptionsAndBody: function () {
              return E.selectHttpOptionsAndBody;
            },
            selectHttpOptionsAndBodyInternal: function () {
              return E.selectHttpOptionsAndBodyInternal;
            },
            selectURI: function () {
              return E.selectURI;
            },
            serializeFetchParameter: function () {
              return E.serializeFetchParameter;
            },
            setLogVerbosity: function () {
              return C.U6;
            },
            split: function () {
              return m.V;
            },
            throwServerError: function () {
              return A.P;
            },
            toPromise: function () {
              return T;
            },
          });
        var r,
          o = n(38854),
          i = n(14012),
          s = n(44780),
          a = n(1644),
          u = n(30990);
        r || (r = {});
        var c = n(11294),
          f = n(13440),
          l = n(75727),
          p = n(49641),
          h = n(66438),
          d = n(16459),
          y = n(86909),
          v = y.i.empty,
          g = y.i.from,
          m = n(35367),
          _ = y.i.concat,
          b = n(47037),
          E = n(38802);
        function T(e) {
          var t = !1;
          return new Promise(function (n, r) {
            e.subscribe({
              next: function (e) {
                t
                  ? !1 !== globalThis.__DEV__ && d.kG.warn(43)
                  : ((t = !0), n(e));
              },
              error: r,
            });
          });
        }
        var O = n(16261),
          S = n(2824),
          A = n(12782),
          w = n(18056),
          I = n(48216),
          N = n(51761),
          C = n(40303),
          R = n(50456);
        (0, C.U6)(!1 !== globalThis.__DEV__ ? "log" : "silent");
      },
      38802: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            HttpLink: function () {
              return f.u;
            },
            checkFetcher: function () {
              return s.U;
            },
            createHttpLink: function () {
              return c.L;
            },
            createSignalIfSupported: function () {
              return a;
            },
            defaultPrinter: function () {
              return i.sb;
            },
            fallbackHttpConfig: function () {
              return i.SC;
            },
            parseAndCheckHttpResponse: function () {
              return r.dO;
            },
            rewriteURIForGET: function () {
              return l.H;
            },
            selectHttpOptionsAndBody: function () {
              return i.E4;
            },
            selectHttpOptionsAndBodyInternal: function () {
              return i.ve;
            },
            selectURI: function () {
              return u.r;
            },
            serializeFetchParameter: function () {
              return o.g;
            },
          }),
          n(16459);
        var r = n(81999),
          o = n(15049),
          i = n(3453),
          s = n(23178),
          a = function () {
            if ("undefined" == typeof AbortController)
              return { controller: !1, signal: !1 };
            var e = new AbortController(),
              t = e.signal;
            return { controller: e, signal: t };
          },
          u = n(11037),
          c = n(34747),
          f = n(72198),
          l = n(88663);
      },
      10269: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            AutoCleanedStrongCache: function () {
              return Q.L;
            },
            AutoCleanedWeakCache: function () {
              return Q.s;
            },
            Concast: function () {
              return M.X;
            },
            DEV: function () {
              return r.Rk;
            },
            DeepMerger: function () {
              return v.w0;
            },
            DocumentTransform: function () {
              return i.A;
            },
            Observable: function () {
              return T.y;
            },
            addTypenameToDocument: function () {
              return f.Gw;
            },
            argumentsObjectFromField: function () {
              return c.NC;
            },
            asyncMap: function () {
              return R.s;
            },
            buildQueryFromSelectionSet: function () {
              return f.aL;
            },
            cacheSizes: function () {
              return $.Q;
            },
            canUseAsyncIteratorSymbol: function () {
              return P.DN;
            },
            canUseDOM: function () {
              return P.Nq;
            },
            canUseLayoutEffect: function () {
              return P.JC;
            },
            canUseSymbol: function () {
              return P.aS;
            },
            canUseWeakMap: function () {
              return P.mr;
            },
            canUseWeakSet: function () {
              return P.sy;
            },
            canonicalStringify: function () {
              return F.B;
            },
            checkDocument: function () {
              return a.A$;
            },
            cloneDeep: function () {
              return I.X;
            },
            compact: function () {
              return x.o;
            },
            concatPagination: function () {
              return g;
            },
            createFragmentMap: function () {
              return s.F;
            },
            createFulfilledPromise: function () {
              return O;
            },
            createRejectedPromise: function () {
              return S;
            },
            fixObservableSubclass: function () {
              return D.D;
            },
            getDefaultValues: function () {
              return a.O4;
            },
            getDirectiveNames: function () {
              return o.iX;
            },
            getFragmentDefinition: function () {
              return a.pD;
            },
            getFragmentDefinitions: function () {
              return a.kU;
            },
            getFragmentFromSelection: function () {
              return s.hi;
            },
            getFragmentQueryDocument: function () {
              return s.Yk;
            },
            getGraphQLErrorsFromResult: function () {
              return L.K;
            },
            getInclusionDirectives: function () {
              return o.IX;
            },
            getMainDefinition: function () {
              return a.p$;
            },
            getOperationDefinition: function () {
              return a.$H;
            },
            getOperationName: function () {
              return a.rY;
            },
            getQueryDefinition: function () {
              return a.iW;
            },
            getStoreKeyName: function () {
              return c.PT;
            },
            getTypenameFromResult: function () {
              return c.qw;
            },
            graphQLResultHasError: function () {
              return L.d;
            },
            hasAllDirectives: function () {
              return o.qb;
            },
            hasAnyDirectives: function () {
              return o.On;
            },
            hasClientExports: function () {
              return o.mj;
            },
            hasDirectives: function () {
              return o.FS;
            },
            isApolloPayloadResult: function () {
              return G.yU;
            },
            isArray: function () {
              return k.k;
            },
            isDocumentNode: function () {
              return c.JW;
            },
            isExecutionPatchIncrementalResult: function () {
              return G.GG;
            },
            isExecutionPatchInitialResult: function () {
              return G.x3;
            },
            isExecutionPatchResult: function () {
              return G.M0;
            },
            isField: function () {
              return c.My;
            },
            isInlineFragment: function () {
              return c.Ao;
            },
            isMutationOperation: function () {
              return p;
            },
            isNonEmptyArray: function () {
              return k.O;
            },
            isNonNullObject: function () {
              return U.s;
            },
            isPlainObject: function () {
              return U.P;
            },
            isQueryOperation: function () {
              return h;
            },
            isReference: function () {
              return c.Yk;
            },
            isStatefulPromise: function () {
              return A;
            },
            isSubscriptionOperation: function () {
              return d;
            },
            iterateObserversSafely: function () {
              return C.p;
            },
            makeReference: function () {
              return c.kQ;
            },
            makeUniqueId: function () {
              return B.X;
            },
            maybe: function () {
              return r.wY;
            },
            maybeDeepFreeze: function () {
              return N.J;
            },
            mergeDeep: function () {
              return v.Ee;
            },
            mergeDeepArray: function () {
              return v.bw;
            },
            mergeIncrementalData: function () {
              return G.mT;
            },
            mergeOptions: function () {
              return V.J;
            },
            offsetLimitPagination: function () {
              return m;
            },
            omitDeep: function () {
              return q;
            },
            print: function () {
              return u.S;
            },
            relayStylePagination: function () {
              return _;
            },
            removeArgumentsFromDocument: function () {
              return f.Vw;
            },
            removeClientSetsFromDocument: function () {
              return f.ob;
            },
            removeConnectionDirectiveFromDocument: function () {
              return f.Fo;
            },
            removeDirectivesFromDocument: function () {
              return f.bi;
            },
            removeFragmentSpreadFromDocument: function () {
              return f.RR;
            },
            resultKeyNameFromField: function () {
              return c.u2;
            },
            shouldInclude: function () {
              return o.LZ;
            },
            storeKeyNameFromField: function () {
              return c.vf;
            },
            stringifyForDisplay: function () {
              return j.v;
            },
            stripTypename: function () {
              return H;
            },
            valueToObjectRepresentation: function () {
              return c.vb;
            },
            wrapPromiseWithState: function () {
              return w;
            },
          });
        var r = n(16459),
          o = n(19065),
          i = n(18056),
          s = n(23361),
          a = n(36765),
          u = n(68470),
          c = n(51761),
          f = n(76487);
        function l(e, t) {
          var n;
          return (
            (null === (n = (0, a.$H)(e)) || void 0 === n
              ? void 0
              : n.operation) === t
          );
        }
        function p(e) {
          return l(e, "mutation");
        }
        function h(e) {
          return l(e, "query");
        }
        function d(e) {
          return l(e, "subscription");
        }
        var y = n(23564),
          v = n(182);
        function g(e) {
          return (
            void 0 === e && (e = !1),
            {
              keyArgs: e,
              merge: function (e, t) {
                return e ? (0, y.ev)((0, y.ev)([], e, !0), t, !0) : t;
              },
            }
          );
        }
        function m(e) {
          return (
            void 0 === e && (e = !1),
            {
              keyArgs: e,
              merge: function (e, t, n) {
                var r = n.args,
                  o = e ? e.slice(0) : [];
                if (t) {
                  if (r)
                    for (
                      var i = r.offset, s = void 0 === i ? 0 : i, a = 0;
                      a < t.length;
                      ++a
                    )
                      o[s + a] = t[a];
                  else o.push.apply(o, t);
                }
                return o;
              },
            }
          );
        }
        function _(e) {
          return (
            void 0 === e && (e = !1),
            {
              keyArgs: e,
              read: function (e, t) {
                var n = t.canRead,
                  r = t.readField;
                if (!e) return e;
                var o = [],
                  i = "",
                  s = "";
                e.edges.forEach(function (e) {
                  n(r("node", e)) &&
                    (o.push(e),
                    e.cursor &&
                      ((i = i || e.cursor || ""), (s = e.cursor || s)));
                }),
                  o.length > 1 && i === s && (i = "");
                var a = e.pageInfo || {},
                  u = a.startCursor,
                  c = a.endCursor;
                return (0, y.pi)((0, y.pi)({}, b(e)), {
                  edges: o,
                  pageInfo: (0, y.pi)((0, y.pi)({}, e.pageInfo), {
                    startCursor: u || i,
                    endCursor: c || s,
                  }),
                });
              },
              merge: function (e, t, n) {
                var r = n.args,
                  o = n.isReference,
                  i = n.readField;
                if (
                  (e ||
                    (e = {
                      edges: [],
                      pageInfo: {
                        hasPreviousPage: !1,
                        hasNextPage: !0,
                        startCursor: "",
                        endCursor: "",
                      },
                    }),
                  !t)
                )
                  return e;
                var s = t.edges
                  ? t.edges.map(function (e) {
                      return (
                        o((e = (0, y.pi)({}, e))) &&
                          (e.cursor = i("cursor", e)),
                        e
                      );
                    })
                  : [];
                if (t.pageInfo) {
                  var a = t.pageInfo,
                    u = a.startCursor,
                    c = a.endCursor,
                    f = s[0],
                    l = s[s.length - 1];
                  f && u && (f.cursor = u), l && c && (l.cursor = c);
                  var p = f && f.cursor;
                  p &&
                    !u &&
                    (t = (0, v.Ee)(t, { pageInfo: { startCursor: p } }));
                  var h = l && l.cursor;
                  h && !c && (t = (0, v.Ee)(t, { pageInfo: { endCursor: h } }));
                }
                var d = e.edges,
                  g = [];
                if (r && r.after) {
                  var m = d.findIndex(function (e) {
                    return e.cursor === r.after;
                  });
                  m >= 0 && (d = d.slice(0, m + 1));
                } else if (r && r.before) {
                  var m = d.findIndex(function (e) {
                    return e.cursor === r.before;
                  });
                  (g = m < 0 ? d : d.slice(m)), (d = []);
                } else t.edges && (d = []);
                var _ = (0, y.ev)(
                    (0, y.ev)((0, y.ev)([], d, !0), s, !0),
                    g,
                    !0
                  ),
                  E = (0, y.pi)((0, y.pi)({}, t.pageInfo), e.pageInfo);
                if (t.pageInfo) {
                  var T = t.pageInfo,
                    O = T.hasPreviousPage,
                    S = T.hasNextPage,
                    u = T.startCursor,
                    c = T.endCursor;
                  Object.assign(
                    E,
                    (0, y._T)(T, [
                      "hasPreviousPage",
                      "hasNextPage",
                      "startCursor",
                      "endCursor",
                    ])
                  ),
                    d.length ||
                      (void 0 !== O && (E.hasPreviousPage = O),
                      void 0 === u || (E.startCursor = u)),
                    g.length ||
                      (void 0 !== S && (E.hasNextPage = S),
                      void 0 === c || (E.endCursor = c));
                }
                return (0, y.pi)((0, y.pi)((0, y.pi)({}, b(e)), b(t)), {
                  edges: _,
                  pageInfo: E,
                });
              },
            }
          );
        }
        var b = function (e) {
            return (0, y._T)(e, E);
          },
          E = ["edges", "pageInfo"],
          T = n(48216);
        function O(e) {
          var t = Promise.resolve(e);
          return (t.status = "fulfilled"), (t.value = e), t;
        }
        function S(e) {
          var t = Promise.reject(e);
          return (
            t.catch(function () {}), (t.status = "rejected"), (t.reason = e), t
          );
        }
        function A(e) {
          return "status" in e;
        }
        function w(e) {
          if (A(e)) return e;
          var t = e;
          return (
            (t.status = "pending"),
            t.then(
              function (e) {
                if ("pending" === t.status) {
                  var n = t;
                  (n.status = "fulfilled"), (n.value = e);
                }
              },
              function (e) {
                if ("pending" === t.status) {
                  var n = t;
                  (n.status = "rejected"), (n.reason = e);
                }
              }
            ),
            e
          );
        }
        var I = n(79487),
          N = n(48702),
          C = n(18263),
          R = n(46951),
          M = n(55687),
          D = n(86403),
          k = n(21436),
          U = n(13154),
          L = n(69383),
          P = n(30320),
          x = n(53712),
          B = n(60897),
          j = n(13887),
          V = n(14012),
          G = n(37280),
          F = n(5466);
        function q(e, t) {
          return K(e, t);
        }
        function K(e, t, n) {
          if ((void 0 === n && (n = new Map()), n.has(e))) return n.get(e);
          var r = !1;
          if (Array.isArray(e)) {
            var o = [];
            if (
              (n.set(e, o),
              e.forEach(function (e, i) {
                var s = K(e, t, n);
                r || (r = s !== e), (o[i] = s);
              }),
              r)
            )
              return o;
          } else if ((0, U.P)(e)) {
            var i = Object.create(Object.getPrototypeOf(e));
            if (
              (n.set(e, i),
              Object.keys(e).forEach(function (o) {
                if (o === t) {
                  r = !0;
                  return;
                }
                var s = K(e[o], t, n);
                r || (r = s !== e[o]), (i[o] = s);
              }),
              r)
            )
              return i;
          }
          return e;
        }
        function H(e) {
          return K(e, "__typename");
        }
        var Q = n(38991),
          $ = n(66331);
      },
      85955: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            BREAK: function () {
              return M.$_;
            },
            BreakingChangeType: function () {
              return a;
            },
            DEFAULT_DEPRECATION_REASON: function () {
              return b.SY;
            },
            DangerousChangeType: function () {
              return u;
            },
            DirectiveLocation: function () {
              return k.B;
            },
            ExecutableDefinitionsRule: function () {
              return F.i;
            },
            FieldsOnCorrectTypeRule: function () {
              return q.A;
            },
            FragmentsOnCompositeTypesRule: function () {
              return K.T;
            },
            GRAPHQL_MAX_INT: function () {
              return E.HI;
            },
            GRAPHQL_MIN_INT: function () {
              return E.st;
            },
            GraphQLBoolean: function () {
              return E.EZ;
            },
            GraphQLDeprecatedDirective: function () {
              return b.fg;
            },
            GraphQLDirective: function () {
              return b.NZ;
            },
            GraphQLEnumType: function () {
              return m.mR;
            },
            GraphQLError: function () {
              return B.__;
            },
            GraphQLFloat: function () {
              return E.av;
            },
            GraphQLID: function () {
              return E.km;
            },
            GraphQLIncludeDirective: function () {
              return b.Yf;
            },
            GraphQLInputObjectType: function () {
              return m.sR;
            },
            GraphQLInt: function () {
              return E._o;
            },
            GraphQLInterfaceType: function () {
              return m.oW;
            },
            GraphQLList: function () {
              return m.p2;
            },
            GraphQLNonNull: function () {
              return m.bM;
            },
            GraphQLObjectType: function () {
              return m.h6;
            },
            GraphQLScalarType: function () {
              return m.n2;
            },
            GraphQLSchema: function () {
              return _.XO;
            },
            GraphQLSkipDirective: function () {
              return b.QE;
            },
            GraphQLSpecifiedByDirective: function () {
              return b.df;
            },
            GraphQLString: function () {
              return E.kH;
            },
            GraphQLUnionType: function () {
              return m.Gp;
            },
            Kind: function () {
              return D.h;
            },
            KnownArgumentNamesRule: function () {
              return H.e;
            },
            KnownDirectivesRule: function () {
              return Q.J;
            },
            KnownFragmentNamesRule: function () {
              return $.a;
            },
            KnownTypeNamesRule: function () {
              return Y.I;
            },
            Lexer: function () {
              return N.h;
            },
            Location: function () {
              return S.Ye;
            },
            LoneAnonymousOperationRule: function () {
              return z.F;
            },
            LoneSchemaDefinitionRule: function () {
              return ed.t;
            },
            NoDeprecatedCustomRule: function () {
              return eT.r;
            },
            NoFragmentCyclesRule: function () {
              return W.H;
            },
            NoSchemaIntrospectionCustomRule: function () {
              return j;
            },
            NoUndefinedVariablesRule: function () {
              return J.$;
            },
            NoUnusedFragmentsRule: function () {
              return Z.J;
            },
            NoUnusedVariablesRule: function () {
              return X.p;
            },
            OperationTypeNode: function () {
              return S.ku;
            },
            OverlappingFieldsCanBeMergedRule: function () {
              return ee.y;
            },
            PossibleFragmentSpreadsRule: function () {
              return et.a;
            },
            PossibleTypeExtensionsRule: function () {
              return eE.g;
            },
            ProvidedRequiredArgumentsRule: function () {
              return en.s;
            },
            ScalarLeafsRule: function () {
              return er.O;
            },
            SchemaMetaFieldDef: function () {
              return T.Az;
            },
            SingleFieldSubscriptionsRule: function () {
              return eo.Z;
            },
            Source: function () {
              return A.H;
            },
            Token: function () {
              return S.WU;
            },
            TokenKind: function () {
              return C.T;
            },
            TypeInfo: function () {
              return tv.a;
            },
            TypeKind: function () {
              return T.zU;
            },
            TypeMetaFieldDef: function () {
              return T.tF;
            },
            TypeNameMetaFieldDef: function () {
              return T.hU;
            },
            UniqueArgumentDefinitionNamesRule: function () {
              return e_.L;
            },
            UniqueArgumentNamesRule: function () {
              return ei.L;
            },
            UniqueDirectiveNamesRule: function () {
              return eb.o;
            },
            UniqueDirectivesPerLocationRule: function () {
              return es.k;
            },
            UniqueEnumValueNamesRule: function () {
              return eg.L;
            },
            UniqueFieldDefinitionNamesRule: function () {
              return em.y;
            },
            UniqueFragmentNamesRule: function () {
              return ea.N;
            },
            UniqueInputFieldNamesRule: function () {
              return eu.P;
            },
            UniqueOperationNamesRule: function () {
              return ec.H;
            },
            UniqueOperationTypesRule: function () {
              return ey.q;
            },
            UniqueTypeNamesRule: function () {
              return ev.P;
            },
            UniqueVariableNamesRule: function () {
              return ef.H;
            },
            ValidationContext: function () {
              return V._t;
            },
            ValuesOfCorrectTypeRule: function () {
              return el.j;
            },
            VariablesAreInputTypesRule: function () {
              return ep.I;
            },
            VariablesInAllowedPositionRule: function () {
              return eh.w;
            },
            __Directive: function () {
              return T.l3;
            },
            __DirectiveLocation: function () {
              return T.x2;
            },
            __EnumValue: function () {
              return T.jT;
            },
            __Field: function () {
              return T.e_;
            },
            __InputValue: function () {
              return T.XQ;
            },
            __Schema: function () {
              return T.TK;
            },
            __Type: function () {
              return T.qz;
            },
            __TypeKind: function () {
              return T.PX;
            },
            assertAbstractType: function () {
              return m.fU;
            },
            assertCompositeType: function () {
              return m.M_;
            },
            assertDirective: function () {
              return b.CO;
            },
            assertEnumType: function () {
              return m.Zu;
            },
            assertEnumValueName: function () {
              return O.g;
            },
            assertInputObjectType: function () {
              return m.U8;
            },
            assertInputType: function () {
              return m.qT;
            },
            assertInterfaceType: function () {
              return m.k2;
            },
            assertLeafType: function () {
              return m.H5;
            },
            assertListType: function () {
              return m.kS;
            },
            assertName: function () {
              return O.i;
            },
            assertNamedType: function () {
              return m.rM;
            },
            assertNonNullType: function () {
              return m.E$;
            },
            assertNullableType: function () {
              return m.i_;
            },
            assertObjectType: function () {
              return m.Z6;
            },
            assertOutputType: function () {
              return m.Gt;
            },
            assertScalarType: function () {
              return m.Pt;
            },
            assertSchema: function () {
              return _.EO;
            },
            assertType: function () {
              return m.p_;
            },
            assertUnionType: function () {
              return m.rc;
            },
            assertValidName: function () {
              return te;
            },
            assertValidSchema: function () {
              return p.J;
            },
            assertWrappingType: function () {
              return m.vX;
            },
            astFromValue: function () {
              return e$.J;
            },
            buildASTSchema: function () {
              return eB;
            },
            buildClientSchema: function () {
              return th.Z;
            },
            buildSchema: function () {
              return ej;
            },
            coerceInputValue: function () {
              return tg.K;
            },
            concatAST: function () {
              return e4;
            },
            createSourceEventStream: function () {
              return x.z;
            },
            defaultFieldResolver: function () {
              return d.El;
            },
            defaultTypeResolver: function () {
              return d.mn;
            },
            doTypesOverlap: function () {
              return tm.zR;
            },
            execute: function () {
              return d.ht;
            },
            executeSync: function () {
              return d.p0;
            },
            extendSchema: function () {
              return ek;
            },
            findBreakingChanges: function () {
              return tr;
            },
            findDangerousChanges: function () {
              return to;
            },
            formatError: function () {
              return B.Z;
            },
            getArgumentValues: function () {
              return P.LX;
            },
            getDirectiveValues: function () {
              return P.zu;
            },
            getEnterLeaveForKind: function () {
              return M.Eu;
            },
            getIntrospectionQuery: function () {
              return eI.K;
            },
            getLocation: function () {
              return w.k;
            },
            getNamedType: function () {
              return m.xC;
            },
            getNullableType: function () {
              return m.tf;
            },
            getOperationAST: function () {
              return tp.S;
            },
            getOperationRootType: function () {
              return eA;
            },
            getVariableValues: function () {
              return P.QF;
            },
            getVisitFn: function () {
              return M.CK;
            },
            graphql: function () {
              return y;
            },
            graphqlSync: function () {
              return v;
            },
            introspectionFromSchema: function () {
              return eN;
            },
            introspectionTypes: function () {
              return T.nL;
            },
            isAbstractType: function () {
              return m.m0;
            },
            isCompositeType: function () {
              return m.Gv;
            },
            isConstValueNode: function () {
              return U.Of;
            },
            isDefinitionNode: function () {
              return U.Ir;
            },
            isDirective: function () {
              return b.wX;
            },
            isEnumType: function () {
              return m.EM;
            },
            isEqualType: function () {
              return tm._7;
            },
            isExecutableDefinitionNode: function () {
              return U.Wk;
            },
            isInputObjectType: function () {
              return m.hL;
            },
            isInputType: function () {
              return m.j$;
            },
            isInterfaceType: function () {
              return m.oT;
            },
            isIntrospectionType: function () {
              return T.s9;
            },
            isLeafType: function () {
              return m.UT;
            },
            isListType: function () {
              return m.HG;
            },
            isNamedType: function () {
              return m.Zs;
            },
            isNonNullType: function () {
              return m.zM;
            },
            isNullableType: function () {
              return m.zP;
            },
            isObjectType: function () {
              return m.lp;
            },
            isOutputType: function () {
              return m.SZ;
            },
            isRequiredArgument: function () {
              return m.dK;
            },
            isRequiredInputField: function () {
              return m.Wd;
            },
            isScalarType: function () {
              return m.KA;
            },
            isSchema: function () {
              return _.nN;
            },
            isSelectionNode: function () {
              return U.pO;
            },
            isSpecifiedDirective: function () {
              return b.xg;
            },
            isSpecifiedScalarType: function () {
              return E.u1;
            },
            isType: function () {
              return m.P9;
            },
            isTypeDefinitionNode: function () {
              return U.zT;
            },
            isTypeExtensionNode: function () {
              return U.D$;
            },
            isTypeNode: function () {
              return U.VB;
            },
            isTypeSubTypeOf: function () {
              return tm.uJ;
            },
            isTypeSystemDefinitionNode: function () {
              return U.G4;
            },
            isTypeSystemExtensionNode: function () {
              return U.aU;
            },
            isUnionType: function () {
              return m.EN;
            },
            isValidNameError: function () {
              return tt;
            },
            isValueNode: function () {
              return U.nr;
            },
            isWrappingType: function () {
              return m.fw;
            },
            lexicographicSortSchema: function () {
              return eF;
            },
            locatedError: function () {
              return eS.y;
            },
            parse: function () {
              return l.Qc;
            },
            parseConstValue: function () {
              return l.tl;
            },
            parseType: function () {
              return l.gZ;
            },
            parseValue: function () {
              return l.H2;
            },
            print: function () {
              return R.print;
            },
            printError: function () {
              return B.OS;
            },
            printIntrospectionSchema: function () {
              return ez;
            },
            printLocation: function () {
              return I.Q;
            },
            printSchema: function () {
              return eY;
            },
            printSourceLocation: function () {
              return I.z;
            },
            printType: function () {
              return eZ;
            },
            resolveObjMapThunk: function () {
              return m.WB;
            },
            resolveReadonlyArrayThunk: function () {
              return m._9;
            },
            responsePathAsArray: function () {
              return L.N;
            },
            separateOperations: function () {
              return e8;
            },
            specifiedDirectives: function () {
              return b.V4;
            },
            specifiedRules: function () {
              return G.i;
            },
            specifiedScalarTypes: function () {
              return E.HS;
            },
            stripIgnoredCharacters: function () {
              return e7;
            },
            subscribe: function () {
              return x.L;
            },
            syntaxError: function () {
              return eO.h;
            },
            typeFromAST: function () {
              return td._;
            },
            validate: function () {
              return h.Gu;
            },
            validateSchema: function () {
              return p.F;
            },
            valueFromAST: function () {
              return eD.u;
            },
            valueFromASTUntyped: function () {
              return ty.M;
            },
            version: function () {
              return r;
            },
            versionInfo: function () {
              return o;
            },
            visit: function () {
              return M.Vn;
            },
            visitInParallel: function () {
              return M.j1;
            },
            visitWithTypeInfo: function () {
              return tv.y;
            },
          });
        let r = "16.8.1",
          o = Object.freeze({
            major: 16,
            minor: 8,
            patch: 1,
            preReleaseTag: null,
          });
        var i,
          s,
          a,
          u,
          c = n(37826),
          f = n(38659),
          l = n(84275),
          p = n(19655),
          h = n(24635),
          d = n(74296);
        function y(e) {
          return new Promise((t) => t(g(e)));
        }
        function v(e) {
          let t = g(e);
          if ((0, f.t)(t))
            throw Error("GraphQL execution failed to complete synchronously.");
          return t;
        }
        function g(e) {
          let t;
          arguments.length < 2 ||
            (0, c.a)(
              !1,
              "graphql@16 dropped long-deprecated support for positional arguments, please pass an object instead."
            );
          let {
              schema: n,
              source: r,
              rootValue: o,
              contextValue: i,
              variableValues: s,
              operationName: a,
              fieldResolver: u,
              typeResolver: f,
            } = e,
            y = (0, p.F)(n);
          if (y.length > 0) return { errors: y };
          try {
            t = (0, l.Qc)(r);
          } catch (e) {
            return { errors: [e] };
          }
          let v = (0, h.Gu)(n, t);
          return v.length > 0
            ? { errors: v }
            : (0, d.ht)({
                schema: n,
                document: t,
                rootValue: o,
                contextValue: i,
                variableValues: s,
                operationName: a,
                fieldResolver: u,
                typeResolver: f,
              });
        }
        var m = n(4454),
          _ = n(59678),
          b = n(68238),
          E = n(3801),
          T = n(52433),
          O = n(96303),
          S = n(72380),
          A = n(7926),
          w = n(57867),
          I = n(90850),
          N = n(92105),
          C = n(74635),
          R = n(16918),
          M = n(77304),
          D = n(97359),
          k = n(99878),
          U = n(75844),
          L = n(79380),
          P = n(66422),
          x = n(70145),
          B = n(28087);
        function j(e) {
          return {
            Field(t) {
              let n = (0, m.xC)(e.getType());
              n &&
                (0, T.s9)(n) &&
                e.reportError(
                  new B.__(
                    `GraphQL introspection has been disabled, but the requested query contained the field "${t.name.value}".`,
                    { nodes: t }
                  )
                );
            },
          };
        }
        var V = n(32734),
          G = n(24196),
          F = n(88081),
          q = n(48741),
          K = n(77143),
          H = n(47815),
          Q = n(84873),
          $ = n(5311),
          Y = n(25580),
          z = n(27898),
          W = n(91422),
          J = n(14790),
          Z = n(81294),
          X = n(72283),
          ee = n(54203),
          et = n(63259),
          en = n(61967),
          er = n(41954),
          eo = n(10423),
          ei = n(42266),
          es = n(96300),
          ea = n(45591),
          eu = n(92767),
          ec = n(82621),
          ef = n(1564),
          el = n(19831),
          ep = n(45972),
          eh = n(9701),
          ed = n(52877),
          ey = n(77990),
          ev = n(69538),
          eg = n(93201),
          em = n(22618),
          e_ = n(12337),
          eb = n(53274),
          eE = n(34800),
          eT = n(15394),
          eO = n(45219),
          eS = n(31394);
        function eA(e, t) {
          if ("query" === t.operation) {
            let n = e.getQueryType();
            if (!n)
              throw new B.__(
                "Schema does not define the required query root type.",
                { nodes: t }
              );
            return n;
          }
          if ("mutation" === t.operation) {
            let n = e.getMutationType();
            if (!n)
              throw new B.__("Schema is not configured for mutations.", {
                nodes: t,
              });
            return n;
          }
          if ("subscription" === t.operation) {
            let n = e.getSubscriptionType();
            if (!n)
              throw new B.__("Schema is not configured for subscriptions.", {
                nodes: t,
              });
            return n;
          }
          throw new B.__(
            "Can only have query, mutation and subscription operations.",
            { nodes: t }
          );
        }
        var ew = n(29551),
          eI = n(82254);
        function eN(e, t) {
          let n = {
              specifiedByUrl: !0,
              directiveIsRepeatable: !0,
              schemaDescription: !0,
              inputValueDeprecation: !0,
              ...t,
            },
            r = (0, l.Qc)((0, eI.K)(n)),
            o = (0, d.p0)({ schema: e, document: r });
          return (!o.errors && o.data) || (0, ew.k)(!1), o.data;
        }
        var eC = n(25821),
          eR = n(73498),
          eM = n(95723),
          eD = n(58081);
        function ek(e, t, n) {
          (0, _.EO)(e),
            (null != t && t.kind === D.h.DOCUMENT) ||
              (0, c.a)(!1, "Must provide valid Document AST."),
            (null == n ? void 0 : n.assumeValid) !== !0 &&
              (null == n ? void 0 : n.assumeValidSDL) !== !0 &&
              (0, h.ED)(t, e);
          let r = e.toConfig(),
            o = eU(r, t, n);
          return r === o ? e : new _.XO(o);
        }
        function eU(e, t, n) {
          var r, o, i, s, a, u;
          let c;
          let f = [],
            l = Object.create(null),
            p = [],
            h = [];
          for (let e of t.definitions)
            if (e.kind === D.h.SCHEMA_DEFINITION) c = e;
            else if (e.kind === D.h.SCHEMA_EXTENSION) h.push(e);
            else if ((0, U.zT)(e)) f.push(e);
            else if ((0, U.D$)(e)) {
              let t = e.name.value,
                n = l[t];
              l[t] = n ? n.concat([e]) : [e];
            } else e.kind === D.h.DIRECTIVE_DEFINITION && p.push(e);
          if (
            0 === Object.keys(l).length &&
            0 === f.length &&
            0 === p.length &&
            0 === h.length &&
            null == c
          )
            return e;
          let d = Object.create(null);
          for (let t of e.types)
            d[t.name] =
              ((u = t),
              (0, T.s9)(u) || (0, E.u1)(u)
                ? u
                : (0, m.KA)(u)
                ? (function (e) {
                    var t, n;
                    let r = e.toConfig(),
                      o = null !== (t = l[r.name]) && void 0 !== t ? t : [],
                      i = r.specifiedByURL;
                    for (let e of o)
                      i = null !== (n = ex(e)) && void 0 !== n ? n : i;
                    return new m.n2({
                      ...r,
                      specifiedByURL: i,
                      extensionASTNodes: r.extensionASTNodes.concat(o),
                    });
                  })(u)
                : (0, m.lp)(u)
                ? (function (e) {
                    var t;
                    let n = e.toConfig(),
                      r = null !== (t = l[n.name]) && void 0 !== t ? t : [];
                    return new m.h6({
                      ...n,
                      interfaces: () => [...e.getInterfaces().map(g), ...M(r)],
                      fields: () => ({ ...(0, eM.j)(n.fields, _), ...I(r) }),
                      extensionASTNodes: n.extensionASTNodes.concat(r),
                    });
                  })(u)
                : (0, m.oT)(u)
                ? (function (e) {
                    var t;
                    let n = e.toConfig(),
                      r = null !== (t = l[n.name]) && void 0 !== t ? t : [];
                    return new m.oW({
                      ...n,
                      interfaces: () => [...e.getInterfaces().map(g), ...M(r)],
                      fields: () => ({ ...(0, eM.j)(n.fields, _), ...I(r) }),
                      extensionASTNodes: n.extensionASTNodes.concat(r),
                    });
                  })(u)
                : (0, m.EN)(u)
                ? (function (e) {
                    var t;
                    let n = e.toConfig(),
                      r = null !== (t = l[n.name]) && void 0 !== t ? t : [];
                    return new m.Gp({
                      ...n,
                      types: () => [...e.getTypes().map(g), ...k(r)],
                      extensionASTNodes: n.extensionASTNodes.concat(r),
                    });
                  })(u)
                : (0, m.EM)(u)
                ? (function (e) {
                    var t;
                    let n = e.toConfig(),
                      r = null !== (t = l[e.name]) && void 0 !== t ? t : [];
                    return new m.mR({
                      ...n,
                      values: { ...n.values, ...R(r) },
                      extensionASTNodes: n.extensionASTNodes.concat(r),
                    });
                  })(u)
                : (0, m.hL)(u)
                ? (function (e) {
                    var t;
                    let n = e.toConfig(),
                      r = null !== (t = l[n.name]) && void 0 !== t ? t : [];
                    return new m.sR({
                      ...n,
                      fields: () => ({
                        ...(0, eM.j)(n.fields, (e) => ({
                          ...e,
                          type: v(e.type),
                        })),
                        ...C(r),
                      }),
                      extensionASTNodes: n.extensionASTNodes.concat(r),
                    });
                  })(u)
                : void (0, ew.k)(!1, "Unexpected type: " + (0, eC.X)(u)));
          for (let e of f) {
            let t = e.name.value;
            d[t] =
              null !== (a = eL[t]) && void 0 !== a
                ? a
                : (function (e) {
                    var t, n, r, o, i, s, a;
                    let u = e.name.value,
                      c = null !== (t = l[u]) && void 0 !== t ? t : [];
                    switch (e.kind) {
                      case D.h.OBJECT_TYPE_DEFINITION: {
                        let t = [e, ...c];
                        return new m.h6({
                          name: u,
                          description:
                            null === (n = e.description) || void 0 === n
                              ? void 0
                              : n.value,
                          interfaces: () => M(t),
                          fields: () => I(t),
                          astNode: e,
                          extensionASTNodes: c,
                        });
                      }
                      case D.h.INTERFACE_TYPE_DEFINITION: {
                        let t = [e, ...c];
                        return new m.oW({
                          name: u,
                          description:
                            null === (r = e.description) || void 0 === r
                              ? void 0
                              : r.value,
                          interfaces: () => M(t),
                          fields: () => I(t),
                          astNode: e,
                          extensionASTNodes: c,
                        });
                      }
                      case D.h.ENUM_TYPE_DEFINITION: {
                        let t = [e, ...c];
                        return new m.mR({
                          name: u,
                          description:
                            null === (o = e.description) || void 0 === o
                              ? void 0
                              : o.value,
                          values: R(t),
                          astNode: e,
                          extensionASTNodes: c,
                        });
                      }
                      case D.h.UNION_TYPE_DEFINITION: {
                        let t = [e, ...c];
                        return new m.Gp({
                          name: u,
                          description:
                            null === (i = e.description) || void 0 === i
                              ? void 0
                              : i.value,
                          types: () => k(t),
                          astNode: e,
                          extensionASTNodes: c,
                        });
                      }
                      case D.h.SCALAR_TYPE_DEFINITION:
                        return new m.n2({
                          name: u,
                          description:
                            null === (s = e.description) || void 0 === s
                              ? void 0
                              : s.value,
                          specifiedByURL: ex(e),
                          astNode: e,
                          extensionASTNodes: c,
                        });
                      case D.h.INPUT_OBJECT_TYPE_DEFINITION: {
                        let t = [e, ...c];
                        return new m.sR({
                          name: u,
                          description:
                            null === (a = e.description) || void 0 === a
                              ? void 0
                              : a.value,
                          fields: () => C(t),
                          astNode: e,
                          extensionASTNodes: c,
                        });
                      }
                    }
                  })(e);
          }
          let y = {
            query: e.query && g(e.query),
            mutation: e.mutation && g(e.mutation),
            subscription: e.subscription && g(e.subscription),
            ...(c && S([c])),
            ...S(h),
          };
          return {
            description:
              null === (r = c) || void 0 === r
                ? void 0
                : null === (o = r.description) || void 0 === o
                ? void 0
                : o.value,
            ...y,
            types: Object.values(d),
            directives: [
              ...e.directives.map(function (e) {
                let t = e.toConfig();
                return new b.NZ({ ...t, args: (0, eM.j)(t.args, O) });
              }),
              ...p.map(function (e) {
                var t;
                return new b.NZ({
                  name: e.name.value,
                  description:
                    null === (t = e.description) || void 0 === t
                      ? void 0
                      : t.value,
                  locations: e.locations.map(({ value: e }) => e),
                  isRepeatable: e.repeatable,
                  args: N(e.arguments),
                  astNode: e,
                });
              }),
            ],
            extensions: Object.create(null),
            astNode: null !== (i = c) && void 0 !== i ? i : e.astNode,
            extensionASTNodes: e.extensionASTNodes.concat(h),
            assumeValid:
              null !== (s = null == n ? void 0 : n.assumeValid) &&
              void 0 !== s &&
              s,
          };
          function v(e) {
            return (0, m.HG)(e)
              ? new m.p2(v(e.ofType))
              : (0, m.zM)(e)
              ? new m.bM(v(e.ofType))
              : g(e);
          }
          function g(e) {
            return d[e.name];
          }
          function _(e) {
            return {
              ...e,
              type: v(e.type),
              args: e.args && (0, eM.j)(e.args, O),
            };
          }
          function O(e) {
            return { ...e, type: v(e.type) };
          }
          function S(e) {
            let t = {};
            for (let r of e) {
              var n;
              let e = null !== (n = r.operationTypes) && void 0 !== n ? n : [];
              for (let n of e) t[n.operation] = A(n.type);
            }
            return t;
          }
          function A(e) {
            var t;
            let n = e.name.value,
              r = null !== (t = eL[n]) && void 0 !== t ? t : d[n];
            if (void 0 === r) throw Error(`Unknown type: "${n}".`);
            return r;
          }
          function w(e) {
            return e.kind === D.h.LIST_TYPE
              ? new m.p2(w(e.type))
              : e.kind === D.h.NON_NULL_TYPE
              ? new m.bM(w(e.type))
              : A(e);
          }
          function I(e) {
            let t = Object.create(null);
            for (let o of e) {
              var n, r;
              let e = null !== (n = o.fields) && void 0 !== n ? n : [];
              for (let n of e)
                t[n.name.value] = {
                  type: w(n.type),
                  description:
                    null === (r = n.description) || void 0 === r
                      ? void 0
                      : r.value,
                  args: N(n.arguments),
                  deprecationReason: eP(n),
                  astNode: n,
                };
            }
            return t;
          }
          function N(e) {
            let t = Object.create(null);
            for (let r of null != e ? e : []) {
              var n;
              let e = w(r.type);
              t[r.name.value] = {
                type: e,
                description:
                  null === (n = r.description) || void 0 === n
                    ? void 0
                    : n.value,
                defaultValue: (0, eD.u)(r.defaultValue, e),
                deprecationReason: eP(r),
                astNode: r,
              };
            }
            return t;
          }
          function C(e) {
            let t = Object.create(null);
            for (let o of e) {
              var n, r;
              let e = null !== (n = o.fields) && void 0 !== n ? n : [];
              for (let n of e) {
                let e = w(n.type);
                t[n.name.value] = {
                  type: e,
                  description:
                    null === (r = n.description) || void 0 === r
                      ? void 0
                      : r.value,
                  defaultValue: (0, eD.u)(n.defaultValue, e),
                  deprecationReason: eP(n),
                  astNode: n,
                };
              }
            }
            return t;
          }
          function R(e) {
            let t = Object.create(null);
            for (let o of e) {
              var n, r;
              let e = null !== (n = o.values) && void 0 !== n ? n : [];
              for (let n of e)
                t[n.name.value] = {
                  description:
                    null === (r = n.description) || void 0 === r
                      ? void 0
                      : r.value,
                  deprecationReason: eP(n),
                  astNode: n,
                };
            }
            return t;
          }
          function M(e) {
            return e.flatMap((e) => {
              var t, n;
              return null !==
                (t =
                  null === (n = e.interfaces) || void 0 === n
                    ? void 0
                    : n.map(A)) && void 0 !== t
                ? t
                : [];
            });
          }
          function k(e) {
            return e.flatMap((e) => {
              var t, n;
              return null !==
                (t =
                  null === (n = e.types) || void 0 === n ? void 0 : n.map(A)) &&
                void 0 !== t
                ? t
                : [];
            });
          }
        }
        let eL = (0, eR.P)([...E.HS, ...T.nL], (e) => e.name);
        function eP(e) {
          let t = (0, P.zu)(b.fg, e);
          return null == t ? void 0 : t.reason;
        }
        function ex(e) {
          let t = (0, P.zu)(b.df, e);
          return null == t ? void 0 : t.url;
        }
        function eB(e, t) {
          (null != e && e.kind === D.h.DOCUMENT) ||
            (0, c.a)(!1, "Must provide valid Document AST."),
            (null == t ? void 0 : t.assumeValid) !== !0 &&
              (null == t ? void 0 : t.assumeValidSDL) !== !0 &&
              (0, h.zo)(e);
          let n = {
              description: void 0,
              types: [],
              directives: [],
              extensions: Object.create(null),
              extensionASTNodes: [],
              assumeValid: !1,
            },
            r = eU(n, e, t);
          if (null == r.astNode)
            for (let e of r.types)
              switch (e.name) {
                case "Query":
                  r.query = e;
                  break;
                case "Mutation":
                  r.mutation = e;
                  break;
                case "Subscription":
                  r.subscription = e;
              }
          let o = [
            ...r.directives,
            ...b.V4.filter((e) => r.directives.every((t) => t.name !== e.name)),
          ];
          return new _.XO({ ...r, directives: o });
        }
        function ej(e, t) {
          let n = (0, l.Qc)(e, {
            noLocation: null == t ? void 0 : t.noLocation,
            allowLegacyFragmentVariables:
              null == t ? void 0 : t.allowLegacyFragmentVariables,
          });
          return eB(n, {
            assumeValidSDL: null == t ? void 0 : t.assumeValidSDL,
            assumeValid: null == t ? void 0 : t.assumeValid,
          });
        }
        var eV = n(54950),
          eG = n(8224);
        function eF(e) {
          var t, n, r;
          let o = e.toConfig(),
            i = (0, eV.w)(
              eK(o.types),
              (e) => e.name,
              function (e) {
                if ((0, m.KA)(e) || (0, T.s9)(e)) return e;
                if ((0, m.lp)(e)) {
                  let t = e.toConfig();
                  return new m.h6({
                    ...t,
                    interfaces: () => f(t.interfaces),
                    fields: () => c(t.fields),
                  });
                }
                if ((0, m.oT)(e)) {
                  let t = e.toConfig();
                  return new m.oW({
                    ...t,
                    interfaces: () => f(t.interfaces),
                    fields: () => c(t.fields),
                  });
                }
                if ((0, m.EN)(e)) {
                  let t = e.toConfig();
                  return new m.Gp({ ...t, types: () => f(t.types) });
                }
                if ((0, m.EM)(e)) {
                  let t = e.toConfig();
                  return new m.mR({ ...t, values: eq(t.values, (e) => e) });
                }
                if ((0, m.hL)(e)) {
                  let t = e.toConfig();
                  return new m.sR({
                    ...t,
                    fields: () =>
                      eq(t.fields, (e) => ({ ...e, type: s(e.type) })),
                  });
                }
                (0, ew.k)(!1, "Unexpected type: " + (0, eC.X)(e));
              }
            );
          return new _.XO({
            ...o,
            types: Object.values(i),
            directives: eK(o.directives).map(function (e) {
              let t = e.toConfig();
              return new b.NZ({
                ...t,
                locations: eH(t.locations, (e) => e),
                args: u(t.args),
              });
            }),
            query: (t = o.query) && a(t),
            mutation: (n = o.mutation) && a(n),
            subscription: (r = o.subscription) && a(r),
          });
          function s(e) {
            return (0, m.HG)(e)
              ? new m.p2(s(e.ofType))
              : (0, m.zM)(e)
              ? new m.bM(s(e.ofType))
              : a(e);
          }
          function a(e) {
            return i[e.name];
          }
          function u(e) {
            return eq(e, (e) => ({ ...e, type: s(e.type) }));
          }
          function c(e) {
            return eq(e, (e) => ({
              ...e,
              type: s(e.type),
              args: e.args && u(e.args),
            }));
          }
          function f(e) {
            return eK(e).map(a);
          }
        }
        function eq(e, t) {
          let n = Object.create(null);
          for (let r of Object.keys(e).sort(eG.K)) n[r] = t(e[r]);
          return n;
        }
        function eK(e) {
          return eH(e, (e) => e.name);
        }
        function eH(e, t) {
          return e.slice().sort((e, n) => {
            let r = t(e),
              o = t(n);
            return (0, eG.K)(r, o);
          });
        }
        var eQ = n(87392),
          e$ = n(78631);
        function eY(e) {
          return eJ(e, (e) => !(0, b.xg)(e), eW);
        }
        function ez(e) {
          return eJ(e, b.xg, T.s9);
        }
        function eW(e) {
          return !(0, E.u1)(e) && !(0, T.s9)(e);
        }
        function eJ(e, t, n) {
          let r = e.getDirectives().filter(t),
            o = Object.values(e.getTypeMap()).filter(n);
          return [
            (function (e) {
              if (
                null == e.description &&
                (function (e) {
                  let t = e.getQueryType();
                  if (t && "Query" !== t.name) return !1;
                  let n = e.getMutationType();
                  if (n && "Mutation" !== n.name) return !1;
                  let r = e.getSubscriptionType();
                  return !r || "Subscription" === r.name;
                })(e)
              )
                return;
              let t = [],
                n = e.getQueryType();
              n && t.push(`  query: ${n.name}`);
              let r = e.getMutationType();
              r && t.push(`  mutation: ${r.name}`);
              let o = e.getSubscriptionType();
              return (
                o && t.push(`  subscription: ${o.name}`),
                e6(e) +
                  `schema {
${t.join("\n")}
}`
              );
            })(e),
            ...r.map(
              (e) =>
                e6(e) +
                "directive @" +
                e.name +
                e2(e.args) +
                (e.isRepeatable ? " repeatable" : "") +
                " on " +
                e.locations.join(" | ")
            ),
            ...o.map((e) => eZ(e)),
          ]
            .filter(Boolean)
            .join("\n\n");
        }
        function eZ(e) {
          return (0, m.KA)(e)
            ? e6(e) +
                `scalar ${e.name}` +
                (function (e) {
                  if (null == e.specifiedByURL) return "";
                  let t = (0, R.print)({
                    kind: D.h.STRING,
                    value: e.specifiedByURL,
                  });
                  return ` @specifiedBy(url: ${t})`;
                })(e)
            : (0, m.lp)(e)
            ? e6(e) + `type ${e.name}` + eX(e) + e0(e)
            : (0, m.oT)(e)
            ? e6(e) + `interface ${e.name}` + eX(e) + e0(e)
            : (0, m.EN)(e)
            ? (function (e) {
                let t = e.getTypes(),
                  n = t.length ? " = " + t.join(" | ") : "";
                return e6(e) + "union " + e.name + n;
              })(e)
            : (0, m.EM)(e)
            ? (function (e) {
                let t = e
                  .getValues()
                  .map(
                    (e, t) =>
                      e6(e, "  ", !t) + "  " + e.name + e3(e.deprecationReason)
                  );
                return e6(e) + `enum ${e.name}` + e1(t);
              })(e)
            : (0, m.hL)(e)
            ? (function (e) {
                let t = Object.values(e.getFields()).map(
                  (e, t) => e6(e, "  ", !t) + "  " + e5(e)
                );
                return e6(e) + `input ${e.name}` + e1(t);
              })(e)
            : void (0, ew.k)(!1, "Unexpected type: " + (0, eC.X)(e));
        }
        function eX(e) {
          let t = e.getInterfaces();
          return t.length
            ? " implements " + t.map((e) => e.name).join(" & ")
            : "";
        }
        function e0(e) {
          let t = Object.values(e.getFields()).map(
            (e, t) =>
              e6(e, "  ", !t) +
              "  " +
              e.name +
              e2(e.args, "  ") +
              ": " +
              String(e.type) +
              e3(e.deprecationReason)
          );
          return e1(t);
        }
        function e1(e) {
          return 0 !== e.length ? " {\n" + e.join("\n") + "\n}" : "";
        }
        function e2(e, t = "") {
          return 0 === e.length
            ? ""
            : e.every((e) => !e.description)
            ? "(" + e.map(e5).join(", ") + ")"
            : "(\n" +
              e
                .map((e, n) => e6(e, "  " + t, !n) + "  " + t + e5(e))
                .join("\n") +
              "\n" +
              t +
              ")";
        }
        function e5(e) {
          let t = (0, e$.J)(e.defaultValue, e.type),
            n = e.name + ": " + String(e.type);
          return (
            t && (n += ` = ${(0, R.print)(t)}`), n + e3(e.deprecationReason)
          );
        }
        function e3(e) {
          if (null == e) return "";
          if (e !== b.SY) {
            let t = (0, R.print)({ kind: D.h.STRING, value: e });
            return ` @deprecated(reason: ${t})`;
          }
          return " @deprecated";
        }
        function e6(e, t = "", n = !0) {
          let { description: r } = e;
          if (null == r) return "";
          let o = (0, R.print)({
            kind: D.h.STRING,
            value: r,
            block: (0, eQ.MZ)(r),
          });
          return (t && !n ? "\n" + t : t) + o.replace(/\n/g, "\n" + t) + "\n";
        }
        function e4(e) {
          let t = [];
          for (let n of e) t.push(...n.definitions);
          return { kind: D.h.DOCUMENT, definitions: t };
        }
        function e8(e) {
          let t = [],
            n = Object.create(null);
          for (let r of e.definitions)
            switch (r.kind) {
              case D.h.OPERATION_DEFINITION:
                t.push(r);
                break;
              case D.h.FRAGMENT_DEFINITION:
                n[r.name.value] = e9(r.selectionSet);
            }
          let r = Object.create(null);
          for (let o of t) {
            let t = new Set();
            for (let e of e9(o.selectionSet))
              (function e(t, n, r) {
                if (!t.has(r)) {
                  t.add(r);
                  let o = n[r];
                  if (void 0 !== o) for (let r of o) e(t, n, r);
                }
              })(t, n, e);
            let i = o.name ? o.name.value : "";
            r[i] = {
              kind: D.h.DOCUMENT,
              definitions: e.definitions.filter(
                (e) =>
                  e === o ||
                  (e.kind === D.h.FRAGMENT_DEFINITION && t.has(e.name.value))
              ),
            };
          }
          return r;
        }
        function e9(e) {
          let t = [];
          return (
            (0, M.Vn)(e, {
              FragmentSpread(e) {
                t.push(e.name.value);
              },
            }),
            t
          );
        }
        function e7(e) {
          let t = (0, A.T)(e) ? e : new A.H(e),
            n = t.body,
            r = new N.h(t),
            o = "",
            i = !1;
          for (; r.advance().kind !== C.T.EOF; ) {
            let e = r.token,
              t = e.kind,
              s = !(0, N.u)(e.kind);
            i && (s || e.kind === C.T.SPREAD) && (o += " ");
            let a = n.slice(e.start, e.end);
            t === C.T.BLOCK_STRING
              ? (o += (0, eQ.LZ)(e.value, { minimize: !0 }))
              : (o += a),
              (i = s);
          }
          return o;
        }
        function te(e) {
          let t = tt(e);
          if (t) throw t;
          return e;
        }
        function tt(e) {
          if (
            ("string" == typeof e ||
              (0, c.a)(!1, "Expected name to be a string."),
            e.startsWith("__"))
          )
            return new B.__(
              `Name "${e}" must not begin with "__", which is reserved by GraphQL introspection.`
            );
          try {
            (0, O.i)(e);
          } catch (e) {
            return e;
          }
        }
        var tn = n(38360);
        function tr(e, t) {
          return ti(e, t).filter((e) => e.type in a);
        }
        function to(e, t) {
          return ti(e, t).filter((e) => e.type in u);
        }
        function ti(e, t) {
          return [
            ...(function (e, t) {
              let n = [],
                r = tl(
                  Object.values(e.getTypeMap()),
                  Object.values(t.getTypeMap())
                );
              for (let e of r.removed)
                n.push({
                  type: a.TYPE_REMOVED,
                  description: (0, E.u1)(e)
                    ? `Standard scalar ${e.name} was removed because it is not referenced anymore.`
                    : `${e.name} was removed.`,
                });
              for (let [e, t] of r.persisted)
                (0, m.EM)(e) && (0, m.EM)(t)
                  ? n.push(
                      ...(function (e, t) {
                        let n = [],
                          r = tl(e.getValues(), t.getValues());
                        for (let t of r.added)
                          n.push({
                            type: u.VALUE_ADDED_TO_ENUM,
                            description: `${t.name} was added to enum type ${e.name}.`,
                          });
                        for (let t of r.removed)
                          n.push({
                            type: a.VALUE_REMOVED_FROM_ENUM,
                            description: `${t.name} was removed from enum type ${e.name}.`,
                          });
                        return n;
                      })(e, t)
                    )
                  : (0, m.EN)(e) && (0, m.EN)(t)
                  ? n.push(
                      ...(function (e, t) {
                        let n = [],
                          r = tl(e.getTypes(), t.getTypes());
                        for (let t of r.added)
                          n.push({
                            type: u.TYPE_ADDED_TO_UNION,
                            description: `${t.name} was added to union type ${e.name}.`,
                          });
                        for (let t of r.removed)
                          n.push({
                            type: a.TYPE_REMOVED_FROM_UNION,
                            description: `${t.name} was removed from union type ${e.name}.`,
                          });
                        return n;
                      })(e, t)
                    )
                  : (0, m.hL)(e) && (0, m.hL)(t)
                  ? n.push(
                      ...(function (e, t) {
                        let n = [],
                          r = tl(
                            Object.values(e.getFields()),
                            Object.values(t.getFields())
                          );
                        for (let t of r.added)
                          (0, m.Wd)(t)
                            ? n.push({
                                type: a.REQUIRED_INPUT_FIELD_ADDED,
                                description: `A required field ${t.name} on input type ${e.name} was added.`,
                              })
                            : n.push({
                                type: u.OPTIONAL_INPUT_FIELD_ADDED,
                                description: `An optional field ${t.name} on input type ${e.name} was added.`,
                              });
                        for (let t of r.removed)
                          n.push({
                            type: a.FIELD_REMOVED,
                            description: `${e.name}.${t.name} was removed.`,
                          });
                        for (let [t, o] of r.persisted) {
                          let r = tu(t.type, o.type);
                          r ||
                            n.push({
                              type: a.FIELD_CHANGED_KIND,
                              description: `${e.name}.${
                                t.name
                              } changed type from ${String(t.type)} to ${String(
                                o.type
                              )}.`,
                            });
                        }
                        return n;
                      })(e, t)
                    )
                  : (0, m.lp)(e) && (0, m.lp)(t)
                  ? n.push(...ta(e, t), ...ts(e, t))
                  : (0, m.oT)(e) && (0, m.oT)(t)
                  ? n.push(...ta(e, t), ...ts(e, t))
                  : e.constructor !== t.constructor &&
                    n.push({
                      type: a.TYPE_CHANGED_KIND,
                      description: `${e.name} changed from ${tc(e)} to ${tc(
                        t
                      )}.`,
                    });
              return n;
            })(e, t),
            ...(function (e, t) {
              let n = [],
                r = tl(e.getDirectives(), t.getDirectives());
              for (let e of r.removed)
                n.push({
                  type: a.DIRECTIVE_REMOVED,
                  description: `${e.name} was removed.`,
                });
              for (let [e, t] of r.persisted) {
                let r = tl(e.args, t.args);
                for (let t of r.added)
                  (0, m.dK)(t) &&
                    n.push({
                      type: a.REQUIRED_DIRECTIVE_ARG_ADDED,
                      description: `A required arg ${t.name} on directive ${e.name} was added.`,
                    });
                for (let t of r.removed)
                  n.push({
                    type: a.DIRECTIVE_ARG_REMOVED,
                    description: `${t.name} was removed from ${e.name}.`,
                  });
                for (let r of (e.isRepeatable &&
                  !t.isRepeatable &&
                  n.push({
                    type: a.DIRECTIVE_REPEATABLE_REMOVED,
                    description: `Repeatable flag was removed from ${e.name}.`,
                  }),
                e.locations))
                  t.locations.includes(r) ||
                    n.push({
                      type: a.DIRECTIVE_LOCATION_REMOVED,
                      description: `${r} was removed from ${e.name}.`,
                    });
              }
              return n;
            })(e, t),
          ];
        }
        function ts(e, t) {
          let n = [],
            r = tl(e.getInterfaces(), t.getInterfaces());
          for (let t of r.added)
            n.push({
              type: u.IMPLEMENTED_INTERFACE_ADDED,
              description: `${t.name} added to interfaces implemented by ${e.name}.`,
            });
          for (let t of r.removed)
            n.push({
              type: a.IMPLEMENTED_INTERFACE_REMOVED,
              description: `${e.name} no longer implements interface ${t.name}.`,
            });
          return n;
        }
        function ta(e, t) {
          let n = [],
            r = tl(Object.values(e.getFields()), Object.values(t.getFields()));
          for (let t of r.removed)
            n.push({
              type: a.FIELD_REMOVED,
              description: `${e.name}.${t.name} was removed.`,
            });
          for (let [t, o] of r.persisted) {
            n.push(
              ...(function (e, t, n) {
                let r = [],
                  o = tl(t.args, n.args);
                for (let n of o.removed)
                  r.push({
                    type: a.ARG_REMOVED,
                    description: `${e.name}.${t.name} arg ${n.name} was removed.`,
                  });
                for (let [n, i] of o.persisted) {
                  let o = tu(n.type, i.type);
                  if (o) {
                    if (void 0 !== n.defaultValue) {
                      if (void 0 === i.defaultValue)
                        r.push({
                          type: u.ARG_DEFAULT_VALUE_CHANGE,
                          description: `${e.name}.${t.name} arg ${n.name} defaultValue was removed.`,
                        });
                      else {
                        let o = tf(n.defaultValue, n.type),
                          s = tf(i.defaultValue, i.type);
                        o !== s &&
                          r.push({
                            type: u.ARG_DEFAULT_VALUE_CHANGE,
                            description: `${e.name}.${t.name} arg ${n.name} has changed defaultValue from ${o} to ${s}.`,
                          });
                      }
                    }
                  } else
                    r.push({
                      type: a.ARG_CHANGED_KIND,
                      description: `${e.name}.${t.name} arg ${
                        n.name
                      } has changed type from ${String(n.type)} to ${String(
                        i.type
                      )}.`,
                    });
                }
                for (let n of o.added)
                  (0, m.dK)(n)
                    ? r.push({
                        type: a.REQUIRED_ARG_ADDED,
                        description: `A required arg ${n.name} on ${e.name}.${t.name} was added.`,
                      })
                    : r.push({
                        type: u.OPTIONAL_ARG_ADDED,
                        description: `An optional arg ${n.name} on ${e.name}.${t.name} was added.`,
                      });
                return r;
              })(e, t, o)
            );
            let r = (function e(t, n) {
              return (0, m.HG)(t)
                ? ((0, m.HG)(n) && e(t.ofType, n.ofType)) ||
                    ((0, m.zM)(n) && e(t, n.ofType))
                : (0, m.zM)(t)
                ? (0, m.zM)(n) && e(t.ofType, n.ofType)
                : ((0, m.Zs)(n) && t.name === n.name) ||
                  ((0, m.zM)(n) && e(t, n.ofType));
            })(t.type, o.type);
            r ||
              n.push({
                type: a.FIELD_CHANGED_KIND,
                description: `${e.name}.${t.name} changed type from ${String(
                  t.type
                )} to ${String(o.type)}.`,
              });
          }
          return n;
        }
        function tu(e, t) {
          return (0, m.HG)(e)
            ? (0, m.HG)(t) && tu(e.ofType, t.ofType)
            : (0, m.zM)(e)
            ? ((0, m.zM)(t) && tu(e.ofType, t.ofType)) ||
              (!(0, m.zM)(t) && tu(e.ofType, t))
            : (0, m.Zs)(t) && e.name === t.name;
        }
        function tc(e) {
          return (0, m.KA)(e)
            ? "a Scalar type"
            : (0, m.lp)(e)
            ? "an Object type"
            : (0, m.oT)(e)
            ? "an Interface type"
            : (0, m.EN)(e)
            ? "a Union type"
            : (0, m.EM)(e)
            ? "an Enum type"
            : (0, m.hL)(e)
            ? "an Input type"
            : void (0, ew.k)(!1, "Unexpected type: " + (0, eC.X)(e));
        }
        function tf(e, t) {
          let n = (0, e$.J)(e, t);
          return null != n || (0, ew.k)(!1), (0, R.print)((0, tn.n)(n));
        }
        function tl(e, t) {
          let n = [],
            r = [],
            o = [],
            i = (0, eR.P)(e, ({ name: e }) => e),
            s = (0, eR.P)(t, ({ name: e }) => e);
          for (let t of e) {
            let e = s[t.name];
            void 0 === e ? r.push(t) : o.push([t, e]);
          }
          for (let e of t) void 0 === i[e.name] && n.push(e);
          return { added: n, persisted: o, removed: r };
        }
        ((i = a || (a = {})).TYPE_REMOVED = "TYPE_REMOVED"),
          (i.TYPE_CHANGED_KIND = "TYPE_CHANGED_KIND"),
          (i.TYPE_REMOVED_FROM_UNION = "TYPE_REMOVED_FROM_UNION"),
          (i.VALUE_REMOVED_FROM_ENUM = "VALUE_REMOVED_FROM_ENUM"),
          (i.REQUIRED_INPUT_FIELD_ADDED = "REQUIRED_INPUT_FIELD_ADDED"),
          (i.IMPLEMENTED_INTERFACE_REMOVED = "IMPLEMENTED_INTERFACE_REMOVED"),
          (i.FIELD_REMOVED = "FIELD_REMOVED"),
          (i.FIELD_CHANGED_KIND = "FIELD_CHANGED_KIND"),
          (i.REQUIRED_ARG_ADDED = "REQUIRED_ARG_ADDED"),
          (i.ARG_REMOVED = "ARG_REMOVED"),
          (i.ARG_CHANGED_KIND = "ARG_CHANGED_KIND"),
          (i.DIRECTIVE_REMOVED = "DIRECTIVE_REMOVED"),
          (i.DIRECTIVE_ARG_REMOVED = "DIRECTIVE_ARG_REMOVED"),
          (i.REQUIRED_DIRECTIVE_ARG_ADDED = "REQUIRED_DIRECTIVE_ARG_ADDED"),
          (i.DIRECTIVE_REPEATABLE_REMOVED = "DIRECTIVE_REPEATABLE_REMOVED"),
          (i.DIRECTIVE_LOCATION_REMOVED = "DIRECTIVE_LOCATION_REMOVED"),
          ((s = u || (u = {})).VALUE_ADDED_TO_ENUM = "VALUE_ADDED_TO_ENUM"),
          (s.TYPE_ADDED_TO_UNION = "TYPE_ADDED_TO_UNION"),
          (s.OPTIONAL_INPUT_FIELD_ADDED = "OPTIONAL_INPUT_FIELD_ADDED"),
          (s.OPTIONAL_ARG_ADDED = "OPTIONAL_ARG_ADDED"),
          (s.IMPLEMENTED_INTERFACE_ADDED = "IMPLEMENTED_INTERFACE_ADDED"),
          (s.ARG_DEFAULT_VALUE_CHANGE = "ARG_DEFAULT_VALUE_CHANGE");
        var tp = n(52100),
          th = n(99120),
          td = n(30077),
          ty = n(12319),
          tv = n(22676),
          tg = n(27816),
          tm = n(90316);
      },
      48910: function (e) {
        "use strict";
        e.exports = JSON.parse(
          '{"name":"aws-appsync-auth-link","version":"3.0.7","main":"lib/index.js","license":"Apache-2.0","description":"AWS Mobile AppSync Auth Link for JavaScript","author":{"name":"Amazon Web Services","url":"https://aws.amazon.com/"},"homepage":"https://github.com/awslabs/aws-mobile-appsync-sdk-js.git","repository":{"type":"git","url":"https://github.com/awslabs/aws-mobile-appsync-sdk-js.git"},"scripts":{"prepare":"tsc","test":"jest --coverage --coverageReporters=text --passWithNoTests","test-watch":"jest --watch"},"dependencies":{"@aws-crypto/sha256-js":"^1.2.0","@aws-sdk/types":"^3.25.0","@aws-sdk/util-hex-encoding":"^3.29.0","debug":"2.6.9"},"devDependencies":{"@apollo/client":"^3.2.0"},"peerDependencies":{"@apollo/client":"3.x"}}'
        );
      },
    },
  ]);
