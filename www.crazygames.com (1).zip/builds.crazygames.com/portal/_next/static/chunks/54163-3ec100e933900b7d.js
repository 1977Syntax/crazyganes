!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "2ec5c0c6-aad0-480c-abfd-ade2443ed87f"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-2ec5c0c6-aad0-480c-abfd-ade2443ed87f"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [54163],
    {
      30954: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return m;
          },
        });
        var r = n(87462),
          a = n(63366),
          o = n(67294),
          i = n(33703),
          l = n(94780),
          d = n(32289),
          s = n(34867);
        function u(e) {
          return (0, s.ZP)("MuiOption", e);
        }
        (0, n(1588).Z)("MuiOption", [
          "root",
          "disabled",
          "selected",
          "highlighted",
        ]);
        var c = n(44922),
          h = n(85893);
        let f = [
            "children",
            "component",
            "disabled",
            "label",
            "slotProps",
            "slots",
            "value",
          ],
          p = o.forwardRef(function (e, t) {
            let {
                children: n,
                component: s,
                disabled: p,
                label: m,
                slotProps: g = {},
                slots: b = {},
                value: y,
              } = e,
              w = (0, a.Z)(e, f),
              v = o.useContext(d.j);
            if (!v)
              throw Error(
                "OptionUnstyled must be used within a SelectUnstyled"
              );
            let M = s || b.root || "li",
              Z = { value: y, label: m || n, disabled: p },
              C = v.getOptionState(Z),
              k = v.getOptionProps(Z),
              _ = v.listboxRef,
              x = (0, r.Z)({}, e, C),
              R = o.useRef(null),
              S = (0, i.Z)(t, R);
            o.useEffect(() => {
              if (C.highlighted) {
                if (!_.current || !R.current) return;
                let e = _.current.getBoundingClientRect(),
                  t = R.current.getBoundingClientRect();
                t.top < e.top
                  ? (_.current.scrollTop -= e.top - t.top)
                  : t.bottom > e.bottom &&
                    (_.current.scrollTop += t.bottom - e.bottom);
              }
            }, [C.highlighted, _]);
            let P = (function (e) {
                let { disabled: t, highlighted: n, selected: r } = e;
                return (0, l.Z)(
                  {
                    root: [
                      "root",
                      t && "disabled",
                      n && "highlighted",
                      r && "selected",
                    ],
                  },
                  u,
                  {}
                );
              })(x),
              E = (0, c.Z)({
                elementType: M,
                externalSlotProps: g.root,
                externalForwardedProps: w,
                additionalProps: (0, r.Z)({}, k, { ref: S }),
                className: P.root,
                ownerState: x,
              });
            return (0, h.jsx)(M, (0, r.Z)({}, E, { children: n }));
          });
        var m = o.memo(p);
      },
      88078: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return R;
          },
        });
        var r = n(63366),
          a = n(87462),
          o = n(67294),
          i = n(90512),
          l = n(70917),
          d = n(94780),
          s = n(41796),
          u = n(90948),
          c = n(71657),
          h = n(1588),
          f = n(34867);
        function p(e) {
          return (0, f.ZP)("MuiSkeleton", e);
        }
        (0, h.Z)("MuiSkeleton", [
          "root",
          "text",
          "rectangular",
          "rounded",
          "circular",
          "pulse",
          "wave",
          "withChildren",
          "fitContent",
          "heightAuto",
        ]);
        var m = n(85893);
        let g = [
            "animation",
            "className",
            "component",
            "height",
            "style",
            "variant",
            "width",
          ],
          b = (e) => e,
          y,
          w,
          v,
          M,
          Z = (e) => {
            let {
              classes: t,
              variant: n,
              animation: r,
              hasChildren: a,
              width: o,
              height: i,
            } = e;
            return (0, d.Z)(
              {
                root: [
                  "root",
                  n,
                  r,
                  a && "withChildren",
                  a && !o && "fitContent",
                  a && !i && "heightAuto",
                ],
              },
              p,
              t
            );
          },
          C = (0, l.F4)(
            y ||
              (y = b`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)
          ),
          k = (0, l.F4)(
            w ||
              (w = b`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)
          ),
          _ = (0, u.ZP)("span", {
            name: "MuiSkeleton",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.root,
                t[n.variant],
                !1 !== n.animation && t[n.animation],
                n.hasChildren && t.withChildren,
                n.hasChildren && !n.width && t.fitContent,
                n.hasChildren && !n.height && t.heightAuto,
              ];
            },
          })(
            ({ theme: e, ownerState: t }) => {
              let n =
                  String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1] ||
                  "px",
                r = parseFloat(e.shape.borderRadius);
              return (0, a.Z)(
                {
                  display: "block",
                  backgroundColor: e.vars
                    ? e.vars.palette.Skeleton.bg
                    : (0, s.Fq)(
                        e.palette.text.primary,
                        "light" === e.palette.mode ? 0.11 : 0.13
                      ),
                  height: "1.2em",
                },
                "text" === t.variant && {
                  marginTop: 0,
                  marginBottom: 0,
                  height: "auto",
                  transformOrigin: "0 55%",
                  transform: "scale(1, 0.60)",
                  borderRadius: `${r}${n}/${
                    Math.round((r / 0.6) * 10) / 10
                  }${n}`,
                  "&:empty:before": { content: '"\\00a0"' },
                },
                "circular" === t.variant && { borderRadius: "50%" },
                "rounded" === t.variant && {
                  borderRadius: (e.vars || e).shape.borderRadius,
                },
                t.hasChildren && { "& > *": { visibility: "hidden" } },
                t.hasChildren && !t.width && { maxWidth: "fit-content" },
                t.hasChildren && !t.height && { height: "auto" }
              );
            },
            ({ ownerState: e }) =>
              "pulse" === e.animation &&
              (0, l.iv)(
                v ||
                  (v = b`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),
                C
              ),
            ({ ownerState: e, theme: t }) =>
              "wave" === e.animation &&
              (0, l.iv)(
                M ||
                  (M = b`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),
                k,
                (t.vars || t).palette.action.hover
              )
          ),
          x = o.forwardRef(function (e, t) {
            let n = (0, c.Z)({ props: e, name: "MuiSkeleton" }),
              {
                animation: o = "pulse",
                className: l,
                component: d = "span",
                height: s,
                style: u,
                variant: h = "text",
                width: f,
              } = n,
              p = (0, r.Z)(n, g),
              b = (0, a.Z)({}, n, {
                animation: o,
                component: d,
                variant: h,
                hasChildren: Boolean(p.children),
              }),
              y = Z(b);
            return (0,
            m.jsx)(_, (0, a.Z)({ as: d, ref: t, className: (0, i.Z)(y.root, l), ownerState: b }, p, { style: (0, a.Z)({ width: f, height: s }, u) }));
          });
        var R = x;
      },
      89609: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return d;
          },
        });
        var r = n(37078),
          a = n(61354),
          o = n(1588);
        let i = (0, o.Z)("MuiBox", ["root"]),
          l = (0, a.Z)({
            defaultClassName: i.root,
            generateClassName: r.Z.generate,
          });
        var d = l;
      },
      61730: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return c;
          },
        });
        var r,
          a = n(67294),
          o = n(73546),
          i = n(20539),
          l = n(34168);
        function d(e, t, n, r, i) {
          let [l, d] = a.useState(() =>
            i && n ? n(e).matches : r ? r(e).matches : t
          );
          return (
            (0, o.Z)(() => {
              let t = !0;
              if (!n) return;
              let r = n(e),
                a = () => {
                  t && d(r.matches);
                };
              return (
                a(),
                r.addListener(a),
                () => {
                  (t = !1), r.removeListener(a);
                }
              );
            }, [e, n]),
            l
          );
        }
        let s = (r || (r = n.t(a, 2))).useSyncExternalStore;
        function u(e, t, n, r, o) {
          let i = a.useCallback(() => t, [t]),
            l = a.useMemo(() => {
              if (o && n) return () => n(e).matches;
              if (null !== r) {
                let { matches: t } = r(e);
                return () => t;
              }
              return i;
            }, [i, e, r, o, n]),
            [d, u] = a.useMemo(() => {
              if (null === n) return [i, () => () => {}];
              let t = n(e);
              return [
                () => t.matches,
                (e) => (
                  t.addListener(e),
                  () => {
                    t.removeListener(e);
                  }
                ),
              ];
            }, [i, n, e]),
            c = s(u, d, l);
          return c;
        }
        function c(e, t = {}) {
          let n = (0, l.Z)(),
            r = "undefined" != typeof window && void 0 !== window.matchMedia,
            {
              defaultMatches: a = !1,
              matchMedia: o = r ? window.matchMedia : null,
              ssrMatchMedia: c = null,
              noSsr: h = !1,
            } = (0, i.Z)({ name: "MuiUseMediaQuery", props: t, theme: n }),
            f = "function" == typeof e ? e(n) : e;
          f = f.replace(/^@media( ?)/m, "");
          let p = (void 0 !== s ? u : d)(f, a, o, c, h);
          return p;
        }
      },
    },
  ]);
