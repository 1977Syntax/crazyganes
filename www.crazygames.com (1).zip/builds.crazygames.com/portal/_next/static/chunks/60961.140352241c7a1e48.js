!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "e9c6502c-4194-424c-9f5f-b107f61f44e1"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-e9c6502c-4194-424c-9f5f-b107f61f44e1"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [60961],
    {
      70150: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M12.002 4C11.4497 4 11.002 4.44772 11.002 5C11.002 5.55228 11.4497 6 12.002 6C12.5542 6 13.002 5.55228 13.002 5C13.002 4.44772 12.5542 4 12.002 4ZM9.00195 5C9.00195 3.34315 10.3451 2 12.002 2C13.6588 2 15.002 3.34315 15.002 5C15.002 6.30623 14.1671 7.41747 13.0019 7.8293V8.5828C13.4503 8.65773 13.8922 8.78342 14.319 8.95985L19.9492 11.2903L19.9517 11.2913C20.1346 11.3664 20.302 11.4725 20.4469 11.6042C20.7759 11.7679 21.002 12.1075 21.002 12.5V17.2268C21.0116 17.4774 20.9667 17.7272 20.8703 17.959C20.7087 18.348 20.4087 18.6633 20.0283 18.8442L20.0261 18.8452L14.5641 21.4252C13.763 21.8036 12.888 22 12.002 22C11.116 22 10.241 21.8037 9.43985 21.4252L3.97668 18.8446C3.66495 18.6969 3.40537 18.4581 3.23222 18.1597C3.06692 17.8749 2.98782 17.5485 3.00395 17.2203L3.00214 12.9411C3.00009 12.9005 2.99951 12.8596 3.00041 12.8187C3.00075 12.8032 3.00131 12.7877 3.00207 12.7723L3.00196 12.5004C3.00179 12.1104 3.22494 11.7724 3.55059 11.6074C3.69899 11.4719 3.87112 11.3632 4.05945 11.2874C4.06978 11.2832 4.08015 11.2792 4.09057 11.2754L9.68448 8.96002C10.1113 8.78359 10.5536 8.65773 11.0019 8.5828V7.82929C9.83675 7.41744 9.00195 6.30621 9.00195 5ZM5.00296 14.8665L5.0039 17.118L10.2941 19.6168C10.8281 19.8691 11.4114 20 12.002 20C12.5925 20 13.1758 19.8691 13.7098 19.6168L19.002 17.117V14.866L14.559 16.9346C13.7581 17.3069 12.8851 17.5001 12.0019 17.5001C11.1187 17.5001 10.2462 17.3071 9.44532 16.9348L5.00296 14.8665ZM10.4494 10.808C10.63 10.7333 10.8147 10.6722 11.0019 10.6247V13C11.0019 13.5523 11.4496 14 12.0019 14C12.5542 14 13.0019 13.5523 13.0019 13V10.6247C13.1892 10.6722 13.3743 10.7335 13.5549 10.8081L18.5438 12.8732L13.7153 15.1212C13.1786 15.3708 12.5938 15.5001 12.0019 15.5001C11.41 15.5001 10.8253 15.3708 10.2885 15.1212L5.46001 12.8732L10.4494 10.808Z",
            }),
          })
        );
        t.Z = s;
      },
      59411: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M15.6699 5.25759C15.2599 4.88759 14.6276 4.92005 14.2576 5.33007C13.8876 5.7401 13.92 6.37243 14.3301 6.74243L19.0483 11H3C2.44772 11 2 11.4477 2 12C2 12.5523 2.44772 13 3 13H19.0483L14.3301 17.2576C13.92 17.6276 13.8876 18.2599 14.2576 18.6699C14.6276 19.08 15.2599 19.1124 15.6699 18.7424L21.2109 13.7424C22.263 12.793 22.263 11.207 21.2109 10.2576L15.6699 5.25759Z",
            }),
          })
        );
        t.Z = s;
      },
      73274: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M10.0704 5C9.73601 5 9.42378 5.1671 9.23832 5.4453L8.42578 6.6641C7.86939 7.4987 6.93269 8 5.92963 8H5C4.44772 8 4 8.44772 4 9V18C4 18.5523 4.44772 19 5 19H19C19.5523 19 20 18.5523 20 18V9C20 8.44772 19.5523 8 19 8H18.0704C17.0673 8 16.1306 7.4987 15.5742 6.6641L14.7617 5.4453C14.5762 5.1671 14.264 5 13.9296 5H10.0704ZM7.57422 4.3359C8.13061 3.5013 9.06731 3 10.0704 3H13.9296C14.9327 3 15.8694 3.5013 16.4258 4.3359L17.2383 5.5547C17.4238 5.8329 17.736 6 18.0704 6H19C20.6569 6 22 7.34315 22 9V18C22 19.6569 20.6569 21 19 21H5C3.34315 21 2 19.6569 2 18V9C2 7.34315 3.34315 6 5 6H5.92963C6.26399 6 6.57622 5.8329 6.76168 5.5547L7.57422 4.3359ZM12 11C10.8954 11 10 11.8954 10 13C10 14.1046 10.8954 15 12 15C13.1046 15 14 14.1046 14 13C14 11.8954 13.1046 11 12 11ZM8 13C8 10.7909 9.79086 9 12 9C14.2091 9 16 10.7909 16 13C16 15.2091 14.2091 17 12 17C9.79086 17 8 15.2091 8 13Z",
            }),
          })
        );
        t.Z = s;
      },
      77557: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M20.5692 4.17784C21.0233 4.4922 21.1366 5.11516 20.8222 5.56924L11.8222 18.5692C11.6534 18.813 11.3851 18.9694 11.0898 18.996C10.7945 19.0226 10.5026 18.9168 10.2929 18.7071L4.29289 12.7071C3.90237 12.3166 3.90237 11.6834 4.29289 11.2929C4.68342 10.9024 5.31658 10.9024 5.70711 11.2929L10.8598 16.4457L19.1778 4.43082C19.4922 3.97674 20.1151 3.86347 20.5692 4.17784Z",
            }),
          })
        );
        t.Z = s;
      },
      24909: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M7.25759 2.33006C7.62758 1.92004 8.25992 1.88759 8.66994 2.25758L16.9814 9.75758C18.3395 10.9831 18.3395 13.0169 16.9814 14.2424L8.66994 21.7424C8.25992 22.1124 7.62758 22.08 7.25759 21.6699C6.88759 21.2599 6.92005 20.6276 7.33007 20.2576L15.6415 12.7576C16.1195 12.3263 16.1195 11.6737 15.6415 11.2424L7.33007 3.74242C6.92005 3.37242 6.88759 2.74009 7.25759 2.33006Z",
            }),
          })
        );
        t.Z = s;
      },
      8379: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M3 6.01527C3 4.35716 4.33599 3 6 3H14C15.664 3 17 4.35716 17 6.01527V7.03053H18C19.664 7.03053 21 8.3877 21 10.0458V18.1069C21 19.765 19.664 21.1221 18 21.1221H10C8.33599 21.1221 7 19.765 7 18.1069V17.0916H6C4.33599 17.0916 3 15.7344 3 14.0763V6.01527ZM9 18.1069C9 18.6748 9.45487 19.1221 10 19.1221H18C18.5451 19.1221 19 18.6748 19 18.1069V10.0458C19 9.4779 18.5451 9.03053 18 9.03053H10C9.45487 9.03053 9 9.4779 9 10.0458V18.1069ZM15 7.03053H10C8.33599 7.03053 7 8.3877 7 10.0458V15.0916H6C5.45487 15.0916 5 14.6442 5 14.0763V6.01527C5 5.44737 5.45487 5 6 5H14C14.5451 5 15 5.44737 15 6.01527V7.03053Z",
            }),
          })
        );
        t.Z = s;
      },
      48112: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 20 20",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M4.99935 10.0007C4.99935 10.9211 4.25316 11.6673 3.33268 11.6673C2.41221 11.6673 1.66602 10.9211 1.66602 10.0007C1.66602 9.08018 2.41221 8.33398 3.33268 8.33398C4.25316 8.33398 4.99935 9.08018 4.99935 10.0007ZM11.666 10.0007C11.666 10.9211 10.9198 11.6673 9.99935 11.6673C9.07887 11.6673 8.33268 10.9211 8.33268 10.0007C8.33268 9.08018 9.07887 8.33398 9.99935 8.33398C10.9198 8.33398 11.666 9.08018 11.666 10.0007ZM16.666 11.6673C17.5865 11.6673 18.3327 10.9211 18.3327 10.0007C18.3327 9.08018 17.5865 8.33398 16.666 8.33398C15.7455 8.33398 14.9993 9.08018 14.9993 10.0007C14.9993 10.9211 15.7455 11.6673 16.666 11.6673Z",
            }),
          })
        );
        t.Z = s;
      },
      60362: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M10 4C8.34315 4 7 5.34315 7 7C7 8.65685 8.34315 10 10 10C11.6569 10 13 8.65685 13 7C13 5.34315 11.6569 4 10 4ZM5 7C5 4.23858 7.23858 2 10 2C12.7614 2 15 4.23858 15 7C15 9.76142 12.7614 12 10 12C7.23858 12 5 9.76142 5 7ZM15.9181 19.9771C15.4451 17.1282 12.981 15 10 15C7.01897 15 4.55491 17.1282 4.08194 19.9771H15.9181ZM2 20.9771C2 16.5223 5.58876 13 10 13C14.4112 13 18 16.5223 18 20.9771C18 21.5294 17.5523 21.9771 17 21.9771H3C2.44772 21.9771 2 21.5294 2 20.9771ZM18.5 8C19.0523 8 19.5 8.44772 19.5 9V10.5H21C21.5523 10.5 22 10.9477 22 11.5C22 12.0523 21.5523 12.5 21 12.5H19.5V14C19.5 14.5523 19.0523 15 18.5 15C17.9477 15 17.5 14.5523 17.5 14V12.5H16C15.4477 12.5 15 12.0523 15 11.5C15 10.9477 15.4477 10.5 16 10.5H17.5V9C17.5 8.44772 17.9477 8 18.5 8Z",
            }),
          })
        );
        t.Z = s;
      },
      79862: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 20 20",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M5.00002 3.33332C4.07955 3.33332 3.33335 4.07952 3.33335 4.99999V15C3.33335 15.9205 4.07955 16.6667 5.00002 16.6667H15C15.9205 16.6667 16.6667 15.9205 16.6667 15V12.5C16.6667 12.0398 17.0398 11.6667 17.5 11.6667C17.9603 11.6667 18.3334 12.0398 18.3334 12.5V15C18.3334 16.8409 16.841 18.3333 15 18.3333H5.00002C3.15907 18.3333 1.66669 16.8409 1.66669 15V4.99999C1.66669 3.15904 3.15907 1.66666 5.00002 1.66666H7.50002C7.96026 1.66666 8.33335 2.03975 8.33335 2.49999C8.33335 2.96023 7.96026 3.33332 7.50002 3.33332H5.00002ZM16.6667 4.51185L8.50594 12.6726C8.18051 12.998 7.65287 12.998 7.32743 12.6726C7.00199 12.3472 7.00199 11.8195 7.32743 11.4941L15.4882 3.33332H12.5C12.0398 3.33332 11.6667 2.96023 11.6667 2.49999C11.6667 2.03975 12.0398 1.66666 12.5 1.66666H16.6667C17.5872 1.66666 18.3334 2.41285 18.3334 3.33332V7.49999C18.3334 7.96023 17.9603 8.33332 17.5 8.33332C17.0398 8.33332 16.6667 7.96023 16.6667 7.49999V4.51185Z",
            }),
          })
        );
        t.Z = s;
      },
      46828: function (e, t, n) {
        "use strict";
        var r = n(85893),
          i = n(67294),
          o = n(95914);
        let s = i.memo((e) =>
          (0, r.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("svg", {
              width: "20",
              height: "20",
              viewBox: "0 0 20 20",
              xmlns: "http://www.w3.org/2000/svg",
              children: (0, r.jsx)("path", {
                d: "M10.8336 6.70429V4.1657C10.8336 3.94495 10.9214 3.73325 11.0777 3.57716C11.2339 3.42106 11.4459 3.33337 11.6669 3.33337C11.8855 3.33429 12.095 3.42098 12.2502 3.57475L18.0836 9.40101C18.1617 9.47839 18.2237 9.57044 18.266 9.67187C18.3083 9.7733 18.3301 9.88209 18.3301 9.99196C18.3301 10.1018 18.3083 10.2106 18.266 10.3121C18.2237 10.4135 18.1617 10.5055 18.0836 10.5829L12.2502 16.4092C12.1333 16.5237 11.9851 16.6013 11.8242 16.6321C11.6633 16.663 11.4969 16.6459 11.3458 16.5828C11.1946 16.5198 11.0654 16.4136 10.9743 16.2776C10.8832 16.1416 10.8343 15.9818 10.8336 15.8182V13.238H10.1252C8.80865 13.2184 7.50354 13.4852 6.30052 14.0199C5.0975 14.5545 4.02538 15.3443 3.15858 16.3343C3.05412 16.4732 2.90876 16.5759 2.74288 16.6282C2.577 16.6804 2.39892 16.6795 2.23358 16.6256C2.06532 16.5689 1.91961 16.46 1.81767 16.3147C1.71574 16.1695 1.66292 15.9955 1.66691 15.8182C1.66691 8.22744 8.40025 6.92901 10.8336 6.70429ZM10.1252 11.5567C10.6826 11.555 11.2395 11.5911 11.7919 11.6649C11.9892 11.6948 12.1692 11.7944 12.2992 11.9456C12.4292 12.0969 12.5005 12.2896 12.5002 12.4889V13.8123L16.3169 9.99196L12.5002 6.1716V7.49499C12.5002 7.71574 12.4124 7.92744 12.2562 8.08353C12.0999 8.23962 11.8879 8.32732 11.6669 8.32732C10.9086 8.32732 4.90858 8.49378 3.60858 13.6792C5.4955 12.2896 7.78094 11.5453 10.1252 11.5567Z",
              }),
            }),
          })
        );
        t.Z = s;
      },
      91731: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return P;
          },
          e: function () {
            return k;
          },
        });
        var r = n(85893),
          i = n(66252),
          o = n(6388),
          s = n(67294),
          a = n(74040),
          l = n(89950),
          c = n(23180),
          d = n(58362),
          u = n(84275),
          h = n(92114),
          p = n(37899),
          x = n(19167),
          y = n(73359),
          f = n(46313),
          g = n(63922);
        let m = (e) => {
          let { game: t, gfSource: n } = e,
            { user: r, loadingUser: i } = s.useContext(a.S),
            { data: l } = (0, o.aM)(g.Qt, { skip: !r }),
            [u] = (0, y.t)(g.Qt),
            [h, p] = s.useState(!1),
            x = s.useRef(!1),
            { openedDrawer: m } = s.useContext(c.rf),
            { favourites: C } = s.useContext(d.Q),
            _ = C.some((e) => e.slug === t.slug);
          return (
            s.useEffect(() => {
              m &&
                ["signIn", "signUp", "signUpEmail"].includes(m.drawer) &&
                p(!0);
            }, [m]),
            s.useEffect(() => {
              h &&
                r &&
                !x.current &&
                ((x.current = !0),
                (async function () {
                  let e = await u();
                  if (!e.data) throw Error("Failed to query user");
                  let t = e.data.me,
                    i = {
                      username: `${t.username}`,
                      profilePictureUrl: `${f.Z.Instance.data.images}${t.profile.avatar}`,
                    };
                  n.window?.postMessage(
                    {
                      type: "userLoggedIn",
                      data: {
                        userId: r.uid,
                        userData: i,
                        email: r?.email || void 0,
                      },
                    },
                    "*"
                  );
                })());
            }, [r, n, u, h]),
            s.useEffect(() => {
              if (i) return;
              let e = l
                  ? {
                      username: `${l.me.username}`,
                      profilePictureUrl: `${f.Z.Instance.data.images}${l.me.profile.avatar}`,
                    }
                  : void 0,
                t = {
                  type: "userPortalInfoSync",
                  data: {
                    userId: r?.uid,
                    userData: e,
                    isFavouriteGame: _,
                    email: r?.email || void 0,
                  },
                };
              n.window?.postMessage(t, "*");
            }, [_, i, r, l, n]),
            null
          );
        };
        var C = n(32017);
        let _ = (e) => {
          let { theatreModeAvailable: t, gfSource: n } = e;
          return (
            s.useEffect(() => {
              t
                ? n.window?.postMessage("set-status-theatre-mode-enabled", "*")
                : n.window?.postMessage(
                    "set-status-theatre-mode-disabled",
                    "*"
                  );
            }, [t, n]),
            null
          );
        };
        var w = n(63306),
          v = n(380),
          j = n(13592);
        let B = (e) => {
          let { gfSource: t } = e,
            { services: n } = s.useContext(p.Z),
            r = n.crazyAnalyticsService;
          return (
            s.useEffect(() => {
              let e = async () => {
                let e = await r.analyticsInfo();
                t.window?.postMessage(
                  { type: "analyticsInfoGF", data: { analyticsInfo: e } },
                  "*"
                );
              };
              e();
            }, [r, t]),
            null
          );
        };
        var D = n(69395),
          z = n(42257),
          b = n(82702);
        let k = null,
          Z = (e) => {
            let { game: t, theatreModeAvailable: n } = e,
              { user: y, loadingUser: f } = s.useContext(a.S),
              { openDrawer: Z } = s.useContext(c.s9),
              { isDesktop: P } = s.useContext(z.Z),
              {
                favourites: S,
                addToFavourite: F,
                removeFromFavourite: L,
              } = s.useContext(d.Q),
              { services: M } = s.useContext(p.Z),
              { routeHelper: I } = s.useContext(w.Z),
              {
                setProgressIconStatus: E,
                resetGameInvites: R,
                setGameInviteLink: A,
                gameInviteLink: V,
              } = s.useContext(v.DN),
              { czyExpSkipPlayNow_CZY_13219_2: N } = s.useContext(D.T),
              { crazyRouterChange: H } = s.useContext(j.R),
              W = (0, i.x)(),
              { data: T } = (0, o.aM)(g.Qt, { skip: !y }),
              q = S.some((e) => e.slug === t.slug),
              [U, G] = s.useState(null),
              Y = M.experimentService,
              O = b.G9();
            return (s.useEffect(() => {
              let e = async (e) => {
                  let {
                    requestType: t,
                    rawGraphqlString: n,
                    variables: r,
                    fetchPolicy: i,
                    errorPolicy: o = "all",
                    callbackId: s,
                  } = e.data;
                  try {
                    let a = (0, u.Qc)(n);
                    if ("query" === t) {
                      let t = await W.query({
                          query: a,
                          variables: r,
                          fetchPolicy: i,
                          errorPolicy: o,
                        }),
                        n = {
                          resultData: t.data,
                          errors: t.errors,
                          networkStatus: t.networkStatus,
                          callbackId: s,
                        };
                      e.source?.postMessage(
                        { type: "forwardToUpGraphqlResponse", data: n },
                        "*"
                      );
                    } else if ("mutation" === t) {
                      let t = await W.mutate({
                          mutation: a,
                          fetchPolicy: "no-cache",
                          variables: r,
                          errorPolicy: o,
                          context: { queryDeduplication: !1 },
                        }),
                        n = {
                          resultData: t.data,
                          errors: t.errors,
                          callbackId: s,
                        };
                      e.source?.postMessage(
                        { type: "forwardToUpGraphqlResponse", data: n },
                        "*"
                      );
                    }
                  } catch (n) {
                    console.error("[UPGFConnector]", JSON.stringify(n));
                    let t = {
                      resultData: null,
                      errors: [n.message ? n.message : JSON.stringify(n)],
                      callbackId: s,
                    };
                    e.source?.postMessage(
                      { type: "forwardToUpGraphqlResponse", data: t },
                      "*"
                    );
                  }
                },
                r = (e) => {
                  let t = !!JSON.parse(x.Z.Instance.getItem(h.c) || "false"),
                    r = !!JSON.parse(x.Z.Instance.getItem(h.v) || "false"),
                    i = y?.email
                      ?.trim()
                      .toLowerCase()
                      .replace(/\+[^@]*@/g, "@");
                  e.source?.postMessage(
                    {
                      type: "gfInit",
                      data: {
                        userAccountAvailable: !0,
                        userExpected: t,
                        theatreModeAvailable: n,
                        wasUserLoggedIn: r,
                        email: i || void 0,
                        skipPrerollExp25:
                          P && void 0 !== N ? "enabled" === N : void 0,
                      },
                    },
                    "*"
                  ),
                    G({ window: e.source }),
                    (k = { window: e.source }),
                    (0, C.hO)("beforePlayNow");
                },
                i = async (n) => {
                  if (n.data && n.data.type === l.V)
                    switch (n.data.event) {
                      case "requestToFavouriteGame":
                        y
                          ? F({
                              id: t.id,
                              slug: t.slug,
                              name: t.slug,
                              cover: t.cover,
                              videos: t.videos,
                              status: t.status,
                              iosFriendly: !0,
                              androidFriendly: !0,
                              mobileFriendly: !0,
                              gameThumbLabels: [],
                            })
                          : Z("myGames-favourite");
                        break;
                      case "requestToUnFavouriteGame":
                        y ? L(t.id) : Z("myGames");
                        break;
                      case "forwardToUpGraphql":
                        await e(n);
                        break;
                      case "requestGfInit":
                        r(n);
                        break;
                      case "redirectToHomepage":
                        let i = I.homePageLink();
                        H(i.href, i.as);
                        break;
                      case "refreshGamePage":
                        window.location.reload();
                        break;
                      case "openProgressStatusDrawer":
                        E(n.data.progressIconStatus), Z("progressStatus");
                        break;
                      case "showInviteButton":
                        if (!y) return;
                        let o = n.data;
                        A(o.inviteUrl),
                          M.crazyAnalyticsService.gameInteractionEvent({
                            method: "join",
                            origin: "game",
                            action: "broadcast",
                            target: null,
                            targetStatus: null,
                            targetGameId: t.id,
                          });
                        break;
                      case "hideInviteButton":
                        if (!y || !V) return;
                        await O({
                          variables: { input: { joinUrl: V, gameId: t.id } },
                        }),
                          R(),
                          A(null),
                          M.crazyAnalyticsService.gameInteractionEvent({
                            method: "join",
                            origin: "game",
                            action: "expire",
                            target: null,
                            targetStatus: null,
                            targetGameId: t.id,
                          });
                        break;
                      case "showFriendsDrawer":
                        y ? Z("friends") : Z("friendsGuest");
                        break;
                      case "showEditProfileDrawer":
                        Z("editProfile");
                        break;
                      case "showLoginDrawer":
                        Z("signIn");
                    }
                };
              return (
                window.addEventListener("message", i),
                function () {
                  window.removeEventListener("message", i);
                }
              );
            }, [H, W, M, y, n, F, L, Z, t, q, T, f, I, Y, E, R, A, N, P, V, O]),
            U)
              ? (0, r.jsxs)(r.Fragment, {
                  children: [
                    (0, r.jsx)(_, { gfSource: U, theatreModeAvailable: n }),
                    (0, r.jsx)(m, { game: t, gfSource: U }),
                    (0, r.jsx)(B, { gfSource: U }),
                  ],
                })
              : null;
          };
        var P = Z;
      },
      68888: function (e, t, n) {
        "use strict";
        var r = n(67294),
          i = n(37899),
          o = n(92512),
          s = n(63306),
          a = n(13592),
          l = n(82702);
        let c = () => {
          let { routeHelper: e } = r.useContext(s.Z),
            { respondToNotification: t } = r.useContext(o.c),
            { crazyAnalyticsService: n } = r.useContext(i.Z).services,
            { crazyRouterChange: c } = r.useContext(a.R),
            d = r.useCallback((e) => window.location.href === e, []),
            u = l.sb(),
            h = r.useCallback(
              (r, i) => {
                let o = u({
                  variables: { input: { id: r.id, status: "accepted" } },
                });
                t(r.id, "accepted");
                let s =
                  e.localizedJoinUrl(r.game.gameSlug, r.game.joinUrl) ||
                  r.game.joinUrl;
                n.gameInteractionEvent({
                  method: "invite",
                  origin: "popupNotification",
                  action: "accept",
                  target: r.fromUser.id,
                  targetStatus: null,
                  targetGameId: r.game.gameId,
                }),
                  o.finally(() => {
                    c(s);
                  }),
                  d(s) && i?.();
              },
              [d, u, n, t, e, c]
            ),
            p = r.useCallback(
              (e, r) => {
                u({ variables: { input: { id: e.id, status: "declined" } } }),
                  t(e.id, "declined"),
                  n.gameInteractionEvent({
                    method: "invite",
                    origin: "popupNotification",
                    action: "decline",
                    target: e.fromUser.id,
                    targetStatus: null,
                    targetGameId: e.game.gameId,
                  }),
                  r?.();
              },
              [n, t, u]
            );
          return { onAcceptClick: h, onDeclineClick: p };
        };
        t.Z = c;
      },
      10210: function (e, t, n) {
        "use strict";
        n.d(t, {
          P7: function () {
            return d;
          },
          bw: function () {
            return c;
          },
          jj: function () {
            return l;
          },
          qM: function () {
            return s;
          },
          sX: function () {
            return u;
          },
          zC: function () {
            return a;
          },
        });
        var r = n(90948),
          i = n(69661),
          o = n(3411);
        let s = (0, r.ZP)("div")(() => ({
            fontWeight: 800,
            fontSize: 16,
            color: o.D.white[100],
          })),
          a = (0, r.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              background: o.D.black[60],
              borderRadius: 16,
              padding: t(2),
            };
          }),
          l = (0, r.ZP)("span")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginLeft: t(1.5),
              color: o.D.white[60],
              fontSize: 14,
              fontWeight: 700,
            };
          }),
          c = (0, r.ZP)(i.Z)((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginRight: t(1.5),
              marginLeft: 2,
              height: 40,
              width: 40,
              borderWidth: 1,
              backgroundColor: o.D.black[100],
              borderColor: o.D.black[100],
              borderStyle: "solid",
            };
          }),
          d = (0, r.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: t(1, 2),
              "& svg.dotsHori": {
                color: o.D.white[10],
                "&:hover": { color: o.D.white[30] },
              },
              "& button:disabled": { color: o.D.white[30] },
              "&:hover": { background: o.D.black[70], cursor: "pointer" },
            };
          }),
          u = (0, r.ZP)("div")({
            position: "absolute",
            width: "calc(100% - 32px)",
            height: "calc(100% - 145px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            top: 130,
          });
      },
      11765: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            useBirthdayFormatted: function () {
              return y;
            },
          });
        var r = n(85893),
          i = n(67294),
          o = n(94745),
          s = n(59319),
          a = n(42298),
          l = n(32079),
          c = n(15318),
          d = n.n(c),
          u = n(50720),
          h = n(88844),
          p = n(85812),
          x = n.n(p);
        let y = (e) => {
            if (!e) return "Not specified";
            let t = new Date(e);
            return t
              ? t.toLocaleDateString(void 0, {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })
              : null;
          },
          f = (e) => {
            let {
                readOnly: t,
                value: n,
                onChange: c,
                hideCalendarButton: p,
              } = e,
              f = i.useMemo(() => (n ? new Date(n) : null), [n]),
              g = (0, o.mV)(),
              m = (
                p ? [x().datePicker, x().hideCalendarButton] : [x().datePicker]
              ).join(" "),
              C = i.useMemo(
                () =>
                  (function () {
                    let e = new Date(1337, 9, 5),
                      t = e.toLocaleDateString(void 0, {
                        year: "numeric",
                        month: "numeric",
                        day: "numeric",
                      }),
                      n = t.indexOf("1337"),
                      r = t.indexOf("10"),
                      i = t.indexOf("5"),
                      o = t.replace(/\d/g, "")[0];
                    return i < r && r < n
                      ? `dd${o}MM${o}yyyy`
                      : r < i && i < n
                      ? `M${o}dd${o}yyyy`
                      : `yyyy${o}MM${o}dd`;
                  })(),
                []
              ),
              _ = new Date(),
              w = (0, s.Z)(new Date(), 200),
              v = y(n);
            return (0, r.jsx)(u._, {
              dateAdapter: h.H,
              children: (0, r.jsx)(l.M, {
                value: f,
                onChange: (e) => {
                  if (c && e) {
                    let t = (0, a.Z)(e, "yyyy-MM-dd");
                    c(t);
                  }
                },
                format: C,
                className: m,
                maxDate: _,
                minDate: w,
                label: g._({ id: "common.upDrawer.editProfile.birthday" }),
                disableFuture: !0,
                disableHighlightToday: !0,
                closeOnSelect: !0,
                views: ["year", "month", "day"],
                openTo: "year",
                slotProps: {
                  field: { clearable: !0, onClear: () => c?.("") },
                  dialog: {
                    sx: {
                      ".MuiPaper-root": {
                        backgroundColor: "var(--black-50)",
                        color: "var(--white)",
                      },
                      ".MuiPaper-root *": { fontFamily: d().style.fontFamily },
                    },
                  },
                  popper: {
                    sx: {
                      ".MuiPickersLayout-root ": {
                        backgroundImage: "none !important",
                        backgroundColor: "var(--black-50)",
                      },
                      ".MuiPaper-root *": { fontFamily: d().style.fontFamily },
                    },
                  },
                  textField: t ? { inputProps: { value: v } } : void 0,
                },
              }),
            });
          };
        t.default = f;
      },
      60961: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return nk;
            },
          });
        var r = n(85893),
          i = n(67294),
          o = n(5152),
          s = n.n(o),
          a = n(2734),
          l = n(69661),
          c = n(21519),
          d = n(54509),
          u = n(94745),
          h = n(74040),
          p = n(23180),
          x = n(75007),
          y = n(99306),
          f = n(3411),
          g = n(95914);
        let m = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: (0, r.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M9.35285 4.08139C10.0266 1.3062 13.9734 1.3062 14.6471 4.08139C14.7628 4.5579 15.3088 4.78402 15.7275 4.52888C18.1662 3.04293 20.9571 5.83376 19.4711 8.27251C19.216 8.69125 19.4421 9.23717 19.9186 9.35285C22.6938 10.0266 22.6938 13.9734 19.9186 14.6471C19.4421 14.7628 19.216 15.3088 19.4711 15.7275C20.9571 18.1662 18.1662 20.9571 15.7275 19.4711C15.3088 19.216 14.7628 19.4421 14.6471 19.9186C13.9734 22.6938 10.0266 22.6938 9.35285 19.9186C9.23717 19.4421 8.69125 19.216 8.27252 19.4711C5.83376 20.9571 3.04293 18.1662 4.52889 15.7275C4.78402 15.3088 4.5579 14.7628 4.08139 14.6471C1.3062 13.9734 1.3062 10.0266 4.08139 9.35285C4.5579 9.23717 4.78402 8.69125 4.52888 8.27251C3.04293 5.83376 5.83376 3.04293 8.27252 4.52888C8.69125 4.78402 9.23717 4.55789 9.35285 4.08139ZM12.7036 4.55323C12.5245 3.81559 11.4755 3.81559 11.2964 4.55322C10.8612 6.34596 8.80726 7.19673 7.23186 6.23681C6.58365 5.84185 5.84185 6.58364 6.23681 7.23185C7.19673 8.80726 6.34596 10.8612 4.55322 11.2964C3.81559 11.4755 3.81559 12.5245 4.55323 12.7036C6.34596 13.1388 7.19673 15.1927 6.23682 16.7681C5.84186 17.4164 6.58365 18.1581 7.23186 17.7632C8.80726 16.8033 10.8612 17.654 11.2964 19.4468C11.4755 20.1844 12.5245 20.1844 12.7036 19.4468C13.1388 17.654 15.1927 16.8033 16.7681 17.7632C17.4164 18.1581 18.1581 17.4164 17.7632 16.7681C16.8033 15.1927 17.654 13.1388 19.4468 12.7036C20.1844 12.5245 20.1844 11.4755 19.4468 11.2964C17.654 10.8612 16.8033 8.80726 17.7632 7.23185C18.1581 6.58364 17.4164 5.84185 16.7681 6.23682C15.1927 7.19673 13.1388 6.34596 12.7036 4.55323ZM12 10C10.8954 10 10 10.8954 10 12C10 13.1046 10.8954 14 12 14C13.1046 14 14 13.1046 14 12C14 10.8954 13.1046 10 12 10ZM8 12C8 9.79086 9.79086 8 12 8C14.2091 8 16 9.79086 16 12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12Z",
              }),
            })
          ),
          C = i.memo((e) =>
            (0, r.jsxs)(g.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: [
                (0, r.jsx)("path", {
                  fillRule: "evenodd",
                  clipRule: "evenodd",
                  d: "M18.4356 6.88962L19.2473 5.11398C20.3188 5.60382 21.0195 6.69122 20.9922 7.89378C20.7358 19.1879 14.1232 22 12 22C9.87674 22 3.26418 19.1879 3.00779 7.89378C2.98049 6.69121 3.6812 5.60382 4.75271 5.11398L5.58423 6.93293C5.2283 7.09564 4.99839 7.45712 5.00727 7.84839C5.24327 18.244 11.1425 20 12 20C12.8575 20 18.7567 18.244 18.9927 7.84839C19.0016 7.45712 18.7717 7.09564 18.4158 6.93293L12.4158 4.19007C12.1517 4.06937 11.8483 4.06937 11.5842 4.19007L5.58423 6.93293L4.75271 5.11398L10.7527 2.37112C11.5448 2.00902 12.4552 2.00902 13.2473 2.37113L19.2473 5.11398L18.4356 6.88962Z",
                }),
                (0, r.jsx)("path", {
                  d: "M11 11C11 10.4477 11.4477 10 12 10C12.5523 10 13 10.4477 13 11V16C13 16.5523 12.5523 17 12 17C11.4477 17 11 16.5523 11 16V11Z",
                }),
                (0, r.jsx)("path", {
                  d: "M11 8C11 7.44772 11.4477 7 12 7C12.5523 7 13 7.44772 13 8C13 8.55228 12.5523 9 12 9C11.4477 9 11 8.55228 11 8Z",
                }),
              ],
            })
          ),
          _ = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: (0, r.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M6 5C4.89543 5 4 5.89543 4 7V17C4 18.1046 4.89543 19 6 19H10C11.1046 19 12 18.1046 12 17V16C12 15.4477 12.4477 15 13 15C13.5523 15 14 15.4477 14 16V17C14 19.2091 12.2091 21 10 21H6C3.79086 21 2 19.2091 2 17V7C2 4.79086 3.79086 3 6 3H10C12.2091 3 14 4.79086 14 7V8C14 8.55228 13.5523 9 13 9C12.4477 9 12 8.55228 12 8V7C12 5.89543 11.1046 5 10 5H6ZM16.2929 7.29289C16.6834 6.90237 17.3166 6.90237 17.7071 7.29289L21.7071 11.2929C22.0976 11.6834 22.0976 12.3166 21.7071 12.7071L17.7071 16.7071C17.3166 17.0976 16.6834 17.0976 16.2929 16.7071C15.9024 16.3166 15.9024 15.6834 16.2929 15.2929L18.5858 13L7 13C6.44772 13 6 12.5523 6 12C6 11.4477 6.44772 11 7 11L18.5858 11L16.2929 8.70711C15.9024 8.31658 15.9024 7.68342 16.2929 7.29289Z",
              }),
            })
          );
        var w = n(25827),
          v = n(90948),
          j = n(31601),
          B = n(32350);
        let D = (0, v.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              gap: 10,
              marginTop: t(3),
              marginBottom: t(2.5),
            };
          }),
          z = (0, v.ZP)(j.Sn)(() => ({
            userSelect: "none",
            "& svg": { color: f.D.white[10] },
            padding: 0,
            fontWeight: 400,
            height: 22,
          })),
          b = (0, v.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginTop: t(1.25),
              backgroundColor: "#E70D5C33",
              padding: `${t(1.25)} ${t(2.5)}`,
              fontWeight: 700,
              fontSize: "12px",
              color: f.D.alert[60],
              fontFamily: B.I8,
              textAlign: "center",
            };
          }),
          k = (0, v.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              gap: 10,
              marginTop: t(2.5),
              marginBottom: t(2.5),
              paddingLeft: t(3.5),
            };
          }),
          Z = (0, v.ZP)(j.Sn)(() => ({
            "& svg": { color: f.D.white[10] },
            padding: 0,
            fontWeight: 400,
            height: 22,
          }));
        var P = n(63306),
          S = n(54265);
        let F = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: (0, r.jsx)("path", {
                d: "M11 4C8.79086 4 7 5.79086 7 8C7 8.30288 7.03348 8.59674 7.09656 8.87852C7.21716 9.41729 6.8783 9.95187 6.33958 10.0727C5.00015 10.3732 4 11.571 4 13C4 13.8705 4.36934 14.7016 4.96373 15.2883C5.35677 15.6763 5.36087 16.3095 4.97288 16.7025C4.5849 17.0956 3.95174 17.0997 3.5587 16.7117C2.60038 15.7657 2 14.4285 2 13C2 10.9436 3.24073 9.1787 5.01385 8.41034C5.00466 8.27465 5 8.13781 5 8C5 4.68629 7.68629 2 11 2C13.6277 2 15.8592 3.68831 16.6719 6.03894C19.6341 6.38143 22 8.94255 22 12C22 13.7179 21.2754 15.4723 20.1092 16.6913C19.7274 17.0904 19.0944 17.1044 18.6954 16.7226C18.2963 16.3408 18.2823 15.7078 18.6641 15.3087C19.4817 14.4541 20 13.192 20 12C20 9.82403 18.1682 8.00178 15.9992 8.00004C15.9728 8.00002 15.9463 8.00027 15.9198 8.00079C15.4368 8.01024 15.0161 7.67312 14.9201 7.19971C14.5499 5.37395 12.9343 4 11 4ZM12 10C12.5523 10 13 10.4477 13 11V18.5858L14.2929 17.2929C14.6834 16.9024 15.3166 16.9024 15.7071 17.2929C16.0976 17.6834 16.0976 18.3166 15.7071 18.7071L12.7071 21.7071C12.3166 22.0976 11.6834 22.0976 11.2929 21.7071L8.29289 18.7071C7.90237 18.3166 7.90237 17.6834 8.29289 17.2929C8.68342 16.9024 9.31658 16.9024 9.70711 17.2929L11 18.5858V11C11 10.4477 11.4477 10 12 10Z",
              }),
            })
          ),
          L = (0, v.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              gap: 10,
              marginTop: t(2.5),
              marginBottom: t(2.5),
              paddingLeft: t(3.5),
              paddingRight: t(3.5),
            };
          }),
          M = (0, v.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginTop: t(0.5),
              marginBottom: t(0.5),
              display: "flex",
              flexWrap: "wrap",
              width: "260px",
              "& a": {
                width: "130px",
                overflow: "hidden",
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
              },
            };
          });
        var I = n(76717);
        let E = (0, v.ZP)("span")({
          color: f.D.white[30],
          textDecoration: "none",
          cursor: "pointer",
          marginBottom: 2,
          marginTop: 2,
          "&:hover": { opacity: 0.8 },
          overflow: "hidden",
          textOverflow: "ellipsis",
        });
        var R = n(96714),
          A = n(69626),
          V = n(2978);
        let N = () => {
          let { routeHelper: e } = i.useContext(P.Z),
            { showPreferences: t, showDoNotSell: n } = i.useContext(R.s),
            o = (e) => {
              let t = (0, A.a)();
              e.preventDefault(), t.userDoNotSell();
            },
            s = (e) => {
              let t = (0, A.a)();
              e.preventDefault(), t.showPreferences();
            },
            a = [
              {
                labelId: "common.menu.about",
                linkData: e.aboutPageLink(),
                external: !0,
              },
              {
                labelId: "common.menu.kids",
                linkData: e.kidsPageLink(),
                external: !0,
              },
              {
                labelId: "common.menu.termsAndConditions",
                linkData: e.termsAndConditionsPageLink(),
                external: !1,
              },
              {
                labelId: "common.menu.jobs",
                linkData: e.jobsPageLink(),
                external: !0,
              },
              {
                labelId: "common.menu.privacy",
                linkData: e.privacyPolicyPageLink(),
                external: !1,
              },
              {
                labelId: "common.menu.informationForParents",
                linkData: e.informationForParentsPageLink(),
                external: !1,
              },
              {
                labelId: "common.menu.developers",
                linkData: e.developersPageLink(),
                external: !0,
              },
              {
                labelId: "common.menu.allGames",
                linkData: e.allGamesPageLink(),
                external: !1,
              },
            ],
            l = a.filter((e) => {
              let { linkData: t } = e;
              return !!t;
            });
          return (0, r.jsxs)(r.Fragment, {
            children: [
              l.map((e) =>
                (0, r.jsx)(
                  V.Z,
                  {
                    ...e.linkData,
                    target: e.external ? "_blank" : void 0,
                    rel: e.external ? "external nofollow" : void 0,
                    children: (0, r.jsx)(E, {
                      children: (0, r.jsx)(u.cC, { id: e.labelId }),
                    }),
                  },
                  e.labelId
                )
              ),
              t &&
                (0, r.jsx)(E, {
                  onClick: s,
                  children: (0, r.jsx)(u.cC, {
                    id: "common.menu.privacyPreferences",
                  }),
                }),
              n &&
                (0, r.jsx)(E, {
                  onClick: o,
                  children: (0, r.jsx)(u.cC, { id: "common.menu.doNotSell" }),
                }),
            ],
          });
        };
        var H = n(33759);
        let W = () =>
            (0, r.jsxs)(L, {
              children: [
                (0, r.jsx)(I.Z, {}),
                (0, r.jsx)(M, { children: (0, r.jsx)(N, {}) }),
                (0, r.jsx)("div", {
                  style: { display: "flex" },
                  children: (0, r.jsx)(H.Z, {}),
                }),
              ],
            }),
          T = () => {
            let { routeHelper: e } = i.useContext(P.Z),
              { openDrawer: t } = i.useContext(p.s9),
              n = e.pwaInstallLink();
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsxs)(k, {
                  children: [
                    (0, r.jsxs)(Z, {
                      color: "white",
                      onClick: () => t("mainFeedback"),
                      children: [
                        (0, r.jsx)(S.Z, {}),
                        (0, r.jsx)(u.cC, {
                          id: "common.upDrawer.profile.support",
                        }),
                      ],
                    }),
                    (0, r.jsx)(V.Z, {
                      href: n.href,
                      as: n.as,
                      children: (0, r.jsxs)(Z, {
                        color: "white",
                        children: [
                          (0, r.jsx)(F, {}),
                          (0, r.jsx)(u.cC, {
                            id: "common.upDrawer.profile.pwaInstall",
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
                (0, r.jsx)(c.Z, { style: { borderColor: f.D.black[50] } }),
                (0, r.jsx)(W, {}),
              ],
            });
          };
        var q = n(83514),
          U = n(37899),
          G = n(46828),
          Y = n(82702),
          O = n(24909),
          J = n(7854),
          Q = n.n(J);
        let $ = () => {
            let e = Y.xJ();
            if (!e) return 100;
            let t = [
                e?.profile?.avatar,
                e?.profile?.cover,
                e?.profile?.country,
                e?.profile?.gender,
                e?.profile?.birthday,
              ],
              n = t.filter((e) => e).length;
            return (n / t.length) * 100;
          },
          K = i.memo((e) => {
            let { progress: t } = e,
              { openDrawer: n } = i.useContext(p.s9),
              o = i.useCallback(() => {
                n("editProfile");
              }, [n]);
            return (0, r.jsxs)("div", {
              className: Q().root,
              onClick: o,
              children: [
                (0, r.jsxs)("div", {
                  className: Q().row,
                  children: [
                    (0, r.jsx)(u.cC, {
                      id: "common.upDrawer.profileProgress",
                      values: { number: t },
                    }),
                    (0, r.jsxs)("a", {
                      className: Q().completeNow,
                      children: [
                        (0, r.jsx)(u.cC, { id: "common.upDrawer.completeNow" }),
                        (0, r.jsx)(O.Z, { className: Q().chevronRight }),
                      ],
                    }),
                  ],
                }),
                (0, r.jsx)("progress", {
                  className: Q().progress,
                  value: t,
                  max: 100,
                }),
              ],
            });
          });
        var X = n(88296),
          ee = n(63105),
          et = n.n(ee);
        let en = () => {
          let { openDrawer: e } = i.useContext(p.s9),
            { pageUrlHelper: t } = i.useContext(q.t),
            { logout: n } = i.useContext(d.V),
            { user: o } = i.useContext(h.S),
            s = i.useContext(P.Z).routeHelper,
            { crazyAnalyticsService: g } = i.useContext(U.Z).services,
            v = (0, a.Z)(),
            j = Y.xJ(),
            B = j?.profile.avatar,
            k = $(),
            Z = !!j && t.isProfilePageWithUsername(j.username),
            F = () => {
              e(null), g.resetCzyId(), n();
            },
            L = () => {
              Z && e(null);
            };
          return (0, r.jsxs)(r.Fragment, {
            children: [
              (0, r.jsx)(w.Z, {}),
              (0, r.jsxs)("div", {
                className: et().header,
                children: [
                  (0, r.jsx)("div", {
                    className: et().avatarContainer,
                    children:
                      B &&
                      (0, r.jsx)(l.Z, {
                        src: (0, x.ZP)(B, { width: 60, height: 60 }),
                        sx: {
                          width: 60,
                          height: 60,
                          border: "3px solid #FFFFFF",
                        },
                      }),
                  }),
                  j?.username &&
                    (0, r.jsx)("div", {
                      style: {
                        fontSize: 20,
                        fontWeight: 800,
                        lineHeight: "27px",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        userSelect: "none",
                      },
                      children: (0, r.jsxs)(V.Z, {
                        href: s.profilePageLink(j?.username).as,
                        onClick: L,
                        children: ["@", j?.username],
                      }),
                    }),
                  o?.email &&
                    (0, r.jsx)("div", {
                      style: {
                        color: f.D.white[100],
                        lineHeight: "16px",
                        marginBottom: v.spacing(1),
                      },
                      children: o.email,
                    }),
                  (0, r.jsx)(V.Z, {
                    onClick: (e) => {
                      j?.username || (e.preventDefault(), e.stopPropagation());
                    },
                    href: s.profilePageLink(j?.username || "").as,
                    style: {
                      width: "100%",
                      display: "flex",
                      justifyContent: "center",
                    },
                    children: (0, r.jsxs)(X.Z, {
                      variant: "contained",
                      onClick: L,
                      color: "purple",
                      className: et().button,
                      height: 34,
                      children: [
                        (0, r.jsx)(y.Z, {}),
                        (0, r.jsx)(u.cC, {
                          id: "common.upDrawer.profile.myProfile",
                        }),
                      ],
                    }),
                  }),
                  (0, r.jsxs)(X.Z, {
                    onClick: () =>
                      e("shareProfile", {
                        isExiting: !1,
                        returnToDrawer: "main",
                      }),
                    variant: "contained",
                    color: "grey",
                    className: et().button,
                    height: 34,
                    children: [
                      (0, r.jsx)(G.Z, {}),
                      (0, r.jsx)(u.cC, { id: "common.upDrawer.profile.share" }),
                    ],
                  }),
                  (0, r.jsxs)("div", {
                    className: et().messages,
                    children: [
                      j?.strike &&
                        j?.strike.isStriked &&
                        j?.strike.strikeEndDate &&
                        (0, r.jsx)(b, {
                          style: { marginBottom: 0 },
                          children: (0, r.jsx)(u.cC, {
                            id: "common.upDrawer.strikeMessage",
                            values: {
                              strikeExpiryDate: (function (e) {
                                let t = new Date(e + " UTC"),
                                  n = t.getFullYear(),
                                  r = String(t.getMonth() + 1).padStart(2, "0"),
                                  i = String(t.getDate()).padStart(2, "0");
                                return `${n}-${r}-${i}`;
                              })(j?.strike.strikeEndDate),
                            },
                          }),
                        }),
                      j && k < 100 && (0, r.jsx)(K, { progress: k }),
                    ],
                  }),
                ],
              }),
              (0, r.jsx)(c.Z, { style: { borderColor: f.D.black[50] } }),
              (0, r.jsx)("div", {
                style: {
                  display: "flex",
                  flexDirection: "column",
                  paddingLeft: v.spacing(3.5),
                  alignItems: "flex-start",
                },
                children: (0, r.jsxs)(D, {
                  children: [
                    (0, r.jsxs)(z, {
                      color: "white",
                      onClick: () => e("notificationPreferences"),
                      children: [
                        (0, r.jsx)(S.Z, {}),
                        (0, r.jsx)(u.cC, {
                          id: "friends.upDrawer.profile.notificationPreferences",
                        }),
                      ],
                    }),
                    (0, r.jsxs)(z, {
                      color: "white",
                      onClick: () => e("privacyPreferences"),
                      children: [
                        (0, r.jsx)(C, {}),
                        (0, r.jsx)(u.cC, {
                          id: "friends.upDrawer.profile.privacyPreferences",
                        }),
                      ],
                    }),
                    (0, r.jsxs)(z, {
                      color: "white",
                      onClick: () => e("settings"),
                      children: [
                        (0, r.jsx)(m, {}),
                        (0, r.jsx)(u.cC, {
                          id: "common.upDrawer.profile.settings",
                        }),
                      ],
                    }),
                    (0, r.jsxs)(z, {
                      color: "white",
                      onClick: F,
                      children: [
                        (0, r.jsx)(_, {}),
                        (0, r.jsx)(u.cC, {
                          id: "common.upDrawer.profile.logout",
                        }),
                      ],
                    }),
                  ],
                }),
              }),
              (0, r.jsx)(c.Z, { style: { borderColor: f.D.black[50] } }),
              (0, r.jsx)(T, {}),
            ],
          });
        };
        var er = n(80822),
          ei = n(79495),
          eo = n(42257),
          es = n(59411),
          ea = n(13264);
        let el = (0, ea.Z)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              padding: t(2, 0.5),
              "& svg": { color: f.D.white[10] },
              "&:hover": { cursor: "pointer" },
            };
          }),
          ec = (0, ea.Z)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return { fontWeight: 700, fontSize: 16, marginTop: t() };
          }),
          ed = (e) => {
            let { label: t, data: n, action: i } = e;
            return (0, r.jsxs)(el, {
              onClick: i,
              children: [
                (0, r.jsx)("div", {
                  style: { color: f.D.white[20] },
                  children: t,
                }),
                (0, r.jsxs)("div", {
                  style: { display: "flex", justifyContent: "space-between" },
                  children: [
                    (0, r.jsx)(ec, { children: n }),
                    (0, r.jsx)(j.Qh, {
                      color: "white",
                      height: 40,
                      children: (0, r.jsx)(es.Z, {}),
                    }),
                  ],
                }),
              ],
            });
          },
          eu = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { i18n: t } = (0, u.mV)(),
              { user: n } = i.useContext(h.S),
              o = n?.providerData[0]?.providerId === "password",
              { isDesktop: s } = i.useContext(eo.Z);
            return (0, r.jsx)(ei.Z, {
              onBack: () => {
                e("main", { isExiting: !0 });
              },
              title: t._({ id: "common.upDrawer.settings" }),
              children: (0, r.jsxs)(er.Z, {
                sx: s ? void 0 : { p: 2 },
                children: [
                  o &&
                    (0, r.jsxs)(r.Fragment, {
                      children: [
                        (0, r.jsx)(ed, {
                          label: t._({ id: "common.upDrawer.editEmail.label" }),
                          data: n.email ? n.email : "",
                          action: () => {
                            e("editEmail");
                          },
                        }),
                        (0, r.jsx)(c.Z, {}),
                        (0, r.jsx)(ed, {
                          label: t._({
                            id: "common.upDrawer.editPassword.label",
                          }),
                          data: t._({
                            id: "common.upDrawer.editPassword.subtitle",
                          }),
                          action: () => {
                            e("editPassword");
                          },
                        }),
                        (0, r.jsx)(c.Z, {}),
                      ],
                    }),
                  (0, r.jsx)(ed, {
                    label: t._({ id: "common.upDrawer.deleteAccount.label" }),
                    data: t._({ id: "common.upDrawer.deleteAccount.subtitle" }),
                    action: () => {
                      e("deleteAccount");
                    },
                  }),
                  (0, r.jsx)(c.Z, {}),
                ],
              }),
            });
          };
        var eh = n(89555);
        let ep = (0, v.ZP)("div", { shouldForwardProp: (e) => "type" !== e })(
            (e) => {
              let {
                theme: { spacing: t, dimensions: n },
                type: r,
              } = e;
              return {
                width:
                  "avatar" === r
                    ? n.avatarSelector.avatarWidth
                    : n.profileCoverSelector.coverWidth,
                height:
                  "avatar" === r
                    ? n.avatarSelector.avatarHeight
                    : n.profileCoverSelector.coverHeight,
                backgroundColor: "rgba(255,255,255,0.07)",
                margin: t(),
                overflow: "hidden",
                borderRadius: `calc(${t()} + 2px)`,
                "&:hover": { opacity: 0.8, cursor: "pointer" },
              };
            }
          ),
          ex = (0, v.ZP)("span", {
            shouldForwardProp: (e) => "isActive" !== e && "type" !== e,
          })((e) => {
            let {
              theme: { spacing: t, dimensions: n },
              isActive: r,
              type: i,
            } = e;
            return {
              width:
                "avatar" === i
                  ? n.avatarSelector.avatarWidth
                  : n.profileCoverSelector.coverWidth,
              height:
                "avatar" === i
                  ? n.avatarSelector.avatarHeight
                  : n.profileCoverSelector.coverHeight,
              borderWidth: 3,
              borderStyle: "solid",
              borderColor: "#4AF0A7",
              position: "absolute",
              borderRadius: t(),
              display: "none",
              ...(r && { display: "block" }),
            };
          }),
          ey = (0, v.ZP)("span")(() => ({
            width: 30,
            height: 30,
            position: "absolute",
            right: -3,
            top: -3,
            background: "#4AF0A7",
            borderRadius: "0px 8px 0px 18px",
          })),
          ef = (0, v.ZP)("img")(() => ({
            objectFit: "cover",
            height: "100%",
            width: "100%",
          }));
        var eg = n(77557),
          em = n(4978);
        let eC = () => {
            let [e, t] = i.useState([]);
            return (
              i.useEffect(() => {
                if (e.length > 0) return;
                let r = !0;
                return (
                  n
                    .e(46629)
                    .then(n.t.bind(n, 46629, 19))
                    .then((e) => {
                      r && t(e.default);
                    })
                    .catch(console.error),
                  () => {
                    r = !1;
                  }
                );
              }, [e]),
              e
            );
          },
          e_ = () => {
            let e = eC(),
              { dimensions: t } = (0, a.Z)(),
              { avatarWidth: n, avatarHeight: i } = t.avatarSelector,
              o = Y.MB(),
              s = Y.xJ(),
              l = s?.profile.avatar;
            return (0, r.jsxs)("div", {
              style: {
                display: "flex",
                width: "100%",
                height: "100%",
                flexFlow: "row wrap",
                justifyContent: "center",
                alignItems: "center",
              },
              children: [
                0 === e.length && (0, r.jsx)(em.Z, {}),
                e.map((e, t) => {
                  let s = e.cover === l;
                  return (0, r.jsxs)(
                    ep,
                    {
                      type: "avatar",
                      onClick: () => {
                        o(e.cover);
                      },
                      children: [
                        (0, r.jsx)(ex, {
                          isActive: s,
                          type: "avatar",
                          children: (0, r.jsx)(ey, {
                            children: (0, r.jsx)("div", {
                              style: {
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                              },
                              children: (0, r.jsx)(eg.Z, { color: "primary" }),
                            }),
                          }),
                        }),
                        (0, r.jsx)(ef, {
                          src: (0, x.ZP)(e.cover, { width: n, height: i }),
                          alt: "Avatar image",
                          loading: "lazy",
                          decoding: "async",
                        }),
                      ],
                    },
                    t
                  );
                }),
              ],
            });
          },
          ew = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              t = () => {
                e("editProfile", { isExiting: !0 });
              };
            return (0, r.jsx)(ei.Z, {
              onBack: t,
              title: eh.ag._({ id: "common.upDrawer.changeAvatar" }),
              fixHeader: !0,
              children: (0, r.jsx)(e_, {}),
            });
          },
          ev = () => {
            let [e, t] = i.useState([]);
            return (
              i.useEffect(() => {
                if (e.length > 0) return;
                let r = !0;
                return (
                  n
                    .e(90371)
                    .then(n.t.bind(n, 90371, 19))
                    .then((e) => {
                      r && t(e.default);
                    })
                    .catch(console.error),
                  () => {
                    r = !1;
                  }
                );
              }, [e]),
              e
            );
          },
          ej = () => {
            let e = ev(),
              { dimensions: t } = (0, a.Z)(),
              { coverWidth: n, coverHeight: i } = t.profileCoverSelector,
              o = Y.sV(),
              s = Y.xJ(),
              l = s?.profile.cover;
            return (0, r.jsxs)("div", {
              style: {
                display: "flex",
                width: "100%",
                height: "100%",
                flexFlow: "row wrap",
                justifyContent: "center",
                alignItems: "center",
              },
              children: [
                0 === e.length && (0, r.jsx)(em.Z, {}),
                e.map((e, t) => {
                  let s = e.cover === l;
                  return (0, r.jsxs)(
                    ep,
                    {
                      type: "cover",
                      onClick: () => {
                        o(e.cover);
                      },
                      children: [
                        (0, r.jsx)(ex, {
                          isActive: s,
                          type: "cover",
                          children: (0, r.jsx)(ey, {
                            children: (0, r.jsx)("div", {
                              style: {
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                              },
                              children: (0, r.jsx)(eg.Z, { color: "primary" }),
                            }),
                          }),
                        }),
                        (0, r.jsx)(ef, {
                          src: (0, x.ZP)(e.cover, {
                            width: n,
                            height: i,
                            fit: "crop",
                          }),
                          alt: e.name,
                          loading: "lazy",
                          decoding: "async",
                        }),
                      ],
                    },
                    t
                  );
                }),
              ],
            });
          },
          eB = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { i18n: t } = (0, u.mV)(),
              n = () => {
                e("editProfile", { isExiting: !0 });
              };
            return (0, r.jsx)(ei.Z, {
              onBack: n,
              title: t._({ id: "common.upDrawer.changeCover" }),
              fixHeader: !0,
              children: (0, r.jsx)(ej, {}),
            });
          };
        var eD = n(17305),
          ez = n(43016);
        let eb = () => {
          let { openDrawer: e } = i.useContext(p.s9),
            { i18n: t } = (0, u.mV)();
          return (0, r.jsx)(ei.Z, {
            onBack: () => {
              e("editProfile", { isExiting: !0 });
            },
            title: t._({ id: "common.upDrawer.changeUsername" }),
            contentPadding: 2,
            children: (0, r.jsxs)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                width: "100%",
                flexDirection: "column",
              },
              children: [
                (0, r.jsx)(eD.NF, {
                  children: (0, r.jsx)(u.cC, {
                    id: "common.upDrawer.usernameSelectorDescription",
                  }),
                }),
                (0, r.jsx)(ez.Z, {}),
              ],
            }),
          });
        };
        var ek = n(24086),
          eZ = n(20805),
          eP = n.n(eZ),
          eS = n(34003);
        let eF = s()(() => Promise.resolve().then(n.bind(n, 11765)), {
            loadableGenerated: { webpack: () => [11765] },
          }),
          eL = (e) =>
            i.useMemo(() => {
              if (!e) return 0;
              let t = new Date(e),
                n = Date.now() - t.getTime();
              return n / 315576e5;
            }, [e]),
          eM = (e) => {
            let t = eL(e);
            return t >= 13 && t <= 120;
          },
          eI = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { setMessage: t } = i.useContext(d.V),
              [n, { loading: o }] = Y.dM(),
              s = (0, u.mV)(),
              [a, l] = i.useState(void 0),
              c = s._("common.upDrawer.editProfile.birthdayError"),
              h = Y.xJ(),
              x = h?.profile.birthday,
              y = "" === a || a ? a : x,
              f = eM(y),
              g = async () => {
                try {
                  await n("" === y ? null : y);
                } catch (e) {
                  return;
                } finally {
                  l(void 0);
                }
                e("editProfile", { isExiting: !0 });
              };
            return (
              (0, i.useEffect)(() => {
                y && !f ? t(c) : t(void 0);
              }, [f, y, c, t]),
              (0, r.jsxs)(ei.Z, {
                onBack: () => {
                  e("editProfile", { isExiting: !0 });
                },
                contentPadding: 2,
                title: (0, r.jsx)(u.cC, {
                  id: "common.upDrawer.editProfile.updateBirthday",
                }),
                children: [
                  (0, r.jsx)(eF, {
                    value: y,
                    onChange: (e) => {
                      l(e);
                    },
                  }),
                  (0, r.jsx)(eS.Z, {}),
                  (0, r.jsx)("div", {
                    className: eP().submitButtonWrapper,
                    children: (0, r.jsx)(ek.Z, {
                      loading: o,
                      disabled: !!y && !f,
                      onClick: g,
                      height: 50,
                      sx: { width: "100%" },
                      children: (0, r.jsx)(u.cC, {
                        id: "common.upDrawer.confirmChange",
                      }),
                    }),
                  }),
                ],
              })
            );
          };
        var eE = n(73274);
        let eR = (0, v.ZP)(j.Sn)(() => ({
          position: "absolute",
          minWidth: 30,
          width: 30,
          height: 30,
          right: 0,
          bottom: 0,
        }));
        var eA = n(19073),
          eV = n(42381),
          eN = n(70115),
          eH = n.n(eN),
          eW = n(11765);
        let eT = () => {
            let { i18n: e } = (0, u.mV)();
            return (t) =>
              e._({ id: "common.upDrawer.editProfile.gender." + t });
          },
          eq = () => {
            let e = eT();
            return ["male", "female", "other", "na"].map((t) => ({
              label: e(t),
              value: t,
            }));
          },
          eU = (e) => {
            let {
                value: t,
                options: n,
                labelId: i,
                onChange: o,
                allowEmpty: s,
              } = e,
              { i18n: a } = (0, u.mV)();
            return (0, r.jsxs)(eA.ZP, {
              height: 63,
              width: "100%",
              label: a._({ id: i }),
              native: !0,
              onChange: (e, t) => {
                o(t);
              },
              children: [
                (0, r.jsx)("option", {
                  value: "",
                  disabled: !s,
                  selected: !t,
                  children: (0, r.jsx)(u.cC, { id: i }),
                }),
                n.map((e) => {
                  let { label: n, value: i } = e;
                  return (0, r.jsx)(
                    "option",
                    { value: i, disabled: !i, selected: i === t, children: n },
                    i
                  );
                }),
              ],
            });
          },
          eG = () => {
            let [e, t] = i.useState([]);
            return (
              i.useEffect(() => {
                if (e.length > 0) return;
                let r = !0;
                return (
                  n
                    .e(22180)
                    .then(n.t.bind(n, 22180, 19))
                    .then((e) => {
                      r && t(e.default);
                    })
                    .catch(console.error),
                  () => {
                    r = !1;
                  }
                );
              }, [e]),
              e
            );
          },
          eY = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              t = Y.xJ(),
              { dimensions: n } = (0, a.Z)(),
              o = t?.profile.cover;
            return (0, r.jsx)("div", {
              className: eH().coverWrapper,
              children:
                o &&
                (0, r.jsxs)("div", {
                  className: eH().coverContainer,
                  children: [
                    (0, r.jsx)("img", {
                      src: (0, x.ZP)(o, {
                        height: 145,
                        width: n.drawer.width,
                        fit: "crop",
                      }),
                      alt: "User Profile Header Background",
                      className: eH().cover,
                    }),
                    (0, r.jsx)(eR, {
                      variant: "contained",
                      color: "purple",
                      onClick: () => {
                        e("coverSelector");
                      },
                      className: eH().cameraButton,
                      sx: {
                        "& svg": { mr: 0, minWidth: 20 },
                        right: 10,
                        left: "auto",
                        bottom: 24,
                      },
                      children: (0, r.jsx)(eE.Z, {}),
                    }),
                  ],
                }),
            });
          },
          eO = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              t = Y.xJ(),
              n = t?.profile.avatar;
            return (0, r.jsx)("div", {
              className: eH().avatarWrapper,
              children:
                n &&
                (0, r.jsxs)("div", {
                  className: eH().avatarContainer,
                  children: [
                    (0, r.jsx)(l.Z, {
                      src: (0, x.ZP)(n, { width: 90, height: 90 }),
                      sx: { width: 90, height: 90 },
                    }),
                    (0, r.jsx)(eR, {
                      variant: "contained",
                      color: "purple",
                      onClick: () => {
                        e("avatarSelector");
                      },
                      sx: { "& svg": { mr: 0, minWidth: 20 } },
                      children: (0, r.jsx)(eE.Z, {}),
                    }),
                  ],
                }),
            });
          },
          eJ = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              t = Y.xJ(),
              { i18n: n } = (0, u.mV)();
            return (0, r.jsx)(eV.Z, {
              readOnly: !0,
              value: t?.username,
              label: n._({ id: "common.upDrawer.editProfile.username" }),
              onClick: () => e("usernameSelector"),
            });
          },
          eQ = () => {
            let e = Y.xJ(),
              t = e?.profile.countryCode,
              n = eG(),
              [i] = Y.lU();
            return (0, r.jsx)(eU, {
              value: t,
              onChange: (e) => {
                e && i(e);
              },
              options: n.map((e) => {
                let { code: t, name: n } = e;
                return { label: n, value: t };
              }),
              labelId: "common.upDrawer.editProfile.location",
            });
          },
          e$ = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              t = Y.xJ(),
              n = t?.profile.birthday,
              { i18n: o } = (0, u.mV)(),
              s = (0, eW.useBirthdayFormatted)(n);
            return (0, r.jsx)(eV.Z, {
              label: o._({ id: "common.upDrawer.editProfile.birthday" }),
              value: s,
              readOnly: !0,
              onClick: () => e("birthdaySelector"),
            });
          },
          eK = () => {
            let e = Y.xJ(),
              t = e?.profile.gender,
              n = eq(),
              [i] = (0, Y.Sh)();
            return (0, r.jsx)(eU, {
              onChange: (e) => {
                i(e);
              },
              value: t,
              options: n,
              labelId: "common.upDrawer.editProfile.gender",
            });
          },
          eX = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { openedDrawer: t } = i.useContext(p.rf),
              { i18n: n } = (0, u.mV)();
            return (0, r.jsxs)(ei.Z, {
              onBack: () => {
                e(t?.returnToDrawer ? t.returnToDrawer : "main", {
                  isExiting: !0,
                });
              },
              title: n._({ id: "common.upDrawer.editProfile" }),
              children: [
                (0, r.jsx)(eY, {}),
                (0, r.jsx)(eO, {}),
                (0, r.jsxs)("div", {
                  className: eH().formContainer,
                  children: [
                    (0, r.jsx)(eJ, {}),
                    (0, r.jsx)(eQ, {}),
                    (0, r.jsx)(c.Z, { className: eH().divider }),
                    (0, r.jsx)("div", {
                      className: eH().personalDetailsTitle,
                      children: (0, r.jsx)(u.cC, {
                        id: "common.upDrawer.editProfile.personalDetails",
                      }),
                    }),
                    (0, r.jsx)("div", {
                      className: eH().personalDetailsDescription,
                      children: (0, r.jsx)(u.cC, {
                        id: "common.upDrawer.editProfile.personalDetailsDescription",
                      }),
                    }),
                    (0, r.jsx)(e$, {}),
                    (0, r.jsx)(eK, {}),
                  ],
                }),
              ],
            });
          };
        var e1 = n(63922),
          e0 = n(50319),
          e2 = n(73359),
          e3 = n(47210),
          e6 = n(49025);
        let e5 = () => {
          let { openDrawer: e } = i.useContext(p.s9),
            [t, n] = i.useState(!1),
            { i18n: o } = (0, u.mV)(),
            { logout: s } = i.useContext(d.V),
            { pageUrlHelper: a } = i.useContext(q.t),
            { routeHelper: l } = i.useContext(P.Z),
            [c] = (0, e0.D)(e1.bw),
            [h] = (0, e2.t)(e6.Gs),
            x = async () => {
              try {
                let e = e3.v0().currentUser?.uid;
                n(!0);
                let { data: t } = await h({ variables: { id: e } });
                await c(),
                  s(),
                  e &&
                    t &&
                    a.isProfilePageWithUsername(t?.me.username) &&
                    (window.location.href = l.homePageCanonical()),
                  n(!1);
              } catch (e) {
                n(!1);
                return;
              }
              e(null);
            };
          return (0, r.jsx)(ei.Z, {
            onBack: () => {
              e("settings", { isExiting: !0 });
            },
            title: o._({ id: "common.upDrawer.deleteAccount.label" }),
            contentPadding: 2,
            children: (0, r.jsxs)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                flexDirection: "column",
                alignItems: "center",
                width: "100%",
              },
              children: [
                (0, r.jsx)(eD.NF, {
                  children: (0, r.jsx)(u.cC, {
                    id: "common.upDrawer.deleteAccount.description",
                  }),
                }),
                (0, r.jsx)(ek.Z, {
                  loading: t,
                  color: "alert",
                  onClick: x,
                  height: 50,
                  sx: { width: "100%" },
                  children: (0, r.jsx)(u.cC, {
                    id: "common.upDrawer.deleteAccount.button",
                  }),
                }),
              ],
            }),
          });
        };
        var e7 = n(12959),
          e4 = n(70768);
        let e9 = () => {
          let { openDrawer: e } = i.useContext(p.s9),
            [t, n] = i.useState(!1),
            [o, s] = i.useState(""),
            [a, l] = i.useState(!1),
            [c, d] = i.useState(""),
            [h, x] = i.useState(!1),
            { i18n: y } = (0, u.mV)(),
            f = (e) => {
              let t = e.target.value;
              s(t), (0, e7.o)(t) ? n(!0) : n(!1);
            },
            g = (e) => {
              let t = (0, e4.r)(e, y);
              return (
                t ||
                (e && e.message
                  ? e.message
                  : y._({ id: "auth.ui.error.generic" }))
              );
            },
            m = async () => {
              x(!0);
              try {
                await (0, e3.Ov)((0, e3.v0)().currentUser, o),
                  d(y._({ id: "common.upDrawer.emailChanged" })),
                  l(!1);
              } catch (t) {
                l(!0);
                let e = g(t);
                d(e), console.error(t);
              } finally {
                x(!1);
              }
            };
          return (0, r.jsx)(ei.Z, {
            onBack: () => {
              e("settings", { isExiting: !0 });
            },
            title: y._({ id: "common.upDrawer.editEmail.label" }),
            contentPadding: 2,
            children: (0, r.jsxs)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                flexDirection: "column",
                alignItems: "center",
                width: "100%",
              },
              children: [
                (0, r.jsx)(eD.NF, {
                  children: (0, r.jsx)(u.cC, {
                    id: "common.upDrawer.editEmail.description",
                  }),
                }),
                (0, r.jsx)(eV.Z, {
                  required: !0,
                  label: y._({ id: "auth.ui.label.email" }),
                  onChange: f,
                  type: "email",
                  error: a,
                  helperText: c,
                }),
                (0, r.jsx)(ek.Z, {
                  disabled: !t,
                  loading: h,
                  onClick: m,
                  height: 50,
                  sx: { width: "100%", mt: 2 },
                  children: (0, r.jsx)(u.cC, {
                    id: "common.upDrawer.confirmChange",
                  }),
                }),
              ],
            }),
          });
        };
        var e8 = n(42916),
          te = n(66060),
          tt = n.n(te);
        let tn = () => {
          let { openDrawer: e } = i.useContext(p.s9),
            [t, n] = i.useState(""),
            [o, s] = i.useState(""),
            [l, c] = i.useState(""),
            [d, h] = i.useState(""),
            [x, y] = i.useState(""),
            [f, g] = i.useState(!1),
            { i18n: m } = (0, u.mV)(),
            { spacing: C } = (0, a.Z)(),
            _ = (e) => {
              let t = (0, e4.r)(e, m);
              return (
                t ||
                (e && e.message
                  ? e.message
                  : m._({ id: "auth.ui.error.generic" }))
              );
            },
            w = async () => {
              g(!0);
              try {
                let e = (0, e3.v0)().currentUser,
                  r = e3.w9.credential(e.email, t);
                await (0, e3.aF)(e, r),
                  await (0, e3.gQ)(e, o),
                  h(""),
                  s(""),
                  c(""),
                  n(""),
                  y(m._({ id: "common.upDrawer.passwordChanged" }));
              } catch (t) {
                let e = _(t);
                h(e), console.error(t);
              } finally {
                g(!1);
              }
            };
          return (0, r.jsx)(ei.Z, {
            onBack: () => {
              e("settings", { isExiting: !0 });
            },
            title: m._({ id: "common.upDrawer.editPassword.label" }),
            contentPadding: 2,
            children: (0, r.jsx)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                flexDirection: "column",
                alignItems: "center",
                width: "100%",
              },
              children: (0, r.jsxs)("div", {
                style: {
                  width: "100%",
                  display: "flex",
                  flexDirection: "column",
                  gap: C(),
                },
                children: [
                  (0, r.jsx)(eD.NF, {
                    children: (0, r.jsx)(u.cC, {
                      id: "common.upDrawer.editPassword.description",
                    }),
                  }),
                  (0, r.jsx)(eV.Z, {
                    helperText: ((e) => {
                      if (e.length > 0 && e.length < e4.l)
                        return m._("common.upDrawer.minPasswordLength", {
                          ch: e4.l,
                        });
                    })(t),
                    type: "password",
                    error: t.length > 0 && t.length < e4.l,
                    label: m._({ id: "common.upDrawer.currentPasswordHelp" }),
                    value: t,
                    onChange: (e) => n(e.target.value),
                  }),
                  (0, r.jsx)(eV.Z, {
                    helperText: ((e) => {
                      if (e.length > 0 && !(0, e8.Z)(e))
                        return m._("auth.ui.helper.passwordConditions", {
                          numberOfChars: e4.l,
                        });
                    })(o),
                    type: "password",
                    error: o.length > 0 && !(0, e8.Z)(o),
                    label: m._({ id: "common.upDrawer.newPasswordHelp" }),
                    value: o,
                    onChange: (e) => s(e.target.value),
                  }),
                  (0, r.jsx)(eV.Z, {
                    helperText:
                      (0, e8.Z)(o) && (0, e8.Z)(l)
                        ? o !== l
                          ? m._({ id: "common.upDrawer.passwordsDontMatch" })
                          : d || void 0
                        : void 0,
                    type: "password",
                    error: o !== l || "" !== d,
                    label: m._({ id: "common.upDrawer.confirmPasswordHelp" }),
                    value: l,
                    onChange: (e) => {
                      c(e.target.value), h("");
                    },
                  }),
                  !!x &&
                    (0, r.jsx)("div", {
                      style: { fontSize: 12, opacity: 0.7, marginTop: 8 },
                      children: x,
                    }),
                  (0, r.jsx)(ek.Z, {
                    disabled: f || !(0, e8.Z)(o) || o !== l || t.length < e4.l,
                    loading: f,
                    onClick: w,
                    height: 50,
                    sx: { width: "100%", mt: 2 },
                    children: (0, r.jsx)(u.cC, {
                      id: "common.upDrawer.confirmChange",
                    }),
                  }),
                  (0, r.jsx)(X.Z, {
                    onClick: () => e("passwordReset"),
                    color: "purple",
                    className: tt().forgotPasswordButton,
                    children: (0, r.jsx)(u.cC, {
                      id: "auth.ui.forgotPassword",
                    }),
                  }),
                ],
              }),
            }),
          });
        };
        var tr = n(98456),
          ti = n(72852),
          to = n(29632);
        let ts = (e) => {
            let { textLabel: t, value: n, onChange: i } = e;
            return (0, r.jsxs)("div", {
              style: {
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                height: 40,
              },
              children: [
                (0, r.jsx)("div", {
                  style: {
                    fontWeight: 400,
                    fontSize: 14,
                    flex: 1,
                    color: f.D.white[80],
                    maxWidth: 220,
                    lineHeight: "135%",
                  },
                  children: (0, r.jsx)(u.cC, { id: t }),
                }),
                (0, r.jsx)(tl, { checked: n, onChange: (e, t) => i(t) }),
              ],
            });
          },
          ta = ".Mui-focusVisible",
          tl = (0, v.ZP)((e) =>
            (0, r.jsx)(ti.Z, {
              focusVisibleClassName: ta,
              disableRipple: !0,
              ...e,
            })
          )((e) => {
            let { theme: t } = e;
            return {
              width: 55,
              height: 30,
              padding: 0,
              [`& .${to.Z.switchBase}`]: {
                padding: 0,
                margin: 4,
                transitionDuration: "300ms",
                [`&.${to.Z.checked}`]: {
                  transform: "translateX(25px)",
                  color: "#fff",
                  [`& + .${to.Z.track}`]: {
                    backgroundColor: "#10E9D7",
                    opacity: 1,
                    border: 0,
                  },
                  [`&.${to.Z.disabled} + .${to.Z.track}`]: { opacity: 0.5 },
                },
                [`&.${ta} .${to.Z.thumb}`]: {
                  color: "#33cf4d",
                  border: "6px solid #fff",
                },
                [`&.${to.Z.disabled} .${to.Z.thumb}`]: { color: f.D.white[50] },
                [`&.${to.Z.disabled} + .${to.Z.track}`]: { opacity: 0.5 },
              },
              [`& .${to.Z.thumb}`]: {
                boxSizing: "border-box",
                width: 22,
                height: 22,
                boxShadow: "0px 2px 4px 0px #00000033",
              },
              [`& .${to.Z.track}`]: {
                borderRadius: 15,
                backgroundColor: "#3B3D4E",
                opacity: 1,
                transition: t.transitions.create(["background-color"], {
                  duration: 500,
                }),
              },
            };
          });
        var tc = n(6388),
          td = n(10210),
          tu = n(79862);
        let th = () => {
          let { openDrawer: e } = i.useContext(p.s9),
            { openedDrawer: t } = i.useContext(p.rf),
            { services: n } = i.useContext(U.Z),
            { routeHelper: o } = i.useContext(P.Z),
            { crazyAnalyticsService: s } = n,
            a = Y.D6(),
            { data: l, loading: c } = (0, tc.aM)(e1.l2),
            [d] = (0, e0.D)(e1.e7),
            h = l?.me?.settings?.privacyPreferences,
            x = async (e, t) => {
              let n = {
                  liveActivityPublicForFriends: h.liveActivityPublicForFriends,
                  profileVisibleForAnyone: h.profileVisibleForAnyone,
                  friendsCanSendGameInvites: h.friendsCanSendGameInvites,
                  receiveFriendRequests: h.receiveFriendRequests,
                  [e]: t,
                },
                r = { ...l.me.settings, privacyPreferences: n },
                i = await d({
                  variables: { input: { privacyPreferences: n } },
                  optimisticResponse: {
                    updateUserSettings: {
                      id: l.me.id,
                      settings: r,
                      __typename: "User",
                    },
                  },
                });
              i.data &&
                s.updateUserSettingsEvent({
                  settingName: e,
                  settingValue: `${t}`,
                });
            },
            y = () =>
              (0, r.jsx)("div", {
                style: {
                  height: 120,
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                },
                children: (0, r.jsx)(tr.Z, { color: "secondary", size: 60 }),
              }),
            g = t?.returnToDrawer ? t.returnToDrawer : "main",
            m = c || void 0 === h,
            C = o.privacyPolicyPageLink();
          return (0, r.jsx)(ei.Z, {
            onBack: () => {
              e(g, { isExiting: !0 });
            },
            title: eh.ag._({ id: "friends.upDrawer.privacyPreferences" }),
            children: (0, r.jsxs)(er.Z, {
              sx: { display: "flex", flexDirection: "column", gap: 2 },
              children: [
                (0, r.jsx)(td.qM, {
                  sx: { p: 0, m: 0 },
                  children: (0, r.jsx)(u.cC, {
                    id: "friends.upDrawer.privacyPreferences.community",
                  }),
                }),
                m
                  ? y()
                  : (0, r.jsxs)(td.zC, {
                      sx: {
                        display: "flex",
                        flexDirection: "column",
                        gap: 1,
                        py: 3,
                        px: 2.5,
                      },
                      children: [
                        (0, r.jsx)(ts, {
                          textLabel:
                            "friends.upDrawer.privacyPreferences.profileVisibleForAnyone",
                          value: !!h.profileVisibleForAnyone,
                          onChange: (e) => {
                            x("profileVisibleForAnyone", e);
                          },
                        }),
                        (0, r.jsx)(ts, {
                          textLabel:
                            "friends.upDrawer.privacyPreferences.receiveFriendRequests",
                          value: !!h.receiveFriendRequests,
                          onChange: (e) => {
                            x("receiveFriendRequests", e);
                          },
                        }),
                        !h.receiveFriendRequests &&
                          (0, r.jsx)("div", {
                            style: {
                              fontSize: 12,
                              color: f.D.white[40],
                              width: 280,
                              fontWeight: 700,
                              marginTop: -10,
                            },
                            children: (0, r.jsx)(u.cC, {
                              id: "friends.upDrawer.privacyPreferences.receiveFriendRequestsHelp",
                              values: {
                                link: (0, r.jsx)("span", {
                                  style: {
                                    cursor: "pointer",
                                    color: f.D.brand[60],
                                  },
                                  onClick: () =>
                                    e("friends", {
                                      isExiting: !1,
                                      returnToDrawer: "privacyPreferences",
                                    }),
                                  children: (0, r.jsx)(u.cC, {
                                    id: "friends.upDrawer.privacyPreferences.receiveFriendRequestsHelpLink",
                                  }),
                                }),
                              },
                            }),
                          }),
                      ],
                    }),
                (0, r.jsx)(td.qM, {
                  sx: { p: 0, m: 0 },
                  children: (0, r.jsx)(u.cC, {
                    id: "friends.upDrawer.privacyPreferences.friends",
                  }),
                }),
                m
                  ? y()
                  : (0, r.jsxs)(td.zC, {
                      sx: {
                        display: "flex",
                        flexDirection: "column",
                        gap: 1,
                        py: 3,
                        px: 2.5,
                      },
                      children: [
                        (0, r.jsx)(ts, {
                          textLabel:
                            "friends.upDrawer.privacyPreferences.liveActivityPublicForFriends",
                          value: !!h.liveActivityPublicForFriends,
                          onChange: (e) => {
                            x("liveActivityPublicForFriends", e),
                              e ||
                                a({ variables: { input: { gameId: void 0 } } });
                          },
                        }),
                        (0, r.jsx)(ts, {
                          textLabel:
                            "friends.upDrawer.privacyPreferences.friendsCanSendGameInvites",
                          value: !!h.friendsCanSendGameInvites,
                          onChange: (e) => {
                            x("friendsCanSendGameInvites", e);
                          },
                        }),
                      ],
                    }),
                (0, r.jsx)(td.qM, {
                  sx: { p: 0, m: 0 },
                  children: (0, r.jsx)(u.cC, {
                    id: "friends.upDrawer.privacyPreferences.yourData",
                  }),
                }),
                (0, r.jsx)(V.Z, {
                  ...C,
                  children: (0, r.jsxs)(td.zC, {
                    sx: {
                      display: "flex",
                      flexDirection: "row",
                      gap: 1.5,
                      py: 2,
                      px: 2.5,
                      justifyContent: "space-between",
                      cursor: "pointer",
                      "&:hover": { background: f.D.black[70] },
                    },
                    children: [
                      (0, r.jsx)(u.cC, {
                        id: "friends.upDrawer.privacyPreferences.privacyPolicyCookieLink",
                      }),
                      (0, r.jsx)(tu.Z, {}),
                    ],
                  }),
                }),
              ],
            }),
          });
        };
        var tp = n(380),
          tx = n(60362),
          ty = n(88061),
          tf = n(63462),
          tg = n(13592),
          tm = n(90512),
          tC = n(57860),
          t_ = n.n(tC);
        let tw = i.memo((e) => {
          let { user: t, origin: n, inviteLink: o } = e,
            s = t.id,
            a = t.profile?.avatar || "",
            l = t.username,
            c = t.userStatus?.status,
            d = t.gameStatus,
            { i18n: h } = (0, u.mV)(),
            { sendGameInvite: p, playingGame: y } = i.useContext(tp.DN),
            { crazyAnalyticsService: g } = i.useContext(U.Z).services,
            { routeHelper: m } = i.useContext(P.Z),
            { crazyRouterChange: C } = i.useContext(tg.R),
            [_, w] = i.useState(!1),
            v = Y.Lv(),
            B = (e) => {
              if ((e.preventDefault(), !d?.joinUrl)) return;
              let t = d.joinUrl;
              d.gameSlug &&
                (t = m.localizedJoinUrl(d.gameSlug, d.joinUrl) || d.joinUrl),
                g.gameInteractionEvent({
                  method: "join",
                  origin: n,
                  action: "join",
                  target: s,
                  targetStatus: c,
                  targetGameId: d.gameId,
                }),
                e.metaKey || e.ctrlKey ? window.open(t, "_blank") : C(t);
            },
            D = async (e) => {
              if (
                (e.preventDefault(),
                w(!0),
                p(s),
                setTimeout(() => {
                  w(!1);
                }, 1e4),
                o)
              ) {
                let e = await v({
                  variables: { input: { userId: s, joinUrl: o, gameId: y.id } },
                });
                e.data &&
                  g.gameInteractionEvent({
                    method: "invite",
                    origin: n,
                    action: "send",
                    target: s,
                    targetStatus: c,
                    targetGameId: y.id,
                  });
              }
            },
            z =
              h._({ id: "friends.upDrawer.inviteFriends.inviteButton" })
                .length > 8,
            b =
              h._({ id: "friends.upDrawer.inviteFriends.invited" }).length > 8,
            k = !t.privacy?.canReceiveGameInvites,
            Z = (0, r.jsxs)(X.Z, {
              variant: "contained",
              height: 34,
              className: (0, tm.Z)(t_().friendListButton, t_().colorSuccess),
              fullWidth: !0,
              disabled: !0,
              children: [
                (0, r.jsx)(eg.Z, { sx: b ? { mr: "0 !important" } : void 0 }),
                !b &&
                  (0, r.jsx)(u.cC, {
                    id: "friends.upDrawer.inviteFriends.invited",
                  }),
              ],
            });
          return (0, r.jsx)(r.Fragment, {
            children: (0, r.jsx)("a", {
              target: "_blank",
              href: m.profilePageLink(l).as,
              children: (0, r.jsxs)(td.P7, {
                className: "friendListItem",
                children: [
                  (0, r.jsxs)("div", {
                    style: { position: "relative" },
                    children: [
                      "offline" != c &&
                        (0, r.jsx)(j.hZ, {
                          sx: {
                            background:
                              "online" === c
                                ? f.D.success[100]
                                : f.D.warning[100],
                            right: 12,
                          },
                        }),
                      (0, r.jsx)(td.bw, {
                        src: (0, x.ZP)(a, { width: 100, height: 100 }),
                        alt: "Avatar",
                      }),
                    ],
                  }),
                  (0, r.jsxs)("div", {
                    style: { flex: 1 },
                    children: [
                      (0, r.jsx)(er.Z, {
                        style: {
                          fontSize: 14,
                          fontWeight: 700,
                          width: "online" === c && d.joinUrl ? 140 : 160,
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                          whiteSpace: "nowrap",
                          display: "block",
                        },
                        sx: { color: f.D.white[80], pr: 2 },
                        children: l,
                      }),
                      (() => {
                        let e = "online" === c && d?.joinUrl;
                        return "online" === c && d.gameName && d.gameSlug
                          ? (0, r.jsx)("div", {
                              style: {
                                fontSize: 12,
                                fontWeight: 400,
                                color: e ? f.D.success[100] : f.D.brand[60],
                                width: 150,
                                textOverflow: "ellipsis",
                                overflow: "hidden",
                                whiteSpace: "nowrap",
                                display: "block",
                              },
                              children: d.gameName,
                            })
                          : null;
                      })(),
                    ],
                  }),
                  "inviteFriendsDrawer" === n
                    ? (0, r.jsx)(r.Fragment, {
                        children: _
                          ? b
                            ? (0, r.jsx)(tf.m, {
                                title: h._(
                                  "friends.upDrawer.inviteFriends.invited"
                                ),
                                placement: "top",
                                sx: { p: 1, width: "auto" },
                                children: Z,
                              })
                            : Z
                          : (() => {
                              let e = (0, r.jsxs)(X.Z, {
                                variant: k ? "outlined" : "contained",
                                color: k ? "black" : "purple",
                                height: 34,
                                fullWidth: !0,
                                className: t_().friendListButton,
                                onClick: D,
                                disabled: k,
                                children: [
                                  (0, r.jsx)(tx.Z, {
                                    sx: z ? { mr: "0 !important" } : void 0,
                                  }),
                                  !z &&
                                    (0, r.jsx)(u.cC, {
                                      id: "friends.upDrawer.inviteFriends.inviteButton",
                                    }),
                                ],
                              });
                              return k
                                ? (0, r.jsx)(tf.m, {
                                    title: h._(
                                      "friends.upDrawer.inviteFriends.privacyDisabled"
                                    ),
                                    placement: "top",
                                    sx: { p: 1, width: "auto" },
                                    children: e,
                                  })
                                : z
                                ? (0, r.jsx)(tf.m, {
                                    title: h._(
                                      "friends.upDrawer.inviteFriends.inviteButton"
                                    ),
                                    placement: "top",
                                    sx: { p: 1, width: "auto" },
                                    children: e,
                                  })
                                : e;
                            })(),
                      })
                    : (0, r.jsx)(r.Fragment, {
                        children:
                          "online" === c && d.joinUrl
                            ? (0, r.jsx)(X.Z, {
                                onClick: B,
                                variant: "contained",
                                height: 34,
                                color: "green-gradient",
                                className: (0, tm.Z)(
                                  t_().friendListButton,
                                  t_().joinButton
                                ),
                                children: (0, r.jsx)(u.cC, {
                                  id: "friends.upDrawer.friends.join",
                                }),
                              })
                            : "online" === c &&
                              d.gameSlug &&
                              (0, r.jsx)(ty.Z, {
                                slug: d.gameSlug,
                                children: (0, r.jsx)(X.Z, {
                                  variant: "contained",
                                  height: 34,
                                  color: "purple",
                                  className: (0, tm.Z)(
                                    t_().friendListButton,
                                    t_().joinButton
                                  ),
                                  children: (0, r.jsx)(u.cC, {
                                    id: "friends.upDrawer.friends.play",
                                  }),
                                }),
                              }),
                      }),
                ],
              }),
            }),
          });
        });
        var tv = n(83696),
          tj = n.n(tv);
        let tB = (e) => {
            let { children: t, limitBeforeExpand: n = 5, drawerPaperSx: o } = e,
              [s, a] = i.useState(!1),
              l = s ? t : t.slice(0, n),
              c = t.length > n;
            return (0, r.jsxs)(td.zC, {
              sx: { p: 0, pt: 1, pb: c ? 2 : 1, ...o },
              id: `button: ${c}`,
              children: [
                l.map((e) => e),
                c &&
                  (0, r.jsx)(X.Z, {
                    className: tj().button,
                    variant: "contained",
                    color: "grey",
                    onClick: () => a(!s),
                    children: s
                      ? (0, r.jsx)(u.cC, {
                          id: "common.expandableList.showLess",
                        })
                      : (0, r.jsx)(u.cC, {
                          id: "common.expandableList.showAll",
                        }),
                  }),
              ],
            });
          },
          tD = { joinable: 1, playing: 2, online: 3, away: 4 },
          tz = (e) =>
            "away" === e.userStatus.status
              ? "away"
              : "online" === e.userStatus.status
              ? e.gameStatus.joinUrl
                ? "joinable"
                : e.gameStatus.gameName && e.gameStatus.gameSlug
                ? "playing"
                : "online"
              : "away",
          tb = (e, t) =>
            tz(e) !== tz(t)
              ? tD[tz(e)] - tD[tz(t)]
              : e.username.toLowerCase() <= t.username.toLowerCase()
              ? -1
              : 1,
          tk = (e) => {
            let { friends: t, origin: n, inviteLink: i, hideIfEmpty: o } = e,
              s = t
                .filter(
                  (e) =>
                    "online" === e.userStatus.status ||
                    "away" === e.userStatus.status
                )
                .sort(tb),
              a = t.filter((e) => "offline" === e.userStatus.status);
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(r.Fragment, {
                  children:
                    o && 0 === s.length
                      ? (0, r.jsx)(r.Fragment, {})
                      : (0, r.jsxs)(r.Fragment, {
                          children: [
                            (0, r.jsxs)(td.qM, {
                              sx: { mb: 1 },
                              children: [
                                (0, r.jsx)(u.cC, {
                                  id: "friends.upDrawer.inviteFriends.online",
                                }),
                                s.length
                                  ? (0, r.jsx)(td.jj, { children: s.length })
                                  : "",
                              ],
                            }),
                            s.length > 0
                              ? (0, r.jsx)(tB, {
                                  limitBeforeExpand: 20,
                                  drawerPaperSx: { mb: 3 },
                                  children: s.map((e) =>
                                    (0, r.jsx)(
                                      tw,
                                      { user: e, origin: n, inviteLink: i },
                                      e.id
                                    )
                                  ),
                                })
                              : (0, r.jsxs)(td.zC, {
                                  sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    textAlign: "center",
                                    fontSize: 16,
                                    fontWeight: 700,
                                    minHeight: 130,
                                  },
                                  children: [
                                    (0, r.jsx)("div", {
                                      style: { fontSize: 26 },
                                      children: "\uD83D\uDE29",
                                    }),
                                    (0, r.jsx)(u.cC, {
                                      id: "friends.upDrawer.gameInviteLink.nobody",
                                    }),
                                  ],
                                }),
                          ],
                        }),
                }),
                a.length > 0 &&
                  (0, r.jsxs)(r.Fragment, {
                    children: [
                      (0, r.jsxs)(td.qM, {
                        sx: { mt: 3, mb: 1 },
                        children: [
                          (0, r.jsx)(u.cC, {
                            id: "friends.upDrawer.inviteFriends.offline",
                          }),
                          (0, r.jsx)(td.jj, { children: a.length }),
                        ],
                      }),
                      (0, r.jsx)(tB, {
                        drawerPaperSx: {
                          mb: 1,
                          "& .friendListItem": {
                            opacity: 0.6,
                            "&:hover": { opacity: 1 },
                            "& a": { "&:hover": { color: f.D.white[80] } },
                          },
                        },
                        children: a.map((e) =>
                          (0, r.jsx)(
                            tw,
                            { user: e, origin: n, inviteLink: i },
                            e.id
                          )
                        ),
                      }),
                    ],
                  }),
              ],
            });
          },
          tZ = (e) => {
            let {
              friends: t,
              splitOnlineOffline: n,
              origin: i,
              inviteLink: o,
              hideIfEmpty: s,
            } = e;
            return (0, r.jsx)(r.Fragment, {
              children: n
                ? (0, r.jsx)(tk, {
                    friends: t,
                    origin: i,
                    inviteLink: o,
                    hideIfEmpty: s,
                  })
                : (0, r.jsx)(tB, {
                    children: t.map((e) =>
                      (0, r.jsx)(tw, { user: e, origin: i }, e.id)
                    ),
                  }),
            });
          };
        var tP = n(89609);
        let tS = i.memo((e) =>
          (0, r.jsx)(g.Z, {
            ...e,
            viewBox: "0 0 20 20",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M3.57806 3.57806C3.9035 3.25263 4.43114 3.25263 4.75657 3.57806L10.0007 8.82214L15.2447 3.57806C15.5702 3.25263 16.0978 3.25263 16.4232 3.57806C16.7487 3.9035 16.7487 4.43114 16.4232 4.75657L11.1792 10.0007L16.4232 15.2447C16.7487 15.5702 16.7487 16.0978 16.4232 16.4232C16.0978 16.7487 15.5702 16.7487 15.2447 16.4232L10.0007 11.1792L4.75657 16.4232C4.43114 16.7487 3.9035 16.7487 3.57806 16.4232C3.25263 16.0978 3.25263 15.5702 3.57806 15.2447L8.82214 10.0007L3.57806 4.75657C3.25263 4.43114 3.25263 3.9035 3.57806 3.57806Z",
            }),
          })
        );
        var tF = n(25503),
          tL = n(66252),
          tM = n(33661);
        let tI = (e) => {
            let { timestamp: t } = e;
            if (!t) return null;
            let n = ((e) => {
              let t = new Date(e).getTime();
              if (isNaN(t)) return null;
              let n = new Date().getTime() - t,
                i = n / 1e3 / 60 + 1;
              if (i < 60)
                return (0, r.jsx)(u.cC, {
                  id: "friends.drawers.availableSinceMinutes",
                  values: { duration: Math.floor(i) },
                });
              let o = i / 60;
              if (o < 24)
                return (0, r.jsx)(u.cC, {
                  id: "friends.drawers.availableSinceHours",
                  values: { duration: Math.floor(o) },
                });
              let s = o / 24;
              return s > 50
                ? null
                : (0, r.jsx)(u.cC, {
                    id: "friends.drawers.availableSinceDays",
                    values: { duration: Math.floor(s) },
                  });
            })(t);
            return n
              ? (0, r.jsx)("div", {
                  style: {
                    fontSize: 12,
                    fontWeight: 800,
                    color: f.D.white[40],
                  },
                })
              : null;
          },
          tE = i.memo(
            (e) => {
              let { request: t, origin: n } = e,
                o = t.user.id,
                s = t.user.profile?.avatar || "",
                a = t.user.username,
                [l, c] = i.useState(!1),
                { crazyAnalyticsService: d } = i.useContext(U.Z).services,
                u = i.useContext(P.Z).routeHelper,
                [h] = (0, e0.D)(tF.dn, {
                  refetchQueries: [tF.rc],
                  awaitRefetchQueries: !0,
                }),
                p = (0, tL.x)(),
                y = async () => {
                  c(!0);
                  let { data: e } = await h({
                    variables: { input: { fromId: o, accept: !0 } },
                  });
                  e?.respondToFriendRequest.success
                    ? ((0, tM.sy)(p, o),
                      d.friendRequestEvent({
                        action: "accept",
                        target: o,
                        origin: n,
                      }))
                    : (0, tM.sN)(p, o),
                    c(!1);
                },
                g = async () => {
                  c(!0);
                  let { data: e } = await h({
                    variables: { input: { fromId: o, accept: !1 } },
                  });
                  e?.respondToFriendRequest.success
                    ? ((0, tM.fP)(p, o),
                      d.friendRequestEvent({
                        action: "decline",
                        target: o,
                        origin: n,
                      }))
                    : (0, tM.vt)(p, o),
                    c(!1);
                };
              return (0, r.jsxs)(td.P7, {
                children: [
                  (0, r.jsx)("div", {
                    style: { position: "relative" },
                    children: (0, r.jsx)(td.bw, {
                      src: (0, x.ZP)(s, { width: 100, height: 100 }),
                      alt: "Avatar",
                    }),
                  }),
                  (0, r.jsxs)("div", {
                    style: { flex: 1 },
                    children: [
                      (0, r.jsx)(er.Z, {
                        style: {
                          fontSize: 14,
                          fontWeight: 700,
                          width: 145,
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                          whiteSpace: "nowrap",
                          display: "block",
                        },
                        component: "a",
                        href: u.profilePageLink(a).as,
                        sx: {
                          color: f.D.white[80],
                          pr: 1,
                          "&:hover": {
                            cursor: "pointer",
                            color: f.D.white[40],
                          },
                        },
                        children: a,
                      }),
                      (0, r.jsx)(tI, { timestamp: t.requestAvailableSince }),
                    ],
                  }),
                  l
                    ? (0, r.jsx)("div", {
                        style: { width: 108, textAlign: "center" },
                        children: (0, r.jsx)(tr.Z, {
                          style: {
                            color: f.D.white[10],
                            width: 30,
                            height: 30,
                          },
                        }),
                      })
                    : (0, r.jsxs)(r.Fragment, {
                        children: [
                          (0, r.jsx)(X.Z, {
                            variant: "contained",
                            color: "black",
                            height: 34,
                            onClick: g,
                            className: t_().friendRequestButton,
                            children: (0, r.jsx)(tS, {
                              className: "cross",
                              style: { color: f.D.alert[100] },
                            }),
                          }),
                          (0, r.jsx)(X.Z, {
                            variant: "contained",
                            color: "black",
                            height: 34,
                            onClick: y,
                            className: t_().friendRequestButton,
                            children: (0, r.jsx)(eg.Z, {
                              className: "check",
                              style: { color: f.D.success[100] },
                            }),
                          }),
                        ],
                      }),
                ],
              });
            },
            (e, t) => e.request === t.request
          ),
          tR = () => {
            let [e, { refetch: t }] = Y.Bx(),
              n = e?.length || 0;
            return (i.useEffect(() => {
              t();
            }, [t]),
            n < 1)
              ? null
              : (0, r.jsxs)(r.Fragment, {
                  children: [
                    (0, r.jsxs)(td.qM, {
                      sx: { mb: 1 },
                      children: [
                        (0, r.jsx)(u.cC, {
                          id: "friends.upDrawer.friends.requestsReceived",
                        }),
                        (0, r.jsx)(td.jj, { children: n }),
                      ],
                    }),
                    (0, r.jsx)(tB, {
                      drawerPaperSx: { mb: 3 },
                      children: e?.map((e) =>
                        (0, r.jsx)(
                          tE,
                          { request: e, origin: "friendRequestDrawer" },
                          e.user.id
                        )
                      ),
                    }),
                  ],
                });
          },
          tA = i.memo(
            (e) => {
              let { user: t, origin: n, type: o } = e,
                s = t.id,
                a = t.profile?.avatar,
                l = t.username,
                c = t.relationship,
                [d, h] = i.useState(!1),
                p = (0, tL.x)(),
                { crazyAnalyticsService: y } = i.useContext(U.Z).services,
                g = i.useContext(P.Z).routeHelper,
                { i18n: m } = (0, u.mV)(),
                [C] = (0, e0.D)(tF.Yl, {
                  refetchQueries: [tF.rc],
                  awaitRefetchQueries: !0,
                }),
                _ = async (e) => {
                  e.preventDefault(), h(!0);
                  let { data: t } = await C({
                    variables: { input: { toId: s } },
                  });
                  if (t?.sendFriendRequest.success) {
                    let e = t.sendFriendRequest.newRelationship;
                    (0, tM.P2)(p, s, e),
                      e?.includes("friend")
                        ? y.friendRequestEvent({
                            action: "accept",
                            target: s,
                            origin: n,
                          })
                        : y.friendRequestEvent({
                            action: "send",
                            target: s,
                            origin: n,
                          });
                  }
                  h(!1);
                },
                w = async (e) => {
                  e.preventDefault(), h(!0);
                  let { data: t } = await C({
                    variables: { input: { toId: s, cancel: !0 } },
                  });
                  t?.sendFriendRequest.success &&
                    ((0, tM.r_)(p, s),
                    y.friendRequestEvent({
                      action: "cancel",
                      target: s,
                      origin: n,
                    })),
                    h(!1);
                };
              return (0, r.jsx)("a", {
                target: "_blank",
                href: g.profilePageLink(l).as,
                children: (0, r.jsxs)(td.P7, {
                  children: [
                    (0, r.jsx)("div", {
                      style: { position: "relative" },
                      children:
                        a &&
                        (0, r.jsx)(td.bw, {
                          src: (0, x.ZP)(a, { width: 100, height: 100 }),
                          alt: "Avatar",
                        }),
                    }),
                    (0, r.jsx)("div", {
                      style: { flex: 1 },
                      children: (0, r.jsx)(er.Z, {
                        style: {
                          fontSize: 14,
                          fontWeight: 700,
                          width: 175,
                          textOverflow: "ellipsis",
                          overflow: "hidden",
                          whiteSpace: "nowrap",
                          display: "block",
                        },
                        sx: { color: f.D.white[80], pr: 2 },
                        children: l,
                      }),
                    }),
                    d
                      ? (0, r.jsx)("div", {
                          style: { width: 79, textAlign: "center" },
                          children: (0, r.jsx)(tr.Z, {
                            style: {
                              color: f.D.white[10],
                              width: 30,
                              height: 30,
                            },
                          }),
                        })
                      : c?.includes("invite-sent")
                      ? (0, r.jsx)(X.Z, {
                          className: t_().friendListButton,
                          variant: "outlined",
                          height: 34,
                          color: "white",
                          onClick: w,
                          children: (0, r.jsx)(u.cC, {
                            id: "friends.upDrawer.friends.cancel",
                          }),
                        })
                      : "disabled-striked" === o
                      ? (0, r.jsx)(tf.m, {
                          title: m._(
                            "friends.upDrawer.inviteFriends.error.strike"
                          ),
                          placement: "top",
                          sx: { p: 1, width: "auto" },
                          children: (0, r.jsx)(X.Z, {
                            className: t_().friendListButton,
                            variant: "outlined",
                            disabled: !0,
                            height: 34,
                            children: (0, r.jsx)(u.cC, {
                              id: "friends.upDrawer.friends.addFriend",
                            }),
                          }),
                        })
                      : (0, r.jsx)(X.Z, {
                          className: t_().friendListButton,
                          variant: "contained",
                          height: 34,
                          onClick: _,
                          children: (0, r.jsx)(u.cC, {
                            id: "friends.upDrawer.friends.addFriend",
                          }),
                        }),
                  ],
                }),
              });
            },
            (e, t) => e.user === t.user
          ),
          tV = (e) => {
            let { searchQuery: t } = e,
              [n, { refetch: o }] = Y.Hd(),
              s = n?.length || 0;
            i.useEffect(() => {
              o();
            }, [o]);
            let a = i.useCallback(() => {
              if (!n) return [];
              if (!t) return n;
              let e = n.filter((e) =>
                e.user.username.toLowerCase().includes(t.toLowerCase())
              );
              return e;
            }, [n, t]);
            if (s < 1) return null;
            let l = a();
            return 0 === l.length
              ? (0, r.jsx)(r.Fragment, {})
              : (0, r.jsxs)(r.Fragment, {
                  children: [
                    (0, r.jsxs)(td.qM, {
                      sx: { mt: 3, mb: 1 },
                      children: [
                        (0, r.jsx)(u.cC, {
                          id: "friends.upDrawer.friends.requestsSent",
                        }),
                        (0, r.jsx)(td.jj, { children: s }),
                      ],
                    }),
                    (0, r.jsx)(tB, {
                      children: l.map((e) =>
                        (0, r.jsx)(
                          tA,
                          { user: e?.user, origin: "friendRequestDrawer" },
                          e?.user?.id
                        )
                      ),
                    }),
                  ],
                });
          };
        var tN = n(70150),
          tH = n(61765),
          tW = n.n(tH);
        let tT = () => {
            let { openDrawer: e } = i.useContext(p.s9);
            return (0, r.jsxs)("div", {
              style: { alignSelf: "center", textAlign: "center" },
              children: [
                (0, r.jsx)("div", {
                  style: {
                    width: 227,
                    height: 327,
                    margin: "auto",
                    display: "flex",
                    alignItems: "flex-end",
                  },
                  children: (0, r.jsx)("img", {
                    src: (0, x.ZP)(
                      "crazygames/friends/BringYourFriends2.svg",
                      {},
                      !1
                    ),
                    alt: "",
                    style: { width: 227 },
                  }),
                }),
                (0, r.jsx)("div", {
                  style: { fontSize: 28, fontWeight: 900 },
                  children: (0, r.jsx)(u.cC, {
                    id: "friends.upDrawer.friends.noFriends.title",
                  }),
                }),
                (0, r.jsx)("div", {
                  style: {
                    fontWeight: 400,
                    fontSize: 20,
                    color: f.D.white[60],
                    maxWidth: 310,
                  },
                  children: (0, r.jsx)(u.cC, {
                    id: "friends.upDrawer.friends.noFriends.subtitle",
                    values: {
                      link: (0, r.jsx)(tP.Z, {
                        component: "span",
                        onClick: () => e("shareProfile"),
                        sx: {
                          color: f.D.brand[60],
                          fontWeight: 700,
                          cursor: "pointer",
                          "&:hover": { color: f.D.brand[40] },
                        },
                        children: (0, r.jsx)(u.cC, {
                          id: "friends.upDrawer.friends.noFriends.link",
                        }),
                      }),
                    },
                  }),
                }),
              ],
            });
          },
          tq = () => {
            let [e, { loading: t, refetch: n }] = Y.RS(),
              [o] = Y.Bx(),
              [s] = Y.Hd(),
              a = 0 === e.length && 0 === o.length && 0 === s.length;
            return (i.useEffect(() => {
              n();
            }, [n]),
            t)
              ? (0, r.jsx)(td.sX, {
                  children: (0, r.jsx)(tr.Z, { color: "secondary", size: 60 }),
                })
              : a
              ? (0, r.jsx)(tT, {})
              : (0, r.jsx)(tZ, {
                  friends: e,
                  splitOnlineOffline: !0,
                  origin: "friendsDrawer",
                });
          },
          tU = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { routeHelper: t } = i.useContext(P.Z),
              { crazyRouterChange: n } = i.useContext(tg.R),
              o = t.tagPageDirectLink("with-friends");
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsxs)(X.Z, {
                  className: tW().gamesForFriendButton,
                  variant: "contained",
                  fullWidth: !0,
                  color: "green-gradient",
                  onClick: () => n(o.href, o.as),
                  children: [
                    (0, r.jsx)(tN.Z, {}),
                    (0, r.jsx)(u.cC, {
                      id: "friends.upDrawer.friends.gamesButton",
                    }),
                  ],
                }),
                (0, r.jsxs)(X.Z, {
                  className: tW().shareProfileButton,
                  onClick: () =>
                    e("shareProfile", {
                      isExiting: !1,
                      returnToDrawer: "friends",
                    }),
                  variant: "contained",
                  fullWidth: !0,
                  color: "grey",
                  children: [
                    (0, r.jsx)(G.Z, {}),
                    (0, r.jsx)(u.cC, { id: "common.upDrawer.profile.share" }),
                  ],
                }),
                (0, r.jsx)(tR, {}),
                (0, r.jsx)(tq, {}),
                (0, r.jsx)(tV, {}),
              ],
            });
          };
        var tG = n(2075),
          tY = n(99008),
          tO = n(43740);
        let tJ = (e) => {
          let { value: t, onChange: n } = e,
            { i18n: i } = (0, u.mV)(),
            o = async (e) => {
              e && e.type && "click" !== e.type && n(e.currentTarget.value);
            };
          return (0, r.jsx)(er.Z, {
            component: "form",
            autoComplete: "off",
            onSubmit: (e) => {
              e.preventDefault();
            },
            sx: { width: 1 },
            children: (0, r.jsxs)("div", {
              style: { width: "100%", position: "relative" },
              children: [
                (0, r.jsx)(tG.Z, {
                  size: "small",
                  sx: {
                    position: "absolute",
                    top: 8,
                    left: 10,
                    color: f.D.white[30],
                  },
                }),
                (0, r.jsx)(tY.GB, {
                  id: "friends-search-input",
                  placeholder: i._({
                    id: "friends.upDrawer.friends.searchPlaceholder",
                  }),
                  onChange: o,
                  value: t,
                  sx: {
                    pl: 5,
                    width: 1,
                    background: "rgba(0, 0, 0, 0.4)",
                    borderColor: f.D.black[50],
                    color: f.D.white[30],
                  },
                }),
                t && t.length > 0
                  ? (0, r.jsx)(j.Qh, {
                      onClick: () => n(""),
                      variant: "contained",
                      height: 24,
                      sx: {
                        "& svg": { width: 14, height: 14 },
                        position: "absolute",
                        right: 8,
                        top: 8,
                        fontWeight: 400,
                      },
                      children: (0, r.jsx)(tO.Z, {}),
                    })
                  : null,
              ],
            }),
          });
        };
        var tQ = n(20296),
          t$ = n.n(tQ);
        let tK = (e, t) => {
            let [n, r] = i.useState(e),
              o = i.useCallback(
                t$()((e) => {
                  r(e);
                }, t),
                [t]
              );
            return (
              i.useEffect(() => {
                o(e);
              }, [e, o]),
              n
            );
          },
          tX = (e) => {
            let { searchQuery: t } = e,
              n = tK(t, 500),
              [o, { loading: s }] = Y.RS(),
              a = Y.rL(),
              [l, { loading: c, called: d }] = Y.s1(n),
              [h] = Y.Bx(),
              p = i.useCallback(() => {
                if (h) {
                  let e = h.filter((e) =>
                    e.user.username.toLowerCase().includes(t.toLowerCase())
                  );
                  return e;
                }
                return [];
              }, [h, t]),
              y = p(),
              f = l?.friends,
              g = l?.notFriends,
              m = f && f.length > 0,
              C = g && g.length > 0,
              _ = y.length > 0;
            return !h || c || s
              ? (0, r.jsx)(td.sX, {
                  children: (0, r.jsx)(tr.Z, { color: "secondary", size: 60 }),
                })
              : !d || m || C || _
              ? (0, r.jsxs)(r.Fragment, {
                  children: [
                    _
                      ? (0, r.jsxs)(r.Fragment, {
                          children: [
                            (0, r.jsx)(td.qM, {
                              sx: { mt: 2, mb: 1 },
                              children: (0, r.jsx)(u.cC, {
                                id: "friends.upDrawer.friends.friendRequests",
                              }),
                            }),
                            (0, r.jsx)(tB, {
                              children: y.map((e) =>
                                (0, r.jsx)(
                                  tE,
                                  { request: e, origin: "searchUsers" },
                                  e.user.id
                                )
                              ),
                            }),
                          ],
                        })
                      : (0, r.jsx)(r.Fragment, {}),
                    (() => {
                      if (!m) return (0, r.jsx)(r.Fragment, {});
                      let e = {
                          userStatus: { status: "offline" },
                          gameStatus: {},
                        },
                        t = f.map((t) => {
                          let n = o?.find((e) => e.id === t.id);
                          return { ...t, ...e, ...n };
                        });
                      return (0, r.jsx)("div", {
                        className: tW().friendsSearchFriendList,
                        children: (0, r.jsx)(tZ, {
                          friends: t,
                          origin: "searchUsers",
                          splitOnlineOffline: !0,
                          hideIfEmpty: !0,
                        }),
                      });
                    })(),
                    (0, r.jsx)(tV, { searchQuery: t }),
                    C
                      ? (0, r.jsxs)(r.Fragment, {
                          children: [
                            (0, r.jsx)(td.qM, {
                              sx: { mt: 3, mb: 1 },
                              children: (0, r.jsx)(u.cC, {
                                id: "friends.upDrawer.friends.addFriends",
                              }),
                            }),
                            (0, r.jsx)(tB, {
                              children: g.map((e) =>
                                (0, r.jsx)(
                                  tA,
                                  {
                                    user: e,
                                    origin: "searchUsers",
                                    type: a ? "disabled-striked" : "normal",
                                  },
                                  e.id
                                )
                              ),
                            }),
                          ],
                        })
                      : (0, r.jsx)(r.Fragment, {}),
                  ],
                })
              : (0, r.jsx)(td.sX, {
                  children: (0, r.jsxs)("div", {
                    children: [
                      (0, r.jsx)("div", {
                        style: { height: 110 },
                        children: (0, r.jsx)("img", {
                          src: (0, x.ZP)("crazygames/ziggy_no_results3.svg", {
                            width: 115,
                          }),
                          alt: "",
                        }),
                      }),
                      (0, r.jsx)("div", {
                        style: { fontWeight: 800, fontSize: 16 },
                        children: (0, r.jsx)(u.cC, {
                          id: "friends.upDrawer.friends.search.noResults",
                        }),
                      }),
                    ],
                  }),
                });
          },
          t1 = () => {
            let [e, t] = (0, i.useState)(""),
              { openedDrawer: n } = i.useContext(p.rf),
              { openDrawer: o } = i.useContext(p.s9),
              s = n?.returnToDrawer ? n.returnToDrawer : null;
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(w.Z, {
                  title: eh.ag._({ id: "friends.upDrawer.friends.title" }),
                  onBack: s
                    ? () => {
                        o(s, { isExiting: !0 });
                      }
                    : void 0,
                }),
                (0, r.jsxs)(eD.qt, {
                  sx: { p: 2, flexDirection: "column", overflowY: "initial" },
                  children: [
                    (0, r.jsx)(tJ, { value: e, onChange: t }),
                    e.length > 0 && (0, r.jsx)(tX, { searchQuery: e }),
                    0 === e.length && (0, r.jsx)(tU, {}),
                  ],
                }),
              ],
            });
          },
          t0 = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { isDesktop: t } = i.useContext(eo.Z),
              { crazyAnalyticsService: n } = i.useContext(U.Z).services,
              { openedDrawer: o } = i.useContext(p.rf),
              { data: s, loading: a } = (0, tc.aM)(e1.l2),
              [l] = (0, e0.D)(e1.e7),
              c = s?.me?.settings?.notificationPreferences,
              d = async (e, t) => {
                let r = {
                    gameUpdatesRecommendations: c.gameUpdatesRecommendations,
                    friendRequests: c.friendRequests,
                    eventsCompetitions: c.eventsCompetitions,
                    achievementsLeaderboards: c.achievementsLeaderboards,
                    platformUpdates: c.platformUpdates,
                    pushNotifications: c.pushNotifications,
                    interactiveNotifications: c.interactiveNotifications,
                    informationalNotifications: c.informationalNotifications,
                    [e]: t,
                  },
                  i = { ...s.me.settings, notificationPreferences: r },
                  o = await l({
                    variables: { input: { notificationPreferences: r } },
                    optimisticResponse: {
                      updateUserSettings: {
                        id: s.me.id,
                        settings: i,
                        __typename: "User",
                      },
                    },
                  });
                o.data &&
                  n.updateUserSettingsEvent({
                    settingName: e,
                    settingValue: `${t}`,
                  });
              },
              h = function () {
                let e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : 120;
                return (0, r.jsx)("div", {
                  style: {
                    height: e,
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  },
                  children: (0, r.jsx)(tr.Z, { color: "secondary", size: 60 }),
                });
              },
              x = a || void 0 === c,
              y = o?.returnToDrawer ? o.returnToDrawer : "main";
            return (0, r.jsx)(ei.Z, {
              onBack: () => {
                e(y, { isExiting: !0 });
              },
              title: eh.ag._({
                id: "friends.upDrawer.notificationPreferences",
              }),
              children: (0, r.jsxs)(er.Z, {
                sx: { p: t ? void 0 : 2 },
                children: [
                  (0, r.jsx)(eD.iI, {
                    children: (0, r.jsx)(u.cC, {
                      id: "friends.upDrawer.notificationPreferences.emails",
                    }),
                  }),
                  (0, r.jsx)(eD.dA, {
                    sx: { mt: 1 },
                    children: (0, r.jsx)(u.cC, {
                      id: "friends.upDrawer.notificationPreferences.emailsInfo",
                    }),
                  }),
                  x
                    ? h(246)
                    : (0, r.jsxs)(td.zC, {
                        sx: {
                          mt: 2,
                          display: "flex",
                          flexDirection: "column",
                          gap: 1,
                        },
                        children: [
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.gameUpdatesRecommendations",
                            value: !!c.gameUpdatesRecommendations,
                            onChange: (e) => {
                              d("gameUpdatesRecommendations", e);
                            },
                          }),
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.friendRequests",
                            value: !!c.friendRequests,
                            onChange: (e) => {
                              d("friendRequests", e);
                            },
                          }),
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.eventsCompetitions",
                            value: !!c.eventsCompetitions,
                            onChange: (e) => {
                              d("eventsCompetitions", e);
                            },
                          }),
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.achievementsLeaderboards",
                            value: !!c.achievementsLeaderboards,
                            onChange: (e) => {
                              d("achievementsLeaderboards", e);
                            },
                          }),
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.platformUpdates",
                            value: !!c?.platformUpdates,
                            onChange: (e) => {
                              d("platformUpdates", e);
                            },
                          }),
                        ],
                      }),
                  (0, r.jsx)(eD.iI, {
                    sx: { mt: 2.5 },
                    children: (0, r.jsx)(u.cC, {
                      id: "friends.upDrawer.notificationPreferences.site",
                    }),
                  }),
                  (0, r.jsx)(eD.dA, {
                    sx: { mt: 1 },
                    children: (0, r.jsx)(u.cC, {
                      id: "friends.upDrawer.notificationPreferences.siteInfo",
                    }),
                  }),
                  x
                    ? h(246)
                    : (0, r.jsxs)(td.zC, {
                        sx: {
                          mt: 2,
                          display: "flex",
                          flexDirection: "column",
                          gap: 1,
                        },
                        children: [
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.interactive",
                            value: !!c.interactiveNotifications,
                            onChange: (e) => {
                              d("interactiveNotifications", e);
                            },
                          }),
                          (0, r.jsx)(ts, {
                            textLabel:
                              "friends.upDrawer.notificationPreferences.informational",
                            value: !!c.informationalNotifications,
                            onChange: (e) => {
                              d("informationalNotifications", e);
                            },
                          }),
                        ],
                      }),
                ],
              }),
            });
          };
        var t2 = n(8379),
          t3 = n(22405),
          t6 = n.n(t3);
        let t5 = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              { spacing: t } = (0, a.Z)(),
              { gameInviteLink: n } = i.useContext(tp.DN),
              o = i.useRef(null),
              [s, l] = i.useState(!1),
              c = () => {
                o.current
                  ? (o.current?.select(), document.execCommand("copy"), l(!0))
                  : console.error("Missing profile link ref");
              };
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(w.Z, {
                  title: eh.ag._({ id: "friends.upDrawer.friends.title" }),
                }),
                (0, r.jsx)("div", {
                  style: {
                    width: 600,
                    height: 600,
                    top: -236,
                    left: -100,
                    position: "absolute",
                    borderRadius: 940,
                    background:
                      "radial-gradient(50% 50% at 50% 50%, #560696 0%, rgba(26, 27, 40, 0.00) 100%)",
                    zIndex: 1,
                  },
                }),
                (0, r.jsx)("div", {
                  style: {
                    background: "#121B3A",
                    width: "100%",
                    height: "100%",
                    position: "absolute",
                    zIndex: 0,
                  },
                }),
                (0, r.jsxs)("div", {
                  style: {
                    position: "absolute",
                    zIndex: 2,
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    marginTop: 120,
                  },
                  children: [
                    (0, r.jsx)("div", {
                      style: { width: 227, height: 227 },
                      children: (0, r.jsx)("img", {
                        src: (0, x.ZP)(
                          "crazygames/friends/BringYourFriends2.svg",
                          {},
                          !1
                        ),
                        alt: "Bring your friends",
                        style: { width: 227 },
                      }),
                    }),
                    (0, r.jsx)(eD.mH, {
                      sx: { fontWeight: 900, mt: 3, lineHeight: "135%" },
                      children: (0, r.jsx)(u.cC, {
                        id: "friends.upDrawer.friends.guestTitle",
                      }),
                    }),
                    (0, r.jsx)(eD.X0, {
                      sx: { mt: 1, mb: 3, maxWidth: 300 },
                      children: (0, r.jsx)(u.cC, {
                        id: "friends.upDrawer.friends.guestSubtitle",
                      }),
                    }),
                    (0, r.jsx)(X.Z, {
                      variant: "contained",
                      color: "purple",
                      className: t6().button,
                      height: 50,
                      onClick: () => e("signIn"),
                      children: (0, r.jsx)(u.cC, {
                        id: "friends.upDrawer.friends.guestButton",
                      }),
                    }),
                    n &&
                      (0, r.jsxs)(r.Fragment, {
                        children: [
                          (0, r.jsx)("div", {
                            style: {
                              fontWeight: 400,
                              fontSize: 18,
                              color: f.D.white[60],
                              marginTop: t(1.5),
                            },
                            children: (0, r.jsx)(u.cC, {
                              id: "friends.upDrawer.or",
                            }),
                          }),
                          (0, r.jsx)("input", {
                            readOnly: !0,
                            ref: o,
                            value: n,
                            style: {
                              position: "fixed",
                              top: -9999,
                              marginBottom: t(1.5),
                            },
                          }),
                          (0, r.jsxs)(X.Z, {
                            className: t6().button,
                            variant: "outlined",
                            onClick: c,
                            height: 50,
                            children: [
                              (0, r.jsx)(t2.Z, {}),
                              (0, r.jsx)(u.cC, {
                                id: s
                                  ? "friends.upDrawer.gameInviteLink.copied"
                                  : "friends.upDrawer.inviteFriends.copyInviteLink",
                              }),
                            ],
                          }),
                        ],
                      }),
                  ],
                }),
                (0, r.jsx)(eD.qt, { sx: { p: 2, flexDirection: "column" } }),
              ],
            });
          },
          t7 = () => {
            let [e, { loading: t }] = Y.RS(),
              [n, o] = i.useState(!1),
              { gameInviteLink: s } = i.useContext(tp.DN),
              { openDrawer: a } = i.useContext(p.s9),
              l = i.useRef(null),
              d = () => {
                l.current
                  ? (l.current?.select(), document.execCommand("copy"), o(!0))
                  : console.error("Missing profile link ref");
              };
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(w.Z, {
                  title: eh.ag._({
                    id: "friends.upDrawer.inviteFriends.title",
                  }),
                }),
                t
                  ? (0, r.jsx)(td.sX, {
                      sx: { top: 57, width: 1 },
                      children: (0, r.jsx)(tr.Z, {
                        color: "secondary",
                        size: 60,
                      }),
                    })
                  : (0, r.jsxs)(eD.qt, {
                      sx: { p: 2, flexDirection: "column", height: "100%" },
                      children: [
                        s &&
                          (0, r.jsxs)(r.Fragment, {
                            children: [
                              (0, r.jsx)("input", {
                                readOnly: !0,
                                ref: l,
                                value: s,
                                style: { position: "fixed", top: -9999 },
                              }),
                              (0, r.jsxs)(X.Z, {
                                variant: "contained",
                                onClick: d,
                                children: [
                                  (0, r.jsx)(t2.Z, {}),
                                  (0, r.jsx)(u.cC, {
                                    id: n
                                      ? "friends.upDrawer.gameInviteLink.copied"
                                      : "friends.upDrawer.inviteFriends.copyInviteLink",
                                  }),
                                ],
                              }),
                            ],
                          }),
                        (0, r.jsx)(c.Z, {
                          sx: { borderColor: f.D.black[60], mt: 3 },
                        }),
                        e && e.length > 0
                          ? (0, r.jsx)(tZ, {
                              friends: e,
                              splitOnlineOffline: !0,
                              origin: "inviteFriendsDrawer",
                              inviteLink: s || void 0,
                            })
                          : (0, r.jsxs)("div", {
                              style: {
                                width: "100%",
                                display: "flex",
                                flexDirection: "column",
                                justifyContent: "center",
                                alignItems: "center",
                                marginTop: 120,
                              },
                              children: [
                                (0, r.jsx)("div", {
                                  style: { width: 227, height: 227 },
                                  children: (0, r.jsx)("img", {
                                    src: (0, x.ZP)(
                                      "crazygames/friends/BringYourFriends2.svg",
                                      {},
                                      !1
                                    ),
                                    alt: "Bring your friends",
                                    style: { width: 227 },
                                  }),
                                }),
                                (0, r.jsx)(eD.mH, {
                                  sx: {
                                    fontWeight: 900,
                                    mt: 3,
                                    lineHeight: "135%",
                                  },
                                  children: (0, r.jsx)(u.cC, {
                                    id: "friends.upDrawer.inviteFriends.noFriendsTitle",
                                  }),
                                }),
                                (0, r.jsx)(eD.X0, {
                                  sx: {
                                    mt: 1,
                                    mb: 3,
                                    maxWidth: 300,
                                    "& span.link": {
                                      color: f.D.brand[60],
                                      fontWeight: 700,
                                      cursor: "pointer",
                                    },
                                  },
                                  children: (0, r.jsx)(u.cC, {
                                    id: "friends.upDrawer.inviteFriends.noFriendsSubtitle",
                                    values: {
                                      searchingLink: (0, r.jsx)("span", {
                                        className: "link",
                                        onClick: () =>
                                          a("friends", {
                                            isExiting: !1,
                                            returnToDrawer: "inviteFriends",
                                          }),
                                        children: (0, r.jsx)(u.cC, {
                                          id: "friends.upDrawer.inviteFriends.noFriendsSubtitleSearching",
                                        }),
                                      }),
                                      profileLink: (0, r.jsx)("span", {
                                        className: "link",
                                        onClick: () =>
                                          a("shareProfile", {
                                            isExiting: !1,
                                            returnToDrawer: "inviteFriends",
                                          }),
                                        children: (0, r.jsx)(u.cC, {
                                          id: "friends.upDrawer.inviteFriends.noFriendsSubtitleProfileLink",
                                        }),
                                      }),
                                    },
                                  }),
                                }),
                              ],
                            }),
                      ],
                    }),
              ],
            });
          };
        var t4 = n(92512),
          t9 = n(55260),
          t8 = n(58947);
        let ne = i.memo((e) =>
          (0, r.jsx)(g.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, r.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M8 4C8 2.89543 8.89543 2 10 2H14C15.1046 2 16 2.89543 16 4V6H18.9883C18.9953 5.99993 19.0024 5.99993 19.0095 6H20C20.5523 6 21 6.44772 21 7C21 7.55228 20.5523 8 20 8H19.9201L18.997 19.0778C18.8882 20.5542 17.6582 22 16 22H8C6.34175 22 5.11178 20.5542 5.00301 19.0778L4.07987 8H4C3.44772 8 3 7.55228 3 7C3 6.44772 3.44772 6 4 6H4.99054C4.9976 5.99993 5.00466 5.99993 5.0117 6H8V4ZM6.0868 8L6.99753 18.9287C7.04142 19.5433 7.56213 20 8 20H16C16.4379 20 16.9586 19.5433 17.0025 18.9288L17.0034 18.9169L17.9132 8H6.0868ZM14 6H10V4H14V6ZM10 10C10.5523 10 11 10.4477 11 11V17C11 17.5523 10.5523 18 10 18C9.44772 18 9 17.5523 9 17V11C9 10.4477 9.44772 10 10 10ZM14 10C14.5523 10 15 10.4477 15 11V17C15 17.5523 14.5523 18 14 18C13.4477 18 13 17.5523 13 17V11C13 10.4477 13.4477 10 14 10Z",
            }),
          })
        );
        var nt = n(48112),
          nn = n(96034);
        let nr = (e) => {
          let { notificationId: t } = e,
            [n, o] = i.useState(null),
            s = i.useRef(null),
            a = Boolean(n),
            { removeNotification: l } = i.useContext(t4.c),
            [c] = (0, e0.D)(nn.TW),
            d = {
              label: (0, r.jsxs)(r.Fragment, {
                children: [
                  (0, r.jsx)(ne, {}),
                  (0, r.jsx)(u.cC, { id: "friends.notifications.menu.remove" }),
                ],
              }),
              value: "remove",
              action: async () => {
                let { data: e } = await c({ variables: { input: { id: t } } });
                e?.removeNotification.success && l(t);
              },
            },
            h = (e) => {
              e.stopPropagation(),
                e.preventDefault(),
                i.startTransition(() => {
                  Boolean(n) ? o(null) : o(e.currentTarget);
                });
            },
            p = () => {
              i.startTransition(() => {
                o(null);
              });
            };
          return (0, r.jsxs)("div", {
            style: { position: "relative" },
            children: [
              (0, r.jsx)(j.Qh, {
                style: { width: 34, height: 34 },
                onPointerDown: h,
                onClick: (e) => e.stopPropagation(),
                children: (0, r.jsx)(nt.Z, {
                  style: { color: f.D.white[10], height: 20, width: 20 },
                  className: "dotsHori",
                }),
              }),
              (0, r.jsx)(t9.Z, {
                actions: s,
                open: a,
                onClose: p,
                anchorEl: n,
                slots: { root: eA.dK, listbox: eA.c6 },
                slotProps: { root: { placement: "bottom" } },
                children: [d].map((e, t) =>
                  (0, r.jsx)(
                    t8.Z,
                    {
                      onClick: (t) => {
                        t.stopPropagation(), e.action(), p();
                      },
                      style: {
                        outline: 0,
                        ...(e.color ? { color: e.color } : void 0),
                      },
                      children: e.label,
                    },
                    t
                  )
                ),
              }),
            ],
          });
        };
        var ni = n(68888),
          no = n(53059);
        let ns = (e) => {
            let { id: t, data: n, createdAt: o, fromUser: s, game: a } = e,
              { openDrawer: l } = i.useContext(p.s9),
              { pageUrlHelper: c } = i.useContext(q.t),
              [d, h] = i.useState(n.status ?? null),
              { onAcceptClick: y, onDeclineClick: g } = (0, ni.Z)(),
              m = i.useContext(P.Z).routeHelper,
              C = (t) => {
                t.stopPropagation(),
                  y(e, () => {
                    h("accepted"), l(null);
                  });
              },
              _ = (t) => {
                t.stopPropagation(), g(e, () => h("declined"));
              },
              w = (0, no.q)(e),
              v = "accepted" !== d && "declined" !== d && !w,
              j = c.isProfilePageWithUsername(s.username),
              B = () => {
                j || window.open(`/uid/${s.id}`, "_blank");
              };
            return (0, r.jsx)(r.Fragment, {
              children: (0, r.jsxs)(er.Z, {
                sx: {
                  background: v ? f.D.brand[160] : f.D.black[80],
                  display: "flex",
                  width: 1,
                  py: 2,
                  pr: 2.5,
                  borderBottom: `1px solid ${
                    v ? f.D.black[80] : f.D.black[60]
                  }`,
                  "&:hover": j
                    ? void 0
                    : {
                        cursor: "pointer",
                        background: v ? f.D.brand[140] : f.D.black[90],
                      },
                },
                onClick: B,
                children: [
                  (0, r.jsx)(er.Z, {
                    sx: {
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      px: 2.5,
                      "&:hover": j ? void 0 : { cursor: "pointer" },
                    },
                    onClick: B,
                    children: (0, r.jsx)(td.bw, {
                      src: (0, x.ZP)(s.profile.avatar, {
                        width: 100,
                        height: 100,
                      }),
                      alt: "Avatar",
                      sx: {
                        width: 50,
                        height: 50,
                        m: 0,
                        "& img": { width: 50, height: 50 },
                      },
                    }),
                  }),
                  (0, r.jsxs)("div", {
                    style: { width: "100%" },
                    children: [
                      a.gameSlug &&
                        (0, r.jsx)(er.Z, {
                          sx: { fontSize: 14, lineHeight: "135%", mb: 1 },
                          children: (0, r.jsx)(u.cC, {
                            id: "friends.upDrawer.notifications.userInvitedToPlay",
                            values: {
                              user: j
                                ? (0, r.jsx)("span", {
                                    style: { fontWeight: 700 },
                                    children: s.username,
                                  })
                                : (0, r.jsx)(V.Z, {
                                    href: m.profilePageLink(s.username).href,
                                    as: m.profilePageLink(s.username).as,
                                    children: (0, r.jsx)("span", {
                                      style: { fontWeight: 700 },
                                      children: s.username,
                                    }),
                                  }),
                              game: (0, r.jsx)(ty.Z, {
                                slug: a.gameSlug,
                                children: (0, r.jsx)("span", {
                                  style: { cursor: "pointer", fontWeight: 700 },
                                  children: a.gameName,
                                }),
                              }),
                            },
                          }),
                        }),
                      v
                        ? (0, r.jsxs)(er.Z, {
                            sx: {
                              width: 1,
                              display: "flex",
                              gap: 2,
                              "& button": { fontSize: 14, width: "50%" },
                            },
                            children: [
                              (0, r.jsx)(X.Z, {
                                variant: "contained",
                                height: 34,
                                onClick: C,
                                children: (0, r.jsx)(u.cC, {
                                  id: "friends.upDrawer.notifications.accept",
                                }),
                              }),
                              (0, r.jsx)(X.Z, {
                                variant: "outlined",
                                height: 34,
                                color: "white",
                                onClick: _,
                                children: (0, r.jsx)(u.cC, {
                                  id: "friends.upDrawer.notifications.decline",
                                }),
                              }),
                            ],
                          })
                        : (0, r.jsx)("div", {
                            style: {
                              fontSize: 14,
                              color: f.D.white[10],
                              fontWeight: 400,
                            },
                            children: (0, r.jsx)(u.cC, {
                              id: ((e) => {
                                switch (e) {
                                  case "accepted":
                                    return "friends.upDrawer.notifications.acceptedInvite";
                                  case "declined":
                                    return "friends.upDrawer.notifications.declinedInvite";
                                  default:
                                    return "friends.upDrawer.notifications.expiredInvite";
                                }
                              })(d),
                              values: { user: s.username },
                            }),
                          }),
                    ],
                  }),
                  (0, r.jsxs)(er.Z, {
                    sx: {
                      pl: 2,
                      "& svg": {
                        color: f.D.white[50],
                        "&:hover": { cursor: "pointer", color: f.D.white[30] },
                      },
                    },
                    children: [
                      (0, r.jsx)(er.Z, {
                        sx: { ml: 1 },
                        children: (0, r.jsx)(tI, { timestamp: o }),
                      }),
                      (0, r.jsx)("div", {
                        children: (0, r.jsx)(nr, { notificationId: t }),
                      }),
                    ],
                  }),
                ],
              }),
            });
          },
          na = () => {
            let { notifications: e } = i.useContext(t4.c),
              { openDrawer: t } = i.useContext(p.s9);
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(w.Z, {
                  title: eh.ag._({
                    id: "friends.upDrawer.notifications.title",
                  }),
                  customLeftIcon: (0, r.jsx)(j.Qh, {
                    color: "white",
                    onClick: () =>
                      t("notificationPreferences", {
                        returnToDrawer: "notifications",
                      }),
                    sx: { ml: 1 },
                    children: (0, r.jsx)(m, {}),
                  }),
                }),
                (0, r.jsx)(eD.qt, {
                  sx: {
                    flexDirection: "column",
                    height: "100%",
                    alignItems: "center",
                  },
                  children:
                    e.length > 0
                      ? e.map((e) =>
                          "GAME_INVITE" === e.type
                            ? (0, i.createElement)(ns, {
                                ...e,
                                key: `${e.id}_${e.data.status}`,
                              })
                            : (console.error(
                                `Unknown notification type ${e.type}`
                              ),
                              null)
                        )
                      : (0, r.jsx)(td.sX, {
                          sx: { top: 50 },
                          children: (0, r.jsxs)("div", {
                            children: [
                              (0, r.jsx)("div", {
                                style: { fontSize: 30 },
                                children: "\uD83D\uDE34",
                              }),
                              (0, r.jsx)("div", {
                                style: { fontWeight: 800, fontSize: 16 },
                                children: (0, r.jsx)(u.cC, {
                                  id: "friends.upDrawer.notifications.noNotificationsMsg",
                                }),
                              }),
                            ],
                          }),
                        }),
                }),
              ],
            });
          },
          nl = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 101 100",
              children: (0, r.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M50.4923 16.6668L50.5 16.6667C52.3374 16.6668 54.1365 16.8652 55.8796 17.2443C57.0637 17.5019 57.8176 18.6835 57.5634 19.8835C57.3092 21.0834 56.1432 21.8474 54.959 21.5898C53.5166 21.276 52.0273 21.1115 50.5038 21.1112C48.7076 21.1177 47.21 21.1588 45.8122 21.346C44.6115 21.5069 43.5094 20.651 43.3507 19.4343C43.1919 18.2176 44.0366 17.1008 45.2373 16.9399C46.9331 16.7127 48.6701 16.6733 50.4923 16.6668ZM38.2479 21.7933C38.9862 22.7661 38.8065 24.1613 37.8465 24.9095C36.767 25.7508 35.5965 26.7881 34.2972 28.0714C33.451 28.9073 32.6615 29.8047 31.9426 30.7481C31.2024 31.7195 29.8252 31.8989 28.8666 31.1487C27.908 30.3986 27.731 29.0031 28.4712 28.0317C29.3164 26.9227 30.2429 25.8695 31.2358 24.8888C32.6292 23.5124 33.9294 22.3554 35.1726 21.3865C36.1327 20.6383 37.5095 20.8204 38.2479 21.7933ZM62.6262 22.1812C63.3297 21.1822 64.6993 20.9502 65.6852 21.6631C68.5614 23.7429 71.0621 26.3913 73.0601 29.4583C73.7274 30.4826 73.4489 31.861 72.4382 32.5372C71.4274 33.2134 70.0671 32.9312 69.3998 31.9069C67.6881 29.2795 65.5599 27.0325 63.1375 25.2809C62.1516 24.568 61.9227 23.1803 62.6262 22.1812ZM27.2234 34.0915C28.3638 34.5048 28.9576 35.7767 28.5498 36.9323C28.1553 38.0499 27.873 39.1722 27.7126 40.2817L27.4997 41.7549L26.0742 42.1157C24.189 42.5928 22.4133 43.4406 20.8151 44.599C19.83 45.313 18.4602 45.0826 17.7556 44.0844C17.051 43.0861 17.2784 41.6981 18.2635 40.9841C19.9026 39.796 21.7065 38.8534 23.6307 38.209C23.8331 37.2726 24.0986 36.346 24.42 35.4355C24.8279 34.2799 26.083 33.6782 27.2234 34.0915ZM74.652 37.6841C75.827 37.3865 77.0176 38.1104 77.3113 39.3011C77.6048 40.491 77.8354 41.7095 77.999 42.9521C79.7345 43.416 81.3737 44.1489 82.8768 45.1055C83.9025 45.7582 84.2117 47.1299 83.5676 48.1692C82.9234 49.2086 81.5698 49.5219 80.5441 48.8692C79.0455 47.9155 77.39 47.2676 75.6439 46.9847L73.9474 46.7099L73.8048 44.9748C73.675 43.3958 73.4216 41.8599 73.0563 40.3788C72.7626 39.1882 73.477 37.9817 74.652 37.6841ZM12.6362 51.504C13.7946 51.8623 14.447 53.1043 14.0935 54.2782C13.5282 56.155 13.2193 58.1735 13.2193 60.2837C13.2193 62.7373 13.6367 65.0652 14.3892 67.1903C14.7982 68.3455 14.2056 69.6179 13.0656 70.0324C11.9257 70.4469 10.6699 69.8464 10.2609 68.6912C9.33832 66.0857 8.83337 63.2501 8.83337 60.2837C8.83337 57.7327 9.20691 55.2771 9.89854 52.9808C10.2521 51.8069 11.4778 51.1458 12.6362 51.504ZM88.3528 54.6012C89.5051 54.2232 90.7415 54.8634 91.1145 56.0311C91.7967 58.1671 92.1667 60.4646 92.1667 62.8575C92.1667 65.489 91.7189 68.0052 90.9003 70.3179C90.4913 71.4731 89.2357 72.0737 88.0956 71.6593C86.9556 71.2449 86.3629 69.9725 86.7719 68.8173C87.4204 66.985 87.7807 64.9764 87.7807 62.8575C87.7807 60.9302 87.483 59.0944 86.9416 57.3997C86.5687 56.232 87.2005 54.9791 88.3528 54.6012ZM20.2591 78.4201C20.7835 77.3138 22.0937 76.8479 23.1854 77.3793C25.1868 78.3536 27.3835 78.889 29.6826 78.889H35.1756C36.3868 78.889 37.3686 79.8839 37.3686 81.1112C37.3686 82.3385 36.3868 83.3334 35.1756 83.3334H29.6826C26.7012 83.3334 23.8574 82.6371 21.2861 81.3854C20.1944 80.854 19.7346 79.5264 20.2591 78.4201ZM82.1288 78.6326C82.6534 79.7387 82.1938 81.0665 81.1022 81.5981C78.8134 82.7129 76.2811 83.3334 73.6267 83.3334H68.1337C66.9225 83.3334 65.9407 82.3385 65.9407 81.1112C65.9407 79.8839 66.9225 78.889 68.1337 78.889H73.6267C75.5982 78.889 77.4832 78.4296 79.2022 77.5924C80.2939 77.0607 81.6041 77.5264 82.1288 78.6326ZM43.9687 81.1112C43.9687 79.8839 44.9505 78.889 46.1616 78.889H57.1477C58.3588 78.889 59.3406 79.8839 59.3406 81.1112C59.3406 82.3385 58.3588 83.3334 57.1477 83.3334H46.1616C44.9505 83.3334 43.9687 82.3385 43.9687 81.1112Z",
              }),
            })
          ),
          nc = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 101 100",
              children: (0, r.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M31.7812 24.8001C36.9869 19.5767 43.6262 16.6918 50.5 16.6667C64.5104 16.6667 76.1406 28.788 77.4062 44.4183C85.6979 45.7819 92.1666 53.8607 92.1666 63.7758C92.1666 74.6607 84.3646 83.3334 74.9114 83.3334H28.526C17.7291 83.3334 8.83331 73.4304 8.83331 61.0183C8.83331 50.3334 15.4271 41.4849 24.1562 39.2425C24.901 34.0122 27.7916 28.8001 31.7812 24.8001ZM45.3273 28.4542C46.1172 27.5814 47.2394 27.0834 48.4166 27.0834H52.5833C54.8845 27.0834 56.75 28.9489 56.75 31.2501C56.75 32.0215 56.5906 33.8372 56.4057 35.7792C56.2084 37.8505 55.9463 40.4056 55.6854 42.8842C55.4243 45.3651 55.1632 47.7795 54.9676 49.573C54.8697 50.47 54.7882 51.2121 54.7311 51.7302L54.6416 52.5399C54.4061 54.6588 52.6089 56.2617 50.4771 56.25C48.3453 56.2383 46.5661 54.6193 46.354 52.498L44.2707 31.6647C44.1535 30.4933 44.5374 29.3271 45.3273 28.4542ZM46.3333 68.7501C46.3333 71.0513 48.1988 72.9167 50.5 72.9167C52.8012 72.9167 54.6666 71.0513 54.6666 68.7501V66.6667C54.6666 64.3656 52.8012 62.5001 50.5 62.5001C48.1988 62.5001 46.3333 64.3656 46.3333 66.6667V68.7501Z",
                fill: "#FFAC4A",
              }),
            })
          ),
          nd = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 101 100",
              children: (0, r.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M31.7813 24.8001C36.9869 19.5767 43.6263 16.6918 50.5 16.6667C64.5104 16.6667 76.1406 28.788 77.4063 44.4183C85.6979 45.7819 92.1667 53.8607 92.1667 63.7758C92.1667 74.6607 84.3646 83.3334 74.9115 83.3334H28.5261C17.7292 83.3334 8.83334 73.4304 8.83334 61.0183C8.83334 50.3334 15.4271 41.4849 24.1563 39.2425C24.9011 34.0122 27.7917 28.8001 31.7813 24.8001ZM45.3273 28.4542C46.1172 27.5814 47.2395 27.0834 48.4167 27.0834H52.5833C54.8845 27.0834 56.75 28.9489 56.75 31.2501C56.75 32.0215 56.5907 33.8372 56.4057 35.7792C56.2085 37.8505 55.9464 40.4056 55.6855 42.8842C55.4243 45.3651 55.1633 47.7795 54.9676 49.573C54.8698 50.47 54.7882 51.2121 54.7311 51.7302L54.6416 52.5399C54.4062 54.6588 52.609 56.2617 50.4771 56.25C48.3453 56.2383 46.5662 54.6193 46.354 52.498L44.2707 31.6647C44.1536 30.4933 44.5374 29.3271 45.3273 28.4542ZM46.3333 68.7501C46.3333 71.0513 48.1988 72.9167 50.5 72.9167C52.8012 72.9167 54.6667 71.0513 54.6667 68.7501V66.6667C54.6667 64.3656 52.8012 62.5001 50.5 62.5001C48.1988 62.5001 46.3333 64.3656 46.3333 66.6667V68.7501Z",
                fill: "#F16E9D",
              }),
            })
          ),
          nu = i.memo((e) =>
            (0, r.jsx)(g.Z, {
              ...e,
              viewBox: "0 0 101 100",
              children: (0, r.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M50.5 16.6667C43.6263 16.6918 36.9869 19.5767 31.7813 24.8001C27.7917 28.8001 24.9011 34.0122 24.1563 39.2425C15.4271 41.4849 8.83337 50.3334 8.83337 61.0183C8.83337 73.4304 17.7292 83.3334 28.5261 83.3334H74.9115C84.3646 83.3334 92.1667 74.6607 92.1667 63.7758C92.1667 53.8607 85.698 45.7819 77.4063 44.4183C76.1407 28.788 64.5105 16.6667 50.5 16.6667ZM66.2537 48.4362C67.6912 46.6393 67.3999 44.0172 65.6029 42.5797C63.806 41.1422 61.184 41.4335 59.7464 43.2304L45.947 60.4797L36.7379 51.5264C35.0879 49.9223 32.45 49.9594 30.8459 51.6094C29.2418 53.2593 29.2789 55.8972 30.9289 57.5014L43.4289 69.6541C44.2713 70.4732 45.4204 70.8985 46.5931 70.8252C47.7658 70.752 48.853 70.187 49.587 69.2695L66.2537 48.4362Z",
                fill: "#4AF0A7",
              }),
            })
          ),
          nh = () => {
            let { openedDrawer: e } = i.useContext(p.rf),
              { openDrawer: t } = i.useContext(p.s9),
              { progressIconStatus: n } = i.useContext(tp.DN),
              { crazyAnalyticsService: o } = i.useContext(U.Z).services,
              s = e?.returnToDrawer ? e.returnToDrawer : null,
              a = () => {
                t("progressDelete", {
                  isExiting: !1,
                  returnToDrawer: "progressStatus",
                });
              };
            i.useEffect(() => {
              o.userAction("progress", "progress-delete-show");
            }, [o]);
            let l = n?.lastSaveAt
              ? (0, r.jsx)("div", {
                  style: { display: "flex", justifyContent: "center" },
                  children: (0, r.jsxs)(X.Z, {
                    variant: "link",
                    color: "white",
                    onClick: a,
                    children: [
                      (0, r.jsx)(ne, {}),
                      (0, r.jsx)(u.cC, {
                        id: "common.upDrawer.progressStatus.deleteProgress",
                      }),
                    ],
                  }),
                })
              : null;
            return (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(w.Z, {
                  title: eh.ag._({
                    id: "common.upDrawer.progressStatus.title",
                  }),
                  onBack: s
                    ? () => {
                        t(s, { isExiting: !0 });
                      }
                    : void 0,
                }),
                (0, r.jsxs)(eD.qt, {
                  sx: { p: 3.75, flexGrow: 1, flexDirection: "column" },
                  children: [
                    (0, r.jsx)("div", {
                      style: {
                        width: "100%",
                        alignItems: "center",
                        display: "flex",
                        flexGrow: 1,
                      },
                      children: (0, r.jsx)("div", {
                        style: { width: "100%", textAlign: "center" },
                        children: (() => {
                          let e = n?.lastSaveAt
                            ? (0, r.jsxs)(r.Fragment, {
                                children: [
                                  (0, r.jsxs)("div", {
                                    style: {
                                      fontWeight: 700,
                                      fontSize: 16,
                                      color: f.D.white[40],
                                    },
                                    children: [
                                      (0, r.jsx)(u.cC, {
                                        id: "common.upDrawer.progressStatus.latestSave",
                                      }),
                                      ":",
                                    ],
                                  }),
                                  (0, r.jsx)("div", {
                                    style: {
                                      fontWeight: 700,
                                      fontSize: 20,
                                      color: f.D.white[100],
                                    },
                                    children: eh.ag.date(n.lastSaveAt, {
                                      month: "short",
                                      day: "2-digit",
                                      hour: "numeric",
                                      minute: "numeric",
                                      hour12: !1,
                                    }),
                                  }),
                                ],
                              })
                            : null;
                          switch (n?.status) {
                            case "synced-warning":
                              return (0, r.jsxs)(r.Fragment, {
                                children: [
                                  (0, r.jsx)(nc, {
                                    style: { width: 100, height: 100 },
                                  }),
                                  e,
                                  (0, r.jsx)("div", {
                                    children: (0, r.jsx)(u.cC, {
                                      id: "common.upDrawer.progressStatus.warning",
                                    }),
                                  }),
                                ],
                              });
                            case "synced-error":
                              return (0, r.jsxs)(r.Fragment, {
                                children: [
                                  (0, r.jsx)(nd, {
                                    style: {
                                      color: f.D.white[10],
                                      width: 100,
                                      height: 100,
                                    },
                                  }),
                                  e,
                                  (0, r.jsx)("div", {
                                    children: (0, r.jsx)(u.cC, {
                                      id: "common.upDrawer.progressStatus.error",
                                    }),
                                  }),
                                ],
                              });
                            case "synced-success":
                            case "synced":
                              if (!n?.lastSaveAt)
                                return (0, r.jsxs)(r.Fragment, {
                                  children: [
                                    (0, r.jsx)(nl, {
                                      style: {
                                        color: f.D.white[10],
                                        width: 100,
                                        height: 100,
                                      },
                                    }),
                                    (0, r.jsx)("div", {
                                      style: {
                                        fontWeight: 700,
                                        fontSize: 20,
                                        color: f.D.white[100],
                                      },
                                      children: (0, r.jsx)(u.cC, {
                                        id: "common.upDrawer.progressStatus.noProgress",
                                      }),
                                    }),
                                  ],
                                });
                              return (0, r.jsxs)(r.Fragment, {
                                children: [
                                  (0, r.jsx)(nu, {
                                    style: {
                                      color: f.D.white[10],
                                      width: 100,
                                      height: 100,
                                    },
                                  }),
                                  e,
                                ],
                              });
                            default:
                              return (0, r.jsxs)(r.Fragment, {
                                children: [
                                  (0, r.jsx)(nl, {
                                    style: {
                                      color: f.D.white[10],
                                      width: 100,
                                      height: 100,
                                    },
                                  }),
                                  (0, r.jsx)("div", {
                                    style: {
                                      fontWeight: 700,
                                      fontSize: 20,
                                      color: f.D.white[100],
                                    },
                                    children: (0, r.jsx)(u.cC, {
                                      id: "common.upDrawer.progressStatus.noProgress",
                                    }),
                                  }),
                                ],
                              });
                          }
                        })(),
                      }),
                    }),
                    l,
                  ],
                }),
              ],
            });
          },
          np = i.memo((e) =>
            (0, r.jsxs)(g.Z, {
              ...e,
              viewBox: "0 0 151 105",
              children: [
                (0, r.jsx)("path", {
                  d: "M123.141 29.7865C123.635 22.5608 126.566 11.2072 123.148 8.06921C120.78 5.07641 110.932 6.03339 106.922 9.58357C100.694 6.17626 92.9385 4.28887 83.4248 3.86144C73.9111 3.43401 66.024 4.62569 59.5229 7.45402C55.8344 3.55089 50.1189 -1.53544 47.4915 1.2329C42.7028 6.27991 41.7091 18.8233 41.5527 26.0712C39.2436 31.641 37.9052 38.2046 37.5659 45.7564C36.853 61.6243 40.8427 73.576 49.4138 81.3295C55.1871 86.539 62.8912 89.736 72.8308 91.0407C71.6363 91.5757 70.4002 92.0946 69.1258 92.6827L65.4288 94.3037L63.3286 95.2235C61.2901 96.1815 59.1937 97.0164 56.9228 98.2831L56.3609 98.5486C56.201 98.6549 56.0447 98.8393 56.007 99.0504C55.9185 99.4506 56.1758 99.8452 56.5743 99.9198C58.5732 100.315 60.5467 100.8 62.5794 101.069L64.0917 101.307C64.5888 101.386 65.0935 101.451 65.606 101.503L68.6523 101.81C72.7374 102.064 76.8641 102.023 80.9743 101.562C85.0763 101.129 89.1317 100.163 93.0523 98.7432C96.9518 97.3228 100.711 95.4137 104.139 93.036C110.942 88.2 116.417 81.5244 119.838 73.9621C121.089 71.2242 122.057 68.367 122.794 65.457C124.223 60.7981 125.079 55.546 125.342 49.7C125.68 42.1765 124.935 35.5334 123.148 29.7868L123.141 29.7865Z",
                  fill: "#6842FF",
                }),
                (0, r.jsx)("path", {
                  d: "M97.0757 90.1729C91.9495 91.4319 86.1111 91.9071 79.4755 91.609L79.4614 91.6084C78.8351 91.5803 78.1881 91.5441 77.5417 91.4938C76.213 91.4057 74.9281 91.2842 73.6727 91.1356C73.3851 91.1014 73.0976 91.0672 72.8241 91.0336C71.6299 91.5615 70.3935 92.0875 69.1191 92.6756L65.4221 94.2966C67.1269 94.4867 69.1408 94.7048 70.9351 94.7854C81.5676 95.2631 90.1746 93.7421 97.0757 90.1729Z",
                  fill: "#492EB3",
                }),
                (0, r.jsx)("path", {
                  d: "M78.0819 78.405C94.9062 77.8122 105.938 72.6596 105.119 49.4008C104.732 38.4192 101.958 31.0947 96.6686 27.0134C92.1915 23.5699 85.456 22.0421 76.1076 22.3715C66.7592 22.7008 60.1474 24.6848 55.9242 28.4491C50.9213 32.8859 48.684 40.4012 49.0706 51.3757C49.8902 74.6345 61.2576 78.9978 78.0819 78.405Z",
                  fill: "white",
                }),
                (0, r.jsx)("rect", {
                  width: "12.605",
                  height: "24.7212",
                  rx: "6.30251",
                  transform:
                    "matrix(0.998268 -0.0588294 0.0196847 0.999806 59.6441 38.9656)",
                  fill: "#6842FF",
                }),
                (0, r.jsx)("rect", {
                  width: "12.605",
                  height: "24.7212",
                  rx: "6.30251",
                  transform:
                    "matrix(0.99722 -0.0745197 0.0354039 0.999373 77.2536 38.5903)",
                  fill: "#6842FF",
                }),
                (0, r.jsx)("ellipse", {
                  cx: "3.67327",
                  cy: "3.70346",
                  rx: "3.67327",
                  ry: "3.70346",
                  transform:
                    "matrix(0.998588 -0.0531167 0.0548527 0.998494 66.4947 38.0464)",
                  fill: "white",
                }),
                (0, r.jsx)("ellipse", {
                  cx: "3.67327",
                  cy: "3.70346",
                  rx: "3.67327",
                  ry: "3.70346",
                  transform:
                    "matrix(0.998588 -0.0531167 0.0548527 0.998494 84.288 38.0464)",
                  fill: "white",
                }),
                (0, r.jsx)("path", {
                  d: "M3.38754 67.0995C3.18532 65.3199 4.57733 63.7607 6.36836 63.7607H40.6994C42.4904 63.7607 43.8824 65.3199 43.6802 67.0995L40.2973 96.8694C39.9527 99.9014 37.3872 102.192 34.3356 102.192H12.7321C9.68053 102.192 7.11504 99.9014 6.77048 96.8694L3.38754 67.0995Z",
                  fill: "#B5B7C6",
                }),
                (0, r.jsx)("rect", {
                  x: "1.23939",
                  y: "48.7957",
                  width: "41.0515",
                  height: "6.11405",
                  rx: "3.05702",
                  transform: "rotate(-9.74729 1.23939 48.7957)",
                  fill: "#B5B7C6",
                }),
                (0, r.jsx)("rect", {
                  x: "16.8557",
                  y: "41.6819",
                  width: "7.86092",
                  height: "7.86092",
                  rx: "3.93046",
                  transform: "rotate(-9.74729 16.8557 41.6819)",
                  fill: "#B5B7C6",
                }),
                (0, r.jsx)("rect", {
                  x: "12.7281",
                  y: "74.2419",
                  width: "4.36718",
                  height: "18.3421",
                  rx: "2.18359",
                  fill: "#9294A5",
                }),
                (0, r.jsx)("rect", {
                  x: "21.3503",
                  y: "69.0012",
                  width: "4.36718",
                  height: "28.8234",
                  rx: "2.18359",
                  fill: "#9294A5",
                }),
                (0, r.jsx)("rect", {
                  x: "30.1968",
                  y: "74.2419",
                  width: "4.36718",
                  height: "18.3421",
                  rx: "2.18359",
                  fill: "#9294A5",
                }),
                (0, r.jsx)("path", {
                  d: "M22.2016 43.5558C18.3877 44.3913 14.6186 41.9768 13.7831 38.1629C12.9476 34.349 15.9924 33.4572 19.8063 32.6217C23.6202 31.7862 26.759 31.3233 27.5945 35.1372C28.43 38.9511 26.0155 42.7202 22.2016 43.5558Z",
                  fill: "#6842FF",
                }),
                (0, r.jsxs)("g", {
                  clipPath: "url(#clip0_1977_869)",
                  children: [
                    (0, r.jsx)("path", {
                      d: "M114.033 89.6303L139.831 94.2217L144.943 92.9136C145.662 82.3955 146.429 74.1043 147.148 63.5861C145.026 64.5858 140.799 66.2114 135.398 65.8281C127.109 65.2393 121.78 60.3266 120.243 58.7978C118.173 69.0755 116.103 79.3531 114.033 89.6303Z",
                      fill: "#D98925",
                    }),
                    (0, r.jsx)("path", {
                      d: "M147.159 63.5881C146.649 65.7584 146.139 67.9288 145.628 70.0997C143.737 78.1477 141.713 86.1721 139.831 94.2217L113.173 89.4772C115.056 81.4278 116.939 73.3782 118.819 65.3283C119.327 63.1575 119.834 60.9867 120.342 58.8153L147.159 63.5881Z",
                      fill: "#F0B76A",
                    }),
                    (0, r.jsx)("path", {
                      d: "M143.911 68.5644L118.89 64.1112C118.313 64.0084 117.999 63.3778 118.266 62.8569C118.958 61.5098 119.65 60.1623 120.342 58.8152L147.159 63.5881C146.386 65.0937 145.613 66.5992 144.84 68.1047C144.665 68.4446 144.289 68.631 143.911 68.5639L143.911 68.5644Z",
                      fill: "#FFCC90",
                    }),
                    (0, r.jsx)("path", {
                      d: "M126.953 73.5088C128.076 72.7529 129.373 72.4687 130.611 72.7077C133.133 73.2039 134.798 75.7978 134.472 78.6564C135.916 79.1955 136.795 80.879 136.444 82.6639C136.058 84.6233 134.346 85.9083 132.645 85.5735L124.294 83.9306C122.351 83.5482 121.1 81.4504 121.54 79.216C121.918 77.2926 123.419 75.9332 125.069 75.8387C125.389 74.9235 126.094 74.0876 126.953 73.5088Z",
                      fill: "#B87A2D",
                    }),
                  ],
                }),
                (0, r.jsx)("path", {
                  d: "M133.732 64.532C130.096 63.1101 128.301 59.0096 129.723 55.3734C131.145 51.7372 134.172 52.6855 137.809 54.1074C141.445 55.5294 144.313 56.8866 142.891 60.5228C141.469 64.159 137.368 65.954 133.732 64.532Z",
                  fill: "#6842FF",
                }),
                (0, r.jsx)("defs", {
                  children: (0, r.jsx)("clipPath", {
                    id: "clip0_1977_869",
                    children: (0, r.jsx)("rect", {
                      width: "32.3171",
                      height: "31.4437",
                      fill: "white",
                      transform: "translate(118.683 58.52) rotate(10.0917)",
                    }),
                  }),
                }),
              ],
            })
          );
        var nx = n(91731),
          ny = n(21046),
          nf = n(57632),
          ng = n(95129),
          nm = n(94213),
          nC = n.n(nm);
        let n_ = () => {
          let { openedDrawer: e } = i.useContext(p.rf),
            { openDrawer: t } = i.useContext(p.s9),
            [n, o] = i.useState("delete-pending"),
            [s] = (0, e0.D)(ny.dO, {
              onCompleted: () => {
                o("delete-success");
              },
              onError: () => {
                o("delete-failed");
              },
            }),
            a = i.useContext(tp.DN).playingGame,
            l = i.useContext(eo.Z),
            { crazyAnalyticsService: c } = i.useContext(U.Z).services,
            d = (0, eo.c)(l),
            h = i.useContext(ng.Z),
            x = e?.returnToDrawer ? e.returnToDrawer : null,
            y = () => {
              t(x || null, { isExiting: !0 });
            },
            g = async () => {
              await c.userAction(
                "progress",
                "progress-delete-reload",
                void 0,
                !0
              ),
                window.location.reload();
            },
            m = async () => {
              let e = (t) => {
                t.data &&
                  "GFEvent" === t.data.type &&
                  "deleteProgressRequestResponse" === t.data.event &&
                  (s({
                    variables: {
                      input: {
                        id: a.id,
                        technology: a.technology,
                        version: (0, nf.Z)(),
                        browser: h.browser?.name || "",
                        deviceType: d,
                      },
                    },
                  }),
                  c.userAction("progress", "progress-delete-action"),
                  window.removeEventListener("message", e));
              };
              window.addEventListener("message", e),
                nx.e?.window.postMessage(
                  { type: "deleteProgressRequest" },
                  "*"
                );
            };
          return (
            i.useEffect(
              () => () => {
                "delete-success" === n && window.location.reload();
              },
              [n]
            ),
            (0, r.jsxs)(r.Fragment, {
              children: [
                (0, r.jsx)(w.Z, {
                  onClose: ["delete-success", "delete-failed"].includes(n)
                    ? g
                    : void 0,
                  title: eh.ag._({
                    id: "common.upDrawer.progressDelete.title",
                  }),
                  onBack: ["delete-success", "delete-failed"].includes(n)
                    ? g
                    : x
                    ? () => {
                        t(x, { isExiting: !0 });
                      }
                    : void 0,
                }),
                (0, r.jsxs)(eD.qt, {
                  sx: { p: 3.75, flexGrow: 1, alignItems: "center" },
                  children: [
                    ("delete-pending" === n || "delete-failed" === n) &&
                      (0, r.jsxs)("div", {
                        style: {
                          width: "100%",
                          textAlign: "center",
                          fontSize: 16,
                          color: f.D.white[80],
                        },
                        children: [
                          (0, r.jsx)(np, {
                            style: { width: 150, height: 105 },
                          }),
                          (0, r.jsx)("div", {
                            style: { marginTop: 24 },
                            children: (0, r.jsx)(u.cC, {
                              id: "common.upDrawer.progressDelete.body",
                            }),
                          }),
                          (0, r.jsx)("div", {
                            style: {
                              textDecoration: "underline",
                              marginTop: 24,
                            },
                            children: (0, r.jsx)(u.cC, {
                              id: "common.upDrawer.progressDelete.bodyHighlight",
                            }),
                          }),
                          (0, r.jsxs)("div", {
                            style: { marginTop: 24, display: "flex" },
                            children: [
                              (0, r.jsx)(X.Z, {
                                className: nC().button,
                                variant: "contained",
                                color: "grey",
                                onClick: y,
                                children: "Cancel",
                              }),
                              (0, r.jsx)(X.Z, {
                                className: nC().button,
                                variant: "contained",
                                color: "alert",
                                onClick: m,
                                children: "Delete",
                              }),
                            ],
                          }),
                          "delete-failed" === n &&
                            (0, r.jsxs)(r.Fragment, {
                              children: [
                                (0, r.jsx)("div", {
                                  style: {
                                    color: f.D.alert[60],
                                    marginTop: 24,
                                  },
                                  children: (0, r.jsx)(u.cC, {
                                    id: "common.upDrawer.progressDelete.error1",
                                  }),
                                }),
                                (0, r.jsx)("div", {
                                  style: { color: f.D.alert[60] },
                                  children: (0, r.jsx)(u.cC, {
                                    id: "common.upDrawer.progressDelete.error2",
                                  }),
                                }),
                              ],
                            }),
                        ],
                      }),
                    "delete-success" === n &&
                      (0, r.jsxs)("div", {
                        style: {
                          width: "100%",
                          textAlign: "center",
                          fontSize: 16,
                          color: f.D.white[80],
                        },
                        children: [
                          (0, r.jsx)(eg.Z, {
                            style: {
                              color: "#4AF0A7",
                              width: 150,
                              height: 105,
                            },
                          }),
                          (0, r.jsx)("div", {
                            style: { marginTop: 24 },
                            children: (0, r.jsx)(u.cC, {
                              id: "common.upDrawer.progressDelete.complete.body",
                            }),
                          }),
                          (0, r.jsx)("div", {
                            style: { marginTop: 24, display: "flex" },
                            children: (0, r.jsx)(X.Z, {
                              variant: "contained",
                              color: "purple",
                              onClick: g,
                              className: nC().button,
                              children: "Reload game",
                            }),
                          }),
                        ],
                      }),
                  ],
                }),
              ],
            })
          );
        };
        var nw = n(26579),
          nv = n(83743),
          nj = n.n(nv);
        let nB = s()(() => Promise.resolve().then(n.bind(n, 11765)), {
            loadableGenerated: { webpack: () => [11765] },
          }),
          nD = () => {
            let { openDrawer: e } = i.useContext(p.s9),
              [t, { loading: n }] = Y.Gn(),
              { setMessage: o } = i.useContext(d.V),
              { countryCode: s } = i.useContext(nw.Z),
              { crazyAnalyticsService: a } = i.useContext(U.Z).services,
              [l, c] = i.useState(void 0),
              [h, x] = i.useState(void 0),
              [y, f] = i.useState(s || void 0),
              g = eM(l),
              m = eq(),
              C = eG(),
              _ = C.map((e) => ({ value: e.code, label: e.name })),
              w = async () => {
                try {
                  await t({ birthday: l, gender: h, countryCode: y });
                  let e = [l, h, y],
                    n = e.reduce((e, t) => (void 0 !== t ? e + 1 : e), 0);
                  n === e.length
                    ? a.userAction("profile", "profile_completed", "full")
                    : 0 === n
                    ? a.userAction("profile", "profile_completed", "empty")
                    : a.userAction("profile", "profile_completed", "partial");
                } catch (e) {
                  return;
                } finally {
                  c(void 0), x(void 0), f(void 0);
                }
                e("accountConfirmation");
              };
            return (
              i.useEffect(() => {
                void 0 === l || g
                  ? o(void 0)
                  : o(eh.ag._("common.upDrawer.editProfile.birthdayError"));
              }, [g, l, o]),
              (0, r.jsxs)(ei.Z, {
                onBack: () => {
                  e("editProfile", { isExiting: !0 });
                },
                contentPadding: 2,
                title: (0, r.jsx)(u.cC, { id: "auth.ui.button.signup" }),
                children: [
                  (0, r.jsx)(eD.mH, {
                    sx: { mb: 2, textAlign: "center" },
                    children: (0, r.jsx)(u.cC, {
                      id: "common.upDrawer.tellUsMore",
                    }),
                  }),
                  (0, r.jsx)("div", {
                    className: nj().personalDetailsDisclaimer,
                    children: (0, r.jsx)(u.cC, {
                      id: "common.upDrawer.personalDetailsDisclaimer",
                    }),
                  }),
                  (0, r.jsx)(eU, {
                    allowEmpty: !0,
                    labelId: "common.upDrawer.changeLocation.inputLabel",
                    value: y || "",
                    onChange: f,
                    options: _,
                  }),
                  (0, r.jsx)("div", {
                    className: nj().inputWrapper,
                    children: (0, r.jsx)(nB, {
                      value: l,
                      onChange: (e) => {
                        c(e);
                      },
                    }),
                  }),
                  (0, r.jsx)("div", {
                    className: nj().inputWrapper,
                    children: (0, r.jsx)(eU, {
                      allowEmpty: !0,
                      labelId: "common.upDrawer.editProfile.gender",
                      value: h || "",
                      onChange: (e) => x(e),
                      options: m,
                    }),
                  }),
                  (0, r.jsx)(eS.Z, {}),
                  (0, r.jsx)("div", {
                    className: nj().inputWrapper,
                    children: (0, r.jsx)(ek.Z, {
                      loading: n,
                      disabled: l && !g,
                      onClick: w,
                      height: 50,
                      sx: { width: "100%" },
                      children: (0, r.jsx)(u.cC, {
                        id: "common.upDrawer.save",
                      }),
                    }),
                  }),
                ],
              })
            );
          },
          nz = s()(
            () => Promise.all([n.e(92592), n.e(2292)]).then(n.bind(n, 2292)),
            {
              loadableGenerated: { webpack: () => [2292] },
              loading: () => null,
              ssr: !1,
            }
          ),
          nb = i.memo((e) => {
            let { drawer: t } = e;
            switch (t) {
              case "main":
                return (0, r.jsx)(en, {});
              case "settings":
                return (0, r.jsx)(eu, {});
              case "privacyPreferences":
                return (0, r.jsx)(th, {});
              case "notificationPreferences":
                return (0, r.jsx)(t0, {});
              case "shareProfile":
                return (0, r.jsx)(nz, {});
              case "avatarSelector":
                return (0, r.jsx)(ew, {});
              case "aboutYou":
                return (0, r.jsx)(nD, {});
              case "coverSelector":
                return (0, r.jsx)(eB, {});
              case "usernameSelector":
                return (0, r.jsx)(eb, {});
              case "birthdaySelector":
                return (0, r.jsx)(eI, {});
              case "deleteAccount":
                return (0, r.jsx)(e5, {});
              case "editEmail":
                return (0, r.jsx)(e9, {});
              case "editPassword":
                return (0, r.jsx)(tn, {});
              case "editProfile":
                return (0, r.jsx)(eX, {});
              case "friends":
                return (0, r.jsx)(t1, {});
              case "friendsGuest":
                return (0, r.jsx)(t5, {});
              case "inviteFriends":
                return (0, r.jsx)(t7, {});
              case "notifications":
                return (0, r.jsx)(na, {});
              case "progressStatus":
                return (0, r.jsx)(nh, {});
              case "progressDelete":
                return (0, r.jsx)(n_, {});
              default:
                return null;
            }
          });
        var nk = nb;
      },
      33661: function (e, t, n) {
        "use strict";
        n.d(t, {
          P2: function () {
            return a;
          },
          YP: function () {
            return p;
          },
          bu: function () {
            return y;
          },
          fP: function () {
            return d;
          },
          r_: function () {
            return l;
          },
          sN: function () {
            return u;
          },
          sy: function () {
            return c;
          },
          vt: function () {
            return h;
          },
          xy: function () {
            return x;
          },
        });
        var r = n(25503);
        let i = (e, t, n, r) => {
            try {
              let i = (e) => {
                switch (n) {
                  case "add":
                    return [...e, ...r];
                  case "remove":
                    return e.filter((e) => !r.includes(e));
                }
              };
              e.cache.modify({
                id: e.cache.identify({ __typename: "User", id: t }),
                fields: { relationship: (e) => i(e || []) },
              });
            } catch (e) {
              console.error("Error invalidating cache: ", e);
            }
          },
          o = (e, t) => {
            try {
              e.cache.modify({
                fields: {
                  requestsReceivedFrom(e, n) {
                    let { readField: r } = n;
                    return e.filter((e) => r("id", e.user) !== t);
                  },
                },
              });
            } catch (e) {
              console.error("Error invalidating cache: ", e);
            }
          },
          s = (e, t) => {
            try {
              e.cache.modify({
                fields: {
                  requestsSentTo(e, n) {
                    let { readField: r } = n;
                    return e.filter((e) => r("id", e.user) !== t);
                  },
                },
              });
            } catch (e) {
              console.error("Error invalidating cache: ", e);
            }
          },
          a = (e, t, n) => {
            n ? i(e, t, "add", [n]) : i(e, t, "add", ["invite-sent"]);
          },
          l = (e, t) => {
            i(e, t, "remove", ["invite-sent"]), s(e, t);
          },
          c = (e, t) => {
            i(e, t, "add", ["friends"]),
              i(e, t, "remove", ["invite-received"]),
              o(e, t),
              e.refetchQueries({ include: [r.a_] });
          },
          d = (e, t) => {
            i(e, t, "remove", ["invite-received"]), o(e, t);
          },
          u = (e, t) => {
            i(e, t, "remove", ["invite-received"]), o(e, t);
          },
          h = (e, t) => {
            i(e, t, "remove", ["invite-received"]), o(e, t);
          },
          p = (e, t) => {
            i(e, t, "remove", ["friends"]),
              e.refetchQueries({ include: [r.a_, r.rc] });
          },
          x = (e, t) => {
            i(e, t, "remove", ["friends", "invite-received", "invite-sent"]),
              i(e, t, "add", ["blocked-by-me"]),
              e.refetchQueries({ include: [r.a_, r.rc] });
          },
          y = (e, t) => {
            i(e, t, "remove", ["blocked-by-me"]);
          };
      },
      21046: function (e, t, n) {
        "use strict";
        n.d(t, {
          _l: function () {
            return s;
          },
          dO: function () {
            return a;
          },
          kJ: function () {
            return o;
          },
        });
        var r = n(14646),
          i = n(12774);
        let o = i.qR,
          s = r.OX,
          a = r.Le;
      },
      63462: function (e, t, n) {
        "use strict";
        n.d(t, {
          m: function () {
            return a;
          },
        });
        var r = n(85893),
          i = n(90948),
          o = n(12389),
          s = n(3411);
        let a = (0, i.ZP)((e) => {
          let { className: t, ...n } = e;
          return (0, r.jsx)(o.Z, { classes: { tooltip: t }, ...n });
        })((e) => {
          let {} = e;
          return {
            backgroundColor: s.D.black[40],
            fontSize: "12px",
            color: s.D.white[60],
            lineHeight: "15.6px",
            fontWeight: 400,
            padding: "10px",
            boxShadow: "0px 10px 20px rgba(0, 0, 0, 0.1)",
            borderRadius: "10px",
            textAlign: "center",
            width: "173px",
          };
        });
      },
      49025: function (e, t, n) {
        "use strict";
        n.d(t, {
          FZ: function () {
            return o;
          },
          Gs: function () {
            return s;
          },
          J6: function () {
            return a;
          },
          Si: function () {
            return i;
          },
        });
        var r = n(12774);
        let i = r.Iw,
          o = r.Ck,
          s = r.a1,
          a = r.Ru;
      },
      83696: function (e) {
        e.exports = {
          czyButton: "ExpandableFriendList_czyButton__OqvXd",
          "czyButton--contained--purple":
            "ExpandableFriendList_czyButton--contained--purple__JYevC",
          "czyButton--contained--white":
            "ExpandableFriendList_czyButton--contained--white__z9mmA",
          "czyButton--contained--grey":
            "ExpandableFriendList_czyButton--contained--grey__2xll5",
          "czyButton--contained--alert":
            "ExpandableFriendList_czyButton--contained--alert__wL1qJ",
          "czyButton--contained--success":
            "ExpandableFriendList_czyButton--contained--success__DyO1z",
          "czyButton--contained--black":
            "ExpandableFriendList_czyButton--contained--black__mRvA5",
          "czyButton--contained--green-gradient":
            "ExpandableFriendList_czyButton--contained--green-gradient__9wkRX",
          "czyButton--outlined--purple":
            "ExpandableFriendList_czyButton--outlined--purple__rUTyd",
          "czyButton--link--purple":
            "ExpandableFriendList_czyButton--link--purple__0xeLw",
          "czyButton--outlined--white":
            "ExpandableFriendList_czyButton--outlined--white__63LzQ",
          "czyButton--link--white":
            "ExpandableFriendList_czyButton--link--white__mVkSa",
          "czyButton--outlined--grey":
            "ExpandableFriendList_czyButton--outlined--grey__9leFo",
          "czyButton--link--grey":
            "ExpandableFriendList_czyButton--link--grey__DJ0z4",
          "czyButton--outlined--alert":
            "ExpandableFriendList_czyButton--outlined--alert__KbMor",
          "czyButton--link--alert":
            "ExpandableFriendList_czyButton--link--alert__fwDZa",
          "czyButton--outlined--success":
            "ExpandableFriendList_czyButton--outlined--success__aBsRA",
          "czyButton--link--success":
            "ExpandableFriendList_czyButton--link--success__36L2N",
          "czyButton--outlined":
            "ExpandableFriendList_czyButton--outlined__3uEeF",
          "czyButton--disabled":
            "ExpandableFriendList_czyButton--disabled__Mi9WX",
          "czyButton--height50":
            "ExpandableFriendList_czyButton--height50__aHjYw",
          "czyButton--height34":
            "ExpandableFriendList_czyButton--height34__0IUem",
          "czyButton--fullWidth":
            "ExpandableFriendList_czyButton--fullWidth__kQuyL",
          button: "ExpandableFriendList_button__JXfzK",
        };
      },
      57860: function (e) {
        e.exports = {
          czyButton: "FriendListItem_czyButton__iCno9",
          "czyButton--contained--purple":
            "FriendListItem_czyButton--contained--purple__8ue34",
          "czyButton--contained--white":
            "FriendListItem_czyButton--contained--white__D1xzr",
          "czyButton--contained--grey":
            "FriendListItem_czyButton--contained--grey__cGT9_",
          "czyButton--contained--alert":
            "FriendListItem_czyButton--contained--alert__B94dn",
          "czyButton--contained--success":
            "FriendListItem_czyButton--contained--success__cKixL",
          "czyButton--contained--black":
            "FriendListItem_czyButton--contained--black__DWm2T",
          "czyButton--contained--green-gradient":
            "FriendListItem_czyButton--contained--green-gradient__Gfxed",
          "czyButton--outlined--purple":
            "FriendListItem_czyButton--outlined--purple__9hrm9",
          "czyButton--link--purple":
            "FriendListItem_czyButton--link--purple__UD7Fv",
          "czyButton--outlined--white":
            "FriendListItem_czyButton--outlined--white__l6d60",
          "czyButton--link--white":
            "FriendListItem_czyButton--link--white__Zb8l8",
          "czyButton--outlined--grey":
            "FriendListItem_czyButton--outlined--grey__KIjR0",
          "czyButton--link--grey":
            "FriendListItem_czyButton--link--grey__BDY_h",
          "czyButton--outlined--alert":
            "FriendListItem_czyButton--outlined--alert__N9qzY",
          "czyButton--link--alert":
            "FriendListItem_czyButton--link--alert__ruZE5",
          "czyButton--outlined--success":
            "FriendListItem_czyButton--outlined--success__UvJ7n",
          "czyButton--link--success":
            "FriendListItem_czyButton--link--success__3zU1K",
          "czyButton--outlined": "FriendListItem_czyButton--outlined__4Qi97",
          "czyButton--disabled": "FriendListItem_czyButton--disabled___xsCD",
          "czyButton--height50": "FriendListItem_czyButton--height50__Qml1k",
          "czyButton--height34": "FriendListItem_czyButton--height34__sYOf9",
          "czyButton--fullWidth": "FriendListItem_czyButton--fullWidth__40AVe",
          friendListButton: "FriendListItem_friendListButton__FCTBk",
          joinButton: "FriendListItem_joinButton__GlDhx",
          friendRequestButton: "FriendListItem_friendRequestButton__EB3np",
        };
      },
      22405: function (e) {
        e.exports = { button: "FriendsGuestDrawer_button__vemsu" };
      },
      61765: function (e) {
        e.exports = {
          czyButton: "MainFriendsDrawer_czyButton__gCU73",
          "czyButton--contained--purple":
            "MainFriendsDrawer_czyButton--contained--purple__faM_x",
          "czyButton--contained--white":
            "MainFriendsDrawer_czyButton--contained--white__JWwSB",
          "czyButton--contained--grey":
            "MainFriendsDrawer_czyButton--contained--grey__bel0v",
          "czyButton--contained--alert":
            "MainFriendsDrawer_czyButton--contained--alert__d2TVb",
          "czyButton--contained--success":
            "MainFriendsDrawer_czyButton--contained--success__pWQHp",
          "czyButton--contained--black":
            "MainFriendsDrawer_czyButton--contained--black__nZoLi",
          "czyButton--contained--green-gradient":
            "MainFriendsDrawer_czyButton--contained--green-gradient__kKDFD",
          "czyButton--outlined--purple":
            "MainFriendsDrawer_czyButton--outlined--purple__A2TeA",
          "czyButton--link--purple":
            "MainFriendsDrawer_czyButton--link--purple__g4mQS",
          "czyButton--outlined--white":
            "MainFriendsDrawer_czyButton--outlined--white__1iUDb",
          "czyButton--link--white":
            "MainFriendsDrawer_czyButton--link--white__l8rm_",
          "czyButton--outlined--grey":
            "MainFriendsDrawer_czyButton--outlined--grey__95fxy",
          "czyButton--link--grey":
            "MainFriendsDrawer_czyButton--link--grey__CKtWt",
          "czyButton--outlined--alert":
            "MainFriendsDrawer_czyButton--outlined--alert__PPLYB",
          "czyButton--link--alert":
            "MainFriendsDrawer_czyButton--link--alert__ntPnl",
          "czyButton--outlined--success":
            "MainFriendsDrawer_czyButton--outlined--success__taMzk",
          "czyButton--link--success":
            "MainFriendsDrawer_czyButton--link--success__7c47E",
          "czyButton--outlined": "MainFriendsDrawer_czyButton--outlined__n4ZUf",
          "czyButton--disabled": "MainFriendsDrawer_czyButton--disabled__T7wq0",
          "czyButton--height50": "MainFriendsDrawer_czyButton--height50__krUEk",
          "czyButton--height34": "MainFriendsDrawer_czyButton--height34__peDSz",
          "czyButton--fullWidth":
            "MainFriendsDrawer_czyButton--fullWidth__fPEXQ",
          gamesForFriendButton: "MainFriendsDrawer_gamesForFriendButton__1HOA0",
          shareProfileButton: "MainFriendsDrawer_shareProfileButton__j6Vqz",
          friendsSearchFriendList:
            "MainFriendsDrawer_friendsSearchFriendList__MdmK5",
        };
      },
      63105: function (e) {
        e.exports = {
          czyButton: "MainDrawer_czyButton__wai2x",
          "czyButton--contained--purple":
            "MainDrawer_czyButton--contained--purple__HVIh_",
          "czyButton--contained--white":
            "MainDrawer_czyButton--contained--white__CJ7lC",
          "czyButton--contained--grey":
            "MainDrawer_czyButton--contained--grey__ZDZeU",
          "czyButton--contained--alert":
            "MainDrawer_czyButton--contained--alert__9rSI_",
          "czyButton--contained--success":
            "MainDrawer_czyButton--contained--success___4_SG",
          "czyButton--contained--black":
            "MainDrawer_czyButton--contained--black__6O1gv",
          "czyButton--contained--green-gradient":
            "MainDrawer_czyButton--contained--green-gradient__odFoh",
          "czyButton--outlined--purple":
            "MainDrawer_czyButton--outlined--purple__PTjO3",
          "czyButton--link--purple":
            "MainDrawer_czyButton--link--purple__yRTTm",
          "czyButton--outlined--white":
            "MainDrawer_czyButton--outlined--white__Vdxz2",
          "czyButton--link--white": "MainDrawer_czyButton--link--white___fjmm",
          "czyButton--outlined--grey":
            "MainDrawer_czyButton--outlined--grey__VPCTv",
          "czyButton--link--grey": "MainDrawer_czyButton--link--grey__uBKR_",
          "czyButton--outlined--alert":
            "MainDrawer_czyButton--outlined--alert__zvalz",
          "czyButton--link--alert": "MainDrawer_czyButton--link--alert__eTqKU",
          "czyButton--outlined--success":
            "MainDrawer_czyButton--outlined--success__HYJ7q",
          "czyButton--link--success":
            "MainDrawer_czyButton--link--success__pPOdw",
          "czyButton--outlined": "MainDrawer_czyButton--outlined__C5cEl",
          "czyButton--disabled": "MainDrawer_czyButton--disabled__rosB7",
          "czyButton--height50": "MainDrawer_czyButton--height50__08Nda",
          "czyButton--height34": "MainDrawer_czyButton--height34__VZOSs",
          "czyButton--fullWidth": "MainDrawer_czyButton--fullWidth__7sTId",
          header: "MainDrawer_header__h_jDH",
          avatarContainer: "MainDrawer_avatarContainer__GEoob",
          messages: "MainDrawer_messages__j9dOV",
          button: "MainDrawer_button__LaGFS",
        };
      },
      7854: function (e) {
        e.exports = {
          czyButton: "ProfileCompletionProgressBar_czyButton__4kfAK",
          "czyButton--contained--purple":
            "ProfileCompletionProgressBar_czyButton--contained--purple__CEpcV",
          "czyButton--contained--white":
            "ProfileCompletionProgressBar_czyButton--contained--white__1bS7h",
          "czyButton--contained--grey":
            "ProfileCompletionProgressBar_czyButton--contained--grey__5gAT0",
          "czyButton--contained--alert":
            "ProfileCompletionProgressBar_czyButton--contained--alert__3MeNi",
          "czyButton--contained--success":
            "ProfileCompletionProgressBar_czyButton--contained--success__3VAEK",
          "czyButton--contained--black":
            "ProfileCompletionProgressBar_czyButton--contained--black__qruLT",
          "czyButton--contained--green-gradient":
            "ProfileCompletionProgressBar_czyButton--contained--green-gradient__cViPa",
          "czyButton--outlined--purple":
            "ProfileCompletionProgressBar_czyButton--outlined--purple__8Ll6X",
          "czyButton--link--purple":
            "ProfileCompletionProgressBar_czyButton--link--purple__3xe6r",
          "czyButton--outlined--white":
            "ProfileCompletionProgressBar_czyButton--outlined--white__tjf8o",
          "czyButton--link--white":
            "ProfileCompletionProgressBar_czyButton--link--white__1dw7l",
          "czyButton--outlined--grey":
            "ProfileCompletionProgressBar_czyButton--outlined--grey__z_gPB",
          "czyButton--link--grey":
            "ProfileCompletionProgressBar_czyButton--link--grey__XMfxC",
          "czyButton--outlined--alert":
            "ProfileCompletionProgressBar_czyButton--outlined--alert__VVQVe",
          "czyButton--link--alert":
            "ProfileCompletionProgressBar_czyButton--link--alert__VFJoA",
          "czyButton--outlined--success":
            "ProfileCompletionProgressBar_czyButton--outlined--success__QwKtG",
          "czyButton--link--success":
            "ProfileCompletionProgressBar_czyButton--link--success__90_oS",
          "czyButton--outlined":
            "ProfileCompletionProgressBar_czyButton--outlined__w8DBB",
          "czyButton--disabled":
            "ProfileCompletionProgressBar_czyButton--disabled__zIzCS",
          "czyButton--height50":
            "ProfileCompletionProgressBar_czyButton--height50__Hc7Th",
          "czyButton--height34":
            "ProfileCompletionProgressBar_czyButton--height34__lRQa5",
          "czyButton--fullWidth":
            "ProfileCompletionProgressBar_czyButton--fullWidth__3gERH",
          root: "ProfileCompletionProgressBar_root__X3hbx",
          row: "ProfileCompletionProgressBar_row__bLB0F",
          completeNow: "ProfileCompletionProgressBar_completeNow__EVsp4",
          chevronRight: "ProfileCompletionProgressBar_chevronRight__snGey",
          progress: "ProfileCompletionProgressBar_progress__QmprG",
        };
      },
      94213: function (e) {
        e.exports = {
          czyButton: "Progress_czyButton__ALaef",
          "czyButton--contained--purple":
            "Progress_czyButton--contained--purple__czgBN",
          "czyButton--contained--white":
            "Progress_czyButton--contained--white__LJ8q9",
          "czyButton--contained--grey":
            "Progress_czyButton--contained--grey__Ev3ra",
          "czyButton--contained--alert":
            "Progress_czyButton--contained--alert__YlD44",
          "czyButton--contained--success":
            "Progress_czyButton--contained--success__Z3jNr",
          "czyButton--contained--black":
            "Progress_czyButton--contained--black__lzJL0",
          "czyButton--contained--green-gradient":
            "Progress_czyButton--contained--green-gradient__Jktym",
          "czyButton--outlined--purple":
            "Progress_czyButton--outlined--purple__iY8Ad",
          "czyButton--link--purple": "Progress_czyButton--link--purple__L75sv",
          "czyButton--outlined--white":
            "Progress_czyButton--outlined--white__ub_7f",
          "czyButton--link--white": "Progress_czyButton--link--white__nmEg5",
          "czyButton--outlined--grey":
            "Progress_czyButton--outlined--grey__Yc1kI",
          "czyButton--link--grey": "Progress_czyButton--link--grey__6YpoD",
          "czyButton--outlined--alert":
            "Progress_czyButton--outlined--alert__PTAmR",
          "czyButton--link--alert": "Progress_czyButton--link--alert__jVJKJ",
          "czyButton--outlined--success":
            "Progress_czyButton--outlined--success__oFnQ5",
          "czyButton--link--success":
            "Progress_czyButton--link--success__LoWKE",
          "czyButton--outlined": "Progress_czyButton--outlined__iqsdw",
          "czyButton--disabled": "Progress_czyButton--disabled__xEIag",
          "czyButton--height50": "Progress_czyButton--height50__lsHQI",
          "czyButton--height34": "Progress_czyButton--height34__6b5LM",
          "czyButton--fullWidth": "Progress_czyButton--fullWidth__IV4K8",
          button: "Progress_button__nG15y",
        };
      },
      83743: function (e) {
        e.exports = {
          czyButton: "AboutYouDrawer_czyButton__Vnd4D",
          "czyButton--contained--purple":
            "AboutYouDrawer_czyButton--contained--purple__tPuQR",
          "czyButton--contained--white":
            "AboutYouDrawer_czyButton--contained--white__j8ZDO",
          "czyButton--contained--grey":
            "AboutYouDrawer_czyButton--contained--grey__rTxkC",
          "czyButton--contained--alert":
            "AboutYouDrawer_czyButton--contained--alert__NOSiG",
          "czyButton--contained--success":
            "AboutYouDrawer_czyButton--contained--success__7ZRDf",
          "czyButton--contained--black":
            "AboutYouDrawer_czyButton--contained--black__zo27r",
          "czyButton--contained--green-gradient":
            "AboutYouDrawer_czyButton--contained--green-gradient__qM0PY",
          "czyButton--outlined--purple":
            "AboutYouDrawer_czyButton--outlined--purple__rh4qu",
          "czyButton--link--purple":
            "AboutYouDrawer_czyButton--link--purple__FGTa9",
          "czyButton--outlined--white":
            "AboutYouDrawer_czyButton--outlined--white__d1eNW",
          "czyButton--link--white":
            "AboutYouDrawer_czyButton--link--white__xUeUV",
          "czyButton--outlined--grey":
            "AboutYouDrawer_czyButton--outlined--grey__Es_N4",
          "czyButton--link--grey":
            "AboutYouDrawer_czyButton--link--grey__YgR_V",
          "czyButton--outlined--alert":
            "AboutYouDrawer_czyButton--outlined--alert__DyhMp",
          "czyButton--link--alert":
            "AboutYouDrawer_czyButton--link--alert__zSIPh",
          "czyButton--outlined--success":
            "AboutYouDrawer_czyButton--outlined--success__vDO7V",
          "czyButton--link--success":
            "AboutYouDrawer_czyButton--link--success__1wHuc",
          "czyButton--outlined": "AboutYouDrawer_czyButton--outlined__7wWDz",
          "czyButton--disabled": "AboutYouDrawer_czyButton--disabled__WEW_x",
          "czyButton--height50": "AboutYouDrawer_czyButton--height50__E3yui",
          "czyButton--height34": "AboutYouDrawer_czyButton--height34__YWVyG",
          "czyButton--fullWidth": "AboutYouDrawer_czyButton--fullWidth__evRYy",
          inputWrapper: "AboutYouDrawer_inputWrapper__t2UMe",
          skip: "AboutYouDrawer_skip__4V8Vg",
          personalDetailsDisclaimer:
            "AboutYouDrawer_personalDetailsDisclaimer__A8xp8",
        };
      },
      85812: function (e) {
        e.exports = {
          czyButton: "BirthdayInput_czyButton__kJyKw",
          "czyButton--contained--purple":
            "BirthdayInput_czyButton--contained--purple__hQyEx",
          "czyButton--contained--white":
            "BirthdayInput_czyButton--contained--white__udlV8",
          "czyButton--contained--grey":
            "BirthdayInput_czyButton--contained--grey__3Vkn9",
          "czyButton--contained--alert":
            "BirthdayInput_czyButton--contained--alert__qEkBm",
          "czyButton--contained--success":
            "BirthdayInput_czyButton--contained--success__jJsKT",
          "czyButton--contained--black":
            "BirthdayInput_czyButton--contained--black__olmzi",
          "czyButton--contained--green-gradient":
            "BirthdayInput_czyButton--contained--green-gradient__R3aag",
          "czyButton--outlined--purple":
            "BirthdayInput_czyButton--outlined--purple__AlaUT",
          "czyButton--link--purple":
            "BirthdayInput_czyButton--link--purple__gvLIY",
          "czyButton--outlined--white":
            "BirthdayInput_czyButton--outlined--white__T8aCR",
          "czyButton--link--white":
            "BirthdayInput_czyButton--link--white___jLP2",
          "czyButton--outlined--grey":
            "BirthdayInput_czyButton--outlined--grey__q_7zP",
          "czyButton--link--grey": "BirthdayInput_czyButton--link--grey__bclID",
          "czyButton--outlined--alert":
            "BirthdayInput_czyButton--outlined--alert__2JRlO",
          "czyButton--link--alert":
            "BirthdayInput_czyButton--link--alert____ALV",
          "czyButton--outlined--success":
            "BirthdayInput_czyButton--outlined--success__6jJ23",
          "czyButton--link--success":
            "BirthdayInput_czyButton--link--success__D8vZF",
          "czyButton--outlined": "BirthdayInput_czyButton--outlined__Qt657",
          "czyButton--disabled": "BirthdayInput_czyButton--disabled__MMDEU",
          "czyButton--height50": "BirthdayInput_czyButton--height50__2dUtt",
          "czyButton--height34": "BirthdayInput_czyButton--height34__Zx6N2",
          "czyButton--fullWidth": "BirthdayInput_czyButton--fullWidth__rCjr8",
          datePicker: "BirthdayInput_datePicker__Z3fZ4",
          hideCalendarButton: "BirthdayInput_hideCalendarButton__FL7W7",
        };
      },
      20805: function (e) {
        e.exports = {
          submitButtonWrapper:
            "SubDrawerBirthdaySelector_submitButtonWrapper__8SYgz",
        };
      },
      70115: function (e) {
        e.exports = {
          czyButton: "SubDrawerEditProfileDrawer_czyButton__rHfg5",
          "czyButton--contained--purple":
            "SubDrawerEditProfileDrawer_czyButton--contained--purple__yHg9j",
          "czyButton--contained--white":
            "SubDrawerEditProfileDrawer_czyButton--contained--white__L6nbO",
          "czyButton--contained--grey":
            "SubDrawerEditProfileDrawer_czyButton--contained--grey__9dDMF",
          "czyButton--contained--alert":
            "SubDrawerEditProfileDrawer_czyButton--contained--alert__zSsFb",
          "czyButton--contained--success":
            "SubDrawerEditProfileDrawer_czyButton--contained--success__Jd0Dk",
          "czyButton--contained--black":
            "SubDrawerEditProfileDrawer_czyButton--contained--black__ZeXT_",
          "czyButton--contained--green-gradient":
            "SubDrawerEditProfileDrawer_czyButton--contained--green-gradient__rDS50",
          "czyButton--outlined--purple":
            "SubDrawerEditProfileDrawer_czyButton--outlined--purple__E8G80",
          "czyButton--link--purple":
            "SubDrawerEditProfileDrawer_czyButton--link--purple__1o5Xa",
          "czyButton--outlined--white":
            "SubDrawerEditProfileDrawer_czyButton--outlined--white__c5_Iw",
          "czyButton--link--white":
            "SubDrawerEditProfileDrawer_czyButton--link--white__kMZd9",
          "czyButton--outlined--grey":
            "SubDrawerEditProfileDrawer_czyButton--outlined--grey__MDHVx",
          "czyButton--link--grey":
            "SubDrawerEditProfileDrawer_czyButton--link--grey__OnGnD",
          "czyButton--outlined--alert":
            "SubDrawerEditProfileDrawer_czyButton--outlined--alert__xfMTq",
          "czyButton--link--alert":
            "SubDrawerEditProfileDrawer_czyButton--link--alert__xmGtq",
          "czyButton--outlined--success":
            "SubDrawerEditProfileDrawer_czyButton--outlined--success__Qx_P1",
          "czyButton--link--success":
            "SubDrawerEditProfileDrawer_czyButton--link--success__MYZvh",
          "czyButton--outlined":
            "SubDrawerEditProfileDrawer_czyButton--outlined__A5VWl",
          "czyButton--disabled":
            "SubDrawerEditProfileDrawer_czyButton--disabled__NcXEk",
          "czyButton--height50":
            "SubDrawerEditProfileDrawer_czyButton--height50__F8rMf",
          "czyButton--height34":
            "SubDrawerEditProfileDrawer_czyButton--height34__hEvlJ",
          "czyButton--fullWidth":
            "SubDrawerEditProfileDrawer_czyButton--fullWidth__ajWWY",
          personalDetailsTitle:
            "SubDrawerEditProfileDrawer_personalDetailsTitle__FKrEZ",
          personalDetailsDescription:
            "SubDrawerEditProfileDrawer_personalDetailsDescription__f3GrP",
          avatarWrapper: "SubDrawerEditProfileDrawer_avatarWrapper___7SuX",
          avatarContainer: "SubDrawerEditProfileDrawer_avatarContainer__zKIIk",
          coverWrapper: "SubDrawerEditProfileDrawer_coverWrapper__jQ_ZI",
          coverContainer: "SubDrawerEditProfileDrawer_coverContainer__w4U2K",
          cover: "SubDrawerEditProfileDrawer_cover__ESyuY",
          formContainer: "SubDrawerEditProfileDrawer_formContainer__z2oc1",
          divider: "SubDrawerEditProfileDrawer_divider__K_Hnf",
          startAdornment: "SubDrawerEditProfileDrawer_startAdornment__3zdHT",
        };
      },
      66060: function (e) {
        e.exports = {
          czyButton: "Settings_czyButton__ExQm8",
          "czyButton--contained--purple":
            "Settings_czyButton--contained--purple__LOoGk",
          "czyButton--contained--white":
            "Settings_czyButton--contained--white__OoNSt",
          "czyButton--contained--grey":
            "Settings_czyButton--contained--grey__tlSwX",
          "czyButton--contained--alert":
            "Settings_czyButton--contained--alert__asbEx",
          "czyButton--contained--success":
            "Settings_czyButton--contained--success__nyAww",
          "czyButton--contained--black":
            "Settings_czyButton--contained--black__mwI8x",
          "czyButton--contained--green-gradient":
            "Settings_czyButton--contained--green-gradient__UI7Cm",
          "czyButton--outlined--purple":
            "Settings_czyButton--outlined--purple__5GvXC",
          "czyButton--link--purple": "Settings_czyButton--link--purple__ScDvQ",
          "czyButton--outlined--white":
            "Settings_czyButton--outlined--white__kYMYo",
          "czyButton--link--white": "Settings_czyButton--link--white__eXinq",
          "czyButton--outlined--grey":
            "Settings_czyButton--outlined--grey__qAkb0",
          "czyButton--link--grey": "Settings_czyButton--link--grey__rigSv",
          "czyButton--outlined--alert":
            "Settings_czyButton--outlined--alert__E5Z4X",
          "czyButton--link--alert": "Settings_czyButton--link--alert___nnNy",
          "czyButton--outlined--success":
            "Settings_czyButton--outlined--success__mn76g",
          "czyButton--link--success":
            "Settings_czyButton--link--success__dH0x3",
          "czyButton--outlined": "Settings_czyButton--outlined__SJV_4",
          "czyButton--disabled": "Settings_czyButton--disabled__UO6kZ",
          "czyButton--height50": "Settings_czyButton--height50__g3_wK",
          "czyButton--height34": "Settings_czyButton--height34__rZ9cm",
          "czyButton--fullWidth": "Settings_czyButton--fullWidth__lXm6R",
          forgotPasswordButton: "Settings_forgotPasswordButton__c3ysp",
        };
      },
    },
  ]);
