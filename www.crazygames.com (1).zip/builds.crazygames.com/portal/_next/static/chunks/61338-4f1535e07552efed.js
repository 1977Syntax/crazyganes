!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "8345f385-501d-46e1-bb78-2f4a7d022019"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-8345f385-501d-46e1-bb78-2f4a7d022019"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [61338],
    {
      74112: function (e, t, r) {
        "use strict";
        var n = r(85893),
          o = r(67294),
          i = r(6590),
          s = r(37899),
          a = r(56774);
        let l = (e) => {
          let {
              games: t,
              justifyContent: r,
              slidesToLoadEagerly: l,
              contentVisibility: c,
              containIntrinsicSize: d,
              customStyles: C,
              thumbIconFn: u,
              thumbIcon: h,
              isResponsive: x,
              isResponsiveGrid: p,
              imgResponsiveSizes: _,
              sx: y,
              loading: g,
              useDprSrcset: f,
              enableInstantJoin: j,
              className: m,
            } = e,
            { crazyAnalyticsService: B } = o.useContext(s.Z).services;
          return (0, n.jsx)(a.MM, {
            className: m,
            contentVisibility: c,
            containIntrinsicSize: d,
            style: { ...C, justifyContent: r },
            isResponsive: x,
            sx: y,
            children: t.map((e, r) =>
              e.loading || g
                ? (0, n.jsx)(i.Z, { isResponsive: x }, e.slug)
                : (0, n.jsx)(
                    a.oZ,
                    {
                      game: e,
                      enableInstantJoin: j,
                      eagerLoading: l ? r < l : void 0,
                      iconFn: u,
                      icon: h,
                      onClickAction: () => {
                        B.gameClickedFromList(t);
                      },
                      isResponsive: x,
                      isResponsiveGrid: p,
                      imgResponsiveSizes: _,
                      useDprSrcset: f,
                    },
                    e.slug
                  )
            ),
          });
        };
        t.Z = l;
      },
      6590: function (e, t, r) {
        "use strict";
        var n = r(85893),
          o = r(67294),
          i = r(88078),
          s = r(42257),
          a = r(2734),
          l = r(90512),
          c = r(55176),
          d = r.n(c);
        let C = (e) => {
          let { sx: t, isResponsive: r } = e,
            c = o.useContext(s.Z),
            C = c.isDesktop,
            u = (0, a.Z)(),
            h = u.dimensions.gameThumb,
            x = C ? h.width : h.mobileWidth,
            p = h.height;
          return (0, n.jsx)(i.Z, {
            sx: {
              position: "relative",
              borderRadius: (e) => e.spacing(),
              ...t,
            },
            animation: !1,
            variant: "rectangular",
            width: r ? "calc(100% - 2px)" : x,
            height: r ? "calc(100% - 2px)" : p,
            className: (0, l.Z)(d().skeleton, "skeleton"),
          });
        };
        t.Z = C;
      },
      28818: function (e, t, r) {
        "use strict";
        var n = r(85893),
          o = r(67294),
          i = r(95914);
        let s = o.memo((e) =>
          (0, n.jsx)(i.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, n.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M11.2929 2.29289C11.6834 1.90237 12.3166 1.90237 12.7071 2.29289L21.7071 11.2929C22.0976 11.6834 22.0976 12.3166 21.7071 12.7071C21.3166 13.0976 20.6834 13.0976 20.2929 12.7071L20 12.4142V20C20 21.1046 19.1046 22 18 22H6C4.89543 22 4 21.1046 4 20V12.4142L3.70711 12.7071C3.31658 13.0976 2.68342 13.0976 2.29289 12.7071C1.90237 12.3166 1.90237 11.6834 2.29289 11.2929L11.2929 2.29289ZM6 10.4142V20H9V16C9 14.8954 9.89543 14 11 14H13C14.1046 14 15 14.8954 15 16V20H18V10.4142L12 4.41421L6 10.4142ZM13 20V16H11V20H13Z",
            }),
          })
        );
        t.Z = s;
      },
      20209: function (e, t, r) {
        "use strict";
        var n = r(85893),
          o = r(67294),
          i = r(95914);
        let s = o.memo((e) =>
          (0, n.jsx)(i.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, n.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M5 2C5.55228 2 6 2.44772 6 3V4H7C7.55228 4 8 4.44772 8 5C8 5.55228 7.55228 6 7 6H6V7C6 7.55228 5.55228 8 5 8C4.44772 8 4 7.55228 4 7V6H3C2.44772 6 2 5.55228 2 5C2 4.44772 2.44772 4 3 4H4V3C4 2.44772 4.44772 2 5 2ZM13 2C13.4304 2 13.8126 2.27543 13.9487 2.68377L16.0835 9.08833L21.3511 11.0637C21.7414 11.21 22 11.5832 22 12C22 12.4168 21.7414 12.79 21.3511 12.9363L16.0835 14.9117L13.9487 21.3162C13.8126 21.7246 13.4304 22 13 22C12.5696 22 12.1874 21.7246 12.0513 21.3162L9.91647 14.9117L4.64888 12.9363C4.25857 12.79 4 12.4168 4 12C4 11.5832 4.25857 11.21 4.64888 11.0637L9.91647 9.08833L12.0513 2.68377C12.1874 2.27543 12.5696 2 13 2ZM13 6.16228L11.663 10.1734C11.5675 10.4596 11.348 10.6875 11.0654 10.7935L7.848 12L11.0654 13.2065C11.348 13.3125 11.5675 13.5404 11.663 13.8266L13 17.8377L14.337 13.8266C14.4325 13.5404 14.652 13.3125 14.9346 13.2065L18.152 12L14.9346 10.7935C14.652 10.6875 14.4325 10.4596 14.337 10.1734L13 6.16228ZM6 16C6.55228 16 7 16.4477 7 17V18H8C8.55228 18 9 18.4477 9 19C9 19.5523 8.55228 20 8 20H7V21C7 21.5523 6.55228 22 6 22C5.44772 22 5 21.5523 5 21V20H4C3.44772 20 3 19.5523 3 19C3 18.4477 3.44772 18 4 18H5V17C5 16.4477 5.44772 16 6 16Z",
            }),
          })
        );
        t.Z = s;
      },
      4535: function (e, t, r) {
        "use strict";
        var n = r(85893),
          o = r(67294),
          i = r(95914);
        let s = o.memo((e) =>
          (0, n.jsxs)(i.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: [
              (0, n.jsx)("path", {
                d: "M5.27511 4.90729C5.68383 3.30164 7.30788 2.36461 8.90252 2.81438L18.1126 5.41212C19.7073 5.86189 20.6687 7.52814 20.2599 9.13379L17.7249 19.0927C17.3162 20.6984 15.6921 21.6354 14.0975 21.1856L4.88735 18.5879C3.29271 18.1381 2.33133 16.4719 2.74005 14.8662L5.27511 4.90729Z",
                fill: "url(#paint0_linear_3332_34154)",
              }),
              (0, n.jsx)("ellipse", {
                cx: "1.55695",
                cy: "1.62765",
                rx: "1.55695",
                ry: "1.62765",
                transform:
                  "matrix(0.962449 0.271461 -0.246685 0.969096 7.47775 4.66669)",
                fill: "url(#paint1_linear_3332_34154)",
              }),
              (0, n.jsx)("ellipse", {
                cx: "1.55695",
                cy: "1.62765",
                rx: "1.55695",
                ry: "1.62765",
                transform:
                  "matrix(0.962449 0.271461 -0.246685 0.969096 10.403 10)",
                fill: "url(#paint2_linear_3332_34154)",
              }),
              (0, n.jsx)("ellipse", {
                cx: "1.55695",
                cy: "1.62765",
                rx: "1.55695",
                ry: "1.62765",
                transform:
                  "matrix(0.962449 0.271461 -0.246685 0.969096 13.3282 15.3334)",
                fill: "url(#paint3_linear_3332_34154)",
              }),
              (0, n.jsxs)("defs", {
                children: [
                  (0, n.jsxs)("linearGradient", {
                    id: "paint0_linear_3332_34154",
                    x1: "13.5076",
                    y1: "4.11325",
                    x2: "9.09059",
                    y2: "19.7734",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                      (0, n.jsx)("stop", { stopColor: "#FF769F" }),
                      (0, n.jsx)("stop", { offset: "1", stopColor: "#FF1B1B" }),
                    ],
                  }),
                  (0, n.jsxs)("linearGradient", {
                    id: "paint1_linear_3332_34154",
                    x1: "1.55695",
                    y1: "0",
                    x2: "1.55695",
                    y2: "3.25531",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                      (0, n.jsx)("stop", { stopColor: "#B6E0FF" }),
                      (0, n.jsx)("stop", { offset: "1", stopColor: "#FFF6F6" }),
                    ],
                  }),
                  (0, n.jsxs)("linearGradient", {
                    id: "paint2_linear_3332_34154",
                    x1: "1.55695",
                    y1: "0",
                    x2: "1.55695",
                    y2: "3.25531",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                      (0, n.jsx)("stop", { stopColor: "#B6E0FF" }),
                      (0, n.jsx)("stop", { offset: "1", stopColor: "#FFF6F6" }),
                    ],
                  }),
                  (0, n.jsxs)("linearGradient", {
                    id: "paint3_linear_3332_34154",
                    x1: "1.55695",
                    y1: "0",
                    x2: "1.55695",
                    y2: "3.25531",
                    gradientUnits: "userSpaceOnUse",
                    children: [
                      (0, n.jsx)("stop", { stopColor: "#B6E0FF" }),
                      (0, n.jsx)("stop", { offset: "1", stopColor: "#FFF6F6" }),
                    ],
                  }),
                ],
              }),
            ],
          })
        );
        t.Z = s;
      },
      61338: function (e, t, r) {
        "use strict";
        let n;
        r.d(t, {
          Z: function () {
            return K;
          },
        });
        var o = r(85893),
          i = r(67294),
          s = r(9305),
          a = r(94745),
          l = r(90948),
          c = r(32350);
        let d = (0, l.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              paddingBottom: t(2.5),
            };
          }),
          C = (0, l.ZP)("div")((e) => {
            let { theme: t } = e;
            return {
              textAlign: "center",
              alignItems: "center",
              display: "flex",
              flexDirection: "column",
              "& a": { ...(0, c.GC)(), fontWeight: 400 },
              "& img": { marginBottom: t.spacing(3) },
            };
          }),
          u = (0, l.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return { marginTop: t(2), "& a": { margin: 2 }, maxWidth: 800 };
          });
        var h = r(70133),
          x = r(20209),
          p = r(95914);
        let _ = i.memo((e) =>
          (0, o.jsxs)(p.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: [
              (0, o.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M13.8556 2.01042C14.1999 1.96018 14.5455 2.09248 14.7682 2.35976C17.2757 5.36878 20 9.21266 20 13.7999C20 16.1453 19.1579 18.2104 17.6483 19.6893C16.1396 21.1674 14.0258 21.9999 11.5882 21.9999C9.03924 21.9999 7.10704 20.8282 5.8406 19.1449C4.5948 17.489 4 15.3564 4 13.3499C4 11.317 4.57968 9.76054 5.47779 8.52458C6.35873 7.31224 7.51181 6.4571 8.5693 5.76369C8.8326 5.59104 9.16183 5.55248 9.4579 5.65961C9.75396 5.76673 9.98229 6.00704 10.0741 6.3082C10.2241 6.79975 10.4331 7.25547 10.6343 7.58479C10.8629 7.30707 11.0942 6.94482 11.3582 6.44182C11.7901 5.61877 12.2669 4.50591 12.9585 2.89162C12.9985 2.79812 13.0393 2.70293 13.0809 2.60602C13.2179 2.28623 13.5113 2.06066 13.8556 2.01042ZM14.263 4.92165C13.8332 5.91424 13.4713 6.71911 13.1291 7.37126C12.6171 8.34673 12.1033 9.07347 11.3801 9.63813C10.7888 10.0998 10.1528 9.85682 9.85364 9.6654C9.55424 9.47384 9.31149 9.18921 9.12778 8.93146C8.96402 8.70171 8.80589 8.43417 8.66045 8.14396C8.063 8.60336 7.52787 9.10557 7.09574 9.70026C6.44973 10.5893 6 11.7329 6 13.3499C6 14.9936 6.49344 16.6859 7.43881 17.9425C8.36355 19.1717 9.72547 19.9999 11.5882 19.9999C13.5624 19.9999 15.1545 19.3326 16.2487 18.2606C17.3421 17.1895 18 15.6546 18 13.7999C18 10.5224 16.3184 7.58246 14.263 4.92165Z",
              }),
              (0, o.jsx)("path", {
                d: "M15 17.8C15 19.6667 13.7143 21 11.8235 21C9.93277 21 9 19.2222 9 17.6C9 15.9778 9.88235 15.2 10.7647 14.6C10.9412 15.2 11.2952 15.742 11.4706 15.6C11.9549 15.2078 12.2143 14.5555 12.8571 13C13.9286 14.3334 15 15.9333 15 17.8Z",
              }),
            ],
          })
        );
        var y = r(4535),
          g = r(13301),
          f = r(37899),
          j = r(42257),
          m = r(86650),
          B = r(2978),
          Z = r(13592),
          L = r(88296),
          v = r(82336),
          z = r.n(v);
        let w = (e) => {
          let { routeHelper: t } = e,
            r = t.newPageLink(),
            n = t.hotPageLink(),
            s = i.useContext(j.Z),
            { services: l } = i.useContext(f.Z),
            { liked: c } = i.useContext(m.w3),
            { crazyRouterChange: d } = i.useContext(Z.R),
            C = async () => {
              try {
                let { randomGamesService: e } = l,
                  r = (0, g.yz)(s),
                  n = (0, g.l7)(s),
                  o = await e.getRandomGame(c, { device: r, deviceType: n }),
                  i = t.gamePageLink(o.slug);
                d(i.href, i.as);
              } catch (e) {
                console.error("Error page error: ", e.message || e);
              }
            };
          return (0, o.jsxs)(o.Fragment, {
            children: [
              (0, o.jsx)(B.Z, {
                ...r,
                children: (0, o.jsxs)(L.Z, {
                  height: 50,
                  variant: "contained",
                  color: "white",
                  className: z().errorLinkButton,
                  children: [
                    (0, o.jsx)(x.Z, {}),
                    (0, o.jsx)(a.cC, { id: "error.btn.newGames" }),
                  ],
                }),
              }),
              (0, o.jsx)(B.Z, {
                ...n,
                children: (0, o.jsxs)(L.Z, {
                  height: 50,
                  variant: "contained",
                  color: "white",
                  className: z().errorLinkButton,
                  children: [
                    (0, o.jsx)(_, {}),
                    (0, o.jsx)(a.cC, { id: "error.btn.trendingGames" }),
                  ],
                }),
              }),
              (0, o.jsxs)(L.Z, {
                height: 50,
                variant: "contained",
                color: "white",
                onClick: C,
                className: z().errorLinkButton,
                children: [
                  (0, o.jsx)(y.Z, {}),
                  (0, o.jsx)(a.cC, { id: "error.btn.randomGame" }),
                ],
              }),
            ],
          });
        };
        var E = (0, h.Z)(w),
          b = r(63306);
        let M = (e, t) => Math.floor(Math.random() * (t - e + 1) + e),
          k = (0, l.ZP)("div")({
            placeItems: "center",
            fontSize: 20,
            textAlign: "center",
            "@keyframes glitch":
              ((n = {}),
              [...Array(20)].forEach((e, t) => {
                n[`${5 * t}%`] = {
                  clip: `rect(${M(t, 100)}px, 9999px, ${M(t, 100)}px, 0)`,
                };
              }),
              n),
          }),
          F = (0, l.ZP)("h1")((e) => {
            let {
              theme: { breakpoints: t },
            } = e;
            return {
              color: "#fff",
              fontSize: "10em",
              position: "relative",
              fontWeight: "900",
              lineHeight: "160px",
              [t.down(660)]: { fontSize: "7em", lineHeight: "107px" },
              [t.down(465)]: { fontSize: "5em", lineHeight: "80px" },
              "&::before, &::after": {
                content: "attr(data-title)",
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                overflow: "hidden",
                backgroundColor: "#000",
                color: "#fff",
              },
              "&::before": {
                left: 8,
                textShadow: "2px 0 #00ffea",
                animation: "glitch 3s infinite linear",
              },
              "&::after": {
                left: 8,
                textShadow: "-2px 0 #fe3a7f",
                animation: "glitch 2s infinite linear",
              },
            };
          }),
          H = () =>
            (0, o.jsxs)(k, {
              children: [
                (0, o.jsx)(F, { "data-title": "GAME", children: "GAME" }),
                (0, o.jsx)(F, { "data-title": "OVER", children: "OVER" }),
              ],
            });
        var G = r(28818),
          V = r(3411),
          P = r(80822),
          S = r(74112);
        let R = () => {
            let { routeHelper: e } = i.useContext(b.Z),
              t = e.homePageLink(),
              [r, n] = i.useState([]),
              { api: s } = i.useContext(f.Z).services,
              l = i.useContext(j.Z),
              c = (0, g.yz)(l),
              h = i.useCallback(async () => {
                let e = await s.getFilteredGames(
                  { sorting: "default", device: c },
                  { page: 1, size: 12 }
                );
                n(e.games.data.items);
              }, [s, c]);
            return (
              i.useEffect(() => {
                h();
              }, [h]),
              (0, o.jsxs)(d, {
                children: [
                  (0, o.jsxs)(C, {
                    sx: { mt: 5 },
                    children: [
                      (0, o.jsx)(H, {}),
                      (0, o.jsxs)("div", {
                        style: {
                          fontWeight: 400,
                          fontSize: 24,
                          color: V.D.white[80],
                          padding: 20,
                        },
                        children: [
                          (0, o.jsx)(a.cC, { id: "error.404.deadEnd" }),
                          (0, o.jsx)("br", {}),
                          (0, o.jsx)(a.cC, {
                            id: "error.404.pageDoesNotExist",
                          }),
                        ],
                      }),
                      (0, o.jsx)(B.Z, {
                        prefetch: !0,
                        ...t,
                        children: (0, o.jsxs)(L.Z, {
                          height: 50,
                          variant: "contained",
                          className: z().error404MainButton,
                          children: [
                            (0, o.jsx)(G.Z, {}),
                            " ",
                            (0, o.jsx)(a.cC, { id: "error.404.backBtn" }),
                          ],
                        }),
                      }),
                      (0, o.jsxs)("div", {
                        style: {
                          fontWeight: 700,
                          fontSize: 20,
                          color: V.D.white[80],
                          padding: 3,
                        },
                        children: [
                          (0, o.jsx)(a.cC, { id: "error.404.orTry" }),
                          ":",
                        ],
                      }),
                    ],
                  }),
                  (0, o.jsx)(u, {
                    children: (0, o.jsx)(S.Z, {
                      games: r,
                      justifyContent: "center",
                      customStyles: { width: "100%" },
                    }),
                  }),
                  (0, o.jsx)(P.Z, {
                    sx: {
                      display: "flex",
                      gap: { xs: 1, md: 3 },
                      marginTop: 3,
                      flexDirection: { xs: "column", sm: "row" },
                      width: { xs: "100%", md: "unset" },
                      padding: 3,
                      "& a": { width: 1 },
                    },
                    children: (0, o.jsx)(E, {}),
                  }),
                ],
              })
            );
          },
          A = (e) =>
            (0, o.jsxs)(p.Z, {
              ...e,
              viewBox: "0 0 194 218",
              fill: "none",
              children: [
                (0, o.jsxs)("g", {
                  clipPath: "url(#clip0_11_913)",
                  children: [
                    (0, o.jsx)("path", {
                      d: "M187.633 58.3368C187.983 39.5888 186.254 15.3036 176.167 3.815C173.957 1.308 171.003 0 167.545 0C161.659 0 154.285 4.0548 145.073 12.3606C131.726 6.649 115.927 3.8586 96.9562 3.8586C77.9851 3.8586 62.2087 6.649 48.8829 12.3388C39.7146 4.0548 32.3406 0 26.4545 0C23.0192 0 20.0433 1.308 17.8771 3.7932C7.81164 15.2818 6.06113 39.5016 6.41123 58.2278C2.16625 70.2832 0 84.3224 0 99.953C0 134.375 10.0873 160.099 29.9993 176.406C39.3864 184.057 50.6115 189.42 64.0029 192.581L61.2896 193.911H61.224L61.1584 193.976C60.1737 194.5 59.189 194.979 58.2044 195.481C58.0074 195.59 57.8105 195.677 57.5917 195.786C54.5283 197.312 51.3774 198.881 47.9639 200.952L47.0011 201.454L46.6291 201.65L46.279 201.89C44.6379 203.067 43.5439 204.833 43.2375 206.773C42.9312 208.67 43.3907 210.675 44.5285 212.223C45.6882 213.814 47.4825 214.904 49.43 215.166C50.6115 215.34 51.8588 215.558 53.0841 215.755C53.2592 215.776 53.4124 215.82 53.5874 215.842C56.3882 216.3 59.2547 216.757 62.2305 216.997L65.3158 217.346C66.4974 217.477 67.6352 217.586 68.7949 217.629L75.1405 217.978H75.3812C76.4097 218 77.4381 218 78.4446 218C86.6064 218 94.5055 217.411 101.901 216.256C110.632 214.948 119.407 212.506 127.984 208.997C136.561 205.465 144.526 200.931 151.725 195.524C166.276 184.254 177.545 169.386 184.372 152.447C186.735 146.649 188.617 140.392 189.974 133.874C192.621 123.737 193.934 112.314 193.934 99.9748C193.934 84.3878 191.79 70.3922 187.567 58.3586L187.633 58.3368ZM184.307 132.566C183.081 138.604 181.309 144.556 178.989 150.311C172.622 166.138 161.878 180.351 148.224 190.924C141.332 196.113 133.739 200.386 125.774 203.656C117.787 206.926 109.472 209.28 101.004 210.566C93.5209 211.743 85.9718 212.245 78.4665 212.245C77.4818 212.245 76.4972 212.245 75.5125 212.223L69.1669 211.874C68.0947 211.809 67.0444 211.722 65.9941 211.613L62.8213 211.264C59.9111 211.024 57.0447 210.544 54.1782 210.087C52.8872 209.869 51.5743 209.651 50.2833 209.476C49.4518 209.345 48.8829 208.561 49.0361 207.732C49.1017 207.296 49.3862 206.904 49.7144 206.664L50.8522 206.075C54.1344 204.07 57.2416 202.522 60.2831 201.018C61.4866 200.407 62.6901 199.819 63.8716 199.208L68.1385 197.137L75.6438 193.475C77.3068 192.625 78.926 191.84 80.5233 191.055C81.4205 190.619 82.2957 190.205 83.1491 189.769C62.4275 188.025 46.1696 182.161 33.7192 171.98C15.2294 156.851 5.84232 132.675 5.84232 100.04C5.84232 84.4968 8.00857 70.9154 12.2754 59.2742C11.9253 44.3848 12.8225 18.53 22.2752 7.7172C23.3912 6.4528 24.8134 5.9078 26.4545 5.9078C32.5157 5.9078 41.487 13.3198 47.767 19.3584C60.9833 12.9492 77.2411 9.7882 96.9781 9.7882C116.715 9.7882 132.995 12.9492 146.211 19.3802C152.491 13.3416 161.462 5.9296 167.545 5.9296V5.8642C169.208 5.8642 170.631 6.4092 171.747 7.6736C181.221 18.4864 182.097 44.4284 181.746 59.3178C185.991 70.9372 188.136 84.5186 188.136 99.9966C188.136 112.03 186.845 122.887 184.328 132.588L184.307 132.566Z",
                      fill: "#F9FAFF",
                    }),
                    (0, o.jsx)("path", {
                      d: "M139.275 53.3664C130.238 45.9762 116.387 42.3356 96.9781 42.3356C77.5694 42.3356 63.7185 45.9326 54.6815 53.3664C43.9815 62.13 38.7957 77.39 38.7957 99.953C38.7957 147.782 62.0555 157.57 96.9781 157.57C131.901 157.57 155.161 147.782 155.161 99.953C155.161 77.3682 149.931 62.13 139.275 53.3664ZM66.9569 98.8412C65.9285 98.8412 64.9001 98.4488 64.1124 97.664C62.5369 96.0944 62.5369 93.5438 64.1124 91.9742L68.8606 87.2436L64.1124 82.513C62.5369 80.9434 62.5369 78.3928 64.1124 76.8232C65.6878 75.2536 68.2479 75.2536 69.8234 76.8232L74.5717 81.5538L79.3199 76.8232C80.8954 75.2536 83.4555 75.2536 85.0309 76.8232C86.6064 78.3928 86.6064 80.9434 85.0309 82.513L80.2827 87.2436L85.0309 91.9742C86.6064 93.5438 86.6064 96.0944 85.0309 97.664C84.2432 98.4488 83.2148 98.8412 82.1864 98.8412C81.1579 98.8412 80.1295 98.4488 79.3418 97.664L74.5935 92.9334L69.8453 97.664C69.0576 98.4488 68.0291 98.8412 67.0007 98.8412H66.9569ZM120.479 127.966H118.75V132.348C118.75 138.692 114.396 143.88 109.057 143.88C103.718 143.88 99.3632 138.692 99.3632 132.348V127.966H73.6745C71.9678 127.966 70.5674 126.593 70.5674 124.87C70.5674 123.148 71.9459 121.775 73.6745 121.775H120.457C122.164 121.775 123.564 123.148 123.564 124.87C123.564 126.593 122.185 127.966 120.457 127.966H120.479ZM129.888 91.9742C131.463 93.5438 131.463 96.0944 129.888 97.664C129.1 98.4488 128.072 98.8412 127.043 98.8412C126.015 98.8412 124.986 98.4488 124.199 97.664L119.45 92.9334L114.702 97.664C113.914 98.4488 112.886 98.8412 111.857 98.8412C110.829 98.8412 109.801 98.4488 109.013 97.664C107.437 96.0944 107.437 93.5438 109.013 91.9742L113.761 87.2436L109.013 82.513C107.437 80.9434 107.437 78.3928 109.013 76.8232C110.588 75.2536 113.148 75.2536 114.724 76.8232L119.472 81.5538L124.22 76.8232C125.796 75.2536 128.356 75.2536 129.931 76.8232C131.507 78.3928 131.507 80.9434 129.931 82.513L125.183 87.2436L129.931 91.9742H129.888Z",
                      fill: "#F9FAFF",
                    }),
                  ],
                }),
                (0, o.jsx)("defs", {
                  children: (0, o.jsx)("clipPath", {
                    id: "clip0_11_913",
                    children: (0, o.jsx)("rect", {
                      width: "194",
                      height: "218",
                      fill: "white",
                    }),
                  }),
                }),
              ],
            });
        var D = r(4388),
          I = r(2734),
          N = r(88650),
          W = r(90512);
        let O = () => {
          let { routeHelper: e } = i.useContext(b.Z),
            { openMainFeedbackDrawer: t } = i.useContext(N.l),
            r = e.homePageLink(),
            { spacing: n } = (0, I.Z)();
          return (0, o.jsx)(d, {
            children: (0, o.jsxs)(C, {
              sx: { height: "calc(100vh - 190px)", justifyContent: "center" },
              children: [
                (0, o.jsx)(A, {
                  style: { width: 194, height: 218, marginBottom: 45 },
                }),
                (0, o.jsx)("h2", {
                  style: { fontWeight: 700, fontSize: 28 },
                  children: (0, o.jsx)(a.cC, { id: "error.500.wrong" }),
                }),
                (0, o.jsx)("div", {
                  style: {
                    fontWeight: 400,
                    fontSize: 20,
                    color: V.D.white[60],
                  },
                  children: (0, o.jsx)(a.cC, { id: "error.500.reload" }),
                }),
                (0, o.jsxs)(L.Z, {
                  height: 50,
                  variant: "contained",
                  className: (0, W.Z)(z().error500button, z().reload),
                  onClick: () => location.reload(),
                  children: [
                    (0, o.jsx)(D.Z, {}),
                    " ",
                    (0, o.jsx)(a.cC, { id: "error.500.reloadBtn" }),
                  ],
                }),
                (0, o.jsx)(B.Z, {
                  prefetch: !0,
                  ...r,
                  children: (0, o.jsxs)(L.Z, {
                    height: 50,
                    variant: "outlined",
                    className: z().error500button,
                    color: "white",
                    children: [
                      (0, o.jsx)(G.Z, {}),
                      " ",
                      (0, o.jsx)(a.cC, { id: "error.404.backBtn" }),
                    ],
                  }),
                }),
                (0, o.jsx)("div", {
                  style: { marginTop: n(4) },
                  children: (0, o.jsx)(a.cC, {
                    id: "error.500.notWorking",
                    values: {
                      link: (0, o.jsx)(L.Z, {
                        variant: "link",
                        onClick: () => {
                          t("errorPage");
                        },
                        children: (0, o.jsx)(a.cC, {
                          id: "error.500.contactUs",
                        }),
                      }),
                    },
                  }),
                }),
              ],
            }),
          });
        };
        var U = r(11163),
          T = r(33209),
          J = r(83808),
          K = function (e) {
            class t extends i.Component {
              static async getInitialProps(t) {
                try {
                  let r = e.getInitialProps ? await e.getInitialProps(t) : {};
                  return (
                    r.statusCode && t.res && (t.res.statusCode = r.statusCode),
                    r
                  );
                } catch (r) {
                  let e = 500;
                  return (
                    console.error(r.message),
                    r instanceof s.Z && (e = r.statusCode),
                    t.res && (t.res.statusCode = e),
                    { statusCode: e }
                  );
                }
              }
              static getDerivedStateFromError(e) {
                return { hasError: !0 };
              }
              constructor(e) {
                super(e);
                let { statusCode: t } = e;
                this.state = { hasError: !!(t && t >= 400) };
              }
              async componentDidMount() {
                let e = (0, T.Jx)(window.location.hostname),
                  { analyticsService: t } = (0, J.t)(e);
                this.props.statusCode &&
                  t.trackGAEvent({
                    eventCategory: "error-page",
                    eventAction: "error-page",
                    eventLabel: `${this.props.statusCode}`,
                    nonInteraction: !0,
                  });
              }
              componentDidUpdate() {
                let { hasError: e } = this.state;
                if (!this.props.statusCode || this.props.statusCode < 400) {
                  e && this.setState({ hasError: !1 });
                  return;
                }
                if (!e) {
                  let e = (0, T.Jx)(window.location.hostname),
                    { analyticsService: t } = (0, J.t)(e);
                  t.trackGAEvent({
                    eventCategory: "error-page",
                    eventAction: "error-page",
                    eventLabel: `${this.props.statusCode}`,
                    nonInteraction: !0,
                  }),
                    this.setState({ hasError: !0 });
                }
              }
              render() {
                let { statusCode: t, router: r } = this.props;
                return this.hasError()
                  ? r
                    ? t >= 400 && t < 500
                      ? this.render404()
                      : this.render500()
                    : this.renderCouldNotRenderErrorPage()
                  : (0, o.jsx)(e, { ...this.props });
              }
              render404() {
                return (0, o.jsx)(R, {});
              }
              render500() {
                return (0, o.jsx)(O, {});
              }
              renderCouldNotRenderErrorPage() {
                return (0, o.jsx)(i.Fragment, {
                  children: (0, o.jsx)("article", {
                    children: (0, o.jsx)("main", {
                      children: "An error has occured",
                    }),
                  }),
                });
              }
              hasError() {
                let { hasError: e } = this.state;
                return e;
              }
            }
            return (0, U.withRouter)(t);
          };
      },
      82336: function (e) {
        e.exports = {
          czyButton: "Error_czyButton__EALON",
          "czyButton--contained--purple":
            "Error_czyButton--contained--purple__kdMQ9",
          "czyButton--contained--white":
            "Error_czyButton--contained--white__Y_19P",
          "czyButton--contained--grey":
            "Error_czyButton--contained--grey__zYQCO",
          "czyButton--contained--alert":
            "Error_czyButton--contained--alert__9BTTm",
          "czyButton--contained--success":
            "Error_czyButton--contained--success__MXgHr",
          "czyButton--contained--black":
            "Error_czyButton--contained--black__4bjPj",
          "czyButton--contained--green-gradient":
            "Error_czyButton--contained--green-gradient__wsIJF",
          "czyButton--outlined--purple":
            "Error_czyButton--outlined--purple__Km0cB",
          "czyButton--link--purple": "Error_czyButton--link--purple__lqVBn",
          "czyButton--outlined--white":
            "Error_czyButton--outlined--white__8GNFZ",
          "czyButton--link--white": "Error_czyButton--link--white__4fRwh",
          "czyButton--outlined--grey": "Error_czyButton--outlined--grey__8fZ_p",
          "czyButton--link--grey": "Error_czyButton--link--grey__hwkK7",
          "czyButton--outlined--alert":
            "Error_czyButton--outlined--alert___xF34",
          "czyButton--link--alert": "Error_czyButton--link--alert__DPEI3",
          "czyButton--outlined--success":
            "Error_czyButton--outlined--success__dG5Om",
          "czyButton--link--success": "Error_czyButton--link--success__9zfgf",
          "czyButton--outlined": "Error_czyButton--outlined__n_UnF",
          "czyButton--disabled": "Error_czyButton--disabled__ZnQ6X",
          "czyButton--height50": "Error_czyButton--height50__WgbJZ",
          "czyButton--height34": "Error_czyButton--height34__jYKhd",
          "czyButton--fullWidth": "Error_czyButton--fullWidth__dnJ19",
          error404MainButton: "Error_error404MainButton__RKj2c",
          error500button: "Error_error500button__3y40f",
          reload: "Error_reload__FDhHy",
          contentNotAvailableButton: "Error_contentNotAvailableButton__O_8da",
          errorLinkButton: "Error_errorLinkButton__iMFMA",
        };
      },
    },
  ]);
