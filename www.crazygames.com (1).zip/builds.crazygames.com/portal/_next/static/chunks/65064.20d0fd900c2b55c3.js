!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      a = new e.Error().stack;
    a &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[a] = "fffed578-016f-438c-8a96-1419236b697c"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-fffed578-016f-438c-8a96-1419236b697c"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [65064],
    {
      65064: function (e) {
        e.exports = {
          messages: JSON.parse(
            '{"game.head.metaDescriptionFallback":["Play ",["name"]," for free on CrazyGames. It is one of our best ",["category"]," games!"],"game.head.title":[["name"]," \uD83D\uDD79️ Play on CrazyGames"],"game.about":"About","game.controls":"Controls","game.rating":"Rating","game.developer":"Developer","game.released":"Released","game.technology":"Technology","game.votes":[["number"]," votes"],"game.moreGames":"More Games","game.share.button":"Share","game.share.modal.title":"Share this game","game.share.modal.copy":"Copy","game.share.modal.confirm":"Ok","game.series.title":"More Games In This Series","game.categorization":"Categorization","game.mobile.relatedGames":"Related Games","game.mobile.showFullDescription":"Show full description","game.mobile.hideFullDescription":"Hide full description","game.mobile.play":"Play now","game.mobile.join":"Join game","game.mobile.continuePlaying":"Continue playing…","game.mobile.install":"or add it as an App","game.feedback":"Feedback","game.feedback.performance":"I have performance issues","game.feedback.suggestion":"I have suggestions","game.feedback.input":"Write your feedback","game.feedback.email":"Your email (optional)","game.feedback.sent":"Feedback sent!","game.feedback.sentLabel":"Thanks for your feedback! This will help the developer improve the game and make it even more awesome!","game.feedback.close":"Close","game.backToGame":"Back to game","game.lastUpdated":"Last Updated","game.info.dev":["Developed by ",["developerName"]],"game.info.devContact":"Contact the developer by entering your message below","game.info.email":"Email","game.info.message":"Message","game.info.subject.label":"Select a subject","game.info.subject.bug":"Bug","game.info.subject.feedback":"Feedback","game.info.subject.other":"Other","game.info.contact.sendBtn":"Send message","game.info.contact.cancelBtn":"Cancel","game.info.contact.success":"Your message has been sent!","game.info.contact.error":"Internal error. Please try again later.","game.modal.cancel":"Cancel","game.platform":"Platform","game.platforms":"Platforms","game.wikipages":"Wiki pages","game.info.faq.title":"FAQ","game.info.video.title":"Gameplay Video","game.embed.button":"Embed","game.embed.modal.title":"Embed","game.embed.modal.copy":"Copy","game.embed.modal.confirm":"Ok","game.embed.modal.warning":["our ",["tAndCLink"]," apply"],"game.embed.modal.tAndC":"Terms and Conditions","game.mobile.unavailable":["Use your computer to play ",["game"],". Or try one of the games below!"],"game.mobile.unavailableOsStore":"Download the app to play on mobile","game.mobile.unavailableOtherGamesButton":"Show other games","game.mobile.warningPlay":"Play anyway","game.mobile.warningSubText":"This game might not work on your device","game.mobile.dislikeFeedback.title":"Don\'t like this game?","game.mobile.dislikeFeedback.action":"Tell us why","game.mobile.inviteFriends":"Invite friends","game.qrMobile.title":"Play on mobile! ","game.qrMobile.subtitle":"Scan this QR code to enjoy some playtime on your mobile! ","game.relatedTabs.foryou":"For you","game.relatedTabs.new":"New","game.relatedTabs.trending":"Trending","game.adUnitPlaceholder.title":"Your rewards are locked by your ad blocker ...","game.adUnitPlaceholder.subtitle":"Support CrazyGames and our game developers by disabling your ad blocker","game.preview.report.button":"Report","game.preview.contentWarning":"You are playing this game in a QA environment. This link should not be shared with end users. No revenue will be attributed.","game.related.showMoreGames":"Show more games","game.adUnitLogin.title":"Log in to save your progress! ","game.adUnitLogin.login":"Log in","game.adUnitFriends.title":["Play online with ",["yourFriends"]],"game.adUnitFriends.yourFriends":"your friends","game.adUnitFriends.inviteFriends":"Invite friends","game.adUnitLogin.title2":"Log in to play with friends! ","game.adUnitMobile.title":["Play ",["onMobile"],", no installs needed"],"game.adUnitMobile.onMobile":"on mobile"}'
          ),
        };
      },
    },
  ]);
