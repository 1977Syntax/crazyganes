!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "cf4dd2c3-bed8-463c-9e27-7ca767ea5d3d"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-cf4dd2c3-bed8-463c-9e27-7ca767ea5d3d"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [67069],
    {
      67069: function (e, t, n) {
        n.r(t),
          n.d(t, {
            default: function () {
              return y;
            },
          });
        var a = n(85893),
          o = n(67294),
          s = n(42257),
          r = n(90948),
          i = n(70917),
          l = n(32350),
          d = n(31601);
        let u = (0, r.ZP)("div", {
            shouldForwardProp: (e) =>
              "hide" !== e && "isIos" !== e && "isDesktop" !== e,
          })((e) => {
            let { hide: t } = e;
            return {
              position: "fixed",
              bottom: 20,
              right: 20,
              zIndex: 10,
              "& button": { fontSize: l.CH.h3 },
              transition: "opacity 0.2s ease",
              opacity: 1,
              ...(t && { opacity: 0 }),
            };
          }),
          c = i.F4`
  0% { transform: scale(1,1)    translateY(0) }
  10% { transform: scale(1.03,.97) translateY(0) }
  30% { transform: scale(.97,1.03) translateY(-30px) }
  50% { transform: scale(1,1)    translateY(0) }
  57% { transform: scale(1,1)    translateY(-3px) }
  64% { transform: scale(1,1)    translateY(0) }
  100% { transform: scale(1,1)    translateY(0) 
  `,
          f = (0, r.ZP)(d.Sn, {
            shouldForwardProp: (e) =>
              "isDesktop" !== e && "hasLabel" !== e && "playAnimation" !== e,
          })((e) => {
            let { isDesktop: t, hasLabel: n, playAnimation: a } = e;
            return {
              boxShadow: "0px 10px 40px rgba(0, 0, 0, 0.2)",
              "& svg": {
                height: n ? 20 : 25,
                width: n ? 20 : 25,
                marginRight: n ? 1 : 0,
                position: n ? "static" : "absolute",
              },
              ...(t && { "&:hover": { animationName: "none" } }),
              ...(a && {
                animationDuration: "1.5s",
                animationIterationCount: 4,
                animationName: c,
                animationTimingFunction: "ease",
              }),
            };
          });
        var m = n(84872),
          w = n(51491),
          p = n(75485);
        let g = (e) => {
          let {
              height: t,
              onClick: n,
              label: r,
              playAnimation: i,
              newMainContainer: l,
            } = e,
            [d, c] = o.useState(0),
            [g, y] = o.useState(!1),
            [b, M] = o.useTransition(),
            h = o.useContext(s.Z),
            { isBackToTopEnabled: v, isBackToTopVisible: E } = o.useContext(
              p.i
            ),
            _ = (0, w.Z)();
          o.useEffect(() => {
            let e = l
              ? document.getElementById("gamePageMainContainer").scrollTop
              : window.scrollY;
            c(e);
          }, [l]),
            o.useEffect(() => {
              let e = l
                  ? document.getElementById("gamePageMainContainer")
                  : window,
                t = () => {
                  let e = l
                    ? document.getElementById("gamePageMainContainer").scrollTop
                    : window.scrollY;
                  M(() => {
                    c(e), y(!1);
                  });
                },
                n = "onscrollend" in window;
              return (
                n && e.addEventListener("scrollend", t, { passive: !0 }),
                function () {
                  n && e.removeEventListener("scrollend", t);
                }
              );
            }, [l]),
            o.useEffect(() => {
              let e = l
                  ? document.getElementById("gamePageMainContainer")
                  : window,
                t = "onscrollend" in window;
              if (!t || g) return;
              let n = () => {
                M(() => {
                  y(!0);
                });
              };
              return (
                e.addEventListener("scroll", n, { passive: !0 }),
                function () {
                  e.removeEventListener("scroll", n);
                }
              );
            }, [g, l]),
            o.useEffect(() => {
              let e;
              let t = l
                  ? document.getElementById("gamePageMainContainer")
                  : window,
                n = "onscrollend" in window;
              if (n) return;
              let a = () => {
                M(() => {
                  y(!0);
                }),
                  e && window.clearTimeout(e),
                  (e = window.setTimeout(() => {
                    M(() => {
                      c(window.scrollY), y(!1);
                    });
                  }, 100));
              };
              return (
                t.addEventListener("scroll", a, { passive: !0 }),
                function () {
                  t.removeEventListener("scroll", a), window.clearTimeout(e);
                }
              );
            }, [l]);
          let k = o.useCallback(() => {
            let e = l
              ? document.getElementById("gamePageMainContainer")
              : window;
            e.scrollTo({ top: 0, left: 0, behavior: "smooth" }), n && n();
          }, [n, l]);
          if (d < t || !v || !E) return null;
          let I = !!i && h.isDesktop;
          return (0, a.jsx)(u, {
            isDesktop: h.isDesktop,
            hide: g,
            isIos: _,
            children: (0, a.jsxs)(f, {
              hasLabel: !!r,
              isDesktop: h.isDesktop,
              height: 50,
              sx: { width: r ? "auto" : 50 },
              variant: "contained",
              playAnimation: I,
              onClick: k,
              children: [(0, a.jsx)(m.Z, {}), r],
            }),
          });
        };
        var y = g;
      },
    },
  ]);
