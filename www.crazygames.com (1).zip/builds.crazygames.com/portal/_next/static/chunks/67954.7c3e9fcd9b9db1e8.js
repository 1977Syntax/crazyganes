!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "27387ebb-5ddb-42ac-86d5-785086b803de"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-27387ebb-5ddb-42ac-86d5-785086b803de"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [67954],
    {
      67954: function (e, t, a) {
        a.r(t);
        var n = a(85893),
          d = a(67294),
          l = a(2734),
          i = a(80822),
          o = a(42257),
          r = a(31099),
          s = a(13422),
          u = a(94984),
          b = a(5152),
          p = a.n(b);
        let y = p()(() => a.e(29660).then(a.bind(a, 29660)), {
            loadableGenerated: { webpack: () => [29660] },
            loading: () => null,
            ssr: !1,
          }),
          g = p()(() => a.e(99536).then(a.bind(a, 99536)), {
            loadableGenerated: { webpack: () => [99536] },
            loading: () => null,
            ssr: !1,
          }),
          h = () => {
            let { spacing: e } = (0, l.Z)(),
              { isDesktop: t } = d.useContext(o.Z),
              { loading: a, shouldDisplayRecent: b } = d.useContext(s.rh);
            return (0, n.jsx)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                gap: e(3),
                alignItems: "center",
                height: t ? 84 : 74,
                paddingTop: t && !b ? e(1.5) : void 0,
                paddingLeft: e(2),
                paddingRight: e(2),
                position: "relative",
                borderBottom: b ? "1px solid #292929" : void 0,
              },
              children:
                a || null === b
                  ? (0, n.jsx)("div", {
                      style: {
                        height: "100%",
                        width: "100%",
                        position: "relative",
                      },
                      children: (0, n.jsx)(r.Z, {}),
                    })
                  : b
                  ? (0, n.jsx)(i.Z, {
                      sx: {
                        height: 50,
                        width: "100%",
                        position: "relative",
                        display: "flex",
                        alignItems: "center",
                        "& .double-arrow": { display: "none" },
                        "& .arrow": { height: "100%", width: 30, top: 0 },
                        "& ul": {
                          padding: 0,
                          "& li": {
                            mr: 0.5,
                            "& .gameThumbTitleContainer": { display: "none" },
                            "& > div": {
                              height: "50px !important",
                              aspectRatio: "89 / 50",
                            },
                          },
                          "& a, .skeleton": {
                            height: "50px !important",
                            aspectRatio: "89 / 50",
                          },
                        },
                      },
                      children: (0, n.jsx)(u.H, {
                        newClickOrigin: "recent",
                        children: (0, n.jsx)(g, {}),
                      }),
                    })
                  : (0, n.jsx)(y, {}),
            });
          };
        t.default = h;
      },
    },
  ]);
