!(function () {
  try {
    var t =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      e = new t.Error().stack;
    e &&
      ((t._sentryDebugIds = t._sentryDebugIds || {}),
      (t._sentryDebugIds[e] = "e368bd68-5a22-4ea1-b4b0-b664f7127d78"),
      (t._sentryDebugIdIdentifier =
        "sentry-dbid-e368bd68-5a22-4ea1-b4b0-b664f7127d78"));
  } catch (t) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [68419],
    {
      30954: function (t, e, n) {
        "use strict";
        n.d(e, {
          Z: function () {
            return f;
          },
        });
        var i = n(87462),
          o = n(63366),
          r = n(67294),
          a = n(33703),
          l = n(94780),
          s = n(32289),
          u = n(34867);
        function d(t) {
          return (0, u.ZP)("MuiOption", t);
        }
        (0, n(1588).Z)("MuiOption", [
          "root",
          "disabled",
          "selected",
          "highlighted",
        ]);
        var c = n(44922),
          h = n(85893);
        let g = [
            "children",
            "component",
            "disabled",
            "label",
            "slotProps",
            "slots",
            "value",
          ],
          p = r.forwardRef(function (t, e) {
            let {
                children: n,
                component: u,
                disabled: p,
                label: f,
                slotProps: m = {},
                slots: y = {},
                value: _,
              } = t,
              b = (0, o.Z)(t, g),
              x = r.useContext(s.j);
            if (!x)
              throw Error(
                "OptionUnstyled must be used within a SelectUnstyled"
              );
            let w = u || y.root || "li",
              j = { value: _, label: f || n, disabled: p },
              v = x.getOptionState(j),
              z = x.getOptionProps(j),
              P = x.listboxRef,
              B = (0, i.Z)({}, t, v),
              C = r.useRef(null),
              k = (0, a.Z)(e, C);
            r.useEffect(() => {
              if (v.highlighted) {
                if (!P.current || !C.current) return;
                let t = P.current.getBoundingClientRect(),
                  e = C.current.getBoundingClientRect();
                e.top < t.top
                  ? (P.current.scrollTop -= t.top - e.top)
                  : e.bottom > t.bottom &&
                    (P.current.scrollTop += e.bottom - t.bottom);
              }
            }, [v.highlighted, P]);
            let M = (function (t) {
                let { disabled: e, highlighted: n, selected: i } = t;
                return (0, l.Z)(
                  {
                    root: [
                      "root",
                      e && "disabled",
                      n && "highlighted",
                      i && "selected",
                    ],
                  },
                  d,
                  {}
                );
              })(B),
              Z = (0, c.Z)({
                elementType: w,
                externalSlotProps: m.root,
                externalForwardedProps: b,
                additionalProps: (0, i.Z)({}, z, { ref: k }),
                className: M.root,
                ownerState: B,
              });
            return (0, h.jsx)(w, (0, i.Z)({}, Z, { children: n }));
          });
        var f = r.memo(p);
      },
      88078: function (t, e, n) {
        "use strict";
        n.d(e, {
          Z: function () {
            return C;
          },
        });
        var i = n(63366),
          o = n(87462),
          r = n(67294),
          a = n(90512),
          l = n(70917),
          s = n(94780),
          u = n(41796),
          d = n(90948),
          c = n(71657),
          h = n(1588),
          g = n(34867);
        function p(t) {
          return (0, g.ZP)("MuiSkeleton", t);
        }
        (0, h.Z)("MuiSkeleton", [
          "root",
          "text",
          "rectangular",
          "rounded",
          "circular",
          "pulse",
          "wave",
          "withChildren",
          "fitContent",
          "heightAuto",
        ]);
        var f = n(85893);
        let m = [
            "animation",
            "className",
            "component",
            "height",
            "style",
            "variant",
            "width",
          ],
          y = (t) => t,
          _,
          b,
          x,
          w,
          j = (t) => {
            let {
              classes: e,
              variant: n,
              animation: i,
              hasChildren: o,
              width: r,
              height: a,
            } = t;
            return (0, s.Z)(
              {
                root: [
                  "root",
                  n,
                  i,
                  o && "withChildren",
                  o && !r && "fitContent",
                  o && !a && "heightAuto",
                ],
              },
              p,
              e
            );
          },
          v = (0, l.F4)(
            _ ||
              (_ = y`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)
          ),
          z = (0, l.F4)(
            b ||
              (b = y`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)
          ),
          P = (0, d.ZP)("span", {
            name: "MuiSkeleton",
            slot: "Root",
            overridesResolver: (t, e) => {
              let { ownerState: n } = t;
              return [
                e.root,
                e[n.variant],
                !1 !== n.animation && e[n.animation],
                n.hasChildren && e.withChildren,
                n.hasChildren && !n.width && e.fitContent,
                n.hasChildren && !n.height && e.heightAuto,
              ];
            },
          })(
            ({ theme: t, ownerState: e }) => {
              let n =
                  String(t.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1] ||
                  "px",
                i = parseFloat(t.shape.borderRadius);
              return (0, o.Z)(
                {
                  display: "block",
                  backgroundColor: t.vars
                    ? t.vars.palette.Skeleton.bg
                    : (0, u.Fq)(
                        t.palette.text.primary,
                        "light" === t.palette.mode ? 0.11 : 0.13
                      ),
                  height: "1.2em",
                },
                "text" === e.variant && {
                  marginTop: 0,
                  marginBottom: 0,
                  height: "auto",
                  transformOrigin: "0 55%",
                  transform: "scale(1, 0.60)",
                  borderRadius: `${i}${n}/${
                    Math.round((i / 0.6) * 10) / 10
                  }${n}`,
                  "&:empty:before": { content: '"\\00a0"' },
                },
                "circular" === e.variant && { borderRadius: "50%" },
                "rounded" === e.variant && {
                  borderRadius: (t.vars || t).shape.borderRadius,
                },
                e.hasChildren && { "& > *": { visibility: "hidden" } },
                e.hasChildren && !e.width && { maxWidth: "fit-content" },
                e.hasChildren && !e.height && { height: "auto" }
              );
            },
            ({ ownerState: t }) =>
              "pulse" === t.animation &&
              (0, l.iv)(
                x ||
                  (x = y`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),
                v
              ),
            ({ ownerState: t, theme: e }) =>
              "wave" === t.animation &&
              (0, l.iv)(
                w ||
                  (w = y`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),
                z,
                (e.vars || e).palette.action.hover
              )
          ),
          B = r.forwardRef(function (t, e) {
            let n = (0, c.Z)({ props: t, name: "MuiSkeleton" }),
              {
                animation: r = "pulse",
                className: l,
                component: s = "span",
                height: u,
                style: d,
                variant: h = "text",
                width: g,
              } = n,
              p = (0, i.Z)(n, m),
              y = (0, o.Z)({}, n, {
                animation: r,
                component: s,
                variant: h,
                hasChildren: Boolean(p.children),
              }),
              _ = j(y);
            return (0,
            f.jsx)(P, (0, o.Z)({ as: s, ref: e, className: (0, a.Z)(_.root, l), ownerState: y }, p, { style: (0, o.Z)({ width: g, height: u }, d) }));
          });
        var C = B;
      },
      59411: function (t, e, n) {
        "use strict";
        var i = n(85893),
          o = n(67294),
          r = n(95914);
        let a = o.memo((t) =>
          (0, i.jsx)(r.Z, {
            ...t,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M15.6699 5.25759C15.2599 4.88759 14.6276 4.92005 14.2576 5.33007C13.8876 5.7401 13.92 6.37243 14.3301 6.74243L19.0483 11H3C2.44772 11 2 11.4477 2 12C2 12.5523 2.44772 13 3 13H19.0483L14.3301 17.2576C13.92 17.6276 13.8876 18.2599 14.2576 18.6699C14.6276 19.08 15.2599 19.1124 15.6699 18.7424L21.2109 13.7424C22.263 12.793 22.263 11.207 21.2109 10.2576L15.6699 5.25759Z",
            }),
          })
        );
        e.Z = a;
      },
      82921: function (t, e, n) {
        "use strict";
        var i = n(85893);
        n(67294);
        var o = n(94745),
          r = n(88061);
        let a = (t) => {
          let { tag: e, topGames: n, mobileGames: a, linkBoostedGames: l } = t,
            s = (t) =>
              (0, i.jsx)("ol", {
                children: t.map((t) =>
                  (0, i.jsx)(
                    "li",
                    {
                      children: (0, i.jsx)(r.Z, {
                        slug: t.slug,
                        children: (0, i.jsx)(i.Fragment, { children: t.name }),
                      }),
                    },
                    t.slug
                  )
                ),
              });
          return (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)("h2", {
                children: (0, i.jsx)(o.cC, { id: "tag.faq.faq" }),
              }),
              (0, i.jsx)("h3", {
                children: (0, i.jsx)(o.cC, {
                  id: "tag.faq.popular",
                  values: { title: e.title },
                }),
              }),
              s(n),
              (0, i.jsx)("h3", {
                children: (0, i.jsx)(o.cC, {
                  id: "tag.faq.mobile",
                  values: { title: e.title },
                }),
              }),
              s(a),
              l.length > 0 &&
                (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsx)("h3", {
                      children: (0, i.jsx)(o.cC, {
                        id: "tag.faq.whatAreSomeUnderrated",
                        values: { title: e.title },
                      }),
                    }),
                    s(l),
                  ],
                }),
              e.intro &&
                (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsx)("h3", {
                      children: (0, i.jsx)(o.cC, {
                        id: "tag.faq.whatAre",
                        values: { title: e.title },
                      }),
                    }),
                    (0, i.jsx)("div", {
                      dangerouslySetInnerHTML: { __html: e.intro },
                    }),
                  ],
                }),
            ],
          });
        };
        e.Z = a;
      },
      3040: function (t, e, n) {
        "use strict";
        var i = n(85893),
          o = n(67294),
          r = n(94745),
          a = n(63306);
        function l(t, e) {
          return {
            "@type": "Question",
            name: t,
            acceptedAnswer: { "@type": "Answer", text: e },
          };
        }
        function s(t, e) {
          let n = t.map((t) => {
            let n = e.gamePageLink(t.slug).as;
            return `<li><a href="${n}">${t.name}</a></li>`;
          });
          return `<ol>${n.join("")}</ol>`;
        }
        let u = (t) => {
          let { tag: e, mobileGames: n, topGames: u, linkBoostedGames: d } = t,
            { i18n: c } = (0, r.mV)(),
            { routeHelper: h } = o.useContext(a.Z),
            g = (function (t, e, n, i, o, r) {
              let a = r._("tag.faq.popular", { title: t.title }),
                u = r._("tag.faq.mobile", { title: t.title }),
                d = r._("tag.faq.whatAre", { title: t.title }),
                c = r._("tag.faq.whatAreSomeUnderrated", { title: t.title }),
                h = s(e, o),
                g = s(n, o),
                p = i.length > 0 ? s(i, o) : null,
                f = t.intro,
                m = l(a, h),
                y = l(u, g),
                _ = f ? l(d, f) : null,
                b = p ? l(c, p) : null,
                x = [m, y];
              return (
                b && x.push(b),
                _ && x.push(_),
                {
                  "@context": "https://schema.org",
                  "@type": "FAQPage",
                  mainEntity: x,
                }
              );
            })(e, u, n, d, h, c),
            p = JSON.stringify(g);
          return (0, i.jsx)("script", {
            type: "application/ld+json",
            dangerouslySetInnerHTML: { __html: p },
          });
        };
        e.Z = u;
      },
      40657: function (t, e, n) {
        "use strict";
        n.d(e, {
          A: function () {
            return r;
          },
          f: function () {
            return a;
          },
        });
        var i = n(90948),
          o = n(32350);
        let r = (0, i.ZP)("div")(() => ({ ...o.Hq })),
          a = (0, i.ZP)("div", { shouldForwardProp: (t) => "isDesktop" !== t })(
            (t) => {
              let {
                theme: { spacing: e },
                isDesktop: n,
              } = t;
              return { paddingLeft: n ? e(1) : void 0, paddingBottom: e(2.5) };
            }
          );
      },
      65216: function (t, e, n) {
        "use strict";
        n.d(e, {
          Z: function () {
            return y;
          },
        });
        var i = n(85893),
          o = n(67294),
          r = n(2978);
        let a = (t) => {
          let {
            urlGenerator: e,
            page: n,
            disabled: o,
            children: a,
            sorting: l,
          } = t;
          if (o) return (0, i.jsx)(i.Fragment, { children: a });
          let s = e(n, l);
          return (0, i.jsx)(r.Z, { ...s, children: a });
        };
        var l = n(83514),
          s = n(64774),
          u = n(59411),
          d = n(90512),
          c = n(15417),
          h = n.n(c);
        let g = o.memo((t) => {
            let { showNum: e, page: n, next: o } = t;
            return e
              ? (0, i.jsx)(i.Fragment, { children: n })
              : o
              ? (0, i.jsx)(u.Z, {})
              : (0, i.jsx)(s.Z, {});
          }),
          p = (t) => {
            let {
                paginationLinkType: e,
                disabled: n,
                page: r,
                urlGenerator: s,
                showNum: u,
                isCurrent: c,
              } = t,
              { pageUrlHelper: p } = o.useContext(l.t),
              f = p.getSorting();
            return (0, i.jsx)(a, {
              page: r,
              disabled: n,
              urlGenerator: s,
              sorting: f,
              children: (0, i.jsx)("div", {
                className: (0, d.Z)(
                  h().gamePageLink,
                  (c || n) && h().disabled,
                  c && h().current,
                  u && h().number
                ),
                children: (0, i.jsx)(g, {
                  showNum: u,
                  page: r,
                  next: "next" === e,
                }),
              }),
            });
          },
          f = o.memo((t) => {
            let { currentPage: e, urlGenerator: n, totalPages: o } = t,
              r = (function (t, e, n) {
                let i = Array.from({ length: t }, (t, e) => e + 1),
                  o = n - 1;
                if (e < 3)
                  throw Error(
                    "maxLength should be at least 3 to show first, current, and last elements."
                  );
                let r = i.length;
                if (r <= e) return i;
                if (o <= Math.floor(e / 2))
                  return [...i.slice(0, e - 2), "...", i[r - 1]];
                if (o >= r - Math.floor(e / 2))
                  return [i[0], "...", ...i.slice(r - (e - 2))];
                {
                  let t = Math.max(Math.floor((e - 5) / 2), 0);
                  return [
                    i[0],
                    "...",
                    ...i.slice(Math.max(1, o - t), Math.min(r - 1, o + t + 1)),
                    "...",
                    i[r - 1],
                  ];
                }
              })(o, 7, e);
            return (0, i.jsx)(i.Fragment, {
              children: r.map((t, o) =>
                "..." === t
                  ? (0, i.jsx)(
                      "div",
                      { className: h().ellipsis, children: "..." },
                      o
                    )
                  : (0, i.jsx)(
                      p,
                      {
                        page: t,
                        disabled: !1,
                        urlGenerator: n,
                        showNum: !0,
                        isCurrent: t === e,
                      },
                      o
                    )
              ),
            });
          }),
          m = (t) => {
            let { urlGenerator: e, games: n, pageLimit: o } = t,
              { pagination: r, total: a } = n,
              l = o || Number.MAX_SAFE_INTEGER,
              s = Math.min(Math.ceil(a / r.size), l),
              u = r.page,
              d = n.items.length > r.size;
            return s < 2
              ? null
              : (0, i.jsxs)("div", {
                  className: h().paginationContainer,
                  children: [
                    (0, i.jsx)(p, {
                      page: u - 1,
                      disabled: !(u > 1),
                      paginationLinkType: "previous",
                      urlGenerator: e,
                    }),
                    (0, i.jsx)(f, {
                      currentPage: u,
                      totalPages: s,
                      urlGenerator: e,
                    }),
                    (0, i.jsx)(p, {
                      page: u + 1,
                      disabled: !(u < s && !d),
                      paginationLinkType: "next",
                      urlGenerator: e,
                    }),
                  ],
                });
          };
        var y = m;
      },
      62716: function (t, e, n) {
        "use strict";
        n.d(e, {
          Z: function () {
            return f;
          },
        });
        var i = n(85893),
          o = n(94745),
          r = n(67294),
          a = n(32350),
          l = n(90948),
          s = n(3411);
        let u = (0, l.ZP)("div", {
            shouldForwardProp: (t) => "showMore" !== t,
          })((t) => {
            let {
              theme: { spacing: e },
              showMore: n,
            } = t;
            return {
              margin: e(2),
              contentVisibility: "auto",
              contain: "layout paint",
              containIntrinsicSize: "400px",
              overflowAnchor: "none",
              borderRadius: 10,
              backgroundColor: s.D.black[90],
              height: n ? "auto" : 250,
              position: "relative",
              color: s.D.white[50],
              fontSize: 16,
              "& h2, & h3": {
                color: s.D.white[80],
                fontWeight: 800,
                fontSize: 16,
              },
              "& p": { color: s.D.white[50], fontSize: 16 },
              "& a": (0, a.GC)(),
            };
          }),
          d = (0, l.ZP)("div", { shouldForwardProp: (t) => "showMore" !== t })(
            (t) => {
              let { showMore: e } = t;
              return {
                height: "100%",
                overflowX: "hidden",
                overflowY: "auto",
                padding: 30,
                ...(0, a.no)(4),
                paddingBottom: e ? 0 : 60,
              };
            }
          ),
          c = (0, l.ZP)("div")(() => ({
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 4,
            background: `linear-gradient(180deg, rgba(19, 20, 30, 0) 0%, ${s.D.black[90]} 35.42%)`,
            height: 80,
            paddingTop: 40,
            paddingLeft: 30,
          })),
          h = (0, l.ZP)("div")(() => ({
            backgroundColor: s.D.black[90],
            height: 50,
            paddingTop: 10,
            paddingLeft: 30,
          })),
          g = (0, l.ZP)("span")({ cursor: "pointer", ...(0, a.GC)() }),
          p = (t) => {
            let { children: e } = t,
              [n, a] = (0, r.useState)(!1);
            return (0, i.jsxs)(u, {
              showMore: n,
              style: { overflowAnchor: "auto" },
              children: [
                (0, i.jsx)(d, {
                  showMore: n,
                  style: { overflow: "hidden" },
                  children: e,
                }),
                !n &&
                  (0, i.jsx)(c, {
                    children: (0, i.jsx)(g, {
                      onClick: () => a(!0),
                      children: (0, i.jsx)(o.cC, { id: "common.showMore" }),
                    }),
                  }),
                n &&
                  (0, i.jsx)(h, {
                    children: (0, i.jsx)(g, {
                      onClick: () => a(!1),
                      children: (0, i.jsx)(o.cC, { id: "common.showLess" }),
                    }),
                  }),
              ],
            });
          };
        var f = p;
      },
      60081: function (t, e, n) {
        "use strict";
        var i = n(85893),
          o = n(67294),
          r = n(9008),
          a = n.n(r),
          l = n(33209),
          s = n(75007),
          u = n(8697);
        let d = (t) => {
          let {
              canonical: e,
              title: n,
              description: r,
              imageUrl: d = "crazygames/share.png",
              imageWidth: c = 1200,
              imageHeight: h = 630,
              type: g,
            } = t,
            { locale: p } = o.useContext(u.Z),
            f = (0, s.ZP)(d, { width: c, height: h, fit: "crop" });
          return (0, i.jsxs)(a(), {
            children: [
              (0, i.jsx)("meta", { property: "og:url", content: e }),
              (0, i.jsx)("meta", { property: "og:title", content: n }),
              (0, i.jsx)("meta", { property: "og:description", content: r }),
              (0, i.jsx)("meta", {
                property: "og:locale",
                content: (0, l.Ld)(p),
              }),
              (0, i.jsx)("meta", { property: "og:image", content: f }),
              (0, i.jsx)("meta", {
                property: "og:image:width",
                content: c.toString(),
              }),
              (0, i.jsx)("meta", {
                property: "og:image:height",
                content: h.toString(),
              }),
              g && (0, i.jsx)("meta", { property: "og:type", content: g }),
              (0, i.jsx)("meta", {
                property: "twitter:card",
                content: "summary_large_image",
              }),
              (0, i.jsx)("meta", { property: "twitter:url", content: e }),
              (0, i.jsx)("meta", { property: "twitter:title", content: n }),
              (0, i.jsx)("meta", {
                property: "twitter:description",
                content: r,
              }),
              (0, i.jsx)("meta", { property: "twitter:image", content: f }),
            ],
          });
        };
        e.Z = d;
      },
      48715: function (t, e, n) {
        "use strict";
        n.d(e, {
          K: function () {
            return o;
          },
        });
        var i = n(35715);
        let o = (t, e) =>
          e ? t : { ...t, pagination: { ...t.pagination, size: i.U } };
      },
      4743: function (t, e) {
        "use strict";
        e.Z = function (t, e) {
          return e.isIos && t.swap ? t.swap : t.data;
        };
      },
      15417: function (t) {
        t.exports = {
          czyButton: "Pagination_czyButton__CrJcu",
          "czyButton--contained--purple":
            "Pagination_czyButton--contained--purple__Tne5E",
          "czyButton--contained--white":
            "Pagination_czyButton--contained--white__W2aRh",
          "czyButton--contained--grey":
            "Pagination_czyButton--contained--grey__z87sS",
          "czyButton--contained--alert":
            "Pagination_czyButton--contained--alert__K0pje",
          "czyButton--contained--success":
            "Pagination_czyButton--contained--success__m9r7e",
          "czyButton--contained--black":
            "Pagination_czyButton--contained--black__HI8It",
          "czyButton--contained--green-gradient":
            "Pagination_czyButton--contained--green-gradient__h21nH",
          "czyButton--outlined--purple":
            "Pagination_czyButton--outlined--purple__ljowN",
          "czyButton--link--purple":
            "Pagination_czyButton--link--purple__whmjf",
          "czyButton--outlined--white":
            "Pagination_czyButton--outlined--white__nJjag",
          "czyButton--link--white": "Pagination_czyButton--link--white__fQHHx",
          "czyButton--outlined--grey":
            "Pagination_czyButton--outlined--grey__4eSQW",
          "czyButton--link--grey": "Pagination_czyButton--link--grey__uijpD",
          "czyButton--outlined--alert":
            "Pagination_czyButton--outlined--alert__sXx1Y",
          "czyButton--link--alert": "Pagination_czyButton--link--alert__23Kzv",
          "czyButton--outlined--success":
            "Pagination_czyButton--outlined--success__CDFRh",
          "czyButton--link--success":
            "Pagination_czyButton--link--success__BQJxc",
          "czyButton--outlined": "Pagination_czyButton--outlined__65OUS",
          "czyButton--disabled": "Pagination_czyButton--disabled__nbeEj",
          "czyButton--height50": "Pagination_czyButton--height50__UTPIe",
          "czyButton--height34": "Pagination_czyButton--height34__1OgCY",
          "czyButton--fullWidth": "Pagination_czyButton--fullWidth__qVwgH",
          paginationContainer: "Pagination_paginationContainer__ZdF_m",
          ellipsis: "Pagination_ellipsis__1Xzoo",
          gamePageLink: "Pagination_gamePageLink__52hMn",
          number: "Pagination_number__Nh3VT",
          current: "Pagination_current__TuEd_",
          disabled: "Pagination_disabled__R07W7",
        };
      },
    },
  ]);
