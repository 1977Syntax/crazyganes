!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      r = new e.Error().stack;
    r &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[r] = "af233e00-ffc8-485e-a7d8-52d6f9199085"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-af233e00-ffc8-485e-a7d8-52d6f9199085"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [68762],
    {
      68762: function (e, r, a) {
        a.r(r),
          a.d(r, {
            default: function () {
              return i;
            },
            shouldIgnoreError: function () {
              return s;
            },
          });
        var t = a(19013),
          o = a(13882);
        let n = [
          {
            name: "ApiError",
            statusCode: 400,
            condition: () => {
              let e =
                "undefined" != typeof navigator &&
                /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
              return e;
            },
          },
          { message: /Can't execute code from a freed script/ },
          { name: "TypeError", message: /Load failed/ },
          { message: /Non-Error promise rejection captured with keys/ },
          { message: /Non-Error promise rejection captured with value/ },
          { message: /Failed to fetch/ },
          { message: /status -> 400/ },
          { name: "ApolloError", message: /an error occurred/ },
          { name: "ApolloError", message: /Load failed/ },
          { name: "ApolloError", message: /401/ },
          { name: "ApolloError", message: /NetworkError/ },
          { name: "TypeError", message: /Permissions check failed/ },
          { message: /captured as promise rejection/ },
          {
            message:
              /An attempt was made to break through the security policy of the user agent/,
          },
          { name: "ApiError", message: /NetworkError/ },
          { name: "TypeError", message: /NetworkError/ },
          { name: "FirebaseError" },
          { name: "QuotaExceededError" },
          { message: /Connection is closing/ },
          { name: "UnhandledRejection", message: /Request timeout/ },
          { name: "TypeError", message: /not granted/ },
          { name: "Error", message: /AbortError/ },
        ];
        function s(e, r) {
          let a = window.__NEXT_DATA__?.props?.date
            ? window.__NEXT_DATA__.props.date
            : Date.now();
          return !!(
            (r &&
              !(function (e) {
                return (0, o.Z)(1, arguments), 2 === (0, t.Z)(e).getDay();
              })(a)) ||
            n.some(
              (r) =>
                "string" != typeof e &&
                ["name", "statusCode", "message", "condition"].every((a) => {
                  if (!r[a]) return !0;
                  if ("name" === a) return e?.name === r?.name;
                  if ("statusCode" === a)
                    return e?.statusCode === r?.statusCode;
                  if ("condition" === a && r?.condition) return r.condition();
                  if ("message" === a) {
                    if (r?.message instanceof RegExp)
                      return r?.message?.test(e?.message);
                    r?.message, e?.message;
                  }
                  return !0;
                })
            )
          );
        }
        let d = (e) => ({
          debug: !1,
          attachStacktrace: !0,
          release: e.version,
          allowUrls: [/_next/],
          autoSessionTracking: !1,
          ignoreErrors: [/NotAllowedError/],
          tracesSampleRate: 0,
          beforeSend: (r, a) => {
            if (
              !r.exception ||
              !r.exception.values ||
              !r.exception.values[0].stacktrace
            )
              return null;
            let t = a && a.originalException;
            return s(t, "production" === e.environment) ? null : r;
          },
        });
        var i = d;
      },
    },
  ]);
