!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "5627ed58-ddfb-4eeb-8867-5d1b91c4ddd3"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-5627ed58-ddfb-4eeb-8867-5d1b91c4ddd3"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [69029],
    {
      88078: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return F;
          },
        });
        var a = n(63366),
          r = n(87462),
          o = n(67294),
          i = n(90512),
          d = n(70917),
          l = n(94780),
          u = n(41796),
          s = n(90948),
          h = n(71657),
          c = n(1588),
          f = n(34867);
        function g(e) {
          return (0, f.ZP)("MuiSkeleton", e);
        }
        (0, c.Z)("MuiSkeleton", [
          "root",
          "text",
          "rectangular",
          "rounded",
          "circular",
          "pulse",
          "wave",
          "withChildren",
          "fitContent",
          "heightAuto",
        ]);
        var b = n(85893);
        let M = [
            "animation",
            "className",
            "component",
            "height",
            "style",
            "variant",
            "width",
          ],
          p = (e) => e,
          v,
          y,
          m,
          Z,
          w = (e) => {
            let {
              classes: t,
              variant: n,
              animation: a,
              hasChildren: r,
              width: o,
              height: i,
            } = e;
            return (0, l.Z)(
              {
                root: [
                  "root",
                  n,
                  a,
                  r && "withChildren",
                  r && !o && "fitContent",
                  r && !i && "heightAuto",
                ],
              },
              g,
              t
            );
          },
          _ = (0, d.F4)(
            v ||
              (v = p`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)
          ),
          k = (0, d.F4)(
            y ||
              (y = p`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)
          ),
          C = (0, s.ZP)("span", {
            name: "MuiSkeleton",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.root,
                t[n.variant],
                !1 !== n.animation && t[n.animation],
                n.hasChildren && t.withChildren,
                n.hasChildren && !n.width && t.fitContent,
                n.hasChildren && !n.height && t.heightAuto,
              ];
            },
          })(
            ({ theme: e, ownerState: t }) => {
              let n =
                  String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1] ||
                  "px",
                a = parseFloat(e.shape.borderRadius);
              return (0, r.Z)(
                {
                  display: "block",
                  backgroundColor: e.vars
                    ? e.vars.palette.Skeleton.bg
                    : (0, u.Fq)(
                        e.palette.text.primary,
                        "light" === e.palette.mode ? 0.11 : 0.13
                      ),
                  height: "1.2em",
                },
                "text" === t.variant && {
                  marginTop: 0,
                  marginBottom: 0,
                  height: "auto",
                  transformOrigin: "0 55%",
                  transform: "scale(1, 0.60)",
                  borderRadius: `${a}${n}/${
                    Math.round((a / 0.6) * 10) / 10
                  }${n}`,
                  "&:empty:before": { content: '"\\00a0"' },
                },
                "circular" === t.variant && { borderRadius: "50%" },
                "rounded" === t.variant && {
                  borderRadius: (e.vars || e).shape.borderRadius,
                },
                t.hasChildren && { "& > *": { visibility: "hidden" } },
                t.hasChildren && !t.width && { maxWidth: "fit-content" },
                t.hasChildren && !t.height && { height: "auto" }
              );
            },
            ({ ownerState: e }) =>
              "pulse" === e.animation &&
              (0, d.iv)(
                m ||
                  (m = p`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),
                _
              ),
            ({ ownerState: e, theme: t }) =>
              "wave" === e.animation &&
              (0, d.iv)(
                Z ||
                  (Z = p`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),
                k,
                (t.vars || t).palette.action.hover
              )
          ),
          D = o.forwardRef(function (e, t) {
            let n = (0, h.Z)({ props: e, name: "MuiSkeleton" }),
              {
                animation: o = "pulse",
                className: d,
                component: l = "span",
                height: u,
                style: s,
                variant: c = "text",
                width: f,
              } = n,
              g = (0, a.Z)(n, M),
              p = (0, r.Z)({}, n, {
                animation: o,
                component: l,
                variant: c,
                hasChildren: Boolean(g.children),
              }),
              v = w(p);
            return (0,
            b.jsx)(C, (0, r.Z)({ as: l, ref: t, className: (0, i.Z)(v.root, d), ownerState: p }, g, { style: (0, r.Z)({ width: f, height: u }, s) }));
          });
        var F = D;
      },
      24262: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return a;
          },
        });
        function a(e) {
          var t = new Date(
            Date.UTC(
              e.getFullYear(),
              e.getMonth(),
              e.getDate(),
              e.getHours(),
              e.getMinutes(),
              e.getSeconds(),
              e.getMilliseconds()
            )
          );
          return t.setUTCFullYear(e.getFullYear()), e.getTime() - t.getTime();
        }
      },
      29383: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return l;
          },
        });
        var a = n(19013),
          r = n(24262),
          o = n(69119),
          i = n(13882);
        function d(e, t) {
          var n =
            e.getFullYear() - t.getFullYear() ||
            e.getMonth() - t.getMonth() ||
            e.getDate() - t.getDate() ||
            e.getHours() - t.getHours() ||
            e.getMinutes() - t.getMinutes() ||
            e.getSeconds() - t.getSeconds() ||
            e.getMilliseconds() - t.getMilliseconds();
          return n < 0 ? -1 : n > 0 ? 1 : n;
        }
        function l(e, t) {
          (0, i.Z)(2, arguments);
          var n = (0, a.Z)(e),
            l = (0, a.Z)(t),
            u = d(n, l),
            s = Math.abs(
              (function (e, t) {
                (0, i.Z)(2, arguments);
                var n = (0, o.Z)(e),
                  a = (0, o.Z)(t);
                return Math.round(
                  (n.getTime() - (0, r.Z)(n) - (a.getTime() - (0, r.Z)(a))) /
                    864e5
                );
              })(n, l)
            );
          n.setDate(n.getDate() - u * s);
          var h = Number(d(n, l) === -u),
            c = u * (s - h);
          return 0 === c ? 0 : c;
        }
      },
      28584: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return i;
          },
        });
        var a = n(29383),
          r = n(13882),
          o = {
            ceil: Math.ceil,
            round: Math.round,
            floor: Math.floor,
            trunc: function (e) {
              return e < 0 ? Math.ceil(e) : Math.floor(e);
            },
          };
        function i(e, t, n) {
          (0, r.Z)(2, arguments);
          var i,
            d = (0, a.Z)(e, t) / 7;
          return ((i = null == n ? void 0 : n.roundingMethod) ? o[i] : o.trunc)(
            d
          );
        }
      },
      78966: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return o;
          },
        });
        var a = n(19013),
          r = n(13882);
        function o(e) {
          return (0, r.Z)(1, arguments), (0, a.Z)(e).getMonth();
        }
      },
      95570: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return o;
          },
        });
        var a = n(19013),
          r = n(13882);
        function o(e) {
          return (0, r.Z)(1, arguments), (0, a.Z)(e).getFullYear();
        }
      },
      69119: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return o;
          },
        });
        var a = n(19013),
          r = n(13882);
        function o(e) {
          (0, r.Z)(1, arguments);
          var t = (0, a.Z)(e);
          return t.setHours(0, 0, 0, 0), t;
        }
      },
    },
  ]);
