!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "82bf25bf-2a38-4411-866c-bf666ff0e629"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-82bf25bf-2a38-4411-866c-bf666ff0e629"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [70035],
    {
      31394: function (e, t, n) {
        n.d(t, {
          y: function () {
            return l;
          },
        });
        var r = n(25821);
        class o extends Error {
          constructor(e) {
            super("Unexpected error value: " + (0, r.X)(e)),
              (this.name = "NonErrorThrown"),
              (this.thrownValue = e);
          }
        }
        var a = n(28087);
        function l(e, t, n) {
          var r;
          let l = e instanceof Error ? e : new o(e);
          return Array.isArray(l.path)
            ? l
            : new a.__(l.message, {
                nodes: null !== (r = l.nodes) && void 0 !== r ? r : t,
                source: l.source,
                positions: l.positions,
                path: n,
                originalError: l,
              });
        }
      },
      74296: function (e, t, n) {
        let r;
        n.d(t, {
          td: function () {
            return E;
          },
          VZ: function () {
            return O;
          },
          p$: function () {
            return k;
          },
          El: function () {
            return G;
          },
          mn: function () {
            return F;
          },
          ht: function () {
            return M;
          },
          p0: function () {
            return $;
          },
          Vm: function () {
            return X;
          },
        });
        var o,
          a = n(37826),
          l = n(25821),
          i = n(29551),
          u = n(93831),
          s = n(88495),
          f = n(38659),
          c = n(79380);
        function d(e) {
          return Promise.all(Object.values(e)).then((t) => {
            let n = Object.create(null);
            for (let [r, o] of Object.keys(e).entries()) n[o] = t[r];
            return n;
          });
        }
        var p = n(28087),
          y = n(31394),
          h = n(72380),
          m = n(97359),
          v = n(4454),
          b = n(52433),
          w = n(19655),
          _ = n(97677),
          g = n(66422);
        let T =
          ((o = (e, t, n) =>
            (0, _.w)(e.schema, e.fragments, e.variableValues, t, n)),
          function (e, t, n) {
            void 0 === r && (r = new WeakMap());
            let a = r.get(e);
            void 0 === a && ((a = new WeakMap()), r.set(e, a));
            let l = a.get(t);
            void 0 === l && ((l = new WeakMap()), a.set(t, l));
            let i = l.get(n);
            return void 0 === i && ((i = o(e, t, n)), l.set(n, i)), i;
          });
        function M(e) {
          arguments.length < 2 ||
            (0, a.a)(
              !1,
              "graphql@16 dropped long-deprecated support for positional arguments, please pass an object instead."
            );
          let { schema: t, document: n, variableValues: r, rootValue: o } = e;
          E(t, n, r);
          let l = O(e);
          if (!("schema" in l)) return { errors: l };
          try {
            let { operation: e } = l,
              t = (function (e, t, n) {
                let r = e.schema.getRootType(t.operation);
                if (null == r)
                  throw new p.__(
                    `Schema is not configured to execute ${t.operation} operation.`,
                    { nodes: t }
                  );
                let o = (0, _.g)(
                    e.schema,
                    e.fragments,
                    e.variableValues,
                    r,
                    t.selectionSet
                  ),
                  a = void 0;
                switch (t.operation) {
                  case h.ku.QUERY:
                    return I(e, r, n, a, o);
                  case h.ku.MUTATION:
                    return (function (e, t, n) {
                      let r = n;
                      for (let n of e)
                        r = (0, f.t)(r) ? r.then((e) => t(e, n)) : t(r, n);
                      return r;
                    })(
                      o.entries(),
                      (t, [o, l]) => {
                        let i = (0, c.Q)(a, o, r.name),
                          u = V(e, r, n, l, i);
                        return void 0 === u
                          ? t
                          : (0, f.t)(u)
                          ? u.then((e) => ((t[o] = e), t))
                          : ((t[o] = u), t);
                      },
                      Object.create(null)
                    );
                  case h.ku.SUBSCRIPTION:
                    return I(e, r, n, a, o);
                }
              })(l, e, o);
            if ((0, f.t)(t))
              return t.then(
                (e) => N(e, l.errors),
                (e) => (l.errors.push(e), N(null, l.errors))
              );
            return N(t, l.errors);
          } catch (e) {
            return l.errors.push(e), N(null, l.errors);
          }
        }
        function $(e) {
          let t = M(e);
          if ((0, f.t)(t))
            throw Error("GraphQL execution failed to complete synchronously.");
          return t;
        }
        function N(e, t) {
          return 0 === t.length ? { data: e } : { errors: t, data: e };
        }
        function E(e, t, n) {
          t || (0, a.a)(!1, "Must provide document."),
            (0, w.J)(e),
            null == n ||
              (0, s.y)(n) ||
              (0, a.a)(
                !1,
                "Variables must be provided as an Object where each property is a variable value. Perhaps look to see if an unparsed JSON string was provided."
              );
        }
        function O(e) {
          var t, n;
          let r;
          let {
              schema: o,
              document: a,
              rootValue: l,
              contextValue: i,
              variableValues: u,
              operationName: s,
              fieldResolver: f,
              typeResolver: c,
              subscribeFieldResolver: d,
            } = e,
            y = Object.create(null);
          for (let e of a.definitions)
            switch (e.kind) {
              case m.h.OPERATION_DEFINITION:
                if (null == s) {
                  if (void 0 !== r)
                    return [
                      new p.__(
                        "Must provide operation name if query contains multiple operations."
                      ),
                    ];
                  r = e;
                } else
                  (null === (t = e.name) || void 0 === t ? void 0 : t.value) ===
                    s && (r = e);
                break;
              case m.h.FRAGMENT_DEFINITION:
                y[e.name.value] = e;
            }
          if (!r)
            return null != s
              ? [new p.__(`Unknown operation named "${s}".`)]
              : [new p.__("Must provide an operation.")];
          let h = null !== (n = r.variableDefinitions) && void 0 !== n ? n : [],
            v = (0, g.QF)(o, h, null != u ? u : {}, { maxErrors: 50 });
          return v.errors
            ? v.errors
            : {
                schema: o,
                fragments: y,
                rootValue: l,
                contextValue: i,
                operation: r,
                variableValues: v.coerced,
                fieldResolver: null != f ? f : G,
                typeResolver: null != c ? c : F,
                subscribeFieldResolver: null != d ? d : G,
                errors: [],
              };
        }
        function I(e, t, n, r, o) {
          let a = Object.create(null),
            l = !1;
          try {
            for (let [i, u] of o.entries()) {
              let o = (0, c.Q)(r, i, t.name),
                s = V(e, t, n, u, o);
              void 0 !== s && ((a[i] = s), (0, f.t)(s) && (l = !0));
            }
          } catch (e) {
            if (l)
              return d(a).finally(() => {
                throw e;
              });
            throw e;
          }
          return l ? d(a) : a;
        }
        function V(e, t, n, r, o) {
          var a;
          let l = X(e.schema, t, r[0]);
          if (!l) return;
          let i = l.type,
            u = null !== (a = l.resolve) && void 0 !== a ? a : e.fieldResolver,
            s = k(e, l, r, t, o);
          try {
            let t;
            let a = (0, g.LX)(l, r[0], e.variableValues),
              d = e.contextValue,
              p = u(n, a, d, s);
            if (
              ((t = (0, f.t)(p)
                ? p.then((t) => j(e, i, r, s, o, t))
                : j(e, i, r, s, o, p)),
              (0, f.t)(t))
            )
              return t.then(void 0, (t) => {
                let n = (0, y.y)(t, r, (0, c.N)(o));
                return x(n, i, e);
              });
            return t;
          } catch (n) {
            let t = (0, y.y)(n, r, (0, c.N)(o));
            return x(t, i, e);
          }
        }
        function k(e, t, n, r, o) {
          return {
            fieldName: t.name,
            fieldNodes: n,
            returnType: t.type,
            parentType: r,
            path: o,
            schema: e.schema,
            fragments: e.fragments,
            rootValue: e.rootValue,
            operation: e.operation,
            variableValues: e.variableValues,
          };
        }
        function x(e, t, n) {
          if ((0, v.zM)(t)) throw e;
          return n.errors.push(e), null;
        }
        function j(e, t, n, r, o, a) {
          if (a instanceof Error) throw a;
          if ((0, v.zM)(t)) {
            let l = j(e, t.ofType, n, r, o, a);
            if (null === l)
              throw Error(
                `Cannot return null for non-nullable field ${r.parentType.name}.${r.fieldName}.`
              );
            return l;
          }
          return null == a
            ? null
            : (0, v.HG)(t)
            ? (function (e, t, n, r, o, a) {
                if (!(0, u.i)(a))
                  throw new p.__(
                    `Expected Iterable, but did not find one for field "${r.parentType.name}.${r.fieldName}".`
                  );
                let l = t.ofType,
                  i = !1,
                  s = Array.from(a, (t, a) => {
                    let u = (0, c.Q)(o, a, void 0);
                    try {
                      let o;
                      if (
                        ((o = (0, f.t)(t)
                          ? t.then((t) => j(e, l, n, r, u, t))
                          : j(e, l, n, r, u, t)),
                        (0, f.t)(o))
                      )
                        return (
                          (i = !0),
                          o.then(void 0, (t) => {
                            let r = (0, y.y)(t, n, (0, c.N)(u));
                            return x(r, l, e);
                          })
                        );
                      return o;
                    } catch (r) {
                      let t = (0, y.y)(r, n, (0, c.N)(u));
                      return x(t, l, e);
                    }
                  });
                return i ? Promise.all(s) : s;
              })(e, t, n, r, o, a)
            : (0, v.UT)(t)
            ? (function (e, t) {
                let n = e.serialize(t);
                if (null == n)
                  throw Error(
                    `Expected \`${(0, l.X)(e)}.serialize(${(0, l.X)(
                      t
                    )})\` to return non-nullable value, returned: ${(0, l.X)(
                      n
                    )}`
                  );
                return n;
              })(t, a)
            : (0, v.m0)(t)
            ? (function (e, t, n, r, o, a) {
                var l;
                let i =
                    null !== (l = t.resolveType) && void 0 !== l
                      ? l
                      : e.typeResolver,
                  u = e.contextValue,
                  s = i(a, u, r, t);
                return (0, f.t)(s)
                  ? s.then((l) => R(e, A(l, e, t, n, r, a), n, r, o, a))
                  : R(e, A(s, e, t, n, r, a), n, r, o, a);
              })(e, t, n, r, o, a)
            : (0, v.lp)(t)
            ? R(e, t, n, r, o, a)
            : void (0, i.k)(
                !1,
                "Cannot complete value of unexpected output type: " +
                  (0, l.X)(t)
              );
        }
        function A(e, t, n, r, o, a) {
          if (null == e)
            throw new p.__(
              `Abstract type "${n.name}" must resolve to an Object type at runtime for field "${o.parentType.name}.${o.fieldName}". Either the "${n.name}" type should provide a "resolveType" function or each possible type should provide an "isTypeOf" function.`,
              r
            );
          if ((0, v.lp)(e))
            throw new p.__(
              "Support for returning GraphQLObjectType from resolveType was removed in graphql-js@16.0.0 please return type name instead."
            );
          if ("string" != typeof e)
            throw new p.__(
              `Abstract type "${
                n.name
              }" must resolve to an Object type at runtime for field "${
                o.parentType.name
              }.${o.fieldName}" with value ${(0, l.X)(a)}, received "${(0, l.X)(
                e
              )}".`
            );
          let i = t.schema.getType(e);
          if (null == i)
            throw new p.__(
              `Abstract type "${n.name}" was resolved to a type "${e}" that does not exist inside the schema.`,
              { nodes: r }
            );
          if (!(0, v.lp)(i))
            throw new p.__(
              `Abstract type "${n.name}" was resolved to a non-object type "${e}".`,
              { nodes: r }
            );
          if (!t.schema.isSubType(n, i))
            throw new p.__(
              `Runtime Object type "${i.name}" is not a possible type for "${n.name}".`,
              { nodes: r }
            );
          return i;
        }
        function R(e, t, n, r, o, a) {
          let l = T(e, t, n);
          if (t.isTypeOf) {
            let i = t.isTypeOf(a, e.contextValue, r);
            if ((0, f.t)(i))
              return i.then((r) => {
                if (!r) throw S(t, a, n);
                return I(e, t, a, o, l);
              });
            if (!i) throw S(t, a, n);
          }
          return I(e, t, a, o, l);
        }
        function S(e, t, n) {
          return new p.__(
            `Expected value of type "${e.name}" but got: ${(0, l.X)(t)}.`,
            { nodes: n }
          );
        }
        let F = function (e, t, n, r) {
            if ((0, s.y)(e) && "string" == typeof e.__typename)
              return e.__typename;
            let o = n.schema.getPossibleTypes(r),
              a = [];
            for (let r = 0; r < o.length; r++) {
              let l = o[r];
              if (l.isTypeOf) {
                let o = l.isTypeOf(e, t, n);
                if ((0, f.t)(o)) a[r] = o;
                else if (o) return l.name;
              }
            }
            if (a.length)
              return Promise.all(a).then((e) => {
                for (let t = 0; t < e.length; t++) if (e[t]) return o[t].name;
              });
          },
          G = function (e, t, n, r) {
            if ((0, s.y)(e) || "function" == typeof e) {
              let o = e[r.fieldName];
              return "function" == typeof o ? e[r.fieldName](t, n, r) : o;
            }
          };
        function X(e, t, n) {
          let r = n.name.value;
          return r === b.Az.name && e.getQueryType() === t
            ? b.Az
            : r === b.tF.name && e.getQueryType() === t
            ? b.tF
            : r === b.hU.name
            ? b.hU
            : t.getFields()[r];
        }
      },
      70145: function (e, t, n) {
        n.d(t, {
          z: function () {
            return p;
          },
          L: function () {
            return d;
          },
        });
        var r = n(37826),
          o = n(25821);
        function a(e) {
          return (
            "function" == typeof (null == e ? void 0 : e[Symbol.asyncIterator])
          );
        }
        var l = n(79380),
          i = n(28087),
          u = n(31394),
          s = n(97677),
          f = n(74296),
          c = n(66422);
        async function d(e) {
          arguments.length < 2 ||
            (0, r.a)(
              !1,
              "graphql@16 dropped long-deprecated support for positional arguments, please pass an object instead."
            );
          let t = await p(e);
          if (!a(t)) return t;
          let n = (t) => (0, f.ht)({ ...e, rootValue: t });
          return (function (e, t) {
            let n = e[Symbol.asyncIterator]();
            async function r(e) {
              if (e.done) return e;
              try {
                return { value: await t(e.value), done: !1 };
              } catch (e) {
                if ("function" == typeof n.return)
                  try {
                    await n.return();
                  } catch (e) {}
                throw e;
              }
            }
            return {
              next: async () => r(await n.next()),
              return: async () =>
                "function" == typeof n.return
                  ? r(await n.return())
                  : { value: void 0, done: !0 },
              async throw(e) {
                if ("function" == typeof n.throw) return r(await n.throw(e));
                throw e;
              },
              [Symbol.asyncIterator]() {
                return this;
              },
            };
          })(t, n);
        }
        async function p(...e) {
          let t = (function (e) {
              let t = e[0];
              return t && "document" in t
                ? t
                : {
                    schema: t,
                    document: e[1],
                    rootValue: e[2],
                    contextValue: e[3],
                    variableValues: e[4],
                    operationName: e[5],
                    subscribeFieldResolver: e[6],
                  };
            })(e),
            { schema: n, document: r, variableValues: l } = t;
          (0, f.td)(n, r, l);
          let u = (0, f.VZ)(t);
          if (!("schema" in u)) return { errors: u };
          try {
            let e = await y(u);
            if (!a(e))
              throw Error(
                `Subscription field must return Async Iterable. Received: ${(0,
                o.X)(e)}.`
              );
            return e;
          } catch (e) {
            if (e instanceof i.__) return { errors: [e] };
            throw e;
          }
        }
        async function y(e) {
          let {
              schema: t,
              fragments: n,
              operation: r,
              variableValues: o,
              rootValue: a,
            } = e,
            d = t.getSubscriptionType();
          if (null == d)
            throw new i.__(
              "Schema is not configured to execute subscription operation.",
              { nodes: r }
            );
          let p = (0, s.g)(t, n, o, d, r.selectionSet),
            [y, h] = [...p.entries()][0],
            m = (0, f.Vm)(t, d, h[0]);
          if (!m) {
            let e = h[0].name.value;
            throw new i.__(`The subscription field "${e}" is not defined.`, {
              nodes: h,
            });
          }
          let v = (0, l.Q)(void 0, y, d.name),
            b = (0, f.p$)(e, m, h, d, v);
          try {
            var w;
            let t = (0, c.LX)(m, h[0], o),
              n = e.contextValue,
              r =
                null !== (w = m.subscribe) && void 0 !== w
                  ? w
                  : e.subscribeFieldResolver,
              l = await r(a, t, n, b);
            if (l instanceof Error) throw l;
            return l;
          } catch (e) {
            throw (0, u.y)(e, h, (0, l.N)(v));
          }
        }
      },
      38659: function (e, t, n) {
        n.d(t, {
          t: function () {
            return r;
          },
        });
        function r(e) {
          return "function" == typeof (null == e ? void 0 : e.then);
        }
      },
      52100: function (e, t, n) {
        n.d(t, {
          S: function () {
            return o;
          },
        });
        var r = n(97359);
        function o(e, t) {
          let n = null;
          for (let a of e.definitions)
            if (a.kind === r.h.OPERATION_DEFINITION) {
              var o;
              if (null == t) {
                if (n) return null;
                n = a;
              } else if (
                (null === (o = a.name) || void 0 === o ? void 0 : o.value) === t
              )
                return a;
            }
          return n;
        }
      },
    },
  ]);
