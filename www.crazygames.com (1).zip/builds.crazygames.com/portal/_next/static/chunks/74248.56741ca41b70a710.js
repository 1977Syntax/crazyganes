!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "4f8c5900-fab1-4cf5-872d-ef3924da144d"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-4f8c5900-fab1-4cf5-872d-ef3924da144d"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [74248],
    {
      83454: function (e, t, n) {
        "use strict";
        var r, i;
        e.exports =
          (null == (r = n.g.process) ? void 0 : r.env) &&
          "object" == typeof (null == (i = n.g.process) ? void 0 : i.env)
            ? n.g.process
            : n(77663);
      },
      77663: function (e) {
        !(function () {
          var t = {
              229: function (e) {
                var t,
                  n,
                  r,
                  i = (e.exports = {});
                function o() {
                  throw Error("setTimeout has not been defined");
                }
                function a() {
                  throw Error("clearTimeout has not been defined");
                }
                function s(e) {
                  if (t === setTimeout) return setTimeout(e, 0);
                  if ((t === o || !t) && setTimeout)
                    return (t = setTimeout), setTimeout(e, 0);
                  try {
                    return t(e, 0);
                  } catch (n) {
                    try {
                      return t.call(null, e, 0);
                    } catch (n) {
                      return t.call(this, e, 0);
                    }
                  }
                }
                !(function () {
                  try {
                    t = "function" == typeof setTimeout ? setTimeout : o;
                  } catch (e) {
                    t = o;
                  }
                  try {
                    n = "function" == typeof clearTimeout ? clearTimeout : a;
                  } catch (e) {
                    n = a;
                  }
                })();
                var u = [],
                  l = !1,
                  c = -1;
                function p() {
                  l &&
                    r &&
                    ((l = !1),
                    r.length ? (u = r.concat(u)) : (c = -1),
                    u.length && f());
                }
                function f() {
                  if (!l) {
                    var e = s(p);
                    l = !0;
                    for (var t = u.length; t; ) {
                      for (r = u, u = []; ++c < t; ) r && r[c].run();
                      (c = -1), (t = u.length);
                    }
                    (r = null),
                      (l = !1),
                      (function (e) {
                        if (n === clearTimeout) return clearTimeout(e);
                        if ((n === a || !n) && clearTimeout)
                          return (n = clearTimeout), clearTimeout(e);
                        try {
                          n(e);
                        } catch (t) {
                          try {
                            return n.call(null, e);
                          } catch (t) {
                            return n.call(this, e);
                          }
                        }
                      })(e);
                  }
                }
                function d(e, t) {
                  (this.fun = e), (this.array = t);
                }
                function h() {}
                (i.nextTick = function (e) {
                  var t = Array(arguments.length - 1);
                  if (arguments.length > 1)
                    for (var n = 1; n < arguments.length; n++)
                      t[n - 1] = arguments[n];
                  u.push(new d(e, t)), 1 !== u.length || l || s(f);
                }),
                  (d.prototype.run = function () {
                    this.fun.apply(null, this.array);
                  }),
                  (i.title = "browser"),
                  (i.browser = !0),
                  (i.env = {}),
                  (i.argv = []),
                  (i.version = ""),
                  (i.versions = {}),
                  (i.on = h),
                  (i.addListener = h),
                  (i.once = h),
                  (i.off = h),
                  (i.removeListener = h),
                  (i.removeAllListeners = h),
                  (i.emit = h),
                  (i.prependListener = h),
                  (i.prependOnceListener = h),
                  (i.listeners = function (e) {
                    return [];
                  }),
                  (i.binding = function (e) {
                    throw Error("process.binding is not supported");
                  }),
                  (i.cwd = function () {
                    return "/";
                  }),
                  (i.chdir = function (e) {
                    throw Error("process.chdir is not supported");
                  }),
                  (i.umask = function () {
                    return 0;
                  });
              },
            },
            n = {};
          function r(e) {
            var i = n[e];
            if (void 0 !== i) return i.exports;
            var o = (n[e] = { exports: {} }),
              a = !0;
            try {
              t[e](o, o.exports, r), (a = !1);
            } finally {
              a && delete n[e];
            }
            return o.exports;
          }
          r.ab = "//";
          var i = r(229);
          e.exports = i;
        })();
      },
      97677: function (e, t, n) {
        "use strict";
        n.d(t, {
          g: function () {
            return u;
          },
          w: function () {
            return l;
          },
        });
        var r = n(97359),
          i = n(4454),
          o = n(68238),
          a = n(30077),
          s = n(66422);
        function u(e, t, n, r, i) {
          let o = new Map();
          return c(e, t, n, r, i, o, new Set()), o;
        }
        function l(e, t, n, r, i) {
          let o = new Map(),
            a = new Set();
          for (let s of i)
            s.selectionSet && c(e, t, n, r, s.selectionSet, o, a);
          return o;
        }
        function c(e, t, n, i, o, a, s) {
          for (let l of o.selections)
            switch (l.kind) {
              case r.h.FIELD: {
                var u;
                if (!p(n, l)) continue;
                let e = (u = l).alias ? u.alias.value : u.name.value,
                  t = a.get(e);
                void 0 !== t ? t.push(l) : a.set(e, [l]);
                break;
              }
              case r.h.INLINE_FRAGMENT:
                if (!p(n, l) || !f(e, l, i)) continue;
                c(e, t, n, i, l.selectionSet, a, s);
                break;
              case r.h.FRAGMENT_SPREAD: {
                let r = l.name.value;
                if (s.has(r) || !p(n, l)) continue;
                s.add(r);
                let o = t[r];
                if (!o || !f(e, o, i)) continue;
                c(e, t, n, i, o.selectionSet, a, s);
              }
            }
        }
        function p(e, t) {
          let n = (0, s.zu)(o.QE, t, e);
          if ((null == n ? void 0 : n.if) === !0) return !1;
          let r = (0, s.zu)(o.Yf, t, e);
          return (null == r ? void 0 : r.if) !== !1;
        }
        function f(e, t, n) {
          let r = t.typeCondition;
          if (!r) return !0;
          let o = (0, a._)(e, r);
          return o === n || (!!(0, i.m0)(o) && e.isSubType(o, n));
        }
      },
      66422: function (e, t, n) {
        "use strict";
        n.d(t, {
          LX: function () {
            return h;
          },
          QF: function () {
            return d;
          },
          zu: function () {
            return m;
          },
        });
        var r = n(25821),
          i = n(73498),
          o = n(94244),
          a = n(28087),
          s = n(97359),
          u = n(16918),
          l = n(4454),
          c = n(27816),
          p = n(30077),
          f = n(58081);
        function d(e, t, n, i) {
          let s = [],
            d = null == i ? void 0 : i.maxErrors;
          try {
            let i = (function (e, t, n, i) {
              let s = {};
              for (let d of t) {
                let t = d.variable.name.value,
                  h = (0, p._)(e, d.type);
                if (!(0, l.j$)(h)) {
                  let e = (0, u.print)(d.type);
                  i(
                    new a.__(
                      `Variable "$${t}" expected value of type "${e}" which cannot be used as an input type.`,
                      { nodes: d.type }
                    )
                  );
                  continue;
                }
                if (!y(n, t)) {
                  if (d.defaultValue) s[t] = (0, f.u)(d.defaultValue, h);
                  else if ((0, l.zM)(h)) {
                    let e = (0, r.X)(h);
                    i(
                      new a.__(
                        `Variable "$${t}" of required type "${e}" was not provided.`,
                        { nodes: d }
                      )
                    );
                  }
                  continue;
                }
                let m = n[t];
                if (null === m && (0, l.zM)(h)) {
                  let e = (0, r.X)(h);
                  i(
                    new a.__(
                      `Variable "$${t}" of non-null type "${e}" must not be null.`,
                      { nodes: d }
                    )
                  );
                  continue;
                }
                s[t] = (0, c.K)(m, h, (e, n, s) => {
                  let u = `Variable "$${t}" got invalid value ` + (0, r.X)(n);
                  e.length > 0 && (u += ` at "${t}${(0, o.F)(e)}"`),
                    i(
                      new a.__(u + "; " + s.message, {
                        nodes: d,
                        originalError: s,
                      })
                    );
                });
              }
              return s;
            })(e, t, n, (e) => {
              if (null != d && s.length >= d)
                throw new a.__(
                  "Too many errors processing variables, error limit reached. Execution aborted."
                );
              s.push(e);
            });
            if (0 === s.length) return { coerced: i };
          } catch (e) {
            s.push(e);
          }
          return { errors: s };
        }
        function h(e, t, n) {
          var o;
          let c = {},
            p = null !== (o = t.arguments) && void 0 !== o ? o : [],
            d = (0, i.P)(p, (e) => e.name.value);
          for (let i of e.args) {
            let e = i.name,
              o = i.type,
              p = d[e];
            if (!p) {
              if (void 0 !== i.defaultValue) c[e] = i.defaultValue;
              else if ((0, l.zM)(o))
                throw new a.__(
                  `Argument "${e}" of required type "${(0, r.X)(
                    o
                  )}" was not provided.`,
                  { nodes: t }
                );
              continue;
            }
            let h = p.value,
              m = h.kind === s.h.NULL;
            if (h.kind === s.h.VARIABLE) {
              let t = h.name.value;
              if (null == n || !y(n, t)) {
                if (void 0 !== i.defaultValue) c[e] = i.defaultValue;
                else if ((0, l.zM)(o))
                  throw new a.__(
                    `Argument "${e}" of required type "${(0, r.X)(
                      o
                    )}" was provided the variable "$${t}" which was not provided a runtime value.`,
                    { nodes: h }
                  );
                continue;
              }
              m = null == n[t];
            }
            if (m && (0, l.zM)(o))
              throw new a.__(
                `Argument "${e}" of non-null type "${(0, r.X)(
                  o
                )}" must not be null.`,
                { nodes: h }
              );
            let v = (0, f.u)(h, o, n);
            if (void 0 === v)
              throw new a.__(
                `Argument "${e}" has invalid value ${(0, u.print)(h)}.`,
                { nodes: h }
              );
            c[e] = v;
          }
          return c;
        }
        function m(e, t, n) {
          var r;
          let i =
            null === (r = t.directives) || void 0 === r
              ? void 0
              : r.find((t) => t.name.value === e.name);
          if (i) return h(e, i, n);
        }
        function y(e, t) {
          return Object.prototype.hasOwnProperty.call(e, t);
        }
      },
      79380: function (e, t, n) {
        "use strict";
        function r(e, t, n) {
          return { prev: e, key: t, typename: n };
        }
        function i(e) {
          let t = [],
            n = e;
          for (; n; ) t.push(n.key), (n = n.prev);
          return t.reverse();
        }
        n.d(t, {
          N: function () {
            return i;
          },
          Q: function () {
            return r;
          },
        });
      },
      53177: function (e, t, n) {
        "use strict";
        function r(e, t) {
          let [n, r] = t ? [e, t] : [void 0, e],
            i = " Did you mean ";
          n && (i += n + " ");
          let o = r.map((e) => `"${e}"`);
          switch (o.length) {
            case 0:
              return "";
            case 1:
              return i + o[0] + "?";
            case 2:
              return i + o[0] + " or " + o[1] + "?";
          }
          let a = o.slice(0, 5),
            s = a.pop();
          return i + a.join(", ") + ", or " + s + "?";
        }
        n.d(t, {
          l: function () {
            return r;
          },
        });
      },
      3231: function (e, t, n) {
        "use strict";
        function r(e, t) {
          let n = new Map();
          for (let r of e) {
            let e = t(r),
              i = n.get(e);
            void 0 === i ? n.set(e, [r]) : i.push(r);
          }
          return n;
        }
        n.d(t, {
          v: function () {
            return r;
          },
        });
      },
      93831: function (e, t, n) {
        "use strict";
        function r(e) {
          return (
            "object" == typeof e &&
            "function" == typeof (null == e ? void 0 : e[Symbol.iterator])
          );
        }
        n.d(t, {
          i: function () {
            return r;
          },
        });
      },
      73498: function (e, t, n) {
        "use strict";
        function r(e, t) {
          let n = Object.create(null);
          for (let r of e) n[t(r)] = r;
          return n;
        }
        n.d(t, {
          P: function () {
            return r;
          },
        });
      },
      54950: function (e, t, n) {
        "use strict";
        function r(e, t, n) {
          let r = Object.create(null);
          for (let i of e) r[t(i)] = n(i);
          return r;
        }
        n.d(t, {
          w: function () {
            return r;
          },
        });
      },
      95723: function (e, t, n) {
        "use strict";
        function r(e, t) {
          let n = Object.create(null);
          for (let r of Object.keys(e)) n[r] = t(e[r], r);
          return n;
        }
        n.d(t, {
          j: function () {
            return r;
          },
        });
      },
      8224: function (e, t, n) {
        "use strict";
        function r(e, t) {
          let n = 0,
            r = 0;
          for (; n < e.length && r < t.length; ) {
            let a = e.charCodeAt(n),
              s = t.charCodeAt(r);
            if (o(a) && o(s)) {
              let u = 0;
              do ++n, (u = 10 * u + a - i), (a = e.charCodeAt(n));
              while (o(a) && u > 0);
              let l = 0;
              do ++r, (l = 10 * l + s - i), (s = t.charCodeAt(r));
              while (o(s) && l > 0);
              if (u < l) return -1;
              if (u > l) return 1;
            } else {
              if (a < s) return -1;
              if (a > s) return 1;
              ++n, ++r;
            }
          }
          return e.length - t.length;
        }
        n.d(t, {
          K: function () {
            return r;
          },
        });
        let i = 48;
        function o(e) {
          return !isNaN(e) && i <= e && e <= 57;
        }
      },
      94244: function (e, t, n) {
        "use strict";
        function r(e) {
          return e
            .map((e) =>
              "number" == typeof e ? "[" + e.toString() + "]" : "." + e
            )
            .join("");
        }
        n.d(t, {
          F: function () {
            return r;
          },
        });
      },
      3294: function (e, t, n) {
        "use strict";
        n.d(t, {
          D: function () {
            return i;
          },
        });
        var r = n(8224);
        function i(e, t) {
          let n = Object.create(null),
            i = new o(e),
            a = Math.floor(0.4 * e.length) + 1;
          for (let e of t) {
            let t = i.measure(e, a);
            void 0 !== t && (n[e] = t);
          }
          return Object.keys(n).sort((e, t) => {
            let i = n[e] - n[t];
            return 0 !== i ? i : (0, r.K)(e, t);
          });
        }
        class o {
          constructor(e) {
            (this._input = e),
              (this._inputLowerCase = e.toLowerCase()),
              (this._inputArray = a(this._inputLowerCase)),
              (this._rows = [
                Array(e.length + 1).fill(0),
                Array(e.length + 1).fill(0),
                Array(e.length + 1).fill(0),
              ]);
          }
          measure(e, t) {
            if (this._input === e) return 0;
            let n = e.toLowerCase();
            if (this._inputLowerCase === n) return 1;
            let r = a(n),
              i = this._inputArray;
            if (r.length < i.length) {
              let e = r;
              (r = i), (i = e);
            }
            let o = r.length,
              s = i.length;
            if (o - s > t) return;
            let u = this._rows;
            for (let e = 0; e <= s; e++) u[0][e] = e;
            for (let e = 1; e <= o; e++) {
              let n = u[(e - 1) % 3],
                o = u[e % 3],
                a = (o[0] = e);
              for (let t = 1; t <= s; t++) {
                let s = r[e - 1] === i[t - 1] ? 0 : 1,
                  l = Math.min(n[t] + 1, o[t - 1] + 1, n[t - 1] + s);
                if (
                  e > 1 &&
                  t > 1 &&
                  r[e - 1] === i[t - 2] &&
                  r[e - 2] === i[t - 1]
                ) {
                  let n = u[(e - 2) % 3][t - 2];
                  l = Math.min(l, n + 1);
                }
                l < a && (a = l), (o[t] = l);
              }
              if (a > t) return;
            }
            let l = u[o % 3][s];
            return l <= t ? l : void 0;
          }
        }
        function a(e) {
          let t = e.length,
            n = Array(t);
          for (let r = 0; r < t; ++r) n[r] = e.charCodeAt(r);
          return n;
        }
      },
      28824: function (e, t, n) {
        "use strict";
        function r(e) {
          if (null == e) return Object.create(null);
          if (null === Object.getPrototypeOf(e)) return e;
          let t = Object.create(null);
          for (let [n, r] of Object.entries(e)) t[n] = r;
          return t;
        }
        n.d(t, {
          u: function () {
            return r;
          },
        });
      },
      96303: function (e, t, n) {
        "use strict";
        n.d(t, {
          g: function () {
            return s;
          },
          i: function () {
            return a;
          },
        });
        var r = n(37826),
          i = n(28087),
          o = n(68297);
        function a(e) {
          if (
            (null != e || (0, r.a)(!1, "Must provide name."),
            "string" == typeof e ||
              (0, r.a)(!1, "Expected name to be a string."),
            0 === e.length)
          )
            throw new i.__("Expected name to be a non-empty string.");
          for (let t = 1; t < e.length; ++t)
            if (!(0, o.HQ)(e.charCodeAt(t)))
              throw new i.__(
                `Names must only contain [_a-zA-Z0-9] but "${e}" does not.`
              );
          if (!(0, o.LQ)(e.charCodeAt(0)))
            throw new i.__(
              `Names must start with [_a-zA-Z] but "${e}" does not.`
            );
          return e;
        }
        function s(e) {
          if ("true" === e || "false" === e || "null" === e)
            throw new i.__(`Enum values cannot be named: ${e}`);
          return a(e);
        }
      },
      4454: function (e, t, n) {
        "use strict";
        n.d(t, {
          mR: function () {
            return ev;
          },
          sR: function () {
            return eg;
          },
          oW: function () {
            return eh;
          },
          p2: function () {
            return J;
          },
          bM: function () {
            return H;
          },
          h6: function () {
            return ea;
          },
          n2: function () {
            return eo;
          },
          Gp: function () {
            return em;
          },
          DM: function () {
            return ef;
          },
          fU: function () {
            return Q;
          },
          M_: function () {
            return G;
          },
          Zu: function () {
            return A;
          },
          U8: function () {
            return F;
          },
          qT: function () {
            return U;
          },
          k2: function () {
            return S;
          },
          H5: function () {
            return B;
          },
          kS: function () {
            return M;
          },
          rM: function () {
            return et;
          },
          E$: function () {
            return j;
          },
          i_: function () {
            return K;
          },
          Z6: function () {
            return I;
          },
          Gt: function () {
            return C;
          },
          Pt: function () {
            return b;
          },
          p_: function () {
            return _;
          },
          rc: function () {
            return $;
          },
          vX: function () {
            return q;
          },
          WO: function () {
            return el;
          },
          xC: function () {
            return en;
          },
          tf: function () {
            return W;
          },
          m0: function () {
            return z;
          },
          Gv: function () {
            return P;
          },
          EM: function () {
            return L;
          },
          hL: function () {
            return k;
          },
          j$: function () {
            return x;
          },
          oT: function () {
            return w;
          },
          UT: function () {
            return X;
          },
          HG: function () {
            return D;
          },
          Zs: function () {
            return ee;
          },
          zM: function () {
            return R;
          },
          zP: function () {
            return Z;
          },
          lp: function () {
            return N;
          },
          SZ: function () {
            return V;
          },
          dK: function () {
            return ed;
          },
          Wd: function () {
            return eE;
          },
          KA: function () {
            return E;
          },
          P9: function () {
            return g;
          },
          EN: function () {
            return O;
          },
          fw: function () {
            return Y;
          },
          WB: function () {
            return ei;
          },
          _9: function () {
            return er;
          },
        });
        var r = n(37826),
          i = n(53177);
        function o(e) {
          return e;
        }
        var a = n(25821),
          s = n(8306),
          u = n(88495),
          l = n(73498),
          c = n(54950),
          p = n(95723),
          f = n(3294),
          d = n(28824),
          h = n(28087),
          m = n(97359),
          y = n(16918),
          v = n(12319),
          T = n(96303);
        function g(e) {
          return E(e) || N(e) || w(e) || O(e) || L(e) || k(e) || D(e) || R(e);
        }
        function _(e) {
          if (!g(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL type.`);
          return e;
        }
        function E(e) {
          return (0, s.n)(e, eo);
        }
        function b(e) {
          if (!E(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL Scalar type.`);
          return e;
        }
        function N(e) {
          return (0, s.n)(e, ea);
        }
        function I(e) {
          if (!N(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL Object type.`);
          return e;
        }
        function w(e) {
          return (0, s.n)(e, eh);
        }
        function S(e) {
          if (!w(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL Interface type.`
            );
          return e;
        }
        function O(e) {
          return (0, s.n)(e, em);
        }
        function $(e) {
          if (!O(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL Union type.`);
          return e;
        }
        function L(e) {
          return (0, s.n)(e, ev);
        }
        function A(e) {
          if (!L(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL Enum type.`);
          return e;
        }
        function k(e) {
          return (0, s.n)(e, eg);
        }
        function F(e) {
          if (!k(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL Input Object type.`
            );
          return e;
        }
        function D(e) {
          return (0, s.n)(e, J);
        }
        function M(e) {
          if (!D(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL List type.`);
          return e;
        }
        function R(e) {
          return (0, s.n)(e, H);
        }
        function j(e) {
          if (!R(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL Non-Null type.`
            );
          return e;
        }
        function x(e) {
          return E(e) || L(e) || k(e) || (Y(e) && x(e.ofType));
        }
        function U(e) {
          if (!x(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL input type.`);
          return e;
        }
        function V(e) {
          return E(e) || N(e) || w(e) || O(e) || L(e) || (Y(e) && V(e.ofType));
        }
        function C(e) {
          if (!V(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL output type.`);
          return e;
        }
        function X(e) {
          return E(e) || L(e);
        }
        function B(e) {
          if (!X(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL leaf type.`);
          return e;
        }
        function P(e) {
          return N(e) || w(e) || O(e);
        }
        function G(e) {
          if (!P(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL composite type.`
            );
          return e;
        }
        function z(e) {
          return w(e) || O(e);
        }
        function Q(e) {
          if (!z(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL abstract type.`
            );
          return e;
        }
        class J {
          constructor(e) {
            g(e) ||
              (0, r.a)(!1, `Expected ${(0, a.X)(e)} to be a GraphQL type.`),
              (this.ofType = e);
          }
          get [Symbol.toStringTag]() {
            return "GraphQLList";
          }
          toString() {
            return "[" + String(this.ofType) + "]";
          }
          toJSON() {
            return this.toString();
          }
        }
        class H {
          constructor(e) {
            Z(e) ||
              (0, r.a)(
                !1,
                `Expected ${(0, a.X)(e)} to be a GraphQL nullable type.`
              ),
              (this.ofType = e);
          }
          get [Symbol.toStringTag]() {
            return "GraphQLNonNull";
          }
          toString() {
            return String(this.ofType) + "!";
          }
          toJSON() {
            return this.toString();
          }
        }
        function Y(e) {
          return D(e) || R(e);
        }
        function q(e) {
          if (!Y(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL wrapping type.`
            );
          return e;
        }
        function Z(e) {
          return g(e) && !R(e);
        }
        function K(e) {
          if (!Z(e))
            throw Error(
              `Expected ${(0, a.X)(e)} to be a GraphQL nullable type.`
            );
          return e;
        }
        function W(e) {
          if (e) return R(e) ? e.ofType : e;
        }
        function ee(e) {
          return E(e) || N(e) || w(e) || O(e) || L(e) || k(e);
        }
        function et(e) {
          if (!ee(e))
            throw Error(`Expected ${(0, a.X)(e)} to be a GraphQL named type.`);
          return e;
        }
        function en(e) {
          if (e) {
            let t = e;
            for (; Y(t); ) t = t.ofType;
            return t;
          }
        }
        function er(e) {
          return "function" == typeof e ? e() : e;
        }
        function ei(e) {
          return "function" == typeof e ? e() : e;
        }
        class eo {
          constructor(e) {
            var t, n, i, s;
            let u = null !== (t = e.parseValue) && void 0 !== t ? t : o;
            (this.name = (0, T.i)(e.name)),
              (this.description = e.description),
              (this.specifiedByURL = e.specifiedByURL),
              (this.serialize =
                null !== (n = e.serialize) && void 0 !== n ? n : o),
              (this.parseValue = u),
              (this.parseLiteral =
                null !== (i = e.parseLiteral) && void 0 !== i
                  ? i
                  : (e, t) => u((0, v.M)(e, t))),
              (this.extensions = (0, d.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (s = e.extensionASTNodes) && void 0 !== s ? s : []),
              null == e.specifiedByURL ||
                "string" == typeof e.specifiedByURL ||
                (0, r.a)(
                  !1,
                  `${
                    this.name
                  } must provide "specifiedByURL" as a string, but got: ${(0,
                  a.X)(e.specifiedByURL)}.`
                ),
              null == e.serialize ||
                "function" == typeof e.serialize ||
                (0, r.a)(
                  !1,
                  `${this.name} must provide "serialize" function. If this custom Scalar is also used as an input type, ensure "parseValue" and "parseLiteral" functions are also provided.`
                ),
              e.parseLiteral &&
                (("function" == typeof e.parseValue &&
                  "function" == typeof e.parseLiteral) ||
                  (0, r.a)(
                    !1,
                    `${this.name} must provide both "parseValue" and "parseLiteral" functions.`
                  ));
          }
          get [Symbol.toStringTag]() {
            return "GraphQLScalarType";
          }
          toConfig() {
            return {
              name: this.name,
              description: this.description,
              specifiedByURL: this.specifiedByURL,
              serialize: this.serialize,
              parseValue: this.parseValue,
              parseLiteral: this.parseLiteral,
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
            };
          }
          toString() {
            return this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        class ea {
          constructor(e) {
            var t;
            (this.name = (0, T.i)(e.name)),
              (this.description = e.description),
              (this.isTypeOf = e.isTypeOf),
              (this.extensions = (0, d.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (t = e.extensionASTNodes) && void 0 !== t ? t : []),
              (this._fields = () => eu(e)),
              (this._interfaces = () => es(e)),
              null == e.isTypeOf ||
                "function" == typeof e.isTypeOf ||
                (0, r.a)(
                  !1,
                  `${
                    this.name
                  } must provide "isTypeOf" as a function, but got: ${(0, a.X)(
                    e.isTypeOf
                  )}.`
                );
          }
          get [Symbol.toStringTag]() {
            return "GraphQLObjectType";
          }
          getFields() {
            return (
              "function" == typeof this._fields &&
                (this._fields = this._fields()),
              this._fields
            );
          }
          getInterfaces() {
            return (
              "function" == typeof this._interfaces &&
                (this._interfaces = this._interfaces()),
              this._interfaces
            );
          }
          toConfig() {
            return {
              name: this.name,
              description: this.description,
              interfaces: this.getInterfaces(),
              fields: ep(this.getFields()),
              isTypeOf: this.isTypeOf,
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
            };
          }
          toString() {
            return this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        function es(e) {
          var t;
          let n = er(null !== (t = e.interfaces) && void 0 !== t ? t : []);
          return (
            Array.isArray(n) ||
              (0, r.a)(
                !1,
                `${e.name} interfaces must be an Array or a function which returns an Array.`
              ),
            n
          );
        }
        function eu(e) {
          let t = ei(e.fields);
          return (
            ec(t) ||
              (0, r.a)(
                !1,
                `${e.name} fields must be an object with field names as keys or a function which returns such an object.`
              ),
            (0, p.j)(t, (t, n) => {
              var i;
              ec(t) ||
                (0, r.a)(!1, `${e.name}.${n} field config must be an object.`),
                null == t.resolve ||
                  "function" == typeof t.resolve ||
                  (0, r.a)(
                    !1,
                    `${
                      e.name
                    }.${n} field resolver must be a function if provided, but got: ${(0,
                    a.X)(t.resolve)}.`
                  );
              let o = null !== (i = t.args) && void 0 !== i ? i : {};
              return (
                ec(o) ||
                  (0, r.a)(
                    !1,
                    `${e.name}.${n} args must be an object with argument names as keys.`
                  ),
                {
                  name: (0, T.i)(n),
                  description: t.description,
                  type: t.type,
                  args: el(o),
                  resolve: t.resolve,
                  subscribe: t.subscribe,
                  deprecationReason: t.deprecationReason,
                  extensions: (0, d.u)(t.extensions),
                  astNode: t.astNode,
                }
              );
            })
          );
        }
        function el(e) {
          return Object.entries(e).map(([e, t]) => ({
            name: (0, T.i)(e),
            description: t.description,
            type: t.type,
            defaultValue: t.defaultValue,
            deprecationReason: t.deprecationReason,
            extensions: (0, d.u)(t.extensions),
            astNode: t.astNode,
          }));
        }
        function ec(e) {
          return (0, u.y)(e) && !Array.isArray(e);
        }
        function ep(e) {
          return (0, p.j)(e, (e) => ({
            description: e.description,
            type: e.type,
            args: ef(e.args),
            resolve: e.resolve,
            subscribe: e.subscribe,
            deprecationReason: e.deprecationReason,
            extensions: e.extensions,
            astNode: e.astNode,
          }));
        }
        function ef(e) {
          return (0, c.w)(
            e,
            (e) => e.name,
            (e) => ({
              description: e.description,
              type: e.type,
              defaultValue: e.defaultValue,
              deprecationReason: e.deprecationReason,
              extensions: e.extensions,
              astNode: e.astNode,
            })
          );
        }
        function ed(e) {
          return R(e.type) && void 0 === e.defaultValue;
        }
        class eh {
          constructor(e) {
            var t;
            (this.name = (0, T.i)(e.name)),
              (this.description = e.description),
              (this.resolveType = e.resolveType),
              (this.extensions = (0, d.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (t = e.extensionASTNodes) && void 0 !== t ? t : []),
              (this._fields = eu.bind(void 0, e)),
              (this._interfaces = es.bind(void 0, e)),
              null == e.resolveType ||
                "function" == typeof e.resolveType ||
                (0, r.a)(
                  !1,
                  `${
                    this.name
                  } must provide "resolveType" as a function, but got: ${(0,
                  a.X)(e.resolveType)}.`
                );
          }
          get [Symbol.toStringTag]() {
            return "GraphQLInterfaceType";
          }
          getFields() {
            return (
              "function" == typeof this._fields &&
                (this._fields = this._fields()),
              this._fields
            );
          }
          getInterfaces() {
            return (
              "function" == typeof this._interfaces &&
                (this._interfaces = this._interfaces()),
              this._interfaces
            );
          }
          toConfig() {
            return {
              name: this.name,
              description: this.description,
              interfaces: this.getInterfaces(),
              fields: ep(this.getFields()),
              resolveType: this.resolveType,
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
            };
          }
          toString() {
            return this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        class em {
          constructor(e) {
            var t;
            (this.name = (0, T.i)(e.name)),
              (this.description = e.description),
              (this.resolveType = e.resolveType),
              (this.extensions = (0, d.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (t = e.extensionASTNodes) && void 0 !== t ? t : []),
              (this._types = ey.bind(void 0, e)),
              null == e.resolveType ||
                "function" == typeof e.resolveType ||
                (0, r.a)(
                  !1,
                  `${
                    this.name
                  } must provide "resolveType" as a function, but got: ${(0,
                  a.X)(e.resolveType)}.`
                );
          }
          get [Symbol.toStringTag]() {
            return "GraphQLUnionType";
          }
          getTypes() {
            return (
              "function" == typeof this._types && (this._types = this._types()),
              this._types
            );
          }
          toConfig() {
            return {
              name: this.name,
              description: this.description,
              types: this.getTypes(),
              resolveType: this.resolveType,
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
            };
          }
          toString() {
            return this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        function ey(e) {
          let t = er(e.types);
          return (
            Array.isArray(t) ||
              (0, r.a)(
                !1,
                `Must provide Array of types or a function which returns such an array for Union ${e.name}.`
              ),
            t
          );
        }
        class ev {
          constructor(e) {
            var t, n, i;
            (this.name = (0, T.i)(e.name)),
              (this.description = e.description),
              (this.extensions = (0, d.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (t = e.extensionASTNodes) && void 0 !== t ? t : []),
              (this._values =
                ((n = this.name),
                ec((i = e.values)) ||
                  (0, r.a)(
                    !1,
                    `${n} values must be an object with value names as keys.`
                  ),
                Object.entries(i).map(
                  ([e, t]) => (
                    ec(t) ||
                      (0, r.a)(
                        !1,
                        `${n}.${e} must refer to an object with a "value" key representing an internal value but got: ${(0,
                        a.X)(t)}.`
                      ),
                    {
                      name: (0, T.g)(e),
                      description: t.description,
                      value: void 0 !== t.value ? t.value : e,
                      deprecationReason: t.deprecationReason,
                      extensions: (0, d.u)(t.extensions),
                      astNode: t.astNode,
                    }
                  )
                ))),
              (this._valueLookup = new Map(
                this._values.map((e) => [e.value, e])
              )),
              (this._nameLookup = (0, l.P)(this._values, (e) => e.name));
          }
          get [Symbol.toStringTag]() {
            return "GraphQLEnumType";
          }
          getValues() {
            return this._values;
          }
          getValue(e) {
            return this._nameLookup[e];
          }
          serialize(e) {
            let t = this._valueLookup.get(e);
            if (void 0 === t)
              throw new h.__(
                `Enum "${this.name}" cannot represent value: ${(0, a.X)(e)}`
              );
            return t.name;
          }
          parseValue(e) {
            if ("string" != typeof e) {
              let t = (0, a.X)(e);
              throw new h.__(
                `Enum "${this.name}" cannot represent non-string value: ${t}.` +
                  eT(this, t)
              );
            }
            let t = this.getValue(e);
            if (null == t)
              throw new h.__(
                `Value "${e}" does not exist in "${this.name}" enum.` +
                  eT(this, e)
              );
            return t.value;
          }
          parseLiteral(e, t) {
            if (e.kind !== m.h.ENUM) {
              let t = (0, y.print)(e);
              throw new h.__(
                `Enum "${this.name}" cannot represent non-enum value: ${t}.` +
                  eT(this, t),
                { nodes: e }
              );
            }
            let n = this.getValue(e.value);
            if (null == n) {
              let t = (0, y.print)(e);
              throw new h.__(
                `Value "${t}" does not exist in "${this.name}" enum.` +
                  eT(this, t),
                { nodes: e }
              );
            }
            return n.value;
          }
          toConfig() {
            let e = (0, c.w)(
              this.getValues(),
              (e) => e.name,
              (e) => ({
                description: e.description,
                value: e.value,
                deprecationReason: e.deprecationReason,
                extensions: e.extensions,
                astNode: e.astNode,
              })
            );
            return {
              name: this.name,
              description: this.description,
              values: e,
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
            };
          }
          toString() {
            return this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        function eT(e, t) {
          let n = e.getValues().map((e) => e.name),
            r = (0, f.D)(t, n);
          return (0, i.l)("the enum value", r);
        }
        class eg {
          constructor(e) {
            var t;
            (this.name = (0, T.i)(e.name)),
              (this.description = e.description),
              (this.extensions = (0, d.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (t = e.extensionASTNodes) && void 0 !== t ? t : []),
              (this._fields = e_.bind(void 0, e));
          }
          get [Symbol.toStringTag]() {
            return "GraphQLInputObjectType";
          }
          getFields() {
            return (
              "function" == typeof this._fields &&
                (this._fields = this._fields()),
              this._fields
            );
          }
          toConfig() {
            let e = (0, p.j)(this.getFields(), (e) => ({
              description: e.description,
              type: e.type,
              defaultValue: e.defaultValue,
              deprecationReason: e.deprecationReason,
              extensions: e.extensions,
              astNode: e.astNode,
            }));
            return {
              name: this.name,
              description: this.description,
              fields: e,
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
            };
          }
          toString() {
            return this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        function e_(e) {
          let t = ei(e.fields);
          return (
            ec(t) ||
              (0, r.a)(
                !1,
                `${e.name} fields must be an object with field names as keys or a function which returns such an object.`
              ),
            (0, p.j)(
              t,
              (t, n) => (
                "resolve" in t &&
                  (0, r.a)(
                    !1,
                    `${e.name}.${n} field has a resolve property, but Input Types cannot define resolvers.`
                  ),
                {
                  name: (0, T.i)(n),
                  description: t.description,
                  type: t.type,
                  defaultValue: t.defaultValue,
                  deprecationReason: t.deprecationReason,
                  extensions: (0, d.u)(t.extensions),
                  astNode: t.astNode,
                }
              )
            )
          );
        }
        function eE(e) {
          return R(e.type) && void 0 === e.defaultValue;
        }
      },
      68238: function (e, t, n) {
        "use strict";
        n.d(t, {
          CO: function () {
            return d;
          },
          NZ: function () {
            return h;
          },
          QE: function () {
            return y;
          },
          SY: function () {
            return v;
          },
          V4: function () {
            return _;
          },
          Yf: function () {
            return m;
          },
          df: function () {
            return g;
          },
          fg: function () {
            return T;
          },
          wX: function () {
            return f;
          },
          xg: function () {
            return E;
          },
        });
        var r = n(37826),
          i = n(25821),
          o = n(8306),
          a = n(88495),
          s = n(28824),
          u = n(99878),
          l = n(96303),
          c = n(4454),
          p = n(3801);
        function f(e) {
          return (0, o.n)(e, h);
        }
        function d(e) {
          if (!f(e))
            throw Error(`Expected ${(0, i.X)(e)} to be a GraphQL directive.`);
          return e;
        }
        class h {
          constructor(e) {
            var t, n;
            (this.name = (0, l.i)(e.name)),
              (this.description = e.description),
              (this.locations = e.locations),
              (this.isRepeatable =
                null !== (t = e.isRepeatable) && void 0 !== t && t),
              (this.extensions = (0, s.u)(e.extensions)),
              (this.astNode = e.astNode),
              Array.isArray(e.locations) ||
                (0, r.a)(!1, `@${e.name} locations must be an Array.`);
            let i = null !== (n = e.args) && void 0 !== n ? n : {};
            ((0, a.y)(i) && !Array.isArray(i)) ||
              (0, r.a)(
                !1,
                `@${e.name} args must be an object with argument names as keys.`
              ),
              (this.args = (0, c.WO)(i));
          }
          get [Symbol.toStringTag]() {
            return "GraphQLDirective";
          }
          toConfig() {
            return {
              name: this.name,
              description: this.description,
              locations: this.locations,
              args: (0, c.DM)(this.args),
              isRepeatable: this.isRepeatable,
              extensions: this.extensions,
              astNode: this.astNode,
            };
          }
          toString() {
            return "@" + this.name;
          }
          toJSON() {
            return this.toString();
          }
        }
        let m = new h({
            name: "include",
            description:
              "Directs the executor to include this field or fragment only when the `if` argument is true.",
            locations: [u.B.FIELD, u.B.FRAGMENT_SPREAD, u.B.INLINE_FRAGMENT],
            args: {
              if: { type: new c.bM(p.EZ), description: "Included when true." },
            },
          }),
          y = new h({
            name: "skip",
            description:
              "Directs the executor to skip this field or fragment when the `if` argument is true.",
            locations: [u.B.FIELD, u.B.FRAGMENT_SPREAD, u.B.INLINE_FRAGMENT],
            args: {
              if: { type: new c.bM(p.EZ), description: "Skipped when true." },
            },
          }),
          v = "No longer supported",
          T = new h({
            name: "deprecated",
            description:
              "Marks an element of a GraphQL schema as no longer supported.",
            locations: [
              u.B.FIELD_DEFINITION,
              u.B.ARGUMENT_DEFINITION,
              u.B.INPUT_FIELD_DEFINITION,
              u.B.ENUM_VALUE,
            ],
            args: {
              reason: {
                type: p.kH,
                description:
                  "Explains why this element was deprecated, usually also including a suggestion for how to access supported similar data. Formatted using the Markdown syntax, as specified by [CommonMark](https://commonmark.org/).",
                defaultValue: v,
              },
            },
          }),
          g = new h({
            name: "specifiedBy",
            description:
              "Exposes a URL that specifies the behavior of this scalar.",
            locations: [u.B.SCALAR],
            args: {
              url: {
                type: new c.bM(p.kH),
                description:
                  "The URL that specifies the behavior of this scalar.",
              },
            },
          }),
          _ = Object.freeze([m, y, T, g]);
        function E(e) {
          return _.some(({ name: t }) => t === e.name);
        }
      },
      52433: function (e, t, n) {
        "use strict";
        n.d(t, {
          Az: function () {
            return _;
          },
          PX: function () {
            return g;
          },
          TK: function () {
            return f;
          },
          XQ: function () {
            return v;
          },
          e_: function () {
            return y;
          },
          hU: function () {
            return b;
          },
          jT: function () {
            return T;
          },
          l3: function () {
            return d;
          },
          nL: function () {
            return N;
          },
          qz: function () {
            return m;
          },
          s9: function () {
            return I;
          },
          tF: function () {
            return E;
          },
          x2: function () {
            return h;
          },
          zU: function () {
            return i;
          },
        });
        var r,
          i,
          o = n(25821),
          a = n(29551),
          s = n(99878),
          u = n(16918),
          l = n(78631),
          c = n(4454),
          p = n(3801);
        let f = new c.h6({
            name: "__Schema",
            description:
              "A GraphQL Schema defines the capabilities of a GraphQL server. It exposes all available types and directives on the server, as well as the entry points for query, mutation, and subscription operations.",
            fields: () => ({
              description: { type: p.kH, resolve: (e) => e.description },
              types: {
                description: "A list of all types supported by this server.",
                type: new c.bM(new c.p2(new c.bM(m))),
                resolve: (e) => Object.values(e.getTypeMap()),
              },
              queryType: {
                description:
                  "The type that query operations will be rooted at.",
                type: new c.bM(m),
                resolve: (e) => e.getQueryType(),
              },
              mutationType: {
                description:
                  "If this server supports mutation, the type that mutation operations will be rooted at.",
                type: m,
                resolve: (e) => e.getMutationType(),
              },
              subscriptionType: {
                description:
                  "If this server support subscription, the type that subscription operations will be rooted at.",
                type: m,
                resolve: (e) => e.getSubscriptionType(),
              },
              directives: {
                description:
                  "A list of all directives supported by this server.",
                type: new c.bM(new c.p2(new c.bM(d))),
                resolve: (e) => e.getDirectives(),
              },
            }),
          }),
          d = new c.h6({
            name: "__Directive",
            description:
              "A Directive provides a way to describe alternate runtime execution and type validation behavior in a GraphQL document.\n\nIn some cases, you need to provide options to alter GraphQL's execution behavior in ways field arguments will not suffice, such as conditionally including or skipping a field. Directives provide this by describing additional information to the executor.",
            fields: () => ({
              name: { type: new c.bM(p.kH), resolve: (e) => e.name },
              description: { type: p.kH, resolve: (e) => e.description },
              isRepeatable: {
                type: new c.bM(p.EZ),
                resolve: (e) => e.isRepeatable,
              },
              locations: {
                type: new c.bM(new c.p2(new c.bM(h))),
                resolve: (e) => e.locations,
              },
              args: {
                type: new c.bM(new c.p2(new c.bM(v))),
                args: { includeDeprecated: { type: p.EZ, defaultValue: !1 } },
                resolve: (e, { includeDeprecated: t }) =>
                  t
                    ? e.args
                    : e.args.filter((e) => null == e.deprecationReason),
              },
            }),
          }),
          h = new c.mR({
            name: "__DirectiveLocation",
            description:
              "A Directive can be adjacent to many parts of the GraphQL language, a __DirectiveLocation describes one such possible adjacencies.",
            values: {
              QUERY: {
                value: s.B.QUERY,
                description: "Location adjacent to a query operation.",
              },
              MUTATION: {
                value: s.B.MUTATION,
                description: "Location adjacent to a mutation operation.",
              },
              SUBSCRIPTION: {
                value: s.B.SUBSCRIPTION,
                description: "Location adjacent to a subscription operation.",
              },
              FIELD: {
                value: s.B.FIELD,
                description: "Location adjacent to a field.",
              },
              FRAGMENT_DEFINITION: {
                value: s.B.FRAGMENT_DEFINITION,
                description: "Location adjacent to a fragment definition.",
              },
              FRAGMENT_SPREAD: {
                value: s.B.FRAGMENT_SPREAD,
                description: "Location adjacent to a fragment spread.",
              },
              INLINE_FRAGMENT: {
                value: s.B.INLINE_FRAGMENT,
                description: "Location adjacent to an inline fragment.",
              },
              VARIABLE_DEFINITION: {
                value: s.B.VARIABLE_DEFINITION,
                description: "Location adjacent to a variable definition.",
              },
              SCHEMA: {
                value: s.B.SCHEMA,
                description: "Location adjacent to a schema definition.",
              },
              SCALAR: {
                value: s.B.SCALAR,
                description: "Location adjacent to a scalar definition.",
              },
              OBJECT: {
                value: s.B.OBJECT,
                description: "Location adjacent to an object type definition.",
              },
              FIELD_DEFINITION: {
                value: s.B.FIELD_DEFINITION,
                description: "Location adjacent to a field definition.",
              },
              ARGUMENT_DEFINITION: {
                value: s.B.ARGUMENT_DEFINITION,
                description: "Location adjacent to an argument definition.",
              },
              INTERFACE: {
                value: s.B.INTERFACE,
                description: "Location adjacent to an interface definition.",
              },
              UNION: {
                value: s.B.UNION,
                description: "Location adjacent to a union definition.",
              },
              ENUM: {
                value: s.B.ENUM,
                description: "Location adjacent to an enum definition.",
              },
              ENUM_VALUE: {
                value: s.B.ENUM_VALUE,
                description: "Location adjacent to an enum value definition.",
              },
              INPUT_OBJECT: {
                value: s.B.INPUT_OBJECT,
                description:
                  "Location adjacent to an input object type definition.",
              },
              INPUT_FIELD_DEFINITION: {
                value: s.B.INPUT_FIELD_DEFINITION,
                description:
                  "Location adjacent to an input object field definition.",
              },
            },
          }),
          m = new c.h6({
            name: "__Type",
            description:
              "The fundamental unit of any GraphQL Schema is the type. There are many kinds of types in GraphQL as represented by the `__TypeKind` enum.\n\nDepending on the kind of a type, certain fields describe information about that type. Scalar types provide no information beyond a name, description and optional `specifiedByURL`, while Enum types provide their values. Object and Interface types provide the fields they describe. Abstract types, Union and Interface, provide the Object types possible at runtime. List and NonNull types compose other types.",
            fields: () => ({
              kind: {
                type: new c.bM(g),
                resolve: (e) =>
                  (0, c.KA)(e)
                    ? i.SCALAR
                    : (0, c.lp)(e)
                    ? i.OBJECT
                    : (0, c.oT)(e)
                    ? i.INTERFACE
                    : (0, c.EN)(e)
                    ? i.UNION
                    : (0, c.EM)(e)
                    ? i.ENUM
                    : (0, c.hL)(e)
                    ? i.INPUT_OBJECT
                    : (0, c.HG)(e)
                    ? i.LIST
                    : (0, c.zM)(e)
                    ? i.NON_NULL
                    : void (0, a.k)(!1, `Unexpected type: "${(0, o.X)(e)}".`),
              },
              name: {
                type: p.kH,
                resolve: (e) => ("name" in e ? e.name : void 0),
              },
              description: {
                type: p.kH,
                resolve: (e) => ("description" in e ? e.description : void 0),
              },
              specifiedByURL: {
                type: p.kH,
                resolve: (e) =>
                  "specifiedByURL" in e ? e.specifiedByURL : void 0,
              },
              fields: {
                type: new c.p2(new c.bM(y)),
                args: { includeDeprecated: { type: p.EZ, defaultValue: !1 } },
                resolve(e, { includeDeprecated: t }) {
                  if ((0, c.lp)(e) || (0, c.oT)(e)) {
                    let n = Object.values(e.getFields());
                    return t ? n : n.filter((e) => null == e.deprecationReason);
                  }
                },
              },
              interfaces: {
                type: new c.p2(new c.bM(m)),
                resolve(e) {
                  if ((0, c.lp)(e) || (0, c.oT)(e)) return e.getInterfaces();
                },
              },
              possibleTypes: {
                type: new c.p2(new c.bM(m)),
                resolve(e, t, n, { schema: r }) {
                  if ((0, c.m0)(e)) return r.getPossibleTypes(e);
                },
              },
              enumValues: {
                type: new c.p2(new c.bM(T)),
                args: { includeDeprecated: { type: p.EZ, defaultValue: !1 } },
                resolve(e, { includeDeprecated: t }) {
                  if ((0, c.EM)(e)) {
                    let n = e.getValues();
                    return t ? n : n.filter((e) => null == e.deprecationReason);
                  }
                },
              },
              inputFields: {
                type: new c.p2(new c.bM(v)),
                args: { includeDeprecated: { type: p.EZ, defaultValue: !1 } },
                resolve(e, { includeDeprecated: t }) {
                  if ((0, c.hL)(e)) {
                    let n = Object.values(e.getFields());
                    return t ? n : n.filter((e) => null == e.deprecationReason);
                  }
                },
              },
              ofType: {
                type: m,
                resolve: (e) => ("ofType" in e ? e.ofType : void 0),
              },
            }),
          }),
          y = new c.h6({
            name: "__Field",
            description:
              "Object and Interface types are described by a list of Fields, each of which has a name, potentially a list of arguments, and a return type.",
            fields: () => ({
              name: { type: new c.bM(p.kH), resolve: (e) => e.name },
              description: { type: p.kH, resolve: (e) => e.description },
              args: {
                type: new c.bM(new c.p2(new c.bM(v))),
                args: { includeDeprecated: { type: p.EZ, defaultValue: !1 } },
                resolve: (e, { includeDeprecated: t }) =>
                  t
                    ? e.args
                    : e.args.filter((e) => null == e.deprecationReason),
              },
              type: { type: new c.bM(m), resolve: (e) => e.type },
              isDeprecated: {
                type: new c.bM(p.EZ),
                resolve: (e) => null != e.deprecationReason,
              },
              deprecationReason: {
                type: p.kH,
                resolve: (e) => e.deprecationReason,
              },
            }),
          }),
          v = new c.h6({
            name: "__InputValue",
            description:
              "Arguments provided to Fields or Directives and the input fields of an InputObject are represented as Input Values which describe their type and optionally a default value.",
            fields: () => ({
              name: { type: new c.bM(p.kH), resolve: (e) => e.name },
              description: { type: p.kH, resolve: (e) => e.description },
              type: { type: new c.bM(m), resolve: (e) => e.type },
              defaultValue: {
                type: p.kH,
                description:
                  "A GraphQL-formatted string representing the default value for this input value.",
                resolve(e) {
                  let { type: t, defaultValue: n } = e,
                    r = (0, l.J)(n, t);
                  return r ? (0, u.print)(r) : null;
                },
              },
              isDeprecated: {
                type: new c.bM(p.EZ),
                resolve: (e) => null != e.deprecationReason,
              },
              deprecationReason: {
                type: p.kH,
                resolve: (e) => e.deprecationReason,
              },
            }),
          }),
          T = new c.h6({
            name: "__EnumValue",
            description:
              "One possible value for a given Enum. Enum values are unique values, not a placeholder for a string or numeric value. However an Enum value is returned in a JSON response as a string.",
            fields: () => ({
              name: { type: new c.bM(p.kH), resolve: (e) => e.name },
              description: { type: p.kH, resolve: (e) => e.description },
              isDeprecated: {
                type: new c.bM(p.EZ),
                resolve: (e) => null != e.deprecationReason,
              },
              deprecationReason: {
                type: p.kH,
                resolve: (e) => e.deprecationReason,
              },
            }),
          });
        ((r = i || (i = {})).SCALAR = "SCALAR"),
          (r.OBJECT = "OBJECT"),
          (r.INTERFACE = "INTERFACE"),
          (r.UNION = "UNION"),
          (r.ENUM = "ENUM"),
          (r.INPUT_OBJECT = "INPUT_OBJECT"),
          (r.LIST = "LIST"),
          (r.NON_NULL = "NON_NULL");
        let g = new c.mR({
            name: "__TypeKind",
            description:
              "An enum describing what kind of type a given `__Type` is.",
            values: {
              SCALAR: {
                value: i.SCALAR,
                description: "Indicates this type is a scalar.",
              },
              OBJECT: {
                value: i.OBJECT,
                description:
                  "Indicates this type is an object. `fields` and `interfaces` are valid fields.",
              },
              INTERFACE: {
                value: i.INTERFACE,
                description:
                  "Indicates this type is an interface. `fields`, `interfaces`, and `possibleTypes` are valid fields.",
              },
              UNION: {
                value: i.UNION,
                description:
                  "Indicates this type is a union. `possibleTypes` is a valid field.",
              },
              ENUM: {
                value: i.ENUM,
                description:
                  "Indicates this type is an enum. `enumValues` is a valid field.",
              },
              INPUT_OBJECT: {
                value: i.INPUT_OBJECT,
                description:
                  "Indicates this type is an input object. `inputFields` is a valid field.",
              },
              LIST: {
                value: i.LIST,
                description:
                  "Indicates this type is a list. `ofType` is a valid field.",
              },
              NON_NULL: {
                value: i.NON_NULL,
                description:
                  "Indicates this type is a non-null. `ofType` is a valid field.",
              },
            },
          }),
          _ = {
            name: "__schema",
            type: new c.bM(f),
            description: "Access the current type schema of this server.",
            args: [],
            resolve: (e, t, n, { schema: r }) => r,
            deprecationReason: void 0,
            extensions: Object.create(null),
            astNode: void 0,
          },
          E = {
            name: "__type",
            type: m,
            description: "Request the type information of a single type.",
            args: [
              {
                name: "name",
                description: void 0,
                type: new c.bM(p.kH),
                defaultValue: void 0,
                deprecationReason: void 0,
                extensions: Object.create(null),
                astNode: void 0,
              },
            ],
            resolve: (e, { name: t }, n, { schema: r }) => r.getType(t),
            deprecationReason: void 0,
            extensions: Object.create(null),
            astNode: void 0,
          },
          b = {
            name: "__typename",
            type: new c.bM(p.kH),
            description: "The name of the current Object type at runtime.",
            args: [],
            resolve: (e, t, n, { parentType: r }) => r.name,
            deprecationReason: void 0,
            extensions: Object.create(null),
            astNode: void 0,
          },
          N = Object.freeze([f, d, h, m, y, v, T, g]);
        function I(e) {
          return N.some(({ name: t }) => e.name === t);
        }
      },
      3801: function (e, t, n) {
        "use strict";
        n.d(t, {
          EZ: function () {
            return h;
          },
          HI: function () {
            return l;
          },
          HS: function () {
            return y;
          },
          _o: function () {
            return p;
          },
          av: function () {
            return f;
          },
          kH: function () {
            return d;
          },
          km: function () {
            return m;
          },
          st: function () {
            return c;
          },
          u1: function () {
            return v;
          },
        });
        var r = n(25821),
          i = n(88495),
          o = n(28087),
          a = n(97359),
          s = n(16918),
          u = n(4454);
        let l = 2147483647,
          c = -2147483648,
          p = new u.n2({
            name: "Int",
            description:
              "The `Int` scalar type represents non-fractional signed whole numeric values. Int can represent values between -(2^31) and 2^31 - 1.",
            serialize(e) {
              let t = T(e);
              if ("boolean" == typeof t) return t ? 1 : 0;
              let n = t;
              if (
                ("string" == typeof t && "" !== t && (n = Number(t)),
                "number" != typeof n || !Number.isInteger(n))
              )
                throw new o.__(
                  `Int cannot represent non-integer value: ${(0, r.X)(t)}`
                );
              if (n > l || n < c)
                throw new o.__(
                  "Int cannot represent non 32-bit signed integer value: " +
                    (0, r.X)(t)
                );
              return n;
            },
            parseValue(e) {
              if ("number" != typeof e || !Number.isInteger(e))
                throw new o.__(
                  `Int cannot represent non-integer value: ${(0, r.X)(e)}`
                );
              if (e > l || e < c)
                throw new o.__(
                  `Int cannot represent non 32-bit signed integer value: ${e}`
                );
              return e;
            },
            parseLiteral(e) {
              if (e.kind !== a.h.INT)
                throw new o.__(
                  `Int cannot represent non-integer value: ${(0, s.print)(e)}`,
                  { nodes: e }
                );
              let t = parseInt(e.value, 10);
              if (t > l || t < c)
                throw new o.__(
                  `Int cannot represent non 32-bit signed integer value: ${e.value}`,
                  { nodes: e }
                );
              return t;
            },
          }),
          f = new u.n2({
            name: "Float",
            description:
              "The `Float` scalar type represents signed double-precision fractional values as specified by [IEEE 754](https://en.wikipedia.org/wiki/IEEE_floating_point).",
            serialize(e) {
              let t = T(e);
              if ("boolean" == typeof t) return t ? 1 : 0;
              let n = t;
              if (
                ("string" == typeof t && "" !== t && (n = Number(t)),
                "number" != typeof n || !Number.isFinite(n))
              )
                throw new o.__(
                  `Float cannot represent non numeric value: ${(0, r.X)(t)}`
                );
              return n;
            },
            parseValue(e) {
              if ("number" != typeof e || !Number.isFinite(e))
                throw new o.__(
                  `Float cannot represent non numeric value: ${(0, r.X)(e)}`
                );
              return e;
            },
            parseLiteral(e) {
              if (e.kind !== a.h.FLOAT && e.kind !== a.h.INT)
                throw new o.__(
                  `Float cannot represent non numeric value: ${(0, s.print)(
                    e
                  )}`,
                  e
                );
              return parseFloat(e.value);
            },
          }),
          d = new u.n2({
            name: "String",
            description:
              "The `String` scalar type represents textual data, represented as UTF-8 character sequences. The String type is most often used by GraphQL to represent free-form human-readable text.",
            serialize(e) {
              let t = T(e);
              if ("string" == typeof t) return t;
              if ("boolean" == typeof t) return t ? "true" : "false";
              if ("number" == typeof t && Number.isFinite(t))
                return t.toString();
              throw new o.__(`String cannot represent value: ${(0, r.X)(e)}`);
            },
            parseValue(e) {
              if ("string" != typeof e)
                throw new o.__(
                  `String cannot represent a non string value: ${(0, r.X)(e)}`
                );
              return e;
            },
            parseLiteral(e) {
              if (e.kind !== a.h.STRING)
                throw new o.__(
                  `String cannot represent a non string value: ${(0, s.print)(
                    e
                  )}`,
                  { nodes: e }
                );
              return e.value;
            },
          }),
          h = new u.n2({
            name: "Boolean",
            description:
              "The `Boolean` scalar type represents `true` or `false`.",
            serialize(e) {
              let t = T(e);
              if ("boolean" == typeof t) return t;
              if (Number.isFinite(t)) return 0 !== t;
              throw new o.__(
                `Boolean cannot represent a non boolean value: ${(0, r.X)(t)}`
              );
            },
            parseValue(e) {
              if ("boolean" != typeof e)
                throw new o.__(
                  `Boolean cannot represent a non boolean value: ${(0, r.X)(e)}`
                );
              return e;
            },
            parseLiteral(e) {
              if (e.kind !== a.h.BOOLEAN)
                throw new o.__(
                  `Boolean cannot represent a non boolean value: ${(0, s.print)(
                    e
                  )}`,
                  { nodes: e }
                );
              return e.value;
            },
          }),
          m = new u.n2({
            name: "ID",
            description:
              'The `ID` scalar type represents a unique identifier, often used to refetch an object or as key for a cache. The ID type appears in a JSON response as a String; however, it is not intended to be human-readable. When expected as an input type, any string (such as `"4"`) or integer (such as `4`) input value will be accepted as an ID.',
            serialize(e) {
              let t = T(e);
              if ("string" == typeof t) return t;
              if (Number.isInteger(t)) return String(t);
              throw new o.__(`ID cannot represent value: ${(0, r.X)(e)}`);
            },
            parseValue(e) {
              if ("string" == typeof e) return e;
              if ("number" == typeof e && Number.isInteger(e))
                return e.toString();
              throw new o.__(`ID cannot represent value: ${(0, r.X)(e)}`);
            },
            parseLiteral(e) {
              if (e.kind !== a.h.STRING && e.kind !== a.h.INT)
                throw new o.__(
                  "ID cannot represent a non-string and non-integer value: " +
                    (0, s.print)(e),
                  { nodes: e }
                );
              return e.value;
            },
          }),
          y = Object.freeze([d, p, f, h, m]);
        function v(e) {
          return y.some(({ name: t }) => e.name === t);
        }
        function T(e) {
          if ((0, i.y)(e)) {
            if ("function" == typeof e.valueOf) {
              let t = e.valueOf();
              if (!(0, i.y)(t)) return t;
            }
            if ("function" == typeof e.toJSON) return e.toJSON();
          }
          return e;
        }
      },
      59678: function (e, t, n) {
        "use strict";
        n.d(t, {
          EO: function () {
            return d;
          },
          XO: function () {
            return h;
          },
          nN: function () {
            return f;
          },
        });
        var r = n(37826),
          i = n(25821),
          o = n(8306),
          a = n(88495),
          s = n(28824),
          u = n(72380),
          l = n(4454),
          c = n(68238),
          p = n(52433);
        function f(e) {
          return (0, o.n)(e, h);
        }
        function d(e) {
          if (!f(e))
            throw Error(`Expected ${(0, i.X)(e)} to be a GraphQL schema.`);
          return e;
        }
        class h {
          constructor(e) {
            var t, n;
            (this.__validationErrors = !0 === e.assumeValid ? [] : void 0),
              (0, a.y)(e) || (0, r.a)(!1, "Must provide configuration object."),
              !e.types ||
                Array.isArray(e.types) ||
                (0, r.a)(
                  !1,
                  `"types" must be Array if provided but got: ${(0, i.X)(
                    e.types
                  )}.`
                ),
              !e.directives ||
                Array.isArray(e.directives) ||
                (0, r.a)(
                  !1,
                  `"directives" must be Array if provided but got: ${(0, i.X)(
                    e.directives
                  )}.`
                ),
              (this.description = e.description),
              (this.extensions = (0, s.u)(e.extensions)),
              (this.astNode = e.astNode),
              (this.extensionASTNodes =
                null !== (t = e.extensionASTNodes) && void 0 !== t ? t : []),
              (this._queryType = e.query),
              (this._mutationType = e.mutation),
              (this._subscriptionType = e.subscription),
              (this._directives =
                null !== (n = e.directives) && void 0 !== n ? n : c.V4);
            let o = new Set(e.types);
            if (null != e.types) for (let t of e.types) o.delete(t), m(t, o);
            for (let e of (null != this._queryType && m(this._queryType, o),
            null != this._mutationType && m(this._mutationType, o),
            null != this._subscriptionType && m(this._subscriptionType, o),
            this._directives))
              if ((0, c.wX)(e)) for (let t of e.args) m(t.type, o);
            for (let e of (m(p.TK, o),
            (this._typeMap = Object.create(null)),
            (this._subTypeMap = Object.create(null)),
            (this._implementationsMap = Object.create(null)),
            o)) {
              if (null == e) continue;
              let t = e.name;
              if (
                (t ||
                  (0, r.a)(
                    !1,
                    "One of the provided types for building the Schema is missing a name."
                  ),
                void 0 !== this._typeMap[t])
              )
                throw Error(
                  `Schema must contain uniquely named types but contains multiple types named "${t}".`
                );
              if (((this._typeMap[t] = e), (0, l.oT)(e))) {
                for (let t of e.getInterfaces())
                  if ((0, l.oT)(t)) {
                    let n = this._implementationsMap[t.name];
                    void 0 === n &&
                      (n = this._implementationsMap[t.name] =
                        { objects: [], interfaces: [] }),
                      n.interfaces.push(e);
                  }
              } else if ((0, l.lp)(e)) {
                for (let t of e.getInterfaces())
                  if ((0, l.oT)(t)) {
                    let n = this._implementationsMap[t.name];
                    void 0 === n &&
                      (n = this._implementationsMap[t.name] =
                        { objects: [], interfaces: [] }),
                      n.objects.push(e);
                  }
              }
            }
          }
          get [Symbol.toStringTag]() {
            return "GraphQLSchema";
          }
          getQueryType() {
            return this._queryType;
          }
          getMutationType() {
            return this._mutationType;
          }
          getSubscriptionType() {
            return this._subscriptionType;
          }
          getRootType(e) {
            switch (e) {
              case u.ku.QUERY:
                return this.getQueryType();
              case u.ku.MUTATION:
                return this.getMutationType();
              case u.ku.SUBSCRIPTION:
                return this.getSubscriptionType();
            }
          }
          getTypeMap() {
            return this._typeMap;
          }
          getType(e) {
            return this.getTypeMap()[e];
          }
          getPossibleTypes(e) {
            return (0, l.EN)(e)
              ? e.getTypes()
              : this.getImplementations(e).objects;
          }
          getImplementations(e) {
            let t = this._implementationsMap[e.name];
            return null != t ? t : { objects: [], interfaces: [] };
          }
          isSubType(e, t) {
            let n = this._subTypeMap[e.name];
            if (void 0 === n) {
              if (((n = Object.create(null)), (0, l.EN)(e)))
                for (let t of e.getTypes()) n[t.name] = !0;
              else {
                let t = this.getImplementations(e);
                for (let e of t.objects) n[e.name] = !0;
                for (let e of t.interfaces) n[e.name] = !0;
              }
              this._subTypeMap[e.name] = n;
            }
            return void 0 !== n[t.name];
          }
          getDirectives() {
            return this._directives;
          }
          getDirective(e) {
            return this.getDirectives().find((t) => t.name === e);
          }
          toConfig() {
            return {
              description: this.description,
              query: this.getQueryType(),
              mutation: this.getMutationType(),
              subscription: this.getSubscriptionType(),
              types: Object.values(this.getTypeMap()),
              directives: this.getDirectives(),
              extensions: this.extensions,
              astNode: this.astNode,
              extensionASTNodes: this.extensionASTNodes,
              assumeValid: void 0 !== this.__validationErrors,
            };
          }
        }
        function m(e, t) {
          let n = (0, l.xC)(e);
          if (!t.has(n)) {
            if ((t.add(n), (0, l.EN)(n))) for (let e of n.getTypes()) m(e, t);
            else if ((0, l.lp)(n) || (0, l.oT)(n)) {
              for (let e of n.getInterfaces()) m(e, t);
              for (let e of Object.values(n.getFields()))
                for (let n of (m(e.type, t), e.args)) m(n.type, t);
            } else if ((0, l.hL)(n))
              for (let e of Object.values(n.getFields())) m(e.type, t);
          }
          return t;
        }
      },
      19655: function (e, t, n) {
        "use strict";
        n.d(t, {
          F: function () {
            return p;
          },
          J: function () {
            return f;
          },
        });
        var r = n(25821),
          i = n(28087),
          o = n(72380),
          a = n(90316),
          s = n(4454),
          u = n(68238),
          l = n(52433),
          c = n(59678);
        function p(e) {
          if (((0, c.EO)(e), e.__validationErrors)) return e.__validationErrors;
          let t = new d(e);
          (function (e) {
            var t, n, i;
            let a = e.schema,
              u = a.getQueryType();
            u
              ? (0, s.lp)(u) ||
                e.reportError(
                  `Query root type must be Object type, it cannot be ${(0, r.X)(
                    u
                  )}.`,
                  null !== (t = h(a, o.ku.QUERY)) && void 0 !== t
                    ? t
                    : u.astNode
                )
              : e.reportError("Query root type must be provided.", a.astNode);
            let l = a.getMutationType();
            l &&
              !(0, s.lp)(l) &&
              e.reportError(
                `Mutation root type must be Object type if provided, it cannot be ${(0,
                r.X)(l)}.`,
                null !== (n = h(a, o.ku.MUTATION)) && void 0 !== n
                  ? n
                  : l.astNode
              );
            let c = a.getSubscriptionType();
            c &&
              !(0, s.lp)(c) &&
              e.reportError(
                `Subscription root type must be Object type if provided, it cannot be ${(0,
                r.X)(c)}.`,
                null !== (i = h(a, o.ku.SUBSCRIPTION)) && void 0 !== i
                  ? i
                  : c.astNode
              );
          })(t),
            (function (e) {
              for (let n of e.schema.getDirectives()) {
                if (!(0, u.wX)(n)) {
                  e.reportError(
                    `Expected directive but got: ${(0, r.X)(n)}.`,
                    null == n ? void 0 : n.astNode
                  );
                  continue;
                }
                for (let i of (m(e, n), n.args))
                  if (
                    (m(e, i),
                    (0, s.j$)(i.type) ||
                      e.reportError(
                        `The type of @${n.name}(${
                          i.name
                        }:) must be Input Type but got: ${(0, r.X)(i.type)}.`,
                        i.astNode
                      ),
                    (0, s.dK)(i) && null != i.deprecationReason)
                  ) {
                    var t;
                    e.reportError(
                      `Required argument @${n.name}(${i.name}:) cannot be deprecated.`,
                      [
                        _(i.astNode),
                        null === (t = i.astNode) || void 0 === t
                          ? void 0
                          : t.type,
                      ]
                    );
                  }
              }
            })(t),
            (function (e) {
              let t = (function (e) {
                  let t = Object.create(null),
                    n = [],
                    r = Object.create(null);
                  return function i(o) {
                    if (t[o.name]) return;
                    (t[o.name] = !0), (r[o.name] = n.length);
                    let a = Object.values(o.getFields());
                    for (let t of a)
                      if ((0, s.zM)(t.type) && (0, s.hL)(t.type.ofType)) {
                        let o = t.type.ofType,
                          a = r[o.name];
                        if ((n.push(t), void 0 === a)) i(o);
                        else {
                          let t = n.slice(a),
                            r = t.map((e) => e.name).join(".");
                          e.reportError(
                            `Cannot reference Input Object "${o.name}" within itself through a series of non-null fields: "${r}".`,
                            t.map((e) => e.astNode)
                          );
                        }
                        n.pop();
                      }
                    r[o.name] = void 0;
                  };
                })(e),
                n = e.schema.getTypeMap();
              for (let i of Object.values(n)) {
                if (!(0, s.Zs)(i)) {
                  e.reportError(
                    `Expected GraphQL named type but got: ${(0, r.X)(i)}.`,
                    i.astNode
                  );
                  continue;
                }
                (0, l.s9)(i) || m(e, i),
                  (0, s.lp)(i)
                    ? (y(e, i), v(e, i))
                    : (0, s.oT)(i)
                    ? (y(e, i), v(e, i))
                    : (0, s.EN)(i)
                    ? (function (e, t) {
                        let n = t.getTypes();
                        0 === n.length &&
                          e.reportError(
                            `Union type ${t.name} must define one or more member types.`,
                            [t.astNode, ...t.extensionASTNodes]
                          );
                        let i = Object.create(null);
                        for (let o of n) {
                          if (i[o.name]) {
                            e.reportError(
                              `Union type ${t.name} can only include type ${o.name} once.`,
                              g(t, o.name)
                            );
                            continue;
                          }
                          (i[o.name] = !0),
                            (0, s.lp)(o) ||
                              e.reportError(
                                `Union type ${
                                  t.name
                                } can only include Object types, it cannot include ${(0,
                                r.X)(o)}.`,
                                g(t, String(o))
                              );
                        }
                      })(e, i)
                    : (0, s.EM)(i)
                    ? (function (e, t) {
                        let n = t.getValues();
                        for (let r of (0 === n.length &&
                          e.reportError(
                            `Enum type ${t.name} must define one or more values.`,
                            [t.astNode, ...t.extensionASTNodes]
                          ),
                        n))
                          m(e, r);
                      })(e, i)
                    : (0, s.hL)(i) &&
                      ((function (e, t) {
                        let n = Object.values(t.getFields());
                        for (let a of (0 === n.length &&
                          e.reportError(
                            `Input Object type ${t.name} must define one or more fields.`,
                            [t.astNode, ...t.extensionASTNodes]
                          ),
                        n)) {
                          var i, o;
                          m(e, a),
                            (0, s.j$)(a.type) ||
                              e.reportError(
                                `The type of ${t.name}.${
                                  a.name
                                } must be Input Type but got: ${(0, r.X)(
                                  a.type
                                )}.`,
                                null === (i = a.astNode) || void 0 === i
                                  ? void 0
                                  : i.type
                              ),
                            (0, s.Wd)(a) &&
                              null != a.deprecationReason &&
                              e.reportError(
                                `Required input field ${t.name}.${a.name} cannot be deprecated.`,
                                [
                                  _(a.astNode),
                                  null === (o = a.astNode) || void 0 === o
                                    ? void 0
                                    : o.type,
                                ]
                              );
                        }
                      })(e, i),
                      t(i));
              }
            })(t);
          let n = t.getErrors();
          return (e.__validationErrors = n), n;
        }
        function f(e) {
          let t = p(e);
          if (0 !== t.length) throw Error(t.map((e) => e.message).join("\n\n"));
        }
        class d {
          constructor(e) {
            (this._errors = []), (this.schema = e);
          }
          reportError(e, t) {
            let n = Array.isArray(t) ? t.filter(Boolean) : t;
            this._errors.push(new i.__(e, { nodes: n }));
          }
          getErrors() {
            return this._errors;
          }
        }
        function h(e, t) {
          var n;
          return null ===
            (n = [e.astNode, ...e.extensionASTNodes]
              .flatMap((e) => {
                var t;
                return null !== (t = null == e ? void 0 : e.operationTypes) &&
                  void 0 !== t
                  ? t
                  : [];
              })
              .find((e) => e.operation === t)) || void 0 === n
            ? void 0
            : n.type;
        }
        function m(e, t) {
          t.name.startsWith("__") &&
            e.reportError(
              `Name "${t.name}" must not begin with "__", which is reserved by GraphQL introspection.`,
              t.astNode
            );
        }
        function y(e, t) {
          let n = Object.values(t.getFields());
          for (let u of (0 === n.length &&
            e.reportError(`Type ${t.name} must define one or more fields.`, [
              t.astNode,
              ...t.extensionASTNodes,
            ]),
          n)) {
            var i, o, a;
            for (let n of (m(e, u),
            (0, s.SZ)(u.type) ||
              e.reportError(
                `The type of ${t.name}.${
                  u.name
                } must be Output Type but got: ${(0, r.X)(u.type)}.`,
                null === (i = u.astNode) || void 0 === i ? void 0 : i.type
              ),
            u.args)) {
              let i = n.name;
              m(e, n),
                (0, s.j$)(n.type) ||
                  e.reportError(
                    `The type of ${t.name}.${
                      u.name
                    }(${i}:) must be Input Type but got: ${(0, r.X)(n.type)}.`,
                    null === (o = n.astNode) || void 0 === o ? void 0 : o.type
                  ),
                (0, s.dK)(n) &&
                  null != n.deprecationReason &&
                  e.reportError(
                    `Required argument ${t.name}.${u.name}(${i}:) cannot be deprecated.`,
                    [
                      _(n.astNode),
                      null === (a = n.astNode) || void 0 === a
                        ? void 0
                        : a.type,
                    ]
                  );
            }
          }
        }
        function v(e, t) {
          let n = Object.create(null);
          for (let i of t.getInterfaces()) {
            if (!(0, s.oT)(i)) {
              e.reportError(
                `Type ${(0, r.X)(
                  t
                )} must only implement Interface types, it cannot implement ${(0,
                r.X)(i)}.`,
                T(t, i)
              );
              continue;
            }
            if (t === i) {
              e.reportError(
                `Type ${t.name} cannot implement itself because it would create a circular reference.`,
                T(t, i)
              );
              continue;
            }
            if (n[i.name]) {
              e.reportError(
                `Type ${t.name} can only implement ${i.name} once.`,
                T(t, i)
              );
              continue;
            }
            (n[i.name] = !0),
              (function (e, t, n) {
                let r = t.getInterfaces();
                for (let i of n.getInterfaces())
                  r.includes(i) ||
                    e.reportError(
                      i === t
                        ? `Type ${t.name} cannot implement ${n.name} because it would create a circular reference.`
                        : `Type ${t.name} must implement ${i.name} because it is implemented by ${n.name}.`,
                      [...T(n, i), ...T(t, n)]
                    );
              })(e, t, i),
              (function (e, t, n) {
                let i = t.getFields();
                for (let p of Object.values(n.getFields())) {
                  var o, u, l, c;
                  let f = p.name,
                    d = i[f];
                  if (!d) {
                    e.reportError(
                      `Interface field ${n.name}.${f} expected but ${t.name} does not provide it.`,
                      [p.astNode, t.astNode, ...t.extensionASTNodes]
                    );
                    continue;
                  }
                  for (let i of ((0, a.uJ)(e.schema, d.type, p.type) ||
                    e.reportError(
                      `Interface field ${n.name}.${f} expects type ${(0, r.X)(
                        p.type
                      )} but ${t.name}.${f} is type ${(0, r.X)(d.type)}.`,
                      [
                        null === (o = p.astNode) || void 0 === o
                          ? void 0
                          : o.type,
                        null === (u = d.astNode) || void 0 === u
                          ? void 0
                          : u.type,
                      ]
                    ),
                  p.args)) {
                    let o = i.name,
                      s = d.args.find((e) => e.name === o);
                    if (!s) {
                      e.reportError(
                        `Interface field argument ${n.name}.${f}(${o}:) expected but ${t.name}.${f} does not provide it.`,
                        [i.astNode, d.astNode]
                      );
                      continue;
                    }
                    (0, a._7)(i.type, s.type) ||
                      e.reportError(
                        `Interface field argument ${
                          n.name
                        }.${f}(${o}:) expects type ${(0, r.X)(i.type)} but ${
                          t.name
                        }.${f}(${o}:) is type ${(0, r.X)(s.type)}.`,
                        [
                          null === (l = i.astNode) || void 0 === l
                            ? void 0
                            : l.type,
                          null === (c = s.astNode) || void 0 === c
                            ? void 0
                            : c.type,
                        ]
                      );
                  }
                  for (let r of d.args) {
                    let i = r.name,
                      o = p.args.find((e) => e.name === i);
                    !o &&
                      (0, s.dK)(r) &&
                      e.reportError(
                        `Object field ${t.name}.${f} includes required argument ${i} that is missing from the Interface field ${n.name}.${f}.`,
                        [r.astNode, p.astNode]
                      );
                  }
                }
              })(e, t, i);
          }
        }
        function T(e, t) {
          let { astNode: n, extensionASTNodes: r } = e,
            i = null != n ? [n, ...r] : r;
          return i
            .flatMap((e) => {
              var t;
              return null !== (t = e.interfaces) && void 0 !== t ? t : [];
            })
            .filter((e) => e.name.value === t.name);
        }
        function g(e, t) {
          let { astNode: n, extensionASTNodes: r } = e,
            i = null != n ? [n, ...r] : r;
          return i
            .flatMap((e) => {
              var t;
              return null !== (t = e.types) && void 0 !== t ? t : [];
            })
            .filter((e) => e.name.value === t);
        }
        function _(e) {
          var t;
          return null == e
            ? void 0
            : null === (t = e.directives) || void 0 === t
            ? void 0
            : t.find((e) => e.name.value === u.fg.name);
        }
      },
      22676: function (e, t, n) {
        "use strict";
        n.d(t, {
          a: function () {
            return l;
          },
          y: function () {
            return p;
          },
        });
        var r = n(72380),
          i = n(97359),
          o = n(77304),
          a = n(4454),
          s = n(52433),
          u = n(30077);
        class l {
          constructor(e, t, n) {
            (this._schema = e),
              (this._typeStack = []),
              (this._parentTypeStack = []),
              (this._inputTypeStack = []),
              (this._fieldDefStack = []),
              (this._defaultValueStack = []),
              (this._directive = null),
              (this._argument = null),
              (this._enumValue = null),
              (this._getFieldDef = null != n ? n : c),
              t &&
                ((0, a.j$)(t) && this._inputTypeStack.push(t),
                (0, a.Gv)(t) && this._parentTypeStack.push(t),
                (0, a.SZ)(t) && this._typeStack.push(t));
          }
          get [Symbol.toStringTag]() {
            return "TypeInfo";
          }
          getType() {
            if (this._typeStack.length > 0)
              return this._typeStack[this._typeStack.length - 1];
          }
          getParentType() {
            if (this._parentTypeStack.length > 0)
              return this._parentTypeStack[this._parentTypeStack.length - 1];
          }
          getInputType() {
            if (this._inputTypeStack.length > 0)
              return this._inputTypeStack[this._inputTypeStack.length - 1];
          }
          getParentInputType() {
            if (this._inputTypeStack.length > 1)
              return this._inputTypeStack[this._inputTypeStack.length - 2];
          }
          getFieldDef() {
            if (this._fieldDefStack.length > 0)
              return this._fieldDefStack[this._fieldDefStack.length - 1];
          }
          getDefaultValue() {
            if (this._defaultValueStack.length > 0)
              return this._defaultValueStack[
                this._defaultValueStack.length - 1
              ];
          }
          getDirective() {
            return this._directive;
          }
          getArgument() {
            return this._argument;
          }
          getEnumValue() {
            return this._enumValue;
          }
          enter(e) {
            let t = this._schema;
            switch (e.kind) {
              case i.h.SELECTION_SET: {
                let e = (0, a.xC)(this.getType());
                this._parentTypeStack.push((0, a.Gv)(e) ? e : void 0);
                break;
              }
              case i.h.FIELD: {
                let n, r;
                let i = this.getParentType();
                i && (n = this._getFieldDef(t, i, e)) && (r = n.type),
                  this._fieldDefStack.push(n),
                  this._typeStack.push((0, a.SZ)(r) ? r : void 0);
                break;
              }
              case i.h.DIRECTIVE:
                this._directive = t.getDirective(e.name.value);
                break;
              case i.h.OPERATION_DEFINITION: {
                let n = t.getRootType(e.operation);
                this._typeStack.push((0, a.lp)(n) ? n : void 0);
                break;
              }
              case i.h.INLINE_FRAGMENT:
              case i.h.FRAGMENT_DEFINITION: {
                let n = e.typeCondition,
                  r = n ? (0, u._)(t, n) : (0, a.xC)(this.getType());
                this._typeStack.push((0, a.SZ)(r) ? r : void 0);
                break;
              }
              case i.h.VARIABLE_DEFINITION: {
                let n = (0, u._)(t, e.type);
                this._inputTypeStack.push((0, a.j$)(n) ? n : void 0);
                break;
              }
              case i.h.ARGUMENT: {
                var n;
                let t, r;
                let i =
                  null !== (n = this.getDirective()) && void 0 !== n
                    ? n
                    : this.getFieldDef();
                i &&
                  (t = i.args.find((t) => t.name === e.name.value)) &&
                  (r = t.type),
                  (this._argument = t),
                  this._defaultValueStack.push(t ? t.defaultValue : void 0),
                  this._inputTypeStack.push((0, a.j$)(r) ? r : void 0);
                break;
              }
              case i.h.LIST: {
                let e = (0, a.tf)(this.getInputType()),
                  t = (0, a.HG)(e) ? e.ofType : e;
                this._defaultValueStack.push(void 0),
                  this._inputTypeStack.push((0, a.j$)(t) ? t : void 0);
                break;
              }
              case i.h.OBJECT_FIELD: {
                let t, n;
                let r = (0, a.xC)(this.getInputType());
                (0, a.hL)(r) &&
                  (n = r.getFields()[e.name.value]) &&
                  (t = n.type),
                  this._defaultValueStack.push(n ? n.defaultValue : void 0),
                  this._inputTypeStack.push((0, a.j$)(t) ? t : void 0);
                break;
              }
              case i.h.ENUM: {
                let t;
                let n = (0, a.xC)(this.getInputType());
                (0, a.EM)(n) && (t = n.getValue(e.value)),
                  (this._enumValue = t);
              }
            }
          }
          leave(e) {
            switch (e.kind) {
              case i.h.SELECTION_SET:
                this._parentTypeStack.pop();
                break;
              case i.h.FIELD:
                this._fieldDefStack.pop(), this._typeStack.pop();
                break;
              case i.h.DIRECTIVE:
                this._directive = null;
                break;
              case i.h.OPERATION_DEFINITION:
              case i.h.INLINE_FRAGMENT:
              case i.h.FRAGMENT_DEFINITION:
                this._typeStack.pop();
                break;
              case i.h.VARIABLE_DEFINITION:
                this._inputTypeStack.pop();
                break;
              case i.h.ARGUMENT:
                (this._argument = null),
                  this._defaultValueStack.pop(),
                  this._inputTypeStack.pop();
                break;
              case i.h.LIST:
              case i.h.OBJECT_FIELD:
                this._defaultValueStack.pop(), this._inputTypeStack.pop();
                break;
              case i.h.ENUM:
                this._enumValue = null;
            }
          }
        }
        function c(e, t, n) {
          let r = n.name.value;
          return r === s.Az.name && e.getQueryType() === t
            ? s.Az
            : r === s.tF.name && e.getQueryType() === t
            ? s.tF
            : r === s.hU.name && (0, a.Gv)(t)
            ? s.hU
            : (0, a.lp)(t) || (0, a.oT)(t)
            ? t.getFields()[r]
            : void 0;
        }
        function p(e, t) {
          return {
            enter(...n) {
              let i = n[0];
              e.enter(i);
              let a = (0, o.Eu)(t, i.kind).enter;
              if (a) {
                let o = a.apply(t, n);
                return (
                  void 0 !== o && (e.leave(i), (0, r.UG)(o) && e.enter(o)), o
                );
              }
            },
            leave(...n) {
              let r;
              let i = n[0],
                a = (0, o.Eu)(t, i.kind).leave;
              return a && (r = a.apply(t, n)), e.leave(i), r;
            },
          };
        }
      },
      78631: function (e, t, n) {
        "use strict";
        n.d(t, {
          J: function () {
            return function e(t, n) {
              if ((0, u.zM)(n)) {
                let r = e(t, n.ofType);
                return (null == r ? void 0 : r.kind) === s.h.NULL ? null : r;
              }
              if (null === t) return { kind: s.h.NULL };
              if (void 0 === t) return null;
              if ((0, u.HG)(n)) {
                let r = n.ofType;
                if ((0, o.i)(t)) {
                  let n = [];
                  for (let i of t) {
                    let t = e(i, r);
                    null != t && n.push(t);
                  }
                  return { kind: s.h.LIST, values: n };
                }
                return e(t, r);
              }
              if ((0, u.hL)(n)) {
                if (!(0, a.y)(t)) return null;
                let r = [];
                for (let i of Object.values(n.getFields())) {
                  let n = e(t[i.name], i.type);
                  n &&
                    r.push({
                      kind: s.h.OBJECT_FIELD,
                      name: { kind: s.h.NAME, value: i.name },
                      value: n,
                    });
                }
                return { kind: s.h.OBJECT, fields: r };
              }
              if ((0, u.UT)(n)) {
                let e = n.serialize(t);
                if (null == e) return null;
                if ("boolean" == typeof e)
                  return { kind: s.h.BOOLEAN, value: e };
                if ("number" == typeof e && Number.isFinite(e)) {
                  let t = String(e);
                  return c.test(t)
                    ? { kind: s.h.INT, value: t }
                    : { kind: s.h.FLOAT, value: t };
                }
                if ("string" == typeof e)
                  return (0, u.EM)(n)
                    ? { kind: s.h.ENUM, value: e }
                    : n === l.km && c.test(e)
                    ? { kind: s.h.INT, value: e }
                    : { kind: s.h.STRING, value: e };
                throw TypeError(`Cannot convert value to AST: ${(0, r.X)(e)}.`);
              }
              (0, i.k)(!1, "Unexpected input type: " + (0, r.X)(n));
            };
          },
        });
        var r = n(25821),
          i = n(29551),
          o = n(93831),
          a = n(88495),
          s = n(97359),
          u = n(4454),
          l = n(3801);
        let c = /^-?(?:0|[1-9][0-9]*)$/;
      },
      99120: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return h;
          },
        });
        var r = n(37826),
          i = n(25821),
          o = n(88495),
          a = n(54950),
          s = n(84275),
          u = n(4454),
          l = n(68238),
          c = n(52433),
          p = n(3801),
          f = n(59678),
          d = n(58081);
        function h(e, t) {
          ((0, o.y)(e) && (0, o.y)(e.__schema)) ||
            (0, r.a)(
              !1,
              `Invalid or incomplete introspection result. Ensure that you are passing "data" property of introspection response and no "errors" was returned alongside: ${(0,
              i.X)(e)}.`
            );
          let n = e.__schema,
            h = (0, a.w)(
              n.types,
              (e) => e.name,
              (e) =>
                (function (e) {
                  if (null != e && null != e.name && null != e.kind)
                    switch (e.kind) {
                      case c.zU.SCALAR:
                        return new u.n2({
                          name: e.name,
                          description: e.description,
                          specifiedByURL: e.specifiedByURL,
                        });
                      case c.zU.OBJECT:
                        return new u.h6({
                          name: e.name,
                          description: e.description,
                          interfaces: () => N(e),
                          fields: () => I(e),
                        });
                      case c.zU.INTERFACE:
                        return new u.oW({
                          name: e.name,
                          description: e.description,
                          interfaces: () => N(e),
                          fields: () => I(e),
                        });
                      case c.zU.UNION:
                        return (function (e) {
                          if (!e.possibleTypes) {
                            let t = (0, i.X)(e);
                            throw Error(
                              `Introspection result missing possibleTypes: ${t}.`
                            );
                          }
                          return new u.Gp({
                            name: e.name,
                            description: e.description,
                            types: () => e.possibleTypes.map(E),
                          });
                        })(e);
                      case c.zU.ENUM:
                        return (function (e) {
                          if (!e.enumValues) {
                            let t = (0, i.X)(e);
                            throw Error(
                              `Introspection result missing enumValues: ${t}.`
                            );
                          }
                          return new u.mR({
                            name: e.name,
                            description: e.description,
                            values: (0, a.w)(
                              e.enumValues,
                              (e) => e.name,
                              (e) => ({
                                description: e.description,
                                deprecationReason: e.deprecationReason,
                              })
                            ),
                          });
                        })(e);
                      case c.zU.INPUT_OBJECT:
                        return (function (e) {
                          if (!e.inputFields) {
                            let t = (0, i.X)(e);
                            throw Error(
                              `Introspection result missing inputFields: ${t}.`
                            );
                          }
                          return new u.sR({
                            name: e.name,
                            description: e.description,
                            fields: () => S(e.inputFields),
                          });
                        })(e);
                    }
                  let t = (0, i.X)(e);
                  throw Error(
                    `Invalid or incomplete introspection result. Ensure that a full introspection query is used in order to build a client schema: ${t}.`
                  );
                })(e)
            );
          for (let e of [...p.HS, ...c.nL]) h[e.name] && (h[e.name] = e);
          let m = n.queryType ? E(n.queryType) : null,
            y = n.mutationType ? E(n.mutationType) : null,
            v = n.subscriptionType ? E(n.subscriptionType) : null,
            T = n.directives
              ? n.directives.map(function (e) {
                  if (!e.args) {
                    let t = (0, i.X)(e);
                    throw Error(
                      `Introspection result missing directive args: ${t}.`
                    );
                  }
                  if (!e.locations) {
                    let t = (0, i.X)(e);
                    throw Error(
                      `Introspection result missing directive locations: ${t}.`
                    );
                  }
                  return new l.NZ({
                    name: e.name,
                    description: e.description,
                    isRepeatable: e.isRepeatable,
                    locations: e.locations.slice(),
                    args: S(e.args),
                  });
                })
              : [];
          return new f.XO({
            description: n.description,
            query: m,
            mutation: y,
            subscription: v,
            types: Object.values(h),
            directives: T,
            assumeValid: null == t ? void 0 : t.assumeValid,
          });
          function g(e) {
            if (e.kind === c.zU.LIST) {
              let t = e.ofType;
              if (!t)
                throw Error("Decorated type deeper than introspection query.");
              return new u.p2(g(t));
            }
            if (e.kind === c.zU.NON_NULL) {
              let t = e.ofType;
              if (!t)
                throw Error("Decorated type deeper than introspection query.");
              let n = g(t);
              return new u.bM((0, u.i_)(n));
            }
            return _(e);
          }
          function _(e) {
            let t = e.name;
            if (!t) throw Error(`Unknown type reference: ${(0, i.X)(e)}.`);
            let n = h[t];
            if (!n)
              throw Error(
                `Invalid or incomplete schema, unknown type: ${t}. Ensure that a full introspection query is used in order to build a client schema.`
              );
            return n;
          }
          function E(e) {
            return (0, u.Z6)(_(e));
          }
          function b(e) {
            return (0, u.k2)(_(e));
          }
          function N(e) {
            if (null === e.interfaces && e.kind === c.zU.INTERFACE) return [];
            if (!e.interfaces) {
              let t = (0, i.X)(e);
              throw Error(`Introspection result missing interfaces: ${t}.`);
            }
            return e.interfaces.map(b);
          }
          function I(e) {
            if (!e.fields)
              throw Error(
                `Introspection result missing fields: ${(0, i.X)(e)}.`
              );
            return (0, a.w)(e.fields, (e) => e.name, w);
          }
          function w(e) {
            let t = g(e.type);
            if (!(0, u.SZ)(t)) {
              let e = (0, i.X)(t);
              throw Error(
                `Introspection must provide output type for fields, but received: ${e}.`
              );
            }
            if (!e.args) {
              let t = (0, i.X)(e);
              throw Error(`Introspection result missing field args: ${t}.`);
            }
            return {
              description: e.description,
              deprecationReason: e.deprecationReason,
              type: t,
              args: S(e.args),
            };
          }
          function S(e) {
            return (0, a.w)(e, (e) => e.name, O);
          }
          function O(e) {
            let t = g(e.type);
            if (!(0, u.j$)(t)) {
              let e = (0, i.X)(t);
              throw Error(
                `Introspection must provide input type for arguments, but received: ${e}.`
              );
            }
            let n =
              null != e.defaultValue
                ? (0, d.u)((0, s.H2)(e.defaultValue), t)
                : void 0;
            return {
              description: e.description,
              type: t,
              defaultValue: n,
              deprecationReason: e.deprecationReason,
            };
          }
        }
      },
      27816: function (e, t, n) {
        "use strict";
        n.d(t, {
          K: function () {
            return d;
          },
        });
        var r = n(53177),
          i = n(25821),
          o = n(29551),
          a = n(93831),
          s = n(88495),
          u = n(79380),
          l = n(94244),
          c = n(3294),
          p = n(28087),
          f = n(4454);
        function d(e, t, n = h) {
          return (function e(t, n, l, d) {
            if ((0, f.zM)(n))
              return null != t
                ? e(t, n.ofType, l, d)
                : void l(
                    (0, u.N)(d),
                    t,
                    new p.__(
                      `Expected non-nullable type "${(0, i.X)(
                        n
                      )}" not to be null.`
                    )
                  );
            if (null == t) return null;
            if ((0, f.HG)(n)) {
              let r = n.ofType;
              return (0, a.i)(t)
                ? Array.from(t, (t, n) => {
                    let i = (0, u.Q)(d, n, void 0);
                    return e(t, r, l, i);
                  })
                : [e(t, r, l, d)];
            }
            if ((0, f.hL)(n)) {
              if (!(0, s.y)(t)) {
                l(
                  (0, u.N)(d),
                  t,
                  new p.__(`Expected type "${n.name}" to be an object.`)
                );
                return;
              }
              let o = {},
                a = n.getFields();
              for (let r of Object.values(a)) {
                let a = t[r.name];
                if (void 0 === a) {
                  if (void 0 !== r.defaultValue) o[r.name] = r.defaultValue;
                  else if ((0, f.zM)(r.type)) {
                    let e = (0, i.X)(r.type);
                    l(
                      (0, u.N)(d),
                      t,
                      new p.__(
                        `Field "${r.name}" of required type "${e}" was not provided.`
                      )
                    );
                  }
                  continue;
                }
                o[r.name] = e(a, r.type, l, (0, u.Q)(d, r.name, n.name));
              }
              for (let e of Object.keys(t))
                if (!a[e]) {
                  let i = (0, c.D)(e, Object.keys(n.getFields()));
                  l(
                    (0, u.N)(d),
                    t,
                    new p.__(
                      `Field "${e}" is not defined by type "${n.name}".` +
                        (0, r.l)(i)
                    )
                  );
                }
              return o;
            }
            if ((0, f.UT)(n)) {
              let e;
              try {
                e = n.parseValue(t);
              } catch (e) {
                e instanceof p.__
                  ? l((0, u.N)(d), t, e)
                  : l(
                      (0, u.N)(d),
                      t,
                      new p.__(`Expected type "${n.name}". ` + e.message, {
                        originalError: e,
                      })
                    );
                return;
              }
              return (
                void 0 === e &&
                  l((0, u.N)(d), t, new p.__(`Expected type "${n.name}".`)),
                e
              );
            }
            (0, o.k)(!1, "Unexpected input type: " + (0, i.X)(n));
          })(e, t, n, void 0);
        }
        function h(e, t, n) {
          let r = "Invalid value " + (0, i.X)(t);
          throw (
            (e.length > 0 && (r += ` at "value${(0, l.F)(e)}"`),
            (n.message = r + ": " + n.message),
            n)
          );
        }
      },
      82254: function (e, t, n) {
        "use strict";
        function r(e) {
          let t = {
              descriptions: !0,
              specifiedByUrl: !1,
              directiveIsRepeatable: !1,
              schemaDescription: !1,
              inputValueDeprecation: !1,
              ...e,
            },
            n = t.descriptions ? "description" : "",
            r = t.specifiedByUrl ? "specifiedByURL" : "",
            i = t.directiveIsRepeatable ? "isRepeatable" : "",
            o = t.schemaDescription ? n : "";
          function a(e) {
            return t.inputValueDeprecation ? e : "";
          }
          return `
    query IntrospectionQuery {
      __schema {
        ${o}
        queryType { name }
        mutationType { name }
        subscriptionType { name }
        types {
          ...FullType
        }
        directives {
          name
          ${n}
          ${i}
          locations
          args${a("(includeDeprecated: true)")} {
            ...InputValue
          }
        }
      }
    }

    fragment FullType on __Type {
      kind
      name
      ${n}
      ${r}
      fields(includeDeprecated: true) {
        name
        ${n}
        args${a("(includeDeprecated: true)")} {
          ...InputValue
        }
        type {
          ...TypeRef
        }
        isDeprecated
        deprecationReason
      }
      inputFields${a("(includeDeprecated: true)")} {
        ...InputValue
      }
      interfaces {
        ...TypeRef
      }
      enumValues(includeDeprecated: true) {
        name
        ${n}
        isDeprecated
        deprecationReason
      }
      possibleTypes {
        ...TypeRef
      }
    }

    fragment InputValue on __InputValue {
      name
      ${n}
      type { ...TypeRef }
      defaultValue
      ${a("isDeprecated")}
      ${a("deprecationReason")}
    }

    fragment TypeRef on __Type {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
                ofType {
                  kind
                  name
                  ofType {
                    kind
                    name
                    ofType {
                      kind
                      name
                      ofType {
                        kind
                        name
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  `;
        }
        n.d(t, {
          K: function () {
            return r;
          },
        });
      },
      38360: function (e, t, n) {
        "use strict";
        n.d(t, {
          n: function () {
            return function e(t) {
              switch (t.kind) {
                case i.h.OBJECT:
                  return {
                    ...t,
                    fields: t.fields
                      .map((t) => ({ ...t, value: e(t.value) }))
                      .sort((e, t) => (0, r.K)(e.name.value, t.name.value)),
                  };
                case i.h.LIST:
                  return { ...t, values: t.values.map(e) };
                case i.h.INT:
                case i.h.FLOAT:
                case i.h.STRING:
                case i.h.BOOLEAN:
                case i.h.NULL:
                case i.h.ENUM:
                case i.h.VARIABLE:
                  return t;
              }
            };
          },
        });
        var r = n(8224),
          i = n(97359);
      },
      90316: function (e, t, n) {
        "use strict";
        n.d(t, {
          _7: function () {
            return function e(t, n) {
              return (
                t === n ||
                (!!(
                  ((0, r.zM)(t) && (0, r.zM)(n)) ||
                  ((0, r.HG)(t) && (0, r.HG)(n))
                ) &&
                  e(t.ofType, n.ofType))
              );
            };
          },
          uJ: function () {
            return function e(t, n, i) {
              return (
                n === i ||
                ((0, r.zM)(i)
                  ? !!(0, r.zM)(n) && e(t, n.ofType, i.ofType)
                  : (0, r.zM)(n)
                  ? e(t, n.ofType, i)
                  : (0, r.HG)(i)
                  ? !!(0, r.HG)(n) && e(t, n.ofType, i.ofType)
                  : !(0, r.HG)(n) &&
                    (0, r.m0)(i) &&
                    ((0, r.oT)(n) || (0, r.lp)(n)) &&
                    t.isSubType(i, n))
              );
            };
          },
          zR: function () {
            return i;
          },
        });
        var r = n(4454);
        function i(e, t, n) {
          return (
            t === n ||
            ((0, r.m0)(t)
              ? (0, r.m0)(n)
                ? e.getPossibleTypes(t).some((t) => e.isSubType(n, t))
                : e.isSubType(t, n)
              : !!(0, r.m0)(n) && e.isSubType(n, t))
          );
        }
      },
      30077: function (e, t, n) {
        "use strict";
        n.d(t, {
          _: function () {
            return function e(t, n) {
              switch (n.kind) {
                case r.h.LIST_TYPE: {
                  let r = e(t, n.type);
                  return r && new i.p2(r);
                }
                case r.h.NON_NULL_TYPE: {
                  let r = e(t, n.type);
                  return r && new i.bM(r);
                }
                case r.h.NAMED_TYPE:
                  return t.getType(n.name.value);
              }
            };
          },
        });
        var r = n(97359),
          i = n(4454);
      },
      58081: function (e, t, n) {
        "use strict";
        n.d(t, {
          u: function () {
            return function e(t, n, l) {
              if (t) {
                if (t.kind === a.h.VARIABLE) {
                  let e = t.name.value;
                  if (null == l || void 0 === l[e]) return;
                  let r = l[e];
                  if (null === r && (0, s.zM)(n)) return;
                  return r;
                }
                if ((0, s.zM)(n)) {
                  if (t.kind === a.h.NULL) return;
                  return e(t, n.ofType, l);
                }
                if (t.kind === a.h.NULL) return null;
                if ((0, s.HG)(n)) {
                  let r = n.ofType;
                  if (t.kind === a.h.LIST) {
                    let n = [];
                    for (let i of t.values)
                      if (u(i, l)) {
                        if ((0, s.zM)(r)) return;
                        n.push(null);
                      } else {
                        let t = e(i, r, l);
                        if (void 0 === t) return;
                        n.push(t);
                      }
                    return n;
                  }
                  let i = e(t, r, l);
                  if (void 0 === i) return;
                  return [i];
                }
                if ((0, s.hL)(n)) {
                  if (t.kind !== a.h.OBJECT) return;
                  let r = Object.create(null),
                    i = (0, o.P)(t.fields, (e) => e.name.value);
                  for (let t of Object.values(n.getFields())) {
                    let n = i[t.name];
                    if (!n || u(n.value, l)) {
                      if (void 0 !== t.defaultValue) r[t.name] = t.defaultValue;
                      else if ((0, s.zM)(t.type)) return;
                      continue;
                    }
                    let o = e(n.value, t.type, l);
                    if (void 0 === o) return;
                    r[t.name] = o;
                  }
                  return r;
                }
                if ((0, s.UT)(n)) {
                  let e;
                  try {
                    e = n.parseLiteral(t, l);
                  } catch (e) {
                    return;
                  }
                  if (void 0 === e) return;
                  return e;
                }
                (0, i.k)(!1, "Unexpected input type: " + (0, r.X)(n));
              }
            };
          },
        });
        var r = n(25821),
          i = n(29551),
          o = n(73498),
          a = n(97359),
          s = n(4454);
        function u(e, t) {
          return (
            e.kind === a.h.VARIABLE && (null == t || void 0 === t[e.name.value])
          );
        }
      },
      12319: function (e, t, n) {
        "use strict";
        n.d(t, {
          M: function () {
            return function e(t, n) {
              switch (t.kind) {
                case i.h.NULL:
                  return null;
                case i.h.INT:
                  return parseInt(t.value, 10);
                case i.h.FLOAT:
                  return parseFloat(t.value);
                case i.h.STRING:
                case i.h.ENUM:
                case i.h.BOOLEAN:
                  return t.value;
                case i.h.LIST:
                  return t.values.map((t) => e(t, n));
                case i.h.OBJECT:
                  return (0, r.w)(
                    t.fields,
                    (e) => e.name.value,
                    (t) => e(t.value, n)
                  );
                case i.h.VARIABLE:
                  return null == n ? void 0 : n[t.name.value];
              }
            };
          },
        });
        var r = n(54950),
          i = n(97359);
      },
      32734: function (e, t, n) {
        "use strict";
        n.d(t, {
          _t: function () {
            return u;
          },
          yv: function () {
            return s;
          },
        });
        var r = n(97359),
          i = n(77304),
          o = n(22676);
        class a {
          constructor(e, t) {
            (this._ast = e),
              (this._fragments = void 0),
              (this._fragmentSpreads = new Map()),
              (this._recursivelyReferencedFragments = new Map()),
              (this._onError = t);
          }
          get [Symbol.toStringTag]() {
            return "ASTValidationContext";
          }
          reportError(e) {
            this._onError(e);
          }
          getDocument() {
            return this._ast;
          }
          getFragment(e) {
            let t;
            if (this._fragments) t = this._fragments;
            else {
              for (let e of ((t = Object.create(null)),
              this.getDocument().definitions))
                e.kind === r.h.FRAGMENT_DEFINITION && (t[e.name.value] = e);
              this._fragments = t;
            }
            return t[e];
          }
          getFragmentSpreads(e) {
            let t = this._fragmentSpreads.get(e);
            if (!t) {
              let n;
              t = [];
              let i = [e];
              for (; (n = i.pop()); )
                for (let e of n.selections)
                  e.kind === r.h.FRAGMENT_SPREAD
                    ? t.push(e)
                    : e.selectionSet && i.push(e.selectionSet);
              this._fragmentSpreads.set(e, t);
            }
            return t;
          }
          getRecursivelyReferencedFragments(e) {
            let t = this._recursivelyReferencedFragments.get(e);
            if (!t) {
              let n;
              t = [];
              let r = Object.create(null),
                i = [e.selectionSet];
              for (; (n = i.pop()); )
                for (let e of this.getFragmentSpreads(n)) {
                  let n = e.name.value;
                  if (!0 !== r[n]) {
                    r[n] = !0;
                    let e = this.getFragment(n);
                    e && (t.push(e), i.push(e.selectionSet));
                  }
                }
              this._recursivelyReferencedFragments.set(e, t);
            }
            return t;
          }
        }
        class s extends a {
          constructor(e, t, n) {
            super(e, n), (this._schema = t);
          }
          get [Symbol.toStringTag]() {
            return "SDLValidationContext";
          }
          getSchema() {
            return this._schema;
          }
        }
        class u extends a {
          constructor(e, t, n, r) {
            super(t, r),
              (this._schema = e),
              (this._typeInfo = n),
              (this._variableUsages = new Map()),
              (this._recursiveVariableUsages = new Map());
          }
          get [Symbol.toStringTag]() {
            return "ValidationContext";
          }
          getSchema() {
            return this._schema;
          }
          getVariableUsages(e) {
            let t = this._variableUsages.get(e);
            if (!t) {
              let n = [],
                r = new o.a(this._schema);
              (0, i.Vn)(
                e,
                (0, o.y)(r, {
                  VariableDefinition: () => !1,
                  Variable(e) {
                    n.push({
                      node: e,
                      type: r.getInputType(),
                      defaultValue: r.getDefaultValue(),
                    });
                  },
                })
              ),
                (t = n),
                this._variableUsages.set(e, t);
            }
            return t;
          }
          getRecursiveVariableUsages(e) {
            let t = this._recursiveVariableUsages.get(e);
            if (!t) {
              for (let n of ((t = this.getVariableUsages(e)),
              this.getRecursivelyReferencedFragments(e)))
                t = t.concat(this.getVariableUsages(n));
              this._recursiveVariableUsages.set(e, t);
            }
            return t;
          }
          getType() {
            return this._typeInfo.getType();
          }
          getParentType() {
            return this._typeInfo.getParentType();
          }
          getInputType() {
            return this._typeInfo.getInputType();
          }
          getParentInputType() {
            return this._typeInfo.getParentInputType();
          }
          getFieldDef() {
            return this._typeInfo.getFieldDef();
          }
          getDirective() {
            return this._typeInfo.getDirective();
          }
          getArgument() {
            return this._typeInfo.getArgument();
          }
          getEnumValue() {
            return this._typeInfo.getEnumValue();
          }
        }
      },
      88081: function (e, t, n) {
        "use strict";
        n.d(t, {
          i: function () {
            return a;
          },
        });
        var r = n(28087),
          i = n(97359),
          o = n(75844);
        function a(e) {
          return {
            Document(t) {
              for (let n of t.definitions)
                if (!(0, o.Wk)(n)) {
                  let t =
                    n.kind === i.h.SCHEMA_DEFINITION ||
                    n.kind === i.h.SCHEMA_EXTENSION
                      ? "schema"
                      : '"' + n.name.value + '"';
                  e.reportError(
                    new r.__(`The ${t} definition is not executable.`, {
                      nodes: n,
                    })
                  );
                }
              return !1;
            },
          };
        }
      },
      48741: function (e, t, n) {
        "use strict";
        n.d(t, {
          A: function () {
            return u;
          },
        });
        var r = n(53177),
          i = n(8224),
          o = n(3294),
          a = n(28087),
          s = n(4454);
        function u(e) {
          return {
            Field(t) {
              let n = e.getParentType();
              if (n) {
                let u = e.getFieldDef();
                if (!u) {
                  let u = e.getSchema(),
                    l = t.name.value,
                    c = (0, r.l)(
                      "to use an inline fragment on",
                      (function (e, t, n) {
                        if (!(0, s.m0)(t)) return [];
                        let r = new Set(),
                          o = Object.create(null);
                        for (let i of e.getPossibleTypes(t))
                          if (i.getFields()[n])
                            for (let e of (r.add(i),
                            (o[i.name] = 1),
                            i.getInterfaces())) {
                              var a;
                              e.getFields()[n] &&
                                (r.add(e),
                                (o[e.name] =
                                  (null !== (a = o[e.name]) && void 0 !== a
                                    ? a
                                    : 0) + 1));
                            }
                        return [...r]
                          .sort((t, n) => {
                            let r = o[n.name] - o[t.name];
                            return 0 !== r
                              ? r
                              : (0, s.oT)(t) && e.isSubType(t, n)
                              ? -1
                              : (0, s.oT)(n) && e.isSubType(n, t)
                              ? 1
                              : (0, i.K)(t.name, n.name);
                          })
                          .map((e) => e.name);
                      })(u, n, l)
                    );
                  "" === c &&
                    (c = (0, r.l)(
                      (function (e, t) {
                        if ((0, s.lp)(e) || (0, s.oT)(e)) {
                          let n = Object.keys(e.getFields());
                          return (0, o.D)(t, n);
                        }
                        return [];
                      })(n, l)
                    )),
                    e.reportError(
                      new a.__(
                        `Cannot query field "${l}" on type "${n.name}".` + c,
                        { nodes: t }
                      )
                    );
                }
              }
            },
          };
        }
      },
      77143: function (e, t, n) {
        "use strict";
        n.d(t, {
          T: function () {
            return s;
          },
        });
        var r = n(28087),
          i = n(16918),
          o = n(4454),
          a = n(30077);
        function s(e) {
          return {
            InlineFragment(t) {
              let n = t.typeCondition;
              if (n) {
                let t = (0, a._)(e.getSchema(), n);
                if (t && !(0, o.Gv)(t)) {
                  let t = (0, i.print)(n);
                  e.reportError(
                    new r.__(
                      `Fragment cannot condition on non composite type "${t}".`,
                      { nodes: n }
                    )
                  );
                }
              }
            },
            FragmentDefinition(t) {
              let n = (0, a._)(e.getSchema(), t.typeCondition);
              if (n && !(0, o.Gv)(n)) {
                let n = (0, i.print)(t.typeCondition);
                e.reportError(
                  new r.__(
                    `Fragment "${t.name.value}" cannot condition on non composite type "${n}".`,
                    { nodes: t.typeCondition }
                  )
                );
              }
            },
          };
        }
      },
      47815: function (e, t, n) {
        "use strict";
        n.d(t, {
          e: function () {
            return u;
          },
          o: function () {
            return l;
          },
        });
        var r = n(53177),
          i = n(3294),
          o = n(28087),
          a = n(97359),
          s = n(68238);
        function u(e) {
          return {
            ...l(e),
            Argument(t) {
              let n = e.getArgument(),
                a = e.getFieldDef(),
                s = e.getParentType();
              if (!n && a && s) {
                let n = t.name.value,
                  u = a.args.map((e) => e.name),
                  l = (0, i.D)(n, u);
                e.reportError(
                  new o.__(
                    `Unknown argument "${n}" on field "${s.name}.${a.name}".` +
                      (0, r.l)(l),
                    { nodes: t }
                  )
                );
              }
            },
          };
        }
        function l(e) {
          let t = Object.create(null),
            n = e.getSchema(),
            u = n ? n.getDirectives() : s.V4;
          for (let e of u) t[e.name] = e.args.map((e) => e.name);
          let l = e.getDocument().definitions;
          for (let e of l)
            if (e.kind === a.h.DIRECTIVE_DEFINITION) {
              var c;
              let n = null !== (c = e.arguments) && void 0 !== c ? c : [];
              t[e.name.value] = n.map((e) => e.name.value);
            }
          return {
            Directive(n) {
              let a = n.name.value,
                s = t[a];
              if (n.arguments && s)
                for (let t of n.arguments) {
                  let n = t.name.value;
                  if (!s.includes(n)) {
                    let u = (0, i.D)(n, s);
                    e.reportError(
                      new o.__(
                        `Unknown argument "${n}" on directive "@${a}".` +
                          (0, r.l)(u),
                        { nodes: t }
                      )
                    );
                  }
                }
              return !1;
            },
          };
        }
      },
      84873: function (e, t, n) {
        "use strict";
        n.d(t, {
          J: function () {
            return c;
          },
        });
        var r = n(25821),
          i = n(29551),
          o = n(28087),
          a = n(72380),
          s = n(99878),
          u = n(97359),
          l = n(68238);
        function c(e) {
          let t = Object.create(null),
            n = e.getSchema(),
            c = n ? n.getDirectives() : l.V4;
          for (let e of c) t[e.name] = e.locations;
          let p = e.getDocument().definitions;
          for (let e of p)
            e.kind === u.h.DIRECTIVE_DEFINITION &&
              (t[e.name.value] = e.locations.map((e) => e.value));
          return {
            Directive(n, l, c, p, f) {
              let d = n.name.value,
                h = t[d];
              if (!h) {
                e.reportError(
                  new o.__(`Unknown directive "@${d}".`, { nodes: n })
                );
                return;
              }
              let m = (function (e) {
                let t = e[e.length - 1];
                switch (("kind" in t || (0, i.k)(!1), t.kind)) {
                  case u.h.OPERATION_DEFINITION:
                    return (function (e) {
                      switch (e) {
                        case a.ku.QUERY:
                          return s.B.QUERY;
                        case a.ku.MUTATION:
                          return s.B.MUTATION;
                        case a.ku.SUBSCRIPTION:
                          return s.B.SUBSCRIPTION;
                      }
                    })(t.operation);
                  case u.h.FIELD:
                    return s.B.FIELD;
                  case u.h.FRAGMENT_SPREAD:
                    return s.B.FRAGMENT_SPREAD;
                  case u.h.INLINE_FRAGMENT:
                    return s.B.INLINE_FRAGMENT;
                  case u.h.FRAGMENT_DEFINITION:
                    return s.B.FRAGMENT_DEFINITION;
                  case u.h.VARIABLE_DEFINITION:
                    return s.B.VARIABLE_DEFINITION;
                  case u.h.SCHEMA_DEFINITION:
                  case u.h.SCHEMA_EXTENSION:
                    return s.B.SCHEMA;
                  case u.h.SCALAR_TYPE_DEFINITION:
                  case u.h.SCALAR_TYPE_EXTENSION:
                    return s.B.SCALAR;
                  case u.h.OBJECT_TYPE_DEFINITION:
                  case u.h.OBJECT_TYPE_EXTENSION:
                    return s.B.OBJECT;
                  case u.h.FIELD_DEFINITION:
                    return s.B.FIELD_DEFINITION;
                  case u.h.INTERFACE_TYPE_DEFINITION:
                  case u.h.INTERFACE_TYPE_EXTENSION:
                    return s.B.INTERFACE;
                  case u.h.UNION_TYPE_DEFINITION:
                  case u.h.UNION_TYPE_EXTENSION:
                    return s.B.UNION;
                  case u.h.ENUM_TYPE_DEFINITION:
                  case u.h.ENUM_TYPE_EXTENSION:
                    return s.B.ENUM;
                  case u.h.ENUM_VALUE_DEFINITION:
                    return s.B.ENUM_VALUE;
                  case u.h.INPUT_OBJECT_TYPE_DEFINITION:
                  case u.h.INPUT_OBJECT_TYPE_EXTENSION:
                    return s.B.INPUT_OBJECT;
                  case u.h.INPUT_VALUE_DEFINITION: {
                    let t = e[e.length - 3];
                    return (
                      "kind" in t || (0, i.k)(!1),
                      t.kind === u.h.INPUT_OBJECT_TYPE_DEFINITION
                        ? s.B.INPUT_FIELD_DEFINITION
                        : s.B.ARGUMENT_DEFINITION
                    );
                  }
                  default:
                    (0, i.k)(!1, "Unexpected kind: " + (0, r.X)(t.kind));
                }
              })(f);
              m &&
                !h.includes(m) &&
                e.reportError(
                  new o.__(`Directive "@${d}" may not be used on ${m}.`, {
                    nodes: n,
                  })
                );
            },
          };
        }
      },
      5311: function (e, t, n) {
        "use strict";
        n.d(t, {
          a: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          return {
            FragmentSpread(t) {
              let n = t.name.value,
                i = e.getFragment(n);
              i ||
                e.reportError(
                  new r.__(`Unknown fragment "${n}".`, { nodes: t.name })
                );
            },
          };
        }
      },
      25580: function (e, t, n) {
        "use strict";
        n.d(t, {
          I: function () {
            return l;
          },
        });
        var r = n(53177),
          i = n(3294),
          o = n(28087),
          a = n(75844),
          s = n(52433),
          u = n(3801);
        function l(e) {
          let t = e.getSchema(),
            n = t ? t.getTypeMap() : Object.create(null),
            s = Object.create(null);
          for (let t of e.getDocument().definitions)
            (0, a.zT)(t) && (s[t.name.value] = !0);
          let u = [...Object.keys(n), ...Object.keys(s)];
          return {
            NamedType(t, l, p, f, d) {
              let h = t.name.value;
              if (!n[h] && !s[h]) {
                var m, y;
                let n = null !== (m = d[2]) && void 0 !== m ? m : p,
                  s =
                    null != n &&
                    "kind" in (y = n) &&
                    ((0, a.G4)(y) || (0, a.aU)(y));
                if (s && c.includes(h)) return;
                let l = (0, i.D)(h, s ? c.concat(u) : u);
                e.reportError(
                  new o.__(`Unknown type "${h}".` + (0, r.l)(l), { nodes: t })
                );
              }
            },
          };
        }
        let c = [...u.HS, ...s.nL].map((e) => e.name);
      },
      27898: function (e, t, n) {
        "use strict";
        n.d(t, {
          F: function () {
            return o;
          },
        });
        var r = n(28087),
          i = n(97359);
        function o(e) {
          let t = 0;
          return {
            Document(e) {
              t = e.definitions.filter(
                (e) => e.kind === i.h.OPERATION_DEFINITION
              ).length;
            },
            OperationDefinition(n) {
              !n.name &&
                t > 1 &&
                e.reportError(
                  new r.__(
                    "This anonymous operation must be the only defined operation.",
                    { nodes: n }
                  )
                );
            },
          };
        }
      },
      52877: function (e, t, n) {
        "use strict";
        n.d(t, {
          t: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          var t, n, i;
          let o = e.getSchema(),
            a =
              null !==
                (t =
                  null !==
                    (n =
                      null !== (i = null == o ? void 0 : o.astNode) &&
                      void 0 !== i
                        ? i
                        : null == o
                        ? void 0
                        : o.getQueryType()) && void 0 !== n
                    ? n
                    : null == o
                    ? void 0
                    : o.getMutationType()) && void 0 !== t
                ? t
                : null == o
                ? void 0
                : o.getSubscriptionType(),
            s = 0;
          return {
            SchemaDefinition(t) {
              if (a) {
                e.reportError(
                  new r.__(
                    "Cannot define a new schema within a schema extension.",
                    { nodes: t }
                  )
                );
                return;
              }
              s > 0 &&
                e.reportError(
                  new r.__("Must provide only one schema definition.", {
                    nodes: t,
                  })
                ),
                ++s;
            },
          };
        }
      },
      91422: function (e, t, n) {
        "use strict";
        n.d(t, {
          H: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = Object.create(null),
            n = [],
            i = Object.create(null);
          return {
            OperationDefinition: () => !1,
            FragmentDefinition: (o) => (
              (function o(a) {
                if (t[a.name.value]) return;
                let s = a.name.value;
                t[s] = !0;
                let u = e.getFragmentSpreads(a.selectionSet);
                if (0 !== u.length) {
                  for (let t of ((i[s] = n.length), u)) {
                    let a = t.name.value,
                      s = i[a];
                    if ((n.push(t), void 0 === s)) {
                      let t = e.getFragment(a);
                      t && o(t);
                    } else {
                      let t = n.slice(s),
                        i = t
                          .slice(0, -1)
                          .map((e) => '"' + e.name.value + '"')
                          .join(", ");
                      e.reportError(
                        new r.__(
                          `Cannot spread fragment "${a}" within itself` +
                            ("" !== i ? ` via ${i}.` : "."),
                          { nodes: t }
                        )
                      );
                    }
                    n.pop();
                  }
                  i[s] = void 0;
                }
              })(o),
              !1
            ),
          };
        }
      },
      14790: function (e, t, n) {
        "use strict";
        n.d(t, {
          $: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = Object.create(null);
          return {
            OperationDefinition: {
              enter() {
                t = Object.create(null);
              },
              leave(n) {
                let i = e.getRecursiveVariableUsages(n);
                for (let { node: o } of i) {
                  let i = o.name.value;
                  !0 !== t[i] &&
                    e.reportError(
                      new r.__(
                        n.name
                          ? `Variable "$${i}" is not defined by operation "${n.name.value}".`
                          : `Variable "$${i}" is not defined.`,
                        { nodes: [o, n] }
                      )
                    );
                }
              },
            },
            VariableDefinition(e) {
              t[e.variable.name.value] = !0;
            },
          };
        }
      },
      81294: function (e, t, n) {
        "use strict";
        n.d(t, {
          J: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = [],
            n = [];
          return {
            OperationDefinition: (e) => (t.push(e), !1),
            FragmentDefinition: (e) => (n.push(e), !1),
            Document: {
              leave() {
                let i = Object.create(null);
                for (let n of t)
                  for (let t of e.getRecursivelyReferencedFragments(n))
                    i[t.name.value] = !0;
                for (let t of n) {
                  let n = t.name.value;
                  !0 !== i[n] &&
                    e.reportError(
                      new r.__(`Fragment "${n}" is never used.`, { nodes: t })
                    );
                }
              },
            },
          };
        }
      },
      72283: function (e, t, n) {
        "use strict";
        n.d(t, {
          p: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = [];
          return {
            OperationDefinition: {
              enter() {
                t = [];
              },
              leave(n) {
                let i = Object.create(null),
                  o = e.getRecursiveVariableUsages(n);
                for (let { node: e } of o) i[e.name.value] = !0;
                for (let o of t) {
                  let t = o.variable.name.value;
                  !0 !== i[t] &&
                    e.reportError(
                      new r.__(
                        n.name
                          ? `Variable "$${t}" is never used in operation "${n.name.value}".`
                          : `Variable "$${t}" is never used.`,
                        { nodes: o }
                      )
                    );
                }
              },
            },
            VariableDefinition(e) {
              t.push(e);
            },
          };
        }
      },
      54203: function (e, t, n) {
        "use strict";
        n.d(t, {
          y: function () {
            return c;
          },
        });
        var r = n(25821),
          i = n(28087),
          o = n(97359),
          a = n(16918),
          s = n(4454),
          u = n(38360),
          l = n(30077);
        function c(e) {
          let t = new T(),
            n = new Map();
          return {
            SelectionSet(r) {
              let o = (function (e, t, n, r, i) {
                let o = [],
                  [a, s] = y(e, t, r, i);
                if (
                  ((function (e, t, n, r, i) {
                    for (let [o, a] of Object.entries(i))
                      if (a.length > 1)
                        for (let i = 0; i < a.length; i++)
                          for (let s = i + 1; s < a.length; s++) {
                            let u = h(e, n, r, !1, o, a[i], a[s]);
                            u && t.push(u);
                          }
                  })(e, o, t, n, a),
                  0 !== s.length)
                )
                  for (let r = 0; r < s.length; r++) {
                    p(e, o, t, n, !1, a, s[r]);
                    for (let i = r + 1; i < s.length; i++)
                      f(e, o, t, n, !1, s[r], s[i]);
                  }
                return o;
              })(e, n, t, e.getParentType(), r);
              for (let [[t, n], r, a] of o) {
                let o = (function e(t) {
                  return Array.isArray(t)
                    ? t
                        .map(
                          ([t, n]) =>
                            `subfields "${t}" conflict because ` + e(n)
                        )
                        .join(" and ")
                    : t;
                })(n);
                e.reportError(
                  new i.__(
                    `Fields "${t}" conflict because ${o}. Use different aliases on the fields to fetch both if this was intentional.`,
                    { nodes: r.concat(a) }
                  )
                );
              }
            },
          };
        }
        function p(e, t, n, r, i, o, a) {
          let s = e.getFragment(a);
          if (!s) return;
          let [u, l] = v(e, n, s);
          if (o !== u)
            for (let s of (d(e, t, n, r, i, o, u), l))
              r.has(s, a, i) || (r.add(s, a, i), p(e, t, n, r, i, o, s));
        }
        function f(e, t, n, r, i, o, a) {
          if (o === a || r.has(o, a, i)) return;
          r.add(o, a, i);
          let s = e.getFragment(o),
            u = e.getFragment(a);
          if (!s || !u) return;
          let [l, c] = v(e, n, s),
            [p, h] = v(e, n, u);
          for (let a of (d(e, t, n, r, i, l, p), h)) f(e, t, n, r, i, o, a);
          for (let o of c) f(e, t, n, r, i, o, a);
        }
        function d(e, t, n, r, i, o, a) {
          for (let [s, u] of Object.entries(o)) {
            let o = a[s];
            if (o)
              for (let a of u)
                for (let u of o) {
                  let o = h(e, n, r, i, s, a, u);
                  o && t.push(o);
                }
          }
        }
        function h(e, t, n, i, o, a, u) {
          let [l, c, h] = a,
            [v, T, g] = u,
            _ = i || (l !== v && (0, s.lp)(l) && (0, s.lp)(v));
          if (!_) {
            let e = c.name.value,
              t = T.name.value;
            if (e !== t)
              return [[o, `"${e}" and "${t}" are different fields`], [c], [T]];
            if (
              !(function (e, t) {
                let n = e.arguments,
                  r = t.arguments;
                if (void 0 === n || 0 === n.length)
                  return void 0 === r || 0 === r.length;
                if (void 0 === r || 0 === r.length || n.length !== r.length)
                  return !1;
                let i = new Map(r.map(({ name: e, value: t }) => [e.value, t]));
                return n.every((e) => {
                  let t = e.value,
                    n = i.get(e.name.value);
                  return void 0 !== n && m(t) === m(n);
                });
              })(c, T)
            )
              return [[o, "they have differing arguments"], [c], [T]];
          }
          let E = null == h ? void 0 : h.type,
            b = null == g ? void 0 : g.type;
          if (
            E &&
            b &&
            (function e(t, n) {
              return (0, s.HG)(t)
                ? !(0, s.HG)(n) || e(t.ofType, n.ofType)
                : !!(0, s.HG)(n) ||
                    ((0, s.zM)(t)
                      ? !(0, s.zM)(n) || e(t.ofType, n.ofType)
                      : !!(0, s.zM)(n) ||
                        (!!((0, s.UT)(t) || (0, s.UT)(n)) && t !== n));
            })(E, b)
          )
            return [
              [
                o,
                `they return conflicting types "${(0, r.X)(E)}" and "${(0, r.X)(
                  b
                )}"`,
              ],
              [c],
              [T],
            ];
          let N = c.selectionSet,
            I = T.selectionSet;
          if (N && I) {
            let r = (function (e, t, n, r, i, o, a, s) {
              let u = [],
                [l, c] = y(e, t, i, o),
                [h, m] = y(e, t, a, s);
              for (let i of (d(e, u, t, n, r, l, h), m)) p(e, u, t, n, r, l, i);
              for (let i of c) p(e, u, t, n, r, h, i);
              for (let i of c) for (let o of m) f(e, u, t, n, r, i, o);
              return u;
            })(e, t, n, _, (0, s.xC)(E), N, (0, s.xC)(b), I);
            return (function (e, t, n, r) {
              if (e.length > 0)
                return [
                  [t, e.map(([e]) => e)],
                  [n, ...e.map(([, e]) => e).flat()],
                  [r, ...e.map(([, , e]) => e).flat()],
                ];
            })(r, o, c, T);
          }
        }
        function m(e) {
          return (0, a.print)((0, u.n)(e));
        }
        function y(e, t, n, r) {
          let i = t.get(r);
          if (i) return i;
          let a = Object.create(null),
            u = Object.create(null);
          (function e(t, n, r, i, a) {
            for (let u of r.selections)
              switch (u.kind) {
                case o.h.FIELD: {
                  let e;
                  let t = u.name.value;
                  ((0, s.lp)(n) || (0, s.oT)(n)) && (e = n.getFields()[t]);
                  let r = u.alias ? u.alias.value : t;
                  i[r] || (i[r] = []), i[r].push([n, u, e]);
                  break;
                }
                case o.h.FRAGMENT_SPREAD:
                  a[u.name.value] = !0;
                  break;
                case o.h.INLINE_FRAGMENT: {
                  let r = u.typeCondition,
                    o = r ? (0, l._)(t.getSchema(), r) : n;
                  e(t, o, u.selectionSet, i, a);
                }
              }
          })(e, n, r, a, u);
          let c = [a, Object.keys(u)];
          return t.set(r, c), c;
        }
        function v(e, t, n) {
          let r = t.get(n.selectionSet);
          if (r) return r;
          let i = (0, l._)(e.getSchema(), n.typeCondition);
          return y(e, t, i, n.selectionSet);
        }
        class T {
          constructor() {
            this._data = new Map();
          }
          has(e, t, n) {
            var r;
            let [i, o] = e < t ? [e, t] : [t, e],
              a =
                null === (r = this._data.get(i)) || void 0 === r
                  ? void 0
                  : r.get(o);
            return void 0 !== a && (!!n || n === a);
          }
          add(e, t, n) {
            let [r, i] = e < t ? [e, t] : [t, e],
              o = this._data.get(r);
            void 0 === o ? this._data.set(r, new Map([[i, n]])) : o.set(i, n);
          }
        }
      },
      63259: function (e, t, n) {
        "use strict";
        n.d(t, {
          a: function () {
            return u;
          },
        });
        var r = n(25821),
          i = n(28087),
          o = n(4454),
          a = n(90316),
          s = n(30077);
        function u(e) {
          return {
            InlineFragment(t) {
              let n = e.getType(),
                s = e.getParentType();
              if (
                (0, o.Gv)(n) &&
                (0, o.Gv)(s) &&
                !(0, a.zR)(e.getSchema(), n, s)
              ) {
                let o = (0, r.X)(s),
                  a = (0, r.X)(n);
                e.reportError(
                  new i.__(
                    `Fragment cannot be spread here as objects of type "${o}" can never be of type "${a}".`,
                    { nodes: t }
                  )
                );
              }
            },
            FragmentSpread(t) {
              let n = t.name.value,
                u = (function (e, t) {
                  let n = e.getFragment(t);
                  if (n) {
                    let t = (0, s._)(e.getSchema(), n.typeCondition);
                    if ((0, o.Gv)(t)) return t;
                  }
                })(e, n),
                l = e.getParentType();
              if (u && l && !(0, a.zR)(e.getSchema(), u, l)) {
                let o = (0, r.X)(l),
                  a = (0, r.X)(u);
                e.reportError(
                  new i.__(
                    `Fragment "${n}" cannot be spread here as objects of type "${o}" can never be of type "${a}".`,
                    { nodes: t }
                  )
                );
              }
            },
          };
        }
      },
      34800: function (e, t, n) {
        "use strict";
        n.d(t, {
          g: function () {
            return p;
          },
        });
        var r = n(53177),
          i = n(25821),
          o = n(29551),
          a = n(3294),
          s = n(28087),
          u = n(97359),
          l = n(75844),
          c = n(4454);
        function p(e) {
          let t = e.getSchema(),
            n = Object.create(null);
          for (let t of e.getDocument().definitions)
            (0, l.zT)(t) && (n[t.name.value] = t);
          return {
            ScalarTypeExtension: p,
            ObjectTypeExtension: p,
            InterfaceTypeExtension: p,
            UnionTypeExtension: p,
            EnumTypeExtension: p,
            InputObjectTypeExtension: p,
          };
          function p(l) {
            let p;
            let d = l.name.value,
              h = n[d],
              m = null == t ? void 0 : t.getType(d);
            if (
              (h
                ? (p = f[h.kind])
                : m &&
                  (p = (0, c.KA)(m)
                    ? u.h.SCALAR_TYPE_EXTENSION
                    : (0, c.lp)(m)
                    ? u.h.OBJECT_TYPE_EXTENSION
                    : (0, c.oT)(m)
                    ? u.h.INTERFACE_TYPE_EXTENSION
                    : (0, c.EN)(m)
                    ? u.h.UNION_TYPE_EXTENSION
                    : (0, c.EM)(m)
                    ? u.h.ENUM_TYPE_EXTENSION
                    : (0, c.hL)(m)
                    ? u.h.INPUT_OBJECT_TYPE_EXTENSION
                    : void (0, o.k)(!1, "Unexpected type: " + (0, i.X)(m))),
              p)
            ) {
              if (p !== l.kind) {
                let t = (function (e) {
                  switch (e) {
                    case u.h.SCALAR_TYPE_EXTENSION:
                      return "scalar";
                    case u.h.OBJECT_TYPE_EXTENSION:
                      return "object";
                    case u.h.INTERFACE_TYPE_EXTENSION:
                      return "interface";
                    case u.h.UNION_TYPE_EXTENSION:
                      return "union";
                    case u.h.ENUM_TYPE_EXTENSION:
                      return "enum";
                    case u.h.INPUT_OBJECT_TYPE_EXTENSION:
                      return "input object";
                    default:
                      (0, o.k)(!1, "Unexpected kind: " + (0, i.X)(e));
                  }
                })(l.kind);
                e.reportError(
                  new s.__(`Cannot extend non-${t} type "${d}".`, {
                    nodes: h ? [h, l] : l,
                  })
                );
              }
            } else {
              let i = Object.keys({
                  ...n,
                  ...(null == t ? void 0 : t.getTypeMap()),
                }),
                o = (0, a.D)(d, i);
              e.reportError(
                new s.__(
                  `Cannot extend type "${d}" because it is not defined.` +
                    (0, r.l)(o),
                  { nodes: l.name }
                )
              );
            }
          }
        }
        let f = {
          [u.h.SCALAR_TYPE_DEFINITION]: u.h.SCALAR_TYPE_EXTENSION,
          [u.h.OBJECT_TYPE_DEFINITION]: u.h.OBJECT_TYPE_EXTENSION,
          [u.h.INTERFACE_TYPE_DEFINITION]: u.h.INTERFACE_TYPE_EXTENSION,
          [u.h.UNION_TYPE_DEFINITION]: u.h.UNION_TYPE_EXTENSION,
          [u.h.ENUM_TYPE_DEFINITION]: u.h.ENUM_TYPE_EXTENSION,
          [u.h.INPUT_OBJECT_TYPE_DEFINITION]: u.h.INPUT_OBJECT_TYPE_EXTENSION,
        };
      },
      61967: function (e, t, n) {
        "use strict";
        n.d(t, {
          c: function () {
            return p;
          },
          s: function () {
            return c;
          },
        });
        var r = n(25821),
          i = n(73498),
          o = n(28087),
          a = n(97359),
          s = n(16918),
          u = n(4454),
          l = n(68238);
        function c(e) {
          return {
            ...p(e),
            Field: {
              leave(t) {
                var n;
                let i = e.getFieldDef();
                if (!i) return !1;
                let a = new Set(
                  null === (n = t.arguments) || void 0 === n
                    ? void 0
                    : n.map((e) => e.name.value)
                );
                for (let n of i.args)
                  if (!a.has(n.name) && (0, u.dK)(n)) {
                    let a = (0, r.X)(n.type);
                    e.reportError(
                      new o.__(
                        `Field "${i.name}" argument "${n.name}" of type "${a}" is required, but it was not provided.`,
                        { nodes: t }
                      )
                    );
                  }
              },
            },
          };
        }
        function p(e) {
          var t, n;
          let c = Object.create(null),
            p = e.getSchema(),
            d =
              null !== (t = null == p ? void 0 : p.getDirectives()) &&
              void 0 !== t
                ? t
                : l.V4;
          for (let e of d)
            c[e.name] = (0, i.P)(e.args.filter(u.dK), (e) => e.name);
          let h = e.getDocument().definitions;
          for (let e of h)
            if (e.kind === a.h.DIRECTIVE_DEFINITION) {
              let t = null !== (n = e.arguments) && void 0 !== n ? n : [];
              c[e.name.value] = (0, i.P)(t.filter(f), (e) => e.name.value);
            }
          return {
            Directive: {
              leave(t) {
                let n = t.name.value,
                  i = c[n];
                if (i) {
                  var a;
                  let l = null !== (a = t.arguments) && void 0 !== a ? a : [],
                    c = new Set(l.map((e) => e.name.value));
                  for (let [a, l] of Object.entries(i))
                    if (!c.has(a)) {
                      let i = (0, u.P9)(l.type)
                        ? (0, r.X)(l.type)
                        : (0, s.print)(l.type);
                      e.reportError(
                        new o.__(
                          `Directive "@${n}" argument "${a}" of type "${i}" is required, but it was not provided.`,
                          { nodes: t }
                        )
                      );
                    }
                }
              },
            },
          };
        }
        function f(e) {
          return e.type.kind === a.h.NON_NULL_TYPE && null == e.defaultValue;
        }
      },
      41954: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return a;
          },
        });
        var r = n(25821),
          i = n(28087),
          o = n(4454);
        function a(e) {
          return {
            Field(t) {
              let n = e.getType(),
                a = t.selectionSet;
              if (n) {
                if ((0, o.UT)((0, o.xC)(n))) {
                  if (a) {
                    let o = t.name.value,
                      s = (0, r.X)(n);
                    e.reportError(
                      new i.__(
                        `Field "${o}" must not have a selection since type "${s}" has no subfields.`,
                        { nodes: a }
                      )
                    );
                  }
                } else if (!a) {
                  let o = t.name.value,
                    a = (0, r.X)(n);
                  e.reportError(
                    new i.__(
                      `Field "${o}" of type "${a}" must have a selection of subfields. Did you mean "${o} { ... }"?`,
                      { nodes: t }
                    )
                  );
                }
              }
            },
          };
        }
      },
      10423: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return a;
          },
        });
        var r = n(28087),
          i = n(97359),
          o = n(97677);
        function a(e) {
          return {
            OperationDefinition(t) {
              if ("subscription" === t.operation) {
                let n = e.getSchema(),
                  a = n.getSubscriptionType();
                if (a) {
                  let s = t.name ? t.name.value : null,
                    u = Object.create(null),
                    l = e.getDocument(),
                    c = Object.create(null);
                  for (let e of l.definitions)
                    e.kind === i.h.FRAGMENT_DEFINITION && (c[e.name.value] = e);
                  let p = (0, o.g)(n, c, u, a, t.selectionSet);
                  if (p.size > 1) {
                    let t = [...p.values()],
                      n = t.slice(1),
                      i = n.flat();
                    e.reportError(
                      new r.__(
                        null != s
                          ? `Subscription "${s}" must select only one top level field.`
                          : "Anonymous Subscription must select only one top level field.",
                        { nodes: i }
                      )
                    );
                  }
                  for (let t of p.values()) {
                    let n = t[0],
                      i = n.name.value;
                    i.startsWith("__") &&
                      e.reportError(
                        new r.__(
                          null != s
                            ? `Subscription "${s}" must not select an introspection top level field.`
                            : "Anonymous Subscription must not select an introspection top level field.",
                          { nodes: t }
                        )
                      );
                  }
                }
              }
            },
          };
        }
      },
      12337: function (e, t, n) {
        "use strict";
        n.d(t, {
          L: function () {
            return o;
          },
        });
        var r = n(3231),
          i = n(28087);
        function o(e) {
          return {
            DirectiveDefinition(e) {
              var t;
              let r = null !== (t = e.arguments) && void 0 !== t ? t : [];
              return n(`@${e.name.value}`, r);
            },
            InterfaceTypeDefinition: t,
            InterfaceTypeExtension: t,
            ObjectTypeDefinition: t,
            ObjectTypeExtension: t,
          };
          function t(e) {
            var t, r;
            let i = e.name.value,
              o = null !== (t = e.fields) && void 0 !== t ? t : [];
            for (let e of o) {
              let t = e.name.value,
                o = null !== (r = e.arguments) && void 0 !== r ? r : [];
              n(`${i}.${t}`, o);
            }
            return !1;
          }
          function n(t, n) {
            let o = (0, r.v)(n, (e) => e.name.value);
            for (let [n, r] of o)
              r.length > 1 &&
                e.reportError(
                  new i.__(`Argument "${t}(${n}:)" can only be defined once.`, {
                    nodes: r.map((e) => e.name),
                  })
                );
            return !1;
          }
        }
      },
      42266: function (e, t, n) {
        "use strict";
        n.d(t, {
          L: function () {
            return o;
          },
        });
        var r = n(3231),
          i = n(28087);
        function o(e) {
          return { Field: t, Directive: t };
          function t(t) {
            var n;
            let o = null !== (n = t.arguments) && void 0 !== n ? n : [],
              a = (0, r.v)(o, (e) => e.name.value);
            for (let [t, n] of a)
              n.length > 1 &&
                e.reportError(
                  new i.__(`There can be only one argument named "${t}".`, {
                    nodes: n.map((e) => e.name),
                  })
                );
          }
        }
      },
      53274: function (e, t, n) {
        "use strict";
        n.d(t, {
          o: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = Object.create(null),
            n = e.getSchema();
          return {
            DirectiveDefinition(i) {
              let o = i.name.value;
              if (null != n && n.getDirective(o)) {
                e.reportError(
                  new r.__(
                    `Directive "@${o}" already exists in the schema. It cannot be redefined.`,
                    { nodes: i.name }
                  )
                );
                return;
              }
              return (
                t[o]
                  ? e.reportError(
                      new r.__(
                        `There can be only one directive named "@${o}".`,
                        { nodes: [t[o], i.name] }
                      )
                    )
                  : (t[o] = i.name),
                !1
              );
            },
          };
        }
      },
      96300: function (e, t, n) {
        "use strict";
        n.d(t, {
          k: function () {
            return s;
          },
        });
        var r = n(28087),
          i = n(97359),
          o = n(75844),
          a = n(68238);
        function s(e) {
          let t = Object.create(null),
            n = e.getSchema(),
            s = n ? n.getDirectives() : a.V4;
          for (let e of s) t[e.name] = !e.isRepeatable;
          let u = e.getDocument().definitions;
          for (let e of u)
            e.kind === i.h.DIRECTIVE_DEFINITION &&
              (t[e.name.value] = !e.repeatable);
          let l = Object.create(null),
            c = Object.create(null);
          return {
            enter(n) {
              let a;
              if ("directives" in n && n.directives) {
                if (
                  n.kind === i.h.SCHEMA_DEFINITION ||
                  n.kind === i.h.SCHEMA_EXTENSION
                )
                  a = l;
                else if ((0, o.zT)(n) || (0, o.D$)(n)) {
                  let e = n.name.value;
                  void 0 === (a = c[e]) && (c[e] = a = Object.create(null));
                } else a = Object.create(null);
                for (let i of n.directives) {
                  let n = i.name.value;
                  t[n] &&
                    (a[n]
                      ? e.reportError(
                          new r.__(
                            `The directive "@${n}" can only be used once at this location.`,
                            { nodes: [a[n], i] }
                          )
                        )
                      : (a[n] = i));
                }
              }
            },
          };
        }
      },
      93201: function (e, t, n) {
        "use strict";
        n.d(t, {
          L: function () {
            return o;
          },
        });
        var r = n(28087),
          i = n(4454);
        function o(e) {
          let t = e.getSchema(),
            n = t ? t.getTypeMap() : Object.create(null),
            o = Object.create(null);
          return { EnumTypeDefinition: a, EnumTypeExtension: a };
          function a(t) {
            var a;
            let s = t.name.value;
            o[s] || (o[s] = Object.create(null));
            let u = null !== (a = t.values) && void 0 !== a ? a : [],
              l = o[s];
            for (let t of u) {
              let o = t.name.value,
                a = n[s];
              (0, i.EM)(a) && a.getValue(o)
                ? e.reportError(
                    new r.__(
                      `Enum value "${s}.${o}" already exists in the schema. It cannot also be defined in this type extension.`,
                      { nodes: t.name }
                    )
                  )
                : l[o]
                ? e.reportError(
                    new r.__(
                      `Enum value "${s}.${o}" can only be defined once.`,
                      { nodes: [l[o], t.name] }
                    )
                  )
                : (l[o] = t.name);
            }
            return !1;
          }
        }
      },
      22618: function (e, t, n) {
        "use strict";
        n.d(t, {
          y: function () {
            return o;
          },
        });
        var r = n(28087),
          i = n(4454);
        function o(e) {
          let t = e.getSchema(),
            n = t ? t.getTypeMap() : Object.create(null),
            o = Object.create(null);
          return {
            InputObjectTypeDefinition: a,
            InputObjectTypeExtension: a,
            InterfaceTypeDefinition: a,
            InterfaceTypeExtension: a,
            ObjectTypeDefinition: a,
            ObjectTypeExtension: a,
          };
          function a(t) {
            var a, s;
            let u = t.name.value;
            o[u] || (o[u] = Object.create(null));
            let l = null !== (a = t.fields) && void 0 !== a ? a : [],
              c = o[u];
            for (let t of l) {
              let o = t.name.value;
              ((s = n[u]),
              ((0, i.lp)(s) || (0, i.oT)(s) || (0, i.hL)(s)) &&
                null != s.getFields()[o])
                ? e.reportError(
                    new r.__(
                      `Field "${u}.${o}" already exists in the schema. It cannot also be defined in this type extension.`,
                      { nodes: t.name }
                    )
                  )
                : c[o]
                ? e.reportError(
                    new r.__(`Field "${u}.${o}" can only be defined once.`, {
                      nodes: [c[o], t.name],
                    })
                  )
                : (c[o] = t.name);
            }
            return !1;
          }
        }
      },
      45591: function (e, t, n) {
        "use strict";
        n.d(t, {
          N: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = Object.create(null);
          return {
            OperationDefinition: () => !1,
            FragmentDefinition(n) {
              let i = n.name.value;
              return (
                t[i]
                  ? e.reportError(
                      new r.__(`There can be only one fragment named "${i}".`, {
                        nodes: [t[i], n.name],
                      })
                    )
                  : (t[i] = n.name),
                !1
              );
            },
          };
        }
      },
      92767: function (e, t, n) {
        "use strict";
        n.d(t, {
          P: function () {
            return o;
          },
        });
        var r = n(29551),
          i = n(28087);
        function o(e) {
          let t = [],
            n = Object.create(null);
          return {
            ObjectValue: {
              enter() {
                t.push(n), (n = Object.create(null));
              },
              leave() {
                let e = t.pop();
                e || (0, r.k)(!1), (n = e);
              },
            },
            ObjectField(t) {
              let r = t.name.value;
              n[r]
                ? e.reportError(
                    new i.__(
                      `There can be only one input field named "${r}".`,
                      { nodes: [n[r], t.name] }
                    )
                  )
                : (n[r] = t.name);
            },
          };
        }
      },
      82621: function (e, t, n) {
        "use strict";
        n.d(t, {
          H: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = Object.create(null);
          return {
            OperationDefinition(n) {
              let i = n.name;
              return (
                i &&
                  (t[i.value]
                    ? e.reportError(
                        new r.__(
                          `There can be only one operation named "${i.value}".`,
                          { nodes: [t[i.value], i] }
                        )
                      )
                    : (t[i.value] = i)),
                !1
              );
            },
            FragmentDefinition: () => !1,
          };
        }
      },
      77990: function (e, t, n) {
        "use strict";
        n.d(t, {
          q: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = e.getSchema(),
            n = Object.create(null),
            i = t
              ? {
                  query: t.getQueryType(),
                  mutation: t.getMutationType(),
                  subscription: t.getSubscriptionType(),
                }
              : {};
          return { SchemaDefinition: o, SchemaExtension: o };
          function o(t) {
            var o;
            let a = null !== (o = t.operationTypes) && void 0 !== o ? o : [];
            for (let t of a) {
              let o = t.operation,
                a = n[o];
              i[o]
                ? e.reportError(
                    new r.__(
                      `Type for ${o} already defined in the schema. It cannot be redefined.`,
                      { nodes: t }
                    )
                  )
                : a
                ? e.reportError(
                    new r.__(`There can be only one ${o} type in schema.`, {
                      nodes: [a, t],
                    })
                  )
                : (n[o] = t);
            }
            return !1;
          }
        }
      },
      69538: function (e, t, n) {
        "use strict";
        n.d(t, {
          P: function () {
            return i;
          },
        });
        var r = n(28087);
        function i(e) {
          let t = Object.create(null),
            n = e.getSchema();
          return {
            ScalarTypeDefinition: i,
            ObjectTypeDefinition: i,
            InterfaceTypeDefinition: i,
            UnionTypeDefinition: i,
            EnumTypeDefinition: i,
            InputObjectTypeDefinition: i,
          };
          function i(i) {
            let o = i.name.value;
            if (null != n && n.getType(o)) {
              e.reportError(
                new r.__(
                  `Type "${o}" already exists in the schema. It cannot also be defined in this type definition.`,
                  { nodes: i.name }
                )
              );
              return;
            }
            return (
              t[o]
                ? e.reportError(
                    new r.__(`There can be only one type named "${o}".`, {
                      nodes: [t[o], i.name],
                    })
                  )
                : (t[o] = i.name),
              !1
            );
          }
        }
      },
      1564: function (e, t, n) {
        "use strict";
        n.d(t, {
          H: function () {
            return o;
          },
        });
        var r = n(3231),
          i = n(28087);
        function o(e) {
          return {
            OperationDefinition(t) {
              var n;
              let o =
                  null !== (n = t.variableDefinitions) && void 0 !== n ? n : [],
                a = (0, r.v)(o, (e) => e.variable.name.value);
              for (let [t, n] of a)
                n.length > 1 &&
                  e.reportError(
                    new i.__(`There can be only one variable named "$${t}".`, {
                      nodes: n.map((e) => e.variable.name),
                    })
                  );
            },
          };
        }
      },
      19831: function (e, t, n) {
        "use strict";
        n.d(t, {
          j: function () {
            return c;
          },
        });
        var r = n(53177),
          i = n(25821),
          o = n(73498),
          a = n(3294),
          s = n(28087),
          u = n(16918),
          l = n(4454);
        function c(e) {
          return {
            ListValue(t) {
              let n = (0, l.tf)(e.getParentInputType());
              if (!(0, l.HG)(n)) return p(e, t), !1;
            },
            ObjectValue(t) {
              let n = (0, l.xC)(e.getInputType());
              if (!(0, l.hL)(n)) return p(e, t), !1;
              let r = (0, o.P)(t.fields, (e) => e.name.value);
              for (let o of Object.values(n.getFields())) {
                let a = r[o.name];
                if (!a && (0, l.Wd)(o)) {
                  let r = (0, i.X)(o.type);
                  e.reportError(
                    new s.__(
                      `Field "${n.name}.${o.name}" of required type "${r}" was not provided.`,
                      { nodes: t }
                    )
                  );
                }
              }
            },
            ObjectField(t) {
              let n = (0, l.xC)(e.getParentInputType()),
                i = e.getInputType();
              if (!i && (0, l.hL)(n)) {
                let i = (0, a.D)(t.name.value, Object.keys(n.getFields()));
                e.reportError(
                  new s.__(
                    `Field "${t.name.value}" is not defined by type "${n.name}".` +
                      (0, r.l)(i),
                    { nodes: t }
                  )
                );
              }
            },
            NullValue(t) {
              let n = e.getInputType();
              (0, l.zM)(n) &&
                e.reportError(
                  new s.__(
                    `Expected value of type "${(0, i.X)(n)}", found ${(0,
                    u.print)(t)}.`,
                    { nodes: t }
                  )
                );
            },
            EnumValue: (t) => p(e, t),
            IntValue: (t) => p(e, t),
            FloatValue: (t) => p(e, t),
            StringValue: (t) => p(e, t),
            BooleanValue: (t) => p(e, t),
          };
        }
        function p(e, t) {
          let n = e.getInputType();
          if (!n) return;
          let r = (0, l.xC)(n);
          if (!(0, l.UT)(r)) {
            let r = (0, i.X)(n);
            e.reportError(
              new s.__(
                `Expected value of type "${r}", found ${(0, u.print)(t)}.`,
                { nodes: t }
              )
            );
            return;
          }
          try {
            let o = r.parseLiteral(t, void 0);
            if (void 0 === o) {
              let r = (0, i.X)(n);
              e.reportError(
                new s.__(
                  `Expected value of type "${r}", found ${(0, u.print)(t)}.`,
                  { nodes: t }
                )
              );
            }
          } catch (o) {
            let r = (0, i.X)(n);
            o instanceof s.__
              ? e.reportError(o)
              : e.reportError(
                  new s.__(
                    `Expected value of type "${r}", found ${(0, u.print)(
                      t
                    )}; ` + o.message,
                    { nodes: t, originalError: o }
                  )
                );
          }
        }
      },
      45972: function (e, t, n) {
        "use strict";
        n.d(t, {
          I: function () {
            return s;
          },
        });
        var r = n(28087),
          i = n(16918),
          o = n(4454),
          a = n(30077);
        function s(e) {
          return {
            VariableDefinition(t) {
              let n = (0, a._)(e.getSchema(), t.type);
              if (void 0 !== n && !(0, o.j$)(n)) {
                let n = t.variable.name.value,
                  o = (0, i.print)(t.type);
                e.reportError(
                  new r.__(
                    `Variable "$${n}" cannot be non-input type "${o}".`,
                    { nodes: t.type }
                  )
                );
              }
            },
          };
        }
      },
      9701: function (e, t, n) {
        "use strict";
        n.d(t, {
          w: function () {
            return l;
          },
        });
        var r = n(25821),
          i = n(28087),
          o = n(97359),
          a = n(4454),
          s = n(90316),
          u = n(30077);
        function l(e) {
          let t = Object.create(null);
          return {
            OperationDefinition: {
              enter() {
                t = Object.create(null);
              },
              leave(n) {
                let l = e.getRecursiveVariableUsages(n);
                for (let { node: n, type: c, defaultValue: p } of l) {
                  let l = n.name.value,
                    f = t[l];
                  if (f && c) {
                    let t = e.getSchema(),
                      d = (0, u._)(t, f.type);
                    if (
                      d &&
                      !(function (e, t, n, r, i) {
                        if ((0, a.zM)(r) && !(0, a.zM)(t)) {
                          let a = null != n && n.kind !== o.h.NULL;
                          if (!a && !(void 0 !== i)) return !1;
                          let u = r.ofType;
                          return (0, s.uJ)(e, t, u);
                        }
                        return (0, s.uJ)(e, t, r);
                      })(t, d, f.defaultValue, c, p)
                    ) {
                      let t = (0, r.X)(d),
                        o = (0, r.X)(c);
                      e.reportError(
                        new i.__(
                          `Variable "$${l}" of type "${t}" used in position expecting type "${o}".`,
                          { nodes: [f, n] }
                        )
                      );
                    }
                  }
                }
              },
            },
            VariableDefinition(e) {
              t[e.variable.name.value] = e;
            },
          };
        }
      },
      15394: function (e, t, n) {
        "use strict";
        n.d(t, {
          r: function () {
            return a;
          },
        });
        var r = n(29551),
          i = n(28087),
          o = n(4454);
        function a(e) {
          return {
            Field(t) {
              let n = e.getFieldDef(),
                o = null == n ? void 0 : n.deprecationReason;
              if (n && null != o) {
                let a = e.getParentType();
                null != a || (0, r.k)(!1),
                  e.reportError(
                    new i.__(
                      `The field ${a.name}.${n.name} is deprecated. ${o}`,
                      { nodes: t }
                    )
                  );
              }
            },
            Argument(t) {
              let n = e.getArgument(),
                o = null == n ? void 0 : n.deprecationReason;
              if (n && null != o) {
                let a = e.getDirective();
                if (null != a)
                  e.reportError(
                    new i.__(
                      `Directive "@${a.name}" argument "${n.name}" is deprecated. ${o}`,
                      { nodes: t }
                    )
                  );
                else {
                  let a = e.getParentType(),
                    s = e.getFieldDef();
                  (null != a && null != s) || (0, r.k)(!1),
                    e.reportError(
                      new i.__(
                        `Field "${a.name}.${s.name}" argument "${n.name}" is deprecated. ${o}`,
                        { nodes: t }
                      )
                    );
                }
              }
            },
            ObjectField(t) {
              let n = (0, o.xC)(e.getParentInputType());
              if ((0, o.hL)(n)) {
                let r = n.getFields()[t.name.value],
                  o = null == r ? void 0 : r.deprecationReason;
                null != o &&
                  e.reportError(
                    new i.__(
                      `The input field ${n.name}.${r.name} is deprecated. ${o}`,
                      { nodes: t }
                    )
                  );
              }
            },
            EnumValue(t) {
              let n = e.getEnumValue(),
                a = null == n ? void 0 : n.deprecationReason;
              if (n && null != a) {
                let s = (0, o.xC)(e.getInputType());
                null != s || (0, r.k)(!1),
                  e.reportError(
                    new i.__(
                      `The enum value "${s.name}.${n.name}" is deprecated. ${a}`,
                      { nodes: t }
                    )
                  );
              }
            },
          };
        }
      },
      24196: function (e, t, n) {
        "use strict";
        n.d(t, {
          M: function () {
            return U;
          },
          i: function () {
            return x;
          },
        });
        var r = n(88081),
          i = n(48741),
          o = n(77143),
          a = n(47815),
          s = n(84873),
          u = n(5311),
          l = n(25580),
          c = n(27898),
          p = n(52877),
          f = n(91422),
          d = n(14790),
          h = n(81294),
          m = n(72283),
          y = n(54203),
          v = n(63259),
          T = n(34800),
          g = n(61967),
          _ = n(41954),
          E = n(10423),
          b = n(12337),
          N = n(42266),
          I = n(53274),
          w = n(96300),
          S = n(93201),
          O = n(22618),
          $ = n(45591),
          L = n(92767),
          A = n(82621),
          k = n(77990),
          F = n(69538),
          D = n(1564),
          M = n(19831),
          R = n(45972),
          j = n(9701);
        let x = Object.freeze([
            r.i,
            A.H,
            c.F,
            E.Z,
            l.I,
            o.T,
            R.I,
            _.O,
            i.A,
            $.N,
            u.a,
            h.J,
            v.a,
            f.H,
            D.H,
            d.$,
            m.p,
            s.J,
            w.k,
            a.e,
            N.L,
            M.j,
            g.s,
            j.w,
            y.y,
            L.P,
          ]),
          U = Object.freeze([
            p.t,
            k.q,
            F.P,
            S.L,
            O.y,
            b.L,
            I.o,
            l.I,
            s.J,
            w.k,
            T.g,
            a.o,
            N.L,
            L.P,
            g.c,
          ]);
      },
      24635: function (e, t, n) {
        "use strict";
        n.d(t, {
          ED: function () {
            return d;
          },
          Gu: function () {
            return c;
          },
          zo: function () {
            return f;
          },
        });
        var r = n(37826),
          i = n(28087),
          o = n(77304),
          a = n(19655),
          s = n(22676),
          u = n(24196),
          l = n(32734);
        function c(e, t, n = u.i, c, p = new s.a(e)) {
          var f;
          let d =
            null !== (f = null == c ? void 0 : c.maxErrors) && void 0 !== f
              ? f
              : 100;
          t || (0, r.a)(!1, "Must provide document."), (0, a.J)(e);
          let h = Object.freeze({}),
            m = [],
            y = new l._t(e, t, p, (e) => {
              if (m.length >= d)
                throw (
                  (m.push(
                    new i.__(
                      "Too many validation errors, error limit reached. Validation aborted."
                    )
                  ),
                  h)
                );
              m.push(e);
            }),
            v = (0, o.j1)(n.map((e) => e(y)));
          try {
            (0, o.Vn)(t, (0, s.y)(p, v));
          } catch (e) {
            if (e !== h) throw e;
          }
          return m;
        }
        function p(e, t, n = u.M) {
          let r = [],
            i = new l.yv(e, t, (e) => {
              r.push(e);
            }),
            a = n.map((e) => e(i));
          return (0, o.Vn)(e, (0, o.j1)(a)), r;
        }
        function f(e) {
          let t = p(e);
          if (0 !== t.length) throw Error(t.map((e) => e.message).join("\n\n"));
        }
        function d(e, t) {
          let n = p(e, t);
          if (0 !== n.length) throw Error(n.map((e) => e.message).join("\n\n"));
        }
      },
    },
  ]);
