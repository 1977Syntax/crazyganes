!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "0b7ef770-c7f1-4018-8039-f5584004a8be"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-0b7ef770-c7f1-4018-8039-f5584004a8be"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [76287],
    {
      56774: function (e, t, i) {
        "use strict";
        i.d(t, {
          MM: function () {
            return o;
          },
          aL: function () {
            return a;
          },
          oZ: function () {
            return r;
          },
        });
        var n = i(90948),
          s = i(9512);
        let o = (0, n.ZP)("div", {
            shouldForwardProp: (e) =>
              "contentVisibility" !== e &&
              "containIntrinsicSize" !== e &&
              "isResponsive" !== e &&
              "sx" !== e,
          })((e) => {
            let {
              contentVisibility: t,
              containIntrinsicSize: i,
              isResponsive: n,
              theme: { spacing: s, breakpoints: o, dimensions: r },
            } = e;
            return {
              display: "flex",
              flexFlow: "row wrap",
              boxSizing: "border-box",
              contentVisibility: t || "visible",
              contain: "auto" === t ? "layout paint" : void 0,
              containIntrinsicSize: void 0 !== i ? `${i}px` : void 0,
              marginTop: s(-0.5),
              marginLeft: s(-0.5),
              padding: 0,
              width: `calc(100% + ${s()})`,
              "@media only screen and (max-width: 959px)": {
                justifyContent: "center",
                paddingLeft: "inherit",
              },
              [o.down("md")]: {
                paddingRight: 0,
                paddingLeft: 0,
                marginLeft: 0,
                width: "100%",
              },
              [o.up("gp_x9")]: n
                ? void 0
                : {
                    marginTop: `calc(2px + ${s(-1)})`,
                    marginLeft: -6,
                    width: `calc(100% + ${s(1.5)})`,
                  },
              [o.only("xs")]: {
                containIntrinsicSize: void 0 !== i ? "360px" : void 0,
              },
              "& .skeleton": {
                margin: s(0.5),
                [o.up("gp_x9")]: { margin: 6 },
                ...(n && {
                  height: "0 !important",
                  paddingTop: `calc(${r.gameThumb.height} / ${
                    r.gameThumb.width
                  } * (100% - ${s(0.5)})) !important`,
                }),
              },
              ...(n && {
                display: "grid",
                width: "100%",
                columnGap: s(0.75),
                rowGap: s(0.75),
                margin: 0,
              }),
            };
          }),
          r = (0, n.ZP)(s.Z)({ padding: 0 }),
          a = (0, n.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "grid",
              height: "100%",
              width: "100%",
              gridTemplateColumns: "repeat(2, 1fr)",
              gridTemplateRows: "repeat(2, 1fr)",
              gridGap: t(0.5, 0.5),
              gridAutoFlow: "column",
            };
          });
      },
      71890: function (e, t, i) {
        "use strict";
        i.d(t, {
          _: function () {
            return v;
          },
          Z: function () {
            return T;
          },
        });
        var n = i(85893),
          s = i(67294),
          o = i(17836),
          r = i(90512),
          a = i(95914);
        let l = s.memo((e) =>
          (0, n.jsx)(a.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, n.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M4.18941 2.54556C3.84719 2.11208 3.21836 2.0381 2.78488 2.38032C2.3514 2.72254 2.27742 3.35137 2.61964 3.78485L16.3804 21.2151C16.7226 21.6486 17.3514 21.7225 17.7849 21.3803C18.2184 21.0381 18.2923 20.4093 17.9501 19.9758L16 17.5056C16 17.5037 16 17.5019 16 17.5L16 15.618L19.1056 17.1708C20.4354 17.8357 22 16.8687 22 15.382V8.61803C22 7.13127 20.4354 6.16427 19.1056 6.82917L16 8.38196V7.99999C16 6.34314 14.6569 4.99999 13 4.99999H6.12712L4.18941 2.54556ZM7.70607 6.99999L14 14.9723V14.02C13.9997 14.0062 13.9997 13.9923 14 13.9784L14 10.0216C13.9997 10.0077 13.9997 9.99379 14 9.97991L14 7.99999C14 7.44771 13.5523 6.99999 13 6.99999H7.70607ZM16 13.382L16 10.618L20 8.61803L20 15.382L16 13.382ZM4 8.49999C4 7.94771 3.55228 7.49999 3 7.49999C2.44772 7.49999 2 7.94771 2 8.49999V16C2 17.6568 3.34315 19 5 19H10.5C11.0523 19 11.5 18.5523 11.5 18C11.5 17.4477 11.0523 17 10.5 17H5C4.44772 17 4 16.5523 4 16V8.49999Z",
            }),
          })
        );
        var u = i(36060),
          d = i(55176),
          m = i.n(d);
        let c = (e) => {
          let { game: t, width: i, className: s } = e,
            a = (0, u.Z)(t, { width: i }, !1);
          return a
            ? (0, n.jsx)("div", {
                className: (0, r.Z)(m().gameThumbVideo, s),
                children: (0, n.jsx)("video", {
                  loop: !0,
                  autoPlay: !0,
                  preload: "none",
                  muted: !0,
                  disableRemotePlayback: !0,
                  children: (0, n.jsx)("source", { src: a, type: "video/mp4" }),
                }),
              })
            : (0, n.jsxs)("div", {
                className: m().gameThumbVideo,
                children: [
                  (0, n.jsx)(o.IF, {
                    game: t,
                    useDprSrcset: !0,
                    greyedOut: !0,
                    width: i,
                  }),
                  (0, n.jsx)("div", {
                    className: m().greyedOutOverlay,
                    children: (0, n.jsx)(l, {}),
                  }),
                ],
              });
        };
        var h = i(88531),
          g = i(20702),
          b = i(72552),
          _ = i(1982),
          p = i(37899),
          y = i(88061);
        let C = ["UNAVAILABLE", "ARCHIVED"],
          v = 273,
          f = s.memo((e) => {
            let {
                game: t,
                addViewedGames: i,
                eagerLoading: a,
                bottomLabel: l,
                imgFetchPriority: u,
                className: d,
                onClickAction: f,
                isResponsiveGrid: T,
                isResponsive: x,
                icon: w,
                iconFn: G,
                hideTitle: Z,
                thumbClassName: j,
                enableInstantJoin: z,
                imgDPRSize: L,
                children: B,
              } = e,
              [M, V] = s.useState(!1),
              k = s.useRef(null),
              S = s.useRef(null),
              I = s.useContext(_.t),
              { services: R } = s.useContext(p.Z);
            s.useEffect(() => {
              let e = S.current;
              return (
                e &&
                  g.Z.get().observe(S.current, () => {
                    g.Z.get().unobserve(S.current), i && i(t.id, (0, b.Z)(I));
                  }),
                () => {
                  g.Z.get().unobserve(e),
                    k.current && window.clearTimeout(k.current);
                }
              );
            }, [i, t.id, I]);
            let P = (e) => {
                e.preventDefault(), e.stopPropagation(), G && G(t.slug);
              },
              H = () => N() && !M,
              N = () => void 0 !== t.status && C.includes(t.status),
              O = () => {
                M ||
                  (V(!0),
                  (k.current = window.setTimeout(() => {
                    A();
                  }, 500)));
              },
              E = () => {
                V(!1),
                  k.current && (clearTimeout(k.current), (k.current = null));
              },
              A = s.useCallback(() => {
                R.gameService.prefetchGameData(t, "desktop");
              }, [R, t]),
              D = L || v;
            return (0, n.jsx)(y.Z, {
              slug: t.slug,
              isKids: t.isKids,
              className: (0, r.Z)(
                d,
                m().gameThumbLinkDesktop,
                T && m().isResponsiveGrid,
                x && m().isResponsive,
                d,
                "game-thumb-test-class"
              ),
              isInstantJoin: z && !!t?.multiplayerOptions?.supportsInstantJoin,
              onClick: f,
              onMouseOver: O,
              onMouseLeave: E,
              ref: S,
              children: (0, n.jsxs)(n.Fragment, {
                children: [
                  (0, n.jsx)(h.Z, {
                    videoPlaying: M,
                    gameThumbLabels: t.gameThumbLabels,
                  }),
                  w
                    ? (0, n.jsx)("div", {
                        className: m().closeBtnContainer,
                        onClick: P,
                        children: w,
                      })
                    : null,
                  !Z &&
                    (0, n.jsx)("div", {
                      className: (0, r.Z)(
                        m().gameThumbTitleContainer,
                        "gameThumbTitleContainer",
                        H() && m().greyedOut
                      ),
                      children: t.name,
                    }),
                  l &&
                    (0, n.jsx)("div", {
                      className: (0, r.Z)(
                        m().bottomLabelContainer,
                        M && m().videoPlaying
                      ),
                      children: l,
                    }),
                  M && (0, n.jsx)(c, { game: t, width: D, className: j }),
                  M &&
                    !Z &&
                    (0, n.jsx)("div", { className: m().gradientVignette }),
                  N() && !M ? (0, n.jsx)(o.v4, {}) : null,
                  (0, n.jsx)(o.IF, {
                    game: t,
                    greyedOut: H(),
                    eagerLoading: a,
                    useDprSrcset: !0,
                    width: D,
                    imgFetchPriority: u,
                    className: j,
                  }),
                  B,
                ],
              }),
            });
          });
        var T = f;
      },
      17836: function (e, t, i) {
        "use strict";
        i.d(t, {
          $r: function () {
            return _;
          },
          pm: function () {
            return p;
          },
          IF: function () {
            return g;
          },
          v4: function () {
            return y;
          },
        });
        var n = i(85893),
          s = i(67294),
          o = i(94745),
          r = i(75007),
          a = i(95914);
        let l = s.memo((e) =>
            (0, n.jsx)(a.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: (0, n.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M18 5H6C4.89543 5 4 5.89543 4 7V12C4 13.1046 4.89543 14 6 14H12H18C19.1046 14 20 13.1046 20 12V7C20 5.89543 19.1046 5 18 5ZM18 16H13V19H15C15.5523 19 16 19.4477 16 20C16 20.5523 15.5523 21 15 21H12H9C8.44772 21 8 20.5523 8 20C8 19.4477 8.44772 19 9 19H11V16H6C3.79086 16 2 14.2091 2 12V7C2 4.79086 3.79086 3 6 3H18C20.2091 3 22 4.79086 22 7V12C22 14.2091 20.2091 16 18 16Z",
              }),
            })
          ),
          u = s.memo((e) =>
            (0, n.jsxs)(a.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: [
                (0, n.jsx)("path", {
                  fillRule: "evenodd",
                  clipRule: "evenodd",
                  d: "M12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z",
                }),
                (0, n.jsx)("path", {
                  fillRule: "evenodd",
                  clipRule: "evenodd",
                  d: "M8.29289 8.29289C8.68342 7.90237 9.31658 7.90237 9.70711 8.29289L12 10.5858L14.2929 8.29289C14.6834 7.90237 15.3166 7.90237 15.7071 8.29289C16.0976 8.68342 16.0976 9.31658 15.7071 9.70711L13.4142 12L15.7071 14.2929C16.0976 14.6834 16.0976 15.3166 15.7071 15.7071C15.3166 16.0976 14.6834 16.0976 14.2929 15.7071L12 13.4142L9.70711 15.7071C9.31658 16.0976 8.68342 16.0976 8.29289 15.7071C7.90237 15.3166 7.90237 14.6834 8.29289 14.2929L10.5858 12L8.29289 9.70711C7.90237 9.31658 7.90237 8.68342 8.29289 8.29289Z",
                }),
              ],
            })
          ),
          d = s.memo((e) =>
            (0, n.jsx)(a.Z, {
              ...e,
              viewBox: "0 0 24 24",
              children: (0, n.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M5 5C5 3.34315 6.34315 2 8 2H16C17.6569 2 19 3.34315 19 5V19C19 20.6569 17.6569 22 16 22H8C6.34315 22 5 20.6569 5 19V5ZM8 4C7.44772 4 7 4.44772 7 5V19C7 19.5523 7.44772 20 8 20H16C16.5523 20 17 19.5523 17 19V5C17 4.44772 16.5523 4 16 4H8ZM11 18C11 17.4477 11.4477 17 12 17H12.01C12.5623 17 13.01 17.4477 13.01 18C13.01 18.5523 12.5623 19 12.01 19H12C11.4477 19 11 18.5523 11 18Z",
              }),
            })
          );
        var m = i(90512),
          c = i(55176),
          h = i.n(c);
        let g = (e) => {
            let {
                game: t,
                greyedOut: i,
                eagerLoading: s,
                height: o,
                width: a,
                imgResponsiveSizes: l,
                imgFetchPriority: u,
                useDprSrcset: d,
                onClick: c,
                className: g,
              } = e,
              b = t.cover,
              _ = {
                quality: 85,
                width: a || void 0,
                height: o || void 0,
                fit: "crop",
                saturation: i ? 0 : void 0,
              },
              p = (0, r.ZP)(b, _),
              y = d ? (0, r.LI)(b, _) : l ? (0, r.Dv)(b, _, l) : void 0,
              C = l ? (0, r.qd)(l) : void 0;
            return (0, n.jsx)("img", {
              className: (0, m.Z)(h().gameThumbImage, i && h().greyedOut, g),
              loading: s ? "eager" : "lazy",
              src: p,
              alt: t.name,
              width: a,
              height: o,
              srcSet: y,
              sizes: C,
              ...(u && { fetchpriority: u }),
              onClick: c,
            });
          },
          b = (e) => {
            let { trlId: t, icon: i } = e;
            return (0, n.jsxs)("div", {
              className: h().greyedOutOverlay,
              children: [
                i,
                (0, n.jsx)("div", {
                  className: h().labelContainer,
                  children: (0, n.jsx)(o.cC, { id: t }),
                }),
              ],
            });
          },
          _ = () =>
            (0, n.jsx)(b, {
              icon: (0, n.jsx)(l, {}),
              trlId: "common.computerOnly",
            }),
          p = () =>
            (0, n.jsx)(b, {
              icon: (0, n.jsx)(d, {}),
              trlId: "common.deviceNotSupported",
            }),
          y = () =>
            (0, n.jsx)(b, {
              icon: (0, n.jsx)(u, {}),
              trlId: "common.notAvailable",
            });
      },
      9512: function (e, t, i) {
        "use strict";
        i.d(t, {
          Z: function () {
            return x;
          },
        });
        var n = i(85893),
          s = i(67294),
          o = i(81792),
          r = i(71890),
          a = i(98718),
          l = i(17836),
          u = i(88531),
          d = i(20702),
          m = i(72552),
          c = i(1982),
          h = i(95129),
          g = i(88061),
          b = i(90512),
          _ = i(55176),
          p = i.n(_);
        let y = ["UNAVAILABLE", "ARCHIVED"],
          C = s.memo((e) => {
            let {
                game: t,
                eagerLoading: i,
                bottomLabel: o,
                isResponsive: r,
                isResponsiveGrid: a,
                className: _,
                onClickAction: C,
                imgFetchPriority: v,
                icon: f,
                iconFn: T,
                addViewedGames: x,
                hideTitle: w,
                thumbClassName: G,
                enableInstantJoin: Z,
                children: j,
              } = e,
              z = s.useRef(null),
              L = s.useContext(c.t),
              B = s.useContext(h.Z);
            s.useEffect(() => {
              let e = z.current;
              return (
                e &&
                  d.Z.get().observe(z.current, () => {
                    d.Z.get().unobserve(z.current), x && x(t.id, (0, m.Z)(L));
                  }),
                () => {
                  d.Z.get().unobserve(e);
                }
              );
            }, [x, t.id, L]);
            let M = (e) => {
                e.preventDefault(), e.stopPropagation(), T && T(t.slug);
              },
              V = () => void 0 !== t.status && y.includes(t.status),
              k = () => {
                let e = t.androidFriendly && !t.iosFriendly,
                  i = t.iosFriendly && !t.androidFriendly;
                return (B.isAndroid && i) || ((B.isIos || B.isIPad) && e);
              },
              S = V()
                ? (0, n.jsx)(l.v4, {})
                : t.mobileFriendly
                ? k()
                  ? (0, n.jsx)(l.pm, {})
                  : null
                : (0, n.jsx)(l.$r, {}),
              I = [_ || "", t.mobileFriendly ? "mobile-friendly" : ""]
                .filter((e) => e.length > 0)
                .join(" ");
            return (0, n.jsx)("div", {
              className: (0, b.Z)(
                p().mobileGameGridThumbContainer,
                r && p().isResponsive,
                a && p().isResponsiveGrid,
                _
              ),
              children: (0, n.jsx)(g.Z, {
                className: (0, b.Z)(
                  I,
                  p().gameThumbLinkMobile,
                  "game-thumb-test-class"
                ),
                slug: t.slug,
                isKids: t.isKids,
                onClick: C,
                ref: z,
                isInstantJoin:
                  Z && !!t?.multiplayerOptions?.supportsInstantJoin,
                children: (0, n.jsxs)(n.Fragment, {
                  children: [
                    !S &&
                      (0, n.jsx)(u.Z, { gameThumbLabels: t.gameThumbLabels }),
                    !w &&
                      (0, n.jsx)("div", {
                        className: (0, b.Z)(
                          p().gameThumbTitleContainer,
                          "gameThumbTitleContainer"
                        ),
                        children: t.name,
                      }),
                    f
                      ? (0, n.jsx)("div", {
                          className: p().closeBtnContainer,
                          onClick: M,
                          children: f,
                        })
                      : null,
                    S,
                    o &&
                      (0, n.jsx)("div", {
                        className: p().bottomLabelContainer,
                        children: o,
                      }),
                    (0, n.jsx)(l.IF, {
                      game: t,
                      useDprSrcset: !0,
                      greyedOut: !t.mobileFriendly || k() || V(),
                      eagerLoading: i,
                      width: 205,
                      imgFetchPriority: v,
                      className: G,
                    }),
                    j,
                  ],
                }),
              }),
            });
          });
        var v = i(94984),
          f = i(77655);
        let T = (e) => {
          let t = s.useContext(f.Y).addViewedGames;
          return (0, n.jsxs)(v.H, {
            newClickOrigin: e.game.origin,
            children: [
              (0, n.jsx)(o.Z, {
                children: (0, n.jsx)(r.Z, { addViewedGames: t, ...e }),
              }),
              (0, n.jsx)(a.Z, {
                children: (0, n.jsx)(C, { addViewedGames: t, ...e }),
              }),
            ],
          });
        };
        var x = T;
      },
      88531: function (e, t, i) {
        "use strict";
        var n = i(85893);
        i(67294);
        var s = i(7224),
          o = i(82260),
          r = i(94563),
          a = i(21423);
        let l = ["updated", "new", "hot", "top-rated"],
          u = (e) => {
            let { videoPlaying: t, gameThumbLabels: i, top: u } = e;
            if (!i) return null;
            let d = (e) => {
              let i = {
                position: "absolute",
                zIndex: 4,
                left: -5,
                top: void 0 !== u ? u : -4,
                opacity: t ? 0 : 1,
                transition: "opacity 0.2s linear",
              };
              switch (e) {
                case "hot":
                  return (0, n.jsx)(s.ZP, { customStyle: { ...i } });
                case "new":
                  return (0, n.jsx)(o.ZP, { customStyle: { ...i } });
                case "top-rated":
                  return (0, n.jsx)(r.ZP, { customStyle: { ...i } });
                case "updated":
                  return (0, n.jsx)(a.ZP, { customStyle: { ...i } });
                default:
                  return null;
              }
            };
            for (let e of l) if (i.includes(e)) return d(e);
            return null;
          };
        t.Z = u;
      },
      4388: function (e, t, i) {
        "use strict";
        var n = i(85893),
          s = i(67294),
          o = i(95914);
        let r = s.memo((e) =>
          (0, n.jsx)(o.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, n.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M4 3C4.55228 3 5 3.44772 5 4V6.34298C6.64938 4.30446 9.17168 3 12 3C16.5903 3 20.3767 6.43564 20.9304 10.8763C20.9988 11.4243 20.6099 11.924 20.0618 11.9923C19.5138 12.0607 19.0141 11.6718 18.9458 11.1237C18.5153 7.67174 15.5689 5 12 5C9.62231 5 7.51998 6.18566 6.25442 8H9C9.55228 8 10 8.44772 10 9C10 9.55228 9.55228 10 9 10H4C3.44772 10 3 9.55228 3 9V4C3 3.44772 3.44772 3 4 3ZM3.93815 12.0077C4.48619 11.9393 4.98587 12.3282 5.05421 12.8763C5.48467 16.3283 8.43109 19 12 19C14.3777 19 16.48 17.8143 17.7456 16H15C14.4477 16 14 15.5523 14 15C14 14.4477 14.4477 14 15 14H20C20.5523 14 21 14.4477 21 15V20C21 20.5523 20.5523 21 20 21C19.4477 21 19 20.5523 19 20V17.657C17.3506 19.6955 14.8283 21 12 21C7.40967 21 3.62332 17.5644 3.06958 13.1237C3.00124 12.5757 3.39011 12.076 3.93815 12.0077Z",
            }),
          })
        );
        t.Z = r;
      },
      88061: function (e, t, i) {
        "use strict";
        i.d(t, {
          Z: function () {
            return h;
          },
        });
        var n = i(85893),
          s = i(67294),
          o = i(83514),
          r = i(63306),
          a = i(1982),
          l = i(72552),
          u = i(2978),
          d = i(46313);
        let m = (e, t, i, n) => {
            let [s, o] = e.split("?"),
              r = new URLSearchParams(o);
            return (
              i === n ? r.delete(t) : r.set(t, i),
              r.sort(),
              s + (r.toString() ? "?" + r.toString() : "")
            );
          },
          c = s.forwardRef((e, t) => {
            let { routeHelper: i } = s.useContext(r.Z),
              { pageUrlHelper: c } = s.useContext(o.t),
              {
                slug: h,
                isKids: g,
                className: b,
                isInstantJoin: _,
                children: p,
                ...y
              } = e,
              C = s.useContext(a.t);
            if (g) {
              let e = {
                href: `${d.Z.Instance.data.kids}/game/${h}`,
                rel: "external nofollow",
                target: "_blank",
              };
              return (0, n.jsx)("a", {
                ...e,
                className: b,
                ...y,
                ref: t,
                children: p,
              });
            }
            let v = (0, l.Z)(C),
              f = i.gamePageLink(h, { origin: v });
            _ &&
              (f = (function (e) {
                let { href: t, as: i } = e;
                return { href: (t = m(t, "instantJoin", "true")), as: i };
              })(f));
            let T = c.isGamePage() && c.getGameParams().game;
            return (0, n.jsx)(u.Z, {
              ...f,
              className: b,
              ...y,
              shallow: T === h,
              ref: t,
              prefetch: !0,
              children: p,
            });
          });
        var h = c;
      },
      81792: function (e, t, i) {
        "use strict";
        var n = i(85893),
          s = i(67294),
          o = i(42257);
        let r = (e) => {
          let { children: t } = e,
            i = s.useContext(o.Z);
          return i.isDesktop ? (0, n.jsx)(n.Fragment, { children: t }) : null;
        };
        t.Z = r;
      },
      98718: function (e, t, i) {
        "use strict";
        var n = i(85893),
          s = i(67294),
          o = i(42257);
        let r = (e) => {
          let { children: t } = e,
            i = s.useContext(o.Z);
          return i.isTablet || i.isMobile
            ? (0, n.jsx)(n.Fragment, { children: t })
            : null;
        };
        t.Z = r;
      },
      20702: function (e, t, i) {
        "use strict";
        i.d(t, {
          Z: function () {
            return o;
          },
        });
        let n = {
            errorMargin: 0.05,
            percentCompensation: 0.2,
            minTimeVisible: 250,
            config: { root: null, rootMargin: "0px", threshold: 0.75 },
          },
          s = null;
        class o {
          static get() {
            return s && s instanceof o ? s : (s = new o(n));
          }
          constructor(e) {
            (this.options = Object.assign({}, n, e)),
              (isNaN(this.options.minTimeVisible) ||
                this.options.minTimeVisible < 0) &&
                (this.options.minTimeVisible = n.minTimeVisible),
              (this.elements = new Map()),
              (this.timeouts = new Map()),
              (this.observer = new IntersectionObserver(
                this.watchElements,
                this.options.config
              )),
              window.addEventListener("focus", this.reportVisibilityStates),
              window.addEventListener(
                "orientationchange",
                this.reportVisibilityStates
              );
          }
          removeEventListeners() {
            window.removeEventListener("focus", this.reportVisibilityStates),
              window.removeEventListener(
                "orientationchange",
                this.reportVisibilityStates
              );
          }
          destroy() {
            return (
              this.elements.clear(),
              this.timeouts.clear(),
              this.observer &&
                "function" == typeof this.observer.disconnect &&
                this.observer.disconnect(),
              this.removeEventListeners(),
              (s = null)
            );
          }
          reportVisibilityStates = () => {
            this.elements.forEach((e, t) => {
              let { visible: i } = e;
              i && this.onVisibilityChange(t, i);
            });
          };
          watchElements = (e) => {
            let t = window.innerHeight || document.documentElement.clientHeight;
            e.filter((e) => e.isIntersecting).forEach((e) => {
              let i = e.target,
                n = this.elements.get(i);
              if (!n) return;
              let s = e.boundingClientRect || i.getBoundingClientRect(),
                o = s.height,
                r = this.isElementHeightSimilarToContainer(o, t)
                  ? this.options.errorMargin
                  : 0.025,
                a = e.intersectionRatio >= (t / o > 1 ? 1 - r : t / o - r);
              if (!a || !n.timeoutSet) {
                if (a)
                  (n.timeoutSet = !0),
                    this.timeouts.set(
                      i,
                      setTimeout(() => {
                        this.onVisibilityChange(i, !0);
                      }, this.options.minTimeVisible)
                    );
                else {
                  let e = this.timeouts.get(i);
                  this.onVisibilityChange(i, !1),
                    clearTimeout(e),
                    this.timeouts.delete(i),
                    (n.timeoutSet = !1);
                }
              }
            });
          };
          isElementHeightSimilarToContainer(e, t) {
            return (
              e >= t - t * this.options.percentCompensation &&
              e <= t + t * this.options.percentCompensation
            );
          }
          observe = (e, t) => {
            if (e && t) {
              this.elements.set(e, {
                callback: t,
                visible: !1,
                entry: e,
                timeoutSet: !1,
              });
              try {
                e && this.observer.observe(e);
              } catch (e) {
                console.log(e);
              }
            }
          };
          unobserve = (e) => {
            e &&
              this.elements.get(e) &&
              (this.observer && this.observer.unobserve(e),
              this.elements.delete(e),
              0 === this.elements.size && this.destroy());
          };
          onVisibilityChange(e, t) {
            if (!e) return;
            let i = this.elements.get(e);
            if (!i) return;
            i.visible = t;
            let { callback: n } = i;
            "function" == typeof n && n(t);
          }
        }
      },
      36060: function (e, t, i) {
        "use strict";
        var n = i(46313);
        let s = (e, t, i) => {
          let { videos: s, video: o } = e,
            { width: r, height: a } = t;
          if (
            (r || a) &&
            s &&
            ((s.sizes && s.sizes.length > 0) ||
              (i && s.portraitSizes && s.portraitSizes.length > 0))
          ) {
            let e = 1;
            window.devicePixelRatio > 1 && (e = window.devicePixelRatio);
            let o = a ? "height" : "width",
              r =
                i && s.portraitSizes && s.portraitSizes.length > 0
                  ? s.portraitSizes
                  : s.sizes,
              l = [...r].sort((e, t) => e[o] - t[o]),
              u = l.find((i) => i[o] >= t[o] * e);
            return u
              ? `${n.Z.Instance.data.videos}${u.location}`
              : `${n.Z.Instance.data.videos}${l[l.length - 1].location}`;
          }
          return o ? `${n.Z.Instance.data.videos}${e.video}` : null;
        };
        t.Z = s;
      },
      55176: function (e) {
        e.exports = {
          czyButton: "GameThumb_czyButton__z1rfp",
          "czyButton--contained--purple":
            "GameThumb_czyButton--contained--purple__SAkzN",
          "czyButton--contained--white":
            "GameThumb_czyButton--contained--white__9sJCG",
          "czyButton--contained--grey":
            "GameThumb_czyButton--contained--grey__rxObx",
          "czyButton--contained--alert":
            "GameThumb_czyButton--contained--alert__z_RHC",
          "czyButton--contained--success":
            "GameThumb_czyButton--contained--success__3XQm2",
          "czyButton--contained--black":
            "GameThumb_czyButton--contained--black__mpt_K",
          "czyButton--contained--green-gradient":
            "GameThumb_czyButton--contained--green-gradient__T_CYd",
          "czyButton--outlined--purple":
            "GameThumb_czyButton--outlined--purple__mBmDg",
          "czyButton--link--purple": "GameThumb_czyButton--link--purple__Yvl95",
          "czyButton--outlined--white":
            "GameThumb_czyButton--outlined--white__tN6U0",
          "czyButton--link--white": "GameThumb_czyButton--link--white__SLX02",
          "czyButton--outlined--grey":
            "GameThumb_czyButton--outlined--grey__IleBR",
          "czyButton--link--grey": "GameThumb_czyButton--link--grey__W7YH8",
          "czyButton--outlined--alert":
            "GameThumb_czyButton--outlined--alert__OEXWe",
          "czyButton--link--alert": "GameThumb_czyButton--link--alert__tnls0",
          "czyButton--outlined--success":
            "GameThumb_czyButton--outlined--success__576Ao",
          "czyButton--link--success":
            "GameThumb_czyButton--link--success__Ku1hh",
          "czyButton--outlined": "GameThumb_czyButton--outlined__d8fMT",
          "czyButton--disabled": "GameThumb_czyButton--disabled__j0RGb",
          "czyButton--height50": "GameThumb_czyButton--height50__oQ101",
          "czyButton--height34": "GameThumb_czyButton--height34__6mZpO",
          "czyButton--fullWidth": "GameThumb_czyButton--fullWidth__cxZVv",
          gameThumbLinkDesktop: "GameThumb_gameThumbLinkDesktop__LB7NJ",
          gameThumbTitleContainer: "GameThumb_gameThumbTitleContainer__4f8BU",
          greyedOut: "GameThumb_greyedOut__zhbIT",
          gameThumbImage: "GameThumb_gameThumbImage__isqyS",
          isResponsive: "GameThumb_isResponsive__9XI8J",
          isResponsiveGrid: "GameThumb_isResponsiveGrid__UYKTD",
          gameThumbLinkMobile: "GameThumb_gameThumbLinkMobile__hBl0_",
          bottomLabelContainer: "GameThumb_bottomLabelContainer___PI1a",
          videoPlaying: "GameThumb_videoPlaying__5PJWw",
          gradientVignette: "GameThumb_gradientVignette__P0JPY",
          closeBtnContainer: "GameThumb_closeBtnContainer__5kI8N",
          mobileGameGridThumbContainer:
            "GameThumb_mobileGameGridThumbContainer__PPPBj",
          greyedOutOverlay: "GameThumb_greyedOutOverlay__0BS4D",
          labelContainer: "GameThumb_labelContainer__eXPQi",
          gameThumbVideo: "GameThumb_gameThumbVideo___pfwm",
          gameThumbAllLink: "GameThumb_gameThumbAllLink__Zs__q",
          gameThumbAllLinkDesktopSearchGrid:
            "GameThumb_gameThumbAllLinkDesktopSearchGrid__zbKs7",
          gameThumbAllLinkMobileSearchGrid:
            "GameThumb_gameThumbAllLinkMobileSearchGrid__VsDXq",
          gameThumbAll: "GameThumb_gameThumbAll__DlMRV",
          gameThumbAllLabel: "GameThumb_gameThumbAllLabel__RGnGl",
        };
      },
    },
  ]);
