!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "bf6633d1-508c-4c11-8390-fb41254e4b3c"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-bf6633d1-508c-4c11-8390-fb41254e4b3c"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [76828],
    {
      10454: function (e, t, n) {
        n.d(t, {
          G: function () {
            return i;
          },
          RR: function () {
            return u;
          },
          Zm: function () {
            return s;
          },
          se: function () {
            return l;
          },
        });
        var r = n(23187),
          a = n(17986),
          o = n(51150);
        function s(e) {
          let t = {};
          try {
            e.forEach((e, n) => {
              "string" == typeof e && (t[n] = e);
            });
          } catch (e) {
            r.X &&
              a.kg.warn(
                "Sentry failed extracting headers from a request object. If you see this, please file an issue."
              );
          }
          return t;
        }
        function u(e) {
          let t = Object.create(null);
          try {
            Object.entries(e).forEach(([e, n]) => {
              "string" == typeof n && (t[e] = n);
            });
          } catch (e) {
            r.X &&
              a.kg.warn(
                "Sentry failed extracting headers from a request object. If you see this, please file an issue."
              );
          }
          return t;
        }
        function l(e) {
          let t = s(e.headers);
          return {
            method: e.method,
            url: e.url,
            query_string: d(e.url),
            headers: t,
          };
        }
        function i(e) {
          let t = e.headers || {},
            n = t.host || "<no host>",
            r = e.socket && e.socket.encrypted ? "https" : "http",
            a = e.url || "",
            s = a.startsWith(r) ? a : `${r}://${n}${a}`,
            l = e.body || void 0,
            i = e.cookies;
          return (0, o.Jr)({
            url: s,
            method: e.method,
            query_string: d(a),
            headers: u(t),
            cookies: i,
            data: l,
          });
        }
        function d(e) {
          if (e)
            try {
              let t = new URL(e, "http://dogs.are.great").search.slice(1);
              return t.length ? t : void 0;
            } catch (e) {
              return;
            }
        }
      },
      93176: function (e, t, n) {
        n.d(t, {
          q: function () {
            return a;
          },
        });
        var r = n(33280);
        function a(e) {
          let t = r.n[Symbol.for("@vercel/request-context")],
            n = t && t.get && t.get() ? t.get() : {};
          n && n.waitUntil && n.waitUntil(e);
        }
      },
      36096: function (e, t, n) {
        n.d(t, {
          X: function () {
            return r;
          },
        });
        let r = !1;
      },
      76828: function (e, t, n) {
        n.d(t, {
          u: function () {
            return l;
          },
        });
        var r = n(26318),
          a = n(10454),
          o = n(39424),
          s = n(93176),
          u = n(87881);
        async function l(e) {
          let { req: t, res: n, err: l } = e,
            i = (n && n.statusCode) || e.statusCode;
          if ((i && i < 500) || !e.pathname) return Promise.resolve();
          (0, r.$e)((e) => {
            if (t) {
              let n = (0, a.G)(t);
              e.setSDKProcessingMetadata({ normalizedRequest: n });
            }
            (0, o.Tb)(l || `_error.js called with falsy error (${l})`, {
              mechanism: {
                type: "instrument",
                handled: !1,
                data: { function: "_error.getInitialProps" },
              },
            });
          }),
            (0, s.q)((0, u.R)());
        }
      },
      87881: function (e, t, n) {
        n.d(t, {
          R: function () {
            return s;
          },
        });
        var r = n(17986),
          a = n(39424),
          o = n(36096);
        async function s() {
          try {
            o.X && r.kg.log("Flushing events..."),
              await (0, a.yl)(2e3),
              o.X && r.kg.log("Done flushing events");
          } catch (e) {
            o.X && r.kg.log("Error while flushing events:\n", e);
          }
        }
      },
    },
  ]);
