!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "4304b6fa-0511-4947-865b-9e56bd503aac"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-4304b6fa-0511-4947-865b-9e56bd503aac"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [84275],
    {
      28087: function (e, t, n) {
        n.d(t, {
          OS: function () {
            return h;
          },
          Z: function () {
            return l;
          },
          __: function () {
            return o;
          },
        });
        var i = n(88495),
          r = n(57867),
          s = n(90850);
        class o extends Error {
          constructor(e, ...t) {
            var n, s, h;
            let {
              nodes: l,
              source: c,
              positions: u,
              path: p,
              originalError: d,
              extensions: T,
            } = (function (e) {
              let t = e[0];
              return null == t || "kind" in t || "length" in t
                ? {
                    nodes: t,
                    source: e[1],
                    positions: e[2],
                    path: e[3],
                    originalError: e[4],
                    extensions: e[5],
                  }
                : t;
            })(t);
            super(e),
              (this.name = "GraphQLError"),
              (this.path = null != p ? p : void 0),
              (this.originalError = null != d ? d : void 0),
              (this.nodes = a(Array.isArray(l) ? l : l ? [l] : void 0));
            let f = a(
              null === (n = this.nodes) || void 0 === n
                ? void 0
                : n.map((e) => e.loc).filter((e) => null != e)
            );
            (this.source =
              null != c
                ? c
                : null == f
                ? void 0
                : null === (s = f[0]) || void 0 === s
                ? void 0
                : s.source),
              (this.positions =
                null != u ? u : null == f ? void 0 : f.map((e) => e.start)),
              (this.locations =
                u && c
                  ? u.map((e) => (0, r.k)(c, e))
                  : null == f
                  ? void 0
                  : f.map((e) => (0, r.k)(e.source, e.start)));
            let E = (0, i.y)(null == d ? void 0 : d.extensions)
              ? null == d
                ? void 0
                : d.extensions
              : void 0;
            (this.extensions =
              null !== (h = null != T ? T : E) && void 0 !== h
                ? h
                : Object.create(null)),
              Object.defineProperties(this, {
                message: { writable: !0, enumerable: !0 },
                name: { enumerable: !1 },
                nodes: { enumerable: !1 },
                source: { enumerable: !1 },
                positions: { enumerable: !1 },
                originalError: { enumerable: !1 },
              }),
              null != d && d.stack
                ? Object.defineProperty(this, "stack", {
                    value: d.stack,
                    writable: !0,
                    configurable: !0,
                  })
                : Error.captureStackTrace
                ? Error.captureStackTrace(this, o)
                : Object.defineProperty(this, "stack", {
                    value: Error().stack,
                    writable: !0,
                    configurable: !0,
                  });
          }
          get [Symbol.toStringTag]() {
            return "GraphQLError";
          }
          toString() {
            let e = this.message;
            if (this.nodes)
              for (let t of this.nodes)
                t.loc && (e += "\n\n" + (0, s.Q)(t.loc));
            else if (this.source && this.locations)
              for (let t of this.locations)
                e += "\n\n" + (0, s.z)(this.source, t);
            return e;
          }
          toJSON() {
            let e = { message: this.message };
            return (
              null != this.locations && (e.locations = this.locations),
              null != this.path && (e.path = this.path),
              null != this.extensions &&
                Object.keys(this.extensions).length > 0 &&
                (e.extensions = this.extensions),
              e
            );
          }
        }
        function a(e) {
          return void 0 === e || 0 === e.length ? void 0 : e;
        }
        function h(e) {
          return e.toString();
        }
        function l(e) {
          return e.toJSON();
        }
      },
      45219: function (e, t, n) {
        n.d(t, {
          h: function () {
            return r;
          },
        });
        var i = n(28087);
        function r(e, t, n) {
          return new i.__(`Syntax Error: ${n}`, { source: e, positions: [t] });
        }
      },
      8306: function (e, t, n) {
        n.d(t, {
          n: function () {
            return r;
          },
        });
        var i = n(25821);
        let r =
          globalThis.process && "production" === globalThis.process.env.NODE_ENV
            ? function (e, t) {
                return e instanceof t;
              }
            : function (e, t) {
                if (e instanceof t) return !0;
                if ("object" == typeof e && null !== e) {
                  var n;
                  let r = t.prototype[Symbol.toStringTag],
                    s =
                      Symbol.toStringTag in e
                        ? e[Symbol.toStringTag]
                        : null === (n = e.constructor) || void 0 === n
                        ? void 0
                        : n.name;
                  if (r === s) {
                    let t = (0, i.X)(e);
                    throw Error(`Cannot use ${r} "${t}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
                  }
                }
                return !1;
              };
      },
      29551: function (e, t, n) {
        n.d(t, {
          k: function () {
            return i;
          },
        });
        function i(e, t) {
          let n = Boolean(e);
          if (!n)
            throw Error(null != t ? t : "Unexpected invariant triggered.");
        }
      },
      88495: function (e, t, n) {
        n.d(t, {
          y: function () {
            return i;
          },
        });
        function i(e) {
          return "object" == typeof e && null !== e;
        }
      },
      99878: function (e, t, n) {
        var i, r;
        n.d(t, {
          B: function () {
            return i;
          },
        }),
          ((r = i || (i = {})).QUERY = "QUERY"),
          (r.MUTATION = "MUTATION"),
          (r.SUBSCRIPTION = "SUBSCRIPTION"),
          (r.FIELD = "FIELD"),
          (r.FRAGMENT_DEFINITION = "FRAGMENT_DEFINITION"),
          (r.FRAGMENT_SPREAD = "FRAGMENT_SPREAD"),
          (r.INLINE_FRAGMENT = "INLINE_FRAGMENT"),
          (r.VARIABLE_DEFINITION = "VARIABLE_DEFINITION"),
          (r.SCHEMA = "SCHEMA"),
          (r.SCALAR = "SCALAR"),
          (r.OBJECT = "OBJECT"),
          (r.FIELD_DEFINITION = "FIELD_DEFINITION"),
          (r.ARGUMENT_DEFINITION = "ARGUMENT_DEFINITION"),
          (r.INTERFACE = "INTERFACE"),
          (r.UNION = "UNION"),
          (r.ENUM = "ENUM"),
          (r.ENUM_VALUE = "ENUM_VALUE"),
          (r.INPUT_OBJECT = "INPUT_OBJECT"),
          (r.INPUT_FIELD_DEFINITION = "INPUT_FIELD_DEFINITION");
      },
      92105: function (e, t, n) {
        n.d(t, {
          h: function () {
            return h;
          },
          u: function () {
            return l;
          },
        });
        var i = n(45219),
          r = n(72380),
          s = n(87392),
          o = n(68297),
          a = n(74635);
        class h {
          constructor(e) {
            let t = new r.WU(a.T.SOF, 0, 0, 0, 0);
            (this.source = e),
              (this.lastToken = t),
              (this.token = t),
              (this.line = 1),
              (this.lineStart = 0);
          }
          get [Symbol.toStringTag]() {
            return "Lexer";
          }
          advance() {
            this.lastToken = this.token;
            let e = (this.token = this.lookahead());
            return e;
          }
          lookahead() {
            let e = this.token;
            if (e.kind !== a.T.EOF)
              do
                if (e.next) e = e.next;
                else {
                  let t = (function (e, t) {
                    let n = e.source.body,
                      r = n.length,
                      h = t;
                    for (; h < r; ) {
                      let t = n.charCodeAt(h);
                      switch (t) {
                        case 65279:
                        case 9:
                        case 32:
                        case 44:
                          ++h;
                          continue;
                        case 10:
                          ++h, ++e.line, (e.lineStart = h);
                          continue;
                        case 13:
                          10 === n.charCodeAt(h + 1) ? (h += 2) : ++h,
                            ++e.line,
                            (e.lineStart = h);
                          continue;
                        case 35:
                          return (function (e, t) {
                            let n = e.source.body,
                              i = n.length,
                              r = t + 1;
                            for (; r < i; ) {
                              let e = n.charCodeAt(r);
                              if (10 === e || 13 === e) break;
                              if (c(e)) ++r;
                              else if (u(n, r)) r += 2;
                              else break;
                            }
                            return f(e, a.T.COMMENT, t, r, n.slice(t + 1, r));
                          })(e, h);
                        case 33:
                          return f(e, a.T.BANG, h, h + 1);
                        case 36:
                          return f(e, a.T.DOLLAR, h, h + 1);
                        case 38:
                          return f(e, a.T.AMP, h, h + 1);
                        case 40:
                          return f(e, a.T.PAREN_L, h, h + 1);
                        case 41:
                          return f(e, a.T.PAREN_R, h, h + 1);
                        case 46:
                          if (
                            46 === n.charCodeAt(h + 1) &&
                            46 === n.charCodeAt(h + 2)
                          )
                            return f(e, a.T.SPREAD, h, h + 3);
                          break;
                        case 58:
                          return f(e, a.T.COLON, h, h + 1);
                        case 61:
                          return f(e, a.T.EQUALS, h, h + 1);
                        case 64:
                          return f(e, a.T.AT, h, h + 1);
                        case 91:
                          return f(e, a.T.BRACKET_L, h, h + 1);
                        case 93:
                          return f(e, a.T.BRACKET_R, h, h + 1);
                        case 123:
                          return f(e, a.T.BRACE_L, h, h + 1);
                        case 124:
                          return f(e, a.T.PIPE, h, h + 1);
                        case 125:
                          return f(e, a.T.BRACE_R, h, h + 1);
                        case 34:
                          if (
                            34 === n.charCodeAt(h + 1) &&
                            34 === n.charCodeAt(h + 2)
                          )
                            return (function (e, t) {
                              let n = e.source.body,
                                r = n.length,
                                o = e.lineStart,
                                h = t + 3,
                                l = h,
                                p = "",
                                d = [];
                              for (; h < r; ) {
                                let r = n.charCodeAt(h);
                                if (
                                  34 === r &&
                                  34 === n.charCodeAt(h + 1) &&
                                  34 === n.charCodeAt(h + 2)
                                ) {
                                  (p += n.slice(l, h)), d.push(p);
                                  let i = f(
                                    e,
                                    a.T.BLOCK_STRING,
                                    t,
                                    h + 3,
                                    (0, s.wv)(d).join("\n")
                                  );
                                  return (
                                    (e.line += d.length - 1),
                                    (e.lineStart = o),
                                    i
                                  );
                                }
                                if (
                                  92 === r &&
                                  34 === n.charCodeAt(h + 1) &&
                                  34 === n.charCodeAt(h + 2) &&
                                  34 === n.charCodeAt(h + 3)
                                ) {
                                  (p += n.slice(l, h)), (l = h + 1), (h += 4);
                                  continue;
                                }
                                if (10 === r || 13 === r) {
                                  (p += n.slice(l, h)),
                                    d.push(p),
                                    13 === r && 10 === n.charCodeAt(h + 1)
                                      ? (h += 2)
                                      : ++h,
                                    (p = ""),
                                    (l = h),
                                    (o = h);
                                  continue;
                                }
                                if (c(r)) ++h;
                                else if (u(n, h)) h += 2;
                                else
                                  throw (0, i.h)(
                                    e.source,
                                    h,
                                    `Invalid character within String: ${T(
                                      e,
                                      h
                                    )}.`
                                  );
                              }
                              throw (0, i.h)(
                                e.source,
                                h,
                                "Unterminated string."
                              );
                            })(e, h);
                          return (function (e, t) {
                            let n = e.source.body,
                              r = n.length,
                              s = t + 1,
                              o = s,
                              h = "";
                            for (; s < r; ) {
                              let r = n.charCodeAt(s);
                              if (34 === r)
                                return (
                                  (h += n.slice(o, s)),
                                  f(e, a.T.STRING, t, s + 1, h)
                                );
                              if (92 === r) {
                                h += n.slice(o, s);
                                let t =
                                  117 === n.charCodeAt(s + 1)
                                    ? 123 === n.charCodeAt(s + 2)
                                      ? (function (e, t) {
                                          let n = e.source.body,
                                            r = 0,
                                            s = 3;
                                          for (; s < 12; ) {
                                            let e = n.charCodeAt(t + s++);
                                            if (125 === e) {
                                              if (s < 5 || !c(r)) break;
                                              return {
                                                value: String.fromCodePoint(r),
                                                size: s,
                                              };
                                            }
                                            if ((r = (r << 4) | _(e)) < 0)
                                              break;
                                          }
                                          throw (0, i.h)(
                                            e.source,
                                            t,
                                            `Invalid Unicode escape sequence: "${n.slice(
                                              t,
                                              t + s
                                            )}".`
                                          );
                                        })(e, s)
                                      : (function (e, t) {
                                          let n = e.source.body,
                                            r = N(n, t + 2);
                                          if (c(r))
                                            return {
                                              value: String.fromCodePoint(r),
                                              size: 6,
                                            };
                                          if (
                                            p(r) &&
                                            92 === n.charCodeAt(t + 6) &&
                                            117 === n.charCodeAt(t + 7)
                                          ) {
                                            let e = N(n, t + 8);
                                            if (d(e))
                                              return {
                                                value: String.fromCodePoint(
                                                  r,
                                                  e
                                                ),
                                                size: 12,
                                              };
                                          }
                                          throw (0, i.h)(
                                            e.source,
                                            t,
                                            `Invalid Unicode escape sequence: "${n.slice(
                                              t,
                                              t + 6
                                            )}".`
                                          );
                                        })(e, s)
                                    : (function (e, t) {
                                        let n = e.source.body,
                                          r = n.charCodeAt(t + 1);
                                        switch (r) {
                                          case 34:
                                            return { value: '"', size: 2 };
                                          case 92:
                                            return { value: "\\", size: 2 };
                                          case 47:
                                            return { value: "/", size: 2 };
                                          case 98:
                                            return { value: "\b", size: 2 };
                                          case 102:
                                            return { value: "\f", size: 2 };
                                          case 110:
                                            return { value: "\n", size: 2 };
                                          case 114:
                                            return { value: "\r", size: 2 };
                                          case 116:
                                            return { value: "	", size: 2 };
                                        }
                                        throw (0, i.h)(
                                          e.source,
                                          t,
                                          `Invalid character escape sequence: "${n.slice(
                                            t,
                                            t + 2
                                          )}".`
                                        );
                                      })(e, s);
                                (h += t.value), (s += t.size), (o = s);
                                continue;
                              }
                              if (10 === r || 13 === r) break;
                              if (c(r)) ++s;
                              else if (u(n, s)) s += 2;
                              else
                                throw (0, i.h)(
                                  e.source,
                                  s,
                                  `Invalid character within String: ${T(e, s)}.`
                                );
                            }
                            throw (0, i.h)(e.source, s, "Unterminated string.");
                          })(e, h);
                      }
                      if ((0, o.X1)(t) || 45 === t)
                        return (function (e, t, n) {
                          let r = e.source.body,
                            s = t,
                            h = n,
                            l = !1;
                          if ((45 === h && (h = r.charCodeAt(++s)), 48 === h)) {
                            if (((h = r.charCodeAt(++s)), (0, o.X1)(h)))
                              throw (0, i.h)(
                                e.source,
                                s,
                                `Invalid number, unexpected digit after 0: ${T(
                                  e,
                                  s
                                )}.`
                              );
                          } else (s = E(e, s, h)), (h = r.charCodeAt(s));
                          if (
                            (46 === h &&
                              ((l = !0),
                              (h = r.charCodeAt(++s)),
                              (s = E(e, s, h)),
                              (h = r.charCodeAt(s))),
                            (69 === h || 101 === h) &&
                              ((l = !0),
                              (43 === (h = r.charCodeAt(++s)) || 45 === h) &&
                                (h = r.charCodeAt(++s)),
                              (s = E(e, s, h)),
                              (h = r.charCodeAt(s))),
                            46 === h || (0, o.LQ)(h))
                          )
                            throw (0, i.h)(
                              e.source,
                              s,
                              `Invalid number, expected digit but got: ${T(
                                e,
                                s
                              )}.`
                            );
                          return f(
                            e,
                            l ? a.T.FLOAT : a.T.INT,
                            t,
                            s,
                            r.slice(t, s)
                          );
                        })(e, h, t);
                      if ((0, o.LQ)(t))
                        return (function (e, t) {
                          let n = e.source.body,
                            i = n.length,
                            r = t + 1;
                          for (; r < i; ) {
                            let e = n.charCodeAt(r);
                            if ((0, o.HQ)(e)) ++r;
                            else break;
                          }
                          return f(e, a.T.NAME, t, r, n.slice(t, r));
                        })(e, h);
                      throw (0, i.h)(
                        e.source,
                        h,
                        39 === t
                          ? "Unexpected single quote character ('), did you mean to use a double quote (\")?"
                          : c(t) || u(n, h)
                          ? `Unexpected character: ${T(e, h)}.`
                          : `Invalid character: ${T(e, h)}.`
                      );
                    }
                    return f(e, a.T.EOF, r, r);
                  })(this, e.end);
                  (e.next = t), (t.prev = e), (e = t);
                }
              while (e.kind === a.T.COMMENT);
            return e;
          }
        }
        function l(e) {
          return (
            e === a.T.BANG ||
            e === a.T.DOLLAR ||
            e === a.T.AMP ||
            e === a.T.PAREN_L ||
            e === a.T.PAREN_R ||
            e === a.T.SPREAD ||
            e === a.T.COLON ||
            e === a.T.EQUALS ||
            e === a.T.AT ||
            e === a.T.BRACKET_L ||
            e === a.T.BRACKET_R ||
            e === a.T.BRACE_L ||
            e === a.T.PIPE ||
            e === a.T.BRACE_R
          );
        }
        function c(e) {
          return (e >= 0 && e <= 55295) || (e >= 57344 && e <= 1114111);
        }
        function u(e, t) {
          return p(e.charCodeAt(t)) && d(e.charCodeAt(t + 1));
        }
        function p(e) {
          return e >= 55296 && e <= 56319;
        }
        function d(e) {
          return e >= 56320 && e <= 57343;
        }
        function T(e, t) {
          let n = e.source.body.codePointAt(t);
          if (void 0 === n) return a.T.EOF;
          if (n >= 32 && n <= 126) {
            let e = String.fromCodePoint(n);
            return '"' === e ? "'\"'" : `"${e}"`;
          }
          return "U+" + n.toString(16).toUpperCase().padStart(4, "0");
        }
        function f(e, t, n, i, s) {
          let o = e.line,
            a = 1 + n - e.lineStart;
          return new r.WU(t, n, i, o, a, s);
        }
        function E(e, t, n) {
          if (!(0, o.X1)(n))
            throw (0, i.h)(
              e.source,
              t,
              `Invalid number, expected digit but got: ${T(e, t)}.`
            );
          let r = e.source.body,
            s = t + 1;
          for (; (0, o.X1)(r.charCodeAt(s)); ) ++s;
          return s;
        }
        function N(e, t) {
          return (
            (_(e.charCodeAt(t)) << 12) |
            (_(e.charCodeAt(t + 1)) << 8) |
            (_(e.charCodeAt(t + 2)) << 4) |
            _(e.charCodeAt(t + 3))
          );
        }
        function _(e) {
          return e >= 48 && e <= 57
            ? e - 48
            : e >= 65 && e <= 70
            ? e - 55
            : e >= 97 && e <= 102
            ? e - 87
            : -1;
        }
      },
      57867: function (e, t, n) {
        n.d(t, {
          k: function () {
            return s;
          },
        });
        var i = n(29551);
        let r = /\r\n|[\n\r]/g;
        function s(e, t) {
          let n = 0,
            s = 1;
          for (let o of e.body.matchAll(r)) {
            if (("number" == typeof o.index || (0, i.k)(!1), o.index >= t))
              break;
            (n = o.index + o[0].length), (s += 1);
          }
          return { line: s, column: t + 1 - n };
        }
      },
      84275: function (e, t, n) {
        n.d(t, {
          H2: function () {
            return u;
          },
          Qc: function () {
            return c;
          },
          gZ: function () {
            return d;
          },
          tl: function () {
            return p;
          },
        });
        var i = n(45219),
          r = n(72380),
          s = n(99878),
          o = n(97359),
          a = n(92105),
          h = n(7926),
          l = n(74635);
        function c(e, t) {
          let n = new T(e, t);
          return n.parseDocument();
        }
        function u(e, t) {
          let n = new T(e, t);
          n.expectToken(l.T.SOF);
          let i = n.parseValueLiteral(!1);
          return n.expectToken(l.T.EOF), i;
        }
        function p(e, t) {
          let n = new T(e, t);
          n.expectToken(l.T.SOF);
          let i = n.parseConstValueLiteral();
          return n.expectToken(l.T.EOF), i;
        }
        function d(e, t) {
          let n = new T(e, t);
          n.expectToken(l.T.SOF);
          let i = n.parseTypeReference();
          return n.expectToken(l.T.EOF), i;
        }
        class T {
          constructor(e, t = {}) {
            let n = (0, h.T)(e) ? e : new h.H(e);
            (this._lexer = new a.h(n)),
              (this._options = t),
              (this._tokenCounter = 0);
          }
          parseName() {
            let e = this.expectToken(l.T.NAME);
            return this.node(e, { kind: o.h.NAME, value: e.value });
          }
          parseDocument() {
            return this.node(this._lexer.token, {
              kind: o.h.DOCUMENT,
              definitions: this.many(l.T.SOF, this.parseDefinition, l.T.EOF),
            });
          }
          parseDefinition() {
            if (this.peek(l.T.BRACE_L)) return this.parseOperationDefinition();
            let e = this.peekDescription(),
              t = e ? this._lexer.lookahead() : this._lexer.token;
            if (t.kind === l.T.NAME) {
              switch (t.value) {
                case "schema":
                  return this.parseSchemaDefinition();
                case "scalar":
                  return this.parseScalarTypeDefinition();
                case "type":
                  return this.parseObjectTypeDefinition();
                case "interface":
                  return this.parseInterfaceTypeDefinition();
                case "union":
                  return this.parseUnionTypeDefinition();
                case "enum":
                  return this.parseEnumTypeDefinition();
                case "input":
                  return this.parseInputObjectTypeDefinition();
                case "directive":
                  return this.parseDirectiveDefinition();
              }
              if (e)
                throw (0, i.h)(
                  this._lexer.source,
                  this._lexer.token.start,
                  "Unexpected description, descriptions are supported only on type definitions."
                );
              switch (t.value) {
                case "query":
                case "mutation":
                case "subscription":
                  return this.parseOperationDefinition();
                case "fragment":
                  return this.parseFragmentDefinition();
                case "extend":
                  return this.parseTypeSystemExtension();
              }
            }
            throw this.unexpected(t);
          }
          parseOperationDefinition() {
            let e;
            let t = this._lexer.token;
            if (this.peek(l.T.BRACE_L))
              return this.node(t, {
                kind: o.h.OPERATION_DEFINITION,
                operation: r.ku.QUERY,
                name: void 0,
                variableDefinitions: [],
                directives: [],
                selectionSet: this.parseSelectionSet(),
              });
            let n = this.parseOperationType();
            return (
              this.peek(l.T.NAME) && (e = this.parseName()),
              this.node(t, {
                kind: o.h.OPERATION_DEFINITION,
                operation: n,
                name: e,
                variableDefinitions: this.parseVariableDefinitions(),
                directives: this.parseDirectives(!1),
                selectionSet: this.parseSelectionSet(),
              })
            );
          }
          parseOperationType() {
            let e = this.expectToken(l.T.NAME);
            switch (e.value) {
              case "query":
                return r.ku.QUERY;
              case "mutation":
                return r.ku.MUTATION;
              case "subscription":
                return r.ku.SUBSCRIPTION;
            }
            throw this.unexpected(e);
          }
          parseVariableDefinitions() {
            return this.optionalMany(
              l.T.PAREN_L,
              this.parseVariableDefinition,
              l.T.PAREN_R
            );
          }
          parseVariableDefinition() {
            return this.node(this._lexer.token, {
              kind: o.h.VARIABLE_DEFINITION,
              variable: this.parseVariable(),
              type: (this.expectToken(l.T.COLON), this.parseTypeReference()),
              defaultValue: this.expectOptionalToken(l.T.EQUALS)
                ? this.parseConstValueLiteral()
                : void 0,
              directives: this.parseConstDirectives(),
            });
          }
          parseVariable() {
            let e = this._lexer.token;
            return (
              this.expectToken(l.T.DOLLAR),
              this.node(e, { kind: o.h.VARIABLE, name: this.parseName() })
            );
          }
          parseSelectionSet() {
            return this.node(this._lexer.token, {
              kind: o.h.SELECTION_SET,
              selections: this.many(
                l.T.BRACE_L,
                this.parseSelection,
                l.T.BRACE_R
              ),
            });
          }
          parseSelection() {
            return this.peek(l.T.SPREAD)
              ? this.parseFragment()
              : this.parseField();
          }
          parseField() {
            let e, t;
            let n = this._lexer.token,
              i = this.parseName();
            return (
              this.expectOptionalToken(l.T.COLON)
                ? ((e = i), (t = this.parseName()))
                : (t = i),
              this.node(n, {
                kind: o.h.FIELD,
                alias: e,
                name: t,
                arguments: this.parseArguments(!1),
                directives: this.parseDirectives(!1),
                selectionSet: this.peek(l.T.BRACE_L)
                  ? this.parseSelectionSet()
                  : void 0,
              })
            );
          }
          parseArguments(e) {
            let t = e ? this.parseConstArgument : this.parseArgument;
            return this.optionalMany(l.T.PAREN_L, t, l.T.PAREN_R);
          }
          parseArgument(e = !1) {
            let t = this._lexer.token,
              n = this.parseName();
            return (
              this.expectToken(l.T.COLON),
              this.node(t, {
                kind: o.h.ARGUMENT,
                name: n,
                value: this.parseValueLiteral(e),
              })
            );
          }
          parseConstArgument() {
            return this.parseArgument(!0);
          }
          parseFragment() {
            let e = this._lexer.token;
            this.expectToken(l.T.SPREAD);
            let t = this.expectOptionalKeyword("on");
            return !t && this.peek(l.T.NAME)
              ? this.node(e, {
                  kind: o.h.FRAGMENT_SPREAD,
                  name: this.parseFragmentName(),
                  directives: this.parseDirectives(!1),
                })
              : this.node(e, {
                  kind: o.h.INLINE_FRAGMENT,
                  typeCondition: t ? this.parseNamedType() : void 0,
                  directives: this.parseDirectives(!1),
                  selectionSet: this.parseSelectionSet(),
                });
          }
          parseFragmentDefinition() {
            let e = this._lexer.token;
            return (this.expectKeyword("fragment"),
            !0 === this._options.allowLegacyFragmentVariables)
              ? this.node(e, {
                  kind: o.h.FRAGMENT_DEFINITION,
                  name: this.parseFragmentName(),
                  variableDefinitions: this.parseVariableDefinitions(),
                  typeCondition:
                    (this.expectKeyword("on"), this.parseNamedType()),
                  directives: this.parseDirectives(!1),
                  selectionSet: this.parseSelectionSet(),
                })
              : this.node(e, {
                  kind: o.h.FRAGMENT_DEFINITION,
                  name: this.parseFragmentName(),
                  typeCondition:
                    (this.expectKeyword("on"), this.parseNamedType()),
                  directives: this.parseDirectives(!1),
                  selectionSet: this.parseSelectionSet(),
                });
          }
          parseFragmentName() {
            if ("on" === this._lexer.token.value) throw this.unexpected();
            return this.parseName();
          }
          parseValueLiteral(e) {
            let t = this._lexer.token;
            switch (t.kind) {
              case l.T.BRACKET_L:
                return this.parseList(e);
              case l.T.BRACE_L:
                return this.parseObject(e);
              case l.T.INT:
                return (
                  this.advanceLexer(),
                  this.node(t, { kind: o.h.INT, value: t.value })
                );
              case l.T.FLOAT:
                return (
                  this.advanceLexer(),
                  this.node(t, { kind: o.h.FLOAT, value: t.value })
                );
              case l.T.STRING:
              case l.T.BLOCK_STRING:
                return this.parseStringLiteral();
              case l.T.NAME:
                switch ((this.advanceLexer(), t.value)) {
                  case "true":
                    return this.node(t, { kind: o.h.BOOLEAN, value: !0 });
                  case "false":
                    return this.node(t, { kind: o.h.BOOLEAN, value: !1 });
                  case "null":
                    return this.node(t, { kind: o.h.NULL });
                  default:
                    return this.node(t, { kind: o.h.ENUM, value: t.value });
                }
              case l.T.DOLLAR:
                if (e) {
                  if (
                    (this.expectToken(l.T.DOLLAR),
                    this._lexer.token.kind === l.T.NAME)
                  ) {
                    let e = this._lexer.token.value;
                    throw (0, i.h)(
                      this._lexer.source,
                      t.start,
                      `Unexpected variable "$${e}" in constant value.`
                    );
                  }
                  throw this.unexpected(t);
                }
                return this.parseVariable();
              default:
                throw this.unexpected();
            }
          }
          parseConstValueLiteral() {
            return this.parseValueLiteral(!0);
          }
          parseStringLiteral() {
            let e = this._lexer.token;
            return (
              this.advanceLexer(),
              this.node(e, {
                kind: o.h.STRING,
                value: e.value,
                block: e.kind === l.T.BLOCK_STRING,
              })
            );
          }
          parseList(e) {
            let t = () => this.parseValueLiteral(e);
            return this.node(this._lexer.token, {
              kind: o.h.LIST,
              values: this.any(l.T.BRACKET_L, t, l.T.BRACKET_R),
            });
          }
          parseObject(e) {
            let t = () => this.parseObjectField(e);
            return this.node(this._lexer.token, {
              kind: o.h.OBJECT,
              fields: this.any(l.T.BRACE_L, t, l.T.BRACE_R),
            });
          }
          parseObjectField(e) {
            let t = this._lexer.token,
              n = this.parseName();
            return (
              this.expectToken(l.T.COLON),
              this.node(t, {
                kind: o.h.OBJECT_FIELD,
                name: n,
                value: this.parseValueLiteral(e),
              })
            );
          }
          parseDirectives(e) {
            let t = [];
            for (; this.peek(l.T.AT); ) t.push(this.parseDirective(e));
            return t;
          }
          parseConstDirectives() {
            return this.parseDirectives(!0);
          }
          parseDirective(e) {
            let t = this._lexer.token;
            return (
              this.expectToken(l.T.AT),
              this.node(t, {
                kind: o.h.DIRECTIVE,
                name: this.parseName(),
                arguments: this.parseArguments(e),
              })
            );
          }
          parseTypeReference() {
            let e;
            let t = this._lexer.token;
            if (this.expectOptionalToken(l.T.BRACKET_L)) {
              let n = this.parseTypeReference();
              this.expectToken(l.T.BRACKET_R),
                (e = this.node(t, { kind: o.h.LIST_TYPE, type: n }));
            } else e = this.parseNamedType();
            return this.expectOptionalToken(l.T.BANG)
              ? this.node(t, { kind: o.h.NON_NULL_TYPE, type: e })
              : e;
          }
          parseNamedType() {
            return this.node(this._lexer.token, {
              kind: o.h.NAMED_TYPE,
              name: this.parseName(),
            });
          }
          peekDescription() {
            return this.peek(l.T.STRING) || this.peek(l.T.BLOCK_STRING);
          }
          parseDescription() {
            if (this.peekDescription()) return this.parseStringLiteral();
          }
          parseSchemaDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("schema");
            let n = this.parseConstDirectives(),
              i = this.many(
                l.T.BRACE_L,
                this.parseOperationTypeDefinition,
                l.T.BRACE_R
              );
            return this.node(e, {
              kind: o.h.SCHEMA_DEFINITION,
              description: t,
              directives: n,
              operationTypes: i,
            });
          }
          parseOperationTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseOperationType();
            this.expectToken(l.T.COLON);
            let n = this.parseNamedType();
            return this.node(e, {
              kind: o.h.OPERATION_TYPE_DEFINITION,
              operation: t,
              type: n,
            });
          }
          parseScalarTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("scalar");
            let n = this.parseName(),
              i = this.parseConstDirectives();
            return this.node(e, {
              kind: o.h.SCALAR_TYPE_DEFINITION,
              description: t,
              name: n,
              directives: i,
            });
          }
          parseObjectTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("type");
            let n = this.parseName(),
              i = this.parseImplementsInterfaces(),
              r = this.parseConstDirectives(),
              s = this.parseFieldsDefinition();
            return this.node(e, {
              kind: o.h.OBJECT_TYPE_DEFINITION,
              description: t,
              name: n,
              interfaces: i,
              directives: r,
              fields: s,
            });
          }
          parseImplementsInterfaces() {
            return this.expectOptionalKeyword("implements")
              ? this.delimitedMany(l.T.AMP, this.parseNamedType)
              : [];
          }
          parseFieldsDefinition() {
            return this.optionalMany(
              l.T.BRACE_L,
              this.parseFieldDefinition,
              l.T.BRACE_R
            );
          }
          parseFieldDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription(),
              n = this.parseName(),
              i = this.parseArgumentDefs();
            this.expectToken(l.T.COLON);
            let r = this.parseTypeReference(),
              s = this.parseConstDirectives();
            return this.node(e, {
              kind: o.h.FIELD_DEFINITION,
              description: t,
              name: n,
              arguments: i,
              type: r,
              directives: s,
            });
          }
          parseArgumentDefs() {
            return this.optionalMany(
              l.T.PAREN_L,
              this.parseInputValueDef,
              l.T.PAREN_R
            );
          }
          parseInputValueDef() {
            let e;
            let t = this._lexer.token,
              n = this.parseDescription(),
              i = this.parseName();
            this.expectToken(l.T.COLON);
            let r = this.parseTypeReference();
            this.expectOptionalToken(l.T.EQUALS) &&
              (e = this.parseConstValueLiteral());
            let s = this.parseConstDirectives();
            return this.node(t, {
              kind: o.h.INPUT_VALUE_DEFINITION,
              description: n,
              name: i,
              type: r,
              defaultValue: e,
              directives: s,
            });
          }
          parseInterfaceTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("interface");
            let n = this.parseName(),
              i = this.parseImplementsInterfaces(),
              r = this.parseConstDirectives(),
              s = this.parseFieldsDefinition();
            return this.node(e, {
              kind: o.h.INTERFACE_TYPE_DEFINITION,
              description: t,
              name: n,
              interfaces: i,
              directives: r,
              fields: s,
            });
          }
          parseUnionTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("union");
            let n = this.parseName(),
              i = this.parseConstDirectives(),
              r = this.parseUnionMemberTypes();
            return this.node(e, {
              kind: o.h.UNION_TYPE_DEFINITION,
              description: t,
              name: n,
              directives: i,
              types: r,
            });
          }
          parseUnionMemberTypes() {
            return this.expectOptionalToken(l.T.EQUALS)
              ? this.delimitedMany(l.T.PIPE, this.parseNamedType)
              : [];
          }
          parseEnumTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("enum");
            let n = this.parseName(),
              i = this.parseConstDirectives(),
              r = this.parseEnumValuesDefinition();
            return this.node(e, {
              kind: o.h.ENUM_TYPE_DEFINITION,
              description: t,
              name: n,
              directives: i,
              values: r,
            });
          }
          parseEnumValuesDefinition() {
            return this.optionalMany(
              l.T.BRACE_L,
              this.parseEnumValueDefinition,
              l.T.BRACE_R
            );
          }
          parseEnumValueDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription(),
              n = this.parseEnumValueName(),
              i = this.parseConstDirectives();
            return this.node(e, {
              kind: o.h.ENUM_VALUE_DEFINITION,
              description: t,
              name: n,
              directives: i,
            });
          }
          parseEnumValueName() {
            if (
              "true" === this._lexer.token.value ||
              "false" === this._lexer.token.value ||
              "null" === this._lexer.token.value
            )
              throw (0, i.h)(
                this._lexer.source,
                this._lexer.token.start,
                `${f(
                  this._lexer.token
                )} is reserved and cannot be used for an enum value.`
              );
            return this.parseName();
          }
          parseInputObjectTypeDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("input");
            let n = this.parseName(),
              i = this.parseConstDirectives(),
              r = this.parseInputFieldsDefinition();
            return this.node(e, {
              kind: o.h.INPUT_OBJECT_TYPE_DEFINITION,
              description: t,
              name: n,
              directives: i,
              fields: r,
            });
          }
          parseInputFieldsDefinition() {
            return this.optionalMany(
              l.T.BRACE_L,
              this.parseInputValueDef,
              l.T.BRACE_R
            );
          }
          parseTypeSystemExtension() {
            let e = this._lexer.lookahead();
            if (e.kind === l.T.NAME)
              switch (e.value) {
                case "schema":
                  return this.parseSchemaExtension();
                case "scalar":
                  return this.parseScalarTypeExtension();
                case "type":
                  return this.parseObjectTypeExtension();
                case "interface":
                  return this.parseInterfaceTypeExtension();
                case "union":
                  return this.parseUnionTypeExtension();
                case "enum":
                  return this.parseEnumTypeExtension();
                case "input":
                  return this.parseInputObjectTypeExtension();
              }
            throw this.unexpected(e);
          }
          parseSchemaExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("schema");
            let t = this.parseConstDirectives(),
              n = this.optionalMany(
                l.T.BRACE_L,
                this.parseOperationTypeDefinition,
                l.T.BRACE_R
              );
            if (0 === t.length && 0 === n.length) throw this.unexpected();
            return this.node(e, {
              kind: o.h.SCHEMA_EXTENSION,
              directives: t,
              operationTypes: n,
            });
          }
          parseScalarTypeExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("scalar");
            let t = this.parseName(),
              n = this.parseConstDirectives();
            if (0 === n.length) throw this.unexpected();
            return this.node(e, {
              kind: o.h.SCALAR_TYPE_EXTENSION,
              name: t,
              directives: n,
            });
          }
          parseObjectTypeExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("type");
            let t = this.parseName(),
              n = this.parseImplementsInterfaces(),
              i = this.parseConstDirectives(),
              r = this.parseFieldsDefinition();
            if (0 === n.length && 0 === i.length && 0 === r.length)
              throw this.unexpected();
            return this.node(e, {
              kind: o.h.OBJECT_TYPE_EXTENSION,
              name: t,
              interfaces: n,
              directives: i,
              fields: r,
            });
          }
          parseInterfaceTypeExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("interface");
            let t = this.parseName(),
              n = this.parseImplementsInterfaces(),
              i = this.parseConstDirectives(),
              r = this.parseFieldsDefinition();
            if (0 === n.length && 0 === i.length && 0 === r.length)
              throw this.unexpected();
            return this.node(e, {
              kind: o.h.INTERFACE_TYPE_EXTENSION,
              name: t,
              interfaces: n,
              directives: i,
              fields: r,
            });
          }
          parseUnionTypeExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("union");
            let t = this.parseName(),
              n = this.parseConstDirectives(),
              i = this.parseUnionMemberTypes();
            if (0 === n.length && 0 === i.length) throw this.unexpected();
            return this.node(e, {
              kind: o.h.UNION_TYPE_EXTENSION,
              name: t,
              directives: n,
              types: i,
            });
          }
          parseEnumTypeExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("enum");
            let t = this.parseName(),
              n = this.parseConstDirectives(),
              i = this.parseEnumValuesDefinition();
            if (0 === n.length && 0 === i.length) throw this.unexpected();
            return this.node(e, {
              kind: o.h.ENUM_TYPE_EXTENSION,
              name: t,
              directives: n,
              values: i,
            });
          }
          parseInputObjectTypeExtension() {
            let e = this._lexer.token;
            this.expectKeyword("extend"), this.expectKeyword("input");
            let t = this.parseName(),
              n = this.parseConstDirectives(),
              i = this.parseInputFieldsDefinition();
            if (0 === n.length && 0 === i.length) throw this.unexpected();
            return this.node(e, {
              kind: o.h.INPUT_OBJECT_TYPE_EXTENSION,
              name: t,
              directives: n,
              fields: i,
            });
          }
          parseDirectiveDefinition() {
            let e = this._lexer.token,
              t = this.parseDescription();
            this.expectKeyword("directive"), this.expectToken(l.T.AT);
            let n = this.parseName(),
              i = this.parseArgumentDefs(),
              r = this.expectOptionalKeyword("repeatable");
            this.expectKeyword("on");
            let s = this.parseDirectiveLocations();
            return this.node(e, {
              kind: o.h.DIRECTIVE_DEFINITION,
              description: t,
              name: n,
              arguments: i,
              repeatable: r,
              locations: s,
            });
          }
          parseDirectiveLocations() {
            return this.delimitedMany(l.T.PIPE, this.parseDirectiveLocation);
          }
          parseDirectiveLocation() {
            let e = this._lexer.token,
              t = this.parseName();
            if (Object.prototype.hasOwnProperty.call(s.B, t.value)) return t;
            throw this.unexpected(e);
          }
          node(e, t) {
            return (
              !0 !== this._options.noLocation &&
                (t.loc = new r.Ye(
                  e,
                  this._lexer.lastToken,
                  this._lexer.source
                )),
              t
            );
          }
          peek(e) {
            return this._lexer.token.kind === e;
          }
          expectToken(e) {
            let t = this._lexer.token;
            if (t.kind === e) return this.advanceLexer(), t;
            throw (0, i.h)(
              this._lexer.source,
              t.start,
              `Expected ${E(e)}, found ${f(t)}.`
            );
          }
          expectOptionalToken(e) {
            let t = this._lexer.token;
            return t.kind === e && (this.advanceLexer(), !0);
          }
          expectKeyword(e) {
            let t = this._lexer.token;
            if (t.kind === l.T.NAME && t.value === e) this.advanceLexer();
            else
              throw (0, i.h)(
                this._lexer.source,
                t.start,
                `Expected "${e}", found ${f(t)}.`
              );
          }
          expectOptionalKeyword(e) {
            let t = this._lexer.token;
            return (
              t.kind === l.T.NAME && t.value === e && (this.advanceLexer(), !0)
            );
          }
          unexpected(e) {
            let t = null != e ? e : this._lexer.token;
            return (0, i.h)(this._lexer.source, t.start, `Unexpected ${f(t)}.`);
          }
          any(e, t, n) {
            this.expectToken(e);
            let i = [];
            for (; !this.expectOptionalToken(n); ) i.push(t.call(this));
            return i;
          }
          optionalMany(e, t, n) {
            if (this.expectOptionalToken(e)) {
              let e = [];
              do e.push(t.call(this));
              while (!this.expectOptionalToken(n));
              return e;
            }
            return [];
          }
          many(e, t, n) {
            this.expectToken(e);
            let i = [];
            do i.push(t.call(this));
            while (!this.expectOptionalToken(n));
            return i;
          }
          delimitedMany(e, t) {
            this.expectOptionalToken(e);
            let n = [];
            do n.push(t.call(this));
            while (this.expectOptionalToken(e));
            return n;
          }
          advanceLexer() {
            let { maxTokens: e } = this._options,
              t = this._lexer.advance();
            if (
              void 0 !== e &&
              t.kind !== l.T.EOF &&
              (++this._tokenCounter, this._tokenCounter > e)
            )
              throw (0, i.h)(
                this._lexer.source,
                t.start,
                `Document contains more that ${e} tokens. Parsing aborted.`
              );
          }
        }
        function f(e) {
          let t = e.value;
          return E(e.kind) + (null != t ? ` "${t}"` : "");
        }
        function E(e) {
          return (0, a.u)(e) ? `"${e}"` : e;
        }
      },
      90850: function (e, t, n) {
        n.d(t, {
          Q: function () {
            return r;
          },
          z: function () {
            return s;
          },
        });
        var i = n(57867);
        function r(e) {
          return s(e.source, (0, i.k)(e.source, e.start));
        }
        function s(e, t) {
          let n = e.locationOffset.column - 1,
            i = "".padStart(n) + e.body,
            r = t.line - 1,
            s = e.locationOffset.line - 1,
            a = t.line + s,
            h = 1 === t.line ? n : 0,
            l = t.column + h,
            c = `${e.name}:${a}:${l}
`,
            u = i.split(/\r\n|[\n\r]/g),
            p = u[r];
          if (p.length > 120) {
            let e = Math.floor(l / 80),
              t = [];
            for (let e = 0; e < p.length; e += 80) t.push(p.slice(e, e + 80));
            return (
              c +
              o([
                [`${a} |`, t[0]],
                ...t.slice(1, e + 1).map((e) => ["|", e]),
                ["|", "^".padStart(l % 80)],
                ["|", t[e + 1]],
              ])
            );
          }
          return (
            c +
            o([
              [`${a - 1} |`, u[r - 1]],
              [`${a} |`, p],
              ["|", "^".padStart(l)],
              [`${a + 1} |`, u[r + 1]],
            ])
          );
        }
        function o(e) {
          let t = e.filter(([e, t]) => void 0 !== t),
            n = Math.max(...t.map(([e]) => e.length));
          return t
            .map(([e, t]) => e.padStart(n) + (t ? " " + t : ""))
            .join("\n");
        }
      },
      7926: function (e, t, n) {
        n.d(t, {
          H: function () {
            return o;
          },
          T: function () {
            return a;
          },
        });
        var i = n(37826),
          r = n(25821),
          s = n(8306);
        class o {
          constructor(e, t = "GraphQL request", n = { line: 1, column: 1 }) {
            "string" == typeof e ||
              (0, i.a)(!1, `Body must be a string. Received: ${(0, r.X)(e)}.`),
              (this.body = e),
              (this.name = t),
              (this.locationOffset = n),
              this.locationOffset.line > 0 ||
                (0, i.a)(
                  !1,
                  "line in locationOffset is 1-indexed and must be positive."
                ),
              this.locationOffset.column > 0 ||
                (0, i.a)(
                  !1,
                  "column in locationOffset is 1-indexed and must be positive."
                );
          }
          get [Symbol.toStringTag]() {
            return "Source";
          }
        }
        function a(e) {
          return (0, s.n)(e, o);
        }
      },
      74635: function (e, t, n) {
        var i, r;
        n.d(t, {
          T: function () {
            return i;
          },
        }),
          ((r = i || (i = {})).SOF = "<SOF>"),
          (r.EOF = "<EOF>"),
          (r.BANG = "!"),
          (r.DOLLAR = "$"),
          (r.AMP = "&"),
          (r.PAREN_L = "("),
          (r.PAREN_R = ")"),
          (r.SPREAD = "..."),
          (r.COLON = ":"),
          (r.EQUALS = "="),
          (r.AT = "@"),
          (r.BRACKET_L = "["),
          (r.BRACKET_R = "]"),
          (r.BRACE_L = "{"),
          (r.PIPE = "|"),
          (r.BRACE_R = "}"),
          (r.NAME = "Name"),
          (r.INT = "Int"),
          (r.FLOAT = "Float"),
          (r.STRING = "String"),
          (r.BLOCK_STRING = "BlockString"),
          (r.COMMENT = "Comment");
      },
    },
  ]);
