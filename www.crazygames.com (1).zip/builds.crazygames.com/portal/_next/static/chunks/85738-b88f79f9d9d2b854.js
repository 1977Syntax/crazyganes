!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "f00937a6-5201-4419-9f5c-57ea95d82e48"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-f00937a6-5201-4419-9f5c-57ea95d82e48"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [85738],
    {
      67278: function (e, t, i) {
        i.d(t, {
          v: function () {
            return z;
          },
          Z: function () {
            return Y;
          },
        });
        var s,
          n,
          r = i(85893),
          a = i(28584),
          o = i(78966),
          d = i(95570),
          l = i(67294),
          h = i(10029);
        let u = null;
        var c = i(74040),
          m = i(83514),
          f = i(84973),
          g = i(58752),
          p = i(3708),
          v = i(58104),
          w = i(13301),
          b = i(22120),
          y = i(92975);
        let C = [
          { width: 1910, height: 970 },
          { width: 1360, height: 660 },
          { width: 1370, height: 650 },
          { width: 1370, height: 620 },
          { width: 1530, height: 750 },
          { width: 1360, height: 650 },
          { width: 1910, height: 940 },
          { width: 1370, height: 660 },
          { width: 1360, height: 630 },
          { width: 1080, height: 710 },
          { width: 1920, height: 970 },
          { width: 1360, height: 620 },
          { width: 1910, height: 960 },
          { width: 1370, height: 670 },
          { width: 1530, height: 710 },
          { width: 1910, height: 930 },
          { width: 1370, height: 630 },
          { width: 1920, height: 940 },
          { width: 390, height: 660 },
        ];
        var k = i(33209),
          T = i(55933),
          x = i(93988),
          F = i(7057),
          I = i(46413);
        class L {
          constructor(e) {
            (this.id = e),
              (this.previousTimeInView = 0),
              (this.isInView = !1),
              (this.isInFocus = !0),
              (this.isHidden = !1),
              (this.inViewSince = Date.now()),
              (this.inDOMSince = this.inViewSince);
          }
          setHidden(e) {
            this.isHidden = e;
          }
          canRefresh(e, t) {
            return (
              this.isInView &&
              this.isInFocus &&
              this.totalTimeInView() >= e &&
              this.totalTimeInDOM() >= t
            );
          }
          refreshed() {
            (this.previousTimeInView = 0),
              (this.inViewSince = Date.now()),
              (this.inDOMSince = this.inViewSince);
          }
          cameIntoView() {
            (this.isInView = !0), (this.inViewSince = Date.now());
          }
          removedFromView() {
            (this.isInView = !1), this.updateTimeInView();
          }
          pageLostFocus() {
            (this.isInFocus = !1), this.isInView && this.updateTimeInView();
          }
          pageRegainedFocus() {
            (this.isInFocus = !0),
              this.isInView && (this.inViewSince = Date.now());
          }
          updateTimeInView() {
            let e = Date.now() - this.inViewSince;
            (this.previousTimeInView += e), (this.inViewSince = Date.now());
          }
          totalTimeInDOM() {
            return Date.now() - this.inDOMSince;
          }
          totalTimeInView() {
            return this.isInView
              ? this.previousTimeInView + Date.now() - this.inViewSince
              : this.previousTimeInView;
          }
        }
        var E = class {
            constructor(e, t) {
              (this.viewportThreshold = e),
                (this.minimumTimeInViewInMs = t),
                (this.handleVisibilityChange = () => {
                  let e = document[this.hiddenKey],
                    t = I.Z.isFullscreen() || I.Z.isFakeFullscreen();
                  e || t ? this.pageLostFocus() : this.pageRegainedFocus();
                }),
                (this.handleFullscreenChange = () => {
                  let e = I.Z.isFullscreen() || I.Z.isFakeFullscreen();
                  e ? this.pageLostFocus() : this.pageRegainedFocus();
                }),
                (this.adUnits = []),
                this.setVisibilityKeys(),
                (this.observer = this.createObserver()),
                this.installEventListeners(),
                (this.pageFocusChangeCallBacks = []),
                (this.ioCallbackPending = []),
                (this.ioCallbackPendingPromise = null),
                (this.ioCallbackPendingResolve = null);
            }
            addElement(e) {
              if (this.adUnits.find((t) => t.id === e)) return;
              let t = this.getElementById(e);
              t &&
                (this.ioCallbackPending.push(e),
                this.adUnits.push(new L(e)),
                this.observer.observe(t.parentElement));
            }
            removeElement(e, t) {
              (this.adUnits = this.adUnits.filter((t) => t.id !== e)),
                t && this.observer.unobserve(t.parentElement),
                this.removeWaitingForCallbackElement(e);
            }
            addPageFocusChangeCallback(e) {
              this.pageFocusChangeCallBacks.push(e);
            }
            stop() {
              (this.adUnits = []),
                (this.pageFocusChangeCallBacks = []),
                this.observer.disconnect(),
                this.removeEventListeners();
            }
            waitForObservedUnitsCallbacks() {
              return (
                this.ioCallbackPendingPromise ||
                  (this.ioCallbackPendingPromise = new Promise((e) => {
                    (this.ioCallbackPendingResolve = e),
                      0 === this.ioCallbackPending.length && e();
                  })),
                this.ioCallbackPendingPromise
              );
            }
            isUnitHidden(e) {
              let t = this.adUnits.find((t) => t.id === e);
              return !t || t.isHidden;
            }
            canUnitRefresh(e, t) {
              let i = this.adUnits.find((t) => t.id === e);
              return !i || i.canRefresh(this.minimumTimeInViewInMs, t);
            }
            refreshedUnits(e) {
              e.map((e) => this.getObservedUnit(e)).map((e) => e.refreshed());
            }
            intersectionCallback(e) {
              e.forEach((e) => {
                let t = e.target.firstElementChild.id,
                  i = this.getObservedUnit(t);
                e.intersectionRatio >= this.viewportThreshold
                  ? i.cameIntoView()
                  : i.removedFromView(),
                  i.setHidden(this.isEntryHidden(e)),
                  this.removeWaitingForCallbackElement(t);
              });
            }
            isEntryHidden(e) {
              let { boundingClientRect: t } = e;
              return this.isBoundingRectHidden(t);
            }
            isBoundingRectHidden(e) {
              return 0 === e.height && 0 === e.width;
            }
            getElementById(e) {
              let t = document.getElementById(e);
              return (
                t ||
                (console.error(
                  `[AdObserver] could not find element with id ${e}`
                ),
                null)
              );
            }
            getObservedUnit(e) {
              let t = this.adUnits.find((t) => t.id === e);
              if (!t) throw Error("[AdObserver] observed unit not found");
              return t;
            }
            pageLostFocus() {
              this.adUnits.map((e) => e.pageLostFocus()),
                this.invokeCallBacks(!1);
            }
            pageRegainedFocus() {
              this.adUnits.map((e) => e.pageRegainedFocus()),
                this.invokeCallBacks(!0);
            }
            invokeCallBacks(e) {
              this.pageFocusChangeCallBacks.forEach((t) => t(e));
            }
            createObserver() {
              return new IntersectionObserver(
                (e, t) => {
                  this.intersectionCallback(e);
                },
                { threshold: [this.viewportThreshold] }
              );
            }
            installEventListeners() {
              document.addEventListener(
                this.visibilityChangeKey,
                this.handleVisibilityChange,
                !1
              ),
                this.installFullscreenListener();
            }
            removeEventListeners() {
              document.removeEventListener(
                this.visibilityChangeKey,
                this.handleVisibilityChange
              ),
                this.removeFullscreenListeners();
            }
            installFullscreenListener() {
              I.Z.addFullscreenListener(this.handleFullscreenChange),
                I.Z.addFakeFullscreenListener(this.handleFullscreenChange);
            }
            removeFullscreenListeners() {
              I.Z.removeFullscreenListener(this.handleFullscreenChange),
                I.Z.removeFakeFullscreenListener(this.handleFullscreenChange);
            }
            setVisibilityKeys() {
              void 0 !== document.hidden
                ? ((this.hiddenKey = "hidden"),
                  (this.visibilityChangeKey = "visibilitychange"))
                : void 0 !== document.msHidden
                ? ((this.hiddenKey = "msHidden"),
                  (this.visibilityChangeKey = "msvisibilitychange"))
                : void 0 !== document.webkitHidden &&
                  ((this.hiddenKey = "webkitHidden"),
                  (this.visibilityChangeKey = "webkitvisibilitychange"));
            }
            removeWaitingForCallbackElement(e) {
              (this.ioCallbackPending = this.ioCallbackPending.filter(
                (t) => t !== e
              )),
                0 === this.ioCallbackPending.length &&
                  this.ioCallbackPendingResolve &&
                  (this.ioCallbackPendingResolve(),
                  (this.ioCallbackPendingResolve = null));
            }
          },
          U = i(89950),
          A = i(4235);
        let R = function (e, t) {
          let i = window.setTimeout(e, t);
          return () => clearTimeout(i);
        };
        var M = class {
            disposed = !1;
            constructor(e, t, i = R) {
              (this.timerFactory = i),
                (this.timerPeriod = e),
                (this.onEvent = t),
                (this.timeRemaining = 0);
            }
            restart() {
              this.disposed ||
                (this.clearCurrent(), this.startTimer(this.timerPeriod));
            }
            startTimer(e) {
              let t = () => {
                (this.timerDisposer = void 0), this.onEvent();
              };
              (this.timerDisposer = this.timerFactory(t, e)),
                (this.timeStarted = this.now()),
                (this.currentTimeout = e);
            }
            pause() {
              if (this.disposed || !this.isRunning()) return;
              this.clearCurrent();
              let e = this.now() - this.timeStarted;
              this.timeRemaining = this.currentTimeout - e;
            }
            resume(e) {
              if (this.disposed || this.isRunning()) return;
              let t = void 0 !== e ? e : this.timeRemaining;
              t <= 0
                ? ((this.timeRemaining = this.currentTimeout),
                  this.onEvent(),
                  this.isRunning() || this.restart())
                : this.startTimer(t);
            }
            dispose() {
              (this.disposed = !0), this.clearCurrent();
            }
            clearCurrent() {
              void 0 !== this.timerDisposer &&
                (this.timerDisposer(), (this.timerDisposer = void 0));
            }
            isRunning() {
              return void 0 !== this.timerDisposer;
            }
            now() {
              return Date.now();
            }
          },
          D = class {
            timeOfLastRefresh = 0;
            timeOfMount = 0;
            eventHandlerMemory = { gamePlayStarted: !1 };
            constructor(e, t, i) {
              (this.refreshAds = e),
                (this.timer = new M(
                  (function (e) {
                    switch (e.type) {
                      case "smart":
                        return e.maximumTimeBetweenRefreshes;
                      case "regular":
                        return e.timeBetweenRefreshes;
                    }
                  })(i),
                  () => this.handleEvent("timerTriggered")
                )),
                (this.startMomentConfig = t),
                (this.refreshConfig = i);
            }
            refresh() {
              let e = this.refreshAds();
              e
                ? ((this.timeOfLastRefresh = Date.now()), this.timer.restart())
                : this.timer.resume();
            }
            handleExternalEvent(e) {
              switch (e.type) {
                case "focusChanged":
                  return (
                    e.hasFocus
                      ? this.onAction({ type: "refresh" })
                      : this.onAction({ type: "pauseTimer" }),
                    !0
                  );
                case "initialAdsRequestFinished":
                  return (
                    "startOnMount" === this.startMomentConfig.type &&
                      this.onAction({ type: "restartTimer" }),
                    !0
                  );
                case "mounted":
                  return this.init(), this.handleEvent("componentMounted"), !0;
                case "willUnmount":
                  return this.dispose(), !0;
              }
            }
            getMinimumTimeInDOMBeforeRefresh() {
              return this.refreshConfig.minimumTimeInDOM;
            }
            init() {
              let e = this.requiresGameEventListener();
              e &&
                (window.addEventListener("message", this.handleMessageEvent),
                "waitUntilAfterGameLoading" === this.startMomentConfig.type &&
                  A.$()?.contentWindow?.postMessage(
                    "check-loading-state",
                    "*"
                  )),
                (this.timeOfMount = Date.now());
            }
            dispose() {
              this.timer.dispose();
              let e = this.requiresGameEventListener();
              e &&
                window.removeEventListener("message", this.handleMessageEvent);
            }
            requiresGameEventListener() {
              return (
                "smart" === this.refreshConfig.type ||
                "waitUntilAfterGameLoading" === this.startMomentConfig.type
              );
            }
            onAction(e) {
              switch (e.type) {
                case "restartTimer":
                  return this.timer.restart(), !0;
                case "pauseTimer":
                  return this.timer.pause(), !0;
                case "resumeTimer":
                  return this.timer.resume(), !0;
                case "refresh":
                  return this.refresh(), !0;
                case "ignore":
                  return !0;
              }
            }
            handleMessageEvent = (e) => {
              if (!e.data || e.data.type !== U.V) return;
              let t = this.convertToRefreshTimerEvent(e.data);
              this.handleEvent(t);
            };
            convertToRefreshTimerEvent(e) {
              return "gameLoadingStateResponse" === e.event
                ? e.success
                  ? "gameLoadingStateResponseSuccess"
                  : "gameLoadingStateResponseFailure"
                : e.event;
            }
            handleEvent = (e) => {
              let t = (function (e, t, i, s, n, r, a, o) {
                if ("timerTriggered" === e)
                  return s +
                    (() => {
                      switch (a.type) {
                        case "regular":
                          return a.timeBetweenRefreshes;
                        case "smart":
                          return a.minimumTimeBetweenRefreshes;
                      }
                    })() <=
                    1.1 * n
                    ? { type: "refresh" }
                    : { type: "ignore" };
                if (!t) {
                  switch (r.type) {
                    case "startOnMount":
                      return "componentMounted" === e
                        ? { type: "restartTimer" }
                        : { type: "ignore" };
                    case "waitUntilAfterGameLoading":
                      if (
                        "gameFinishedLoading" === e ||
                        "gameLoadingStateResponseSuccess" === e
                      ) {
                        let e = n - i,
                          t = r.minimumWaitTimeAfterPageLoad;
                        if (e >= t) return { type: "refresh" };
                        return {
                          type: "resumeTimer",
                          customTimeout: Math.max(0, t - e),
                        };
                      }
                  }
                  return { type: "ignore" };
                }
                if ("smart" === a.type)
                  switch (e) {
                    case "adFinished":
                    case "gameplayStart":
                      if (o.gamePlayStarted) break;
                      return (o.gamePlayStarted = !0), { type: "restartTimer" };
                    case "rewardedAd":
                    case "midgameAd":
                    case "gameplayStop":
                      if (!o.gamePlayStarted) break;
                      if (
                        ((o.gamePlayStarted = !1),
                        n - s >= a.minimumTimeBetweenRefreshes)
                      )
                        return { type: "refresh" };
                  }
                return { type: "ignore" };
              })(
                e,
                this.timer.isRunning(),
                this.timeOfMount,
                this.timeOfLastRefresh,
                Date.now(),
                this.startMomentConfig,
                this.refreshConfig,
                this.eventHandlerMemory
              );
              this.onAction(t);
            };
          };
        let S = {
            regular: {
              minTimeBetweenConsecutiveRefreshes: 3e4,
              maxTimeBetweenConsecutiveRefreshes: 51e3,
              minTimeInDom: 2e4,
            },
            highlyAffectedSystems: {
              minTimeBetweenConsecutiveRefreshes: 3e4,
              maxTimeBetweenConsecutiveRefreshes: 15e4,
              minTimeInDom: 2e4,
            },
          },
          O = [{ browsers: ["safari"], os: [] }];
        function B(e) {
          return e ? e.toLowerCase().replace(/\s/g, "") : "unknown";
        }
        var P = i(18126),
          _ = class {
            bidderAttemptsWithoutBid = {};
            biddersToDisable = {};
            constructor(e) {
              this.numberOfBidAttempts = e;
            }
            onRequestAdsResult = (e, t, i) => {
              if (i)
                for (let s of e.codes ?? []) {
                  let n = this.extractEnabledBiddersForAdUnitFromRequest(
                    s,
                    e,
                    t
                  );
                  this.updateBidderAttemptsWithoutBid(s, i, n),
                    delete this.biddersToDisable[s];
                }
            };
            getBiddersToDisable = (e) => {
              let t = this.bidderAttemptsWithoutBid[e];
              if (!this.biddersToDisable[e]) {
                if (t) {
                  let i = Object.keys(t),
                    s = i.filter((e) => {
                      let i = t[e];
                      return void 0 !== i && i >= this.numberOfBidAttempts;
                    });
                  this.biddersToDisable[e] = s;
                } else this.biddersToDisable[e] = [];
              }
              return this.biddersToDisable[e];
            };
            reset = () => {
              (this.bidderAttemptsWithoutBid = {}),
                (this.biddersToDisable = {});
            };
            getCurrentNumberOfAttemptsWithoutBid = (e, t) => {
              let i = this.bidderAttemptsWithoutBid[e];
              if (void 0 === i) return 0;
              let s = i[t];
              return void 0 === s ? 0 : s;
            };
            extractEnabledBiddersForAdUnitFromRequest(e, t, i) {
              let s = {};
              (i.bidders || []).forEach((e) => {
                s[e.bidder] = { ...e };
              });
              let n = t.units.find((t) => t.adUnit.code === e)?.bidders || [];
              return (
                n.forEach((e) => {
                  s[e.bidder] = { ...s[e.bidder], ...e };
                }),
                Object.values(s)
                  .filter((e) => e.enabled && "google" !== e.bidder)
                  .map((e) => e.bidder)
              );
            }
            updateBidderAttemptsWithoutBid(e, t, i) {
              this.bidderAttemptsWithoutBid[e] =
                this.bidderAttemptsWithoutBid[e] || {};
              let s = (t[e]?.bids ?? []).map((e) => e.bidder);
              i.forEach((t) => {
                s.includes(t)
                  ? (this.bidderAttemptsWithoutBid[e][t] = 0)
                  : (this.bidderAttemptsWithoutBid[e][t] =
                      (this.bidderAttemptsWithoutBid[e][t] || 0) + 1);
              });
            }
          },
          V = class {
            adsLibraryLoaded = !1;
            adsConfigLoaded = !1;
            userInfoLoaded = !1;
            consent = !1;
            config = null;
            userInfo = null;
            constructor(e) {
              this.shouldWaitForConsent = e;
            }
            handleAction(e) {
              switch (e.type) {
                case "adsLibraryLoaded":
                  return this.onAdsLibraryLoaded();
                case "adsConfigLoaded":
                  return this.onAdsConfigLoaded(e);
                case "consentGiven":
                  return this.onConsentGiven();
                case "userInfoLoaded":
                  return this.onUserInfoLoaded(e);
              }
            }
            retrieveState() {
              return this.adsLibraryLoaded &&
                this.adsConfigLoaded &&
                this.userInfoLoaded &&
                this.consent &&
                null !== this.config &&
                null !== this.userInfo
                ? {
                    ready: !0,
                    userInfo: this.userInfo,
                    config: this.config,
                    consent: !0,
                  }
                : {
                    ready: !1,
                    userInfo: this.userInfo,
                    config: this.config,
                    consent: this.consent,
                  };
            }
            onAdsLibraryLoaded() {
              return (this.adsLibraryLoaded = !0), this.retrieveState();
            }
            onAdsConfigLoaded(e) {
              return (
                (this.adsConfigLoaded = !0),
                (this.config = e.config),
                this.retrieveState()
              );
            }
            onConsentGiven() {
              return (this.consent = !0), this.retrieveState();
            }
            onUserInfoLoaded(e) {
              (this.userInfoLoaded = !0), (this.userInfo = e.userInfo);
              let t = this.shouldWaitForConsent(e.userInfo.countryCode);
              return t ? this.retrieveState() : this.onConsentGiven();
            }
          },
          q = i(37899);
        let j = !1,
          G = (e) => {
            let {
                pageUrlHelper: t,
                dispatch: i,
                resetLibrary: s,
                adsLoaderContext: n,
              } = e,
              [r] = (0, l.useState)(s),
              a = (0, l.useContext)(q.Z).services,
              o = n.adsLoader,
              d = n.initAds;
            return (
              l.useEffect(() => {
                let e = () => {
                  let e = window;
                  r && e.CrazygamesAds.reset(),
                    j ||
                      (d(),
                      a.crazyAnalyticsService.adsFinishedLoading(),
                      a.analyticsService.checkAdblock(),
                      (j = !0)),
                    i({ type: "adsLibraryLoaded" });
                };
                return (
                  o.loadCrazyAds(t),
                  o.addLoadListener(e),
                  () => o.removeLoadListener(e)
                );
              }, [t, i, r, a, o, d]),
              null
            );
          },
          Z = (e) => {
            let { dispatch: t } = e,
              i = (0, l.useContext)(q.Z).services.adUnitService;
            return (
              (0, l.useEffect)(() => {
                void 0 !== i &&
                  i
                    .getAdUnitsConfig()
                    .then((e) => t({ type: "adsConfigLoaded", config: e }));
              }, [t, i]),
              null
            );
          };
        var W = i(69626);
        let H = (e) => {
            let { dispatch: t } = e;
            return (
              l.useEffect(() => {
                let e = () => t({ type: "consentGiven" }),
                  i = (0, W.a)();
                return (
                  i.addConsentListener(e), () => i.removeConsentListener(e)
                );
              }, [t]),
              null
            );
          },
          $ = (e) => {
            let { dispatch: t } = e,
              i = (0, l.useContext)(q.Z).services.userInfoService;
            return (
              l.useEffect(() => {
                i.getUserInfo().then((e) => {
                  t({ type: "userInfoLoaded", userInfo: e });
                });
              }, [i, t]),
              null
            );
          };
        function N() {
          throw Error("[AdContext] No Advertising Context");
        }
        let z = l.createContext({
          addAdUnit: (e) => N(),
          removeAdUnit: (e, t) => N(),
          adblock: !1,
        });
        ((s = n || (n = {})).ANDROID = "android"),
          (s.IOS = "ios"),
          (s.WINDOWS = "windows"),
          (s.MAC = "macos"),
          (s.LINUX = "linux"),
          (s.CHROMIUM = "chromiumos"),
          (s.UBUNTU = "ubuntu"),
          (s.UNKNOWN = "unknown"),
          (s.OTHER = "other");
        let K = { GB: 0.2, US: 0.2 },
          X = [
            "army",
            "battle-royale",
            "battleship",
            "bloody",
            "bomberman",
            "cannon",
            "first-person-shooter",
            "gta",
            "gun",
            "horde-survival",
            "hunting",
            "jump-scare",
            "killing",
            "mmo",
            "police",
            "scary",
            "shooting",
            "sniper",
            "soldier",
            "surgery",
            "survive",
            "tank",
            "third-person-shooter",
            "war",
          ],
          J = null;
        class Q extends l.Component {
          static isFirstRequest = !0;
          countryCode = null;
          deviceInfo = null;
          disabledCountries = ["RU", "VE", "BY"];
          disabledBidderTracker = new _(5);
          mounted = !1;
          disabled = !1;
          constructor(e) {
            super(e),
              (this.adUnits = []),
              (this.timeInViewInMs = 1e4),
              (this.viewPortThreshold = 0.5),
              (this.observer = null),
              (this.advertisingLoadingModel = new V(
                (e) =>
                  (0, p.Z)(e, this.props.pageUrlHelper) &&
                  this.shouldWaitUntilConsented(e)
              )),
              (this.state = {
                loadingModelState: this.advertisingLoadingModel.retrieveState(),
              });
          }
          componentDidMount() {
            let { pageUrlHelper: e } = this.props;
            (this.disabled =
              e.shouldDisableAds() ||
              this.props.disabled ||
              !this.props.deviceType.isDesktop),
              (this.mounted = !0);
            let t = this.props.services.experimentService;
            t.getExperimentValueAsBoolean(x.lU).then((e) => {
              this.alignConsentExperiment = e || !1;
            }),
              (this.observer = new E(
                this.viewPortThreshold,
                this.timeInViewInMs
              )),
              (this.firstPageRequest = !0),
              (this.userType = (0, g.OQ)() ? "returning" : "new"),
              (this.resetBiddersToDisableInterval = window.setInterval(() => {
                this.resetBiddersToDisable();
              }, 9e5));
          }
          componentWillUnmount() {
            (this.mounted = !1),
              this.getRefreshTimer()?.handleExternalEvent({
                type: "willUnmount",
              }),
              this.observer && (this.observer.stop(), (this.observer = null));
            let e = window;
            e.CrazygamesAds &&
              e.CrazygamesAds.nextPage &&
              e.CrazygamesAds.nextPage(),
              window.clearInterval(this.resetBiddersToDisableInterval);
          }
          componentDidUpdate(e, t, i) {
            let s = this.state.loadingModelState,
              n = s.ready;
            if (n && (null === this.adConfig || void 0 === this.adConfig)) {
              if (
                ((this.adConfig = s.config),
                (this.countryCode = s.userInfo.countryCode),
                (this.deviceInfo = s.userInfo.device),
                this.inDisabledCountry(this.countryCode))
              )
                return;
              this.initRefreshTimer(),
                this.addUnitsToObserver(),
                this.toRequestAds();
            }
          }
          dispatchLoadingAction = (e) => {
            if (!this.mounted) return;
            let t = this.advertisingLoadingModel.handleAction(e);
            this.setState({ loadingModelState: t });
          };
          render() {
            return (0, r.jsxs)(r.Fragment, {
              children: [
                !this.disabled &&
                  (0, r.jsxs)(r.Fragment, {
                    children: [
                      (0, r.jsx)(G, {
                        dispatch: this.dispatchLoadingAction,
                        pageUrlHelper: this.props.pageUrlHelper,
                        resetLibrary: !Q.isFirstRequest,
                        adsLoaderContext: this.props.adsLoaderContext,
                      }),
                      (0, r.jsx)(Z, { dispatch: this.dispatchLoadingAction }),
                      (0, r.jsx)($, { dispatch: this.dispatchLoadingAction }),
                      (0, r.jsx)(H, { dispatch: this.dispatchLoadingAction }),
                    ],
                  }),
                (0, r.jsx)(z.Provider, {
                  value: {
                    addAdUnit: this.addAdUnit,
                    removeAdUnit: this.removeAdUnit,
                    adblock: !1,
                  },
                  children: this.props.children,
                }),
              ],
            });
          }
          getCountryCode = () => this.countryCode;
          inDisabledCountry(e) {
            return !e || this.disabledCountries.some((t) => t === e);
          }
          async toRequestAds() {
            await this.requestAds(),
              this.mounted && this.addObserverCallbacks();
          }
          addAdUnit = (e) => {
            !this.adUnits.find((t) => t.id === e.id) &&
              (this.adUnits.push(e),
              this.observer && this.adConfig && this.addUnitToObserver(e));
          };
          removeAdUnit = (e, t) => {
            (this.adUnits = this.adUnits.filter((t) => t.id !== e.id)),
              this.observer &&
                this.adConfig &&
                this.removeUnitFromObserver(e, t);
          };
          async requestAds() {
            let e = this.adUnitsRequestConfig();
            if (
              0 !== e.length &&
              (await this.observer.waitForObservedUnitsCallbacks(),
              this.mounted)
            )
              return this.requestAndRenderAds();
          }
          requestAndRenderAds = () => {
            if (!this.observer) return !1;
            let e = [],
              t = this.getRefreshTimer();
            this.firstPageRequest
              ? (e = this.adUnits.filter(
                  (e) => !this.observer.isUnitHidden(e.id)
                ))
              : null != t &&
                (e = this.adUnits.filter((e) =>
                  this.observer.canUnitRefresh(
                    e.id,
                    t.getMinimumTimeInDOMBeforeRefresh()
                  )
                ));
            let i = e.map((e) => e.id),
              s = this.adUnitsRequestConfig();
            if (0 === s.length || 0 === i.length) return !0;
            let n = { units: s, codes: i },
              r = window.CrazygamesAds;
            if (void 0 === r) return !1;
            let a = this.requestAdsOptions();
            return (
              r
                .requestOnly(n, a)
                .then(async (e) => {
                  if (!this.mounted) return;
                  let t = this.renderAds(i);
                  this.disabledBidderTracker.onRequestAdsResult(n, a, e),
                    await t;
                })
                .catch((e) => console.error(e)),
              this.firstPageRequest &&
                ((this.firstPageRequest = !1),
                (Q.isFirstRequest = !1),
                this.getRefreshTimer()?.handleExternalEvent({
                  type: "initialAdsRequestFinished",
                })),
              !0
            );
          };
          requestAdsOptions() {
            let {
                dollarRate: e,
                priceFloor: t,
                ...i
              } = this.adConfig.advertising,
              s = this.getTimeout(),
              n = this.adConfig.bidders.map((e) =>
                this.mapApiConfigToBidderConfig(e)
              ),
              r = this.isLoggedIn(),
              a = this.getPriceFloor() || t,
              o = this.getUserDetails(),
              d = window.location.origin + window.location.pathname;
            return {
              ...i,
              priceFloor: r && a ? 1.3 * a : a,
              bidders: n,
              timeout: s,
              trafficSource: this.trafficSource(),
              user: o,
              pageUrl: d,
              ortb2Site: this.ortb2SiteConfig(d),
              clientInfo: {
                country: this.getCountryCode(),
                locale: (0, k.Ld)(this.props.locale),
                browser: this.deviceInfo?.browser.name
                  ?.toLowerCase()
                  .replace(/\s/g, ""),
                device: (0, w.l7)(this.props.deviceType),
              },
              pageIdentifier: this.props.advertisingGame.gameSlug,
            };
          }
          ortb2SiteConfig(e) {
            let t = (this.props.advertisingGame.tagsSlug || []).filter(
                (e) => -1 === X.indexOf(e)
              ),
              i = {
                title: this.props.advertisingGame.gameName,
                url: window.location.href,
                context: 2,
                userrating: `${this.props.advertisingGame.numLikes}`,
                sourcerelationship: 1,
                keywords: t.join(","),
              };
            return { page: e, content: i };
          }
          async renderAds(e) {
            try {
              let t = this.renderAdsOptions();
              await window.CrazygamesAds.render(e, t);
            } catch (e) {
              console.error(e);
            }
          }
          renderAdsOptions() {
            let e = this.getTimeout(),
              t = this.adConfig.bidders.find((e) => "google" === e.id),
              i = t
                ? {
                    googleBidder: {
                      ...this.mapApiConfigToBidderConfig(t),
                      enabled: !0,
                    },
                  }
                : {};
            return {
              dfp: this.dfpKeys(),
              banner: {
                callback: (e) => {
                  let { minPrice: t, code: i, empty: s, houseAd: n } = e,
                    r = this.props.services;
                  !(function (e, t) {
                    if (null === u) {
                      let t = window.setTimeout(() => {
                        for (let t in (e.crazyAnalyticsService.bannerAdConversion(
                          u?.totalValue || 0
                        ),
                        u?.valueByGame))
                          e.analyticsService.trackAdConversion({
                            gameSlug: t,
                            value: u?.valueByGame[t] ?? 0,
                          });
                        (function () {
                          if ("undefined" == typeof gtag || !u || !u.totalValue)
                            return;
                          let e = u.totalValue;
                          (0, h.requestIdleCallback)(
                            () => {
                              gtag("event", "conversion", {
                                send_to: "AW-312835820/UBOSCNjR06wDEOz9lZUB",
                                value: e,
                                currency: "EUR",
                              });
                            },
                            { timeout: 2e3 }
                          );
                        })(),
                          (u = null);
                      }, 1e3);
                      u = { timeoutId: t, totalValue: 0, valueByGame: {} };
                    }
                    (u.totalValue = u.totalValue + t.value),
                      (u.valueByGame[t.gameSlug] =
                        (u.valueByGame[t.gameSlug] || 0) + t.value);
                  })(
                    {
                      analyticsService: r.analyticsService,
                      crazyAnalyticsService: r.crazyAnalyticsService,
                    },
                    { value: t, gameSlug: this.props.advertisingGame.gameSlug }
                  );
                  let a = this.adUnits.find((e) => e.code === i);
                  void 0 !== a && a.onRender(s, n);
                },
              },
              requestTimeout: e,
              ...i,
            };
          }
          trafficSource() {
            let e = (0, F.p9)();
            return e ? "purchased" : "organic";
          }
          getPriceFloor() {
            let e = this.getCountryCode();
            return (e && K[e]) || null;
          }
          getTimeout() {
            return Q.isFirstRequest ? 2400 : 2e3;
          }
          mapApiConfigToBidderConfig(e) {
            let t = { bidder: e.id, ...e.config };
            return "adsense" === e.id
              ? { ...t, enabled: !1 }
              : { enabled: !0, ...t };
          }
          pageFocusChangeCallback = (e) => {
            this.mounted &&
              this.getRefreshTimer()?.handleExternalEvent({
                type: "focusChanged",
                hasFocus: e,
              });
          };
          adUnitsRequestConfig() {
            let { units: e } = this.adConfig,
              t = this.adUnits.map((t) => {
                let i = e.find((e) => e.id === t.code);
                if (!i)
                  return (
                    console.error(`[Advertising] Unexpected code ${t.code}`),
                    null
                  );
                let s = this.disabledBidderTracker.getBiddersToDisable(t.id),
                  n = i.config.request.bidders,
                  r = n.map((e) =>
                    s.includes(e.bidder) ? { ...e, enabled: !1 } : e
                  );
                return {
                  adUnit: { mediaTypes: i.definition.mediaTypes, code: t.id },
                  slotId: i.definition.slotId,
                  ...i.config.request,
                  bidders: r,
                };
              });
            return t.filter((e) => !!e);
          }
          addUnitsToObserver() {
            this.adUnits.forEach((e) => {
              this.addUnitToObserver(e);
            });
          }
          addObserverCallbacks() {
            this.observer.addPageFocusChangeCallback(
              this.pageFocusChangeCallback
            );
          }
          addUnitToObserver(e) {
            let t = this.getUnitDefinition(e.code);
            if (!t) {
              console.error("Missing definition", e.code);
              return;
            }
            this.observer.addElement(e.id);
          }
          removeUnitFromObserver(e, t) {
            let i = this.getUnitDefinition(e.code);
            if (!i) {
              console.error("Missing definition", e.code);
              return;
            }
            i.definition.refresh && this.observer.removeElement(e.id, t);
          }
          dfpKeys() {
            let e, t, i;
            let { pageUrlHelper: s, advertisingGame: n } = this.props,
              { gameSlug: r, tagsSlug: l, categoryEnSlug: h } = n,
              u = s.routeData.hostname,
              c = (0, F.FM)(),
              m = (0, F.dj)();
            if (m) {
              let s = Date.now(),
                n = m.date,
                r = (0, a.Z)(s, n) + 1;
              e = `${m.adGroup}_week${r}`;
              let l = (0, o.Z)(n) + 1,
                h = l < 10 ? `0${l}` : `${l}`,
                u = `${(0, d.Z)(n)}`.slice(-2);
              t = `${m.adGroup}_${h}_${u}`;
              let c = new Date(n),
                f = c.getUTCDate().toString().padStart(2, "0"),
                g = (c.getUTCMonth() + 1).toString().padStart(2, "0"),
                p = c.getUTCFullYear().toString().slice(-2);
              i = `${m.adGroup}_${f}_${g}_${p}`;
            }
            let f = this.mapOsToDfpOs(this.deviceInfo?.os.name),
              g = this.isLoggedIn();
            return {
              domain: u,
              advertising_campaign: c,
              pwa: `${(0, T.r)()}`,
              category_slug: h,
              game_slug: r,
              tags_slug: l.length > 0 ? l : void 0,
              ad_group: e,
              ad_group_month: t,
              adgroup_acqdate: i,
              logged_in: `${g}`,
              user_type: this.userType,
              os: f,
              locale: this.props.locale,
              ...(function () {
                let e = window.innerWidth,
                  t = window.innerHeight,
                  i = C.some((i) => i.width === e && i.height === t);
                if (i) return { browser_size: `${e}x${t}` };
              })(),
              ...((0, v.G3)(this.countryCode) && {
                [x.lU]: `${this.alignConsentExperiment}`,
              }),
              ...(void 0 !== this.props.edgeExperiments.aa_exp_24 && {
                aa_exp_24: `${this.props.edgeExperiments.aa_exp_24}`,
              }),
              ...(void 0 !== this.props.edgeExperiments.skip_preroll_exp_25 && {
                skip_preroll_exp2_25: `${this.props.edgeExperiments.skip_preroll_exp_25}`,
              }),
            };
          }
          isLoggedIn() {
            return !!this.props.userContext.user;
          }
          mapOsToDfpOs(e) {
            let t = this.getCleanedString(e);
            switch (t) {
              case "unknown":
                return n.UNKNOWN;
              case "android":
                return n.ANDROID;
              case "ios":
                return n.IOS;
              case "windows":
                return n.WINDOWS;
              case "macos":
                return n.MAC;
              case "linux":
                return n.LINUX;
              case "chromiumos":
                return n.CHROMIUM;
              case "ubuntu":
                return n.UBUNTU;
              default:
                return n.OTHER;
            }
          }
          shouldWaitUntilConsented = (e) =>
            (0, v.I)(e) ||
            (void 0 !== this.alignConsentExperiment && (0, v.G3)(e));
          getUnitDefinition(e) {
            let t = this.adConfig.units.find((t) => t.id === e);
            return t;
          }
          getRefreshTimer() {
            return (
              this.refreshTimer || this.initRefreshTimer(), this.refreshTimer
            );
          }
          initRefreshTimer() {
            if (
              !this.deviceInfo ||
              (null !== this.refreshTimer && void 0 !== this.refreshTimer)
            )
              return;
            let { smartRefresh: e } = this.props,
              t = this.requestAndRenderAds;
            (this.refreshTimer = (function (e, t, i, s, n) {
              let r = (function (e) {
                  let t = e.isLowEndDevice && !(0.05 > Math.random());
                  return t
                    ? {
                        type: "waitUntilAfterGameLoading",
                        minimumWaitTimeAfterPageLoad: 45e3,
                      }
                    : { type: "startOnMount" };
                })(s),
                a = (function (e, t, i) {
                  let s = (function (e, t) {
                      let i = B(e),
                        s = B(t);
                      for (let e of O) {
                        let t =
                            0 === e.browsers.length || e.browsers.includes(s),
                          n = 0 === e.os.length || e.os.includes(i);
                        if (t && n) return !0;
                      }
                      return !1;
                    })(e, t),
                    n = s ? S.highlyAffectedSystems : S.regular,
                    r =
                      i?.minWaitInMs !== void 0
                        ? i.minWaitInMs
                        : n.minTimeBetweenConsecutiveRefreshes,
                    a =
                      i?.maxWaitInMs !== void 0
                        ? i.maxWaitInMs
                        : n.maxTimeBetweenConsecutiveRefreshes;
                  return {
                    type: "smart",
                    minimumTimeBetweenRefreshes: Math.min(r, a),
                    maximumTimeBetweenRefreshes: Math.max(r, a),
                    minimumTimeInDOM: n.minTimeInDom,
                  };
                })(t, i, n);
              return new D(e, r, a);
            })(
              t,
              this.deviceInfo.os.name,
              this.deviceInfo.browser.name,
              this.props.device,
              e
            )),
              this.refreshTimer.handleExternalEvent({ type: "mounted" }),
              this.firstPageRequest ||
                this.refreshTimer.handleExternalEvent({
                  type: "initialAdsRequestFinished",
                });
          }
          getUserEmail() {
            if (this.email) return this.email;
            let { userContext: e } = this.props,
              { user: t, loadingUser: i } = e;
            if (i) return;
            let s = t?.email
              ?.trim()
              .toLowerCase()
              .replace(/\+[^@]*@/g, "@");
            return (this.email = s), this.email;
          }
          getUserDetails() {
            var e;
            let t = this.getUserEmail();
            return {
              email: t,
              amazon: {
                applicable:
                  ((e = this.deviceInfo),
                  null === J &&
                    (J =
                      !!e &&
                      ["Firefox", "Safari", "Mobile Safari"].some((t) =>
                        (0, w.jU)(e?.browser, t)
                      )),
                  J),
              },
              uid2: { applicable: !0 },
            };
          }
          resetBiddersToDisable() {
            this.disabledBidderTracker.reset();
          }
          getCleanedString(e) {
            return e ? e.toLowerCase().replace(/\s/g, "") : "unknown";
          }
        }
        var Y = (0, y.Z)(
          (0, f.Z)(
            (function (e) {
              let t = (t) => {
                let { pageUrlHelper: i } = l.useContext(m.t);
                return (0, r.jsx)(e, { pageUrlHelper: i, ...t });
              };
              return t;
            })(
              (0, b.Z)(
                (function (e) {
                  let t = (t) => {
                    let i = l.useContext(c.S);
                    return (0, r.jsx)(e, { userContext: i, ...t });
                  };
                  return t;
                })(
                  (function (e) {
                    let t = (t) => {
                      let i = l.useContext(P.y);
                      return (0, r.jsx)(e, { adsLoaderContext: i, ...t });
                    };
                    return t;
                  })(Q)
                )
              )
            )
          )
        );
      },
      90611: function (e, t, i) {
        i.d(t, {
          J: function () {
            return r;
          },
        });
        var s = i(67294),
          n = i(380);
        let r = (e) => {
          let { game: t } = e,
            {
              setPlayingGame: i,
              resetGameInvites: r,
              setGameInviteLink: a,
            } = s.useContext(n.DN);
          return (
            s.useEffect(() => {
              if (t)
                return (
                  i(t),
                  () => {
                    i(null), a(null), r();
                  }
                );
            }, [t, r, a, i]),
            null
          );
        };
      },
      18288: function (e, t, i) {
        var s = i(85893),
          n = i(9008),
          r = i.n(n);
        i(67294);
        var a = i(46313),
          o = i(75007),
          d = i(33209);
        let l = "favicons/manifest-icon-3.png",
          h = "favicons/favicon-transparent.png",
          u = (e) => {
            let {
                title: t,
                metaDescription: i,
                canonical: n,
                alternatives: u = [],
                children: c,
              } = e,
              m = u.find((e) => {
                let { locale: t } = e;
                return t === d.ZW;
              }),
              f = (e, t, i) =>
                (0, o.ZP)(e, { width: t, height: i, fit: "crop" }),
              g = "development" === a.Z.Instance.environment;
            return (0, s.jsxs)(r(), {
              children: [
                (0, s.jsx)("title", {
                  children: `${g ? "\uD83E\uDD99 - " : ""}${t}`,
                }),
                (0, s.jsx)("link", { rel: "manifest", href: "/manifest" }),
                (0, s.jsx)("meta", { httpEquiv: "Accept-CH", content: "DPR" }),
                (0, s.jsx)("meta", { name: "description", content: i }),
                n && (0, s.jsx)("link", { rel: "canonical", href: n }),
                u.map((e) => {
                  let { href: t, locale: i } = e,
                    n = (0, d.xi)(i);
                  return (0, s.jsx)(
                    "link",
                    { rel: "alternate", hrefLang: n, href: t },
                    n
                  );
                }),
                m &&
                  (0, s.jsx)("link", {
                    rel: "alternate",
                    href: m.href,
                    hrefLang: "x-default",
                  }),
                (0, s.jsx)("meta", { name: "theme-color", content: "#ffffff" }),
                (0, s.jsx)("meta", {
                  name: "HandheldFriendly",
                  content: "true",
                }),
                (0, s.jsx)("meta", {
                  name: "mobile-web-app-capable",
                  content: "yes",
                }),
                (0, s.jsx)("meta", {
                  name: "apple-mobile-web-app-capable",
                  content: "yes",
                }),
                (0, s.jsx)("meta", {
                  name: "apple-mobile-web-app-status-bar-style",
                  content: "default",
                }),
                (0, s.jsx)("link", {
                  rel: "apple-touch-icon",
                  href: f(l, 120, 120),
                }),
                (0, s.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "152x152",
                  href: f(l, 152, 152),
                }),
                (0, s.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "167x167",
                  href: f(l, 167, 167),
                }),
                (0, s.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "180x180",
                  href: f(l, 180, 180),
                }),
                (0, s.jsx)("link", {
                  rel: "mask-icon",
                  href: (0, o.ZP)("favicons/safari-pinned-tab.svg", {}, !1),
                  color: "#6842ff",
                }),
                (0, s.jsx)("link", {
                  rel: "icon",
                  href: f(h, 16, 16),
                  sizes: "16x16",
                }),
                (0, s.jsx)("link", {
                  rel: "icon",
                  href: f(h, 32, 32),
                  sizes: "32x32",
                }),
                (0, s.jsx)("link", {
                  rel: "icon",
                  href: f(h, 48, 48),
                  sizes: "48x48",
                }),
                (0, s.jsx)("link", {
                  rel: "icon",
                  href: f(h, 196, 196),
                  sizes: "196x196",
                }),
                (0, s.jsx)("meta", {
                  name: "msapplication-TileColor",
                  content: "#603cba",
                }),
                (0, s.jsx)("meta", {
                  name: "msapplication-TileImage",
                  content: f(h, 144, 144),
                }),
                c,
              ],
            });
          };
        t.Z = u;
      },
      4235: function (e, t, i) {
        i.d(t, {
          $: function () {
            return n;
          },
          x: function () {
            return s;
          },
        });
        let s = "game-iframe";
        function n() {
          let e = document.getElementById(s);
          return e;
        }
      },
      84973: function (e, t, i) {
        var s = i(85893),
          n = i(67294),
          r = i(37899);
        t.Z = function (e) {
          let t = (t) => {
            let { services: i } = n.useContext(r.Z);
            return (0, s.jsx)(e, { services: i, ...t });
          };
          return t;
        };
      },
      44898: function (e, t, i) {
        var s = i(50319),
          n = i(73359),
          r = i(67294),
          a = i(21046),
          o = i(89950),
          d = i(74040),
          l = i(95129),
          h = i(42257);
        async function u(e) {
          let t = await fetch(e, { method: "GET" }),
            i = await t.text();
          return i;
        }
        let c = (e) => {
          let { gameId: t, gameTechnology: i } = e,
            { user: c } = r.useContext(d.S),
            m = r.useContext(l.Z),
            f = r.useContext(h.Z),
            [g] = (0, s.D)(a._l),
            [p] = (0, s.D)(a.dO),
            [v, w] = (0, n.t)(a.kJ),
            b = r.useRef([]);
          return (
            r.useEffect(() => {
              if (!w.called || w.loading) return;
              let e = w.data?.gameData;
              w.error
                ? (b.current.forEach((e) => {
                    e({ type: "requestGameDataNone" });
                  }),
                  (b.current = []))
                : e && e.dataUrl
                ? u(e.dataUrl).then((t) => {
                    let i = { ...e, data: t };
                    b.current.forEach((e) => {
                      e({
                        type: "requestGameDataResponse",
                        data: { store: i, error: w.error },
                      });
                    }),
                      (b.current = []);
                  })
                : (b.current.forEach((e) => {
                    e({
                      type: "requestGameDataResponse",
                      data: { store: void 0, error: w.error },
                    });
                  }),
                  (b.current = []));
            }, [w]),
            r.useEffect(() => {
              let e = (e) => {
                  let s = (t) => {
                    let i = e.source;
                    i && i.postMessage(t, "*");
                  };
                  c
                    ? ((b.current = [s, ...b.current]),
                      v({
                        variables: { id: t, technology: i },
                        fetchPolicy: "network-only",
                      }))
                    : b.current.forEach((e) => {
                        e({
                          type: "requestGameDataResponse",
                          data: { store: void 0, error: null },
                        });
                      });
                },
                s = (e) => {
                  let {
                      store: s,
                      version: n,
                      updatedAtTz: r,
                      playedTime: a,
                    } = e.data,
                    o = JSON.stringify(s),
                    d = m.browser?.name || "",
                    l = (0, h.c)(f);
                  g({
                    variables: {
                      input: {
                        data: o,
                        id: t,
                        technology: i,
                        version: n,
                        browser: d,
                        playedTime: a,
                        deviceType: l,
                        updatedAtTz: r,
                      },
                    },
                  });
                },
                n = (e) => {
                  let { version: s } = e.data,
                    n = m.browser?.name || "",
                    r = (0, h.c)(f);
                  p({
                    variables: {
                      input: {
                        id: t,
                        technology: i,
                        version: s,
                        browser: n,
                        deviceType: r,
                      },
                    },
                  });
                },
                r = (t) => {
                  if (t.data && t.data.type === o.V)
                    switch (t.data.event) {
                      case "requestGameData":
                        e(t);
                        break;
                      case "updateGameData":
                      case "replaceGameData":
                        c && s(t);
                        break;
                      case "clearGameData":
                        c && n(t);
                        break;
                      default:
                        return;
                    }
                };
              return (
                window.addEventListener("message", r),
                function () {
                  window.removeEventListener("message", r);
                }
              );
            }, [g, v, p, t, i, c, m.browser, f]),
            null
          );
        };
        t.Z = c;
      },
      21046: function (e, t, i) {
        i.d(t, {
          _l: function () {
            return a;
          },
          dO: function () {
            return o;
          },
          kJ: function () {
            return r;
          },
        });
        var s = i(14646),
          n = i(12774);
        let r = n.qR,
          a = s.OX,
          o = s.Le;
      },
      89041: function (e, t, i) {
        var s = i(73359),
          n = i(6388),
          r = i(67294),
          a = i(89950),
          o = i(74040),
          d = i(63922),
          l = i(23180),
          h = i(46313),
          u = i(46413);
        let c = (e) => {
          let { gameId: t } = e,
            { user: i } = r.useContext(o.S),
            { openedDrawer: c } = r.useContext(l.rf),
            { drawerOpeningPending: m } = r.useContext(l.Xm),
            { openDrawer: f } = r.useContext(l.s9),
            [g, p] = (0, s.t)(d.bI),
            [v, w] = (0, s.t)(d.fo),
            [b, y] = (0, r.useState)(!1),
            [C, k] = (0, r.useState)(null),
            { data: T } = (0, n.aM)(d.Qt, { skip: !i });
          (0, r.useEffect)(() => {
            if (
              !m &&
              b &&
              C &&
              (i ||
                c ||
                (y(!1),
                k(null),
                C.postMessage(
                  {
                    type: "showAuthPromptResponse",
                    data: {
                      error: {
                        code: "userCancelled",
                        message: "User cancelled the auth prompt",
                      },
                    },
                  },
                  "*"
                )),
              i && T && !c)
            ) {
              y(!1), k(null);
              let e = {
                type: "showAuthPromptResponse",
                data: {
                  user: {
                    id: T.me.id,
                    username: `${T.me.username}`,
                    profilePictureUrl: `${h.Z.Instance.data.images}${T.me.profile.avatar}`,
                  },
                },
              };
              C.postMessage(e, "*");
            }
          }, [c, b, i, C, T, m]);
          let x = (0, r.useCallback)(
              async (e, s) => {
                let n = { type: "requestUserTokenResponse", data: {} };
                if (!i) {
                  (n.data = {
                    error: {
                      code: "userNotAuthenticated",
                      message: "The user is not authenticated",
                    },
                  }),
                    e.postMessage(n, "*");
                  return;
                }
                if (p.loading) return;
                let r = await g({
                    variables: { gameId: t, iframeUrl: s },
                    fetchPolicy: "network-only",
                  }),
                  a = r.data?.userToken;
                r.error || !a
                  ? (console.error("User token retrieve error", r.error),
                    (n.data = {
                      error: {
                        code: "unexpectedError",
                        message: "Failed to retrieve user token",
                      },
                    }))
                  : (n.data = { token: a.token, expiresIn: a.expiresIn }),
                  e.postMessage(n, "*");
              },
              [i, p.loading, g, t]
            ),
            F = (0, r.useCallback)(
              async (e) => {
                let s = { type: "requestXsollaUserTokenResponse", data: {} };
                if (!i) {
                  (s.data = {
                    error: {
                      code: "userNotAuthenticated",
                      message: "The user is not authenticated",
                    },
                  }),
                    e.postMessage(s, "*");
                  return;
                }
                if (w.loading) return;
                let n = await v({
                    variables: { gameId: t },
                    fetchPolicy: "network-only",
                  }),
                  r = n.data?.xsollaUserToken;
                if (n.error || !r) {
                  console.error("Xsolla user token retrieve error", n.error);
                  let e = n.error?.graphQLErrors?.[0]?.extensions?.code,
                    t = n.error?.graphQLErrors?.[0]?.message;
                  e
                    ? (s.data = { error: { code: e, message: t || "" } })
                    : (s.data = {
                        error: {
                          code: "unexpectedError",
                          message: "Failed to retrieve Xsolla user token",
                        },
                      });
                } else s.data = { token: r.token, expiresIn: r.expiresIn };
                e.postMessage(s, "*");
              },
              [t, v, i, w.loading]
            );
          return (
            (0, r.useEffect)(() => {
              let e = (e) => {
                  let t = () => {
                    setTimeout(() => {
                      f("signIn"),
                        y(!0),
                        k(e.source),
                        u.Z.removeFakeFullscreenListener(t);
                    }, 100);
                  };
                  u.Z.isFakeFullscreen()
                    ? u.Z.addFakeFullscreenListener(t)
                    : (f("signIn"), y(!0), k(e.source));
                },
                t = (t) => {
                  if (t.data && t.data.type === a.V)
                    switch (t.data.event) {
                      case "requestUserToken":
                        let i = t.data;
                        x(t.source, i.iframeUrl);
                        break;
                      case "requestXsollaUserToken":
                        F(t.source);
                        break;
                      case "showAuthPrompt":
                        e(t);
                        break;
                      default:
                        return;
                    }
                };
              return (
                window.addEventListener("message", t),
                function () {
                  window.removeEventListener("message", t);
                }
              );
            }, [t, i, g, f, F, x]),
            null
          );
        };
        t.Z = c;
      },
      22120: function (e, t, i) {
        var s = i(85893),
          n = i(67294),
          r = i(95129);
        t.Z = function (e) {
          let t = (t) => {
            let i = n.useContext(r.Z);
            return (0, s.jsx)(e, { device: i, ...t });
          };
          return t;
        };
      },
      92975: function (e, t, i) {
        var s = i(85893),
          n = i(67294),
          r = i(42257);
        t.Z = function (e) {
          let t = (t) => {
            let i = n.useContext(r.Z);
            return (0, s.jsx)(e, { deviceType: i, ...t });
          };
          return t;
        };
      },
      46413: function (e, t) {
        let i = new (class {
          fakeFullscreenListeners = [];
          eventKeys = [
            "fullscreenchange",
            "webkitfullscreenchange",
            "mozfullscreenchange",
            "MSFullscreenChange",
          ];
          isInFakeFullscreen = !1;
          removeFullscreenListener(e) {
            this.eventKeys.forEach((t) => {
              document.removeEventListener(t, e);
            });
          }
          addFullscreenListener(e) {
            this.eventKeys.forEach((t) => {
              document.addEventListener(t, e);
            });
          }
          addFakeFullscreenListener(e) {
            this.fakeFullscreenListeners.push(e);
          }
          removeFakeFullscreenListener(e) {
            this.fakeFullscreenListeners = this.fakeFullscreenListeners.filter(
              (t) => t !== e
            );
          }
          isFullscreen() {
            let e = window.document;
            return !!(
              e.fullscreenElement ||
              e.mozFullScreenElement ||
              e.webkitFullscreenElement ||
              e.msFullscreenElement
            );
          }
          isFakeFullscreen() {
            return this.isInFakeFullscreen;
          }
          enteredFakeFullscreen() {
            this.isInFakeFullscreen ||
              ((this.isInFakeFullscreen = !0),
              this.fakeFullscreenListeners.forEach((e) => e()));
          }
          exitFakeFullscreen() {
            this.isInFakeFullscreen &&
              ((this.isInFakeFullscreen = !1),
              this.fakeFullscreenListeners.forEach((e) => e()));
          }
          forceLockOrientation = async (e) => {
            if (
              e &&
              "BOTH" !== e &&
              "screen" in window &&
              window.screen &&
              window.screen.orientation &&
              window.screen.orientation.lock
            )
              try {
                await window.screen.orientation.lock(
                  "PORTRAIT" === e ? "portrait" : "landscape"
                );
              } catch (e) {}
          };
          exitNativeFullscreen() {
            let e = window.document,
              t =
                e.exitFullscreen ||
                e.mozCancelFullScreen ||
                e.webkitExitFullscreen ||
                e.msExitFullscreen;
            return !!t && (window.document.fullscreenElement && t.call(e), !0);
          }
        })();
        t.Z = i;
      },
      44715: function (e, t, i) {
        var s = i(85893),
          n = i(67294),
          r = i(83808);
        t.Z = function () {
          for (var e = arguments.length, t = Array(e), i = 0; i < e; i++)
            t[i] = arguments[i];
          return (e) =>
            class extends n.Component {
              static async getInitialProps(i) {
                let { trlService: s } = (0, r.b)(i);
                if (!i.req) {
                  let n = Promise.all(
                      t.map((e) => s.loadTrlMessagesToLingui(e))
                    ),
                    [r] = await Promise.all([
                      e.getInitialProps ? await e.getInitialProps(i) : {},
                      n,
                    ]);
                  return { ...r };
                }
                let n = Promise.all(t.map((e) => s.getTrlMessages(e))),
                  [a, o] = await Promise.all([
                    e.getInitialProps
                      ? e.getInitialProps(i)
                      : Promise.resolve({}),
                    n,
                  ]),
                  d = o.reduce((e, t) => Object.assign(e, t));
                return { messages: d, ...a };
              }
              render() {
                let { ...t } = this.props;
                return (0, s.jsx)(e, { ...t });
              }
            };
        };
      },
    },
  ]);
