!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "1dbf2042-df5a-4d52-8d5e-678d45aca247"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-1dbf2042-df5a-4d52-8d5e-678d45aca247"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [86507],
    {
      86507: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return A;
          },
        });
        var r = n(87462),
          o = n(63366),
          l = n(67294),
          a = n(33703),
          u = n(82690),
          s = n(59948),
          i = n(91476),
          d = n(94780),
          c = n(78385),
          f = n(74161),
          p = n(29726);
        function h(e, t) {
          t
            ? e.setAttribute("aria-hidden", "true")
            : e.removeAttribute("aria-hidden");
        }
        function m(e) {
          return (
            parseInt((0, f.Z)(e).getComputedStyle(e).paddingRight, 10) || 0
          );
        }
        function b(e, t, n, r, o) {
          let l = [t, n, ...r];
          [].forEach.call(e.children, (e) => {
            let t = -1 === l.indexOf(e),
              n = !(function (e) {
                let t =
                    -1 !==
                    [
                      "TEMPLATE",
                      "SCRIPT",
                      "STYLE",
                      "LINK",
                      "MAP",
                      "META",
                      "NOSCRIPT",
                      "PICTURE",
                      "COL",
                      "COLGROUP",
                      "PARAM",
                      "SLOT",
                      "SOURCE",
                      "TRACK",
                    ].indexOf(e.tagName),
                  n =
                    "INPUT" === e.tagName &&
                    "hidden" === e.getAttribute("type");
                return t || n;
              })(e);
            t && n && h(e, o);
          });
        }
        function y(e, t) {
          let n = -1;
          return e.some((e, r) => !!t(e) && ((n = r), !0)), n;
        }
        var g = n(85893);
        function v(e) {
          let t = [],
            n = [];
          return (
            Array.from(
              e.querySelectorAll(
                'input,select,textarea,a[href],button,[tabindex],audio[controls],video[controls],[contenteditable]:not([contenteditable="false"])'
              )
            ).forEach((e, r) => {
              let o = (function (e) {
                let t = parseInt(e.getAttribute("tabindex"), 10);
                return Number.isNaN(t)
                  ? "true" === e.contentEditable ||
                    (("AUDIO" === e.nodeName ||
                      "VIDEO" === e.nodeName ||
                      "DETAILS" === e.nodeName) &&
                      null === e.getAttribute("tabindex"))
                    ? 0
                    : e.tabIndex
                  : t;
              })(e);
              -1 === o ||
                e.disabled ||
                ("INPUT" === e.tagName && "hidden" === e.type) ||
                (function (e) {
                  if ("INPUT" !== e.tagName || "radio" !== e.type || !e.name)
                    return !1;
                  let t = (t) =>
                      e.ownerDocument.querySelector(`input[type="radio"]${t}`),
                    n = t(`[name="${e.name}"]:checked`);
                  return n || (n = t(`[name="${e.name}"]`)), n !== e;
                })(e) ||
                (0 === o
                  ? t.push(e)
                  : n.push({ documentOrder: r, tabIndex: o, node: e }));
            }),
            n
              .sort((e, t) =>
                e.tabIndex === t.tabIndex
                  ? e.documentOrder - t.documentOrder
                  : e.tabIndex - t.tabIndex
              )
              .map((e) => e.node)
              .concat(t)
          );
        }
        function E() {
          return !0;
        }
        var x = function (e) {
            let {
                children: t,
                disableAutoFocus: n = !1,
                disableEnforceFocus: r = !1,
                disableRestoreFocus: o = !1,
                getTabbable: s = v,
                isEnabled: i = E,
                open: d,
              } = e,
              c = l.useRef(),
              f = l.useRef(null),
              p = l.useRef(null),
              h = l.useRef(null),
              m = l.useRef(null),
              b = l.useRef(!1),
              y = l.useRef(null),
              x = (0, a.Z)(t.ref, y),
              w = l.useRef(null);
            l.useEffect(() => {
              d && y.current && (b.current = !n);
            }, [n, d]),
              l.useEffect(() => {
                if (!d || !y.current) return;
                let e = (0, u.Z)(y.current);
                return (
                  !y.current.contains(e.activeElement) &&
                    (y.current.hasAttribute("tabIndex") ||
                      y.current.setAttribute("tabIndex", -1),
                    b.current && y.current.focus()),
                  () => {
                    o ||
                      (h.current &&
                        h.current.focus &&
                        ((c.current = !0), h.current.focus()),
                      (h.current = null));
                  }
                );
              }, [d]),
              l.useEffect(() => {
                if (!d || !y.current) return;
                let e = (0, u.Z)(y.current),
                  t = (t) => {
                    let { current: n } = y;
                    if (null !== n) {
                      if (!e.hasFocus() || r || !i() || c.current) {
                        c.current = !1;
                        return;
                      }
                      if (!n.contains(e.activeElement)) {
                        if (
                          (t && m.current !== t.target) ||
                          e.activeElement !== m.current
                        )
                          m.current = null;
                        else if (null !== m.current) return;
                        if (!b.current) return;
                        let r = [];
                        if (
                          ((e.activeElement === f.current ||
                            e.activeElement === p.current) &&
                            (r = s(y.current)),
                          r.length > 0)
                        ) {
                          var o, l;
                          let e = Boolean(
                              (null == (o = w.current) ? void 0 : o.shiftKey) &&
                                (null == (l = w.current) ? void 0 : l.key) ===
                                  "Tab"
                            ),
                            t = r[0],
                            n = r[r.length - 1];
                          e ? n.focus() : t.focus();
                        } else n.focus();
                      }
                    }
                  },
                  n = (t) => {
                    (w.current = t),
                      !r &&
                        i() &&
                        "Tab" === t.key &&
                        e.activeElement === y.current &&
                        t.shiftKey &&
                        ((c.current = !0), p.current.focus());
                  };
                e.addEventListener("focusin", t),
                  e.addEventListener("keydown", n, !0);
                let o = setInterval(() => {
                  "BODY" === e.activeElement.tagName && t();
                }, 50);
                return () => {
                  clearInterval(o),
                    e.removeEventListener("focusin", t),
                    e.removeEventListener("keydown", n, !0);
                };
              }, [n, r, o, i, d, s]);
            let R = (e) => {
                null === h.current && (h.current = e.relatedTarget),
                  (b.current = !0),
                  (m.current = e.target);
                let n = t.props.onFocus;
                n && n(e);
              },
              M = (e) => {
                null === h.current && (h.current = e.relatedTarget),
                  (b.current = !0);
              };
            return (0, g.jsxs)(l.Fragment, {
              children: [
                (0, g.jsx)("div", {
                  tabIndex: d ? 0 : -1,
                  onFocus: M,
                  ref: f,
                  "data-testid": "sentinelStart",
                }),
                l.cloneElement(t, { ref: x, onFocus: R }),
                (0, g.jsx)("div", {
                  tabIndex: d ? 0 : -1,
                  onFocus: M,
                  ref: p,
                  "data-testid": "sentinelEnd",
                }),
              ],
            });
          },
          w = n(1588),
          R = n(34867);
        function M(e) {
          return (0, R.ZP)("MuiModal", e);
        }
        (0, w.Z)("MuiModal", ["root", "hidden"]);
        var Z = n(44922);
        let I = [
            "children",
            "classes",
            "closeAfterTransition",
            "component",
            "container",
            "disableAutoFocus",
            "disableEnforceFocus",
            "disableEscapeKeyDown",
            "disablePortal",
            "disableRestoreFocus",
            "disableScrollLock",
            "hideBackdrop",
            "keepMounted",
            "manager",
            "onBackdropClick",
            "onClose",
            "onKeyDown",
            "open",
            "onTransitionEnter",
            "onTransitionExited",
            "slotProps",
            "slots",
          ],
          k = (e) => {
            let { open: t, exited: n, classes: r } = e;
            return (0, d.Z)({ root: ["root", !t && n && "hidden"] }, M, r);
          },
          T = new (class {
            constructor() {
              (this.containers = void 0),
                (this.modals = void 0),
                (this.modals = []),
                (this.containers = []);
            }
            add(e, t) {
              let n = this.modals.indexOf(e);
              if (-1 !== n) return n;
              (n = this.modals.length),
                this.modals.push(e),
                e.modalRef && h(e.modalRef, !1);
              let r = (function (e) {
                let t = [];
                return (
                  [].forEach.call(e.children, (e) => {
                    "true" === e.getAttribute("aria-hidden") && t.push(e);
                  }),
                  t
                );
              })(t);
              b(t, e.mount, e.modalRef, r, !0);
              let o = y(this.containers, (e) => e.container === t);
              return -1 !== o
                ? (this.containers[o].modals.push(e), n)
                : (this.containers.push({
                    modals: [e],
                    container: t,
                    restore: null,
                    hiddenSiblings: r,
                  }),
                  n);
            }
            mount(e, t) {
              let n = y(this.containers, (t) => -1 !== t.modals.indexOf(e)),
                r = this.containers[n];
              r.restore ||
                (r.restore = (function (e, t) {
                  let n = [],
                    r = e.container;
                  if (!t.disableScrollLock) {
                    let e;
                    if (
                      (function (e) {
                        let t = (0, u.Z)(e);
                        return t.body === e
                          ? (0, f.Z)(e).innerWidth >
                              t.documentElement.clientWidth
                          : e.scrollHeight > e.clientHeight;
                      })(r)
                    ) {
                      let e = (0, p.Z)((0, u.Z)(r));
                      n.push({
                        value: r.style.paddingRight,
                        property: "padding-right",
                        el: r,
                      }),
                        (r.style.paddingRight = `${m(r) + e}px`);
                      let t = (0, u.Z)(r).querySelectorAll(".mui-fixed");
                      [].forEach.call(t, (t) => {
                        n.push({
                          value: t.style.paddingRight,
                          property: "padding-right",
                          el: t,
                        }),
                          (t.style.paddingRight = `${m(t) + e}px`);
                      });
                    }
                    if (r.parentNode instanceof DocumentFragment)
                      e = (0, u.Z)(r).body;
                    else {
                      let t = r.parentElement,
                        n = (0, f.Z)(r);
                      e =
                        (null == t ? void 0 : t.nodeName) === "HTML" &&
                        "scroll" === n.getComputedStyle(t).overflowY
                          ? t
                          : r;
                    }
                    n.push(
                      { value: e.style.overflow, property: "overflow", el: e },
                      {
                        value: e.style.overflowX,
                        property: "overflow-x",
                        el: e,
                      },
                      {
                        value: e.style.overflowY,
                        property: "overflow-y",
                        el: e,
                      }
                    ),
                      (e.style.overflow = "hidden");
                  }
                  let o = () => {
                    n.forEach(({ value: e, el: t, property: n }) => {
                      e ? t.style.setProperty(n, e) : t.style.removeProperty(n);
                    });
                  };
                  return o;
                })(r, t));
            }
            remove(e, t = !0) {
              let n = this.modals.indexOf(e);
              if (-1 === n) return n;
              let r = y(this.containers, (t) => -1 !== t.modals.indexOf(e)),
                o = this.containers[r];
              if (
                (o.modals.splice(o.modals.indexOf(e), 1),
                this.modals.splice(n, 1),
                0 === o.modals.length)
              )
                o.restore && o.restore(),
                  e.modalRef && h(e.modalRef, t),
                  b(o.container, e.mount, e.modalRef, o.hiddenSiblings, !1),
                  this.containers.splice(r, 1);
              else {
                let e = o.modals[o.modals.length - 1];
                e.modalRef && h(e.modalRef, !1);
              }
              return n;
            }
            isTopModal(e) {
              return (
                this.modals.length > 0 &&
                this.modals[this.modals.length - 1] === e
              );
            }
          })(),
          P = l.forwardRef(function (e, t) {
            var n, d;
            let {
                children: f,
                classes: p,
                closeAfterTransition: m = !1,
                component: b,
                container: y,
                disableAutoFocus: v = !1,
                disableEnforceFocus: E = !1,
                disableEscapeKeyDown: w = !1,
                disablePortal: R = !1,
                disableRestoreFocus: M = !1,
                disableScrollLock: P = !1,
                hideBackdrop: A = !1,
                keepMounted: N = !1,
                manager: O = T,
                onBackdropClick: _,
                onClose: S,
                onKeyDown: C,
                open: D,
                onTransitionEnter: L,
                onTransitionExited: F,
                slotProps: K = {},
                slots: j = {},
              } = e,
              G = (0, o.Z)(e, I),
              [U, B] = l.useState(!0),
              $ = l.useRef({}),
              W = l.useRef(null),
              Y = l.useRef(null),
              q = (0, a.Z)(Y, t),
              H = !!e.children && e.children.props.hasOwnProperty("in"),
              V = null == (n = e["aria-hidden"]) || n,
              z = () => (0, u.Z)(W.current),
              X = () => (
                ($.current.modalRef = Y.current),
                ($.current.mountNode = W.current),
                $.current
              ),
              J = () => {
                O.mount(X(), { disableScrollLock: P }),
                  (Y.current.scrollTop = 0);
              },
              Q = (0, s.Z)(() => {
                let e = ("function" == typeof y ? y() : y) || z().body;
                O.add(X(), e), Y.current && J();
              }),
              ee = l.useCallback(() => O.isTopModal(X()), [O]),
              et = (0, s.Z)((e) => {
                (W.current = e), e && (D && ee() ? J() : h(Y.current, V));
              }),
              en = l.useCallback(() => {
                O.remove(X(), V);
              }, [O, V]);
            l.useEffect(
              () => () => {
                en();
              },
              [en]
            ),
              l.useEffect(() => {
                D ? Q() : (H && m) || en();
              }, [D, en, H, m, Q]);
            let er = (0, r.Z)({}, e, {
                classes: p,
                closeAfterTransition: m,
                disableAutoFocus: v,
                disableEnforceFocus: E,
                disableEscapeKeyDown: w,
                disablePortal: R,
                disableRestoreFocus: M,
                disableScrollLock: P,
                exited: U,
                hideBackdrop: A,
                keepMounted: N,
              }),
              eo = k(er),
              el = () => {
                B(!1), L && L();
              },
              ea = () => {
                B(!0), F && F(), m && en();
              },
              eu = (e) => {
                e.target === e.currentTarget &&
                  (_ && _(e), S && S(e, "backdropClick"));
              },
              es = (e) => {
                C && C(e),
                  "Escape" === e.key &&
                    ee() &&
                    !w &&
                    (e.stopPropagation(), S && S(e, "escapeKeyDown"));
              },
              ei = {};
            void 0 === f.props.tabIndex && (ei.tabIndex = "-1"),
              H &&
                ((ei.onEnter = (0, i.Z)(el, f.props.onEnter)),
                (ei.onExited = (0, i.Z)(ea, f.props.onExited)));
            let ed = null != (d = null != b ? b : j.root) ? d : "div",
              ec = (0, Z.Z)({
                elementType: ed,
                externalSlotProps: K.root,
                externalForwardedProps: G,
                additionalProps: {
                  ref: q,
                  role: "presentation",
                  onKeyDown: es,
                },
                className: eo.root,
                ownerState: er,
              }),
              ef = j.backdrop,
              ep = (0, Z.Z)({
                elementType: ef,
                externalSlotProps: K.backdrop,
                additionalProps: { "aria-hidden": !0, onClick: eu, open: D },
                className: eo.backdrop,
                ownerState: er,
              });
            return N || D || (H && !U)
              ? (0, g.jsx)(c.Z, {
                  ref: et,
                  container: y,
                  disablePortal: R,
                  children: (0, g.jsxs)(
                    ed,
                    (0, r.Z)({}, ec, {
                      children: [
                        !A && ef ? (0, g.jsx)(ef, (0, r.Z)({}, ep)) : null,
                        (0, g.jsx)(x, {
                          disableEnforceFocus: E,
                          disableAutoFocus: v,
                          disableRestoreFocus: M,
                          isEnabled: ee,
                          open: D,
                          children: l.cloneElement(f, ei),
                        }),
                      ],
                    })
                  ),
                })
              : null;
          });
        var A = P;
      },
      91476: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return r;
          },
        });
        function r(...e) {
          return e.reduce(
            (e, t) =>
              null == t
                ? e
                : function (...n) {
                    e.apply(this, n), t.apply(this, n);
                  },
            () => {}
          );
        }
      },
      29726: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return r;
          },
        });
        function r(e) {
          let t = e.documentElement.clientWidth;
          return Math.abs(window.innerWidth - t);
        }
      },
      74161: function (e, t, n) {
        n.d(t, {
          Z: function () {
            return o;
          },
        });
        var r = n(82690);
        function o(e) {
          let t = (0, r.Z)(e);
          return t.defaultView || window;
        }
      },
      59948: function (e, t, n) {
        var r = n(67294),
          o = n(73546);
        t.Z = function (e) {
          let t = r.useRef(e);
          return (
            (0, o.Z)(() => {
              t.current = e;
            }),
            r.useRef((...e) => (0, t.current)(...e)).current
          );
        };
      },
    },
  ]);
