!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "2f619e51-1576-4465-b403-5b9e74a05e5a"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-2f619e51-1576-4465-b403-5b9e74a05e5a"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [89235],
    {
      93946: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return w;
          },
        });
        var o = n(63366),
          i = n(87462),
          l = n(67294),
          r = n(90512),
          a = n(94780),
          s = n(2101),
          d = n(90948),
          u = n(71657),
          c = n(49990),
          f = n(98216),
          C = n(1588),
          h = n(34867);
        function p(e) {
          return (0, h.ZP)("MuiIconButton", e);
        }
        let g = (0, C.Z)("MuiIconButton", [
          "root",
          "disabled",
          "colorInherit",
          "colorPrimary",
          "colorSecondary",
          "colorError",
          "colorInfo",
          "colorSuccess",
          "colorWarning",
          "edgeStart",
          "edgeEnd",
          "sizeSmall",
          "sizeMedium",
          "sizeLarge",
        ]);
        var y = n(85893);
        let _ = [
            "edge",
            "children",
            "className",
            "color",
            "disabled",
            "disableFocusRipple",
            "size",
          ],
          m = (e) => {
            let { classes: t, disabled: n, color: o, edge: i, size: l } = e,
              r = {
                root: [
                  "root",
                  n && "disabled",
                  "default" !== o && `color${(0, f.Z)(o)}`,
                  i && `edge${(0, f.Z)(i)}`,
                  `size${(0, f.Z)(l)}`,
                ],
              };
            return (0, a.Z)(r, p, t);
          },
          v = (0, d.ZP)(c.Z, {
            name: "MuiIconButton",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.root,
                "default" !== n.color && t[`color${(0, f.Z)(n.color)}`],
                n.edge && t[`edge${(0, f.Z)(n.edge)}`],
                t[`size${(0, f.Z)(n.size)}`],
              ];
            },
          })(
            ({ theme: e, ownerState: t }) =>
              (0, i.Z)(
                {
                  textAlign: "center",
                  flex: "0 0 auto",
                  fontSize: e.typography.pxToRem(24),
                  padding: 8,
                  borderRadius: "50%",
                  overflow: "visible",
                  color: (e.vars || e).palette.action.active,
                  transition: e.transitions.create("background-color", {
                    duration: e.transitions.duration.shortest,
                  }),
                },
                !t.disableRipple && {
                  "&:hover": {
                    backgroundColor: e.vars
                      ? `rgba(${e.vars.palette.action.activeChannel} / ${e.vars.palette.action.hoverOpacity})`
                      : (0, s.Fq)(
                          e.palette.action.active,
                          e.palette.action.hoverOpacity
                        ),
                    "@media (hover: none)": { backgroundColor: "transparent" },
                  },
                },
                "start" === t.edge && {
                  marginLeft: "small" === t.size ? -3 : -12,
                },
                "end" === t.edge && {
                  marginRight: "small" === t.size ? -3 : -12,
                }
              ),
            ({ theme: e, ownerState: t }) => {
              var n;
              let o = null == (n = (e.vars || e).palette) ? void 0 : n[t.color];
              return (0, i.Z)(
                {},
                "inherit" === t.color && { color: "inherit" },
                "inherit" !== t.color &&
                  "default" !== t.color &&
                  (0, i.Z)(
                    { color: null == o ? void 0 : o.main },
                    !t.disableRipple && {
                      "&:hover": (0, i.Z)(
                        {},
                        o && {
                          backgroundColor: e.vars
                            ? `rgba(${o.mainChannel} / ${e.vars.palette.action.hoverOpacity})`
                            : (0, s.Fq)(o.main, e.palette.action.hoverOpacity),
                        },
                        {
                          "@media (hover: none)": {
                            backgroundColor: "transparent",
                          },
                        }
                      ),
                    }
                  ),
                "small" === t.size && {
                  padding: 5,
                  fontSize: e.typography.pxToRem(18),
                },
                "large" === t.size && {
                  padding: 12,
                  fontSize: e.typography.pxToRem(28),
                },
                {
                  [`&.${g.disabled}`]: {
                    backgroundColor: "transparent",
                    color: (e.vars || e).palette.action.disabled,
                  },
                }
              );
            }
          ),
          x = l.forwardRef(function (e, t) {
            let n = (0, u.Z)({ props: e, name: "MuiIconButton" }),
              {
                edge: l = !1,
                children: a,
                className: s,
                color: d = "default",
                disabled: c = !1,
                disableFocusRipple: f = !1,
                size: C = "medium",
              } = n,
              h = (0, o.Z)(n, _),
              p = (0, i.Z)({}, n, {
                edge: l,
                color: d,
                disabled: c,
                disableFocusRipple: f,
                size: C,
              }),
              g = m(p);
            return (0,
            y.jsx)(v, (0, i.Z)({ className: (0, r.Z)(g.root, s), centerRipple: !0, focusRipple: !f, disabled: c, ref: t }, h, { ownerState: p, children: a }));
          });
        var w = x;
      },
      59948: function (e, t, n) {
        "use strict";
        var o = n(67294),
          i = n(73546);
        t.Z = function (e) {
          let t = o.useRef(e);
          return (
            (0, i.Z)(() => {
              t.current = e;
            }),
            o.useRef((...e) => (0, t.current)(...e)).current
          );
        };
      },
      28281: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return l;
          },
        });
        var o = n(20918),
          i = n(19167);
        let l = "seenChristmasDiscordModal2024",
          r = (e, t) => {
            let n = new URL(window.location.href),
              r = !!n.searchParams.get("forceChristmasWeek");
            if (r) return !0;
            if ("en-US" !== t) return !1;
            let a = i.Z.Instance.getItem(l);
            return !a && (0, o.zV)() && e >= 396e5;
          };
        t.Z = r;
      },
      39465: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return V;
            },
          });
        var o = n(85893),
          i = n(67294),
          l = n(90948),
          r = n(3411);
        let a = (0, l.ZP)("div", { shouldForwardProp: (e) => "open" !== e })(
            (e) => {
              let { open: t } = e;
              return {
                bottom: t ? 20 : -500,
                transition: "bottom 0.8s ease-out",
                position: "fixed",
                zIndex: 9,
                display: "flex",
                justifyContent: "center",
                width: "100%",
              };
            }
          ),
          s = (0, l.ZP)("div")({
            width: "min(555px,100vw)",
            height: 78,
            background: r.D.brand[100],
            borderRadius: 20,
            boxShadow: "0 14px 40px 0 rgb(0 0 0 / 90%)",
            display: "flex",
            alignItems: "center",
          }),
          d = i.memo((e) => {
            let { style: t } = e;
            return (0, o.jsxs)("svg", {
              style: t,
              width: "73",
              height: "57",
              viewBox: "0 0 73 57",
              fill: "none",
              xmlns: "http://www.w3.org/2000/svg",
              children: [
                (0, o.jsxs)("g", {
                  filter: "url(#filter0_d_20_692)",
                  children: [
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M56.1276 7.97304C56.1775 7.82791 56.5568 6.99722 56.6267 6.43676C56.8113 5.01057 48.2769 3.22908 48.0972 4.65527L47.9276 5.99138L56.1276 7.97304Z",
                      fill: "#D0D0D0",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M18.0821 7.7478C18.0372 7.60268 17.6678 6.76198 17.6029 6.20151C17.4382 4.77032 26.0026 3.11894 26.1623 4.55013L26.312 5.88625L18.0871 7.7478H18.0821Z",
                      fill: "#D0D0D0",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M37.1822 7.32747C35.9594 7.30245 31.3828 7.18235 30.6691 6.87209C29.8556 6.5168 27.8243 5.15066 27.1954 4.98552C24.8048 4.365 18.1619 5.34082 17.014 7.31746C17.014 7.31746 13.5354 14.5335 12.0331 22.0197C10.5309 29.5009 10.9052 34.4851 11.6388 36.5668C12.3775 38.6486 13.216 39.5093 14.5036 39.6444C15.7913 39.7795 17.2985 39.3842 20.1733 37.5477C23.043 35.7111 24.4754 33.4242 28.0688 32.1281C30.689 31.1823 34.9063 31.1223 36.9975 31.1573C39.0887 31.1523 43.306 31.2774 45.9112 32.2632C49.4797 33.6144 50.8772 35.9213 53.722 37.8029C56.5668 39.6844 58.069 40.1048 59.3567 39.9897C60.6443 39.8746 61.4978 39.0289 62.2713 36.9572C63.0399 34.8854 63.4841 29.9113 62.0967 22.405C60.7092 14.8988 57.3403 7.62772 57.3403 7.62772C56.2274 5.63606 49.5995 4.56017 47.1989 5.14065C46.57 5.29077 44.5188 6.63189 43.7003 6.97217C42.9816 7.27243 38.4049 7.32247 37.1822 7.32747Z",
                      fill: "#BBC6DC",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M37.1822 7.32747C35.9594 7.30245 31.3828 7.18235 30.6691 6.87209C29.8556 6.5168 27.8243 5.15066 27.1954 4.98552C24.8048 4.365 18.1619 5.34082 17.014 7.31746C17.014 7.31746 13.5354 14.5335 12.0331 22.0197C11.4242 25.0773 11.1198 27.7145 11.03 29.9113C11.0899 31.8779 11.3394 33.3291 11.6588 34.2299C12.3975 36.3116 13.2359 37.1723 14.5236 37.3075C15.8112 37.4426 17.3185 37.0422 20.1932 35.2057C23.063 33.3692 24.4954 31.0823 28.0888 29.7862C30.709 28.8404 34.9263 28.7803 37.0175 28.8154C39.1087 28.8154 43.326 28.9355 45.9312 29.9213C49.4997 31.2724 50.8971 33.5793 53.7419 35.4609C56.5867 37.3425 58.089 37.7628 59.3766 37.6477C60.6643 37.5326 61.5227 36.6869 62.2913 34.6152C62.6257 33.7145 62.8952 32.2683 62.9851 30.3066C62.9252 28.1098 62.6656 25.4626 62.1017 22.395C60.7142 14.8888 57.3454 7.61771 57.3454 7.61771C56.2324 5.62605 49.6045 4.55016 47.2039 5.13064C46.575 5.28077 44.5238 6.62188 43.7053 6.96217C42.9866 7.26242 38.4099 7.31246 37.1872 7.31746L37.1822 7.32747Z",
                      fill: "url(#paint0_linear_20_692)",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M23.1578 17.9313C25.259 17.9463 26.9808 16.2449 27.0008 14.1382C27.0157 12.0314 25.3188 10.3 23.2177 10.2849C21.1165 10.2699 19.3897 11.9714 19.3747 14.0781C19.3597 16.1849 21.0566 17.9113 23.1578 17.9313Z",
                      fill: "#B9C1D0",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M23.1628 16.7804C24.6301 16.7904 25.8329 15.5994 25.8479 14.1282C25.8579 12.6569 24.67 11.4459 23.2027 11.4359C21.7354 11.4259 20.5276 12.6169 20.5176 14.0881C20.5076 15.5594 21.6955 16.7654 23.1628 16.7804Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M44.7683 27.7895C46.8994 27.8045 48.6562 26.0731 48.6712 23.9363C48.6862 21.7995 46.9643 20.0431 44.8282 20.023C42.6971 20.008 40.9453 21.7345 40.9253 23.8763C40.9104 26.013 42.6372 27.7745 44.7683 27.7895Z",
                      fill: "#B9C1D0",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M44.7783 26.6186C46.2656 26.6286 47.4933 25.4176 47.5033 23.9263C47.5133 22.4351 46.3055 21.204 44.8182 21.194C43.3309 21.184 42.1032 22.39 42.0932 23.8863C42.0832 25.3775 43.291 26.6085 44.7783 26.6186Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M30.7589 27.6994C32.9749 27.7145 34.7915 25.923 34.8065 23.7011C34.8215 21.4843 33.0348 19.6577 30.8188 19.6427C28.6078 19.6277 26.7912 21.4192 26.7712 23.6411C26.7562 25.8579 28.543 27.6844 30.7589 27.6994Z",
                      fill: "#B9C1D0",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M31.9617 20.6386C31.9018 22.4551 31.9517 22.4851 33.7984 22.4501C33.9531 22.8354 34.0379 23.2558 34.0379 23.6961C34.0379 24.1165 33.9531 24.5218 33.8034 24.8921C31.9218 24.8271 31.8869 24.8571 31.9218 26.7236C31.5624 26.8588 31.1732 26.9288 30.7689 26.9238C30.3147 26.9238 29.8755 26.8237 29.4813 26.6486C29.5411 24.8821 29.4912 24.8121 27.7644 24.8421C27.6246 24.4718 27.5448 24.0664 27.5498 23.6461C27.5498 23.2057 27.6446 22.7854 27.8043 22.4051C29.4962 22.4601 29.5611 22.385 29.5312 20.6736C29.9304 20.5035 30.3646 20.4134 30.8188 20.4134C31.2231 20.4134 31.6074 20.4935 31.9667 20.6336L31.9617 20.6386Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M52.1199 11.6161C53.1779 11.6261 54.0414 10.7653 54.0513 9.70947C54.0613 8.65359 53.2079 7.78286 52.1498 7.77285C51.0917 7.76284 50.2283 8.61856 50.2183 9.67944C50.2084 10.7353 51.0668 11.606 52.1199 11.6161Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M47.8177 15.5543C48.8758 15.5644 49.7392 14.7086 49.7492 13.6478C49.7592 12.5919 48.9058 11.7212 47.8477 11.7111C46.7946 11.7011 45.9262 12.5619 45.9162 13.6177C45.9062 14.6736 46.7597 15.5443 47.8177 15.5543Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M52.055 19.7729C53.1131 19.7829 53.9765 18.9271 53.9865 17.8663C53.9964 16.8054 53.143 15.9397 52.0849 15.9297C51.0319 15.9196 50.1634 16.7754 50.1535 17.8362C50.1435 18.8921 50.9969 19.7628 52.055 19.7729Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M56.1076 15.6143C57.1657 15.6244 58.0291 14.7636 58.0391 13.7078C58.0491 12.6519 57.1956 11.7812 56.1376 11.7711C55.0795 11.7611 54.2161 12.6168 54.2061 13.6777C54.1961 14.7336 55.0495 15.6043 56.1076 15.6143Z",
                      fill: "#767A8E",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M33.7534 16.5402C34.3424 16.5402 34.8265 16.0698 34.8265 15.4793C34.8315 14.8888 34.3573 14.4034 33.7684 14.3984C33.1795 14.3984 32.6954 14.8688 32.6904 15.4593C32.6904 16.0498 33.1595 16.5352 33.7484 16.5352L33.7534 16.5402Z",
                      fill: "#B9C1D0",
                    }),
                    (0, o.jsx)("path", {
                      fillRule: "evenodd",
                      clipRule: "evenodd",
                      d: "M40.4412 16.6202C41.0451 16.6202 41.5442 16.1348 41.5492 15.5293C41.5492 14.9238 41.0651 14.4234 40.4562 14.4184C39.8523 14.4184 39.3532 14.9038 39.3482 15.5143C39.3432 16.1198 39.8323 16.6202 40.4362 16.6252L40.4412 16.6202Z",
                      fill: "#B9C1D0",
                    }),
                  ],
                }),
                (0, o.jsxs)("defs", {
                  children: [
                    (0, o.jsxs)("filter", {
                      id: "filter0_d_20_692",
                      x: "0.997498",
                      y: "0",
                      width: "71.9981",
                      height: "56.0072",
                      filterUnits: "userSpaceOnUse",
                      colorInterpolationFilters: "sRGB",
                      children: [
                        (0, o.jsx)("feFlood", {
                          floodOpacity: "0",
                          result: "BackgroundImageFix",
                        }),
                        (0, o.jsx)("feColorMatrix", {
                          in: "SourceAlpha",
                          type: "matrix",
                          values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
                          result: "hardAlpha",
                        }),
                        (0, o.jsx)("feOffset", { dy: "6" }),
                        (0, o.jsx)("feGaussianBlur", { stdDeviation: "5" }),
                        (0, o.jsx)("feComposite", {
                          in2: "hardAlpha",
                          operator: "out",
                        }),
                        (0, o.jsx)("feColorMatrix", {
                          type: "matrix",
                          values:
                            "0 0 0 0 0.320524 0 0 0 0 0.189375 0 0 0 0 0.841667 0 0 0 1 0",
                        }),
                        (0, o.jsx)("feBlend", {
                          mode: "normal",
                          in2: "BackgroundImageFix",
                          result: "effect1_dropShadow_20_692",
                        }),
                        (0, o.jsx)("feBlend", {
                          mode: "normal",
                          in: "SourceGraphic",
                          in2: "effect1_dropShadow_20_692",
                          result: "shape",
                        }),
                      ],
                    }),
                    (0, o.jsxs)("linearGradient", {
                      id: "paint0_linear_20_692",
                      x1: "37.0075",
                      y1: "4.79999",
                      x2: "37.0075",
                      y2: "37.6653",
                      gradientUnits: "userSpaceOnUse",
                      children: [
                        (0, o.jsx)("stop", { stopColor: "white" }),
                        (0, o.jsx)("stop", {
                          offset: "1",
                          stopColor: "#DDE8FC",
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            });
          });
        var u = n(94745),
          c = n(21519),
          f = n(93946),
          C = n(43740),
          h = n(63306),
          p = n(11163),
          g = n(83514),
          y = n(19167),
          _ = n(37899),
          m = n(2978),
          v = n(88296),
          x = n(88347),
          w = n.n(x);
        let Z = "controllerCloseCounter",
          b = "controllerPreventNotification",
          z = () => {
            let [e, t] = i.useState(!1),
              { routeHelper: n } = i.useContext(h.Z),
              { pageUrlHelper: l } = i.useContext(g.t),
              { crazyAnalyticsService: x } = i.useContext(_.Z).services;
            i.useEffect(() => {
              let e;
              if (!x) return;
              let n = l.isOnSpecificTagOrCategoryPage("controller"),
                o = l.isGamePage(),
                i = (i) => {
                  if (!n && !o) {
                    if (!i) {
                      let e = y.Z.Instance.getItem(b) || "false";
                      if (JSON.parse(e)) return;
                    }
                    x.controllerNotificationDisplayed(),
                      t(!0),
                      (e = window.setTimeout(() => t(!1), 7e3));
                  }
                },
                r = new URL(window.location.href);
              r.searchParams.has("forceController") && i();
              let a = () => {
                  i(!0);
                },
                s = () => {
                  t(!1);
                };
              p.Router.events.on("routeChangeStart", s);
              let d = navigator.getGamepads();
              for (let e of d)
                if (e && e.connected) {
                  i();
                  break;
                }
              return (
                window.addEventListener("gamepadconnected", a),
                function () {
                  e && window.clearTimeout(e),
                    window.removeEventListener("gamepadconnected", a),
                    p.Router.events.off("routeChangeStart", s);
                }
              );
            }, [l, x]);
            let z = () => {
                x.controllerNotificationClose();
                let e = Number(y.Z.Instance.getItem(Z));
                e && e + 1 === 3
                  ? y.Z.Instance.setItem(b, "true")
                  : y.Z.Instance.setItem(Z, (e ? e + 1 : 1).toString()),
                  t(!1);
              },
              R = () => {
                x.controllerNotificationExplore();
              },
              B = n.tagPageDirectLink("controller");
            return (0, o.jsx)(a, {
              open: e,
              children: (0, o.jsxs)(s, {
                children: [
                  (0, o.jsx)(d, {
                    style: { marginLeft: 8, marginTop: 14, marginRight: 6 },
                  }),
                  (0, o.jsxs)("div", {
                    children: [
                      (0, o.jsx)("div", {
                        style: { fontWeight: 900, fontSize: 16 },
                        children: (0, o.jsx)(u.cC, {
                          id: "common.controller.title",
                        }),
                      }),
                      (0, o.jsx)("div", {
                        style: {
                          fontWeight: 400,
                          fontSize: 14,
                          color: r.D.brand[30],
                        },
                        children: (0, o.jsx)(u.cC, {
                          id: "common.controller.message",
                        }),
                      }),
                    ],
                  }),
                  (0, o.jsx)(m.Z, {
                    ...B,
                    children: (0, o.jsx)(v.Z, {
                      className: w().button,
                      variant: "contained",
                      color: "white",
                      height: 34,
                      onClick: R,
                      children: (0, o.jsx)(u.cC, {
                        id: "common.controller.button",
                      }),
                    }),
                  }),
                  (0, o.jsx)(c.Z, { orientation: "vertical" }),
                  (0, o.jsx)(f.Z, {
                    style: { marginLeft: 4 },
                    onClick: z,
                    children: (0, o.jsx)(C.Z, {
                      style: { height: 20, width: 20 },
                    }),
                  }),
                ],
              }),
            });
          };
        var R = n(5152),
          B = n.n(R),
          j = n(8697),
          M = n(42257),
          S = n(28441),
          k = n(57270),
          I = n(74040),
          D = n(28281),
          N = n(30893),
          P = n(13422),
          G = n(18335),
          L = n(59834),
          O = n(33209),
          E = n(86813),
          U = n(58104),
          T = n(26579);
        let F = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(76025)]).then(
                n.bind(n, 420)
              ),
            {
              loadableGenerated: { webpack: () => [420] },
              loading: () => null,
              ssr: !1,
            }
          ),
          A = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(93736)]).then(
                n.bind(n, 99990)
              ),
            {
              loadableGenerated: { webpack: () => [99990] },
              loading: () => null,
              ssr: !1,
            }
          ),
          Q = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(10188)]).then(
                n.bind(n, 91215)
              ),
            {
              loadableGenerated: { webpack: () => [91215] },
              loading: () => null,
              ssr: !1,
            }
          ),
          $ = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(3802)]).then(
                n.bind(n, 45859)
              ),
            {
              loadableGenerated: { webpack: () => [45859] },
              loading: () => null,
              ssr: !1,
            }
          ),
          q = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(53020)]).then(
                n.bind(n, 21226)
              ),
            {
              loadableGenerated: { webpack: () => [21226] },
              loading: () => null,
              ssr: !1,
            }
          ),
          W = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(35601)]).then(
                n.bind(n, 60244)
              ),
            {
              loadableGenerated: { webpack: () => [60244] },
              loading: () => null,
              ssr: !1,
            }
          ),
          J = B()(
            () =>
              Promise.all([n.e(48649), n.e(68627), n.e(91051)]).then(
                n.bind(n, 13572)
              ),
            {
              loadableGenerated: { webpack: () => [13572] },
              loading: () => null,
              ssr: !1,
            }
          ),
          H = () => {
            let [e, t] = i.useState(!1),
              { locale: n } = i.useContext(j.Z),
              { gamesPlayedService: l } = i.useContext(_.Z).services,
              { recent: r } = i.useContext(P.rh),
              { user: a } = i.useContext(I.S),
              { countryCode: s } = i.useContext(T.Z),
              d = i.useContext(M.Z),
              { pageUrlHelper: u } = i.useContext(g.t),
              c = u.routeData.hostname,
              f = c ? (0, O.Jx)(c) : n,
              C = (0, U.G3)(s),
              h = l.getTotalRecentPlayedTime(r);
            if (
              (i.useEffect(() => {
                t(!0);
              }, []),
              !e)
            )
              return null;
            if ((0, L.Z)(h, d, !!a, f)) return (0, o.jsx)(W, {});
            if ((0, G.Z)(h, !!a)) return (0, o.jsx)(q, {});
            if ((0, E.Z)(h, C)) return (0, o.jsx)(J, {});
            if ((0, N.Z)(h, f, !!a)) return (0, o.jsx)($, {});
            if ((0, D.Z)(h, f)) return (0, o.jsx)(Q, {});
            if ((0, k.Z)(f, h, !!a)) return (0, o.jsx)(F, {});
            let p = S.Z.getInstance();
            return p.shouldShowQuestionNotification(f)
              ? (0, o.jsx)(A, {})
              : null;
          },
          K = () =>
            (0, o.jsxs)(o.Fragment, {
              children: [(0, o.jsx)(H, {}), (0, o.jsx)(z, {})],
            });
        var V = K;
      },
      59834: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return r;
          },
        });
        var o = n(42699),
          i = n(20918),
          l = n(19167);
        let r = "seenDontLoseProgressModal2024",
          a = ["es-ES", "da-DK"],
          s = (e, t, n, s) => {
            let d = new URL(window.location.href),
              u = !!d.searchParams.get("forceDontLoseProgress");
            if (u) return !0;
            if (n || !t.isDesktop || !a.includes(s) || !(e >= 18e5)) return !1;
            let c = (0, i.Iz)(),
              f = l.Z.Instance.getItem(r);
            if (f) {
              let e = new Date(parseInt(f, 10)),
                t = new Date(c - 2592e5);
              if ((0, o.Z)(e, t)) return !1;
            }
            return !0;
          };
        t.Z = s;
      },
      28441: function (e, t, n) {
        "use strict";
        var o = n(19167);
        let i = "question-notification",
          l = [];
        class r {
          static instance = null;
          static getInstance() {
            return this.instance || (this.instance = new r()), this.instance;
          }
          constructor() {}
          save() {
            o.Z.Instance.setItem(i, JSON.stringify(this.getStorage()));
          }
          questionWasShownToUser(e) {
            this.updateQuestionData(e, (e) => ({
              ...e,
              askedTimes: e.askedTimes + 1,
            }));
          }
          questionWasIgnored(e) {
            this.updateQuestionData(e, (e) => ({ ...e, ignore: !0 }));
          }
          questionPassedSamplingRate(e, t) {
            this.updateQuestionData(e, (e) => ({
              ...e,
              passedSamplingRate: t,
            }));
          }
          questionWasAnswered(e) {
            this.updateQuestionData(e, (e) => ({ ...e, answered: !0 }));
          }
          getQuestionToAsk() {
            let e = l.find((e) => this.shouldShowQuestion(e));
            return e || null;
          }
          shouldShowQuestionNotification(e) {
            return (
              "en-US" === e &&
              0 !== l.length &&
              l.some((e) => this.shouldShowQuestion(e))
            );
          }
          shouldShowQuestion(e) {
            let t = e.id,
              n = this.getStorage(),
              o = n[t],
              i = void 0 !== e.samplingRate;
            if (!o) {
              if (i && Math.random() <= e.samplingRate)
                this.questionPassedSamplingRate(t, !0);
              else if (i) return this.questionPassedSamplingRate(t, !1), !1;
              return !0;
            }
            let l = i && !o.passedSamplingRate;
            return !(l || o.answered || o.ignore || o.askedTimes >= 3);
          }
          getStorage() {
            if (!this.storage) {
              let e = o.Z.Instance.getItem(i) || "{}";
              this.storage = JSON.parse(e);
            }
            return this.storage;
          }
          updateQuestionData(e, t) {
            let n = this.getStorage(),
              o = n[e] || { askedTimes: 0 },
              i = t(o);
            (n[e] = i), this.save();
          }
        }
        t.Z = r;
      },
      18335: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return a;
          },
        });
        var o = n(42699),
          i = n(313),
          l = n(20918),
          r = n(19167);
        let a = "seenFootballDiscordModal2024",
          s = (e, t) => {
            let n = new URL(window.location.href),
              s = !!n.searchParams.get("forceFootball");
            if (s) return !0;
            let d = new Date(Date.UTC((0, l.Hu)(), 5, 17)),
              u = new Date(Date.UTC((0, l.Hu)(), 6, 14)),
              c = (0, l.Iz)();
            if (!(0, o.Z)(c, d) || !(0, i.Z)(c, u) || (!t && !(e >= 18e5)))
              return !1;
            let f = r.Z.Instance.getItem(a);
            return !f;
          };
        t.Z = s;
      },
      57270: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return l;
          },
        });
        var o = n(20918),
          i = n(19167);
        let l = "social-survey-notif-seen",
          r = (e, t, n) => {
            let r = new URL(window.location.href),
              a = !!r.searchParams.get("surveyForce");
            if (a) return !0;
            if (!(0, o.jK)() || "en-US" !== e || !n) return !1;
            let s = !!i.Z.Instance.getItem(l);
            return !s && t >= 144e6;
          };
        t.Z = r;
      },
      86813: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return l;
          },
        });
        var o = n(20918),
          i = n(19167);
        let l = "seenSuperBowlModal2025",
          r = (e, t) => {
            let n = new URL(window.location.href),
              r = !!n.searchParams.get("forceSuperBowlModal");
            if (r) return !0;
            if (!(0, o.Fc)() || !t || !(e >= 6e5)) return !1;
            let a = i.Z.Instance.getItem(l);
            return !a;
          };
        t.Z = r;
      },
      30893: function (e, t, n) {
        "use strict";
        n.d(t, {
          O: function () {
            return l;
          },
        });
        var o = n(20918),
          i = n(19167);
        let l = "seenValentineDiscordModal2024",
          r = (e, t, n) => {
            if (!n) return !1;
            let r = new URL(window.location.href),
              a = !!r.searchParams.get("forceValentine");
            if (a) return !0;
            if ("en-US" !== t) return !1;
            let s = i.Z.Instance.getItem(l);
            return !s && (0, o.qp)() && e >= 72e5;
          };
        t.Z = r;
      },
      88347: function (e) {
        e.exports = {
          czyButton: "ControllerNotification_czyButton__LiLcx",
          "czyButton--contained--purple":
            "ControllerNotification_czyButton--contained--purple___Vhjf",
          "czyButton--contained--white":
            "ControllerNotification_czyButton--contained--white__90Nwp",
          "czyButton--contained--grey":
            "ControllerNotification_czyButton--contained--grey__sDuJG",
          "czyButton--contained--alert":
            "ControllerNotification_czyButton--contained--alert__8lU1C",
          "czyButton--contained--success":
            "ControllerNotification_czyButton--contained--success__51fGB",
          "czyButton--contained--black":
            "ControllerNotification_czyButton--contained--black__GE0h7",
          "czyButton--contained--green-gradient":
            "ControllerNotification_czyButton--contained--green-gradient__rSN8e",
          "czyButton--outlined--purple":
            "ControllerNotification_czyButton--outlined--purple__38XOi",
          "czyButton--link--purple":
            "ControllerNotification_czyButton--link--purple__eHouC",
          "czyButton--outlined--white":
            "ControllerNotification_czyButton--outlined--white__CZYZ0",
          "czyButton--link--white":
            "ControllerNotification_czyButton--link--white__kf02k",
          "czyButton--outlined--grey":
            "ControllerNotification_czyButton--outlined--grey__9OhGD",
          "czyButton--link--grey":
            "ControllerNotification_czyButton--link--grey__O7xJn",
          "czyButton--outlined--alert":
            "ControllerNotification_czyButton--outlined--alert__NHYcF",
          "czyButton--link--alert":
            "ControllerNotification_czyButton--link--alert__MsnRs",
          "czyButton--outlined--success":
            "ControllerNotification_czyButton--outlined--success__Ewct_",
          "czyButton--link--success":
            "ControllerNotification_czyButton--link--success__eTnMN",
          "czyButton--outlined":
            "ControllerNotification_czyButton--outlined__0GzMP",
          "czyButton--disabled":
            "ControllerNotification_czyButton--disabled__dOWzK",
          "czyButton--height50":
            "ControllerNotification_czyButton--height50__k_m0G",
          "czyButton--height34":
            "ControllerNotification_czyButton--height34__o3lnO",
          "czyButton--fullWidth":
            "ControllerNotification_czyButton--fullWidth__gw9yM",
          button: "ControllerNotification_button__1ZRfd",
        };
      },
    },
  ]);
