!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "8df7c95f-0e0d-4df9-99fa-a1994d8c0da0"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-8df7c95f-0e0d-4df9-99fa-a1994d8c0da0"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [89750],
    {
      68888: function (e, t, n) {
        "use strict";
        var i = n(67294),
          o = n(37899),
          a = n(92512),
          r = n(63306),
          c = n(13592),
          l = n(82702);
        let s = () => {
          let { routeHelper: e } = i.useContext(r.Z),
            { respondToNotification: t } = i.useContext(a.c),
            { crazyAnalyticsService: n } = i.useContext(o.Z).services,
            { crazyRouterChange: s } = i.useContext(c.R),
            u = i.useCallback((e) => window.location.href === e, []),
            d = l.sb(),
            f = i.useCallback(
              (i, o) => {
                let a = d({
                  variables: { input: { id: i.id, status: "accepted" } },
                });
                t(i.id, "accepted");
                let r =
                  e.localizedJoinUrl(i.game.gameSlug, i.game.joinUrl) ||
                  i.game.joinUrl;
                n.gameInteractionEvent({
                  method: "invite",
                  origin: "popupNotification",
                  action: "accept",
                  target: i.fromUser.id,
                  targetStatus: null,
                  targetGameId: i.game.gameId,
                }),
                  a.finally(() => {
                    s(r);
                  }),
                  u(r) && o?.();
              },
              [u, d, n, t, e, s]
            ),
            _ = i.useCallback(
              (e, i) => {
                d({ variables: { input: { id: e.id, status: "declined" } } }),
                  t(e.id, "declined"),
                  n.gameInteractionEvent({
                    method: "invite",
                    origin: "popupNotification",
                    action: "decline",
                    target: e.fromUser.id,
                    targetStatus: null,
                    targetGameId: e.game.gameId,
                  }),
                  i?.();
              },
              [n, t, d]
            );
          return { onAcceptClick: f, onDeclineClick: _ };
        };
        t.Z = s;
      },
      10210: function (e, t, n) {
        "use strict";
        n.d(t, {
          P7: function () {
            return u;
          },
          bw: function () {
            return s;
          },
          jj: function () {
            return l;
          },
          qM: function () {
            return r;
          },
          sX: function () {
            return d;
          },
          zC: function () {
            return c;
          },
        });
        var i = n(90948),
          o = n(69661),
          a = n(3411);
        let r = (0, i.ZP)("div")(() => ({
            fontWeight: 800,
            fontSize: 16,
            color: a.D.white[100],
          })),
          c = (0, i.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              background: a.D.black[60],
              borderRadius: 16,
              padding: t(2),
            };
          }),
          l = (0, i.ZP)("span")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginLeft: t(1.5),
              color: a.D.white[60],
              fontSize: 14,
              fontWeight: 700,
            };
          }),
          s = (0, i.ZP)(o.Z)((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              marginRight: t(1.5),
              marginLeft: 2,
              height: 40,
              width: 40,
              borderWidth: 1,
              backgroundColor: a.D.black[100],
              borderColor: a.D.black[100],
              borderStyle: "solid",
            };
          }),
          u = (0, i.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: t(1, 2),
              "& svg.dotsHori": {
                color: a.D.white[10],
                "&:hover": { color: a.D.white[30] },
              },
              "& button:disabled": { color: a.D.white[30] },
              "&:hover": { background: a.D.black[70], cursor: "pointer" },
            };
          }),
          d = (0, i.ZP)("div")({
            position: "absolute",
            width: "calc(100% - 32px)",
            height: "calc(100% - 145px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            top: 130,
          });
      },
      33661: function (e, t, n) {
        "use strict";
        n.d(t, {
          P2: function () {
            return c;
          },
          YP: function () {
            return _;
          },
          bu: function () {
            return y;
          },
          fP: function () {
            return u;
          },
          r_: function () {
            return l;
          },
          sN: function () {
            return d;
          },
          sy: function () {
            return s;
          },
          vt: function () {
            return f;
          },
          xy: function () {
            return m;
          },
        });
        var i = n(25503);
        let o = (e, t, n, i) => {
            try {
              let o = (e) => {
                switch (n) {
                  case "add":
                    return [...e, ...i];
                  case "remove":
                    return e.filter((e) => !i.includes(e));
                }
              };
              e.cache.modify({
                id: e.cache.identify({ __typename: "User", id: t }),
                fields: { relationship: (e) => o(e || []) },
              });
            } catch (e) {
              console.error("Error invalidating cache: ", e);
            }
          },
          a = (e, t) => {
            try {
              e.cache.modify({
                fields: {
                  requestsReceivedFrom(e, n) {
                    let { readField: i } = n;
                    return e.filter((e) => i("id", e.user) !== t);
                  },
                },
              });
            } catch (e) {
              console.error("Error invalidating cache: ", e);
            }
          },
          r = (e, t) => {
            try {
              e.cache.modify({
                fields: {
                  requestsSentTo(e, n) {
                    let { readField: i } = n;
                    return e.filter((e) => i("id", e.user) !== t);
                  },
                },
              });
            } catch (e) {
              console.error("Error invalidating cache: ", e);
            }
          },
          c = (e, t, n) => {
            n ? o(e, t, "add", [n]) : o(e, t, "add", ["invite-sent"]);
          },
          l = (e, t) => {
            o(e, t, "remove", ["invite-sent"]), r(e, t);
          },
          s = (e, t) => {
            o(e, t, "add", ["friends"]),
              o(e, t, "remove", ["invite-received"]),
              a(e, t),
              e.refetchQueries({ include: [i.a_] });
          },
          u = (e, t) => {
            o(e, t, "remove", ["invite-received"]), a(e, t);
          },
          d = (e, t) => {
            o(e, t, "remove", ["invite-received"]), a(e, t);
          },
          f = (e, t) => {
            o(e, t, "remove", ["invite-received"]), a(e, t);
          },
          _ = (e, t) => {
            o(e, t, "remove", ["friends"]),
              e.refetchQueries({ include: [i.a_, i.rc] });
          },
          m = (e, t) => {
            o(e, t, "remove", ["friends", "invite-received", "invite-sent"]),
              o(e, t, "add", ["blocked-by-me"]),
              e.refetchQueries({ include: [i.a_, i.rc] });
          },
          y = (e, t) => {
            o(e, t, "remove", ["blocked-by-me"]);
          };
      },
      89750: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return X;
            },
          });
        var i = n(85893),
          o = n(67294),
          a = n(74040),
          r = n(89950),
          c = n(23180),
          l = n(380);
        let s = () => {
          let { openDrawer: e } = (0, o.useContext)(c.s9),
            { user: t } = (0, o.useContext)(a.S),
            { setGameInviteLink: n } = o.useContext(l.DN);
          o.useEffect(() => {
            let i = (i) => {
              if (i.data.type !== r.V) return;
              let o = i.data;
              "inviteButtonClick" === o.event
                ? (n(o.url), t ? e("inviteFriends") : e("friendsGuest"))
                : "exitButtonWithInviteClick" === o.event && n(o.url);
            };
            return (
              window.addEventListener("message", i),
              () => {
                window.removeEventListener("message", i);
              }
            );
          }, [e, n, t]);
        };
        var u = n(94745),
          d = n(82702),
          f = n(68888),
          _ = n(92512),
          m = n(29496);
        let y = () => {
            let { enqueueSnackbar: e } = (0, m.Ds)();
            return {
              enqueueSnackbar: o.useCallback(
                (t) => {
                  let { fromUser: n, message: i, accept: o, decline: a } = t;
                  return e(i, {
                    variant: "userportalCoolNotification",
                    persist: !0,
                    fromUser: n,
                    accept: o,
                    decline: a,
                  });
                },
                [e]
              ),
            };
          },
          g = () => {
            let e = d.fy(),
              {
                notifications: t,
                addNotification: n,
                expireGameNotification: a,
              } = o.useContext(_.c),
              { enqueueSnackbar: r } = y(),
              [c, l] = o.useState(!0),
              s = !1 != !e?.privacyPreferences?.friendsCanSendGameInvites || !c,
              m = d.Bm(s),
              g = d.WM(s),
              h = d.fy(),
              v = h?.notificationPreferences?.interactiveNotifications !== !1,
              { onAcceptClick: C, onDeclineClick: p } = (0, f.Z)();
            o.useEffect(() => {
              let e = () => {
                l(!document.hidden);
              };
              return (
                document.addEventListener("visibilitychange", e),
                () => {
                  document.removeEventListener("visibilitychange", e);
                }
              );
            }, []),
              o.useEffect(() => {
                if (m) {
                  let e = { ...m, type: "GAME_INVITE", data: { status: null } };
                  t.some((t) => t.id === e.id) || n(e),
                    v &&
                      r({
                        message: (0, i.jsx)(u.cC, {
                          id: "friends.upDrawer.notifications.userInvitedToPlay",
                          values: {
                            game: (0, i.jsx)("span", {
                              style: { fontWeight: 700 },
                              children: m.game.gameName,
                            }),
                          },
                        }),
                        fromUser: m.fromUser,
                        accept: {
                          element: (0, i.jsx)(u.cC, {
                            id: "friends.upDrawer.notifications.accept",
                          }),
                          onAction: () => {
                            C(e);
                          },
                        },
                        decline: {
                          element: (0, i.jsx)(u.cC, {
                            id: "friends.upDrawer.notifications.decline",
                          }),
                          onAction: () => {
                            p(e);
                          },
                        },
                      });
                }
              }, [n, r, m, v, C, p]),
              o.useEffect(() => {
                if (g) {
                  let { userId: e, joinUrl: n, expireAt: i } = g,
                    o = t.find(
                      (t) => t.fromUser.id === e && t.game.joinUrl === n
                    );
                  o && a(o.id, i);
                }
              }, [t, g, a]);
          };
        var h = n(66252),
          v = n(50319),
          C = n(37899),
          p = n(33661),
          B = n(25503);
        let z = () => {
            let [e] = (0, d.Bx)(),
              t = (0, h.x)(),
              { enqueueSnackbar: n } = y(),
              { crazyAnalyticsService: a } = o.useContext(C.Z).services,
              r = d.fy(),
              [c] = (0, v.D)(B.dn),
              l = (0, o.useRef)(null),
              s = r?.notificationPreferences?.interactiveNotifications !== !1;
            return (
              o.useEffect(() => {
                if (!e) return;
                if (0 === e.length) {
                  l.current = new Date(0);
                  return;
                }
                let o = [...e].sort(
                    (e, t) =>
                      new Date(t.requestAvailableSince).getTime() -
                      new Date(e.requestAvailableSince).getTime()
                  )[0],
                  r = new Date(o.requestAvailableSince);
                s &&
                  null !== l.current &&
                  r.getTime() > l.current.getTime() &&
                  n({
                    message: (0, i.jsx)(u.cC, {
                      id: "friends.upDrawer.notifications.userFriendRequest",
                    }),
                    fromUser: o.user,
                    accept: {
                      element: (0, i.jsx)(u.cC, {
                        id: "friends.upDrawer.notifications.accept",
                      }),
                      onAction: () => {
                        c({
                          variables: {
                            input: { fromId: o.user.id, accept: !0 },
                          },
                        }).then((e) => {
                          e.data?.respondToFriendRequest.success
                            ? ((0, p.sy)(t, o.user.id),
                              a.friendRequestEvent({
                                action: "accept",
                                target: o.user.id,
                                origin: "friendRequestPopup",
                              }))
                            : (0, p.sN)(t, o.user.id);
                        });
                      },
                    },
                    decline: {
                      element: (0, i.jsx)(u.cC, {
                        id: "friends.upDrawer.notifications.decline",
                      }),
                      onAction: () => {
                        c({
                          variables: {
                            input: { fromId: o.user.id, accept: !1 },
                          },
                        }).then((e) => {
                          e.data?.respondToFriendRequest.success
                            ? ((0, p.fP)(t, o.user.id),
                              a.friendRequestEvent({
                                action: "decline",
                                target: o.user.id,
                                origin: "friendRequestPopup",
                              }))
                            : (0, p.vt)(t, o.user.id);
                        });
                      },
                    },
                  }),
                  (l.current = r);
              }, [e, n, s, c, t, a]),
              null
            );
          },
          N = () => {
            let { enqueueSnackbar: e } = (0, m.Ds)(),
              t = o.useRef(new Set()),
              n = o.useCallback(
                (n) => {
                  let { message: i, icon: o, debounce: a } = n;
                  !(a?.key && t.current.has(a.key)) &&
                    (e(i, {
                      variant: "userportalCalmNotification",
                      autoHideDuration: 5e3,
                      icon: o,
                    }),
                    a &&
                      (t.current.add(a.key),
                      setTimeout(() => {
                        t.current.delete(a.key);
                      }, a.interval)));
                },
                [e]
              );
            return o.useMemo(() => ({ enqueueSnackbar: n }), [n]);
          },
          b = () => {
            let { enqueueSnackbar: e } = N(),
              [t, n] = o.useState(!0),
              a = d.qC(!t),
              r = d.fy(),
              c = r?.notificationPreferences?.informationalNotifications !== !1;
            o.useEffect(() => {
              let e = () => {
                n(!document.hidden);
              };
              return (
                document.addEventListener("visibilitychange", e),
                () => {
                  document.removeEventListener("visibilitychange", e);
                }
              );
            }, []),
              o.useEffect(() => {
                if (a && c && a.status) {
                  let t, n;
                  "accepted" === a.status
                    ? ((t =
                        "friends.upDrawer.notifications.acceptedGameInvitation"),
                      (n = (0, i.jsx)("span", { children: "\uD83E\uDD73" })))
                    : "declined" === a.status &&
                      ((t =
                        "friends.upDrawer.notifications.declinedGameInvitation"),
                      (n = (0, i.jsx)("span", { children: "❌" }))),
                    t &&
                      n &&
                      e({
                        message: (0, i.jsx)(u.cC, {
                          id: t,
                          values: {
                            username: (0, i.jsx)("span", {
                              style: { fontWeight: 700 },
                              children: a.fromUser.username,
                            }),
                            game: (0, i.jsx)("span", {
                              style: { fontWeight: 700 },
                              children: a.game.gameName,
                            }),
                          },
                        }),
                        icon: n,
                      });
                }
              }, [a, c, e]);
          },
          w = () => {
            g(), b(), s();
            let e = (0, d.fy)(),
              t = e?.notificationPreferences?.friendRequests;
            return t ? (0, i.jsx)(z, {}) : null;
          },
          k = o.memo((e) => {
            let { friendId: t, username: n, sharesLiveGameActivity: a } = e,
              r = d.Q5(t, a),
              c = r?.updatedUserStatus.userStatus.status,
              { enqueueSnackbar: l } = N(),
              s = d.fy(),
              f = s?.notificationPreferences?.informationalNotifications !== !1;
            return (
              o.useEffect(() => {
                "online" === c &&
                  f &&
                  l({
                    debounce: { interval: 2e4, key: `friend-online-${t}` },
                    message: (0, i.jsx)(u.cC, {
                      id: "friends.notifications.friendIsOnline",
                      values: {
                        username: (0, i.jsx)("span", {
                          style: { fontWeight: 700 },
                          children: n,
                        }),
                      },
                    }),
                    icon: (0, i.jsx)("span", { children: "\uD83E\uDD73" }),
                  });
              }, [c, l, f, n]),
              null
            );
          });
        var x = n(63306),
          j = n(13592);
        let I = () => {
            let { routeHelper: e } = o.useContext(x.Z),
              { crazyAnalyticsService: t } = o.useContext(C.Z).services,
              { crazyRouterChange: n } = o.useContext(j.R),
              i = o.useCallback((e) => window.location.href === e, []),
              a = o.useCallback(
                (o, a) => {
                  let r = o.gameSlug
                    ? e.localizedJoinUrl(o.gameSlug, o.joinUrl)
                    : o.joinUrl;
                  o.gameId &&
                    t.gameInteractionEvent({
                      method: "friendJoinable",
                      origin: "popupNotification",
                      action: "send",
                      target: o.userId,
                      targetStatus: null,
                      targetGameId: o.gameId,
                    }),
                    n(r),
                    i(r) && a?.();
                },
                [i, t, e, n]
              );
            return { onAcceptClick: a };
          },
          E = (e) => {
            let {
                userId: t,
                username: n,
                avatar: a,
                sharesLiveGameActivity: r,
              } = e,
              c = d.fF(t, r),
              { enqueueSnackbar: l } = y(),
              { onAcceptClick: s } = I(),
              f = o.useCallback((e) => {
                let t = new URL(e);
                return (t.search = ""), window.location.href === t.toString();
              }, []);
            return (
              o.useEffect(() => {
                if (!c) return;
                let { joinUrl: e } = c;
                !(!e || f(e)) &&
                  l &&
                  l({
                    message: (0, i.jsx)(u.cC, {
                      id: "friends.popup.friendJoinable.text",
                      values: {
                        gameName: (0, i.jsx)("span", {
                          style: { fontWeight: 700 },
                          children: c.gameName,
                        }),
                      },
                    }),
                    fromUser: { id: t, profile: { avatar: a }, username: n },
                    accept: {
                      element: (0, i.jsx)(u.cC, {
                        id: "friends.popup.friendJoinable.button",
                      }),
                      onAction: () => {
                        s({
                          username: n,
                          joinUrl: e,
                          avatar: a,
                          gameSlug: c.gameSlug,
                          gameId: c.gameId,
                          userId: t,
                          gameName: c.gameName,
                        });
                      },
                    },
                  });
              }, [c, l, s, a, n, t, f]),
              null
            );
          },
          S = () => {
            let e = d.fy();
            d.RS(!0), d.Bx(!0), d.Hd(!0), d.qC();
            let [t] = d.RS(),
              n = e?.notificationPreferences?.interactiveNotifications !== !1;
            return (0, i.jsx)(i.Fragment, {
              children:
                t &&
                t.map((e) =>
                  (0, i.jsxs)(
                    o.Fragment,
                    {
                      children: [
                        n &&
                          (0, i.jsx)(E, {
                            userId: e.id,
                            username: e.username,
                            avatar: e.profile?.avatar,
                            sharesLiveGameActivity:
                              e.privacy?.shareLiveGameActivity ?? !0,
                          }),
                        (0, i.jsx)(
                          k,
                          {
                            username: e.username,
                            friendId: e.id,
                            sharesLiveGameActivity:
                              e.privacy?.shareLiveGameActivity ?? !0,
                          },
                          e.id
                        ),
                      ],
                    },
                    e.id
                  )
                ),
            });
          },
          D = () => {
            let { user: e } = o.useContext(a.S);
            return e ? (0, i.jsx)(S, {}) : null;
          };
        var M = n(60619),
          P = n(75007),
          G = n(43740),
          Z = n(10210),
          A = n(88296),
          R = n(46313),
          q = n(96883),
          U = n(29098),
          W = n.n(U);
        let L = `${R.Z.Instance.data.files}crazygames-portal/sounds/notification.mp3`,
          T = o.forwardRef((e, t) => {
            let {
                id: n,
                fromUser: a,
                message: r,
                accept: c,
                decline: l,
                style: s,
              } = e,
              { closeSnackbar: u } = (0, m.Ds)(),
              [d] = (0, M.Z)(L, { volume: 0.6 }),
              { paused: f, setPaused: _ } = o.useContext(q.S),
              [y, g] = o.useState(0),
              [h, v] = o.useState(null),
              C = o.useCallback(() => {
                u(n);
              }, [n, u]),
              p = o.useCallback(() => {
                l?.onAction && l.onAction(), u(n);
              }, [n, u, l]),
              B = o.useCallback(() => {
                c?.onAction && c.onAction(), u(n);
              }, [n, u, c]),
              z = () => {
                _(!0);
              },
              N = () => {
                _(!1);
              };
            return (
              o.useEffect(() => {
                d && d();
              }, [d]),
              o.useEffect(() => {
                if (f) h && clearInterval(h);
                else {
                  let e = setInterval(() => {
                    g((t) =>
                      t >= 100
                        ? (clearInterval(e), u(n), 100)
                        : t + 1.1428571428571428
                    );
                  }, 80);
                  return v(e), () => clearInterval(e);
                }
              }, [f]),
              o.useEffect(() => {
                let e = setInterval(() => {
                  g((t) =>
                    t >= 100
                      ? (clearInterval(e), u(n), 100)
                      : t + 1.1428571428571428
                  );
                }, 80);
                return v(e), () => clearInterval(e);
              }, [u, n, 1.1428571428571428]),
              (0, i.jsxs)(m.No, {
                ref: t,
                role: "alert",
                className: W().snackbarContent,
                style: s,
                onMouseEnter: z,
                onMouseLeave: N,
                children: [
                  (0, i.jsx)("div", {
                    className: W().closeContainer,
                    onClick: C,
                    children: (0, i.jsx)(G.Z, {}),
                  }),
                  (0, i.jsxs)("div", {
                    className: W().avatarContainer,
                    children: [
                      (0, i.jsx)(Z.bw, {
                        src: (0, P.ZP)(a.profile.avatar, {
                          width: 30,
                          height: 30,
                        }),
                        alt: "Avatar",
                        style: { width: 30, height: 30, marginTop: 5 },
                      }),
                      (0, i.jsxs)("div", {
                        children: [
                          (0, i.jsx)("div", {
                            className: W().username,
                            children: a.username,
                          }),
                          (0, i.jsx)("div", {
                            className: W().message,
                            children: r,
                          }),
                        ],
                      }),
                    ],
                  }),
                  (0, i.jsxs)("div", {
                    className: W().buttonContainer,
                    children: [
                      l &&
                        (0, i.jsx)(A.Z, {
                          variant: "contained",
                          height: 34,
                          color: "white",
                          onClick: p,
                          children: l.element,
                        }),
                      (0, i.jsx)(A.Z, {
                        variant: "contained",
                        height: 34,
                        onClick: B,
                        children: c.element,
                      }),
                    ],
                  }),
                  (0, i.jsx)("div", {
                    className: W().countdownBar,
                    style: { width: `${y}%` },
                  }),
                ],
              })
            );
          });
        var F = n(42257),
          O = n(10450),
          V = n.n(O);
        let J = o.forwardRef((e, t) => {
            let { icon: n, message: o, style: a } = e;
            return (0, i.jsxs)(m.No, {
              ref: t,
              role: "alert",
              className: V().snackbarContent,
              style: a,
              children: [
                (0, i.jsx)("div", { className: V().icon, children: n }),
                (0, i.jsx)("div", { className: V().message, children: o }),
              ],
            });
          }),
          H = (e) => {
            let { children: t } = e,
              [n, a] = o.useState(!1),
              { isDesktop: r } = o.useContext(F.Z);
            return (
              o.useEffect(() => {
                a(!0);
              }, []),
              n && r
                ? (0, i.jsx)(m.wT, {
                    Components: {
                      userportalCoolNotification: T,
                      userportalCalmNotification: J,
                    },
                    anchorOrigin: { vertical: "bottom", horizontal: "right" },
                    children: t,
                  })
                : t
            );
          },
          Q = () =>
            (0, i.jsxs)(H, {
              children: [(0, i.jsx)(w, {}), (0, i.jsx)(D, {})],
            });
        var X = Q;
      },
      10450: function (e) {
        e.exports = {
          czyButton: "CalmNotification_czyButton__579uc",
          "czyButton--contained--purple":
            "CalmNotification_czyButton--contained--purple__gofSw",
          "czyButton--contained--white":
            "CalmNotification_czyButton--contained--white__kwLh6",
          "czyButton--contained--grey":
            "CalmNotification_czyButton--contained--grey__F7lCK",
          "czyButton--contained--alert":
            "CalmNotification_czyButton--contained--alert__OEPY5",
          "czyButton--contained--success":
            "CalmNotification_czyButton--contained--success__RNmvp",
          "czyButton--contained--black":
            "CalmNotification_czyButton--contained--black__COV0s",
          "czyButton--contained--green-gradient":
            "CalmNotification_czyButton--contained--green-gradient__Pa64O",
          "czyButton--outlined--purple":
            "CalmNotification_czyButton--outlined--purple__6IU79",
          "czyButton--link--purple":
            "CalmNotification_czyButton--link--purple__Wvb0_",
          "czyButton--outlined--white":
            "CalmNotification_czyButton--outlined--white__QTuEW",
          "czyButton--link--white":
            "CalmNotification_czyButton--link--white__fYj47",
          "czyButton--outlined--grey":
            "CalmNotification_czyButton--outlined--grey___FMBy",
          "czyButton--link--grey":
            "CalmNotification_czyButton--link--grey__jm7XP",
          "czyButton--outlined--alert":
            "CalmNotification_czyButton--outlined--alert__wOfLP",
          "czyButton--link--alert":
            "CalmNotification_czyButton--link--alert___wAiZ",
          "czyButton--outlined--success":
            "CalmNotification_czyButton--outlined--success__B62yu",
          "czyButton--link--success":
            "CalmNotification_czyButton--link--success__P4jQP",
          "czyButton--outlined": "CalmNotification_czyButton--outlined__aJagT",
          "czyButton--disabled": "CalmNotification_czyButton--disabled__pptPN",
          "czyButton--height50": "CalmNotification_czyButton--height50__0IS__",
          "czyButton--height34": "CalmNotification_czyButton--height34__ioouW",
          "czyButton--fullWidth":
            "CalmNotification_czyButton--fullWidth__Wp_ol",
          snackbarContent: "CalmNotification_snackbarContent__74HO4",
          icon: "CalmNotification_icon__abS0S",
          message: "CalmNotification_message__DlESr",
        };
      },
      29098: function (e) {
        e.exports = {
          czyButton: "CoolNotification_czyButton__rlSdM",
          "czyButton--contained--purple":
            "CoolNotification_czyButton--contained--purple__uCOu_",
          "czyButton--contained--white":
            "CoolNotification_czyButton--contained--white__DonD_",
          "czyButton--contained--grey":
            "CoolNotification_czyButton--contained--grey__rApxI",
          "czyButton--contained--alert":
            "CoolNotification_czyButton--contained--alert__BVCst",
          "czyButton--contained--success":
            "CoolNotification_czyButton--contained--success__17iBF",
          "czyButton--contained--black":
            "CoolNotification_czyButton--contained--black__9VzHB",
          "czyButton--contained--green-gradient":
            "CoolNotification_czyButton--contained--green-gradient__U7C4T",
          "czyButton--outlined--purple":
            "CoolNotification_czyButton--outlined--purple__FWWVE",
          "czyButton--link--purple":
            "CoolNotification_czyButton--link--purple__nnH5O",
          "czyButton--outlined--white":
            "CoolNotification_czyButton--outlined--white__wkTwt",
          "czyButton--link--white":
            "CoolNotification_czyButton--link--white__Vq2S8",
          "czyButton--outlined--grey":
            "CoolNotification_czyButton--outlined--grey__fcIS6",
          "czyButton--link--grey":
            "CoolNotification_czyButton--link--grey__1isu4",
          "czyButton--outlined--alert":
            "CoolNotification_czyButton--outlined--alert__ZhkVY",
          "czyButton--link--alert":
            "CoolNotification_czyButton--link--alert___n94J",
          "czyButton--outlined--success":
            "CoolNotification_czyButton--outlined--success__1EPuo",
          "czyButton--link--success":
            "CoolNotification_czyButton--link--success__zRk9g",
          "czyButton--outlined": "CoolNotification_czyButton--outlined___uGRv",
          "czyButton--disabled": "CoolNotification_czyButton--disabled__9Sclu",
          "czyButton--height50": "CoolNotification_czyButton--height50__Ahqek",
          "czyButton--height34": "CoolNotification_czyButton--height34__3uxov",
          "czyButton--fullWidth":
            "CoolNotification_czyButton--fullWidth__4e8mJ",
          snackbarContent: "CoolNotification_snackbarContent__q7LxM",
          closeContainer: "CoolNotification_closeContainer__G_G2o",
          avatarContainer: "CoolNotification_avatarContainer__WEHXL",
          username: "CoolNotification_username__qbXSw",
          message: "CoolNotification_message__I2s8G",
          buttonContainer: "CoolNotification_buttonContainer__CQZV_",
          countdownBar: "CoolNotification_countdownBar__G2rge",
        };
      },
    },
  ]);
