!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "abbdee01-4965-4695-807c-9984ffdf2c41"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-abbdee01-4965-4695-807c-9984ffdf2c41"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [91846],
    {
      29496: function (e, n, t) {
        t.d(n, {
          No: function () {
            return em;
          },
          wT: function () {
            return eO;
          },
          Ds: function () {
            return eM;
          },
        });
        var r,
          i,
          o,
          a,
          s,
          u,
          c = t(67294),
          l = t(73935),
          d = function () {
            for (var e, n, t = 0, r = ""; t < arguments.length; )
              (e = arguments[t++]) &&
                (n = (function e(n) {
                  var t,
                    r,
                    i = "";
                  if ("string" == typeof n || "number" == typeof n) i += n;
                  else if ("object" == typeof n) {
                    if (Array.isArray(n))
                      for (t = 0; t < n.length; t++)
                        n[t] && (r = e(n[t])) && (i && (i += " "), (i += r));
                    else for (t in n) n[t] && (i && (i += " "), (i += t));
                  }
                  return i;
                })(e)) &&
                (r && (r += " "), (r += n));
            return r;
          };
        let f = { data: "" },
          p = (e) =>
            "object" == typeof window
              ? (
                  (e ? e.querySelector("#_goober") : window._goober) ||
                  Object.assign(
                    (e || document.head).appendChild(
                      document.createElement("style")
                    ),
                    { innerHTML: " ", id: "_goober" }
                  )
                ).firstChild
              : e || f,
          m =
            /(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,
          h = /\/\*[^]*?\*\/|  +/g,
          g = /\n+/g,
          b = (e, n) => {
            let t = "",
              r = "",
              i = "";
            for (let o in e) {
              let a = e[o];
              "@" == o[0]
                ? "i" == o[1]
                  ? (t = o + " " + a + ";")
                  : (r +=
                      "f" == o[1]
                        ? b(a, o)
                        : o + "{" + b(a, "k" == o[1] ? "" : n) + "}")
                : "object" == typeof a
                ? (r += b(
                    a,
                    n
                      ? n.replace(/([^,])+/g, (e) =>
                          o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g, (n) =>
                            /&/.test(n)
                              ? n.replace(/&/g, e)
                              : e
                              ? e + " " + n
                              : n
                          )
                        )
                      : o
                  ))
                : null != a &&
                  ((o = /^--/.test(o)
                    ? o
                    : o.replace(/[A-Z]/g, "-$&").toLowerCase()),
                  (i += b.p ? b.p(o, a) : o + ":" + a + ";"));
            }
            return t + (n && i ? n + "{" + i + "}" : i) + r;
          },
          v = {},
          E = (e) => {
            if ("object" == typeof e) {
              let n = "";
              for (let t in e) n += t + E(e[t]);
              return n;
            }
            return e;
          },
          x = (e, n, t, r, i) => {
            var o, a;
            let s = E(e),
              u =
                v[s] ||
                (v[s] = ((e) => {
                  let n = 0,
                    t = 11;
                  for (; n < e.length; )
                    t = (101 * t + e.charCodeAt(n++)) >>> 0;
                  return "go" + t;
                })(s));
            if (!v[u]) {
              let n =
                s !== e
                  ? e
                  : ((e) => {
                      let n,
                        t,
                        r = [{}];
                      for (; (n = m.exec(e.replace(h, ""))); )
                        n[4]
                          ? r.shift()
                          : n[3]
                          ? ((t = n[3].replace(g, " ").trim()),
                            r.unshift((r[0][t] = r[0][t] || {})))
                          : (r[0][n[1]] = n[2].replace(g, " ").trim());
                      return r[0];
                    })(e);
              v[u] = b(i ? { ["@keyframes " + u]: n } : n, t ? "" : "." + u);
            }
            let c = t && v.g ? v.g : null;
            return (
              t && (v.g = v[u]),
              (o = v[u]),
              (a = n),
              c
                ? (a.data = a.data.replace(c, o))
                : -1 === a.data.indexOf(o) &&
                  (a.data = r ? o + a.data : a.data + o),
              u
            );
          },
          k = (e, n, t) =>
            e.reduce((e, r, i) => {
              let o = n[i];
              if (o && o.call) {
                let e = o(t),
                  n =
                    (e && e.props && e.props.className) || (/^go/.test(e) && e);
                o = n
                  ? "." + n
                  : e && "object" == typeof e
                  ? e.props
                    ? ""
                    : b(e, "")
                  : !1 === e
                  ? ""
                  : e;
              }
              return e + r + (null == o ? "" : o);
            }, "");
        function y(e) {
          let n = this || {},
            t = e.call ? e(n.p) : e;
          return x(
            t.unshift
              ? t.raw
                ? k(t, [].slice.call(arguments, 1), n.p)
                : t.reduce(
                    (e, t) => Object.assign(e, t && t.call ? t(n.p) : t),
                    {}
                  )
              : t,
            p(n.target),
            n.g,
            n.o,
            n.k
          );
        }
        function w(e, n) {
          for (var t = 0; t < n.length; t++) {
            var r = n[t];
            (r.enumerable = r.enumerable || !1),
              (r.configurable = !0),
              "value" in r && (r.writable = !0),
              Object.defineProperty(e, r.key, r);
          }
        }
        function C(e, n, t) {
          return n && w(e.prototype, n), t && w(e, t), e;
        }
        function S() {
          return (S =
            Object.assign ||
            function (e) {
              for (var n = 1; n < arguments.length; n++) {
                var t = arguments[n];
                for (var r in t)
                  Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
              }
              return e;
            }).apply(this, arguments);
        }
        function O(e, n) {
          (e.prototype = Object.create(n.prototype)),
            (e.prototype.constructor = e),
            (e.__proto__ = n);
        }
        function M(e, n) {
          if (null == e) return {};
          var t,
            r,
            i = {},
            o = Object.keys(e);
          for (r = 0; r < o.length; r++)
            (t = o[r]), n.indexOf(t) >= 0 || (i[t] = e[t]);
          return i;
        }
        function D(e) {
          if (void 0 === e)
            throw ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return e;
        }
        y.bind({ g: 1 }), y.bind({ k: 1 });
        var L = function () {
            return "";
          },
          T = c.createContext({ enqueueSnackbar: L, closeSnackbar: L }),
          R = {
            downXs: "@media (max-width:599.95px)",
            upSm: "@media (min-width:600px)",
          },
          j = function (e) {
            return e.charAt(0).toUpperCase() + e.slice(1);
          },
          N = function (e) {
            return "" + j(e.vertical) + j(e.horizontal);
          },
          H = function (e) {
            return !!e || 0 === e;
          },
          _ = "unmounted",
          I = "exited",
          P = "entering",
          q = "entered",
          A = "exiting",
          V = (function (e) {
            function n(n) {
              t = e.call(this, n) || this;
              var t,
                r,
                i = n.appear;
              return (
                (t.appearStatus = null),
                n.in
                  ? i
                    ? ((r = I), (t.appearStatus = P))
                    : (r = q)
                  : (r = n.unmountOnExit || n.mountOnEnter ? _ : I),
                (t.state = { status: r }),
                (t.nextCallback = null),
                t
              );
            }
            O(n, e),
              (n.getDerivedStateFromProps = function (e, n) {
                return e.in && n.status === _ ? { status: I } : null;
              });
            var t = n.prototype;
            return (
              (t.componentDidMount = function () {
                this.updateStatus(!0, this.appearStatus);
              }),
              (t.componentDidUpdate = function (e) {
                var n = null;
                if (e !== this.props) {
                  var t = this.state.status;
                  this.props.in
                    ? t !== P && t !== q && (n = P)
                    : (t === P || t === q) && (n = A);
                }
                this.updateStatus(!1, n);
              }),
              (t.componentWillUnmount = function () {
                this.cancelNextCallback();
              }),
              (t.getTimeouts = function () {
                var e = this.props.timeout,
                  n = e,
                  t = e;
                return (
                  null != e &&
                    "number" != typeof e &&
                    "string" != typeof e &&
                    ((t = e.exit), (n = e.enter)),
                  { exit: t, enter: n }
                );
              }),
              (t.updateStatus = function (e, n) {
                void 0 === e && (e = !1),
                  null !== n
                    ? (this.cancelNextCallback(),
                      n === P ? this.performEnter(e) : this.performExit())
                    : this.props.unmountOnExit &&
                      this.state.status === I &&
                      this.setState({ status: _ });
              }),
              (t.performEnter = function (e) {
                var n = this,
                  t = this.props.enter,
                  r = this.getTimeouts();
                if (!e && !t) {
                  this.safeSetState({ status: q }, function () {
                    n.props.onEntered && n.props.onEntered(n.node, e);
                  });
                  return;
                }
                this.props.onEnter && this.props.onEnter(this.node, e),
                  this.safeSetState({ status: P }, function () {
                    n.props.onEntering && n.props.onEntering(n.node, e),
                      n.onTransitionEnd(r.enter, function () {
                        n.safeSetState({ status: q }, function () {
                          n.props.onEntered && n.props.onEntered(n.node, e);
                        });
                      });
                  });
              }),
              (t.performExit = function () {
                var e = this,
                  n = this.props.exit,
                  t = this.getTimeouts();
                if (!n) {
                  this.safeSetState({ status: I }, function () {
                    e.props.onExited && e.props.onExited(e.node);
                  });
                  return;
                }
                this.props.onExit && this.props.onExit(this.node),
                  this.safeSetState({ status: A }, function () {
                    e.props.onExiting && e.props.onExiting(e.node),
                      e.onTransitionEnd(t.exit, function () {
                        e.safeSetState({ status: I }, function () {
                          e.props.onExited && e.props.onExited(e.node);
                        });
                      });
                  });
              }),
              (t.cancelNextCallback = function () {
                null !== this.nextCallback &&
                  this.nextCallback.cancel &&
                  (this.nextCallback.cancel(), (this.nextCallback = null));
              }),
              (t.safeSetState = function (e, n) {
                (n = this.setNextCallback(n)), this.setState(e, n);
              }),
              (t.setNextCallback = function (e) {
                var n = this,
                  t = !0;
                return (
                  (this.nextCallback = function () {
                    t && ((t = !1), (n.nextCallback = null), e());
                  }),
                  (this.nextCallback.cancel = function () {
                    t = !1;
                  }),
                  this.nextCallback
                );
              }),
              (t.onTransitionEnd = function (e, n) {
                this.setNextCallback(n);
                var t = null == e && !this.props.addEndListener;
                if (!this.node || t) {
                  setTimeout(this.nextCallback, 0);
                  return;
                }
                this.props.addEndListener &&
                  this.props.addEndListener(this.node, this.nextCallback),
                  null != e && setTimeout(this.nextCallback, e);
              }),
              (t.render = function () {
                var e = this.state.status;
                if (e === _) return null;
                var n = this.props;
                return (0, n.children)(
                  e,
                  M(n, [
                    "children",
                    "in",
                    "mountOnEnter",
                    "unmountOnExit",
                    "appear",
                    "enter",
                    "exit",
                    "timeout",
                    "addEndListener",
                    "onEnter",
                    "onEntering",
                    "onEntered",
                    "onExit",
                    "onExiting",
                    "onExited",
                    "nodeRef",
                  ])
                );
              }),
              C(n, [
                {
                  key: "node",
                  get: function () {
                    var e,
                      n =
                        null === (e = this.props.nodeRef) || void 0 === e
                          ? void 0
                          : e.current;
                    if (!n)
                      throw Error(
                        "notistack - Custom snackbar is not refForwarding"
                      );
                    return n;
                  },
                },
              ]),
              n
            );
          })(c.Component);
        function W() {}
        function z(e, n) {
          "function" == typeof e ? e(n) : e && (e.current = n);
        }
        function B(e, n) {
          return (0, c.useMemo)(
            function () {
              return null == e && null == n
                ? null
                : function (t) {
                    z(e, t), z(n, t);
                  };
            },
            [e, n]
          );
        }
        function F(e) {
          var n = e.timeout,
            t = e.style,
            r = void 0 === t ? {} : t,
            i = e.mode;
          return {
            duration: "object" == typeof n ? n[i] || 0 : n,
            easing: r.transitionTimingFunction,
            delay: r.transitionDelay,
          };
        }
        V.defaultProps = {
          in: !1,
          mountOnEnter: !1,
          unmountOnExit: !1,
          appear: !1,
          enter: !0,
          exit: !0,
          onEnter: W,
          onEntering: W,
          onEntered: W,
          onExit: W,
          onExiting: W,
          onExited: W,
        };
        var G = {
            easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
            easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
            easeIn: "cubic-bezier(0.4, 0, 1, 1)",
            sharp: "cubic-bezier(0.4, 0, 0.6, 1)",
          },
          X = function (e) {
            e.scrollTop = e.scrollTop;
          },
          Z = function (e) {
            return Math.round(e) + "ms";
          };
        function Q(e, n) {
          void 0 === e && (e = ["all"]);
          var t = n || {},
            r = t.duration,
            i = void 0 === r ? 300 : r,
            o = t.easing,
            a = void 0 === o ? G.easeInOut : o,
            s = t.delay,
            u = void 0 === s ? 0 : s;
          return (Array.isArray(e) ? e : [e])
            .map(function (e) {
              return (
                e +
                " " +
                ("string" == typeof i ? i : Z(i)) +
                " " +
                a +
                " " +
                ("string" == typeof u ? u : Z(u))
              );
            })
            .join(",");
        }
        function U(e) {
          return ((e && e.ownerDocument) || document).defaultView || window;
        }
        function Y(e, n) {
          if (n) {
            var t = (function (e, n) {
              var t,
                r = n.getBoundingClientRect(),
                i = U(n);
              if (n.fakeTransform) t = n.fakeTransform;
              else {
                var o = i.getComputedStyle(n);
                t =
                  o.getPropertyValue("-webkit-transform") ||
                  o.getPropertyValue("transform");
              }
              var a = 0,
                s = 0;
              if (t && "none" !== t && "string" == typeof t) {
                var u = t.split("(")[1].split(")")[0].split(",");
                (a = parseInt(u[4], 10)), (s = parseInt(u[5], 10));
              }
              switch (e) {
                case "left":
                  return "translateX(" + (i.innerWidth + a - r.left) + "px)";
                case "right":
                  return "translateX(-" + (r.left + r.width - a) + "px)";
                case "up":
                  return "translateY(" + (i.innerHeight + s - r.top) + "px)";
                default:
                  return "translateY(-" + (r.top + r.height - s) + "px)";
              }
            })(e, n);
            t && ((n.style.webkitTransform = t), (n.style.transform = t));
          }
        }
        var K = (0, c.forwardRef)(function (e, n) {
          var t = e.children,
            r = e.direction,
            i = void 0 === r ? "down" : r,
            o = e.in,
            a = e.style,
            s = e.timeout,
            u = void 0 === s ? 0 : s,
            l = e.onEnter,
            d = e.onEntered,
            f = e.onExit,
            p = e.onExited,
            m = M(e, [
              "children",
              "direction",
              "in",
              "style",
              "timeout",
              "onEnter",
              "onEntered",
              "onExit",
              "onExited",
            ]),
            h = (0, c.useRef)(null),
            g = B(t.ref, h),
            b = B(g, n),
            v = (0, c.useCallback)(
              function () {
                h.current && Y(i, h.current);
              },
              [i]
            );
          return (
            (0, c.useEffect)(
              function () {
                if (!o && "down" !== i && "right" !== i) {
                  var e = (function (e, n) {
                      var t;
                      function r() {
                        for (
                          var r = this,
                            i = arguments.length,
                            o = Array(i),
                            a = 0;
                          a < i;
                          a++
                        )
                          o[a] = arguments[a];
                        clearTimeout(t),
                          (t = setTimeout(function () {
                            e.apply(r, o);
                          }, n));
                      }
                      return (
                        void 0 === n && (n = 166),
                        (r.clear = function () {
                          clearTimeout(t);
                        }),
                        r
                      );
                    })(function () {
                      h.current && Y(i, h.current);
                    }),
                    n = U(h.current);
                  return (
                    n.addEventListener("resize", e),
                    function () {
                      e.clear(), n.removeEventListener("resize", e);
                    }
                  );
                }
              },
              [i, o]
            ),
            (0, c.useEffect)(
              function () {
                o || v();
              },
              [o, v]
            ),
            (0, c.createElement)(
              V,
              Object.assign(
                {
                  appear: !0,
                  nodeRef: h,
                  onEnter: function (e, n) {
                    Y(i, e), X(e), l && l(e, n);
                  },
                  onEntered: d,
                  onEntering: function (e) {
                    var n =
                        (null == a ? void 0 : a.transitionTimingFunction) ||
                        G.easeOut,
                      t = F({
                        timeout: u,
                        mode: "enter",
                        style: S({}, a, { transitionTimingFunction: n }),
                      });
                    (e.style.webkitTransition = Q("-webkit-transform", t)),
                      (e.style.transition = Q("transform", t)),
                      (e.style.webkitTransform = "none"),
                      (e.style.transform = "none");
                  },
                  onExit: function (e) {
                    var n =
                        (null == a ? void 0 : a.transitionTimingFunction) ||
                        G.sharp,
                      t = F({
                        timeout: u,
                        mode: "exit",
                        style: S({}, a, { transitionTimingFunction: n }),
                      });
                    (e.style.webkitTransition = Q("-webkit-transform", t)),
                      (e.style.transition = Q("transform", t)),
                      Y(i, e),
                      f && f(e);
                  },
                  onExited: function (e) {
                    (e.style.webkitTransition = ""),
                      (e.style.transition = ""),
                      p && p(e);
                  },
                  in: o,
                  timeout: u,
                },
                m
              ),
              function (e, n) {
                return (0, c.cloneElement)(
                  t,
                  S(
                    {
                      ref: b,
                      style: S(
                        { visibility: "exited" !== e || o ? void 0 : "hidden" },
                        a,
                        {},
                        t.props.style
                      ),
                    },
                    n
                  )
                );
              }
            )
          );
        });
        K.displayName = "Slide";
        var $ = function (e) {
            return c.createElement(
              "svg",
              Object.assign(
                {
                  viewBox: "0 0 24 24",
                  focusable: "false",
                  style: {
                    fontSize: 20,
                    marginInlineEnd: 8,
                    userSelect: "none",
                    width: "1em",
                    height: "1em",
                    display: "inline-block",
                    fill: "currentColor",
                    flexShrink: 0,
                  },
                },
                e
              )
            );
          },
          J = {
            maxSnack: 3,
            persist: !1,
            hideIconVariant: !1,
            disableWindowBlurListener: !1,
            variant: "default",
            autoHideDuration: 5e3,
            iconVariant: {
              default: void 0,
              success: c.createElement(function () {
                return c.createElement(
                  $,
                  null,
                  c.createElement("path", {
                    d: "M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41\n        10.59L10 14.17L17.59 6.58L19 8L10 17Z",
                  })
                );
              }, null),
              warning: c.createElement(function () {
                return c.createElement(
                  $,
                  null,
                  c.createElement("path", {
                    d: "M13,14H11V10H13M13,18H11V16H13M1,21H23L12,2L1,21Z",
                  })
                );
              }, null),
              error: c.createElement(function () {
                return c.createElement(
                  $,
                  null,
                  c.createElement("path", {
                    d: "M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,\n        6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,\n        13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",
                  })
                );
              }, null),
              info: c.createElement(function () {
                return c.createElement(
                  $,
                  null,
                  c.createElement("path", {
                    d: "M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,\n        0 22,12A10,10 0 0,0 12,2Z",
                  })
                );
              }, null),
            },
            anchorOrigin: { vertical: "bottom", horizontal: "left" },
            TransitionComponent: K,
            transitionDuration: { enter: 225, exit: 195 },
          },
          ee = function (e, n) {
            var t = function (e) {
              return "number" == typeof e || null === e;
            };
            return t(e) ? e : t(n) ? n : J.autoHideDuration;
          },
          en = function (e, n) {
            var t = function (e, n) {
              return n.some(function (n) {
                return typeof e === n;
              });
            };
            return t(e, ["string", "number"])
              ? e
              : t(e, ["object"])
              ? S({}, J.transitionDuration, {}, t(n, ["object"]) && n, {}, e)
              : t(n, ["string", "number"])
              ? n
              : t(n, ["object"])
              ? S({}, J.transitionDuration, {}, n)
              : J.transitionDuration;
          };
        function et(e) {
          return Object.entries(e).reduce(function (e, n) {
            var t,
              r = n[0],
              i = n[1];
            return S({}, e, (((t = {})[r] = y(i)), t));
          }, {});
        }
        var er = {
            SnackbarContainer: "notistack-SnackbarContainer",
            Snackbar: "notistack-Snackbar",
            CollapseWrapper: "notistack-CollapseWrapper",
            MuiContent: "notistack-MuiContent",
            MuiContentVariant: function (e) {
              return "notistack-MuiContent-" + e;
            },
          },
          ei = et({ root: { height: 0 }, entered: { height: "auto" } }),
          eo = (0, c.forwardRef)(function (e, n) {
            var t = e.children,
              r = e.in,
              i = e.onExited,
              o = (0, c.useRef)(null),
              a = (0, c.useRef)(null),
              s = B(n, a),
              u = function () {
                return o.current ? o.current.clientHeight : 0;
              };
            return (0, c.createElement)(
              V,
              {
                in: r,
                unmountOnExit: !0,
                onEnter: function (e) {
                  e.style.height = "0px";
                },
                onEntered: function (e) {
                  e.style.height = "auto";
                },
                onEntering: function (e) {
                  var n = u(),
                    t = F({ timeout: 175, mode: "enter" }),
                    r = t.duration,
                    i = t.easing;
                  (e.style.transitionDuration =
                    "string" == typeof r ? r : r + "ms"),
                    (e.style.height = n + "px"),
                    (e.style.transitionTimingFunction = i || "");
                },
                onExit: function (e) {
                  e.style.height = u() + "px";
                },
                onExited: i,
                onExiting: function (e) {
                  X(e);
                  var n = F({ timeout: 175, mode: "exit" }),
                    t = n.duration,
                    r = n.easing;
                  (e.style.transitionDuration =
                    "string" == typeof t ? t : t + "ms"),
                    (e.style.height = "0px"),
                    (e.style.transitionTimingFunction = r || "");
                },
                nodeRef: a,
                timeout: 175,
              },
              function (e, n) {
                return (0, c.createElement)(
                  "div",
                  Object.assign(
                    {
                      ref: s,
                      className: d(ei.root, "entered" === e && ei.entered),
                      style: S(
                        {
                          pointerEvents: "all",
                          overflow: "hidden",
                          minHeight: "0px",
                          transition: Q("height"),
                        },
                        "entered" === e && { overflow: "visible" },
                        {},
                        "exited" === e && !r && { visibility: "hidden" }
                      ),
                    },
                    n
                  ),
                  (0, c.createElement)(
                    "div",
                    {
                      ref: o,
                      className: er.CollapseWrapper,
                      style: { display: "flex", width: "100%" },
                    },
                    t
                  )
                );
              }
            );
          });
        eo.displayName = "Collapse";
        var ea = { right: "left", left: "right", bottom: "up", top: "down" },
          es = function (e) {
            void 0 === e && (e = {});
            var n = {
              containerRoot: !0,
              containerAnchorOriginTopCenter: !0,
              containerAnchorOriginBottomCenter: !0,
              containerAnchorOriginTopRight: !0,
              containerAnchorOriginBottomRight: !0,
              containerAnchorOriginTopLeft: !0,
              containerAnchorOriginBottomLeft: !0,
            };
            return Object.keys(e)
              .filter(function (e) {
                return !n[e];
              })
              .reduce(function (n, t) {
                var r;
                return S({}, n, (((r = {})[t] = e[t]), r));
              }, {});
          },
          eu = function () {};
        function ec(e, n) {
          return e.reduce(function (e, t) {
            return null == t
              ? e
              : function () {
                  for (
                    var r = arguments.length, i = Array(r), o = 0;
                    o < r;
                    o++
                  )
                    i[o] = arguments[o];
                  var a = [].concat(i);
                  n && -1 === a.indexOf(n) && a.push(n),
                    e.apply(this, a),
                    t.apply(this, a);
                };
          }, eu);
        }
        var el = "undefined" != typeof window ? c.useLayoutEffect : c.useEffect;
        function ed(e) {
          var n = (0, c.useRef)(e);
          return (
            el(function () {
              n.current = e;
            }),
            (0, c.useCallback)(function () {
              return n.current.apply(void 0, arguments);
            }, [])
          );
        }
        var ef = (0, c.forwardRef)(function (e, n) {
          var t = e.children,
            r = e.className,
            i = e.autoHideDuration,
            o = e.disableWindowBlurListener,
            a = void 0 !== o && o,
            s = e.onClose,
            u = e.id,
            l = e.open,
            f = e.SnackbarProps,
            p = void 0 === f ? {} : f,
            m = (0, c.useRef)(),
            h = ed(function () {
              s && s.apply(void 0, arguments);
            }),
            g = ed(function (e) {
              s &&
                null != e &&
                (m.current && clearTimeout(m.current),
                (m.current = setTimeout(function () {
                  h(null, "timeout", u);
                }, e)));
            });
          (0, c.useEffect)(
            function () {
              return (
                l && g(i),
                function () {
                  m.current && clearTimeout(m.current);
                }
              );
            },
            [l, i, g]
          );
          var b = function () {
              m.current && clearTimeout(m.current);
            },
            v = (0, c.useCallback)(
              function () {
                null != i && g(0.5 * i);
              },
              [i, g]
            );
          return (
            (0, c.useEffect)(
              function () {
                if (!a && l)
                  return (
                    window.addEventListener("focus", v),
                    window.addEventListener("blur", b),
                    function () {
                      window.removeEventListener("focus", v),
                        window.removeEventListener("blur", b);
                    }
                  );
              },
              [a, v, l]
            ),
            (0, c.createElement)(
              "div",
              Object.assign({ ref: n }, p, {
                className: d(er.Snackbar, r),
                onMouseEnter: function (e) {
                  p.onMouseEnter && p.onMouseEnter(e), b();
                },
                onMouseLeave: function (e) {
                  p.onMouseLeave && p.onMouseLeave(e), v();
                },
              }),
              t
            )
          );
        });
        ef.displayName = "Snackbar";
        var ep = et({
            root:
              (((r = { display: "flex", flexWrap: "wrap", flexGrow: 1 })[
                R.upSm
              ] = { flexGrow: "initial", minWidth: "288px" }),
              r),
          }),
          em = (0, c.forwardRef)(function (e, n) {
            var t = e.className,
              r = M(e, ["className"]);
            return c.createElement(
              "div",
              Object.assign({ ref: n, className: d(ep.root, t) }, r)
            );
          });
        em.displayName = "SnackbarContent";
        var eh = et({
            root: {
              backgroundColor: "#313131",
              fontSize: "0.875rem",
              lineHeight: 1.43,
              letterSpacing: "0.01071em",
              color: "#fff",
              alignItems: "center",
              padding: "6px 16px",
              borderRadius: "4px",
              boxShadow:
                "0px 3px 5px -1px rgba(0,0,0,0.2),0px 6px 10px 0px rgba(0,0,0,0.14),0px 1px 18px 0px rgba(0,0,0,0.12)",
            },
            lessPadding: { paddingLeft: "20px" },
            default: { backgroundColor: "#313131" },
            success: { backgroundColor: "#43a047" },
            error: { backgroundColor: "#d32f2f" },
            warning: { backgroundColor: "#ff9800" },
            info: { backgroundColor: "#2196f3" },
            message: {
              display: "flex",
              alignItems: "center",
              padding: "8px 0",
            },
            action: {
              display: "flex",
              alignItems: "center",
              marginLeft: "auto",
              paddingLeft: "16px",
              marginRight: "-8px",
            },
          }),
          eg = "notistack-snackbar",
          eb = (0, c.forwardRef)(function (e, n) {
            var t = e.id,
              r = e.message,
              i = e.action,
              o = e.iconVariant,
              a = e.variant,
              s = e.hideIconVariant,
              u = e.style,
              l = e.className,
              f = o[a],
              p = i;
            return (
              "function" == typeof p && (p = p(t)),
              c.createElement(
                em,
                {
                  ref: n,
                  role: "alert",
                  "aria-describedby": eg,
                  style: u,
                  className: d(
                    er.MuiContent,
                    er.MuiContentVariant(a),
                    eh.root,
                    eh[a],
                    l,
                    !s && f && eh.lessPadding
                  ),
                },
                c.createElement(
                  "div",
                  { id: eg, className: eh.message },
                  s ? null : f,
                  r
                ),
                p && c.createElement("div", { className: eh.action }, p)
              )
            );
          });
        eb.displayName = "MaterialDesignContent";
        var ev = (0, c.memo)(eb),
          eE = et({
            wrappedRoot: {
              width: "100%",
              position: "relative",
              transform: "translateX(0)",
              top: 0,
              right: 0,
              bottom: 0,
              left: 0,
              minWidth: "288px",
            },
          }),
          ex = function (e) {
            var n,
              t = (0, c.useRef)(),
              r = (0, c.useState)(!0),
              i = r[0],
              o = r[1],
              a = ec([e.snack.onClose, e.onClose]),
              s = (0, c.useCallback)(function () {
                t.current = setTimeout(function () {
                  o(function (e) {
                    return !e;
                  });
                }, 125);
              }, []);
            (0, c.useEffect)(function () {
              return function () {
                t.current && clearTimeout(t.current);
              };
            }, []);
            var u = e.snack,
              l = e.classes,
              f = e.Component,
              p = (0, c.useMemo)(
                function () {
                  return es(l);
                },
                [l]
              ),
              m = u.open,
              h = u.SnackbarProps,
              g = u.TransitionComponent,
              b = u.TransitionProps,
              v = u.transitionDuration,
              E = u.disableWindowBlurListener,
              x = u.content,
              k = M(u, [
                "open",
                "SnackbarProps",
                "TransitionComponent",
                "TransitionProps",
                "transitionDuration",
                "disableWindowBlurListener",
                "content",
                "entered",
                "requestClose",
                "onEnter",
                "onEntered",
                "onExit",
                "onExited",
              ]),
              y = S(
                {
                  direction:
                    "center" !== (n = k.anchorOrigin).horizontal
                      ? ea[n.horizontal]
                      : ea[n.vertical],
                  timeout: v,
                },
                b
              ),
              w = x;
            "function" == typeof w && (w = w(k.id, k.message));
            var C = ["onEnter", "onEntered", "onExit", "onExited"].reduce(
              function (n, t) {
                var r;
                return S(
                  {},
                  n,
                  (((r = {})[t] = ec([e.snack[t], e[t]], k.id)), r)
                );
              },
              {}
            );
            return c.createElement(
              eo,
              { in: i, onExited: C.onExited },
              c.createElement(
                ef,
                {
                  open: m,
                  id: k.id,
                  disableWindowBlurListener: E,
                  autoHideDuration: k.autoHideDuration,
                  className: d(
                    eE.wrappedRoot,
                    p.root,
                    p["anchorOrigin" + N(k.anchorOrigin)]
                  ),
                  SnackbarProps: h,
                  onClose: a,
                },
                c.createElement(
                  g,
                  Object.assign({}, y, {
                    appear: !0,
                    in: m,
                    onExit: C.onExit,
                    onExited: s,
                    onEnter: C.onEnter,
                    onEntered: ec(
                      [
                        C.onEntered,
                        function () {
                          e.snack.requestClose &&
                            a(null, "instructed", e.snack.id);
                        },
                      ],
                      k.id
                    ),
                  }),
                  w ||
                    c.createElement(void 0 === f ? ev : f, Object.assign({}, k))
                )
              )
            );
          },
          ek = {
            view: { default: 20, dense: 4 },
            snackbar: { default: 6, dense: 2 },
          },
          ey = "." + er.CollapseWrapper,
          ew = et({
            root:
              (((i = {
                boxSizing: "border-box",
                display: "flex",
                maxHeight: "100%",
                position: "fixed",
                zIndex: 1400,
                height: "auto",
                width: "auto",
                transition: Q(["top", "right", "bottom", "left", "max-width"], {
                  duration: 300,
                  easing: "ease",
                }),
                pointerEvents: "none",
              })[ey] = {
                padding: ek.snackbar.default + "px 0px",
                transition: "padding 300ms ease 0ms",
              }),
              (i.maxWidth = "calc(100% - " + 2 * ek.view.default + "px)"),
              (i[R.downXs] = { width: "100%", maxWidth: "calc(100% - 32px)" }),
              i),
            rootDense:
              (((o = {})[ey] = { padding: ek.snackbar.dense + "px 0px" }), o),
            top: {
              top: ek.view.default - ek.snackbar.default + "px",
              flexDirection: "column",
            },
            bottom: {
              bottom: ek.view.default - ek.snackbar.default + "px",
              flexDirection: "column-reverse",
            },
            left:
              (((a = { left: ek.view.default + "px" })[R.upSm] = {
                alignItems: "flex-start",
              }),
              (a[R.downXs] = { left: "16px" }),
              a),
            right:
              (((s = { right: ek.view.default + "px" })[R.upSm] = {
                alignItems: "flex-end",
              }),
              (s[R.downXs] = { right: "16px" }),
              s),
            center:
              (((u = { left: "50%", transform: "translateX(-50%)" })[R.upSm] = {
                alignItems: "center",
              }),
              u),
          }),
          eC = (0, c.memo)(function (e) {
            var n = e.classes,
              t = void 0 === n ? {} : n,
              r = e.anchorOrigin,
              i = e.dense,
              o = e.children,
              a = d(
                er.SnackbarContainer,
                ew[r.vertical],
                ew[r.horizontal],
                ew.root,
                t.containerRoot,
                t["containerAnchorOrigin" + N(r)],
                i && ew.rootDense
              );
            return c.createElement("div", { className: a }, o);
          }),
          eS = function (e) {
            return !("string" == typeof e || (0, c.isValidElement)(e));
          },
          eO = (function (e) {
            function n(n) {
              var t;
              return (
                ((t = e.call(this, n) || this).enqueueSnackbar = function (
                  e,
                  n
                ) {
                  if ((void 0 === n && (n = {}), null == e))
                    throw Error("enqueueSnackbar called with invalid argument");
                  var r,
                    i = eS(e) ? e : n,
                    o = eS(e) ? e.message : e,
                    a = i.key,
                    s = i.preventDuplicate,
                    u = M(i, ["key", "preventDuplicate"]),
                    c = H(a),
                    l = c ? a : new Date().getTime() + Math.random(),
                    f =
                      ((r = t.props),
                      function (e, n) {
                        return (void 0 === n && (n = !1), n)
                          ? S({}, J[e], {}, r[e], {}, u[e])
                          : "autoHideDuration" === e
                          ? ee(u.autoHideDuration, r.autoHideDuration)
                          : "transitionDuration" === e
                          ? en(u.transitionDuration, r.transitionDuration)
                          : u[e] || r[e] || J[e];
                      }),
                    p = S({ id: l }, u, {
                      message: o,
                      open: !0,
                      entered: !1,
                      requestClose: !1,
                      persist: f("persist"),
                      action: f("action"),
                      content: f("content"),
                      variant: f("variant"),
                      anchorOrigin: f("anchorOrigin"),
                      disableWindowBlurListener: f("disableWindowBlurListener"),
                      autoHideDuration: f("autoHideDuration"),
                      hideIconVariant: f("hideIconVariant"),
                      TransitionComponent: f("TransitionComponent"),
                      transitionDuration: f("transitionDuration"),
                      TransitionProps: f("TransitionProps", !0),
                      iconVariant: f("iconVariant", !0),
                      style: f("style", !0),
                      SnackbarProps: f("SnackbarProps", !0),
                      className: d(t.props.className, u.className),
                    });
                  return (
                    p.persist && (p.autoHideDuration = void 0),
                    t.setState(function (e) {
                      if ((void 0 === s && t.props.preventDuplicate) || s) {
                        var n = function (e) {
                            return c ? e.id === l : e.message === o;
                          },
                          r = e.queue.findIndex(n) > -1,
                          i = e.snacks.findIndex(n) > -1;
                        if (r || i) return e;
                      }
                      return t.handleDisplaySnack(
                        S({}, e, { queue: [].concat(e.queue, [p]) })
                      );
                    }),
                    l
                  );
                }),
                (t.handleDisplaySnack = function (e) {
                  return e.snacks.length >= t.maxSnack
                    ? t.handleDismissOldest(e)
                    : t.processQueue(e);
                }),
                (t.processQueue = function (e) {
                  var n = e.queue,
                    t = e.snacks;
                  return n.length > 0
                    ? S({}, e, {
                        snacks: [].concat(t, [n[0]]),
                        queue: n.slice(1, n.length),
                      })
                    : e;
                }),
                (t.handleDismissOldest = function (e) {
                  if (
                    e.snacks.some(function (e) {
                      return !e.open || e.requestClose;
                    })
                  )
                    return e;
                  var n = !1,
                    r = !1;
                  e.snacks.reduce(function (e, n) {
                    return e + (n.open && n.persist ? 1 : 0);
                  }, 0) === t.maxSnack && (r = !0);
                  var i = e.snacks.map(function (e) {
                    return n || (e.persist && !r)
                      ? S({}, e)
                      : ((n = !0), e.entered)
                      ? (e.onClose && e.onClose(null, "maxsnack", e.id),
                        t.props.onClose &&
                          t.props.onClose(null, "maxsnack", e.id),
                        S({}, e, { open: !1 }))
                      : S({}, e, { requestClose: !0 });
                  });
                  return S({}, e, { snacks: i });
                }),
                (t.handleEnteredSnack = function (e, n, r) {
                  if (!H(r))
                    throw Error(
                      "handleEnteredSnack Cannot be called with undefined key"
                    );
                  t.setState(function (e) {
                    return {
                      snacks: e.snacks.map(function (e) {
                        return e.id === r
                          ? S({}, e, { entered: !0 })
                          : S({}, e);
                      }),
                    };
                  });
                }),
                (t.handleCloseSnack = function (e, n, r) {
                  t.props.onClose && t.props.onClose(e, n, r);
                  var i = void 0 === r;
                  t.setState(function (e) {
                    var n = e.snacks,
                      t = e.queue;
                    return {
                      snacks: n.map(function (e) {
                        return i || e.id === r
                          ? e.entered
                            ? S({}, e, { open: !1 })
                            : S({}, e, { requestClose: !0 })
                          : S({}, e);
                      }),
                      queue: t.filter(function (e) {
                        return e.id !== r;
                      }),
                    };
                  });
                }),
                (t.closeSnackbar = function (e) {
                  var n = t.state.snacks.find(function (n) {
                    return n.id === e;
                  });
                  H(e) && n && n.onClose && n.onClose(null, "instructed", e),
                    t.handleCloseSnack(null, "instructed", e);
                }),
                (t.handleExitedSnack = function (e, n) {
                  if (!H(n))
                    throw Error(
                      "handleExitedSnack Cannot be called with undefined key"
                    );
                  t.setState(function (e) {
                    var r = t.processQueue(
                      S({}, e, {
                        snacks: e.snacks.filter(function (e) {
                          return e.id !== n;
                        }),
                      })
                    );
                    return 0 === r.queue.length ? r : t.handleDismissOldest(r);
                  });
                }),
                t.enqueueSnackbar,
                t.closeSnackbar,
                (t.state = {
                  snacks: [],
                  queue: [],
                  contextValue: {
                    enqueueSnackbar: t.enqueueSnackbar.bind(D(t)),
                    closeSnackbar: t.closeSnackbar.bind(D(t)),
                  },
                }),
                t
              );
            }
            return (
              O(n, e),
              (n.prototype.render = function () {
                var e = this,
                  n = this.state.contextValue,
                  t = this.props,
                  r = t.domRoot,
                  i = t.children,
                  o = t.dense,
                  a = void 0 !== o && o,
                  s = t.Components,
                  u = void 0 === s ? {} : s,
                  d = t.classes,
                  f = this.state.snacks.reduce(function (e, n) {
                    var t,
                      r = N(n.anchorOrigin),
                      i = e[r] || [];
                    return S({}, e, (((t = {})[r] = [].concat(i, [n])), t));
                  }, {}),
                  p = Object.keys(f).map(function (n) {
                    var t = f[n],
                      r = t[0];
                    return c.createElement(
                      eC,
                      {
                        key: n,
                        dense: a,
                        anchorOrigin: r.anchorOrigin,
                        classes: d,
                      },
                      t.map(function (n) {
                        return c.createElement(ex, {
                          key: n.id,
                          snack: n,
                          classes: d,
                          Component: u[n.variant],
                          onClose: e.handleCloseSnack,
                          onEnter: e.props.onEnter,
                          onExit: e.props.onExit,
                          onExited: ec(
                            [e.handleExitedSnack, e.props.onExited],
                            n.id
                          ),
                          onEntered: ec(
                            [e.handleEnteredSnack, e.props.onEntered],
                            n.id
                          ),
                        });
                      })
                    );
                  });
                return c.createElement(
                  T.Provider,
                  { value: n },
                  i,
                  r ? (0, l.createPortal)(p, r) : p
                );
              }),
              C(n, [
                {
                  key: "maxSnack",
                  get: function () {
                    return this.props.maxSnack || J.maxSnack;
                  },
                },
              ]),
              n
            );
          })(c.Component),
          eM = function () {
            return (0, c.useContext)(T);
          };
      },
      60619: function (e, n, t) {
        var r = t(67294);
        function i() {
          return (i =
            Object.assign ||
            function (e) {
              for (var n = 1; n < arguments.length; n++) {
                var t = arguments[n];
                for (var r in t)
                  Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
              }
              return e;
            }).apply(this, arguments);
        }
        n.Z = function (e, n) {
          void 0 === n && (n = {});
          var o = n,
            a = o.volume,
            s = void 0 === a ? 1 : a,
            u = o.playbackRate,
            c = void 0 === u ? 1 : u,
            l = o.soundEnabled,
            d = void 0 === l || l,
            f = o.interrupt,
            p = void 0 !== f && f,
            m = o.onload,
            h = (function (e, n) {
              if (null == e) return {};
              var t,
                r,
                i = {},
                o = Object.keys(e);
              for (r = 0; r < o.length; r++)
                n.indexOf((t = o[r])) >= 0 || (i[t] = e[t]);
              return i;
            })(o, [
              "volume",
              "playbackRate",
              "soundEnabled",
              "interrupt",
              "onload",
            ]),
            g = r.useRef(null),
            b = r.useRef(!1),
            v = r.useState(!1),
            E = v[0],
            x = v[1],
            k = r.useState(null),
            y = k[0],
            w = k[1],
            C = r.useState(null),
            S = C[0],
            O = C[1],
            M = function () {
              "function" == typeof m && m.call(this),
                b.current && w(1e3 * this.duration());
            };
          (0, r.useEffect)(function () {
            return (
              t
                .e(41766)
                .then(t.t.bind(t, 41766, 23))
                .then(function (n) {
                  b.current ||
                    ((g.current = n.Howl),
                    (b.current = !0),
                    O(
                      new g.current(
                        i({ src: [e], volume: s, rate: c, onload: M }, h)
                      )
                    ));
                }),
              function () {
                b.current = !1;
              }
            );
          }, []),
            r.useEffect(
              function () {
                g.current &&
                  S &&
                  O(new g.current(i({ src: [e], volume: s, onload: M }, h)));
              },
              [e]
            ),
            r.useEffect(
              function () {
                S && (S.volume(s), S.rate(c));
              },
              [s, c]
            );
          var D = r.useCallback(
              function (e) {
                void 0 === e && (e = {}),
                  S &&
                    (d || e.forceSoundEnabled) &&
                    (p && S.stop(),
                    e.playbackRate && S.rate(e.playbackRate),
                    S.play(e.id),
                    b.current &&
                      S.once("end", function () {
                        S.playing() || x(!1);
                      }),
                    b.current && x(!0));
              },
              [S, d, p]
            ),
            L = r.useCallback(
              function (e) {
                S && (S.stop(e), b.current && x(!1));
              },
              [S]
            ),
            T = r.useCallback(
              function (e) {
                S && (S.pause(e), b.current && x(!1));
              },
              [S]
            );
          return [
            D,
            { sound: S, stop: L, pause: T, isPlaying: E, duration: y },
          ];
        };
      },
    },
  ]);
