!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "17eca957-9d02-4b6c-a202-a43092eaf606"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-17eca957-9d02-4b6c-a202-a43092eaf606"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [99536],
    {
      99536: function (e, t, a) {
        a.r(t);
        var n = a(85893),
          d = a(67294),
          o = a(73222),
          r = a(42257),
          s = a(31601),
          l = a(17253),
          i = a(13422),
          u = a(95129),
          c = a(80822),
          b = a(94745),
          y = a(23180),
          f = a(3411),
          p = a(24909),
          g = a(9512),
          m = a(37899);
        let M = () => {
          let { crazyAnalyticsService: e } = d.useContext(m.Z).services,
            t = d.useContext(r.Z),
            { isDesktop: a } = t,
            M = d.useContext(u.Z),
            { recent: _ } = d.useContext(i.rh),
            { openDrawer: k } = d.useContext(y.s9),
            w = _.filter((e) =>
              M.isAndroid ? e.androidFriendly : e.iosFriendly
            ),
            x = (0, n.jsxs)(
              c.Z,
              {
                style: {
                  fontWeight: 800,
                  fontSize: 14,
                  width: 106,
                  lineHeight: "100%",
                  cursor: "pointer",
                  whiteSpace: "normal",
                  background: f.D.black[70],
                  borderRadius: 8,
                  display: "flex",
                  alignItems: "center",
                  padding: 10,
                  border: "1px solid transparent",
                },
                sx: {
                  "&:hover": {
                    background: `${f.D.black[90]} !important`,
                    border: `1px solid ${f.D.brand[100]} !important`,
                  },
                },
                onClick: () => k("myGames"),
                children: [
                  (0, n.jsx)(b.cC, { id: "common.quicknav.recent" }),
                  (0, n.jsx)(p.Z, { style: { color: f.D.brand[60] } }),
                ],
              },
              "firstElement"
            ),
            h = a ? _ : w;
          return (0, n.jsx)(l.Z, {
            games: h,
            maxNoItems: o._R,
            pageSize: 0,
            forceSkeleton: !0,
            prependElement: x,
            renderGameThumb: (t) =>
              (0, n.jsx)(g.Z, {
                game: { ...t, gameThumbLabels: [] },
                onClickAction: () => {
                  e.gameClickedFromList(h);
                },
                isResponsive: !0,
                imgResponsiveSizes: s.D1,
              }),
          });
        };
        t.default = M;
      },
    },
  ]);
