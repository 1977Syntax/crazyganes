!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "ea8bc201-d77e-4d2d-b41b-fa740655e31a"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-ea8bc201-d77e-4d2d-b41b-fa740655e31a"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
("use strict");
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1897],
    {
      69821: function (e, t, r) {
        let n, i, s, o, a, l;
        r.d(t, {
          G: function () {
            return rU;
          },
          T: function () {
            return rW;
          },
        });
        var c,
          u,
          d,
          h,
          p,
          m,
          f,
          y,
          g,
          _,
          S,
          b,
          v = r(3e4),
          w = r(13539),
          E = r(33280),
          k = r(90059),
          M = r(51150),
          C = r(70428),
          T = r(59943),
          I = (r(37895), r(17986)),
          x = (r(49597), r(39424)),
          R = r(82305),
          D = r(26318),
          A = r(81585),
          N = r(72123),
          O = r(42206),
          L = r(50027),
          P = r(46975),
          F = r(5808),
          U = r(52340),
          B = r(26444),
          z = r(31218),
          W = r(13185),
          H = r(79769),
          $ = r(39877),
          j = r(22480),
          V = r(67127),
          q = r(25460),
          G = r(42886);
        let Y = E.n,
          K = "sentryReplaySession",
          J = "Unable to send Replay";
        function X(e, t) {
          return null != e ? e : t();
        }
        function Z(e) {
          let t;
          let r = e[0],
            n = 1;
          for (; n < e.length; ) {
            let i = e[n],
              s = e[n + 1];
            if (
              ((n += 2),
              ("optionalAccess" === i || "optionalCall" === i) && null == r)
            )
              return;
            "access" === i || "optionalAccess" === i
              ? ((t = r), (r = s(r)))
              : ("call" === i || "optionalCall" === i) &&
                ((r = s((...e) => r.call(t, ...e))), (t = void 0));
          }
          return r;
        }
        function Q(e) {
          let t = Z([e, "optionalAccess", (e) => e.host]);
          return Boolean(Z([t, "optionalAccess", (e) => e.shadowRoot]) === e);
        }
        function ee(e) {
          return "[object ShadowRoot]" === Object.prototype.toString.call(e);
        }
        function et(e) {
          try {
            var t;
            let r = e.rules || e.cssRules;
            return r
              ? ((t = Array.from(r, er).join("")).includes(
                  " background-clip: text;"
                ) &&
                  !t.includes(" -webkit-background-clip: text;") &&
                  (t = t.replace(
                    /\sbackground-clip:\s*text;/g,
                    " -webkit-background-clip: text; background-clip: text;"
                  )),
                t)
              : null;
          } catch (e) {
            return null;
          }
        }
        function er(e) {
          let t;
          if ("styleSheet" in e)
            try {
              t =
                et(e.styleSheet) ||
                (function (e) {
                  let { cssText: t } = e;
                  if (t.split('"').length < 3) return t;
                  let r = ["@import", `url(${JSON.stringify(e.href)})`];
                  return (
                    "" === e.layerName
                      ? r.push("layer")
                      : e.layerName && r.push(`layer(${e.layerName})`),
                    e.supportsText && r.push(`supports(${e.supportsText})`),
                    e.media.length && r.push(e.media.mediaText),
                    r.join(" ") + ";"
                  );
                })(e);
            } catch (e) {}
          else if ("selectorText" in e) {
            let t = e.cssText,
              r = e.selectorText.includes(":"),
              n = "string" == typeof e.style.all && e.style.all;
            if (
              (n &&
                (t = (function (e) {
                  let t = "";
                  for (let r = 0; r < e.style.length; r++) {
                    let n = e.style,
                      i = n[r],
                      s = n.getPropertyPriority(i);
                    t += `${i}:${n.getPropertyValue(i)}${
                      s ? " !important" : ""
                    };`;
                  }
                  return `${e.selectorText} { ${t} }`;
                })(e)),
              r &&
                (t = t.replace(
                  /(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm,
                  "$1\\$2"
                )),
              r || n)
            )
              return t;
          }
          return t || e.cssText;
        }
        ((c = g || (g = {}))[(c.Document = 0)] = "Document"),
          (c[(c.DocumentType = 1)] = "DocumentType"),
          (c[(c.Element = 2)] = "Element"),
          (c[(c.Text = 3)] = "Text"),
          (c[(c.CDATA = 4)] = "CDATA"),
          (c[(c.Comment = 5)] = "Comment");
        class en {
          constructor() {
            (this.idNodeMap = new Map()), (this.nodeMetaMap = new WeakMap());
          }
          getId(e) {
            if (!e) return -1;
            let t = Z([
              this,
              "access",
              (e) => e.getMeta,
              "call",
              (t) => t(e),
              "optionalAccess",
              (e) => e.id,
            ]);
            return X(t, () => -1);
          }
          getNode(e) {
            return this.idNodeMap.get(e) || null;
          }
          getIds() {
            return Array.from(this.idNodeMap.keys());
          }
          getMeta(e) {
            return this.nodeMetaMap.get(e) || null;
          }
          removeNodeFromMap(e) {
            let t = this.getId(e);
            this.idNodeMap.delete(t),
              e.childNodes &&
                e.childNodes.forEach((e) => this.removeNodeFromMap(e));
          }
          has(e) {
            return this.idNodeMap.has(e);
          }
          hasNode(e) {
            return this.nodeMetaMap.has(e);
          }
          add(e, t) {
            let r = t.id;
            this.idNodeMap.set(r, e), this.nodeMetaMap.set(e, t);
          }
          replace(e, t) {
            let r = this.getNode(e);
            if (r) {
              let e = this.nodeMetaMap.get(r);
              e && this.nodeMetaMap.set(t, e);
            }
            this.idNodeMap.set(e, t);
          }
          reset() {
            (this.idNodeMap = new Map()), (this.nodeMetaMap = new WeakMap());
          }
        }
        function ei({ maskInputOptions: e, tagName: t, type: r }) {
          return (
            "OPTION" === t && (t = "SELECT"),
            Boolean(
              e[t.toLowerCase()] ||
                (r && e[r]) ||
                "password" === r ||
                ("INPUT" === t && !r && e.text)
            )
          );
        }
        function es({ isMasked: e, element: t, value: r, maskInputFn: n }) {
          let i = r || "";
          return e ? (n && (i = n(i, t)), "*".repeat(i.length)) : i;
        }
        function eo(e) {
          return e.toLowerCase();
        }
        function ea(e) {
          return e.toUpperCase();
        }
        let el = "__rrweb_original__";
        function ec(e) {
          let t = e.type;
          return e.hasAttribute("data-rr-is-password")
            ? "password"
            : t
            ? eo(t)
            : null;
        }
        function eu(e, t, r) {
          return "INPUT" === t && ("radio" === r || "checkbox" === r)
            ? e.getAttribute("value") || ""
            : e.value;
        }
        function ed(e, t) {
          let r;
          try {
            r = new URL(
              e,
              X(t, () => window.location.href)
            );
          } catch (e) {
            return null;
          }
          let n = r.pathname.match(/\.([0-9a-z]+)(?:$)/i);
          return X(Z([n, "optionalAccess", (e) => e[1]]), () => null);
        }
        let eh = {};
        function ep(e) {
          let t = eh[e];
          if (t) return t;
          let r = window.document,
            n = window[e];
          if (r && "function" == typeof r.createElement)
            try {
              let t = r.createElement("iframe");
              (t.hidden = !0), r.head.appendChild(t);
              let i = t.contentWindow;
              i && i[e] && (n = i[e]), r.head.removeChild(t);
            } catch (e) {}
          return (eh[e] = n.bind(window));
        }
        function em(...e) {
          return ep("setTimeout")(...e);
        }
        function ef(...e) {
          return ep("clearTimeout")(...e);
        }
        function ey(e) {
          try {
            return e.contentDocument;
          } catch (e) {}
        }
        let eg = 1,
          e_ = RegExp("[^a-z0-9-_:]");
        function eS() {
          return eg++;
        }
        let eb = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
          ev = /^(?:[a-z+]+:)?\/\//i,
          ew = /^www\..*/i,
          eE = /^(data:)([^,]*),(.*)/i;
        function ek(e, t) {
          return (e || "").replace(eb, (e, r, n, i, s, o) => {
            let a = n || s || o,
              l = r || i || "";
            if (!a) return e;
            if (ev.test(a) || ew.test(a) || eE.test(a))
              return `url(${l}${a}${l})`;
            if ("/" === a[0])
              return `url(${l}${
                (t.indexOf("//") > -1
                  ? t.split("/").slice(0, 3).join("/")
                  : t.split("/")[0]
                ).split("?")[0] + a
              }${l})`;
            let c = t.split("/"),
              u = a.split("/");
            for (let e of (c.pop(), u))
              "." !== e && (".." === e ? c.pop() : c.push(e));
            return `url(${l}${c.join("/")}${l})`;
          });
        }
        let eM = /^[^ \t\n\r\u000c]+/,
          eC = /^[, \t\n\r\u000c]+/,
          eT = new WeakMap();
        function eI(e, t) {
          return t && "" !== t.trim() ? ex(e, t) : t;
        }
        function ex(e, t) {
          let r = eT.get(e);
          if ((r || ((r = e.createElement("a")), eT.set(e, r)), t)) {
            if (t.startsWith("blob:") || t.startsWith("data:")) return t;
          } else t = "";
          return r.setAttribute("href", t), r.href;
        }
        function eR(e, t, r, n, i, s) {
          return n
            ? "src" !== r &&
              ("href" !== r || ("use" === t && "#" === n[0])) &&
              ("xlink:href" !== r || "#" === n[0]) &&
              ("background" !== r ||
                ("table" !== t && "td" !== t && "th" !== t))
              ? "srcset" === r
                ? (function (e, t) {
                    if ("" === t.trim()) return t;
                    let r = 0;
                    function n(e) {
                      let n;
                      let i = e.exec(t.substring(r));
                      return i ? ((n = i[0]), (r += n.length), n) : "";
                    }
                    let i = [];
                    for (; n(eC), !(r >= t.length); ) {
                      let s = n(eM);
                      if ("," === s.slice(-1))
                        (s = eI(e, s.substring(0, s.length - 1))), i.push(s);
                      else {
                        let n = "";
                        s = eI(e, s);
                        let o = !1;
                        for (;;) {
                          let e = t.charAt(r);
                          if ("" === e) {
                            i.push((s + n).trim());
                            break;
                          }
                          if (o) ")" === e && (o = !1);
                          else {
                            if ("," === e) {
                              (r += 1), i.push((s + n).trim());
                              break;
                            }
                            "(" === e && (o = !0);
                          }
                          (n += e), (r += 1);
                        }
                      }
                    }
                    return i.join(", ");
                  })(e, n)
                : "style" === r
                ? ek(n, ex(e))
                : "object" === t && "data" === r
                ? eI(e, n)
                : "function" == typeof s
                ? s(r, n, i)
                : n
              : eI(e, n)
            : n;
        }
        function eD(e, t, r) {
          return ("video" === e || "audio" === e) && "autoplay" === t;
        }
        function eA(e, t, r = 1 / 0, n = 0) {
          return !e || e.nodeType !== e.ELEMENT_NODE || n > r
            ? -1
            : t(e)
            ? n
            : eA(e.parentNode, t, r, n + 1);
        }
        function eN(e, t) {
          return (r) => {
            if (null === r) return !1;
            try {
              if (e) {
                if ("string" == typeof e) {
                  if (r.matches(`.${e}`)) return !0;
                } else if (
                  (function (e, t) {
                    for (let r = e.classList.length; r--; ) {
                      let n = e.classList[r];
                      if (t.test(n)) return !0;
                    }
                    return !1;
                  })(r, e)
                )
                  return !0;
              }
              if (t && r.matches(t)) return !0;
              return !1;
            } catch (e) {
              return !1;
            }
          };
        }
        function eO(e, t, r, n, i, s) {
          try {
            let o = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
            if (null === o) return !1;
            if ("INPUT" === o.tagName) {
              let e = o.getAttribute("autocomplete");
              if (
                [
                  "current-password",
                  "new-password",
                  "cc-number",
                  "cc-exp",
                  "cc-exp-month",
                  "cc-exp-year",
                  "cc-csc",
                ].includes(e)
              )
                return !0;
            }
            let a = -1,
              l = -1;
            if (s) {
              if ((l = eA(o, eN(n, i))) < 0) return !0;
              a = eA(o, eN(t, r), l >= 0 ? l : 1 / 0);
            } else {
              if ((a = eA(o, eN(t, r))) < 0) return !1;
              l = eA(o, eN(n, i), a >= 0 ? a : 1 / 0);
            }
            return a >= 0 ? !(l >= 0) || a <= l : !(l >= 0) && !!s;
          } catch (e) {}
          return !!s;
        }
        function eL(e) {
          return null == e ? "" : e.toLowerCase();
        }
        function eP(e, t) {
          let r;
          let {
              doc: s,
              mirror: o,
              blockClass: a,
              blockSelector: l,
              unblockSelector: c,
              maskAllText: u,
              maskTextClass: d,
              unmaskTextClass: h,
              maskTextSelector: p,
              unmaskTextSelector: m,
              skipChild: f = !1,
              inlineStylesheet: y = !0,
              maskInputOptions: _ = {},
              maskAttributeFn: S,
              maskTextFn: b,
              maskInputFn: v,
              slimDOMOptions: w,
              dataURLOptions: E = {},
              inlineImages: k = !1,
              recordCanvas: M = !1,
              onSerialize: C,
              onIframeLoad: T,
              iframeLoadTimeout: I = 5e3,
              onStylesheetLoad: x,
              stylesheetLoadTimeout: R = 5e3,
              keepIframeSrcFn: D = () => !1,
              newlyAddedElement: A = !1,
            } = t,
            { preserveWhiteSpace: N = !0 } = t,
            O = (function (e, t) {
              let {
                  doc: r,
                  mirror: s,
                  blockClass: o,
                  blockSelector: a,
                  unblockSelector: l,
                  maskAllText: c,
                  maskAttributeFn: u,
                  maskTextClass: d,
                  unmaskTextClass: h,
                  maskTextSelector: p,
                  unmaskTextSelector: m,
                  inlineStylesheet: f,
                  maskInputOptions: y = {},
                  maskTextFn: _,
                  maskInputFn: S,
                  dataURLOptions: b = {},
                  inlineImages: v,
                  recordCanvas: w,
                  keepIframeSrcFn: E,
                  newlyAddedElement: k = !1,
                } = t,
                M = (function (e, t) {
                  if (!t.hasNode(e)) return;
                  let r = t.getId(e);
                  return 1 === r ? void 0 : r;
                })(r, s);
              switch (e.nodeType) {
                case e.DOCUMENT_NODE:
                  if ("CSS1Compat" !== e.compatMode)
                    return {
                      type: g.Document,
                      childNodes: [],
                      compatMode: e.compatMode,
                    };
                  return { type: g.Document, childNodes: [] };
                case e.DOCUMENT_TYPE_NODE:
                  return {
                    type: g.DocumentType,
                    name: e.name,
                    publicId: e.publicId,
                    systemId: e.systemId,
                    rootId: M,
                  };
                case e.ELEMENT_NODE:
                  return (function (e, t) {
                    let r;
                    let {
                        doc: s,
                        blockClass: o,
                        blockSelector: a,
                        unblockSelector: l,
                        inlineStylesheet: c,
                        maskInputOptions: u = {},
                        maskAttributeFn: d,
                        maskInputFn: h,
                        dataURLOptions: p = {},
                        inlineImages: m,
                        recordCanvas: f,
                        keepIframeSrcFn: y,
                        newlyAddedElement: _ = !1,
                        rootId: S,
                        maskAllText: b,
                        maskTextClass: v,
                        unmaskTextClass: w,
                        maskTextSelector: E,
                        unmaskTextSelector: k,
                      } = t,
                      M = (function (e, t, r, n) {
                        try {
                          if (n && e.matches(n)) return !1;
                          if ("string" == typeof t) {
                            if (e.classList.contains(t)) return !0;
                          } else
                            for (let r = e.classList.length; r--; ) {
                              let n = e.classList[r];
                              if (t.test(n)) return !0;
                            }
                          if (r) return e.matches(r);
                        } catch (e) {}
                        return !1;
                      })(e, o, a, l),
                      C = (function (e) {
                        if (e instanceof HTMLFormElement) return "form";
                        let t = eo(e.tagName);
                        return e_.test(t) ? "div" : t;
                      })(e),
                      T = {},
                      I = e.attributes.length;
                    for (let t = 0; t < I; t++) {
                      let r = e.attributes[t];
                      r.name &&
                        !eD(C, r.name, r.value) &&
                        (T[r.name] = eR(s, C, eo(r.name), r.value, e, d));
                    }
                    if ("link" === C && c) {
                      let t = Array.from(s.styleSheets).find(
                          (t) => t.href === e.href
                        ),
                        r = null;
                      t && (r = et(t)),
                        r &&
                          (delete T.rel,
                          delete T.href,
                          (T._cssText = ek(r, t.href)));
                    }
                    if (
                      "style" === C &&
                      e.sheet &&
                      !(e.innerText || e.textContent || "").trim().length
                    ) {
                      let t = et(e.sheet);
                      t && (T._cssText = ek(t, ex(s)));
                    }
                    if (
                      "input" === C ||
                      "textarea" === C ||
                      "select" === C ||
                      "option" === C
                    ) {
                      let t = ec(e),
                        r = eu(e, ea(C), t),
                        n = e.checked;
                      if ("submit" !== t && "button" !== t && r) {
                        let n = eO(
                          e,
                          v,
                          E,
                          w,
                          k,
                          ei({ type: t, tagName: ea(C), maskInputOptions: u })
                        );
                        T.value = es({
                          isMasked: n,
                          element: e,
                          value: r,
                          maskInputFn: h,
                        });
                      }
                      n && (T.checked = n);
                    }
                    if (
                      ("option" === C &&
                        (e.selected && !u.select
                          ? (T.selected = !0)
                          : delete T.selected),
                      "canvas" === C && f)
                    ) {
                      if ("2d" === e.__context)
                        !(function (e) {
                          let t = e.getContext("2d");
                          if (!t) return !0;
                          for (let r = 0; r < e.width; r += 50)
                            for (let n = 0; n < e.height; n += 50) {
                              let i = t.getImageData,
                                s = el in i ? i[el] : i,
                                o = new Uint32Array(
                                  s.call(
                                    t,
                                    r,
                                    n,
                                    Math.min(50, e.width - r),
                                    Math.min(50, e.height - n)
                                  ).data.buffer
                                );
                              if (o.some((e) => 0 !== e)) return !1;
                            }
                          return !0;
                        })(e) &&
                          (T.rr_dataURL = e.toDataURL(p.type, p.quality));
                      else if (!("__context" in e)) {
                        let t = e.toDataURL(p.type, p.quality),
                          r = s.createElement("canvas");
                        (r.width = e.width), (r.height = e.height);
                        let n = r.toDataURL(p.type, p.quality);
                        t !== n && (T.rr_dataURL = t);
                      }
                    }
                    if ("img" === C && m) {
                      n ||
                        (i = (n = s.createElement("canvas")).getContext("2d"));
                      let t = e,
                        r =
                          t.currentSrc ||
                          t.getAttribute("src") ||
                          "<unknown-src>",
                        o = t.crossOrigin,
                        a = () => {
                          t.removeEventListener("load", a);
                          try {
                            (n.width = t.naturalWidth),
                              (n.height = t.naturalHeight),
                              i.drawImage(t, 0, 0),
                              (T.rr_dataURL = n.toDataURL(p.type, p.quality));
                          } catch (e) {
                            if ("anonymous" !== t.crossOrigin) {
                              (t.crossOrigin = "anonymous"),
                                t.complete && 0 !== t.naturalWidth
                                  ? a()
                                  : t.addEventListener("load", a);
                              return;
                            }
                            console.warn(
                              `Cannot inline img src=${r}! Error: ${e}`
                            );
                          }
                          "anonymous" === t.crossOrigin &&
                            (o
                              ? (T.crossOrigin = o)
                              : t.removeAttribute("crossorigin"));
                        };
                      t.complete && 0 !== t.naturalWidth
                        ? a()
                        : t.addEventListener("load", a);
                    }
                    if (
                      (("audio" === C || "video" === C) &&
                        ((T.rr_mediaState = e.paused ? "paused" : "played"),
                        (T.rr_mediaCurrentTime = e.currentTime)),
                      !_ &&
                        (e.scrollLeft && (T.rr_scrollLeft = e.scrollLeft),
                        e.scrollTop && (T.rr_scrollTop = e.scrollTop)),
                      M)
                    ) {
                      let { width: t, height: r } = e.getBoundingClientRect();
                      T = {
                        class: T.class,
                        rr_width: `${t}px`,
                        rr_height: `${r}px`,
                      };
                    }
                    "iframe" !== C ||
                      y(T.src) ||
                      (M || ey(e) || (T.rr_src = T.src), delete T.src);
                    try {
                      customElements.get(C) && (r = !0);
                    } catch (e) {}
                    return {
                      type: g.Element,
                      tagName: C,
                      attributes: T,
                      childNodes: [],
                      isSVG:
                        Boolean("svg" === e.tagName || e.ownerSVGElement) ||
                        void 0,
                      needBlock: M,
                      rootId: S,
                      isCustom: r,
                    };
                  })(e, {
                    doc: r,
                    blockClass: o,
                    blockSelector: a,
                    unblockSelector: l,
                    inlineStylesheet: f,
                    maskAttributeFn: u,
                    maskInputOptions: y,
                    maskInputFn: S,
                    dataURLOptions: b,
                    inlineImages: v,
                    recordCanvas: w,
                    keepIframeSrcFn: E,
                    newlyAddedElement: k,
                    rootId: M,
                    maskAllText: c,
                    maskTextClass: d,
                    unmaskTextClass: h,
                    maskTextSelector: p,
                    unmaskTextSelector: m,
                  });
                case e.TEXT_NODE:
                  return (function (e, t) {
                    let {
                        maskAllText: r,
                        maskTextClass: n,
                        unmaskTextClass: i,
                        maskTextSelector: s,
                        unmaskTextSelector: o,
                        maskTextFn: a,
                        maskInputOptions: l,
                        maskInputFn: c,
                        rootId: u,
                      } = t,
                      d = e.parentNode && e.parentNode.tagName,
                      h = e.textContent,
                      p = "STYLE" === d || void 0,
                      m = "SCRIPT" === d || void 0,
                      f = "TEXTAREA" === d || void 0;
                    if (p && h) {
                      try {
                        e.nextSibling ||
                          e.previousSibling ||
                          (Z([
                            e,
                            "access",
                            (e) => e.parentNode,
                            "access",
                            (e) => e.sheet,
                            "optionalAccess",
                            (e) => e.cssRules,
                          ]) &&
                            (h = et(e.parentNode.sheet)));
                      } catch (t) {
                        console.warn(
                          `Cannot get CSS styles from text's parentNode. Error: ${t}`,
                          e
                        );
                      }
                      h = ek(h, ex(t.doc));
                    }
                    m && (h = "SCRIPT_PLACEHOLDER");
                    let y = eO(e, n, s, i, o, r);
                    if (
                      (p ||
                        m ||
                        f ||
                        !h ||
                        !y ||
                        (h = a
                          ? a(h, e.parentElement)
                          : h.replace(/[\S]/g, "*")),
                      f &&
                        h &&
                        (l.textarea || y) &&
                        (h = c ? c(h, e.parentNode) : h.replace(/[\S]/g, "*")),
                      "OPTION" === d && h)
                    ) {
                      let t = ei({
                        type: null,
                        tagName: d,
                        maskInputOptions: l,
                      });
                      h = es({
                        isMasked: eO(e, n, s, i, o, t),
                        element: e,
                        value: h,
                        maskInputFn: c,
                      });
                    }
                    return {
                      type: g.Text,
                      textContent: h || "",
                      isStyle: p,
                      rootId: u,
                    };
                  })(e, {
                    doc: r,
                    maskAllText: c,
                    maskTextClass: d,
                    unmaskTextClass: h,
                    maskTextSelector: p,
                    unmaskTextSelector: m,
                    maskTextFn: _,
                    maskInputOptions: y,
                    maskInputFn: S,
                    rootId: M,
                  });
                case e.CDATA_SECTION_NODE:
                  return { type: g.CDATA, textContent: "", rootId: M };
                case e.COMMENT_NODE:
                  return {
                    type: g.Comment,
                    textContent: e.textContent || "",
                    rootId: M,
                  };
                default:
                  return !1;
              }
            })(e, {
              doc: s,
              mirror: o,
              blockClass: a,
              blockSelector: l,
              maskAllText: u,
              unblockSelector: c,
              maskTextClass: d,
              unmaskTextClass: h,
              maskTextSelector: p,
              unmaskTextSelector: m,
              inlineStylesheet: y,
              maskInputOptions: _,
              maskAttributeFn: S,
              maskTextFn: b,
              maskInputFn: v,
              dataURLOptions: E,
              inlineImages: k,
              recordCanvas: M,
              keepIframeSrcFn: D,
              newlyAddedElement: A,
            });
          if (!O) return console.warn(e, "not serialized"), null;
          r = o.hasNode(e)
            ? o.getId(e)
            : !(function (e, t) {
                if (t.comment && e.type === g.Comment) return !0;
                if (e.type === g.Element) {
                  if (
                    (t.script &&
                      ("script" === e.tagName ||
                        ("link" === e.tagName &&
                          ("preload" === e.attributes.rel ||
                            "modulepreload" === e.attributes.rel) &&
                          "script" === e.attributes.as) ||
                        ("link" === e.tagName &&
                          "prefetch" === e.attributes.rel &&
                          "string" == typeof e.attributes.href &&
                          "js" === ed(e.attributes.href)))) ||
                    (t.headFavicon &&
                      (("link" === e.tagName &&
                        "shortcut icon" === e.attributes.rel) ||
                        ("meta" === e.tagName &&
                          (eL(e.attributes.name).match(
                            /^msapplication-tile(image|color)$/
                          ) ||
                            "application-name" === eL(e.attributes.name) ||
                            "icon" === eL(e.attributes.rel) ||
                            "apple-touch-icon" === eL(e.attributes.rel) ||
                            "shortcut icon" === eL(e.attributes.rel)))))
                  )
                    return !0;
                  if ("meta" === e.tagName) {
                    if (
                      (t.headMetaDescKeywords &&
                        eL(e.attributes.name).match(
                          /^description|keywords$/
                        )) ||
                      (t.headMetaSocial &&
                        (eL(e.attributes.property).match(/^(og|twitter|fb):/) ||
                          eL(e.attributes.name).match(/^(og|twitter):/) ||
                          "pinterest" === eL(e.attributes.name)))
                    )
                      return !0;
                    if (
                      t.headMetaRobots &&
                      ("robots" === eL(e.attributes.name) ||
                        "googlebot" === eL(e.attributes.name) ||
                        "bingbot" === eL(e.attributes.name))
                    )
                      return !0;
                    if (
                      t.headMetaHttpEquiv &&
                      void 0 !== e.attributes["http-equiv"]
                    )
                      return !0;
                    else if (
                      t.headMetaAuthorship &&
                      ("author" === eL(e.attributes.name) ||
                        "generator" === eL(e.attributes.name) ||
                        "framework" === eL(e.attributes.name) ||
                        "publisher" === eL(e.attributes.name) ||
                        "progid" === eL(e.attributes.name) ||
                        eL(e.attributes.property).match(/^article:/) ||
                        eL(e.attributes.property).match(/^product:/))
                    )
                      return !0;
                    else if (
                      t.headMetaVerification &&
                      ("google-site-verification" === eL(e.attributes.name) ||
                        "yandex-verification" === eL(e.attributes.name) ||
                        "csrf-token" === eL(e.attributes.name) ||
                        "p:domain_verify" === eL(e.attributes.name) ||
                        "verify-v1" === eL(e.attributes.name) ||
                        "verification" === eL(e.attributes.name) ||
                        "shopify-checkout-api-token" === eL(e.attributes.name))
                    )
                      return !0;
                  }
                }
                return !1;
              })(O, w) &&
              (N ||
                O.type !== g.Text ||
                O.isStyle ||
                O.textContent.replace(/^\s+|\s+$/gm, "").length)
            ? eS()
            : -2;
          let L = Object.assign(O, { id: r });
          if ((o.add(e, L), -2 === r)) return null;
          C && C(e);
          let P = !f;
          if (L.type === g.Element) {
            (P = P && !L.needBlock), delete L.needBlock;
            let t = e.shadowRoot;
            t && ee(t) && (L.isShadowHost = !0);
          }
          if ((L.type === g.Document || L.type === g.Element) && P) {
            w.headWhitespace &&
              L.type === g.Element &&
              "head" === L.tagName &&
              (N = !1);
            let t = {
              doc: s,
              mirror: o,
              blockClass: a,
              blockSelector: l,
              maskAllText: u,
              unblockSelector: c,
              maskTextClass: d,
              unmaskTextClass: h,
              maskTextSelector: p,
              unmaskTextSelector: m,
              skipChild: f,
              inlineStylesheet: y,
              maskInputOptions: _,
              maskAttributeFn: S,
              maskTextFn: b,
              maskInputFn: v,
              slimDOMOptions: w,
              dataURLOptions: E,
              inlineImages: k,
              recordCanvas: M,
              preserveWhiteSpace: N,
              onSerialize: C,
              onIframeLoad: T,
              iframeLoadTimeout: I,
              onStylesheetLoad: x,
              stylesheetLoadTimeout: R,
              keepIframeSrcFn: D,
            };
            for (let r of Array.from(e.childNodes)) {
              let e = eP(r, t);
              e && L.childNodes.push(e);
            }
            if (e.nodeType === e.ELEMENT_NODE && e.shadowRoot)
              for (let r of Array.from(e.shadowRoot.childNodes)) {
                let n = eP(r, t);
                n &&
                  (ee(e.shadowRoot) && (n.isShadow = !0), L.childNodes.push(n));
              }
          }
          return (
            e.parentNode &&
              Q(e.parentNode) &&
              ee(e.parentNode) &&
              (L.isShadow = !0),
            L.type === g.Element &&
              "iframe" === L.tagName &&
              (function (e, t, r) {
                let n;
                let i = e.contentWindow;
                if (!i) return;
                let s = !1;
                try {
                  n = i.document.readyState;
                } catch (e) {
                  return;
                }
                if ("complete" !== n) {
                  let n = em(() => {
                    s || (t(), (s = !0));
                  }, r);
                  e.addEventListener("load", () => {
                    ef(n), (s = !0), t();
                  });
                  return;
                }
                let o = "about:blank";
                if (i.location.href !== o || e.src === o || "" === e.src)
                  return em(t, 0), e.addEventListener("load", t);
                e.addEventListener("load", t);
              })(
                e,
                () => {
                  let t = ey(e);
                  if (t && T) {
                    let r = eP(t, {
                      doc: t,
                      mirror: o,
                      blockClass: a,
                      blockSelector: l,
                      unblockSelector: c,
                      maskAllText: u,
                      maskTextClass: d,
                      unmaskTextClass: h,
                      maskTextSelector: p,
                      unmaskTextSelector: m,
                      skipChild: !1,
                      inlineStylesheet: y,
                      maskInputOptions: _,
                      maskAttributeFn: S,
                      maskTextFn: b,
                      maskInputFn: v,
                      slimDOMOptions: w,
                      dataURLOptions: E,
                      inlineImages: k,
                      recordCanvas: M,
                      preserveWhiteSpace: N,
                      onSerialize: C,
                      onIframeLoad: T,
                      iframeLoadTimeout: I,
                      onStylesheetLoad: x,
                      stylesheetLoadTimeout: R,
                      keepIframeSrcFn: D,
                    });
                    r && T(e, r);
                  }
                },
                I
              ),
            L.type === g.Element &&
              "link" === L.tagName &&
              "string" == typeof L.attributes.rel &&
              ("stylesheet" === L.attributes.rel ||
                ("preload" === L.attributes.rel &&
                  "string" == typeof L.attributes.href &&
                  "css" === ed(L.attributes.href))) &&
              (function (e, t, r) {
                let n,
                  i = !1;
                try {
                  n = e.sheet;
                } catch (e) {
                  return;
                }
                if (n) return;
                let s = em(() => {
                  i || (t(), (i = !0));
                }, r);
                e.addEventListener("load", () => {
                  ef(s), (i = !0), t();
                });
              })(
                e,
                () => {
                  if (x) {
                    let t = eP(e, {
                      doc: s,
                      mirror: o,
                      blockClass: a,
                      blockSelector: l,
                      unblockSelector: c,
                      maskAllText: u,
                      maskTextClass: d,
                      unmaskTextClass: h,
                      maskTextSelector: p,
                      unmaskTextSelector: m,
                      skipChild: !1,
                      inlineStylesheet: y,
                      maskInputOptions: _,
                      maskAttributeFn: S,
                      maskTextFn: b,
                      maskInputFn: v,
                      slimDOMOptions: w,
                      dataURLOptions: E,
                      inlineImages: k,
                      recordCanvas: M,
                      preserveWhiteSpace: N,
                      onSerialize: C,
                      onIframeLoad: T,
                      iframeLoadTimeout: I,
                      onStylesheetLoad: x,
                      stylesheetLoadTimeout: R,
                      keepIframeSrcFn: D,
                    });
                    t && x(e, t);
                  }
                },
                R
              ),
            L
          );
        }
        function eF(e) {
          let t;
          let r = e[0],
            n = 1;
          for (; n < e.length; ) {
            let i = e[n],
              s = e[n + 1];
            if (
              ((n += 2),
              ("optionalAccess" === i || "optionalCall" === i) && null == r)
            )
              return;
            "access" === i || "optionalAccess" === i
              ? ((t = r), (r = s(r)))
              : ("call" === i || "optionalCall" === i) &&
                ((r = s((...e) => r.call(t, ...e))), (t = void 0));
          }
          return r;
        }
        function eU(e, t, r = document) {
          let n = { capture: !0, passive: !0 };
          return (
            r.addEventListener(e, t, n), () => r.removeEventListener(e, t, n)
          );
        }
        let eB =
            "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
          ez = {
            map: {},
            getId: () => (console.error(eB), -1),
            getNode: () => (console.error(eB), null),
            removeNodeFromMap() {
              console.error(eB);
            },
            has: () => (console.error(eB), !1),
            reset() {
              console.error(eB);
            },
          };
        function eW(e, t, r = {}) {
          let n = null,
            i = 0;
          return function (...s) {
            let o = Date.now();
            i || !1 !== r.leading || (i = o);
            let a = t - (o - i),
              l = this;
            a <= 0 || a > t
              ? (n &&
                  ((function (...e) {
                    e2("clearTimeout")(...e);
                  })(n),
                  (n = null)),
                (i = o),
                e.apply(l, s))
              : n ||
                !1 === r.trailing ||
                (n = e5(() => {
                  (i = !1 === r.leading ? 0 : Date.now()),
                    (n = null),
                    e.apply(l, s);
                }, a));
          };
        }
        function eH(e, t, r) {
          try {
            if (!(t in e)) return () => {};
            let n = e[t],
              i = r(n);
            return (
              "function" == typeof i &&
                ((i.prototype = i.prototype || {}),
                Object.defineProperties(i, {
                  __rrweb_original__: { enumerable: !1, value: n },
                })),
              (e[t] = i),
              () => {
                e[t] = n;
              }
            );
          } catch (e) {
            return () => {};
          }
        }
        "undefined" != typeof window &&
          window.Proxy &&
          window.Reflect &&
          (ez = new Proxy(ez, {
            get: (e, t, r) => (
              "map" === t && console.error(eB), Reflect.get(e, t, r)
            ),
          }));
        let e$ = Date.now;
        function ej(e) {
          let t = e.document;
          return {
            left: t.scrollingElement
              ? t.scrollingElement.scrollLeft
              : void 0 !== e.pageXOffset
              ? e.pageXOffset
              : eF([
                  t,
                  "optionalAccess",
                  (e) => e.documentElement,
                  "access",
                  (e) => e.scrollLeft,
                ]) ||
                eF([
                  t,
                  "optionalAccess",
                  (e) => e.body,
                  "optionalAccess",
                  (e) => e.parentElement,
                  "optionalAccess",
                  (e) => e.scrollLeft,
                ]) ||
                eF([
                  t,
                  "optionalAccess",
                  (e) => e.body,
                  "optionalAccess",
                  (e) => e.scrollLeft,
                ]) ||
                0,
            top: t.scrollingElement
              ? t.scrollingElement.scrollTop
              : void 0 !== e.pageYOffset
              ? e.pageYOffset
              : eF([
                  t,
                  "optionalAccess",
                  (e) => e.documentElement,
                  "access",
                  (e) => e.scrollTop,
                ]) ||
                eF([
                  t,
                  "optionalAccess",
                  (e) => e.body,
                  "optionalAccess",
                  (e) => e.parentElement,
                  "optionalAccess",
                  (e) => e.scrollTop,
                ]) ||
                eF([
                  t,
                  "optionalAccess",
                  (e) => e.body,
                  "optionalAccess",
                  (e) => e.scrollTop,
                ]) ||
                0,
          };
        }
        function eV() {
          return (
            window.innerHeight ||
            (document.documentElement &&
              document.documentElement.clientHeight) ||
            (document.body && document.body.clientHeight)
          );
        }
        function eq() {
          return (
            window.innerWidth ||
            (document.documentElement &&
              document.documentElement.clientWidth) ||
            (document.body && document.body.clientWidth)
          );
        }
        function eG(e) {
          if (!e) return null;
          let t = e.nodeType === e.ELEMENT_NODE ? e : e.parentElement;
          return t;
        }
        function eY(e, t, r, n, i) {
          if (!e) return !1;
          let s = eG(e);
          if (!s) return !1;
          let o = eN(t, r);
          if (!i) {
            let e = n && s.matches(n);
            return o(s) && !e;
          }
          let a = eA(s, o),
            l = -1;
          return (
            !(a < 0) &&
            (n && (l = eA(s, eN(null, n))), (a > -1 && l < 0) || a < l)
          );
        }
        function eK(e, t) {
          return -2 === t.getId(e);
        }
        function eJ(e) {
          return Boolean(e.changedTouches);
        }
        function eX(e, t) {
          return Boolean("IFRAME" === e.nodeName && t.getMeta(e));
        }
        function eZ(e, t) {
          return Boolean(
            "LINK" === e.nodeName &&
              e.nodeType === e.ELEMENT_NODE &&
              e.getAttribute &&
              "stylesheet" === e.getAttribute("rel") &&
              t.getMeta(e)
          );
        }
        function eQ(e) {
          return Boolean(eF([e, "optionalAccess", (e) => e.shadowRoot]));
        }
        /[1-9][0-9]{12}/.test(Date.now().toString()) ||
          (e$ = () => new Date().getTime());
        class e0 {
          constructor() {
            (this.id = 1),
              (this.styleIDMap = new WeakMap()),
              (this.idStyleMap = new Map());
          }
          getId(e) {
            return (0, v.h)(this.styleIDMap.get(e), () => -1);
          }
          has(e) {
            return this.styleIDMap.has(e);
          }
          add(e, t) {
            let r;
            return this.has(e)
              ? this.getId(e)
              : ((r = void 0 === t ? this.id++ : t),
                this.styleIDMap.set(e, r),
                this.idStyleMap.set(r, e),
                r);
          }
          getStyle(e) {
            return this.idStyleMap.get(e) || null;
          }
          reset() {
            (this.styleIDMap = new WeakMap()),
              (this.idStyleMap = new Map()),
              (this.id = 1);
          }
          generateId() {
            return this.id++;
          }
        }
        function e1(e) {
          let t = null;
          return (
            eF([
              e,
              "access",
              (e) => e.getRootNode,
              "optionalCall",
              (e) => e(),
              "optionalAccess",
              (e) => e.nodeType,
            ]) === Node.DOCUMENT_FRAGMENT_NODE &&
              e.getRootNode().host &&
              (t = e.getRootNode().host),
            t
          );
        }
        let e3 = {};
        function e2(e) {
          let t = e3[e];
          if (t) return t;
          let r = window.document,
            n = window[e];
          if (r && "function" == typeof r.createElement)
            try {
              let t = r.createElement("iframe");
              (t.hidden = !0), r.head.appendChild(t);
              let i = t.contentWindow;
              i && i[e] && (n = i[e]), r.head.removeChild(t);
            } catch (e) {}
          return (e3[e] = n.bind(window));
        }
        function e5(...e) {
          return e2("setTimeout")(...e);
        }
        var e9 =
            (((u = e9 || {})[(u.DomContentLoaded = 0)] = "DomContentLoaded"),
            (u[(u.Load = 1)] = "Load"),
            (u[(u.FullSnapshot = 2)] = "FullSnapshot"),
            (u[(u.IncrementalSnapshot = 3)] = "IncrementalSnapshot"),
            (u[(u.Meta = 4)] = "Meta"),
            (u[(u.Custom = 5)] = "Custom"),
            (u[(u.Plugin = 6)] = "Plugin"),
            u),
          e4 =
            (((d = e4 || {})[(d.Mutation = 0)] = "Mutation"),
            (d[(d.MouseMove = 1)] = "MouseMove"),
            (d[(d.MouseInteraction = 2)] = "MouseInteraction"),
            (d[(d.Scroll = 3)] = "Scroll"),
            (d[(d.ViewportResize = 4)] = "ViewportResize"),
            (d[(d.Input = 5)] = "Input"),
            (d[(d.TouchMove = 6)] = "TouchMove"),
            (d[(d.MediaInteraction = 7)] = "MediaInteraction"),
            (d[(d.StyleSheetRule = 8)] = "StyleSheetRule"),
            (d[(d.CanvasMutation = 9)] = "CanvasMutation"),
            (d[(d.Font = 10)] = "Font"),
            (d[(d.Log = 11)] = "Log"),
            (d[(d.Drag = 12)] = "Drag"),
            (d[(d.StyleDeclaration = 13)] = "StyleDeclaration"),
            (d[(d.Selection = 14)] = "Selection"),
            (d[(d.AdoptedStyleSheet = 15)] = "AdoptedStyleSheet"),
            (d[(d.CustomElement = 16)] = "CustomElement"),
            d),
          e7 =
            (((h = e7 || {})[(h.MouseUp = 0)] = "MouseUp"),
            (h[(h.MouseDown = 1)] = "MouseDown"),
            (h[(h.Click = 2)] = "Click"),
            (h[(h.ContextMenu = 3)] = "ContextMenu"),
            (h[(h.DblClick = 4)] = "DblClick"),
            (h[(h.Focus = 5)] = "Focus"),
            (h[(h.Blur = 6)] = "Blur"),
            (h[(h.TouchStart = 7)] = "TouchStart"),
            (h[(h.TouchMove_Departed = 8)] = "TouchMove_Departed"),
            (h[(h.TouchEnd = 9)] = "TouchEnd"),
            (h[(h.TouchCancel = 10)] = "TouchCancel"),
            h),
          e8 =
            (((p = e8 || {})[(p.Mouse = 0)] = "Mouse"),
            (p[(p.Pen = 1)] = "Pen"),
            (p[(p.Touch = 2)] = "Touch"),
            p);
        ((m = _ || (_ = {}))[(m.Document = 0)] = "Document"),
          (m[(m.DocumentType = 1)] = "DocumentType"),
          (m[(m.Element = 2)] = "Element"),
          (m[(m.Text = 3)] = "Text"),
          (m[(m.CDATA = 4)] = "CDATA"),
          (m[(m.Comment = 5)] = "Comment"),
          ((f = S || (S = {}))[(f.PLACEHOLDER = 0)] = "PLACEHOLDER"),
          (f[(f.ELEMENT_NODE = 1)] = "ELEMENT_NODE"),
          (f[(f.ATTRIBUTE_NODE = 2)] = "ATTRIBUTE_NODE"),
          (f[(f.TEXT_NODE = 3)] = "TEXT_NODE"),
          (f[(f.CDATA_SECTION_NODE = 4)] = "CDATA_SECTION_NODE"),
          (f[(f.ENTITY_REFERENCE_NODE = 5)] = "ENTITY_REFERENCE_NODE"),
          (f[(f.ENTITY_NODE = 6)] = "ENTITY_NODE"),
          (f[(f.PROCESSING_INSTRUCTION_NODE = 7)] =
            "PROCESSING_INSTRUCTION_NODE"),
          (f[(f.COMMENT_NODE = 8)] = "COMMENT_NODE"),
          (f[(f.DOCUMENT_NODE = 9)] = "DOCUMENT_NODE"),
          (f[(f.DOCUMENT_TYPE_NODE = 10)] = "DOCUMENT_TYPE_NODE"),
          (f[(f.DOCUMENT_FRAGMENT_NODE = 11)] = "DOCUMENT_FRAGMENT_NODE");
        class e6 {
          constructor() {
            (this.length = 0), (this.head = null), (this.tail = null);
          }
          get(e) {
            if (e >= this.length) throw Error("Position outside of list range");
            let t = this.head;
            for (let r = 0; r < e; r++)
              t =
                (function (e) {
                  let t;
                  let r = e[0],
                    n = 1;
                  for (; n < e.length; ) {
                    let i = e[n],
                      s = e[n + 1];
                    if (
                      ((n += 2),
                      ("optionalAccess" === i || "optionalCall" === i) &&
                        null == r)
                    )
                      return;
                    "access" === i || "optionalAccess" === i
                      ? ((t = r), (r = s(r)))
                      : ("call" === i || "optionalCall" === i) &&
                        ((r = s((...e) => r.call(t, ...e))), (t = void 0));
                  }
                  return r;
                })([t, "optionalAccess", (e) => e.next]) || null;
            return t;
          }
          addNode(e) {
            let t = { value: e, previous: null, next: null };
            if (
              ((e.__ln = t), e.previousSibling && "__ln" in e.previousSibling)
            ) {
              let r = e.previousSibling.__ln.next;
              (t.next = r),
                (t.previous = e.previousSibling.__ln),
                (e.previousSibling.__ln.next = t),
                r && (r.previous = t);
            } else if (
              e.nextSibling &&
              "__ln" in e.nextSibling &&
              e.nextSibling.__ln.previous
            ) {
              let r = e.nextSibling.__ln.previous;
              (t.previous = r),
                (t.next = e.nextSibling.__ln),
                (e.nextSibling.__ln.previous = t),
                r && (r.next = t);
            } else
              this.head && (this.head.previous = t),
                (t.next = this.head),
                (this.head = t);
            null === t.next && (this.tail = t), this.length++;
          }
          removeNode(e) {
            let t = e.__ln;
            this.head &&
              (t.previous
                ? ((t.previous.next = t.next),
                  t.next
                    ? (t.next.previous = t.previous)
                    : (this.tail = t.previous))
                : ((this.head = t.next),
                  this.head ? (this.head.previous = null) : (this.tail = null)),
              e.__ln && delete e.__ln,
              this.length--);
          }
        }
        let te = (e, t) => `${e}@${t}`;
        class tt {
          constructor() {
            (this.frozen = !1),
              (this.locked = !1),
              (this.texts = []),
              (this.attributes = []),
              (this.attributeMap = new WeakMap()),
              (this.removes = []),
              (this.mapRemoves = []),
              (this.movedMap = {}),
              (this.addedSet = new Set()),
              (this.movedSet = new Set()),
              (this.droppedSet = new Set()),
              (this.processMutations = (e) => {
                e.forEach(this.processMutation), this.emit();
              }),
              (this.emit = () => {
                if (this.frozen || this.locked) return;
                let e = [],
                  t = new Set(),
                  r = new e6(),
                  n = (e) => {
                    let t = e,
                      r = -2;
                    for (; -2 === r; )
                      r = (t = t && t.nextSibling) && this.mirror.getId(t);
                    return r;
                  },
                  i = (i) => {
                    if (
                      !i.parentNode ||
                      !(function (e) {
                        let t = e.ownerDocument;
                        return (
                          !!t &&
                          (t.contains(e) ||
                            (function (e) {
                              let t = e.ownerDocument;
                              if (!t) return !1;
                              let r = (function (e) {
                                let t,
                                  r = e;
                                for (; (t = e1(r)); ) r = t;
                                return r;
                              })(e);
                              return t.contains(r);
                            })(e))
                        );
                      })(i)
                    )
                      return;
                    let s = Q(i.parentNode)
                        ? this.mirror.getId(e1(i))
                        : this.mirror.getId(i.parentNode),
                      o = n(i);
                    if (-1 === s || -1 === o) return r.addNode(i);
                    let a = eP(i, {
                      doc: this.doc,
                      mirror: this.mirror,
                      blockClass: this.blockClass,
                      blockSelector: this.blockSelector,
                      maskAllText: this.maskAllText,
                      unblockSelector: this.unblockSelector,
                      maskTextClass: this.maskTextClass,
                      unmaskTextClass: this.unmaskTextClass,
                      maskTextSelector: this.maskTextSelector,
                      unmaskTextSelector: this.unmaskTextSelector,
                      skipChild: !0,
                      newlyAddedElement: !0,
                      inlineStylesheet: this.inlineStylesheet,
                      maskInputOptions: this.maskInputOptions,
                      maskAttributeFn: this.maskAttributeFn,
                      maskTextFn: this.maskTextFn,
                      maskInputFn: this.maskInputFn,
                      slimDOMOptions: this.slimDOMOptions,
                      dataURLOptions: this.dataURLOptions,
                      recordCanvas: this.recordCanvas,
                      inlineImages: this.inlineImages,
                      onSerialize: (e) => {
                        eX(e, this.mirror) &&
                          !eY(
                            e,
                            this.blockClass,
                            this.blockSelector,
                            this.unblockSelector,
                            !1
                          ) &&
                          this.iframeManager.addIframe(e),
                          eZ(e, this.mirror) &&
                            this.stylesheetManager.trackLinkElement(e),
                          eQ(i) &&
                            this.shadowDomManager.addShadowRoot(
                              i.shadowRoot,
                              this.doc
                            );
                      },
                      onIframeLoad: (e, t) => {
                        eY(
                          e,
                          this.blockClass,
                          this.blockSelector,
                          this.unblockSelector,
                          !1
                        ) ||
                          (this.iframeManager.attachIframe(e, t),
                          e.contentWindow &&
                            this.canvasManager.addWindow(e.contentWindow),
                          this.shadowDomManager.observeAttachShadow(e));
                      },
                      onStylesheetLoad: (e, t) => {
                        this.stylesheetManager.attachLinkElement(e, t);
                      },
                    });
                    a &&
                      (e.push({ parentId: s, nextId: o, node: a }),
                      t.add(a.id));
                  };
                for (; this.mapRemoves.length; )
                  this.mirror.removeNodeFromMap(this.mapRemoves.shift());
                for (let e of this.movedSet)
                  (!tn(this.removes, e, this.mirror) ||
                    this.movedSet.has(e.parentNode)) &&
                    i(e);
                for (let e of this.addedSet)
                  ti(this.droppedSet, e) || tn(this.removes, e, this.mirror)
                    ? ti(this.movedSet, e)
                      ? i(e)
                      : this.droppedSet.add(e)
                    : i(e);
                let s = null;
                for (; r.length; ) {
                  let e = null;
                  if (s) {
                    let t = this.mirror.getId(s.value.parentNode),
                      r = n(s.value);
                    -1 !== t && -1 !== r && (e = s);
                  }
                  if (!e) {
                    let t = r.tail;
                    for (; t; ) {
                      let r = t;
                      if (((t = t.previous), r)) {
                        let t = this.mirror.getId(r.value.parentNode),
                          i = n(r.value);
                        if (-1 === i) continue;
                        if (-1 !== t) {
                          e = r;
                          break;
                        }
                        {
                          let t = r.value;
                          if (
                            t.parentNode &&
                            t.parentNode.nodeType ===
                              Node.DOCUMENT_FRAGMENT_NODE
                          ) {
                            let n = t.parentNode.host,
                              i = this.mirror.getId(n);
                            if (-1 !== i) {
                              e = r;
                              break;
                            }
                          }
                        }
                      }
                    }
                  }
                  if (!e) {
                    for (; r.head; ) r.removeNode(r.head.value);
                    break;
                  }
                  (s = e.previous), r.removeNode(e.value), i(e.value);
                }
                let o = {
                  texts: this.texts
                    .map((e) => ({
                      id: this.mirror.getId(e.node),
                      value: e.value,
                    }))
                    .filter((e) => !t.has(e.id))
                    .filter((e) => this.mirror.has(e.id)),
                  attributes: this.attributes
                    .map((e) => {
                      let { attributes: t } = e;
                      if ("string" == typeof t.style) {
                        let r = JSON.stringify(e.styleDiff),
                          n = JSON.stringify(e._unchangedStyles);
                        r.length < t.style.length &&
                          (r + n).split("var(").length ===
                            t.style.split("var(").length &&
                          (t.style = e.styleDiff);
                      }
                      return { id: this.mirror.getId(e.node), attributes: t };
                    })
                    .filter((e) => !t.has(e.id))
                    .filter((e) => this.mirror.has(e.id)),
                  removes: this.removes,
                  adds: e,
                };
                (o.texts.length ||
                  o.attributes.length ||
                  o.removes.length ||
                  o.adds.length) &&
                  ((this.texts = []),
                  (this.attributes = []),
                  (this.attributeMap = new WeakMap()),
                  (this.removes = []),
                  (this.addedSet = new Set()),
                  (this.movedSet = new Set()),
                  (this.droppedSet = new Set()),
                  (this.movedMap = {}),
                  this.mutationCb(o));
              }),
              (this.processMutation = (e) => {
                if (!eK(e.target, this.mirror))
                  switch (e.type) {
                    case "characterData": {
                      let t = e.target.textContent;
                      eY(
                        e.target,
                        this.blockClass,
                        this.blockSelector,
                        this.unblockSelector,
                        !1
                      ) ||
                        t === e.oldValue ||
                        this.texts.push({
                          value:
                            eO(
                              e.target,
                              this.maskTextClass,
                              this.maskTextSelector,
                              this.unmaskTextClass,
                              this.unmaskTextSelector,
                              this.maskAllText
                            ) && t
                              ? this.maskTextFn
                                ? this.maskTextFn(t, eG(e.target))
                                : t.replace(/[\S]/g, "*")
                              : t,
                          node: e.target,
                        });
                      break;
                    }
                    case "attributes": {
                      let t = e.target,
                        r = e.attributeName,
                        n = e.target.getAttribute(r);
                      if ("value" === r) {
                        let r = ec(t),
                          i = t.tagName;
                        n = eu(t, i, r);
                        let s = ei({
                            maskInputOptions: this.maskInputOptions,
                            tagName: i,
                            type: r,
                          }),
                          o = eO(
                            e.target,
                            this.maskTextClass,
                            this.maskTextSelector,
                            this.unmaskTextClass,
                            this.unmaskTextSelector,
                            s
                          );
                        n = es({
                          isMasked: o,
                          element: t,
                          value: n,
                          maskInputFn: this.maskInputFn,
                        });
                      }
                      if (
                        eY(
                          e.target,
                          this.blockClass,
                          this.blockSelector,
                          this.unblockSelector,
                          !1
                        ) ||
                        n === e.oldValue
                      )
                        return;
                      let i = this.attributeMap.get(e.target);
                      if (
                        "IFRAME" === t.tagName &&
                        "src" === r &&
                        !this.keepIframeSrcFn(n)
                      ) {
                        let e = (function (e) {
                          try {
                            return e.contentDocument;
                          } catch (e) {}
                        })(t);
                        if (e) return;
                        r = "rr_src";
                      }
                      if (
                        (i ||
                          ((i = {
                            node: e.target,
                            attributes: {},
                            styleDiff: {},
                            _unchangedStyles: {},
                          }),
                          this.attributes.push(i),
                          this.attributeMap.set(e.target, i)),
                        "type" === r &&
                          "INPUT" === t.tagName &&
                          "password" === (e.oldValue || "").toLowerCase() &&
                          t.setAttribute("data-rr-is-password", "true"),
                        !eD(t.tagName, r) &&
                          ((i.attributes[r] = eR(
                            this.doc,
                            eo(t.tagName),
                            eo(r),
                            n,
                            t,
                            this.maskAttributeFn
                          )),
                          "style" === r))
                      ) {
                        if (!this.unattachedDoc)
                          try {
                            this.unattachedDoc =
                              document.implementation.createHTMLDocument();
                          } catch (e) {
                            this.unattachedDoc = this.doc;
                          }
                        let r = this.unattachedDoc.createElement("span");
                        for (let n of (e.oldValue &&
                          r.setAttribute("style", e.oldValue),
                        Array.from(t.style))) {
                          let e = t.style.getPropertyValue(n),
                            s = t.style.getPropertyPriority(n);
                          e !== r.style.getPropertyValue(n) ||
                          s !== r.style.getPropertyPriority(n)
                            ? "" === s
                              ? (i.styleDiff[n] = e)
                              : (i.styleDiff[n] = [e, s])
                            : (i._unchangedStyles[n] = [e, s]);
                        }
                        for (let e of Array.from(r.style))
                          "" === t.style.getPropertyValue(e) &&
                            (i.styleDiff[e] = !1);
                      }
                      break;
                    }
                    case "childList":
                      if (
                        eY(
                          e.target,
                          this.blockClass,
                          this.blockSelector,
                          this.unblockSelector,
                          !0
                        )
                      )
                        return;
                      e.addedNodes.forEach((t) => this.genAdds(t, e.target)),
                        e.removedNodes.forEach((t) => {
                          let r = this.mirror.getId(t),
                            n = Q(e.target)
                              ? this.mirror.getId(e.target.host)
                              : this.mirror.getId(e.target);
                          eY(
                            e.target,
                            this.blockClass,
                            this.blockSelector,
                            this.unblockSelector,
                            !1
                          ) ||
                            eK(t, this.mirror) ||
                            -1 === this.mirror.getId(t) ||
                            (this.addedSet.has(t)
                              ? (tr(this.addedSet, t), this.droppedSet.add(t))
                              : (this.addedSet.has(e.target) && -1 === r) ||
                                (function e(t, r) {
                                  if (Q(t)) return !1;
                                  let n = r.getId(t);
                                  return (
                                    !r.has(n) ||
                                    ((!t.parentNode ||
                                      t.parentNode.nodeType !==
                                        t.DOCUMENT_NODE) &&
                                      (!t.parentNode || e(t.parentNode, r)))
                                  );
                                })(e.target, this.mirror) ||
                                (this.movedSet.has(t) && this.movedMap[te(r, n)]
                                  ? tr(this.movedSet, t)
                                  : this.removes.push({
                                      parentId: n,
                                      id: r,
                                      isShadow:
                                        !!(Q(e.target) && ee(e.target)) ||
                                        void 0,
                                    })),
                            this.mapRemoves.push(t));
                        });
                  }
              }),
              (this.genAdds = (e, t) => {
                if (
                  !this.processedNodeManager.inOtherBuffer(e, this) &&
                  !(this.addedSet.has(e) || this.movedSet.has(e))
                ) {
                  if (this.mirror.hasNode(e)) {
                    if (eK(e, this.mirror)) return;
                    this.movedSet.add(e);
                    let r = null;
                    t && this.mirror.hasNode(t) && (r = this.mirror.getId(t)),
                      r &&
                        -1 !== r &&
                        (this.movedMap[te(this.mirror.getId(e), r)] = !0);
                  } else this.addedSet.add(e), this.droppedSet.delete(e);
                  !eY(
                    e,
                    this.blockClass,
                    this.blockSelector,
                    this.unblockSelector,
                    !1
                  ) &&
                    (e.childNodes.forEach((e) => this.genAdds(e)),
                    eQ(e) &&
                      e.shadowRoot.childNodes.forEach((t) => {
                        this.processedNodeManager.add(t, this),
                          this.genAdds(t, e);
                      }));
                }
              });
          }
          init(e) {
            [
              "mutationCb",
              "blockClass",
              "blockSelector",
              "unblockSelector",
              "maskAllText",
              "maskTextClass",
              "unmaskTextClass",
              "maskTextSelector",
              "unmaskTextSelector",
              "inlineStylesheet",
              "maskInputOptions",
              "maskAttributeFn",
              "maskTextFn",
              "maskInputFn",
              "keepIframeSrcFn",
              "recordCanvas",
              "inlineImages",
              "slimDOMOptions",
              "dataURLOptions",
              "doc",
              "mirror",
              "iframeManager",
              "stylesheetManager",
              "shadowDomManager",
              "canvasManager",
              "processedNodeManager",
            ].forEach((t) => {
              this[t] = e[t];
            });
          }
          freeze() {
            (this.frozen = !0), this.canvasManager.freeze();
          }
          unfreeze() {
            (this.frozen = !1), this.canvasManager.unfreeze(), this.emit();
          }
          isFrozen() {
            return this.frozen;
          }
          lock() {
            (this.locked = !0), this.canvasManager.lock();
          }
          unlock() {
            (this.locked = !1), this.canvasManager.unlock(), this.emit();
          }
          reset() {
            this.shadowDomManager.reset(), this.canvasManager.reset();
          }
        }
        function tr(e, t) {
          e.delete(t), t.childNodes.forEach((t) => tr(e, t));
        }
        function tn(e, t, r) {
          return (
            0 !== e.length &&
            (function (e, t, r) {
              let n = t.parentNode;
              for (; n; ) {
                let t = r.getId(n);
                if (e.some((e) => e.id === t)) return !0;
                n = n.parentNode;
              }
              return !1;
            })(e, t, r)
          );
        }
        function ti(e, t) {
          return (
            0 !== e.size &&
            (function e(t, r) {
              let { parentNode: n } = r;
              return !!n && (!!t.has(n) || e(t, n));
            })(e, t)
          );
        }
        let ts = (e) => {
          if (!s) return e;
          let t = (...t) => {
            try {
              return e(...t);
            } catch (e) {
              if (s && !0 === s(e)) return () => {};
              throw e;
            }
          };
          return t;
        };
        function to(e) {
          let t;
          let r = e[0],
            n = 1;
          for (; n < e.length; ) {
            let i = e[n],
              s = e[n + 1];
            if (
              ((n += 2),
              ("optionalAccess" === i || "optionalCall" === i) && null == r)
            )
              return;
            "access" === i || "optionalAccess" === i
              ? ((t = r), (r = s(r)))
              : ("call" === i || "optionalCall" === i) &&
                ((r = s((...e) => r.call(t, ...e))), (t = void 0));
          }
          return r;
        }
        let ta = [];
        function tl(e) {
          try {
            if ("composedPath" in e) {
              let t = e.composedPath();
              if (t.length) return t[0];
            } else if ("path" in e && e.path.length) return e.path[0];
          } catch (e) {}
          return e && e.target;
        }
        let tc = ["INPUT", "TEXTAREA", "SELECT"],
          tu = new WeakMap();
        function td(e) {
          return (function (e, t) {
            if (
              (tm("CSSGroupingRule") &&
                e.parentRule instanceof CSSGroupingRule) ||
              (tm("CSSMediaRule") && e.parentRule instanceof CSSMediaRule) ||
              (tm("CSSSupportsRule") &&
                e.parentRule instanceof CSSSupportsRule) ||
              (tm("CSSConditionRule") &&
                e.parentRule instanceof CSSConditionRule)
            ) {
              let r = Array.from(e.parentRule.cssRules),
                n = r.indexOf(e);
              t.unshift(n);
            } else if (e.parentStyleSheet) {
              let r = Array.from(e.parentStyleSheet.cssRules),
                n = r.indexOf(e);
              t.unshift(n);
            }
            return t;
          })(e, []);
        }
        function th(e, t, r) {
          let n, i;
          return e
            ? (e.ownerNode ? (n = t.getId(e.ownerNode)) : (i = r.getId(e)),
              { styleId: i, id: n })
            : {};
        }
        function tp(e, t = {}) {
          let r;
          let n = e.doc.defaultView;
          if (!n) return () => {};
          e.recordDOM &&
            (r = (function (e, t) {
              let r = new tt();
              ta.push(r), r.init(e);
              let n = window.MutationObserver || window.__rrMutationObserver,
                i = to([
                  window,
                  "optionalAccess",
                  (e) => e.Zone,
                  "optionalAccess",
                  (e) => e.__symbol__,
                  "optionalCall",
                  (e) => e("MutationObserver"),
                ]);
              i && window[i] && (n = window[i]);
              let s = new n(
                ts((t) => {
                  (e.onMutation && !1 === e.onMutation(t)) ||
                    r.processMutations.bind(r)(t);
                })
              );
              return (
                s.observe(t, {
                  attributes: !0,
                  attributeOldValue: !0,
                  characterData: !0,
                  characterDataOldValue: !0,
                  childList: !0,
                  subtree: !0,
                }),
                s
              );
            })(e, e.doc));
          let i = (function ({
              mousemoveCb: e,
              sampling: t,
              doc: r,
              mirror: n,
            }) {
              let i;
              if (!1 === t.mousemove) return () => {};
              let s = "number" == typeof t.mousemove ? t.mousemove : 50,
                o =
                  "number" == typeof t.mousemoveCallback
                    ? t.mousemoveCallback
                    : 500,
                a = [],
                l = eW(
                  ts((t) => {
                    let r = Date.now() - i;
                    e(
                      a.map((e) => ((e.timeOffset -= r), e)),
                      t
                    ),
                      (a = []),
                      (i = null);
                  }),
                  o
                ),
                c = ts(
                  eW(
                    ts((e) => {
                      let t = tl(e),
                        { clientX: r, clientY: s } = eJ(e)
                          ? e.changedTouches[0]
                          : e;
                      i || (i = e$()),
                        a.push({
                          x: r,
                          y: s,
                          id: n.getId(t),
                          timeOffset: e$() - i,
                        }),
                        l(
                          "undefined" != typeof DragEvent &&
                            e instanceof DragEvent
                            ? e4.Drag
                            : e instanceof MouseEvent
                            ? e4.MouseMove
                            : e4.TouchMove
                        );
                    }),
                    s,
                    { trailing: !1 }
                  )
                ),
                u = [
                  eU("mousemove", c, r),
                  eU("touchmove", c, r),
                  eU("drag", c, r),
                ];
              return ts(() => {
                u.forEach((e) => e());
              });
            })(e),
            s = (function ({
              mouseInteractionCb: e,
              doc: t,
              mirror: r,
              blockClass: n,
              blockSelector: i,
              unblockSelector: s,
              sampling: o,
            }) {
              if (!1 === o.mouseInteraction) return () => {};
              let a =
                  !0 === o.mouseInteraction || void 0 === o.mouseInteraction
                    ? {}
                    : o.mouseInteraction,
                l = [],
                c = null,
                u = (t) => (o) => {
                  let a = tl(o);
                  if (eY(a, n, i, s, !0)) return;
                  let l = null,
                    u = t;
                  if ("pointerType" in o) {
                    switch (o.pointerType) {
                      case "mouse":
                        l = e8.Mouse;
                        break;
                      case "touch":
                        l = e8.Touch;
                        break;
                      case "pen":
                        l = e8.Pen;
                    }
                    l === e8.Touch
                      ? e7[t] === e7.MouseDown
                        ? (u = "TouchStart")
                        : e7[t] === e7.MouseUp && (u = "TouchEnd")
                      : e8.Pen;
                  } else eJ(o) && (l = e8.Touch);
                  null !== l
                    ? ((c = l),
                      ((u.startsWith("Touch") && l === e8.Touch) ||
                        (u.startsWith("Mouse") && l === e8.Mouse)) &&
                        (l = null))
                    : e7[t] === e7.Click && ((l = c), (c = null));
                  let d = eJ(o) ? o.changedTouches[0] : o;
                  if (!d) return;
                  let h = r.getId(a),
                    { clientX: p, clientY: m } = d;
                  ts(e)({
                    type: e7[u],
                    id: h,
                    x: p,
                    y: m,
                    ...(null !== l && { pointerType: l }),
                  });
                };
              return (
                Object.keys(e7)
                  .filter(
                    (e) =>
                      Number.isNaN(Number(e)) &&
                      !e.endsWith("_Departed") &&
                      !1 !== a[e]
                  )
                  .forEach((e) => {
                    let r = eo(e),
                      n = u(e);
                    if (window.PointerEvent)
                      switch (e7[e]) {
                        case e7.MouseDown:
                        case e7.MouseUp:
                          r = r.replace("mouse", "pointer");
                          break;
                        case e7.TouchStart:
                        case e7.TouchEnd:
                          return;
                      }
                    l.push(eU(r, n, t));
                  }),
                ts(() => {
                  l.forEach((e) => e());
                })
              );
            })(e),
            o = (function ({
              scrollCb: e,
              doc: t,
              mirror: r,
              blockClass: n,
              blockSelector: i,
              unblockSelector: s,
              sampling: o,
            }) {
              let a = ts(
                eW(
                  ts((o) => {
                    let a = tl(o);
                    if (!a || eY(a, n, i, s, !0)) return;
                    let l = r.getId(a);
                    if (a === t && t.defaultView) {
                      let r = ej(t.defaultView);
                      e({ id: l, x: r.left, y: r.top });
                    } else e({ id: l, x: a.scrollLeft, y: a.scrollTop });
                  }),
                  o.scroll || 100
                )
              );
              return eU("scroll", a, t);
            })(e),
            a = (function ({ viewportResizeCb: e }, { win: t }) {
              let r = -1,
                n = -1,
                i = ts(
                  eW(
                    ts(() => {
                      let t = eV(),
                        i = eq();
                      (r !== t || n !== i) &&
                        (e({ width: Number(i), height: Number(t) }),
                        (r = t),
                        (n = i));
                    }),
                    200
                  )
                );
              return eU("resize", i, t);
            })(e, { win: n }),
            l = (function ({
              inputCb: e,
              doc: t,
              mirror: r,
              blockClass: n,
              blockSelector: i,
              unblockSelector: s,
              ignoreClass: o,
              ignoreSelector: a,
              maskInputOptions: l,
              maskInputFn: c,
              sampling: u,
              userTriggeredOnInput: d,
              maskTextClass: h,
              unmaskTextClass: p,
              maskTextSelector: m,
              unmaskTextSelector: f,
            }) {
              function y(e) {
                let r = tl(e),
                  u = e.isTrusted,
                  y = r && ea(r.tagName);
                if (
                  ("OPTION" === y && (r = r.parentElement),
                  !r || !y || 0 > tc.indexOf(y) || eY(r, n, i, s, !0))
                )
                  return;
                let _ = r;
                if (_.classList.contains(o) || (a && _.matches(a))) return;
                let S = ec(r),
                  b = eu(_, y, S),
                  v = !1,
                  w = ei({ maskInputOptions: l, tagName: y, type: S }),
                  E = eO(r, h, m, p, f, w);
                ("radio" === S || "checkbox" === S) && (v = r.checked),
                  (b = es({
                    isMasked: E,
                    element: r,
                    value: b,
                    maskInputFn: c,
                  })),
                  g(
                    r,
                    d
                      ? { text: b, isChecked: v, userTriggered: u }
                      : { text: b, isChecked: v }
                  );
                let k = r.name;
                "radio" === S &&
                  k &&
                  v &&
                  t
                    .querySelectorAll(`input[type="radio"][name="${k}"]`)
                    .forEach((e) => {
                      if (e !== r) {
                        let t = es({
                          isMasked: E,
                          element: e,
                          value: eu(e, y, S),
                          maskInputFn: c,
                        });
                        g(
                          e,
                          d
                            ? { text: t, isChecked: !v, userTriggered: !1 }
                            : { text: t, isChecked: !v }
                        );
                      }
                    });
              }
              function g(t, n) {
                let i = tu.get(t);
                if (!i || i.text !== n.text || i.isChecked !== n.isChecked) {
                  tu.set(t, n);
                  let i = r.getId(t);
                  ts(e)({ ...n, id: i });
                }
              }
              let _ = "last" === u.input ? ["change"] : ["input", "change"],
                S = _.map((e) => eU(e, ts(y), t)),
                b = t.defaultView;
              if (!b)
                return () => {
                  S.forEach((e) => e());
                };
              let v = b.Object.getOwnPropertyDescriptor(
                  b.HTMLInputElement.prototype,
                  "value"
                ),
                w = [
                  [b.HTMLInputElement.prototype, "value"],
                  [b.HTMLInputElement.prototype, "checked"],
                  [b.HTMLSelectElement.prototype, "value"],
                  [b.HTMLTextAreaElement.prototype, "value"],
                  [b.HTMLSelectElement.prototype, "selectedIndex"],
                  [b.HTMLOptionElement.prototype, "selected"],
                ];
              return (
                v &&
                  v.set &&
                  S.push(
                    ...w.map((e) =>
                      (function e(t, r, n, i, s = window) {
                        let o = s.Object.getOwnPropertyDescriptor(t, r);
                        return (
                          s.Object.defineProperty(
                            t,
                            r,
                            i
                              ? n
                              : {
                                  set(e) {
                                    e5(() => {
                                      n.set.call(this, e);
                                    }, 0),
                                      o && o.set && o.set.call(this, e);
                                  },
                                }
                          ),
                          () => e(t, r, o || {}, !0)
                        );
                      })(
                        e[0],
                        e[1],
                        {
                          set() {
                            ts(y)({ target: this, isTrusted: !1 });
                          },
                        },
                        !1,
                        b
                      )
                    )
                  ),
                ts(() => {
                  S.forEach((e) => e());
                })
              );
            })(e),
            c = (function ({
              mediaInteractionCb: e,
              blockClass: t,
              blockSelector: r,
              unblockSelector: n,
              mirror: i,
              sampling: s,
              doc: o,
            }) {
              let a = ts((o) =>
                  eW(
                    ts((s) => {
                      let a = tl(s);
                      if (!a || eY(a, t, r, n, !0)) return;
                      let {
                        currentTime: l,
                        volume: c,
                        muted: u,
                        playbackRate: d,
                      } = a;
                      e({
                        type: o,
                        id: i.getId(a),
                        currentTime: l,
                        volume: c,
                        muted: u,
                        playbackRate: d,
                      });
                    }),
                    s.media || 500
                  )
                ),
                l = [
                  eU("play", a(0), o),
                  eU("pause", a(1), o),
                  eU("seeked", a(2), o),
                  eU("volumechange", a(3), o),
                  eU("ratechange", a(4), o),
                ];
              return ts(() => {
                l.forEach((e) => e());
              });
            })(e),
            u = () => {},
            d = () => {},
            h = () => {},
            p = () => {};
          e.recordDOM &&
            ((u = (function (
              { styleSheetRuleCb: e, mirror: t, stylesheetManager: r },
              { win: n }
            ) {
              let i, s;
              if (!n.CSSStyleSheet || !n.CSSStyleSheet.prototype)
                return () => {};
              let o = n.CSSStyleSheet.prototype.insertRule;
              n.CSSStyleSheet.prototype.insertRule = new Proxy(o, {
                apply: ts((n, i, s) => {
                  let [o, a] = s,
                    { id: l, styleId: c } = th(i, t, r.styleMirror);
                  return (
                    ((l && -1 !== l) || (c && -1 !== c)) &&
                      e({ id: l, styleId: c, adds: [{ rule: o, index: a }] }),
                    n.apply(i, s)
                  );
                }),
              });
              let a = n.CSSStyleSheet.prototype.deleteRule;
              (n.CSSStyleSheet.prototype.deleteRule = new Proxy(a, {
                apply: ts((n, i, s) => {
                  let [o] = s,
                    { id: a, styleId: l } = th(i, t, r.styleMirror);
                  return (
                    ((a && -1 !== a) || (l && -1 !== l)) &&
                      e({ id: a, styleId: l, removes: [{ index: o }] }),
                    n.apply(i, s)
                  );
                }),
              })),
                n.CSSStyleSheet.prototype.replace &&
                  ((i = n.CSSStyleSheet.prototype.replace),
                  (n.CSSStyleSheet.prototype.replace = new Proxy(i, {
                    apply: ts((n, i, s) => {
                      let [o] = s,
                        { id: a, styleId: l } = th(i, t, r.styleMirror);
                      return (
                        ((a && -1 !== a) || (l && -1 !== l)) &&
                          e({ id: a, styleId: l, replace: o }),
                        n.apply(i, s)
                      );
                    }),
                  }))),
                n.CSSStyleSheet.prototype.replaceSync &&
                  ((s = n.CSSStyleSheet.prototype.replaceSync),
                  (n.CSSStyleSheet.prototype.replaceSync = new Proxy(s, {
                    apply: ts((n, i, s) => {
                      let [o] = s,
                        { id: a, styleId: l } = th(i, t, r.styleMirror);
                      return (
                        ((a && -1 !== a) || (l && -1 !== l)) &&
                          e({ id: a, styleId: l, replaceSync: o }),
                        n.apply(i, s)
                      );
                    }),
                  })));
              let l = {};
              tf("CSSGroupingRule")
                ? (l.CSSGroupingRule = n.CSSGroupingRule)
                : (tf("CSSMediaRule") && (l.CSSMediaRule = n.CSSMediaRule),
                  tf("CSSConditionRule") &&
                    (l.CSSConditionRule = n.CSSConditionRule),
                  tf("CSSSupportsRule") &&
                    (l.CSSSupportsRule = n.CSSSupportsRule));
              let c = {};
              return (
                Object.entries(l).forEach(([n, i]) => {
                  (c[n] = {
                    insertRule: i.prototype.insertRule,
                    deleteRule: i.prototype.deleteRule,
                  }),
                    (i.prototype.insertRule = new Proxy(c[n].insertRule, {
                      apply: ts((n, i, s) => {
                        let [o, a] = s,
                          { id: l, styleId: c } = th(
                            i.parentStyleSheet,
                            t,
                            r.styleMirror
                          );
                        return (
                          ((l && -1 !== l) || (c && -1 !== c)) &&
                            e({
                              id: l,
                              styleId: c,
                              adds: [{ rule: o, index: [...td(i), a || 0] }],
                            }),
                          n.apply(i, s)
                        );
                      }),
                    })),
                    (i.prototype.deleteRule = new Proxy(c[n].deleteRule, {
                      apply: ts((n, i, s) => {
                        let [o] = s,
                          { id: a, styleId: l } = th(
                            i.parentStyleSheet,
                            t,
                            r.styleMirror
                          );
                        return (
                          ((a && -1 !== a) || (l && -1 !== l)) &&
                            e({
                              id: a,
                              styleId: l,
                              removes: [{ index: [...td(i), o] }],
                            }),
                          n.apply(i, s)
                        );
                      }),
                    }));
                }),
                ts(() => {
                  (n.CSSStyleSheet.prototype.insertRule = o),
                    (n.CSSStyleSheet.prototype.deleteRule = a),
                    i && (n.CSSStyleSheet.prototype.replace = i),
                    s && (n.CSSStyleSheet.prototype.replaceSync = s),
                    Object.entries(l).forEach(([e, t]) => {
                      (t.prototype.insertRule = c[e].insertRule),
                        (t.prototype.deleteRule = c[e].deleteRule);
                    });
                })
              );
            })(e, { win: n })),
            (d = (function ({ mirror: e, stylesheetManager: t }, r) {
              let n = null;
              n = "#document" === r.nodeName ? e.getId(r) : e.getId(r.host);
              let i =
                  "#document" === r.nodeName
                    ? to([
                        r,
                        "access",
                        (e) => e.defaultView,
                        "optionalAccess",
                        (e) => e.Document,
                      ])
                    : to([
                        r,
                        "access",
                        (e) => e.ownerDocument,
                        "optionalAccess",
                        (e) => e.defaultView,
                        "optionalAccess",
                        (e) => e.ShadowRoot,
                      ]),
                s = to([i, "optionalAccess", (e) => e.prototype])
                  ? Object.getOwnPropertyDescriptor(
                      to([i, "optionalAccess", (e) => e.prototype]),
                      "adoptedStyleSheets"
                    )
                  : void 0;
              return null !== n && -1 !== n && i && s
                ? (Object.defineProperty(r, "adoptedStyleSheets", {
                    configurable: s.configurable,
                    enumerable: s.enumerable,
                    get() {
                      return to([
                        s,
                        "access",
                        (e) => e.get,
                        "optionalAccess",
                        (e) => e.call,
                        "call",
                        (e) => e(this),
                      ]);
                    },
                    set(e) {
                      let r = to([
                        s,
                        "access",
                        (e) => e.set,
                        "optionalAccess",
                        (e) => e.call,
                        "call",
                        (t) => t(this, e),
                      ]);
                      if (null !== n && -1 !== n)
                        try {
                          t.adoptStyleSheets(e, n);
                        } catch (e) {}
                      return r;
                    },
                  }),
                  ts(() => {
                    Object.defineProperty(r, "adoptedStyleSheets", {
                      configurable: s.configurable,
                      enumerable: s.enumerable,
                      get: s.get,
                      set: s.set,
                    });
                  }))
                : () => {};
            })(e, e.doc)),
            (h = (function (
              {
                styleDeclarationCb: e,
                mirror: t,
                ignoreCSSAttributes: r,
                stylesheetManager: n,
              },
              { win: i }
            ) {
              let s = i.CSSStyleDeclaration.prototype.setProperty;
              i.CSSStyleDeclaration.prototype.setProperty = new Proxy(s, {
                apply: ts((i, o, a) => {
                  let [l, c, u] = a;
                  if (r.has(l)) return s.apply(o, [l, c, u]);
                  let { id: d, styleId: h } = th(
                    to([
                      o,
                      "access",
                      (e) => e.parentRule,
                      "optionalAccess",
                      (e) => e.parentStyleSheet,
                    ]),
                    t,
                    n.styleMirror
                  );
                  return (
                    ((d && -1 !== d) || (h && -1 !== h)) &&
                      e({
                        id: d,
                        styleId: h,
                        set: { property: l, value: c, priority: u },
                        index: td(o.parentRule),
                      }),
                    i.apply(o, a)
                  );
                }),
              });
              let o = i.CSSStyleDeclaration.prototype.removeProperty;
              return (
                (i.CSSStyleDeclaration.prototype.removeProperty = new Proxy(o, {
                  apply: ts((i, s, a) => {
                    let [l] = a;
                    if (r.has(l)) return o.apply(s, [l]);
                    let { id: c, styleId: u } = th(
                      to([
                        s,
                        "access",
                        (e) => e.parentRule,
                        "optionalAccess",
                        (e) => e.parentStyleSheet,
                      ]),
                      t,
                      n.styleMirror
                    );
                    return (
                      ((c && -1 !== c) || (u && -1 !== u)) &&
                        e({
                          id: c,
                          styleId: u,
                          remove: { property: l },
                          index: td(s.parentRule),
                        }),
                      i.apply(s, a)
                    );
                  }),
                })),
                ts(() => {
                  (i.CSSStyleDeclaration.prototype.setProperty = s),
                    (i.CSSStyleDeclaration.prototype.removeProperty = o);
                })
              );
            })(e, { win: n })),
            e.collectFonts &&
              (p = (function ({ fontCb: e, doc: t }) {
                let r = t.defaultView;
                if (!r) return () => {};
                let n = [],
                  i = new WeakMap(),
                  s = r.FontFace;
                r.FontFace = function (e, t, r) {
                  let n = new s(e, t, r);
                  return (
                    i.set(n, {
                      family: e,
                      buffer: "string" != typeof t,
                      descriptors: r,
                      fontSource:
                        "string" == typeof t
                          ? t
                          : JSON.stringify(Array.from(new Uint8Array(t))),
                    }),
                    n
                  );
                };
                let o = eH(t.fonts, "add", function (t) {
                  return function (r) {
                    return (
                      e5(
                        ts(() => {
                          let t = i.get(r);
                          t && (e(t), i.delete(r));
                        }),
                        0
                      ),
                      t.apply(this, [r])
                    );
                  };
                });
                return (
                  n.push(() => {
                    r.FontFace = s;
                  }),
                  n.push(o),
                  ts(() => {
                    n.forEach((e) => e());
                  })
                );
              })(e)));
          let m = (function (e) {
              let {
                  doc: t,
                  mirror: r,
                  blockClass: n,
                  blockSelector: i,
                  unblockSelector: s,
                  selectionCb: o,
                } = e,
                a = !0,
                l = ts(() => {
                  let e = t.getSelection();
                  if (
                    !e ||
                    (a && to([e, "optionalAccess", (e) => e.isCollapsed]))
                  )
                    return;
                  a = e.isCollapsed || !1;
                  let l = [],
                    c = e.rangeCount || 0;
                  for (let t = 0; t < c; t++) {
                    let o = e.getRangeAt(t),
                      {
                        startContainer: a,
                        startOffset: c,
                        endContainer: u,
                        endOffset: d,
                      } = o,
                      h = eY(a, n, i, s, !0) || eY(u, n, i, s, !0);
                    h ||
                      l.push({
                        start: r.getId(a),
                        startOffset: c,
                        end: r.getId(u),
                        endOffset: d,
                      });
                  }
                  o({ ranges: l });
                });
              return l(), eU("selectionchange", l);
            })(e),
            f = (function ({ doc: e, customElementCb: t }) {
              let r = e.defaultView;
              if (!r || !r.customElements) return () => {};
              let n = eH(r.customElements, "define", function (e) {
                return function (r, n, i) {
                  try {
                    t({ define: { name: r } });
                  } catch (e) {}
                  return e.apply(this, [r, n, i]);
                };
              });
              return n;
            })(e),
            y = [];
          for (let t of e.plugins) y.push(t.observer(t.callback, n, t.options));
          return ts(() => {
            ta.forEach((e) => e.reset()),
              to([
                r,
                "optionalAccess",
                (e) => e.disconnect,
                "call",
                (e) => e(),
              ]),
              i(),
              s(),
              o(),
              a(),
              l(),
              c(),
              u(),
              d(),
              h(),
              p(),
              m(),
              f(),
              y.forEach((e) => e());
          });
        }
        function tm(e) {
          return void 0 !== window[e];
        }
        function tf(e) {
          return Boolean(
            void 0 !== window[e] &&
              window[e].prototype &&
              "insertRule" in window[e].prototype &&
              "deleteRule" in window[e].prototype
          );
        }
        class ty {
          constructor(e) {
            (this.generateIdFn = e),
              (this.iframeIdToRemoteIdMap = new WeakMap()),
              (this.iframeRemoteIdToIdMap = new WeakMap());
          }
          getId(e, t, r, n) {
            let i = r || this.getIdToRemoteIdMap(e),
              s = n || this.getRemoteIdToIdMap(e),
              o = i.get(t);
            return (
              o || ((o = this.generateIdFn()), i.set(t, o), s.set(o, t)), o
            );
          }
          getIds(e, t) {
            let r = this.getIdToRemoteIdMap(e),
              n = this.getRemoteIdToIdMap(e);
            return t.map((t) => this.getId(e, t, r, n));
          }
          getRemoteId(e, t, r) {
            let n = r || this.getRemoteIdToIdMap(e);
            if ("number" != typeof t) return t;
            let i = n.get(t);
            return i || -1;
          }
          getRemoteIds(e, t) {
            let r = this.getRemoteIdToIdMap(e);
            return t.map((t) => this.getRemoteId(e, t, r));
          }
          reset(e) {
            if (!e) {
              (this.iframeIdToRemoteIdMap = new WeakMap()),
                (this.iframeRemoteIdToIdMap = new WeakMap());
              return;
            }
            this.iframeIdToRemoteIdMap.delete(e),
              this.iframeRemoteIdToIdMap.delete(e);
          }
          getIdToRemoteIdMap(e) {
            let t = this.iframeIdToRemoteIdMap.get(e);
            return (
              t || ((t = new Map()), this.iframeIdToRemoteIdMap.set(e, t)), t
            );
          }
          getRemoteIdToIdMap(e) {
            let t = this.iframeRemoteIdToIdMap.get(e);
            return (
              t || ((t = new Map()), this.iframeRemoteIdToIdMap.set(e, t)), t
            );
          }
        }
        class tg {
          constructor() {
            (this.crossOriginIframeMirror = new ty(eS)),
              (this.crossOriginIframeRootIdMap = new WeakMap());
          }
          addIframe() {}
          addLoadListener() {}
          attachIframe() {}
        }
        class t_ {
          init() {}
          addShadowRoot() {}
          observeAttachShadow() {}
          reset() {}
        }
        class tS {
          reset() {}
          freeze() {}
          unfreeze() {}
          lock() {}
          unlock() {}
          snapshot() {}
          addWindow() {}
          addShadowRoot() {}
          resetShadowRoots() {}
        }
        class tb {
          constructor(e) {
            (this.trackedLinkElements = new WeakSet()),
              (this.styleMirror = new e0()),
              (this.mutationCb = e.mutationCb),
              (this.adoptedStyleSheetCb = e.adoptedStyleSheetCb);
          }
          attachLinkElement(e, t) {
            "_cssText" in t.attributes &&
              this.mutationCb({
                adds: [],
                removes: [],
                texts: [],
                attributes: [{ id: t.id, attributes: t.attributes }],
              }),
              this.trackLinkElement(e);
          }
          trackLinkElement(e) {
            this.trackedLinkElements.has(e) ||
              (this.trackedLinkElements.add(e),
              this.trackStylesheetInLinkElement(e));
          }
          adoptStyleSheets(e, t) {
            if (0 === e.length) return;
            let r = { id: t, styleIds: [] },
              n = [];
            for (let t of e) {
              let e;
              this.styleMirror.has(t)
                ? (e = this.styleMirror.getId(t))
                : ((e = this.styleMirror.add(t)),
                  n.push({
                    styleId: e,
                    rules: Array.from(t.rules || CSSRule, (e, t) => ({
                      rule: er(e),
                      index: t,
                    })),
                  })),
                r.styleIds.push(e);
            }
            n.length > 0 && (r.styles = n), this.adoptedStyleSheetCb(r);
          }
          reset() {
            this.styleMirror.reset(),
              (this.trackedLinkElements = new WeakSet());
          }
          trackStylesheetInLinkElement(e) {}
        }
        class tv {
          constructor() {
            (this.nodeMap = new WeakMap()), (this.active = !1);
          }
          inOtherBuffer(e, t) {
            let r = this.nodeMap.get(e);
            return r && Array.from(r).some((e) => e !== t);
          }
          add(e, t) {
            this.active ||
              ((this.active = !0),
              (function (...e) {
                e2("requestAnimationFrame")(...e);
              })(() => {
                (this.nodeMap = new WeakMap()), (this.active = !1);
              })),
              this.nodeMap.set(e, (this.nodeMap.get(e) || new Set()).add(t));
          }
          destroy() {}
        }
        try {
          if (2 !== Array.from([1], (e) => 2 * e)[0]) {
            let e = document.createElement("iframe");
            document.body.appendChild(e),
              (Array.from =
                (0, w.x)([
                  e,
                  "access",
                  (e) => e.contentWindow,
                  "optionalAccess",
                  (e) => e.Array,
                  "access",
                  (e) => e.from,
                ]) || Array.from),
              document.body.removeChild(e);
          }
        } catch (e) {
          console.debug("Unable to override Array.from", e);
        }
        let tw = new en();
        function tE(e = {}) {
          let t;
          let {
            emit: r,
            checkoutEveryNms: n,
            checkoutEveryNth: i,
            blockClass: l = "rr-block",
            blockSelector: c = null,
            unblockSelector: u = null,
            ignoreClass: d = "rr-ignore",
            ignoreSelector: h = null,
            maskAllText: p = !1,
            maskTextClass: m = "rr-mask",
            unmaskTextClass: f = null,
            maskTextSelector: y = null,
            unmaskTextSelector: g = null,
            inlineStylesheet: _ = !0,
            maskAllInputs: S,
            maskInputOptions: b,
            slimDOMOptions: v,
            maskAttributeFn: E,
            maskInputFn: k,
            maskTextFn: M,
            maxCanvasSize: C = null,
            packFn: T,
            sampling: I = {},
            dataURLOptions: x = {},
            mousemoveWait: R,
            recordDOM: D = !0,
            recordCanvas: A = !1,
            recordCrossOriginIframes: N = !1,
            recordAfter: O = "DOMContentLoaded" === e.recordAfter
              ? e.recordAfter
              : "load",
            userTriggeredOnInput: L = !1,
            collectFonts: P = !1,
            inlineImages: F = !1,
            plugins: U,
            keepIframeSrcFn: B = () => !1,
            ignoreCSSAttributes: z = new Set([]),
            errorHandler: W,
            onMutation: H,
            getCanvasManager: $,
          } = e;
          s = W;
          let j = !N || window.parent === window,
            V = !1;
          if (!j)
            try {
              window.parent.document && (V = !1);
            } catch (e) {
              V = !0;
            }
          if (j && !r) throw Error("emit function is required");
          if (!j && !V) return () => {};
          void 0 !== R && void 0 === I.mousemove && (I.mousemove = R),
            tw.reset();
          let q =
              !0 === S
                ? {
                    color: !0,
                    date: !0,
                    "datetime-local": !0,
                    email: !0,
                    month: !0,
                    number: !0,
                    range: !0,
                    search: !0,
                    tel: !0,
                    text: !0,
                    time: !0,
                    url: !0,
                    week: !0,
                    textarea: !0,
                    select: !0,
                    radio: !0,
                    checkbox: !0,
                  }
                : void 0 !== b
                ? b
                : {},
            G =
              !0 === v || "all" === v
                ? {
                    script: !0,
                    comment: !0,
                    headFavicon: !0,
                    headWhitespace: !0,
                    headMetaSocial: !0,
                    headMetaRobots: !0,
                    headMetaHttpEquiv: !0,
                    headMetaVerification: !0,
                    headMetaAuthorship: "all" === v,
                    headMetaDescKeywords: "all" === v,
                  }
                : v || {};
          !(function (e = window) {
            "NodeList" in e &&
              !e.NodeList.prototype.forEach &&
              (e.NodeList.prototype.forEach = Array.prototype.forEach),
              "DOMTokenList" in e &&
                !e.DOMTokenList.prototype.forEach &&
                (e.DOMTokenList.prototype.forEach = Array.prototype.forEach),
              Node.prototype.contains ||
                (Node.prototype.contains = (...e) => {
                  let t = e[0];
                  if (!(0 in e)) throw TypeError("1 argument is required");
                  do if (this === t) return !0;
                  while ((t = t && t.parentNode));
                  return !1;
                });
          })();
          let Y = 0,
            K = (e) => {
              for (let t of U || [])
                t.eventProcessor && (e = t.eventProcessor(e));
              return T && !V && (e = T(e)), e;
            };
          o = (e, s) => {
            let o = e;
            if (
              ((o.timestamp = e$()),
              (0, w.x)([
                ta,
                "access",
                (e) => e[0],
                "optionalAccess",
                (e) => e.isFrozen,
                "call",
                (e) => e(),
              ]) &&
                o.type !== e9.FullSnapshot &&
                !(
                  o.type === e9.IncrementalSnapshot &&
                  o.data.source === e4.Mutation
                ) &&
                ta.forEach((e) => e.unfreeze()),
              j)
            )
              (0, w.x)([r, "optionalCall", (e) => e(K(o), s)]);
            else if (V) {
              let e = {
                type: "rrweb",
                event: K(o),
                origin: window.location.origin,
                isCheckout: s,
              };
              window.parent.postMessage(e, "*");
            }
            if (o.type === e9.FullSnapshot) (t = o), (Y = 0);
            else if (o.type === e9.IncrementalSnapshot) {
              if (o.data.source === e4.Mutation && o.data.isAttachIframe)
                return;
              Y++;
              let e = i && Y >= i,
                r = n && t && o.timestamp - t.timestamp > n;
              (e || r) && eo(!0);
            }
          };
          let J = (e) => {
              o({
                type: e9.IncrementalSnapshot,
                data: { source: e4.Mutation, ...e },
              });
            },
            X = (e) =>
              o({
                type: e9.IncrementalSnapshot,
                data: { source: e4.Scroll, ...e },
              }),
            Z = (e) =>
              o({
                type: e9.IncrementalSnapshot,
                data: { source: e4.CanvasMutation, ...e },
              }),
            Q = (e) =>
              o({
                type: e9.IncrementalSnapshot,
                data: { source: e4.AdoptedStyleSheet, ...e },
              }),
            ee = new tb({ mutationCb: J, adoptedStyleSheetCb: Q }),
            et = new tg();
          for (let e of U || [])
            e.getMirror &&
              e.getMirror({
                nodeMirror: tw,
                crossOriginIframeMirror: et.crossOriginIframeMirror,
                crossOriginIframeStyleMirror: et.crossOriginIframeStyleMirror,
              });
          let er = new tv(),
            ei = (function (e, t) {
              try {
                return e ? e(t) : new tS();
              } catch (e) {
                return (
                  console.warn("Unable to initialize CanvasManager"), new tS()
                );
              }
            })($, {
              mirror: tw,
              win: window,
              mutationCb: (e) =>
                o({
                  type: e9.IncrementalSnapshot,
                  data: { source: e4.CanvasMutation, ...e },
                }),
              recordCanvas: A,
              blockClass: l,
              blockSelector: c,
              unblockSelector: u,
              maxCanvasSize: C,
              sampling: I.canvas,
              dataURLOptions: x,
              errorHandler: W,
            }),
            es = new t_(),
            eo = (e = !1) => {
              if (!D) return;
              o(
                {
                  type: e9.Meta,
                  data: {
                    href: window.location.href,
                    width: eq(),
                    height: eV(),
                  },
                },
                e
              ),
                ee.reset(),
                es.init(),
                ta.forEach((e) => e.lock());
              let t = (function (e, t) {
                let {
                  mirror: r = new en(),
                  blockClass: n = "rr-block",
                  blockSelector: i = null,
                  unblockSelector: s = null,
                  maskAllText: o = !1,
                  maskTextClass: a = "rr-mask",
                  unmaskTextClass: l = null,
                  maskTextSelector: c = null,
                  unmaskTextSelector: u = null,
                  inlineStylesheet: d = !0,
                  inlineImages: h = !1,
                  recordCanvas: p = !1,
                  maskAllInputs: m = !1,
                  maskAttributeFn: f,
                  maskTextFn: y,
                  maskInputFn: g,
                  slimDOM: _ = !1,
                  dataURLOptions: S,
                  preserveWhiteSpace: b,
                  onSerialize: v,
                  onIframeLoad: w,
                  iframeLoadTimeout: E,
                  onStylesheetLoad: k,
                  stylesheetLoadTimeout: M,
                  keepIframeSrcFn: C = () => !1,
                } = t || {};
                return eP(e, {
                  doc: e,
                  mirror: r,
                  blockClass: n,
                  blockSelector: i,
                  unblockSelector: s,
                  maskAllText: o,
                  maskTextClass: a,
                  unmaskTextClass: l,
                  maskTextSelector: c,
                  unmaskTextSelector: u,
                  skipChild: !1,
                  inlineStylesheet: d,
                  maskInputOptions:
                    !0 === m
                      ? {
                          color: !0,
                          date: !0,
                          "datetime-local": !0,
                          email: !0,
                          month: !0,
                          number: !0,
                          range: !0,
                          search: !0,
                          tel: !0,
                          text: !0,
                          time: !0,
                          url: !0,
                          week: !0,
                          textarea: !0,
                          select: !0,
                        }
                      : !1 === m
                      ? {}
                      : m,
                  maskAttributeFn: f,
                  maskTextFn: y,
                  maskInputFn: g,
                  slimDOMOptions:
                    !0 === _ || "all" === _
                      ? {
                          script: !0,
                          comment: !0,
                          headFavicon: !0,
                          headWhitespace: !0,
                          headMetaDescKeywords: "all" === _,
                          headMetaSocial: !0,
                          headMetaRobots: !0,
                          headMetaHttpEquiv: !0,
                          headMetaAuthorship: !0,
                          headMetaVerification: !0,
                        }
                      : !1 === _
                      ? {}
                      : _,
                  dataURLOptions: S,
                  inlineImages: h,
                  recordCanvas: p,
                  preserveWhiteSpace: b,
                  onSerialize: v,
                  onIframeLoad: w,
                  iframeLoadTimeout: E,
                  onStylesheetLoad: k,
                  stylesheetLoadTimeout: M,
                  keepIframeSrcFn: C,
                  newlyAddedElement: !1,
                });
              })(document, {
                mirror: tw,
                blockClass: l,
                blockSelector: c,
                unblockSelector: u,
                maskAllText: p,
                maskTextClass: m,
                unmaskTextClass: f,
                maskTextSelector: y,
                unmaskTextSelector: g,
                inlineStylesheet: _,
                maskAllInputs: q,
                maskAttributeFn: E,
                maskInputFn: k,
                maskTextFn: M,
                slimDOM: G,
                dataURLOptions: x,
                recordCanvas: A,
                inlineImages: F,
                onSerialize: (e) => {
                  eX(e, tw) && et.addIframe(e),
                    eZ(e, tw) && ee.trackLinkElement(e),
                    eQ(e) && es.addShadowRoot(e.shadowRoot, document);
                },
                onIframeLoad: (e, t) => {
                  et.attachIframe(e, t),
                    e.contentWindow && ei.addWindow(e.contentWindow),
                    es.observeAttachShadow(e);
                },
                onStylesheetLoad: (e, t) => {
                  ee.attachLinkElement(e, t);
                },
                keepIframeSrcFn: B,
              });
              if (!t) return console.warn("Failed to snapshot the document");
              o({
                type: e9.FullSnapshot,
                data: { node: t, initialOffset: ej(window) },
              }),
                ta.forEach((e) => e.unlock()),
                document.adoptedStyleSheets &&
                  document.adoptedStyleSheets.length > 0 &&
                  ee.adoptStyleSheets(
                    document.adoptedStyleSheets,
                    tw.getId(document)
                  );
            };
          a = eo;
          try {
            let e = [],
              t = (e) =>
                ts(tp)(
                  {
                    onMutation: H,
                    mutationCb: J,
                    mousemoveCb: (e, t) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: t, positions: e },
                      }),
                    mouseInteractionCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.MouseInteraction, ...e },
                      }),
                    scrollCb: X,
                    viewportResizeCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.ViewportResize, ...e },
                      }),
                    inputCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.Input, ...e },
                      }),
                    mediaInteractionCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.MediaInteraction, ...e },
                      }),
                    styleSheetRuleCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.StyleSheetRule, ...e },
                      }),
                    styleDeclarationCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.StyleDeclaration, ...e },
                      }),
                    canvasMutationCb: Z,
                    fontCb: (e) =>
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.Font, ...e },
                      }),
                    selectionCb: (e) => {
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.Selection, ...e },
                      });
                    },
                    customElementCb: (e) => {
                      o({
                        type: e9.IncrementalSnapshot,
                        data: { source: e4.CustomElement, ...e },
                      });
                    },
                    blockClass: l,
                    ignoreClass: d,
                    ignoreSelector: h,
                    maskAllText: p,
                    maskTextClass: m,
                    unmaskTextClass: f,
                    maskTextSelector: y,
                    unmaskTextSelector: g,
                    maskInputOptions: q,
                    inlineStylesheet: _,
                    sampling: I,
                    recordDOM: D,
                    recordCanvas: A,
                    inlineImages: F,
                    userTriggeredOnInput: L,
                    collectFonts: P,
                    doc: e,
                    maskAttributeFn: E,
                    maskInputFn: k,
                    maskTextFn: M,
                    keepIframeSrcFn: B,
                    blockSelector: c,
                    unblockSelector: u,
                    slimDOMOptions: G,
                    dataURLOptions: x,
                    mirror: tw,
                    iframeManager: et,
                    stylesheetManager: ee,
                    shadowDomManager: es,
                    processedNodeManager: er,
                    canvasManager: ei,
                    ignoreCSSAttributes: z,
                    plugins:
                      (0, w.x)([
                        U,
                        "optionalAccess",
                        (e) => e.filter,
                        "call",
                        (e) => e((e) => e.observer),
                        "optionalAccess",
                        (e) => e.map,
                        "call",
                        (e) =>
                          e((e) => ({
                            observer: e.observer,
                            options: e.options,
                            callback: (t) =>
                              o({
                                type: e9.Plugin,
                                data: { plugin: e.name, payload: t },
                              }),
                          })),
                      ]) || [],
                  },
                  {}
                );
            et.addLoadListener((r) => {
              try {
                e.push(t(r.contentDocument));
              } catch (e) {
                console.warn(e);
              }
            });
            let r = () => {
              eo(), e.push(t(document));
            };
            return (
              "interactive" === document.readyState ||
              "complete" === document.readyState
                ? r()
                : (e.push(
                    eU("DOMContentLoaded", () => {
                      o({ type: e9.DomContentLoaded, data: {} }),
                        "DOMContentLoaded" === O && r();
                    })
                  ),
                  e.push(
                    eU(
                      "load",
                      () => {
                        o({ type: e9.Load, data: {} }), "load" === O && r();
                      },
                      window
                    )
                  )),
              () => {
                e.forEach((e) => e()), er.destroy(), (a = void 0), (s = void 0);
              }
            );
          } catch (e) {
            console.warn(e);
          }
        }
        function tk(e) {
          return e > 9999999999 ? e : 1e3 * e;
        }
        function tM(e) {
          return e > 9999999999 ? e / 1e3 : e;
        }
        function tC(e, t) {
          "sentry.transaction" !== t.category &&
            (["ui.click", "ui.input"].includes(t.category)
              ? e.triggerUserActivity()
              : e.checkAndHandleExpiredSession(),
            e.addUpdate(
              () => (
                e.throttledAddEvent({
                  type: e9.Custom,
                  timestamp: 1e3 * (t.timestamp || 0),
                  data: { tag: "breadcrumb", payload: (0, k.Fv)(t, 10, 1e3) },
                }),
                "console" === t.category
              )
            ));
        }
        function tT(e) {
          let t = e.closest("button,a");
          return t || e;
        }
        function tI(e) {
          let t = tx(e);
          return t && t instanceof Element ? tT(t) : t;
        }
        function tx(e) {
          return "object" == typeof e && e && "target" in e ? e.target : e;
        }
        (tE.mirror = tw),
          (tE.takeFullSnapshot = function (e) {
            if (!a)
              throw Error("please take full snapshot after start recording");
            a(e);
          });
        let tR = new Set([
          e4.Mutation,
          e4.StyleSheetRule,
          e4.StyleDeclaration,
          e4.AdoptedStyleSheet,
          e4.CanvasMutation,
          e4.Selection,
          e4.MediaInteraction,
        ]);
        class tD {
          constructor(e, t, r = tC) {
            (this._lastMutation = 0),
              (this._lastScroll = 0),
              (this._clicks = []),
              (this._timeout = t.timeout / 1e3),
              (this._threshold = t.threshold / 1e3),
              (this._scrollTimeout = t.scrollTimeout / 1e3),
              (this._replay = e),
              (this._ignoreSelector = t.ignoreSelector),
              (this._addBreadcrumbEvent = r);
          }
          addListeners() {
            var e;
            let t =
              ((e = () => {
                this._lastMutation = tN();
              }),
              l ||
                ((l = []),
                (0, M.hl)(Y, "open", function (e) {
                  return function (...t) {
                    if (l)
                      try {
                        l.forEach((e) => e());
                      } catch (e) {}
                    return e.apply(Y, t);
                  };
                })),
              l.push(e),
              () => {
                let t = l ? l.indexOf(e) : -1;
                t > -1 && l.splice(t, 1);
              });
            this._teardown = () => {
              t(),
                (this._clicks = []),
                (this._lastMutation = 0),
                (this._lastScroll = 0);
            };
          }
          removeListeners() {
            this._teardown && this._teardown(),
              this._checkClickTimeout && clearTimeout(this._checkClickTimeout);
          }
          handleClick(e, t) {
            var r;
            if (
              ((r = this._ignoreSelector),
              !tA.includes(t.tagName) ||
                ("INPUT" === t.tagName &&
                  !["submit", "button"].includes(
                    t.getAttribute("type") || ""
                  )) ||
                ("A" === t.tagName &&
                  (t.hasAttribute("download") ||
                    (t.hasAttribute("target") &&
                      "_self" !== t.getAttribute("target")))) ||
                (r && t.matches(r)) ||
                !(e.data && "number" == typeof e.data.nodeId && e.timestamp))
            )
              return;
            let n = {
              timestamp: tM(e.timestamp),
              clickBreadcrumb: e,
              clickCount: 0,
              node: t,
            };
            this._clicks.some(
              (e) =>
                e.node === n.node && 1 > Math.abs(e.timestamp - n.timestamp)
            ) ||
              (this._clicks.push(n),
              1 === this._clicks.length && this._scheduleCheckClicks());
          }
          registerMutation(e = Date.now()) {
            this._lastMutation = tM(e);
          }
          registerScroll(e = Date.now()) {
            this._lastScroll = tM(e);
          }
          registerClick(e) {
            let t = tT(e);
            this._handleMultiClick(t);
          }
          _handleMultiClick(e) {
            this._getClicks(e).forEach((e) => {
              e.clickCount++;
            });
          }
          _getClicks(e) {
            return this._clicks.filter((t) => t.node === e);
          }
          _checkClicks() {
            let e = [],
              t = tN();
            for (let r of (this._clicks.forEach((r) => {
              !r.mutationAfter &&
                this._lastMutation &&
                (r.mutationAfter =
                  r.timestamp <= this._lastMutation
                    ? this._lastMutation - r.timestamp
                    : void 0),
                !r.scrollAfter &&
                  this._lastScroll &&
                  (r.scrollAfter =
                    r.timestamp <= this._lastScroll
                      ? this._lastScroll - r.timestamp
                      : void 0),
                r.timestamp + this._timeout <= t && e.push(r);
            }),
            e)) {
              let e = this._clicks.indexOf(r);
              e > -1 &&
                (this._generateBreadcrumbs(r), this._clicks.splice(e, 1));
            }
            this._clicks.length && this._scheduleCheckClicks();
          }
          _generateBreadcrumbs(e) {
            let t = this._replay,
              r = e.scrollAfter && e.scrollAfter <= this._scrollTimeout,
              n = e.mutationAfter && e.mutationAfter <= this._threshold,
              { clickCount: i, clickBreadcrumb: s } = e;
            if (!r && !n) {
              let r =
                  1e3 *
                  Math.min(e.mutationAfter || this._timeout, this._timeout),
                n = r < 1e3 * this._timeout ? "mutation" : "timeout",
                o = {
                  type: "default",
                  message: s.message,
                  timestamp: s.timestamp,
                  category: "ui.slowClickDetected",
                  data: {
                    ...s.data,
                    url: Y.location.href,
                    route: t.getCurrentRoute(),
                    timeAfterClickMs: r,
                    endReason: n,
                    clickCount: i || 1,
                  },
                };
              this._addBreadcrumbEvent(t, o);
              return;
            }
            if (i > 1) {
              let e = {
                type: "default",
                message: s.message,
                timestamp: s.timestamp,
                category: "ui.multiClick",
                data: {
                  ...s.data,
                  url: Y.location.href,
                  route: t.getCurrentRoute(),
                  clickCount: i,
                  metric: !0,
                },
              };
              this._addBreadcrumbEvent(t, e);
            }
          }
          _scheduleCheckClicks() {
            this._checkClickTimeout && clearTimeout(this._checkClickTimeout),
              (this._checkClickTimeout = (0, $.iK)(
                () => this._checkClicks(),
                1e3
              ));
          }
        }
        let tA = ["A", "BUTTON", "INPUT"];
        function tN() {
          return Date.now() / 1e3;
        }
        function tO(e) {
          return { timestamp: Date.now() / 1e3, type: "default", ...e };
        }
        ((y = b || (b = {}))[(y.Document = 0)] = "Document"),
          (y[(y.DocumentType = 1)] = "DocumentType"),
          (y[(y.Element = 2)] = "Element"),
          (y[(y.Text = 3)] = "Text"),
          (y[(y.CDATA = 4)] = "CDATA"),
          (y[(y.Comment = 5)] = "Comment");
        let tL = new Set([
            "id",
            "class",
            "aria-label",
            "role",
            "name",
            "alt",
            "title",
            "data-test-id",
            "data-testid",
            "disabled",
            "aria-disabled",
            "data-sentry-component",
          ]),
          tP = (e) => (t) => {
            if (!e.isEnabled()) return;
            let r = (function (e) {
              let { target: t, message: r } = (function (e) {
                let t;
                let r = "click" === e.name,
                  n = null;
                try {
                  (n = r ? tI(e.event) : tx(e.event)),
                    (t = (0, C.Rt)(n, { maxStringLength: 200 }) || "<unknown>");
                } catch (e) {
                  t = "<unknown>";
                }
                return { target: n, message: t };
              })(e);
              return tO({ category: `ui.${e.name}`, ...tF(t, r) });
            })(t);
            if (!r) return;
            let n = "click" === t.name,
              i = n ? t.event : void 0;
            n &&
              e.clickDetector &&
              i &&
              i.target &&
              !i.altKey &&
              !i.metaKey &&
              !i.ctrlKey &&
              !i.shiftKey &&
              (function (e, t, r) {
                e.handleClick(t, r);
              })(e.clickDetector, r, tI(t.event)),
              tC(e, r);
          };
        function tF(e, t) {
          let r = tE.mirror.getId(e),
            n = r && tE.mirror.getNode(r),
            i = n && tE.mirror.getMeta(n),
            s = i && i.type === b.Element ? i : null;
          return {
            message: t,
            data: s
              ? {
                  nodeId: r,
                  node: {
                    id: r,
                    tagName: s.tagName,
                    textContent: Array.from(s.childNodes)
                      .map((e) => e.type === b.Text && e.textContent)
                      .filter(Boolean)
                      .map((e) => e.trim())
                      .join(""),
                    attributes: (function (e) {
                      let t = {};
                      for (let r in (!e["data-sentry-component"] &&
                        e["data-sentry-element"] &&
                        (e["data-sentry-component"] = e["data-sentry-element"]),
                      e))
                        if (tL.has(r)) {
                          let n = r;
                          ("data-testid" === r || "data-test-id" === r) &&
                            (n = "testId"),
                            (t[n] = e[r]);
                        }
                      return t;
                    })(s.attributes),
                  },
                }
              : {},
          };
        }
        let tU = {
          resource: function (e) {
            let {
              entryType: t,
              initiatorType: r,
              name: n,
              responseEnd: i,
              startTime: s,
              decodedBodySize: o,
              encodedBodySize: a,
              responseStatus: l,
              transferSize: c,
            } = e;
            return ["fetch", "xmlhttprequest"].includes(r)
              ? null
              : {
                  type: `${t}.${r}`,
                  start: tW(s),
                  end: tW(i),
                  name: n,
                  data: {
                    size: c,
                    statusCode: l,
                    decodedBodySize: o,
                    encodedBodySize: a,
                  },
                };
          },
          paint: function (e) {
            let { duration: t, entryType: r, name: n, startTime: i } = e,
              s = tW(i);
            return { type: r, name: n, start: s, end: s + t, data: void 0 };
          },
          navigation: function (e) {
            let {
              entryType: t,
              name: r,
              decodedBodySize: n,
              duration: i,
              domComplete: s,
              encodedBodySize: o,
              domContentLoadedEventStart: a,
              domContentLoadedEventEnd: l,
              domInteractive: c,
              loadEventStart: u,
              loadEventEnd: d,
              redirectCount: h,
              startTime: p,
              transferSize: m,
              type: f,
            } = e;
            return 0 === i
              ? null
              : {
                  type: `${t}.${f}`,
                  start: tW(p),
                  end: tW(s),
                  name: r,
                  data: {
                    size: m,
                    decodedBodySize: n,
                    encodedBodySize: o,
                    duration: i,
                    domInteractive: c,
                    domContentLoadedEventStart: a,
                    domContentLoadedEventEnd: l,
                    loadEventStart: u,
                    loadEventEnd: d,
                    domComplete: s,
                    redirectCount: h,
                  },
                };
          },
        };
        function tB(e, t) {
          return ({ metric: r }) => void t.replayPerformanceEntries.push(e(r));
        }
        function tz(e) {
          let t = tU[e.entryType];
          return t ? t(e) : null;
        }
        function tW(e) {
          return ((T.Z1 || Y.performance.timeOrigin) + e) / 1e3;
        }
        function tH(e) {
          let t = e.entries[e.entries.length - 1],
            r = t && t.element ? [t.element] : void 0;
          return tq(e, "largest-contentful-paint", r);
        }
        function t$(e) {
          let t = [],
            r = [];
          for (let n of e.entries)
            if (void 0 !== n.sources) {
              let e = [];
              for (let t of n.sources)
                if (t.node) {
                  r.push(t.node);
                  let n = tE.mirror.getId(t.node);
                  n && e.push(n);
                }
              t.push({ value: n.value, nodeIds: e.length ? e : void 0 });
            }
          return tq(e, "cumulative-layout-shift", r, t);
        }
        function tj(e) {
          let t = e.entries[e.entries.length - 1],
            r = t && t.target ? [t.target] : void 0;
          return tq(e, "first-input-delay", r);
        }
        function tV(e) {
          let t = e.entries[e.entries.length - 1],
            r = t && t.target ? [t.target] : void 0;
          return tq(e, "interaction-to-next-paint", r);
        }
        function tq(e, t, r, n) {
          let i = e.value,
            s = e.rating,
            o = tW(i);
          return {
            type: "web-vital",
            name: t,
            start: o,
            end: o,
            data: {
              value: i,
              size: i,
              rating: s,
              nodeIds: r ? r.map((e) => tE.mirror.getId(e)) : void 0,
              attributions: n,
            },
          };
        }
        let tG = ["info", "warn", "error", "log"];
        (function () {
          let e = {
            exception: () => void 0,
            infoTick: () => void 0,
            setConfig: (e) => {
              e.captureExceptions, e.traceInternals;
            },
          };
          tG.forEach((t) => {
            e[t] = () => void 0;
          });
        })();
        class tY extends Error {
          constructor() {
            super("Event buffer exceeded maximum size of 20000000.");
          }
        }
        class tK {
          constructor() {
            (this.events = []),
              (this._totalSize = 0),
              (this.hasCheckout = !1),
              (this.waitForCheckout = !1);
          }
          get hasEvents() {
            return this.events.length > 0;
          }
          get type() {
            return "sync";
          }
          destroy() {
            this.events = [];
          }
          async addEvent(e) {
            let t = JSON.stringify(e).length;
            if (((this._totalSize += t), this._totalSize > 2e7)) throw new tY();
            this.events.push(e);
          }
          finish() {
            return new Promise((e) => {
              let t = this.events;
              this.clear(), e(JSON.stringify(t));
            });
          }
          clear() {
            (this.events = []), (this._totalSize = 0), (this.hasCheckout = !1);
          }
          getEarliestTimestamp() {
            let e = this.events.map((e) => e.timestamp).sort()[0];
            return e ? tk(e) : null;
          }
        }
        class tJ {
          constructor(e) {
            (this._worker = e), (this._id = 0);
          }
          ensureReady() {
            return (
              this._ensureReadyPromise ||
                (this._ensureReadyPromise = new Promise((e, t) => {
                  this._worker.addEventListener(
                    "message",
                    ({ data: r }) => {
                      r.success ? e() : t();
                    },
                    { once: !0 }
                  ),
                    this._worker.addEventListener(
                      "error",
                      (e) => {
                        t(e);
                      },
                      { once: !0 }
                    );
                })),
              this._ensureReadyPromise
            );
          }
          destroy() {
            this._worker.terminate();
          }
          postMessage(e, t) {
            let r = this._getAndIncrementId();
            return new Promise((n, i) => {
              let s = ({ data: t }) => {
                if (t.method === e && t.id === r) {
                  if (
                    (this._worker.removeEventListener("message", s), !t.success)
                  ) {
                    i(Error("Error in compression worker"));
                    return;
                  }
                  n(t.response);
                }
              };
              this._worker.addEventListener("message", s),
                this._worker.postMessage({ id: r, method: e, arg: t });
            });
          }
          _getAndIncrementId() {
            return this._id++;
          }
        }
        class tX {
          constructor(e) {
            (this._worker = new tJ(e)),
              (this._earliestTimestamp = null),
              (this._totalSize = 0),
              (this.hasCheckout = !1),
              (this.waitForCheckout = !1);
          }
          get hasEvents() {
            return !!this._earliestTimestamp;
          }
          get type() {
            return "worker";
          }
          ensureReady() {
            return this._worker.ensureReady();
          }
          destroy() {
            this._worker.destroy();
          }
          addEvent(e) {
            let t = tk(e.timestamp);
            (!this._earliestTimestamp || t < this._earliestTimestamp) &&
              (this._earliestTimestamp = t);
            let r = JSON.stringify(e);
            return ((this._totalSize += r.length), this._totalSize > 2e7)
              ? Promise.reject(new tY())
              : this._sendEventToWorker(r);
          }
          finish() {
            return this._finishRequest();
          }
          clear() {
            (this._earliestTimestamp = null),
              (this._totalSize = 0),
              (this.hasCheckout = !1),
              this._worker.postMessage("clear").then(null, (e) => {});
          }
          getEarliestTimestamp() {
            return this._earliestTimestamp;
          }
          _sendEventToWorker(e) {
            return this._worker.postMessage("addEvent", e);
          }
          async _finishRequest() {
            let e = await this._worker.postMessage("finish");
            return (this._earliestTimestamp = null), (this._totalSize = 0), e;
          }
        }
        class tZ {
          constructor(e) {
            (this._fallback = new tK()),
              (this._compression = new tX(e)),
              (this._used = this._fallback),
              (this._ensureWorkerIsLoadedPromise =
                this._ensureWorkerIsLoaded());
          }
          get waitForCheckout() {
            return this._used.waitForCheckout;
          }
          get type() {
            return this._used.type;
          }
          get hasEvents() {
            return this._used.hasEvents;
          }
          get hasCheckout() {
            return this._used.hasCheckout;
          }
          set hasCheckout(e) {
            this._used.hasCheckout = e;
          }
          set waitForCheckout(e) {
            this._used.waitForCheckout = e;
          }
          destroy() {
            this._fallback.destroy(), this._compression.destroy();
          }
          clear() {
            return this._used.clear();
          }
          getEarliestTimestamp() {
            return this._used.getEarliestTimestamp();
          }
          addEvent(e) {
            return this._used.addEvent(e);
          }
          async finish() {
            return await this.ensureWorkerIsLoaded(), this._used.finish();
          }
          ensureWorkerIsLoaded() {
            return this._ensureWorkerIsLoadedPromise;
          }
          async _ensureWorkerIsLoaded() {
            try {
              await this._compression.ensureReady();
            } catch (e) {
              return;
            }
            await this._switchToCompressionWorker();
          }
          async _switchToCompressionWorker() {
            let {
                events: e,
                hasCheckout: t,
                waitForCheckout: r,
              } = this._fallback,
              n = [];
            for (let t of e) n.push(this._compression.addEvent(t));
            (this._compression.hasCheckout = t),
              (this._compression.waitForCheckout = r),
              (this._used = this._compression);
            try {
              await Promise.all(n), this._fallback.clear();
            } catch (e) {}
          }
        }
        function tQ() {
          try {
            return "sessionStorage" in Y && !!Y.sessionStorage;
          } catch (e) {
            return !1;
          }
        }
        function t0(e) {
          return void 0 !== e && Math.random() < e;
        }
        function t1(e) {
          let t = Date.now(),
            r = e.id || (0, R.DM)(),
            n = e.started || t,
            i = e.lastActivity || t,
            s = e.segmentId || 0,
            o = e.sampled,
            a = e.previousSessionId;
          return {
            id: r,
            started: n,
            lastActivity: i,
            segmentId: s,
            sampled: o,
            previousSessionId: a,
          };
        }
        function t3(e) {
          if (tQ())
            try {
              Y.sessionStorage.setItem(K, JSON.stringify(e));
            } catch (e) {}
        }
        function t2(
          { sessionSampleRate: e, allowBuffering: t, stickySession: r = !1 },
          { previousSessionId: n } = {}
        ) {
          let i = t0(e) ? "session" : !!t && "buffer",
            s = t1({ sampled: i, previousSessionId: n });
          return r && t3(s), s;
        }
        function t5(e, t, r = +new Date()) {
          return null === e || void 0 === t || t < 0 || (0 !== t && e + t <= r);
        }
        function t9(
          e,
          {
            maxReplayDuration: t,
            sessionIdleExpire: r,
            targetTime: n = Date.now(),
          }
        ) {
          return t5(e.started, t, n) || t5(e.lastActivity, r, n);
        }
        function t4(e, { sessionIdleExpire: t, maxReplayDuration: r }) {
          return (
            !!t9(e, { sessionIdleExpire: t, maxReplayDuration: r }) &&
            ("buffer" !== e.sampled || 0 !== e.segmentId)
          );
        }
        function t7(
          { sessionIdleExpire: e, maxReplayDuration: t, previousSessionId: r },
          n
        ) {
          let i =
            n.stickySession &&
            (function () {
              if (!tQ()) return null;
              try {
                let e = Y.sessionStorage.getItem(K);
                if (!e) return null;
                let t = JSON.parse(e);
                return t1(t);
              } catch (e) {
                return null;
              }
            })();
          return i
            ? t4(i, { sessionIdleExpire: e, maxReplayDuration: t })
              ? t2(n, { previousSessionId: i.id })
              : i
            : t2(n, { previousSessionId: r });
        }
        function t8(e, t, r) {
          return !!re(e, t) && (t6(e, t, r), !0);
        }
        async function t6(e, t, r) {
          let { eventBuffer: n } = e;
          if (!n || (n.waitForCheckout && !r)) return null;
          let i = "buffer" === e.recordingMode;
          try {
            r && i && n.clear(),
              r && ((n.hasCheckout = !0), (n.waitForCheckout = !1));
            let s = e.getOptions(),
              o = (function (e, t) {
                try {
                  if ("function" == typeof t && e.type === e9.Custom)
                    return t(e);
                } catch (e) {
                  return null;
                }
                return e;
              })(t, s.beforeAddRecordingEvent);
            if (!o) return;
            return await n.addEvent(o);
          } catch (s) {
            let t = s && s instanceof tY;
            if (t && i) return n.clear(), (n.waitForCheckout = !0), null;
            e.handleException(s),
              await e.stop({ reason: t ? "addEventSizeExceeded" : "addEvent" });
            let r = (0, D.s3)();
            r && r.recordDroppedEvent("internal_sdk_error", "replay");
          }
        }
        function re(e, t) {
          if (!e.eventBuffer || e.isPaused() || !e.isEnabled()) return !1;
          let r = tk(t.timestamp);
          return (
            !(r + e.timeouts.sessionIdlePause < Date.now()) &&
            !(
              r >
              e.getContext().initialTimestamp + e.getOptions().maxReplayDuration
            )
          );
        }
        function rt(e) {
          return "transaction" === e.type;
        }
        function rr(e) {
          return "feedback" === e.type;
        }
        function rn(e) {
          return !!e.category;
        }
        function ri() {
          let e = (0, D.nZ)().getPropagationContext().dsc;
          e && delete e.replay_id;
          let t = (0, A.HN)();
          if (t) {
            let e = (0, N.jC)(t);
            delete e.replay_id;
          }
        }
        function rs(e, t) {
          return t.map(({ type: t, start: r, end: n, name: i, data: s }) => {
            let o = e.throttledAddEvent({
              type: e9.Custom,
              timestamp: r,
              data: {
                tag: "performanceSpan",
                payload: {
                  op: t,
                  description: i,
                  startTimestamp: r,
                  endTimestamp: n,
                  data: s,
                },
              },
            });
            return "string" == typeof o ? Promise.resolve(null) : o;
          });
        }
        function ro(e, t) {
          var r;
          e.isEnabled() &&
            null !== t &&
            ((r = t.name),
            (0, O.W)(r, (0, D.s3)()) || e.addUpdate(() => (rs(e, [t]), !0)));
        }
        function ra(e) {
          if (!e) return;
          let t = new TextEncoder();
          try {
            if ("string" == typeof e) return t.encode(e).length;
            if (e instanceof URLSearchParams)
              return t.encode(e.toString()).length;
            if (e instanceof FormData) {
              let r = rf(e);
              return t.encode(r).length;
            }
            if (e instanceof Blob) return e.size;
            if (e instanceof ArrayBuffer) return e.byteLength;
          } catch (e) {}
        }
        function rl(e) {
          if (!e) return;
          let t = parseInt(e, 10);
          return isNaN(t) ? void 0 : t;
        }
        function rc(e) {
          try {
            if ("string" == typeof e) return [e];
            if (e instanceof URLSearchParams) return [e.toString()];
            if (e instanceof FormData) return [rf(e)];
            if (!e) return [void 0];
          } catch (e) {
            return [void 0, "BODY_PARSE_ERROR"];
          }
          return [void 0, "UNPARSEABLE_BODY_TYPE"];
        }
        function ru(e, t) {
          if (!e)
            return { headers: {}, size: void 0, _meta: { warnings: [t] } };
          let r = { ...e._meta },
            n = r.warnings || [];
          return (r.warnings = [...n, t]), (e._meta = r), e;
        }
        function rd(e, t) {
          if (!t) return null;
          let {
              startTimestamp: r,
              endTimestamp: n,
              url: i,
              method: s,
              statusCode: o,
              request: a,
              response: l,
            } = t,
            c = {
              type: e,
              start: r / 1e3,
              end: n / 1e3,
              name: i,
              data: (0, M.Jr)({
                method: s,
                statusCode: o,
                request: a,
                response: l,
              }),
            };
          return c;
        }
        function rh(e) {
          return { headers: {}, size: e, _meta: { warnings: ["URL_SKIPPED"] } };
        }
        function rp(e, t, r) {
          if (!t && 0 === Object.keys(e).length) return;
          if (!t) return { headers: e };
          if (!r) return { headers: e, size: t };
          let n = { headers: e, size: t },
            { body: i, warnings: s } = (function (e) {
              if (!e || "string" != typeof e) return { body: e };
              let t = e.length > 15e4,
                r = (function (e) {
                  let t = e[0],
                    r = e[e.length - 1];
                  return ("[" === t && "]" === r) || ("{" === t && "}" === r);
                })(e);
              if (t) {
                let t = e.slice(0, 15e4);
                return r
                  ? { body: t, warnings: ["MAYBE_JSON_TRUNCATED"] }
                  : { body: `${t}…`, warnings: ["TEXT_TRUNCATED"] };
              }
              if (r)
                try {
                  let t = JSON.parse(e);
                  return { body: t };
                } catch (e) {}
              return { body: e };
            })(r);
          return (
            (n.body = i), s && s.length > 0 && (n._meta = { warnings: s }), n
          );
        }
        function rm(e, t) {
          return Object.entries(e).reduce((r, [n, i]) => {
            let s = n.toLowerCase();
            return t.includes(s) && e[n] && (r[s] = i), r;
          }, {});
        }
        function rf(e) {
          return new URLSearchParams(e).toString();
        }
        function ry(e, t) {
          let r = (function (e, t = Y.document.baseURI) {
            if (
              e.startsWith("http://") ||
              e.startsWith("https://") ||
              e.startsWith(Y.location.origin)
            )
              return e;
            let r = new URL(e, t);
            if (r.origin !== new URL(t).origin) return e;
            let n = r.href;
            return !e.endsWith("/") && n.endsWith("/") ? n.slice(0, -1) : n;
          })(e);
          return (0, L.U0)(r, t);
        }
        async function rg(e, t, r) {
          try {
            let n = await r_(e, t, r),
              i = rd("resource.fetch", n);
            ro(r.replay, i);
          } catch (e) {}
        }
        async function r_(e, t, r) {
          let n = Date.now(),
            { startTimestamp: i = n, endTimestamp: s = n } = t,
            {
              url: o,
              method: a,
              status_code: l = 0,
              request_body_size: c,
              response_body_size: u,
            } = e.data,
            d =
              ry(o, r.networkDetailAllowUrls) &&
              !ry(o, r.networkDetailDenyUrls),
            h = d
              ? (function (
                  { networkCaptureBodies: e, networkRequestHeaders: t },
                  r,
                  n
                ) {
                  let i = r
                    ? 1 === r.length && "string" != typeof r[0]
                      ? rE(r[0], t)
                      : 2 === r.length
                      ? rE(r[1], t)
                      : {}
                    : {};
                  if (!e) return rp(i, n, void 0);
                  let s = rv(r),
                    [o, a] = rc(s),
                    l = rp(i, n, o);
                  return a ? ru(l, a) : l;
                })(r, t.input, c)
              : rh(c),
            p = await rS(d, r, t.response, u);
          return {
            startTimestamp: i,
            endTimestamp: s,
            url: o,
            method: a,
            statusCode: l,
            request: h,
            response: p,
          };
        }
        async function rS(
          e,
          { networkCaptureBodies: t, networkResponseHeaders: r },
          n,
          i
        ) {
          if (!e && void 0 !== i) return rh(i);
          let s = n ? rw(n.headers, r) : {};
          if (!n || (!t && void 0 !== i)) return rp(s, i, void 0);
          let [o, a] = await rb(n),
            l = (function (
              e,
              {
                networkCaptureBodies: t,
                responseBodySize: r,
                captureDetails: n,
                headers: i,
              }
            ) {
              try {
                let s = e && e.length && void 0 === r ? ra(e) : r;
                if (!n) return rh(s);
                if (t) return rp(i, s, e);
                return rp(i, s, void 0);
              } catch (e) {
                return rp(i, r, void 0);
              }
            })(o, {
              networkCaptureBodies: t,
              responseBodySize: i,
              captureDetails: e,
              headers: s,
            });
          return a ? ru(l, a) : l;
        }
        async function rb(e) {
          let t = (function (e) {
            try {
              return e.clone();
            } catch (e) {}
          })(e);
          if (!t) return [void 0, "BODY_PARSE_ERROR"];
          try {
            let e = await new Promise((e, r) => {
              let n = (0, $.iK)(
                () => r(Error("Timeout while trying to read response body")),
                500
              );
              rk(t)
                .then(
                  (t) => e(t),
                  (e) => r(e)
                )
                .finally(() => clearTimeout(n));
            });
            return [e];
          } catch (e) {
            if (e instanceof Error && e.message.indexOf("Timeout") > -1)
              return [void 0, "BODY_PARSE_TIMEOUT"];
            return [void 0, "BODY_PARSE_ERROR"];
          }
        }
        function rv(e = []) {
          if (2 === e.length && "object" == typeof e[1]) return e[1].body;
        }
        function rw(e, t) {
          let r = {};
          return (
            t.forEach((t) => {
              e.get(t) && (r[t] = e.get(t));
            }),
            r
          );
        }
        function rE(e, t) {
          if (!e) return {};
          let r = e.headers;
          return r
            ? r instanceof Headers
              ? rw(r, t)
              : Array.isArray(r)
              ? {}
              : rm(r, t)
            : {};
        }
        async function rk(e) {
          return await e.text();
        }
        async function rM(e, t, r) {
          try {
            let n = (function (e, t, r) {
                let n = Date.now(),
                  {
                    startTimestamp: i = n,
                    endTimestamp: s = n,
                    input: o,
                    xhr: a,
                  } = t,
                  {
                    url: l,
                    method: c,
                    status_code: u = 0,
                    request_body_size: d,
                    response_body_size: h,
                  } = e.data;
                if (!l) return null;
                if (
                  !a ||
                  !ry(l, r.networkDetailAllowUrls) ||
                  ry(l, r.networkDetailDenyUrls)
                ) {
                  let e = rh(d),
                    t = rh(h);
                  return {
                    startTimestamp: i,
                    endTimestamp: s,
                    url: l,
                    method: c,
                    statusCode: u,
                    request: e,
                    response: t,
                  };
                }
                let p = a[V.xU],
                  m = p ? rm(p.request_headers, r.networkRequestHeaders) : {},
                  f = rm(
                    (function (e) {
                      let t = e.getAllResponseHeaders();
                      return t
                        ? t.split("\r\n").reduce((e, t) => {
                            let [r, n] = t.split(": ");
                            return n && (e[r.toLowerCase()] = n), e;
                          }, {})
                        : {};
                    })(a),
                    r.networkResponseHeaders
                  ),
                  [y, g] = r.networkCaptureBodies ? rc(o) : [void 0],
                  [_, S] = r.networkCaptureBodies
                    ? (function (e) {
                        let t = [];
                        try {
                          return [e.responseText];
                        } catch (e) {
                          t.push(e);
                        }
                        try {
                          return (function (e, t) {
                            try {
                              if ("string" == typeof e) return [e];
                              if (e instanceof Document)
                                return [e.body.outerHTML];
                              if ("json" === t && e && "object" == typeof e)
                                return [JSON.stringify(e)];
                              if (!e) return [void 0];
                            } catch (e) {
                              return [void 0, "BODY_PARSE_ERROR"];
                            }
                            return [void 0, "UNPARSEABLE_BODY_TYPE"];
                          })(e.response, e.responseType);
                        } catch (e) {
                          t.push(e);
                        }
                        return [void 0];
                      })(a)
                    : [void 0],
                  b = rp(m, d, y),
                  v = rp(f, h, _);
                return {
                  startTimestamp: i,
                  endTimestamp: s,
                  url: l,
                  method: c,
                  statusCode: u,
                  request: g ? ru(b, g) : b,
                  response: S ? ru(v, S) : v,
                };
              })(e, t, r),
              i = rd("resource.xhr", n);
            ro(r.replay, i);
          } catch (e) {}
        }
        async function rC(e) {
          try {
            return Promise.all(
              rs(e, [
                (function (e) {
                  let {
                      jsHeapSizeLimit: t,
                      totalJSHeapSize: r,
                      usedJSHeapSize: n,
                    } = e,
                    i = Date.now() / 1e3;
                  return {
                    type: "memory",
                    name: "memory",
                    start: i,
                    end: i,
                    data: {
                      memory: {
                        jsHeapSizeLimit: t,
                        totalJSHeapSize: r,
                        usedJSHeapSize: n,
                      },
                    },
                  };
                })(Y.performance.memory),
              ])
            );
          } catch (e) {
            return [];
          }
        }
        async function rT({ client: e, scope: t, replayId: r, event: n }) {
          let i =
              "object" != typeof e._integrations ||
              null === e._integrations ||
              Array.isArray(e._integrations)
                ? void 0
                : Object.keys(e._integrations),
            s = { event_id: r, integrations: i };
          e.emit("preprocessEvent", n, s);
          let o = await (0, F.R)(e.getOptions(), n, s, t, e, (0, D.aF)());
          if (!o) return null;
          o.platform = o.platform || "javascript";
          let a = e.getSdkMetadata(),
            { name: l, version: c } = (a && a.sdk) || {};
          return (
            (o.sdk = {
              ...o.sdk,
              name: l || "sentry.javascript.unknown",
              version: c || "0.0.0",
            }),
            o
          );
        }
        async function rI({
          recordingData: e,
          replayId: t,
          segmentId: r,
          eventContext: n,
          timestamp: i,
          session: s,
        }) {
          var o;
          let a;
          let l = (function ({ recordingData: e, headers: t }) {
              let r;
              let n = `${JSON.stringify(t)}
`;
              if ("string" == typeof e) r = `${n}${e}`;
              else {
                let t = new TextEncoder(),
                  i = t.encode(n);
                (r = new Uint8Array(i.length + e.length)).set(i),
                  r.set(e, i.length);
              }
              return r;
            })({ recordingData: e, headers: { segment_id: r } }),
            { urls: c, errorIds: u, traceIds: d, initialTimestamp: h } = n,
            p = (0, D.s3)(),
            m = (0, D.nZ)(),
            f = p && p.getTransport(),
            y = p && p.getDsn();
          if (!p || !f || !y || !s.sampled) return (0, U.WD)({});
          let g = {
              type: "replay_event",
              replay_start_timestamp: h / 1e3,
              timestamp: i / 1e3,
              error_ids: u,
              trace_ids: d,
              urls: c,
              replay_id: t,
              segment_id: r,
              replay_type: s.sampled,
            },
            _ = await rT({ scope: m, client: p, replayId: t, event: g });
          if (!_)
            return (
              p.recordDroppedEvent("event_processor", "replay", g),
              (0, U.WD)({})
            );
          delete _.sdkProcessingMetadata;
          let S =
            ((o = p.getOptions().tunnel),
            (0, P.Jd)((0, P.Cd)(_, (0, P.HY)(_), o, y), [
              [{ type: "replay_event" }, _],
              [
                {
                  type: "replay_recording",
                  length:
                    "string" == typeof l
                      ? new TextEncoder().encode(l).length
                      : l.length,
                },
                l,
              ],
            ]));
          try {
            a = await f.send(S);
          } catch (t) {
            let e = Error(J);
            try {
              e.cause = t;
            } catch (e) {}
            throw e;
          }
          if (
            "number" == typeof a.statusCode &&
            (a.statusCode < 200 || a.statusCode >= 300)
          )
            throw new rx(a.statusCode);
          let b = (0, B.WG)({}, a);
          if ((0, B.Q)(b, "replay")) throw new rR(b);
          return a;
        }
        class rx extends Error {
          constructor(e) {
            super(`Transport returned status code ${e}`);
          }
        }
        class rR extends Error {
          constructor(e) {
            super("Rate limit hit"), (this.rateLimits = e);
          }
        }
        async function rD(e, t = { count: 0, interval: 5e3 }) {
          let { recordingData: r, onError: n } = e;
          if (r.length)
            try {
              return await rI(e), !0;
            } catch (r) {
              if (r instanceof rx || r instanceof rR) throw r;
              if (
                ((0, x.v)("Replays", { _retryCount: t.count }),
                n && n(r),
                t.count >= 3)
              ) {
                let e = Error(`${J} - max retries exceeded`);
                try {
                  e.cause = r;
                } catch (e) {}
                throw e;
              }
              return (
                (t.interval *= ++t.count),
                new Promise((r, n) => {
                  (0, $.iK)(async () => {
                    try {
                      await rD(e, t), r(!0);
                    } catch (e) {
                      n(e);
                    }
                  }, t.interval);
                })
              );
            }
        }
        let rA = "__THROTTLED";
        class rN {
          constructor({ options: e, recordingOptions: t }) {
            rN.prototype.__init.call(this),
              rN.prototype.__init2.call(this),
              rN.prototype.__init3.call(this),
              rN.prototype.__init4.call(this),
              rN.prototype.__init5.call(this),
              rN.prototype.__init6.call(this),
              (this.eventBuffer = null),
              (this.performanceEntries = []),
              (this.replayPerformanceEntries = []),
              (this.recordingMode = "session"),
              (this.timeouts = {
                sessionIdlePause: 3e5,
                sessionIdleExpire: 9e5,
              }),
              (this._lastActivity = Date.now()),
              (this._isEnabled = !1),
              (this._isPaused = !1),
              (this._requiresManualStart = !1),
              (this._hasInitializedCoreListeners = !1),
              (this._context = {
                errorIds: new Set(),
                traceIds: new Set(),
                urls: [],
                initialTimestamp: Date.now(),
                initialUrl: "",
              }),
              (this._recordingOptions = t),
              (this._options = e),
              (this._debouncedFlush = (function (e, t, r) {
                let n, i, s;
                let o = r && r.maxWait ? Math.max(r.maxWait, t) : 0;
                function a() {
                  return l(), (n = e());
                }
                function l() {
                  void 0 !== i && clearTimeout(i),
                    void 0 !== s && clearTimeout(s),
                    (i = s = void 0);
                }
                function c() {
                  return (
                    i && clearTimeout(i),
                    (i = (0, $.iK)(a, t)),
                    o && void 0 === s && (s = (0, $.iK)(a, o)),
                    n
                  );
                }
                return (
                  (c.cancel = l),
                  (c.flush = function () {
                    return void 0 !== i || void 0 !== s ? a() : n;
                  }),
                  c
                );
              })(() => this._flush(), this._options.flushMinDelay, {
                maxWait: this._options.flushMaxDelay,
              })),
              (this._throttledAddEvent = (function (e, t, r) {
                let n = new Map(),
                  i = (e) => {
                    let t = e - 5;
                    n.forEach((e, r) => {
                      r < t && n.delete(r);
                    });
                  },
                  s = () => [...n.values()].reduce((e, t) => e + t, 0),
                  o = !1;
                return (...t) => {
                  let r = Math.floor(Date.now() / 1e3);
                  if ((i(r), s() >= 300)) {
                    let e = o;
                    return (o = !0), e ? "__SKIPPED" : rA;
                  }
                  o = !1;
                  let a = n.get(r) || 0;
                  return n.set(r, a + 1), e(...t);
                };
              })(
                (e, t) =>
                  re(this, e) ? t6(this, e, t) : Promise.resolve(null),
                0,
                0
              ));
            let { slowClickTimeout: r, slowClickIgnoreSelectors: n } =
                this.getOptions(),
              i = r
                ? {
                    threshold: Math.min(3e3, r),
                    timeout: r,
                    scrollTimeout: 300,
                    ignoreSelector: n ? n.join(",") : "",
                  }
                : void 0;
            i && (this.clickDetector = new tD(this, i));
          }
          getContext() {
            return this._context;
          }
          isEnabled() {
            return this._isEnabled;
          }
          isPaused() {
            return this._isPaused;
          }
          isRecordingCanvas() {
            return Boolean(this._canvas);
          }
          getOptions() {
            return this._options;
          }
          handleException(e) {
            this._options.onError && this._options.onError(e);
          }
          initializeSampling(e) {
            let { errorSampleRate: t, sessionSampleRate: r } = this._options,
              n = t <= 0 && r <= 0;
            (this._requiresManualStart = n),
              !n &&
                (this._initializeSessionForSampling(e), this.session) &&
                !1 !== this.session.sampled &&
                ((this.recordingMode =
                  "buffer" === this.session.sampled &&
                  0 === this.session.segmentId
                    ? "buffer"
                    : "session"),
                this._initializeRecording());
          }
          start() {
            if (
              (this._isEnabled && "session" === this.recordingMode) ||
              (this._isEnabled && "buffer" === this.recordingMode)
            )
              return;
            this._updateUserActivity();
            let e = t7(
              {
                maxReplayDuration: this._options.maxReplayDuration,
                sessionIdleExpire: this.timeouts.sessionIdleExpire,
              },
              {
                stickySession: this._options.stickySession,
                sessionSampleRate: 1,
                allowBuffering: !1,
              }
            );
            (this.session = e), this._initializeRecording();
          }
          startBuffering() {
            if (this._isEnabled) return;
            let e = t7(
              {
                sessionIdleExpire: this.timeouts.sessionIdleExpire,
                maxReplayDuration: this._options.maxReplayDuration,
              },
              {
                stickySession: this._options.stickySession,
                sessionSampleRate: 0,
                allowBuffering: !0,
              }
            );
            (this.session = e),
              (this.recordingMode = "buffer"),
              this._initializeRecording();
          }
          startRecording() {
            try {
              var e;
              let t;
              let r = this._canvas;
              this._stopRecording = tE({
                ...this._recordingOptions,
                ...("buffer" === this.recordingMode
                  ? { checkoutEveryNms: 6e4 }
                  : this._options._experiments.continuousCheckout && {
                      checkoutEveryNms: Math.max(
                        36e4,
                        this._options._experiments.continuousCheckout
                      ),
                    }),
                emit:
                  ((e = this),
                  (t = !1),
                  (r, n) => {
                    if (!e.checkAndHandleExpiredSession()) return;
                    let i = n || !t;
                    (t = !0),
                      e.clickDetector &&
                        (function (e, t) {
                          try {
                            if (3 !== t.type) return;
                            let { source: r } = t.data;
                            if (
                              (tR.has(r) && e.registerMutation(t.timestamp),
                              r === e4.Scroll && e.registerScroll(t.timestamp),
                              t.data.source === e4.MouseInteraction)
                            ) {
                              let { type: r, id: n } = t.data,
                                i = tE.mirror.getNode(n);
                              i instanceof HTMLElement &&
                                r === e7.Click &&
                                e.registerClick(i);
                            }
                          } catch (e) {}
                        })(e.clickDetector, r),
                      e.addUpdate(() => {
                        if (
                          ("buffer" === e.recordingMode &&
                            i &&
                            e.setInitialState(),
                          !t8(e, r, i))
                        )
                          return !0;
                        if (!i) return !1;
                        let t = e.session;
                        if (
                          (i &&
                            e.session &&
                            0 === e.session.segmentId &&
                            t8(
                              e,
                              (function (e) {
                                let t = e.getOptions();
                                return {
                                  type: e9.Custom,
                                  timestamp: Date.now(),
                                  data: {
                                    tag: "options",
                                    payload: {
                                      shouldRecordCanvas: e.isRecordingCanvas(),
                                      sessionSampleRate: t.sessionSampleRate,
                                      errorSampleRate: t.errorSampleRate,
                                      useCompressionOption: t.useCompression,
                                      blockAllMedia: t.blockAllMedia,
                                      maskAllText: t.maskAllText,
                                      maskAllInputs: t.maskAllInputs,
                                      useCompression:
                                        !!e.eventBuffer &&
                                        "worker" === e.eventBuffer.type,
                                      networkDetailHasUrls:
                                        t.networkDetailAllowUrls.length > 0,
                                      networkCaptureBodies:
                                        t.networkCaptureBodies,
                                      networkRequestHasHeaders:
                                        t.networkRequestHeaders.length > 0,
                                      networkResponseHasHeaders:
                                        t.networkResponseHeaders.length > 0,
                                    },
                                  },
                                };
                              })(e),
                              !1
                            ),
                          "buffer" === e.recordingMode && t && e.eventBuffer)
                        ) {
                          let r = e.eventBuffer.getEarliestTimestamp();
                          r &&
                            ((t.started = r),
                            e.getOptions().stickySession && t3(t));
                        }
                        return (
                          (!!t && !!t.previousSessionId) ||
                          ("session" === e.recordingMode && e.flush(), !0)
                        );
                      });
                  }),
                onMutation: this._onMutationHandler,
                ...(r
                  ? {
                      recordCanvas: r.recordCanvas,
                      getCanvasManager: r.getCanvasManager,
                      sampling: r.sampling,
                      dataURLOptions: r.dataURLOptions,
                    }
                  : {}),
              });
            } catch (e) {
              this.handleException(e);
            }
          }
          stopRecording() {
            try {
              return (
                this._stopRecording &&
                  (this._stopRecording(), (this._stopRecording = void 0)),
                !0
              );
            } catch (e) {
              return this.handleException(e), !1;
            }
          }
          async stop({ forceFlush: e = !1, reason: t } = {}) {
            if (this._isEnabled) {
              this._isEnabled = !1;
              try {
                var r;
                ri(),
                  this._removeListeners(),
                  this.stopRecording(),
                  this._debouncedFlush.cancel(),
                  e && (await this._flush({ force: !0 })),
                  this.eventBuffer && this.eventBuffer.destroy(),
                  (this.eventBuffer = null),
                  (r = this),
                  (function () {
                    if (tQ())
                      try {
                        Y.sessionStorage.removeItem(K);
                      } catch (e) {}
                  })(),
                  (r.session = void 0);
              } catch (e) {
                this.handleException(e);
              }
            }
          }
          pause() {
            this._isPaused || ((this._isPaused = !0), this.stopRecording());
          }
          resume() {
            this._isPaused &&
              this._checkSession() &&
              ((this._isPaused = !1), this.startRecording());
          }
          async sendBufferedReplayOrFlush({ continueRecording: e = !0 } = {}) {
            if ("session" === this.recordingMode) return this.flushImmediate();
            let t = Date.now();
            await this.flushImmediate();
            let r = this.stopRecording();
            e &&
              r &&
              "session" !== this.recordingMode &&
              ((this.recordingMode = "session"),
              this.session &&
                (this._updateUserActivity(t),
                this._updateSessionActivity(t),
                this._maybeSaveSession()),
              this.startRecording());
          }
          addUpdate(e) {
            let t = e();
            "buffer" !== this.recordingMode &&
              !0 !== t &&
              this._debouncedFlush();
          }
          triggerUserActivity() {
            if ((this._updateUserActivity(), !this._stopRecording)) {
              if (!this._checkSession()) return;
              this.resume();
              return;
            }
            this.checkAndHandleExpiredSession(), this._updateSessionActivity();
          }
          updateUserActivity() {
            this._updateUserActivity(), this._updateSessionActivity();
          }
          conditionalFlush() {
            return "buffer" === this.recordingMode
              ? Promise.resolve()
              : this.flushImmediate();
          }
          flush() {
            return this._debouncedFlush();
          }
          flushImmediate() {
            return this._debouncedFlush(), this._debouncedFlush.flush();
          }
          cancelFlush() {
            this._debouncedFlush.cancel();
          }
          getSessionId() {
            return this.session && this.session.id;
          }
          checkAndHandleExpiredSession() {
            if (
              this._lastActivity &&
              t5(this._lastActivity, this.timeouts.sessionIdlePause) &&
              this.session &&
              "session" === this.session.sampled
            ) {
              this.pause();
              return;
            }
            return !!this._checkSession();
          }
          setInitialState() {
            let e = `${Y.location.pathname}${Y.location.hash}${Y.location.search}`,
              t = `${Y.location.origin}${e}`;
            (this.performanceEntries = []),
              (this.replayPerformanceEntries = []),
              this._clearContext(),
              (this._context.initialUrl = t),
              (this._context.initialTimestamp = Date.now()),
              this._context.urls.push(t);
          }
          throttledAddEvent(e, t) {
            let r = this._throttledAddEvent(e, t);
            if (r === rA) {
              let e = tO({ category: "replay.throttled" });
              this.addUpdate(
                () =>
                  !t8(this, {
                    type: 5,
                    timestamp: e.timestamp || 0,
                    data: { tag: "breadcrumb", payload: e, metric: !0 },
                  })
              );
            }
            return r;
          }
          getCurrentRoute() {
            let e = this.lastActiveSpan || (0, A.HN)(),
              t = e && (0, A.Gx)(e),
              r = (t && (0, A.XU)(t).data) || {},
              n = r[z.Zj];
            if (t && n && ["route", "custom"].includes(n))
              return (0, A.XU)(t).description;
          }
          _initializeRecording() {
            this.setInitialState(),
              this._updateSessionActivity(),
              (this.eventBuffer = (function ({
                useCompression: e,
                workerUrl: t,
              }) {
                if (e && window.Worker) {
                  let e = (function (e) {
                    try {
                      let t = e || "";
                      if (!t) return;
                      let r = new Worker(t);
                      return new tZ(r);
                    } catch (e) {}
                  })(t);
                  if (e) return e;
                }
                return new tK();
              })({
                useCompression: this._options.useCompression,
                workerUrl: this._options.workerUrl,
              })),
              this._removeListeners(),
              this._addListeners(),
              (this._isEnabled = !0),
              (this._isPaused = !1),
              this.startRecording();
          }
          _initializeSessionForSampling(e) {
            let t = this._options.errorSampleRate > 0,
              r = t7(
                {
                  sessionIdleExpire: this.timeouts.sessionIdleExpire,
                  maxReplayDuration: this._options.maxReplayDuration,
                  previousSessionId: e,
                },
                {
                  stickySession: this._options.stickySession,
                  sessionSampleRate: this._options.sessionSampleRate,
                  allowBuffering: t,
                }
              );
            this.session = r;
          }
          _checkSession() {
            if (!this.session) return !1;
            let e = this.session;
            return (
              !t4(e, {
                sessionIdleExpire: this.timeouts.sessionIdleExpire,
                maxReplayDuration: this._options.maxReplayDuration,
              }) || (this._refreshSession(e), !1)
            );
          }
          async _refreshSession(e) {
            this._isEnabled &&
              (await this.stop({ reason: "refresh session" }),
              this.initializeSampling(e.id));
          }
          _addListeners() {
            try {
              Y.document.addEventListener(
                "visibilitychange",
                this._handleVisibilityChange
              ),
                Y.addEventListener("blur", this._handleWindowBlur),
                Y.addEventListener("focus", this._handleWindowFocus),
                Y.addEventListener("keydown", this._handleKeyboardEvent),
                this.clickDetector && this.clickDetector.addListeners(),
                this._hasInitializedCoreListeners ||
                  ((function (e) {
                    let t = (0, D.s3)();
                    (0, q.O)(tP(e)),
                      (0, G.a)((t) => {
                        if (!e.isEnabled()) return;
                        let r = (function (e) {
                          let { from: t, to: r } = e,
                            n = Date.now() / 1e3;
                          return {
                            type: "navigation.push",
                            start: n,
                            end: n,
                            name: r,
                            data: { previous: t },
                          };
                        })(t);
                        null !== r &&
                          (e.getContext().urls.push(r.name),
                          e.triggerUserActivity(),
                          e.addUpdate(() => (rs(e, [r]), !1)));
                      }),
                      (function (e) {
                        let t = (0, D.s3)();
                        t &&
                          t.on("beforeAddBreadcrumb", (t) =>
                            (function (e, t) {
                              if (!e.isEnabled() || !rn(t)) return;
                              let r =
                                !rn(t) ||
                                [
                                  "fetch",
                                  "xhr",
                                  "sentry.event",
                                  "sentry.transaction",
                                ].includes(t.category) ||
                                t.category.startsWith("ui.")
                                  ? null
                                  : "console" === t.category
                                  ? (function (e) {
                                      let t = e.data && e.data.arguments;
                                      if (!Array.isArray(t) || 0 === t.length)
                                        return tO(e);
                                      let r = !1,
                                        n = t.map((e) => {
                                          if (!e) return e;
                                          if ("string" == typeof e)
                                            return e.length > 5e3
                                              ? ((r = !0),
                                                `${e.slice(0, 5e3)}…`)
                                              : e;
                                          if ("object" == typeof e)
                                            try {
                                              let t = (0, k.Fv)(e, 7),
                                                n = JSON.stringify(t);
                                              if (n.length > 5e3)
                                                return (
                                                  (r = !0),
                                                  `${JSON.stringify(
                                                    t,
                                                    null,
                                                    2
                                                  ).slice(0, 5e3)}…`
                                                );
                                              return t;
                                            } catch (e) {}
                                          return e;
                                        });
                                      return tO({
                                        ...e,
                                        data: {
                                          ...e.data,
                                          arguments: n,
                                          ...(r
                                            ? {
                                                _meta: {
                                                  warnings: [
                                                    "CONSOLE_ARG_TRUNCATED",
                                                  ],
                                                },
                                              }
                                            : {}),
                                        },
                                      });
                                    })(t)
                                  : tO(t);
                              r && tC(e, r);
                            })(e, t)
                          );
                      })(e),
                      (function (e) {
                        let t = (0, D.s3)();
                        try {
                          let {
                              networkDetailAllowUrls: r,
                              networkDetailDenyUrls: n,
                              networkCaptureBodies: i,
                              networkRequestHeaders: s,
                              networkResponseHeaders: o,
                            } = e.getOptions(),
                            a = {
                              replay: e,
                              networkDetailAllowUrls: r,
                              networkDetailDenyUrls: n,
                              networkCaptureBodies: i,
                              networkRequestHeaders: s,
                              networkResponseHeaders: o,
                            };
                          t &&
                            t.on("beforeAddBreadcrumb", (e, t) =>
                              (function (e, t, r) {
                                if (t.data)
                                  try {
                                    var n, i;
                                    "xhr" === t.category &&
                                      (n = r) &&
                                      n.xhr &&
                                      ((function (e, t) {
                                        let { xhr: r, input: n } = t;
                                        if (!r) return;
                                        let i = ra(n),
                                          s = r.getResponseHeader(
                                            "content-length"
                                          )
                                            ? rl(
                                                r.getResponseHeader(
                                                  "content-length"
                                                )
                                              )
                                            : (function (e, t) {
                                                try {
                                                  let r =
                                                    "json" === t &&
                                                    e &&
                                                    "object" == typeof e
                                                      ? JSON.stringify(e)
                                                      : e;
                                                  return ra(r);
                                                } catch (e) {
                                                  return;
                                                }
                                              })(r.response, r.responseType);
                                        void 0 !== i &&
                                          (e.data.request_body_size = i),
                                          void 0 !== s &&
                                            (e.data.response_body_size = s);
                                      })(t, r),
                                      rM(t, r, e)),
                                      "fetch" === t.category &&
                                        (i = r) &&
                                        i.response &&
                                        ((function (e, t) {
                                          let { input: r, response: n } = t,
                                            i = r ? rv(r) : void 0,
                                            s = ra(i),
                                            o = n
                                              ? rl(
                                                  n.headers.get(
                                                    "content-length"
                                                  )
                                                )
                                              : void 0;
                                          void 0 !== s &&
                                            (e.data.request_body_size = s),
                                            void 0 !== o &&
                                              (e.data.response_body_size = o);
                                        })(t, r),
                                        rg(t, r, e));
                                  } catch (e) {}
                              })(a, e, t)
                            );
                        } catch (e) {}
                      })(e);
                    let r = Object.assign(
                      (t, r) => {
                        if (!e.isEnabled() || e.isPaused()) return t;
                        if ("replay_event" === t.type)
                          return delete t.breadcrumbs, t;
                        if (t.type && !rt(t) && !rr(t)) return t;
                        let n = e.checkAndHandleExpiredSession();
                        if (!n) return ri(), t;
                        if (rr(t))
                          return (
                            e.flush(),
                            (t.contexts.feedback.replay_id = e.getSessionId()),
                            e.triggerUserActivity(),
                            e.addUpdate(
                              () =>
                                !t.timestamp ||
                                (e.throttledAddEvent({
                                  type: e9.Custom,
                                  timestamp: 1e3 * t.timestamp,
                                  data: {
                                    tag: "breadcrumb",
                                    payload: {
                                      timestamp: t.timestamp,
                                      type: "default",
                                      category: "sentry.feedback",
                                      data: { feedbackId: t.event_id },
                                    },
                                  },
                                }),
                                !1)
                            ),
                            t
                          );
                        if (
                          !t.type &&
                          t.exception &&
                          t.exception.values &&
                          t.exception.values.length &&
                          r.originalException &&
                          r.originalException.__rrweb__ &&
                          !e.getOptions()._experiments.captureExceptions
                        )
                          return null;
                        let i =
                            "buffer" === e.recordingMode &&
                            t.message !== J &&
                            !!t.exception &&
                            !t.type &&
                            t0(e.getOptions().errorSampleRate),
                          s = i || "session" === e.recordingMode;
                        return (
                          s &&
                            (t.tags = {
                              ...t.tags,
                              replayId: e.getSessionId(),
                            }),
                          t
                        );
                      },
                      { id: "Replay" }
                    );
                    (0, x.Qy)(r),
                      t &&
                        (t.on("beforeSendEvent", (t) => {
                          e.isEnabled() &&
                            !t.type &&
                            (function (e, t) {
                              let r =
                                t.exception &&
                                t.exception.values &&
                                t.exception.values[0] &&
                                t.exception.values[0].value;
                              if (
                                "string" == typeof r &&
                                (r.match(
                                  /(reactjs\.org\/docs\/error-decoder\.html\?invariant=|react\.dev\/errors\/)(418|419|422|423|425)/
                                ) ||
                                  r.match(
                                    /(does not match server-rendered HTML|Hydration failed because)/i
                                  ))
                              ) {
                                let t = tO({
                                  category: "replay.hydrate-error",
                                  data: { url: (0, C.l4)() },
                                });
                                tC(e, t);
                              }
                            })(e, t);
                        }),
                        t.on("afterSendEvent", (t, r) => {
                          if (!e.isEnabled() || (t.type && !rt(t))) return;
                          let n = r && r.statusCode;
                          if (n && !(n < 200) && !(n >= 300)) {
                            if (rt(t)) {
                              (function (e, t) {
                                let r = e.getContext();
                                t.contexts &&
                                  t.contexts.trace &&
                                  t.contexts.trace.trace_id &&
                                  r.traceIds.size < 100 &&
                                  r.traceIds.add(t.contexts.trace.trace_id);
                              })(e, t);
                              return;
                            }
                            (function (e, t) {
                              let r = e.getContext();
                              if (
                                (t.event_id &&
                                  r.errorIds.size < 100 &&
                                  r.errorIds.add(t.event_id),
                                "buffer" !== e.recordingMode ||
                                  !t.tags ||
                                  !t.tags.replayId)
                              )
                                return;
                              let { beforeErrorSampling: n } = e.getOptions();
                              ("function" != typeof n || n(t)) &&
                                (0, $.iK)(async () => {
                                  try {
                                    await e.sendBufferedReplayOrFlush();
                                  } catch (t) {
                                    e.handleException(t);
                                  }
                                });
                            })(e, t);
                          }
                        }),
                        t.on("createDsc", (t) => {
                          let r = e.getSessionId();
                          if (
                            r &&
                            e.isEnabled() &&
                            "session" === e.recordingMode
                          ) {
                            let n = e.checkAndHandleExpiredSession();
                            n && (t.replay_id = r);
                          }
                        }),
                        t.on("spanStart", (t) => {
                          e.lastActiveSpan = t;
                        }),
                        t.on("spanEnd", (t) => {
                          e.lastActiveSpan = t;
                        }),
                        t.on("beforeSendFeedback", (t, r) => {
                          let n = e.getSessionId();
                          r &&
                            r.includeReplay &&
                            e.isEnabled() &&
                            n &&
                            t.contexts &&
                            t.contexts.feedback &&
                            (t.contexts.feedback.replay_id = n);
                        }));
                  })(this),
                  (this._hasInitializedCoreListeners = !0));
            } catch (e) {
              this.handleException(e);
            }
            this._performanceCleanupCallback = (function (e) {
              function t(t) {
                e.performanceEntries.includes(t) ||
                  e.performanceEntries.push(t);
              }
              function r({ entries: e }) {
                e.forEach(t);
              }
              let n = [];
              return (
                ["navigation", "paint", "resource"].forEach((e) => {
                  n.push((0, j._j)(e, r));
                }),
                n.push(
                  (0, j.$A)(tB(tH, e)),
                  (0, j.PR)(tB(t$, e)),
                  (0, j.to)(tB(tj, e)),
                  (0, j.YF)(tB(tV, e))
                ),
                () => {
                  n.forEach((e) => e());
                }
              );
            })(this);
          }
          _removeListeners() {
            try {
              Y.document.removeEventListener(
                "visibilitychange",
                this._handleVisibilityChange
              ),
                Y.removeEventListener("blur", this._handleWindowBlur),
                Y.removeEventListener("focus", this._handleWindowFocus),
                Y.removeEventListener("keydown", this._handleKeyboardEvent),
                this.clickDetector && this.clickDetector.removeListeners(),
                this._performanceCleanupCallback &&
                  this._performanceCleanupCallback();
            } catch (e) {
              this.handleException(e);
            }
          }
          __init() {
            this._handleVisibilityChange = () => {
              "visible" === Y.document.visibilityState
                ? this._doChangeToForegroundTasks()
                : this._doChangeToBackgroundTasks();
            };
          }
          __init2() {
            this._handleWindowBlur = () => {
              let e = tO({ category: "ui.blur" });
              this._doChangeToBackgroundTasks(e);
            };
          }
          __init3() {
            this._handleWindowFocus = () => {
              let e = tO({ category: "ui.focus" });
              this._doChangeToForegroundTasks(e);
            };
          }
          __init4() {
            this._handleKeyboardEvent = (e) => {
              !(function (e, t) {
                if (!e.isEnabled()) return;
                e.updateUserActivity();
                let r = (function (e) {
                  var t;
                  let {
                    metaKey: r,
                    shiftKey: n,
                    ctrlKey: i,
                    altKey: s,
                    key: o,
                    target: a,
                  } = e;
                  if (
                    !a ||
                    "INPUT" === (t = a).tagName ||
                    "TEXTAREA" === t.tagName ||
                    t.isContentEditable ||
                    !o
                  )
                    return null;
                  let l = 1 === o.length;
                  if (!(r || i || s) && l) return null;
                  let c = (0, C.Rt)(a, { maxStringLength: 200 }) || "<unknown>",
                    u = tF(a, c);
                  return tO({
                    category: "ui.keyDown",
                    message: c,
                    data: {
                      ...u.data,
                      metaKey: r,
                      shiftKey: n,
                      ctrlKey: i,
                      altKey: s,
                      key: o,
                    },
                  });
                })(t);
                r && tC(e, r);
              })(this, e);
            };
          }
          _doChangeToBackgroundTasks(e) {
            if (!this.session) return;
            let t = t9(this.session, {
              maxReplayDuration: this._options.maxReplayDuration,
              sessionIdleExpire: this.timeouts.sessionIdleExpire,
            });
            t ||
              (e && this._createCustomBreadcrumb(e), this.conditionalFlush());
          }
          _doChangeToForegroundTasks(e) {
            if (!this.session) return;
            let t = this.checkAndHandleExpiredSession();
            t && e && this._createCustomBreadcrumb(e);
          }
          _updateUserActivity(e = Date.now()) {
            this._lastActivity = e;
          }
          _updateSessionActivity(e = Date.now()) {
            this.session &&
              ((this.session.lastActivity = e), this._maybeSaveSession());
          }
          _createCustomBreadcrumb(e) {
            this.addUpdate(() => {
              this.throttledAddEvent({
                type: e9.Custom,
                timestamp: e.timestamp || 0,
                data: { tag: "breadcrumb", payload: e },
              });
            });
          }
          _addPerformanceEntries() {
            let e = this.performanceEntries
              .map(tz)
              .filter(Boolean)
              .concat(this.replayPerformanceEntries);
            if (
              ((this.performanceEntries = []),
              (this.replayPerformanceEntries = []),
              this._requiresManualStart)
            ) {
              let t = this._context.initialTimestamp / 1e3;
              e = e.filter((e) => e.start >= t);
            }
            return Promise.all(rs(this, e));
          }
          _clearContext() {
            this._context.errorIds.clear(),
              this._context.traceIds.clear(),
              (this._context.urls = []);
          }
          _updateInitialTimestampFromEventBuffer() {
            let { session: e, eventBuffer: t } = this;
            if (!e || !t || this._requiresManualStart || e.segmentId) return;
            let r = t.getEarliestTimestamp();
            r &&
              r < this._context.initialTimestamp &&
              (this._context.initialTimestamp = r);
          }
          _popEventContext() {
            let e = {
              initialTimestamp: this._context.initialTimestamp,
              initialUrl: this._context.initialUrl,
              errorIds: Array.from(this._context.errorIds),
              traceIds: Array.from(this._context.traceIds),
              urls: this._context.urls,
            };
            return this._clearContext(), e;
          }
          async _runFlush() {
            let e = this.getSessionId();
            if (
              this.session &&
              this.eventBuffer &&
              e &&
              (await this._addPerformanceEntries(),
              this.eventBuffer && this.eventBuffer.hasEvents) &&
              (await rC(this), this.eventBuffer && e === this.getSessionId())
            )
              try {
                this._updateInitialTimestampFromEventBuffer();
                let t = Date.now();
                if (
                  t - this._context.initialTimestamp >
                  this._options.maxReplayDuration + 3e4
                )
                  throw Error("Session is too long, not sending replay");
                let r = this._popEventContext(),
                  n = this.session.segmentId++;
                this._maybeSaveSession();
                let i = await this.eventBuffer.finish();
                await rD({
                  replayId: e,
                  recordingData: i,
                  segmentId: n,
                  eventContext: r,
                  session: this.session,
                  timestamp: t,
                  onError: (e) => this.handleException(e),
                });
              } catch (t) {
                this.handleException(t), this.stop({ reason: "sendReplay" });
                let e = (0, D.s3)();
                e &&
                  e.recordDroppedEvent(
                    t instanceof rR ? "ratelimit_backoff" : "send_error",
                    "replay"
                  );
              }
          }
          __init5() {
            this._flush = async ({ force: e = !1 } = {}) => {
              if (
                (!this._isEnabled && !e) ||
                !this.checkAndHandleExpiredSession() ||
                !this.session
              )
                return;
              let t = this.session.started,
                r = Date.now(),
                n = r - t;
              this._debouncedFlush.cancel();
              let i = n < this._options.minReplayDuration,
                s = n > this._options.maxReplayDuration + 5e3;
              if (i || s) {
                i && this._debouncedFlush();
                return;
              }
              let o = this.eventBuffer;
              o && 0 === this.session.segmentId && o.hasCheckout;
              let a = !!this._flushLock;
              this._flushLock || (this._flushLock = this._runFlush());
              try {
                await this._flushLock;
              } catch (e) {
                this.handleException(e);
              } finally {
                (this._flushLock = void 0), a && this._debouncedFlush();
              }
            };
          }
          _maybeSaveSession() {
            this.session && this._options.stickySession && t3(this.session);
          }
          __init6() {
            this._onMutationHandler = (e) => {
              let t = e.length,
                r = this._options.mutationLimit,
                n = this._options.mutationBreadcrumbLimit,
                i = r && t > r;
              if (t > n || i) {
                let e = tO({
                  category: "replay.mutations",
                  data: { count: t, limit: i },
                });
                this._createCustomBreadcrumb(e);
              }
              return (
                !i ||
                (this.stop({
                  reason: "mutationLimit",
                  forceFlush: "session" === this.recordingMode,
                }),
                !1)
              );
            };
          }
        }
        function rO(e, t) {
          return [...e, ...t].join(",");
        }
        let rL =
            'img,image,svg,video,object,picture,embed,map,audio,link[rel="icon"],link[rel="apple-touch-icon"]',
          rP = ["content-length", "content-type", "accept"],
          rF = !1,
          rU = (e) => new rB(e);
        class rB {
          static __initStatic() {
            this.id = "Replay";
          }
          constructor({
            flushMinDelay: e = 5e3,
            flushMaxDelay: t = 5500,
            minReplayDuration: r = 4999,
            maxReplayDuration: n = 36e5,
            stickySession: i = !0,
            useCompression: s = !0,
            workerUrl: o,
            _experiments: a = {},
            maskAllText: l = !0,
            maskAllInputs: c = !0,
            blockAllMedia: u = !0,
            mutationBreadcrumbLimit: d = 750,
            mutationLimit: h = 1e4,
            slowClickTimeout: p = 7e3,
            slowClickIgnoreSelectors: m = [],
            networkDetailAllowUrls: f = [],
            networkDetailDenyUrls: y = [],
            networkCaptureBodies: g = !0,
            networkRequestHeaders: _ = [],
            networkResponseHeaders: S = [],
            mask: b = [],
            maskAttributes: v = ["title", "placeholder"],
            unmask: w = [],
            block: E = [],
            unblock: k = [],
            ignore: M = [],
            maskFn: C,
            beforeAddRecordingEvent: T,
            beforeErrorSampling: I,
            onError: x,
          } = {}) {
            this.name = rB.id;
            let R = (function ({
              mask: e,
              unmask: t,
              block: r,
              unblock: n,
              ignore: i,
            }) {
              let s = rO(e, [".sentry-mask", "[data-sentry-mask]"]),
                o = rO(t, []),
                a = {
                  maskTextSelector: s,
                  unmaskTextSelector: o,
                  blockSelector: rO(r, [
                    ".sentry-block",
                    "[data-sentry-block]",
                    'base[href="/"]',
                  ]),
                  unblockSelector: rO(n, []),
                  ignoreSelector: rO(i, [
                    ".sentry-ignore",
                    "[data-sentry-ignore]",
                    'input[type="file"]',
                  ]),
                };
              return a;
            })({ mask: b, unmask: w, block: E, unblock: k, ignore: M });
            if (
              ((this._recordingOptions = {
                maskAllInputs: c,
                maskAllText: l,
                maskInputOptions: { password: !0 },
                maskTextFn: C,
                maskInputFn: C,
                maskAttributeFn: (e, t, r) =>
                  (function ({
                    el: e,
                    key: t,
                    maskAttributes: r,
                    maskAllText: n,
                    privacyOptions: i,
                    value: s,
                  }) {
                    return !n ||
                      (i.unmaskTextSelector && e.matches(i.unmaskTextSelector))
                      ? s
                      : r.includes(t) ||
                        ("value" === t &&
                          "INPUT" === e.tagName &&
                          ["submit", "button"].includes(
                            e.getAttribute("type") || ""
                          ))
                      ? s.replace(/[\S]/g, "*")
                      : s;
                  })({
                    maskAttributes: v,
                    maskAllText: l,
                    privacyOptions: R,
                    key: e,
                    value: t,
                    el: r,
                  }),
                ...R,
                slimDOMOptions: "all",
                inlineStylesheet: !0,
                inlineImages: !1,
                collectFonts: !0,
                errorHandler: (e) => {
                  try {
                    e.__rrweb__ = !0;
                  } catch (e) {}
                },
              }),
              (this._initialOptions = {
                flushMinDelay: e,
                flushMaxDelay: t,
                minReplayDuration: Math.min(r, 15e3),
                maxReplayDuration: Math.min(n, 36e5),
                stickySession: i,
                useCompression: s,
                workerUrl: o,
                blockAllMedia: u,
                maskAllInputs: c,
                maskAllText: l,
                mutationBreadcrumbLimit: d,
                mutationLimit: h,
                slowClickTimeout: p,
                slowClickIgnoreSelectors: m,
                networkDetailAllowUrls: f,
                networkDetailDenyUrls: y,
                networkCaptureBodies: g,
                networkRequestHeaders: rz(_),
                networkResponseHeaders: rz(S),
                beforeAddRecordingEvent: T,
                beforeErrorSampling: I,
                onError: x,
                _experiments: a,
              }),
              this._initialOptions.blockAllMedia &&
                (this._recordingOptions.blockSelector = this._recordingOptions
                  .blockSelector
                  ? `${this._recordingOptions.blockSelector},${rL}`
                  : rL),
              this._isInitialized && (0, W.j)())
            )
              throw Error(
                "Multiple Sentry Session Replay instances are not supported"
              );
            this._isInitialized = !0;
          }
          get _isInitialized() {
            return rF;
          }
          set _isInitialized(e) {
            rF = e;
          }
          afterAllSetup(e) {
            (0, W.j)() &&
              !this._replay &&
              (this._setup(e), this._initialize(e));
          }
          start() {
            this._replay && this._replay.start();
          }
          startBuffering() {
            this._replay && this._replay.startBuffering();
          }
          stop() {
            return this._replay
              ? this._replay.stop({
                  forceFlush: "session" === this._replay.recordingMode,
                })
              : Promise.resolve();
          }
          flush(e) {
            return this._replay
              ? this._replay.isEnabled()
                ? this._replay.sendBufferedReplayOrFlush(e)
                : (this._replay.start(), Promise.resolve())
              : Promise.resolve();
          }
          getReplayId() {
            if (this._replay && this._replay.isEnabled())
              return this._replay.getSessionId();
          }
          getRecordingMode() {
            if (this._replay && this._replay.isEnabled())
              return this._replay.recordingMode;
          }
          _initialize(e) {
            this._replay &&
              (this._maybeLoadFromReplayCanvasIntegration(e),
              this._replay.initializeSampling());
          }
          _setup(e) {
            let t = (function (e, t) {
              let r = t.getOptions(),
                n = {
                  sessionSampleRate: 0,
                  errorSampleRate: 0,
                  ...(0, M.Jr)(e),
                },
                i = (0, H.o)(r.replaysSessionSampleRate),
                s = (0, H.o)(r.replaysOnErrorSampleRate);
              return (
                null == i &&
                  null == s &&
                  (0, I.Cf)(() => {
                    console.warn(
                      "Replay is disabled because neither `replaysSessionSampleRate` nor `replaysOnErrorSampleRate` are set."
                    );
                  }),
                null != i && (n.sessionSampleRate = i),
                null != s && (n.errorSampleRate = s),
                n
              );
            })(this._initialOptions, e);
            this._replay = new rN({
              options: t,
              recordingOptions: this._recordingOptions,
            });
          }
          _maybeLoadFromReplayCanvasIntegration(e) {
            try {
              let t = e.getIntegrationByName("ReplayCanvas");
              if (!t) return;
              this._replay._canvas = t.getOptions();
            } catch (e) {}
          }
        }
        function rz(e) {
          return [...rP, ...e.map((e) => e.toLowerCase())];
        }
        function rW() {
          let e = (0, D.s3)();
          return e && e.getIntegrationByName("Replay");
        }
        rB.__initStatic();
      },
    },
  ]);
