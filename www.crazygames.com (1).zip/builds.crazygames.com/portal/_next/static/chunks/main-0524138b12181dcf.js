!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "ed8bb45d-25cb-4bc1-9887-e8312ab01556"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-ed8bb45d-25cb-4bc1-9887-e8312ab01556"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [40179],
    {
      60932: function (e, t) {
        "use strict";
        function r(e, t, r, n, a, o, i) {
          try {
            var l = e[o](i),
              s = l.value;
          } catch (e) {
            r(e);
            return;
          }
          l.done ? t(s) : Promise.resolve(s).then(n, a);
        }
        function n(e) {
          return function () {
            var t = this,
              n = arguments;
            return new Promise(function (a, o) {
              var i = e.apply(t, n);
              function l(e) {
                r(i, a, o, l, s, "next", e);
              }
              function s(e) {
                r(i, a, o, l, s, "throw", e);
              }
              l(void 0);
            });
          };
        }
        Object.defineProperty(t, "Z", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      },
      6495: function (e, t) {
        "use strict";
        function r() {
          return (r =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r)
                  Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
              }
              return e;
            }).apply(this, arguments);
        }
        function n() {
          return r.apply(this, arguments);
        }
        Object.defineProperty(t, "Z", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      },
      92648: function (e, t) {
        "use strict";
        function r(e) {
          return e && e.__esModule ? e : { default: e };
        }
        Object.defineProperty(t, "Z", {
          enumerable: !0,
          get: function () {
            return r;
          },
        });
      },
      91598: function (e, t) {
        "use strict";
        function r(e) {
          if ("function" != typeof WeakMap) return null;
          var t = new WeakMap(),
            n = new WeakMap();
          return (r = function (e) {
            return e ? n : t;
          })(e);
        }
        function n(e, t) {
          if (!t && e && e.__esModule) return e;
          if (null === e || ("object" != typeof e && "function" != typeof e))
            return { default: e };
          var n = r(t);
          if (n && n.has(e)) return n.get(e);
          var a = {},
            o = Object.defineProperty && Object.getOwnPropertyDescriptor;
          for (var i in e)
            if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
              var l = o ? Object.getOwnPropertyDescriptor(e, i) : null;
              l && (l.get || l.set)
                ? Object.defineProperty(a, i, l)
                : (a[i] = e[i]);
            }
          return (a.default = e), n && n.set(e, a), a;
        }
        Object.defineProperty(t, "Z", {
          enumerable: !0,
          get: function () {
            return n;
          },
        });
      },
      17273: function (e, t) {
        "use strict";
        function r(e, t) {
          if (null == e) return {};
          var r,
            n,
            a = {},
            o = Object.keys(e);
          for (n = 0; n < o.length; n++)
            (r = o[n]), t.indexOf(r) >= 0 || (a[r] = e[r]);
          return a;
        }
        Object.defineProperty(t, "Z", {
          enumerable: !0,
          get: function () {
            return r;
          },
        });
      },
      40037: function () {
        "trimStart" in String.prototype ||
          (String.prototype.trimStart = String.prototype.trimLeft),
          "trimEnd" in String.prototype ||
            (String.prototype.trimEnd = String.prototype.trimRight),
          "description" in Symbol.prototype ||
            Object.defineProperty(Symbol.prototype, "description", {
              configurable: !0,
              get: function () {
                var e = /\((.*)\)/.exec(this.toString());
                return e ? e[1] : void 0;
              },
            }),
          Array.prototype.flat ||
            ((Array.prototype.flat = function (e, t) {
              return (
                (t = this.concat.apply([], this)),
                e > 1 && t.some(Array.isArray) ? t.flat(e - 1) : t
              );
            }),
            (Array.prototype.flatMap = function (e, t) {
              return this.map(e, t).flat();
            })),
          Promise.prototype.finally ||
            (Promise.prototype.finally = function (e) {
              if ("function" != typeof e) return this.then(e, e);
              var t = this.constructor || Promise;
              return this.then(
                function (r) {
                  return t.resolve(e()).then(function () {
                    return r;
                  });
                },
                function (r) {
                  return t.resolve(e()).then(function () {
                    throw r;
                  });
                }
              );
            }),
          Object.fromEntries ||
            (Object.fromEntries = function (e) {
              return Array.from(e).reduce(function (e, t) {
                return (e[t[0]] = t[1]), e;
              }, {});
            });
      },
      64266: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.addBasePath = function (e, t) {
            return a.normalizePathTrailingSlash(n.addPathPrefix(e, ""));
          });
        var n = r(5246),
          a = r(82387);
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      370: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.addLocale = void 0);
        var n = r(82387);
        (t.addLocale = function (e) {
          for (
            var t = arguments.length, a = Array(t > 1 ? t - 1 : 0), o = 1;
            o < t;
            o++
          )
            a[o - 1] = arguments[o];
          return n.normalizePathTrailingSlash(r(62721).addLocale(e, ...a));
        }),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      2249: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.detectDomainLocale = void 0),
          (t.detectDomainLocale = function () {
            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++)
              t[n] = arguments[n];
            return r(18391).detectDomainLocale(...t);
          }),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      12140: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.hasBasePath = function (e) {
            return n.pathHasPrefix(e, "");
          });
        var n = r(76325);
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      19623: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function () {
            return {
              mountedInstances: new Set(),
              updateHead: (e) => {
                let t = {};
                e.forEach((e) => {
                  if ("link" === e.type && e.props["data-optimized-fonts"]) {
                    if (
                      document.querySelector(
                        `style[data-href="${e.props["data-href"]}"]`
                      )
                    )
                      return;
                    (e.props.href = e.props["data-href"]),
                      (e.props["data-href"] = void 0);
                  }
                  let r = t[e.type] || [];
                  r.push(e), (t[e.type] = r);
                });
                let r = t.title ? t.title[0] : null,
                  o = "";
                if (r) {
                  let { children: e } = r.props;
                  o =
                    "string" == typeof e
                      ? e
                      : Array.isArray(e)
                      ? e.join("")
                      : "";
                }
                o !== document.title && (document.title = o),
                  ["meta", "base", "link", "style", "script"].forEach((e) => {
                    (function (e, t) {
                      let r = document.getElementsByTagName("head")[0],
                        o = r.querySelector("meta[name=next-head-count]"),
                        i = Number(o.content),
                        l = [];
                      for (
                        let t = 0, r = o.previousElementSibling;
                        t < i;
                        t++,
                          r =
                            (null == r ? void 0 : r.previousElementSibling) ||
                            null
                      ) {
                        var s;
                        (null == r
                          ? void 0
                          : null == (s = r.tagName)
                          ? void 0
                          : s.toLowerCase()) === e && l.push(r);
                      }
                      let u = t.map(n).filter((e) => {
                        for (let t = 0, r = l.length; t < r; t++) {
                          let r = l[t];
                          if (a(r, e)) return l.splice(t, 1), !1;
                        }
                        return !0;
                      });
                      l.forEach((e) => {
                        var t;
                        return null == (t = e.parentNode)
                          ? void 0
                          : t.removeChild(e);
                      }),
                        u.forEach((e) => r.insertBefore(e, o)),
                        (o.content = (i - l.length + u.length).toString());
                    })(e, t[e] || []);
                  });
              },
            };
          }),
          (t.isEqualNode = a),
          (t.DOMAttributeNames = void 0);
        let r = {
          acceptCharset: "accept-charset",
          className: "class",
          htmlFor: "for",
          httpEquiv: "http-equiv",
          noModule: "noModule",
        };
        function n(e) {
          let { type: t, props: n } = e,
            a = document.createElement(t);
          for (let e in n) {
            if (
              !n.hasOwnProperty(e) ||
              "children" === e ||
              "dangerouslySetInnerHTML" === e ||
              void 0 === n[e]
            )
              continue;
            let o = r[e] || e.toLowerCase();
            "script" === t &&
            ("async" === o || "defer" === o || "noModule" === o)
              ? (a[o] = !!n[e])
              : a.setAttribute(o, n[e]);
          }
          let { children: o, dangerouslySetInnerHTML: i } = n;
          return (
            i
              ? (a.innerHTML = i.__html || "")
              : o &&
                (a.textContent =
                  "string" == typeof o
                    ? o
                    : Array.isArray(o)
                    ? o.join("")
                    : ""),
            a
          );
        }
        function a(e, t) {
          if (e instanceof HTMLElement && t instanceof HTMLElement) {
            let r = t.getAttribute("nonce");
            if (r && !e.getAttribute("nonce")) {
              let n = t.cloneNode(!0);
              return (
                n.setAttribute("nonce", ""),
                (n.nonce = r),
                r === e.nonce && e.isEqualNode(n)
              );
            }
          }
          return e.isEqualNode(t);
        }
        (t.DOMAttributeNames = r),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      15274: function (e, t, r) {
        "use strict";
        let n, a, o, i, l, s, u, c, d, f, p, h;
        Object.defineProperty(t, "__esModule", { value: !0 });
        let m = r(91598).Z;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.initialize = function () {
            return G.apply(this, arguments);
          }),
          (t.hydrate = function (e) {
            return es.apply(this, arguments);
          }),
          (t.emitter = t.router = t.version = void 0);
        var g = r(60932).Z,
          y = r(6495).Z,
          v = r(92648).Z;
        r(91598).Z, r(40037);
        var _ = v(r(67294)),
          b = v(r(20745)),
          P = r(79958),
          S = v(r(96595)),
          w = r(69955),
          E = r(3105),
          C = r(63162),
          x = r(53908),
          j = r(7905),
          O = r(79064),
          M = r(73232),
          L = v(r(19623)),
          R = v(r(29030)),
          T = v(r(35108)),
          A = r(42827),
          I = r(96885),
          N = r(80676),
          k = r(83341),
          $ = r(39577),
          D = r(12140),
          B = r(24224),
          F = r(29486),
          U = r(78463),
          H = v(r(24225));
        (t.version = "13.2.4"), (t.router = n);
        let q = S.default();
        t.emitter = q;
        let W = (e) => [].slice.call(e),
          Z = !1;
        self.__next_require__ = r;
        class z extends _.default.Component {
          componentDidCatch(e, t) {
            this.props.fn(e, t);
          }
          componentDidMount() {
            this.scrollToHash(),
              n.isSsr &&
                (a.isFallback ||
                  (a.nextExport &&
                    (C.isDynamicRoute(n.pathname) || location.search || Z)) ||
                  (a.props && a.props.__N_SSG && (location.search || Z))) &&
                n
                  .replace(
                    n.pathname +
                      "?" +
                      String(
                        x.assign(
                          x.urlQueryToSearchParams(n.query),
                          new URLSearchParams(location.search)
                        )
                      ),
                    o,
                    { _h: 1, shallow: !a.isFallback && !Z }
                  )
                  .catch((e) => {
                    if (!e.cancelled) throw e;
                  });
          }
          componentDidUpdate() {
            this.scrollToHash();
          }
          scrollToHash() {
            let { hash: e } = location;
            if (!(e = e && e.substring(1))) return;
            let t = document.getElementById(e);
            t && setTimeout(() => t.scrollIntoView(), 0);
          }
          render() {
            return this.props.children;
          }
        }
        function G() {
          return (G = g(function* () {
            arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
              (a = JSON.parse(
                document.getElementById("__NEXT_DATA__").textContent
              )),
              (window.__NEXT_DATA__ = a),
              (h = a.defaultLocale);
            let e = a.assetPrefix || "";
            (r.p = `${e}/_next/`),
              j.setConfig({
                serverRuntimeConfig: {},
                publicRuntimeConfig: a.runtimeConfig || {},
              }),
              (o = O.getURL()),
              D.hasBasePath(o) && (o = $.removeBasePath(o));
            {
              let { normalizeLocalePath: e } = r(34842),
                { detectDomainLocale: t } = r(18391),
                { parseRelativeUrl: n } = r(73460),
                { formatUrl: i } = r(61410);
              if (a.locales) {
                let r = n(o),
                  l = e(r.pathname, a.locales);
                l.detectedLocale
                  ? ((r.pathname = l.pathname), (o = i(r)))
                  : (h = a.locale);
                let s = t(void 0, window.location.hostname);
                s && (h = s.defaultLocale);
              }
            }
            if (a.scriptLoader) {
              let { initScriptLoader: e } = r(85442);
              e(a.scriptLoader);
            }
            i = new R.default(a.buildId, e);
            let t = (e) => {
              let [t, r] = e;
              return i.routeLoader.onEntrypoint(t, r);
            };
            return (
              window.__NEXT_P &&
                window.__NEXT_P.map((e) => setTimeout(() => t(e), 0)),
              (window.__NEXT_P = []),
              (window.__NEXT_P.push = t),
              ((s = L.default()).getIsSsr = () => n.isSsr),
              (l = document.getElementById("__next")),
              { assetPrefix: e }
            );
          })).apply(this, arguments);
        }
        function V(e, t) {
          return _.default.createElement(e, Object.assign({}, t));
        }
        function X(e) {
          var t;
          let { children: r } = e;
          return _.default.createElement(
            z,
            {
              fn: (e) =>
                J({ App: d, err: e }).catch((e) =>
                  console.error("Error rendering page: ", e)
                ),
            },
            _.default.createElement(
              B.AppRouterContext.Provider,
              { value: F.adaptForAppRouterInstance(n) },
              _.default.createElement(
                U.SearchParamsContext.Provider,
                { value: F.adaptForSearchParams(n) },
                _.default.createElement(
                  F.PathnameContextProviderAdapter,
                  {
                    router: n,
                    isAutoExport:
                      null != (t = self.__NEXT_DATA__.autoExport) && t,
                  },
                  _.default.createElement(
                    w.RouterContext.Provider,
                    { value: I.makePublicRouterInstance(n) },
                    _.default.createElement(
                      P.HeadManagerContext.Provider,
                      { value: s },
                      _.default.createElement(
                        k.ImageConfigContext.Provider,
                        {
                          value: {
                            deviceSizes: [
                              640, 750, 828, 1080, 1200, 1920, 2048, 3840,
                            ],
                            imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                            path: "/_next/image",
                            loader: "default",
                            dangerouslyAllowSVG: !1,
                            unoptimized: !1,
                          },
                        },
                        r
                      )
                    )
                  )
                )
              )
            )
          );
        }
        let Y = (e) => (t) => {
          let r = y({}, t, { Component: p, err: a.err, router: n });
          return _.default.createElement(X, null, V(e, r));
        };
        function J(e) {
          let { App: t, err: l } = e;
          return (
            console.error(l),
            console.error(
              "A client-side exception has occurred, see here for more info: https://nextjs.org/docs/messages/client-side-exception-occurred"
            ),
            i
              .loadPage("/_error")
              .then((n) => {
                let { page: a, styleSheets: o } = n;
                return (null == u ? void 0 : u.Component) === a
                  ? Promise.resolve()
                      .then(() => m(r(43499)))
                      .then((n) =>
                        Promise.resolve()
                          .then(() => m(r(65035)))
                          .then((r) => ((t = r.default), (e.App = t), n))
                      )
                      .then((e) => ({
                        ErrorComponent: e.default,
                        styleSheets: [],
                      }))
                  : { ErrorComponent: a, styleSheets: o };
              })
              .then((r) => {
                var i;
                let { ErrorComponent: s, styleSheets: u } = r,
                  c = Y(t),
                  d = {
                    Component: s,
                    AppTree: c,
                    router: n,
                    ctx: {
                      err: l,
                      pathname: a.page,
                      query: a.query,
                      asPath: o,
                      AppTree: c,
                    },
                  };
                return Promise.resolve(
                  (null == (i = e.props) ? void 0 : i.err)
                    ? e.props
                    : O.loadGetInitialProps(t, d)
                ).then((t) =>
                  eo(
                    y({}, e, { err: l, Component: s, styleSheets: u, props: t })
                  )
                );
              })
          );
        }
        function K(e) {
          let { callback: t } = e;
          return _.default.useLayoutEffect(() => t(), [t]), null;
        }
        let Q = null,
          ee = !0;
        function et() {
          [
            "beforeRender",
            "afterHydrate",
            "afterRender",
            "routeChange",
          ].forEach((e) => performance.clearMarks(e));
        }
        function er() {
          O.ST &&
            (performance.mark("afterHydrate"),
            performance.measure(
              "Next.js-before-hydration",
              "navigationStart",
              "beforeRender"
            ),
            performance.measure(
              "Next.js-hydration",
              "beforeRender",
              "afterHydrate"
            ),
            f && performance.getEntriesByName("Next.js-hydration").forEach(f),
            et());
        }
        function en() {
          if (!O.ST) return;
          performance.mark("afterRender");
          let e = performance.getEntriesByName("routeChange", "mark");
          e.length &&
            (performance.measure(
              "Next.js-route-change-to-render",
              e[0].name,
              "beforeRender"
            ),
            performance.measure(
              "Next.js-render",
              "beforeRender",
              "afterRender"
            ),
            f &&
              (performance.getEntriesByName("Next.js-render").forEach(f),
              performance
                .getEntriesByName("Next.js-route-change-to-render")
                .forEach(f)),
            et(),
            ["Next.js-route-change-to-render", "Next.js-render"].forEach((e) =>
              performance.clearMeasures(e)
            ));
        }
        function ea(e) {
          let { callbacks: t, children: r } = e;
          return (
            _.default.useLayoutEffect(() => t.forEach((e) => e()), [t]),
            _.default.useEffect(() => {
              T.default(f);
            }, []),
            r
          );
        }
        function eo(e) {
          let t,
            { App: r, Component: a, props: o, err: i } = e,
            s = "initial" in e ? void 0 : e.styleSheets;
          (a = a || u.Component), (o = o || u.props);
          let d = y({}, o, { Component: a, err: i, router: n });
          u = d;
          let f = !1,
            p = new Promise((e, r) => {
              c && c(),
                (t = () => {
                  (c = null), e();
                }),
                (c = () => {
                  (f = !0), (c = null);
                  let e = Error("Cancel rendering route");
                  (e.cancelled = !0), r(e);
                });
            });
          function h() {
            t();
          }
          !(function () {
            if (!s) return;
            let e = W(document.querySelectorAll("style[data-n-href]")),
              t = new Set(e.map((e) => e.getAttribute("data-n-href"))),
              r = document.querySelector("noscript[data-n-css]"),
              n = null == r ? void 0 : r.getAttribute("data-n-css");
            s.forEach((e) => {
              let { href: r, text: a } = e;
              if (!t.has(r)) {
                let e = document.createElement("style");
                e.setAttribute("data-n-href", r),
                  e.setAttribute("media", "x"),
                  n && e.setAttribute("nonce", n),
                  document.head.appendChild(e),
                  e.appendChild(document.createTextNode(a));
              }
            });
          })();
          let m = _.default.createElement(
            _.default.Fragment,
            null,
            _.default.createElement(K, {
              callback: function () {
                if (s && !f) {
                  let e = new Set(s.map((e) => e.href)),
                    t = W(document.querySelectorAll("style[data-n-href]")),
                    r = t.map((e) => e.getAttribute("data-n-href"));
                  for (let n = 0; n < r.length; ++n)
                    e.has(r[n])
                      ? t[n].removeAttribute("media")
                      : t[n].setAttribute("media", "x");
                  let n = document.querySelector("noscript[data-n-css]");
                  n &&
                    s.forEach((e) => {
                      let { href: t } = e,
                        r = document.querySelector(`style[data-n-href="${t}"]`);
                      r &&
                        (n.parentNode.insertBefore(r, n.nextSibling), (n = r));
                    }),
                    W(document.querySelectorAll("link[data-n-p]")).forEach(
                      (e) => {
                        e.parentNode.removeChild(e);
                      }
                    );
                }
                if (e.scroll) {
                  let { x: t, y: r } = e.scroll;
                  E.handleSmoothScroll(() => {
                    window.scrollTo(t, r);
                  });
                }
              },
            }),
            _.default.createElement(
              X,
              null,
              V(r, d),
              _.default.createElement(
                M.Portal,
                { type: "next-route-announcer" },
                _.default.createElement(A.RouteAnnouncer, null)
              )
            )
          );
          return (
            (function (e, t) {
              O.ST && performance.mark("beforeRender");
              let r = t(ee ? er : en);
              if (Q) {
                let e = _.default.startTransition;
                e(() => {
                  Q.render(r);
                });
              } else
                (Q = b.default.hydrateRoot(e, r, {
                  onRecoverableError: H.default,
                })),
                  (ee = !1);
            })(l, (e) => _.default.createElement(ea, { callbacks: [e, h] }, m)),
            p
          );
        }
        function ei(e) {
          return el.apply(this, arguments);
        }
        function el() {
          return (el = g(function* (e) {
            if (e.err) {
              yield J(e);
              return;
            }
            try {
              yield eo(e);
            } catch (r) {
              let t = N.getProperError(r);
              if (t.cancelled) throw t;
              yield J(y({}, e, { err: t }));
            }
          })).apply(this, arguments);
        }
        function es() {
          return (es = g(function* (e) {
            let r = a.err;
            try {
              let e = yield i.routeLoader.whenEntrypoint("/_app");
              if ("error" in e) throw e.error;
              let { component: t, exports: r } = e;
              (d = t),
                r &&
                  r.reportWebVitals &&
                  (f = (e) => {
                    let t,
                      {
                        id: n,
                        name: a,
                        startTime: o,
                        value: i,
                        duration: l,
                        entryType: s,
                        entries: u,
                        attribution: c,
                      } = e,
                      d = `${Date.now()}-${
                        Math.floor(Math.random() * (9e12 - 1)) + 1e12
                      }`;
                    u && u.length && (t = u[0].startTime);
                    let f = {
                      id: n || d,
                      name: a,
                      startTime: o || t,
                      value: null == i ? l : i,
                      label:
                        "mark" === s || "measure" === s
                          ? "custom"
                          : "web-vital",
                    };
                    c && (f.attribution = c), r.reportWebVitals(f);
                  });
              let n = yield i.routeLoader.whenEntrypoint(a.page);
              if ("error" in n) throw n.error;
              p = n.component;
            } catch (e) {
              r = N.getProperError(e);
            }
            window.__NEXT_PRELOADREADY &&
              (yield window.__NEXT_PRELOADREADY(a.dynamicIds)),
              (t.router = n =
                I.createRouter(a.page, a.query, o, {
                  initialProps: a.props,
                  pageLoader: i,
                  App: d,
                  Component: p,
                  wrapApp: Y,
                  err: r,
                  isFallback: Boolean(a.isFallback),
                  subscription: (e, t, r) =>
                    ei(Object.assign({}, e, { App: t, scroll: r })),
                  locale: a.locale,
                  locales: a.locales,
                  defaultLocale: h,
                  domainLocales: a.domainLocales,
                  isPreview: a.isPreview,
                })),
              (Z = yield n._initialMatchesMiddlewarePromise);
            let l = {
              App: d,
              initial: !0,
              Component: p,
              props: a.props,
              err: r,
            };
            (null == e ? void 0 : e.beforeRender) && (yield e.beforeRender()),
              ei(l);
          })).apply(this, arguments);
        }
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      14642: function (e, t, r) {
        "use strict";
        var n = r(15274);
        (window.next = {
          version: n.version,
          get router() {
            return n.router;
          },
          emitter: n.emitter,
        }),
          n
            .initialize({})
            .then(() => n.hydrate())
            .catch(console.error),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      82387: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.normalizePathTrailingSlash = void 0);
        var n = r(67734),
          a = r(64046);
        let o = (e) => {
          if (!e.startsWith("/")) return e;
          let { pathname: t, query: r, hash: o } = a.parsePath(e);
          return `${n.removeTrailingSlash(t)}${r}${o}`;
        };
        (t.normalizePathTrailingSlash = o),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      24225: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function (e, t) {
            let r = e.digest || t.digest,
              a =
                "function" == typeof reportError
                  ? reportError
                  : (e) => {
                      window.console.error(e);
                    };
            r !== n.NEXT_DYNAMIC_NO_SSR_CODE && a(e);
          });
        var n = r(54149);
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      29030: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var n = r(92648).Z,
          a = r(64266),
          o = r(35036),
          i = n(r(9184)),
          l = r(370),
          s = r(63162),
          u = r(73460),
          c = r(67734),
          d = r(95564);
        (t.default = class {
          getPageList() {
            return d.getClientBuildManifest().then((e) => e.sortedPages);
          }
          getMiddleware() {
            return (
              (window.__MIDDLEWARE_MATCHERS = []), window.__MIDDLEWARE_MATCHERS
            );
          }
          getDataHref(e) {
            let { asPath: t, href: r, locale: n } = e,
              { pathname: d, query: f, search: p } = u.parseRelativeUrl(r),
              { pathname: h } = u.parseRelativeUrl(t),
              m = c.removeTrailingSlash(d);
            if ("/" !== m[0])
              throw Error(`Route name should start with a "/", got "${m}"`);
            return ((e) => {
              let t = i.default(
                c.removeTrailingSlash(l.addLocale(e, n)),
                ".json"
              );
              return a.addBasePath(`/_next/data/${this.buildId}${t}${p}`, !0);
            })(
              e.skipInterpolation
                ? h
                : s.isDynamicRoute(m)
                ? o.interpolateAs(d, h, f).result
                : m
            );
          }
          _isSsg(e) {
            return this.promisedSsgManifest.then((t) => t.has(e));
          }
          loadPage(e) {
            return this.routeLoader.loadRoute(e).then((e) => {
              if ("component" in e)
                return {
                  page: e.component,
                  mod: e.exports,
                  styleSheets: e.styles.map((e) => ({
                    href: e.href,
                    text: e.content,
                  })),
                };
              throw e.error;
            });
          }
          prefetch(e) {
            return this.routeLoader.prefetch(e);
          }
          constructor(e, t) {
            (this.routeLoader = d.createRouteLoader(t)),
              (this.buildId = e),
              (this.assetPrefix = t),
              (this.promisedSsgManifest = new Promise((e) => {
                window.__SSG_MANIFEST
                  ? e(window.__SSG_MANIFEST)
                  : (window.__SSG_MANIFEST_CB = () => {
                      e(window.__SSG_MANIFEST);
                    });
              }));
          }
        }),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      35108: function (e, t, r) {
        "use strict";
        let n;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        let a = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
        location.href;
        let o = !1;
        function i(e) {
          n && n(e);
        }
        var l = (e) => {
          if (((n = e), o)) return;
          o = !0;
          let t = ["FID", "LCP", "CLS", "INP"];
          for (let e of a)
            try {
              let n;
              (null == t ? void 0 : t.includes(e)) && (n = r(59917)),
                n || (n = r(78018)),
                n[`on${e}`](i);
            } catch (t) {
              console.warn(`Failed to track ${e} web-vital`, t);
            }
        };
        (t.default = l),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      73232: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.Portal = void 0);
        var n = r(67294),
          a = r(73935);
        let o = (e) => {
          let { children: t, type: r } = e,
            [o, i] = n.useState(null);
          return (
            n.useEffect(() => {
              let e = document.createElement(r);
              return (
                document.body.appendChild(e),
                i(e),
                () => {
                  document.body.removeChild(e);
                }
              );
            }, [r]),
            o ? a.createPortal(t, o) : null
          );
        };
        (t.Portal = o),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      39577: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.removeBasePath = function (e) {
            return (e = e.slice(0)).startsWith("/") || (e = `/${e}`), e;
          }),
          r(12140),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      52080: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.removeLocale = function (e, t) {
            {
              let { pathname: r } = n.parsePath(e),
                a = r.toLowerCase(),
                o = null == t ? void 0 : t.toLowerCase();
              return t && (a.startsWith(`/${o}/`) || a === `/${o}`)
                ? `${r.length === t.length + 1 ? "/" : ""}${e.slice(
                    t.length + 1
                  )}`
                : e;
            }
          });
        var n = r(64046);
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      10029: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.cancelIdleCallback = t.requestIdleCallback = void 0);
        let r =
          ("undefined" != typeof self &&
            self.requestIdleCallback &&
            self.requestIdleCallback.bind(window)) ||
          function (e) {
            let t = Date.now();
            return self.setTimeout(function () {
              e({
                didTimeout: !1,
                timeRemaining: function () {
                  return Math.max(0, 50 - (Date.now() - t));
                },
              });
            }, 1);
          };
        t.requestIdleCallback = r;
        let n =
          ("undefined" != typeof self &&
            self.cancelIdleCallback &&
            self.cancelIdleCallback.bind(window)) ||
          function (e) {
            return clearTimeout(e);
          };
        (t.cancelIdleCallback = n),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      42827: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = t.RouteAnnouncer = void 0);
        var n = (0, r(92648).Z)(r(67294)),
          a = r(96885);
        let o = {
            border: 0,
            clip: "rect(0 0 0 0)",
            height: "1px",
            margin: "-1px",
            overflow: "hidden",
            padding: 0,
            position: "absolute",
            width: "1px",
            whiteSpace: "nowrap",
            wordWrap: "normal",
          },
          i = () => {
            let { asPath: e } = a.useRouter(),
              [t, r] = n.default.useState(""),
              i = n.default.useRef(e);
            return (
              n.default.useEffect(() => {
                if (i.current !== e) {
                  if (((i.current = e), document.title)) r(document.title);
                  else {
                    var t;
                    let n = document.querySelector("h1"),
                      a =
                        null != (t = null == n ? void 0 : n.innerText)
                          ? t
                          : null == n
                          ? void 0
                          : n.textContent;
                    r(a || e);
                  }
                }
              }, [e]),
              n.default.createElement(
                "p",
                {
                  "aria-live": "assertive",
                  id: "__next-route-announcer__",
                  role: "alert",
                  style: o,
                },
                t
              )
            );
          };
        (t.RouteAnnouncer = i),
          (t.default = i),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      95564: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.markAssetError = l),
          (t.isAssetError = function (e) {
            return e && i in e;
          }),
          (t.getClientBuildManifest = c),
          (t.createRouteLoader = function (e) {
            let t = new Map(),
              r = new Map(),
              n = new Map(),
              i = new Map();
            function c(e) {
              {
                var t;
                let n = r.get(e.toString());
                return (
                  n ||
                  (document.querySelector(`script[src^="${e}"]`)
                    ? Promise.resolve()
                    : (r.set(
                        e.toString(),
                        (n = new Promise((r, n) => {
                          ((t = document.createElement("script")).onload = r),
                            (t.onerror = () =>
                              n(l(Error(`Failed to load script: ${e}`)))),
                            (t.crossOrigin = "anonymous"),
                            (t.src = e),
                            document.body.appendChild(t);
                        }))
                      ),
                      n))
                );
              }
            }
            function f(e) {
              let t = n.get(e);
              return (
                t ||
                  n.set(
                    e,
                    (t = fetch(e)
                      .then((t) => {
                        if (!t.ok)
                          throw Error(`Failed to load stylesheet: ${e}`);
                        return t.text().then((t) => ({ href: e, content: t }));
                      })
                      .catch((e) => {
                        throw l(e);
                      }))
                  ),
                t
              );
            }
            return {
              whenEntrypoint: (e) => o(e, t),
              onEntrypoint(e, r) {
                (r
                  ? Promise.resolve()
                      .then(() => r())
                      .then(
                        (e) => ({
                          component: (e && e.default) || e,
                          exports: e,
                        }),
                        (e) => ({ error: e })
                      )
                  : Promise.resolve(void 0)
                ).then((r) => {
                  let n = t.get(e);
                  n && "resolve" in n
                    ? r && (t.set(e, r), n.resolve(r))
                    : (r ? t.set(e, r) : t.delete(e), i.delete(e));
                });
              },
              loadRoute(r, n) {
                return o(r, i, () => {
                  let a;
                  return u(
                    d(e, r)
                      .then((e) => {
                        let { scripts: n, css: a } = e;
                        return Promise.all([
                          t.has(r) ? [] : Promise.all(n.map(c)),
                          Promise.all(a.map(f)),
                        ]);
                      })
                      .then((e) =>
                        this.whenEntrypoint(r).then((t) => ({
                          entrypoint: t,
                          styles: e[1],
                        }))
                      ),
                    3800,
                    l(Error(`Route did not complete loading: ${r}`))
                  )
                    .then((e) => {
                      let { entrypoint: t, styles: r } = e,
                        n = Object.assign({ styles: r }, t);
                      return "error" in t ? t : n;
                    })
                    .catch((e) => {
                      if (n) throw e;
                      return { error: e };
                    })
                    .finally(() => (null == a ? void 0 : a()));
                });
              },
              prefetch(t) {
                let r;
                return (r = navigator.connection) &&
                  (r.saveData || /2g/.test(r.effectiveType))
                  ? Promise.resolve()
                  : d(e, t)
                      .then((e) =>
                        Promise.all(
                          s
                            ? e.scripts.map((e) => {
                                var t, r, n;
                                return (
                                  (t = e.toString()),
                                  (r = "script"),
                                  new Promise((e, a) => {
                                    let o = `
      link[rel="prefetch"][href^="${t}"],
      link[rel="preload"][href^="${t}"],
      script[src^="${t}"]`;
                                    if (document.querySelector(o)) return e();
                                    (n = document.createElement("link")),
                                      r && (n.as = r),
                                      (n.rel = "prefetch"),
                                      (n.crossOrigin = "anonymous"),
                                      (n.onload = e),
                                      (n.onerror = () =>
                                        a(
                                          l(Error(`Failed to prefetch: ${t}`))
                                        )),
                                      (n.href = t),
                                      document.head.appendChild(n);
                                  })
                                );
                              })
                            : []
                        )
                      )
                      .then(() => {
                        a.requestIdleCallback(() =>
                          this.loadRoute(t, !0).catch(() => {})
                        );
                      })
                      .catch(() => {});
              },
            };
          }),
          (0, r(92648).Z)(r(9184));
        var n = r(466),
          a = r(10029);
        function o(e, t, r) {
          let n,
            a = t.get(e);
          if (a) return "future" in a ? a.future : Promise.resolve(a);
          let o = new Promise((e) => {
            n = e;
          });
          return (
            t.set(e, (a = { resolve: n, future: o })),
            r
              ? r()
                  .then((e) => (n(e), e))
                  .catch((r) => {
                    throw (t.delete(e), r);
                  })
              : o
          );
        }
        let i = Symbol("ASSET_LOAD_ERROR");
        function l(e) {
          return Object.defineProperty(e, i, {});
        }
        let s = (function (e) {
          try {
            return (
              (e = document.createElement("link")),
              (!!window.MSInputMethodContext && !!document.documentMode) ||
                e.relList.supports("prefetch")
            );
          } catch (e) {
            return !1;
          }
        })();
        function u(e, t, r) {
          return new Promise((n, o) => {
            let i = !1;
            e
              .then((e) => {
                (i = !0), n(e);
              })
              .catch(o),
              a.requestIdleCallback(() =>
                setTimeout(() => {
                  i || o(r);
                }, t)
              );
          });
        }
        function c() {
          if (self.__BUILD_MANIFEST)
            return Promise.resolve(self.__BUILD_MANIFEST);
          let e = new Promise((e) => {
            let t = self.__BUILD_MANIFEST_CB;
            self.__BUILD_MANIFEST_CB = () => {
              e(self.__BUILD_MANIFEST), t && t();
            };
          });
          return u(e, 3800, l(Error("Failed to load client build manifest")));
        }
        function d(e, t) {
          return c().then((r) => {
            if (!(t in r)) throw l(Error(`Failed to lookup route: ${t}`));
            let a = r[t].map((t) => e + "/_next/" + encodeURI(t));
            return {
              scripts: a
                .filter((e) => e.endsWith(".js"))
                .map((e) => n.__unsafeCreateTrustedScriptURL(e)),
              css: a.filter((e) => e.endsWith(".css")),
            };
          });
        }
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      96885: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          Object.defineProperty(t, "Router", {
            enumerable: !0,
            get: function () {
              return o.default;
            },
          }),
          Object.defineProperty(t, "withRouter", {
            enumerable: !0,
            get: function () {
              return s.default;
            },
          }),
          (t.useRouter = function () {
            let e = a.default.useContext(i.RouterContext);
            if (!e)
              throw Error(
                "NextRouter was not mounted. https://nextjs.org/docs/messages/next-router-not-mounted"
              );
            return e;
          }),
          (t.createRouter = function () {
            for (var e = arguments.length, t = Array(e), r = 0; r < e; r++)
              t[r] = arguments[r];
            return (
              (u.router = new o.default(...t)),
              u.readyCallbacks.forEach((e) => e()),
              (u.readyCallbacks = []),
              u.router
            );
          }),
          (t.makePublicRouterInstance = function (e) {
            let t = {};
            for (let r of c) {
              if ("object" == typeof e[r]) {
                t[r] = Object.assign(Array.isArray(e[r]) ? [] : {}, e[r]);
                continue;
              }
              t[r] = e[r];
            }
            return (
              (t.events = o.default.events),
              d.forEach((r) => {
                t[r] = function () {
                  for (
                    var t = arguments.length, n = Array(t), a = 0;
                    a < t;
                    a++
                  )
                    n[a] = arguments[a];
                  return e[r](...n);
                };
              }),
              t
            );
          }),
          (t.default = void 0);
        var n = r(92648).Z,
          a = n(r(67294)),
          o = n(r(15932)),
          i = r(69955),
          l = n(r(80676)),
          s = n(r(38620));
        let u = {
            router: null,
            readyCallbacks: [],
            ready(e) {
              if (this.router) return e();
              this.readyCallbacks.push(e);
            },
          },
          c = [
            "pathname",
            "route",
            "query",
            "asPath",
            "components",
            "isFallback",
            "basePath",
            "locale",
            "locales",
            "defaultLocale",
            "isReady",
            "isPreview",
            "isLocaleDomain",
            "domainLocales",
          ],
          d = [
            "push",
            "replace",
            "reload",
            "back",
            "prefetch",
            "beforePopState",
          ];
        function f() {
          if (!u.router)
            throw Error(
              'No router instance found.\nYou should only use "next/router" on the client side of your app.\n'
            );
          return u.router;
        }
        Object.defineProperty(u, "events", { get: () => o.default.events }),
          c.forEach((e) => {
            Object.defineProperty(u, e, {
              get() {
                let t = f();
                return t[e];
              },
            });
          }),
          d.forEach((e) => {
            u[e] = function () {
              for (var t = arguments.length, r = Array(t), n = 0; n < t; n++)
                r[n] = arguments[n];
              let a = f();
              return a[e](...r);
            };
          }),
          [
            "routeChangeStart",
            "beforeHistoryChange",
            "routeChangeComplete",
            "routeChangeError",
            "hashChangeStart",
            "hashChangeComplete",
          ].forEach((e) => {
            u.ready(() => {
              o.default.events.on(e, function () {
                for (var t = arguments.length, r = Array(t), n = 0; n < t; n++)
                  r[n] = arguments[n];
                let a = `on${e.charAt(0).toUpperCase()}${e.substring(1)}`;
                if (u[a])
                  try {
                    u[a](...r);
                  } catch (e) {
                    console.error(`Error when running the Router event: ${a}`),
                      console.error(
                        l.default(e)
                          ? `${e.message}
${e.stack}`
                          : e + ""
                      );
                  }
              });
            });
          }),
          (t.default = u),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      85442: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.handleClientScriptLoad = g),
          (t.initScriptLoader = function (e) {
            e.forEach(g),
              (function () {
                let e = [
                  ...document.querySelectorAll(
                    '[data-nscript="beforeInteractive"]'
                  ),
                  ...document.querySelectorAll(
                    '[data-nscript="beforePageRender"]'
                  ),
                ];
                e.forEach((e) => {
                  let t = e.id || e.getAttribute("src");
                  p.add(t);
                });
              })();
          }),
          (t.default = void 0);
        var n = r(6495).Z,
          a = r(92648).Z,
          o = r(91598).Z,
          i = r(17273).Z,
          l = a(r(73935)),
          s = o(r(67294)),
          u = r(79958),
          c = r(19623),
          d = r(10029);
        let f = new Map(),
          p = new Set(),
          h = [
            "onLoad",
            "onReady",
            "dangerouslySetInnerHTML",
            "children",
            "onError",
            "strategy",
          ],
          m = (e) => {
            let {
                src: t,
                id: r,
                onLoad: n = () => {},
                onReady: a = null,
                dangerouslySetInnerHTML: o,
                children: i = "",
                strategy: l = "afterInteractive",
                onError: s,
              } = e,
              u = r || t;
            if (u && p.has(u)) return;
            if (f.has(t)) {
              p.add(u), f.get(t).then(n, s);
              return;
            }
            let d = () => {
                a && a(), p.add(u);
              },
              m = document.createElement("script"),
              g = new Promise((e, t) => {
                m.addEventListener("load", function (t) {
                  e(), n && n.call(this, t), d();
                }),
                  m.addEventListener("error", function (e) {
                    t(e);
                  });
              }).catch(function (e) {
                s && s(e);
              });
            for (let [r, n] of (o
              ? ((m.innerHTML = o.__html || ""), d())
              : i
              ? ((m.textContent =
                  "string" == typeof i
                    ? i
                    : Array.isArray(i)
                    ? i.join("")
                    : ""),
                d())
              : t && ((m.src = t), f.set(t, g)),
            Object.entries(e))) {
              if (void 0 === n || h.includes(r)) continue;
              let e = c.DOMAttributeNames[r] || r.toLowerCase();
              m.setAttribute(e, n);
            }
            "worker" === l && m.setAttribute("type", "text/partytown"),
              m.setAttribute("data-nscript", l),
              document.body.appendChild(m);
          };
        function g(e) {
          let { strategy: t = "afterInteractive" } = e;
          "lazyOnload" === t
            ? window.addEventListener("load", () => {
                d.requestIdleCallback(() => m(e));
              })
            : m(e);
        }
        function y(e) {
          let {
              id: t,
              src: r = "",
              onLoad: a = () => {},
              onReady: o = null,
              strategy: c = "afterInteractive",
              onError: f,
            } = e,
            h = i(e, ["id", "src", "onLoad", "onReady", "strategy", "onError"]),
            {
              updateScripts: g,
              scripts: y,
              getIsSsr: v,
              appDir: _,
              nonce: b,
            } = s.useContext(u.HeadManagerContext),
            P = s.useRef(!1);
          s.useEffect(() => {
            let e = t || r;
            P.current || (o && e && p.has(e) && o(), (P.current = !0));
          }, [o, t, r]);
          let S = s.useRef(!1);
          if (
            (s.useEffect(() => {
              !S.current &&
                ("afterInteractive" === c
                  ? m(e)
                  : "lazyOnload" === c &&
                    ("complete" === document.readyState
                      ? d.requestIdleCallback(() => m(e))
                      : window.addEventListener("load", () => {
                          d.requestIdleCallback(() => m(e));
                        })),
                (S.current = !0));
            }, [e, c]),
            ("beforeInteractive" === c || "worker" === c) &&
              (g
                ? ((y[c] = (y[c] || []).concat([
                    n({ id: t, src: r, onLoad: a, onReady: o, onError: f }, h),
                  ])),
                  g(y))
                : v && v()
                ? p.add(t || r)
                : v && !v() && m(e)),
            _)
          ) {
            if ("beforeInteractive" === c)
              return r
                ? (l.default.preload(
                    r,
                    h.integrity
                      ? { as: "script", integrity: h.integrity }
                      : { as: "script" }
                  ),
                  s.default.createElement("script", {
                    nonce: b,
                    dangerouslySetInnerHTML: {
                      __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify(
                        [r]
                      )})`,
                    },
                  }))
                : (h.dangerouslySetInnerHTML &&
                    ((h.children = h.dangerouslySetInnerHTML.__html),
                    delete h.dangerouslySetInnerHTML),
                  s.default.createElement("script", {
                    nonce: b,
                    dangerouslySetInnerHTML: {
                      __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify(
                        [0, n({}, h)]
                      )})`,
                    },
                  }));
            "afterInteractive" === c &&
              r &&
              l.default.preload(
                r,
                h.integrity
                  ? { as: "script", integrity: h.integrity }
                  : { as: "script" }
              );
          }
          return null;
        }
        Object.defineProperty(y, "__nextScript", { value: !0 }),
          (t.default = y),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      466: function (e, t) {
        "use strict";
        let r;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.__unsafeCreateTrustedScriptURL = function (e) {
            var t;
            return (
              (null ==
              (t = (function () {
                if (void 0 === r) {
                  var e;
                  r =
                    (null == (e = window.trustedTypes)
                      ? void 0
                      : e.createPolicy("nextjs", {
                          createHTML: (e) => e,
                          createScript: (e) => e,
                          createScriptURL: (e) => e,
                        })) || null;
                }
                return r;
              })())
                ? void 0
                : t.createScriptURL(e)) || e
            );
          }),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      38620: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function (e) {
            function t(t) {
              return n.default.createElement(
                e,
                Object.assign({ router: a.useRouter() }, t)
              );
            }
            return (
              (t.getInitialProps = e.getInitialProps),
              (t.origGetInitialProps = e.origGetInitialProps),
              t
            );
          });
        var n = (0, r(92648).Z)(r(67294)),
          a = r(96885);
        ("function" == typeof t.default ||
          ("object" == typeof t.default && null !== t.default)) &&
          void 0 === t.default.__esModule &&
          (Object.defineProperty(t.default, "__esModule", { value: !0 }),
          Object.assign(t.default, t),
          (e.exports = t.default));
      },
      65035: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var n,
          a = r(60932).Z,
          o = (0, r(92648).Z)(r(67294)),
          i = r(79064);
        function l(e) {
          return s.apply(this, arguments);
        }
        function s() {
          return (s = a(function* (e) {
            let { Component: t, ctx: r } = e,
              n = yield i.loadGetInitialProps(t, r);
            return { pageProps: n };
          })).apply(this, arguments);
        }
        class u extends (n = o.default.Component) {
          render() {
            let { Component: e, pageProps: t } = this.props;
            return o.default.createElement(e, Object.assign({}, t));
          }
        }
        (u.origGetInitialProps = l),
          (u.getInitialProps = l),
          (t.default = u),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      43499: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0);
        var n,
          a = r(92648).Z,
          o = a(r(67294)),
          i = a(r(42636));
        let l = {
          400: "Bad Request",
          404: "This page could not be found",
          405: "Method Not Allowed",
          500: "Internal Server Error",
        };
        function s(e) {
          let { res: t, err: r } = e,
            n = t && t.statusCode ? t.statusCode : r ? r.statusCode : 404;
          return { statusCode: n };
        }
        let u = {
          error: {
            fontFamily:
              'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
            height: "100vh",
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          },
          desc: { display: "inline-block", textAlign: "left" },
          h1: {
            display: "inline-block",
            margin: "0 20px 0 0",
            paddingRight: 23,
            fontSize: 24,
            fontWeight: 500,
            verticalAlign: "top",
            lineHeight: "49px",
          },
          h2: { fontSize: 14, fontWeight: 400, lineHeight: "49px", margin: 0 },
        };
        class c extends (n = o.default.Component) {
          render() {
            let { statusCode: e, withDarkMode: t = !0 } = this.props,
              r =
                this.props.title || l[e] || "An unexpected error has occurred";
            return o.default.createElement(
              "div",
              { style: u.error },
              o.default.createElement(
                i.default,
                null,
                o.default.createElement(
                  "title",
                  null,
                  e
                    ? `${e}: ${r}`
                    : "Application error: a client-side exception has occurred"
                )
              ),
              o.default.createElement(
                "div",
                null,
                o.default.createElement("style", {
                  dangerouslySetInnerHTML: {
                    __html: `body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}${
                      t
                        ? "@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"
                        : ""
                    }`,
                  },
                }),
                e
                  ? o.default.createElement(
                      "h1",
                      { className: "next-error-h1", style: u.h1 },
                      e
                    )
                  : null,
                o.default.createElement(
                  "div",
                  { style: u.desc },
                  o.default.createElement(
                    "h2",
                    { style: u.h2 },
                    this.props.title || e
                      ? r
                      : o.default.createElement(
                          o.default.Fragment,
                          null,
                          "Application error: a client-side exception has occurred (see the browser console for more information)"
                        ),
                    "."
                  )
                )
              )
            );
          }
        }
        (c.displayName = "ErrorPage"),
          (c.getInitialProps = s),
          (c.origGetInitialProps = s),
          (t.default = c),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      14221: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.AmpStateContext = void 0);
        var n = (0, r(92648).Z)(r(67294));
        let a = n.default.createContext({});
        t.AmpStateContext = a;
      },
      63459: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.isInAmpMode = function () {
            let {
              ampFirst: e = !1,
              hybrid: t = !1,
              hasQuery: r = !1,
            } = arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : {};
            return e || (t && r);
          });
      },
      24224: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.TemplateContext =
            t.GlobalLayoutRouterContext =
            t.LayoutRouterContext =
            t.AppRouterContext =
            t.CacheStates =
              void 0);
        var n,
          a,
          o = (0, r(92648).Z)(r(67294));
        (t.CacheStates = n),
          ((a = n || (t.CacheStates = n = {})).LAZY_INITIALIZED =
            "LAZYINITIALIZED"),
          (a.DATA_FETCH = "DATAFETCH"),
          (a.READY = "READY");
        let i = o.default.createContext(null);
        t.AppRouterContext = i;
        let l = o.default.createContext(null);
        t.LayoutRouterContext = l;
        let s = o.default.createContext(null);
        t.GlobalLayoutRouterContext = s;
        let u = o.default.createContext(null);
        t.TemplateContext = u;
      },
      35987: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.escapeStringRegexp = function (e) {
            return r.test(e) ? e.replace(n, "\\$&") : e;
          });
        let r = /[|\\{}()[\]^$+*?.-]/,
          n = /[|\\{}()[\]^$+*?.-]/g;
      },
      79958: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.HeadManagerContext = void 0);
        var n = (0, r(92648).Z)(r(67294));
        let a = n.default.createContext({});
        t.HeadManagerContext = a;
      },
      42636: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.defaultHead = c),
          (t.default = void 0);
        var n = r(6495).Z,
          a = r(92648).Z,
          o = (0, r(91598).Z)(r(67294)),
          i = a(r(63962)),
          l = r(14221),
          s = r(79958),
          u = r(63459);
        function c() {
          let e =
              arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
            t = [o.default.createElement("meta", { charSet: "utf-8" })];
          return (
            e ||
              t.push(
                o.default.createElement("meta", {
                  name: "viewport",
                  content: "width=device-width",
                })
              ),
            t
          );
        }
        function d(e, t) {
          return "string" == typeof t || "number" == typeof t
            ? e
            : t.type === o.default.Fragment
            ? e.concat(
                o.default.Children.toArray(t.props.children).reduce(
                  (e, t) =>
                    "string" == typeof t || "number" == typeof t
                      ? e
                      : e.concat(t),
                  []
                )
              )
            : e.concat(t);
        }
        r(34210);
        let f = ["name", "httpEquiv", "charSet", "itemProp"];
        function p(e, t) {
          let { inAmpMode: r } = t;
          return e
            .reduce(d, [])
            .reverse()
            .concat(c(r).reverse())
            .filter(
              (function () {
                let e = new Set(),
                  t = new Set(),
                  r = new Set(),
                  n = {};
                return (a) => {
                  let o = !0,
                    i = !1;
                  if (
                    a.key &&
                    "number" != typeof a.key &&
                    a.key.indexOf("$") > 0
                  ) {
                    i = !0;
                    let t = a.key.slice(a.key.indexOf("$") + 1);
                    e.has(t) ? (o = !1) : e.add(t);
                  }
                  switch (a.type) {
                    case "title":
                    case "base":
                      t.has(a.type) ? (o = !1) : t.add(a.type);
                      break;
                    case "meta":
                      for (let e = 0, t = f.length; e < t; e++) {
                        let t = f[e];
                        if (a.props.hasOwnProperty(t)) {
                          if ("charSet" === t) r.has(t) ? (o = !1) : r.add(t);
                          else {
                            let e = a.props[t],
                              r = n[t] || new Set();
                            ("name" !== t || !i) && r.has(e)
                              ? (o = !1)
                              : (r.add(e), (n[t] = r));
                          }
                        }
                      }
                  }
                  return o;
                };
              })()
            )
            .reverse()
            .map((e, t) => {
              let a = e.key || t;
              if (
                !r &&
                "link" === e.type &&
                e.props.href &&
                [
                  "https://fonts.googleapis.com/css",
                  "https://use.typekit.net/",
                ].some((t) => e.props.href.startsWith(t))
              ) {
                let t = n({}, e.props || {});
                return (
                  (t["data-href"] = t.href),
                  (t.href = void 0),
                  (t["data-optimized-fonts"] = !0),
                  o.default.cloneElement(e, t)
                );
              }
              return o.default.cloneElement(e, { key: a });
            });
        }
        (t.default = function (e) {
          let { children: t } = e,
            r = o.useContext(l.AmpStateContext),
            n = o.useContext(s.HeadManagerContext);
          return o.default.createElement(
            i.default,
            {
              reduceComponentsToState: p,
              headManager: n,
              inAmpMode: u.isInAmpMode(r),
            },
            t
          );
        }),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      78463: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.LayoutSegmentsContext =
            t.ParamsContext =
            t.PathnameContext =
            t.SearchParamsContext =
              void 0);
        var n = r(67294);
        let a = n.createContext(null);
        t.SearchParamsContext = a;
        let o = n.createContext(null);
        t.PathnameContext = o;
        let i = n.createContext(null);
        t.ParamsContext = i;
        let l = n.createContext(null);
        t.LayoutSegmentsContext = l;
      },
      18391: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.detectDomainLocale = function (e, t, r) {
            let n;
            if (e)
              for (let i of (r && (r = r.toLowerCase()), e)) {
                var a, o;
                let e =
                  null == (a = i.domain)
                    ? void 0
                    : a.split(":")[0].toLowerCase();
                if (
                  t === e ||
                  r === i.defaultLocale.toLowerCase() ||
                  (null == (o = i.locales)
                    ? void 0
                    : o.some((e) => e.toLowerCase() === r))
                ) {
                  n = i;
                  break;
                }
              }
            return n;
          });
      },
      34842: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.normalizeLocalePath = function (e, t) {
            let r;
            let n = e.split("/");
            return (
              (t || []).some(
                (t) =>
                  !!n[1] &&
                  n[1].toLowerCase() === t.toLowerCase() &&
                  ((r = t), n.splice(1, 1), (e = n.join("/") || "/"), !0)
              ),
              { pathname: e, detectedLocale: r }
            );
          });
      },
      83341: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.ImageConfigContext = void 0);
        var n = (0, r(92648).Z)(r(67294)),
          a = r(3735);
        let o = n.default.createContext(a.imageConfigDefault);
        t.ImageConfigContext = o;
      },
      3735: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.imageConfigDefault = t.VALID_LOADERS = void 0),
          (t.VALID_LOADERS = [
            "default",
            "imgix",
            "cloudinary",
            "akamai",
            "custom",
          ]),
          (t.imageConfigDefault = {
            deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
            imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
            path: "/_next/image",
            loader: "default",
            loaderFile: "",
            domains: [],
            disableStaticImages: !1,
            minimumCacheTTL: 60,
            formats: ["image/webp"],
            dangerouslyAllowSVG: !1,
            contentSecurityPolicy:
              "script-src 'none'; frame-src 'none'; sandbox;",
            contentDispositionType: "inline",
            remotePatterns: [],
            unoptimized: !1,
          });
      },
      19125: function (e, t) {
        "use strict";
        function r(e) {
          return Object.prototype.toString.call(e);
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.getObjectClassLabel = r),
          (t.isPlainObject = function (e) {
            if ("[object Object]" !== r(e)) return !1;
            let t = Object.getPrototypeOf(e);
            return null === t || t.hasOwnProperty("isPrototypeOf");
          });
      },
      54149: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.NEXT_DYNAMIC_NO_SSR_CODE = void 0),
          (t.NEXT_DYNAMIC_NO_SSR_CODE = "DYNAMIC_SERVER_USAGE");
      },
      96595: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function () {
            let e = Object.create(null);
            return {
              on(t, r) {
                (e[t] || (e[t] = [])).push(r);
              },
              off(t, r) {
                e[t] && e[t].splice(e[t].indexOf(r) >>> 0, 1);
              },
              emit(t) {
                for (
                  var r = arguments.length, n = Array(r > 1 ? r - 1 : 0), a = 1;
                  a < r;
                  a++
                )
                  n[a - 1] = arguments[a];
                (e[t] || []).slice().map((e) => {
                  e(...n);
                });
              },
            };
          });
      },
      82307: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.denormalizePagePath = function (e) {
            let t = a.normalizePathSep(e);
            return t.startsWith("/index/") && !n.isDynamicRoute(t)
              ? t.slice(6)
              : "/index" !== t
              ? t
              : "/";
          });
        var n = r(919),
          a = r(98106);
      },
      98106: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.normalizePathSep = function (e) {
            return e.replace(/\\/g, "/");
          });
      },
      69955: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.RouterContext = void 0);
        var n = (0, r(92648).Z)(r(67294));
        let a = n.default.createContext(null);
        t.RouterContext = a;
      },
      29486: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.adaptForAppRouterInstance = function (e) {
            return {
              back() {
                e.back();
              },
              forward() {
                e.forward();
              },
              refresh() {
                e.reload();
              },
              push(t) {
                e.push(t);
              },
              replace(t) {
                e.replace(t);
              },
              prefetch(t) {
                e.prefetch(t);
              },
            };
          }),
          (t.adaptForSearchParams = function (e) {
            return e.isReady && e.query
              ? (function (e) {
                  let t = new URLSearchParams();
                  for (let [r, n] of Object.entries(e))
                    if (Array.isArray(n)) for (let e of n) t.append(r, e);
                    else void 0 !== n && t.append(r, n);
                  return t;
                })(e.query)
              : new URLSearchParams();
          }),
          (t.PathnameContextProviderAdapter = function (e) {
            var { children: t, router: r } = e,
              n = a(e, ["children", "router"]);
            let s = o.useRef(n.isAutoExport),
              u = o.useMemo(() => {
                let e;
                let t = s.current;
                if (
                  (t && (s.current = !1),
                  l.isDynamicRoute(r.pathname) &&
                    (r.isFallback || (t && !r.isReady)))
                )
                  return null;
                try {
                  e = new URL(r.asPath, "http://f");
                } catch (e) {
                  return "/";
                }
                return e.pathname;
              }, [r.asPath, r.isFallback, r.isReady, r.pathname]);
            return o.default.createElement(
              i.PathnameContext.Provider,
              { value: u },
              t
            );
          });
        var n = r(91598).Z,
          a = r(17273).Z,
          o = n(r(67294)),
          i = r(78463),
          l = r(919);
      },
      15932: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.matchesMiddleware = D),
          (t.createKey = X),
          (t.default = void 0);
        var n = r(60932).Z,
          a = r(6495).Z,
          o = r(92648).Z,
          i = r(91598).Z,
          l = r(67734),
          s = r(95564),
          u = r(85442),
          c = i(r(80676)),
          d = r(82307),
          f = r(34842),
          p = o(r(96595)),
          h = r(79064),
          m = r(63162),
          g = r(73460);
        o(r(72431));
        var y = r(43978),
          v = r(37762),
          _ = r(61410),
          b = r(2249),
          P = r(64046),
          S = r(370),
          w = r(52080),
          E = r(39577),
          C = r(64266),
          x = r(12140),
          j = r(79423),
          O = r(96373),
          M = r(79473),
          L = r(66385),
          R = r(83353),
          T = r(90293),
          A = r(35821),
          I = r(14532),
          N = r(35036),
          k = r(3105);
        function $() {
          return Object.assign(Error("Route Cancelled"), { cancelled: !0 });
        }
        function D(e) {
          return B.apply(this, arguments);
        }
        function B() {
          return (B = n(function* (e) {
            let t = yield Promise.resolve(e.router.pageLoader.getMiddleware());
            if (!t) return !1;
            let { pathname: r } = P.parsePath(e.asPath),
              n = x.hasBasePath(r) ? E.removeBasePath(r) : r,
              a = C.addBasePath(S.addLocale(n, e.locale));
            return t.some((e) => RegExp(e.regexp).test(a));
          })).apply(this, arguments);
        }
        function F(e) {
          let t = h.getLocationOrigin();
          return e.startsWith(t) ? e.substring(t.length) : e;
        }
        function U(e, t, r) {
          let [n, a] = I.resolveHref(e, t, !0),
            o = h.getLocationOrigin(),
            i = n.startsWith(o),
            l = a && a.startsWith(o);
          (n = F(n)), (a = a ? F(a) : a);
          let s = i ? n : C.addBasePath(n),
            u = r ? F(I.resolveHref(e, r)) : a || n;
          return { url: s, as: l ? u : C.addBasePath(u) };
        }
        function H(e, t) {
          let r = l.removeTrailingSlash(d.denormalizePagePath(e));
          return "/404" === r || "/_error" === r
            ? e
            : (t.includes(r) ||
                t.some((t) => {
                  if (m.isDynamicRoute(t) && v.getRouteRegex(t).re.test(r))
                    return (e = t), !0;
                }),
              l.removeTrailingSlash(e));
        }
        function q(e) {
          return W.apply(this, arguments);
        }
        function W() {
          return (W = n(function* (e) {
            let t = yield D(e);
            if (!t || !e.fetchData) return null;
            try {
              let t = yield e.fetchData(),
                r = yield (function (e, t, r) {
                  let n = {
                      basePath: r.router.basePath,
                      i18n: { locales: r.router.locales },
                      trailingSlash: Boolean(!1),
                    },
                    o = t.headers.get("x-nextjs-rewrite"),
                    i = o || t.headers.get("x-nextjs-matched-path"),
                    u = t.headers.get("x-matched-path");
                  if (
                    (!u ||
                      i ||
                      u.includes("__next_data_catchall") ||
                      u.includes("/_error") ||
                      u.includes("/404") ||
                      (i = u),
                    i)
                  ) {
                    if (i.startsWith("/")) {
                      let t = g.parseRelativeUrl(i),
                        a = O.getNextPathnameInfo(t.pathname, {
                          nextConfig: n,
                          parseData: !0,
                        }),
                        u = l.removeTrailingSlash(a.pathname);
                      return Promise.all([
                        r.router.pageLoader.getPageList(),
                        s.getClientBuildManifest(),
                      ]).then((n) => {
                        let [i, { __rewrites: l }] = n,
                          s = S.addLocale(a.pathname, a.locale);
                        if (
                          m.isDynamicRoute(s) ||
                          (!o &&
                            i.includes(
                              f.normalizeLocalePath(
                                E.removeBasePath(s),
                                r.router.locales
                              ).pathname
                            ))
                        ) {
                          let r = O.getNextPathnameInfo(
                            g.parseRelativeUrl(e).pathname,
                            { parseData: !0 }
                          );
                          (s = C.addBasePath(r.pathname)), (t.pathname = s);
                        }
                        if (!i.includes(u)) {
                          let e = H(u, i);
                          e !== u && (u = e);
                        }
                        let c = i.includes(u)
                          ? u
                          : H(
                              f.normalizeLocalePath(
                                E.removeBasePath(t.pathname),
                                r.router.locales
                              ).pathname,
                              i
                            );
                        if (m.isDynamicRoute(c)) {
                          let e = y.getRouteMatcher(v.getRouteRegex(c))(s);
                          Object.assign(t.query, e || {});
                        }
                        return {
                          type: "rewrite",
                          parsedAs: t,
                          resolvedHref: c,
                        };
                      });
                    }
                    let t = P.parsePath(e),
                      u = M.formatNextPathnameInfo(
                        a(
                          {},
                          O.getNextPathnameInfo(t.pathname, {
                            nextConfig: n,
                            parseData: !0,
                          }),
                          { defaultLocale: r.router.defaultLocale, buildId: "" }
                        )
                      );
                    return Promise.resolve({
                      type: "redirect-external",
                      destination: `${u}${t.query}${t.hash}`,
                    });
                  }
                  let c = t.headers.get("x-nextjs-redirect");
                  if (c) {
                    if (c.startsWith("/")) {
                      let e = P.parsePath(c),
                        t = M.formatNextPathnameInfo(
                          a(
                            {},
                            O.getNextPathnameInfo(e.pathname, {
                              nextConfig: n,
                              parseData: !0,
                            }),
                            {
                              defaultLocale: r.router.defaultLocale,
                              buildId: "",
                            }
                          )
                        );
                      return Promise.resolve({
                        type: "redirect-internal",
                        newAs: `${t}${e.query}${e.hash}`,
                        newUrl: `${t}${e.query}${e.hash}`,
                      });
                    }
                    return Promise.resolve({
                      type: "redirect-external",
                      destination: c,
                    });
                  }
                  return Promise.resolve({ type: "next" });
                })(t.dataHref, t.response, e);
              return {
                dataHref: t.dataHref,
                json: t.json,
                response: t.response,
                text: t.text,
                cacheKey: t.cacheKey,
                effect: r,
              };
            } catch (e) {
              return null;
            }
          })).apply(this, arguments);
        }
        let Z =
            "scrollRestoration" in window.history &&
            !!(function () {
              try {
                let e = "__next";
                return (
                  sessionStorage.setItem(e, e), sessionStorage.removeItem(e), !0
                );
              } catch (e) {}
            })(),
          z = Symbol("SSG_DATA_NOT_FOUND");
        function G(e) {
          try {
            return JSON.parse(e);
          } catch (e) {
            return null;
          }
        }
        function V(e) {
          var t;
          let {
              dataHref: r,
              inflightCache: n,
              isPrefetch: a,
              hasMiddleware: o,
              isServerRender: i,
              parseJSON: l,
              persistCache: u,
              isBackground: c,
              unstable_skipClientCache: d,
            } = e,
            { href: f } = new URL(r, window.location.href),
            p = (e) =>
              (function e(t, r, n) {
                return fetch(t, {
                  credentials: "same-origin",
                  method: n.method || "GET",
                  headers: Object.assign({}, n.headers, {
                    "x-nextjs-data": "1",
                  }),
                }).then((a) =>
                  !a.ok && r > 1 && a.status >= 500 ? e(t, r - 1, n) : a
                );
              })(r, i ? 3 : 1, {
                headers: Object.assign(
                  {},
                  a ? { purpose: "prefetch" } : {},
                  a && o ? { "x-middleware-prefetch": "1" } : {}
                ),
                method: null != (t = null == e ? void 0 : e.method) ? t : "GET",
              })
                .then((t) =>
                  t.ok && (null == e ? void 0 : e.method) === "HEAD"
                    ? {
                        dataHref: r,
                        response: t,
                        text: "",
                        json: {},
                        cacheKey: f,
                      }
                    : t.text().then((e) => {
                        if (!t.ok) {
                          if (o && [301, 302, 307, 308].includes(t.status))
                            return {
                              dataHref: r,
                              response: t,
                              text: e,
                              json: {},
                              cacheKey: f,
                            };
                          if (404 === t.status) {
                            var n;
                            if (null == (n = G(e)) ? void 0 : n.notFound)
                              return {
                                dataHref: r,
                                json: { notFound: z },
                                response: t,
                                text: e,
                                cacheKey: f,
                              };
                          }
                          let a = Error("Failed to load static props");
                          throw (i || s.markAssetError(a), a);
                        }
                        return {
                          dataHref: r,
                          json: l ? G(e) : null,
                          response: t,
                          text: e,
                          cacheKey: f,
                        };
                      })
                )
                .then(
                  (e) => (
                    (u &&
                      "no-cache" !==
                        e.response.headers.get("x-middleware-cache")) ||
                      delete n[f],
                    e
                  )
                )
                .catch((e) => {
                  throw (
                    (d || delete n[f],
                    ("Failed to fetch" === e.message ||
                      "NetworkError when attempting to fetch resource." ===
                        e.message ||
                      "Load failed" === e.message) &&
                      s.markAssetError(e),
                    e)
                  );
                });
          return d && u
            ? p({}).then((e) => ((n[f] = Promise.resolve(e)), e))
            : void 0 !== n[f]
            ? n[f]
            : (n[f] = p(c ? { method: "HEAD" } : {}));
        }
        function X() {
          return Math.random().toString(36).slice(2, 10);
        }
        function Y(e) {
          let { url: t, router: r } = e;
          if (t === C.addBasePath(S.addLocale(r.asPath, r.locale)))
            throw Error(
              `Invariant: attempted to hard navigate to the same URL ${t} ${location.href}`
            );
          window.location.href = t;
        }
        let J = (e) => {
          let { route: t, router: r } = e,
            n = !1,
            a = (r.clc = () => {
              n = !0;
            }),
            o = () => {
              if (n) {
                let e = Error(`Abort fetching component for route: "${t}"`);
                throw ((e.cancelled = !0), e);
              }
              a === r.clc && (r.clc = null);
            };
          return o;
        };
        class K {
          reload() {
            window.location.reload();
          }
          back() {
            window.history.back();
          }
          forward() {
            window.history.forward();
          }
          push(e, t) {
            let r =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : {};
            if (Z)
              try {
                sessionStorage.setItem(
                  "__next_scroll_" + this._key,
                  JSON.stringify({ x: self.pageXOffset, y: self.pageYOffset })
                );
              } catch (e) {}
            return (
              ({ url: e, as: t } = U(this, e, t)),
              this.change("pushState", e, t, r)
            );
          }
          replace(e, t) {
            let r =
              arguments.length > 2 && void 0 !== arguments[2]
                ? arguments[2]
                : {};
            return (
              ({ url: e, as: t } = U(this, e, t)),
              this.change("replaceState", e, t, r)
            );
          }
          _bfl(e, t, r) {
            return n(function* () {})();
          }
          change(e, t, r, o, i) {
            var d = this;
            return n(function* () {
              var n, p, j, O, M, T, I, k, B;
              let F, q;
              if (!R.isLocalURL(t)) return Y({ url: t, router: d }), !1;
              let W = 1 === o._h;
              W || o.shallow || (yield d._bfl(r, void 0, o.locale));
              let Z =
                  W ||
                  o._shouldResolveHref ||
                  P.parsePath(t).pathname === P.parsePath(r).pathname,
                G = a({}, d.state),
                V = !0 !== d.isReady;
              d.isReady = !0;
              let X = d.isSsr;
              if ((W || (d.isSsr = !1), W && d.clc)) return !1;
              let J = G.locale;
              {
                (G.locale =
                  !1 === o.locale ? d.defaultLocale : o.locale || G.locale),
                  void 0 === o.locale && (o.locale = G.locale);
                let e = g.parseRelativeUrl(
                    x.hasBasePath(r) ? E.removeBasePath(r) : r
                  ),
                  a = f.normalizeLocalePath(e.pathname, d.locales);
                a.detectedLocale &&
                  ((G.locale = a.detectedLocale),
                  (e.pathname = C.addBasePath(e.pathname)),
                  (r = _.formatWithValidation(e)),
                  (t = C.addBasePath(
                    f.normalizeLocalePath(
                      x.hasBasePath(t) ? E.removeBasePath(t) : t,
                      d.locales
                    ).pathname
                  )));
                let i = !1;
                (null == (n = d.locales) ? void 0 : n.includes(G.locale)) ||
                  ((e.pathname = S.addLocale(e.pathname, G.locale)),
                  Y({ url: _.formatWithValidation(e), router: d }),
                  (i = !0));
                let l = b.detectDomainLocale(d.domainLocales, void 0, G.locale);
                if (
                  !i &&
                  l &&
                  d.isLocaleDomain &&
                  self.location.hostname !== l.domain
                ) {
                  let e = E.removeBasePath(r);
                  Y({
                    url: `http${l.http ? "" : "s"}://${l.domain}${C.addBasePath(
                      `${G.locale === l.defaultLocale ? "" : `/${G.locale}`}${
                        "/" === e ? "" : e
                      }` || "/"
                    )}`,
                    router: d,
                  }),
                    (i = !0);
                }
                if (i) return new Promise(() => {});
              }
              h.ST && performance.mark("routeChange");
              let { shallow: Q = !1, scroll: ee = !0 } = o,
                et = { shallow: Q };
              d._inFlightRoute &&
                d.clc &&
                (X ||
                  K.events.emit("routeChangeError", $(), d._inFlightRoute, et),
                d.clc(),
                (d.clc = null)),
                (r = C.addBasePath(
                  S.addLocale(
                    x.hasBasePath(r) ? E.removeBasePath(r) : r,
                    o.locale,
                    d.defaultLocale
                  )
                ));
              let er = w.removeLocale(
                x.hasBasePath(r) ? E.removeBasePath(r) : r,
                G.locale
              );
              d._inFlightRoute = r;
              let en = J !== G.locale;
              if (!W && d.onlyAHashChange(er) && !en) {
                (G.asPath = er),
                  K.events.emit("hashChangeStart", r, et),
                  d.changeState(e, t, r, a({}, o, { scroll: !1 })),
                  ee && d.scrollToHash(er);
                try {
                  yield d.set(G, d.components[G.route], null);
                } catch (e) {
                  throw (
                    (c.default(e) &&
                      e.cancelled &&
                      K.events.emit("routeChangeError", e, er, et),
                    e)
                  );
                }
                return K.events.emit("hashChangeComplete", r, et), !0;
              }
              let ea = g.parseRelativeUrl(t),
                { pathname: eo, query: ei } = ea;
              try {
                [F, { __rewrites: q }] = yield Promise.all([
                  d.pageLoader.getPageList(),
                  s.getClientBuildManifest(),
                  d.pageLoader.getMiddleware(),
                ]);
              } catch (e) {
                return Y({ url: r, router: d }), !1;
              }
              d.urlIsNew(er) || en || (e = "replaceState");
              let el = r;
              eo = eo ? l.removeTrailingSlash(E.removeBasePath(eo)) : eo;
              let es = l.removeTrailingSlash(eo),
                eu = r.startsWith("/") && g.parseRelativeUrl(r).pathname,
                ec = !!(
                  eu &&
                  es !== eu &&
                  (!m.isDynamicRoute(es) ||
                    !y.getRouteMatcher(v.getRouteRegex(es))(eu))
                ),
                ed =
                  !o.shallow &&
                  (yield D({ asPath: r, locale: G.locale, router: d }));
              if (
                (W && ed && (Z = !1),
                Z &&
                  "/_error" !== eo &&
                  ((o._shouldResolveHref = !0),
                  (ea.pathname = H(eo, F)),
                  ea.pathname === eo ||
                    ((eo = ea.pathname),
                    (ea.pathname = C.addBasePath(eo)),
                    ed || (t = _.formatWithValidation(ea)))),
                !R.isLocalURL(r))
              )
                return Y({ url: r, router: d }), !1;
              (el = w.removeLocale(E.removeBasePath(el), G.locale)),
                (es = l.removeTrailingSlash(eo));
              let ef = !1;
              if (m.isDynamicRoute(es)) {
                let e = g.parseRelativeUrl(el),
                  n = e.pathname,
                  a = v.getRouteRegex(es);
                ef = y.getRouteMatcher(a)(n);
                let o = es === n,
                  i = o ? N.interpolateAs(es, n, ei) : {};
                if (ef && (!o || i.result))
                  o
                    ? (r = _.formatWithValidation(
                        Object.assign({}, e, {
                          pathname: i.result,
                          query: A.omit(ei, i.params),
                        })
                      ))
                    : Object.assign(ei, ef);
                else {
                  let e = Object.keys(a.groups).filter(
                    (e) => !ei[e] && !a.groups[e].optional
                  );
                  if (e.length > 0 && !ed)
                    throw Error(
                      (o
                        ? `The provided \`href\` (${t}) value is missing query values (${e.join(
                            ", "
                          )}) to be interpolated properly. `
                        : `The provided \`as\` value (${n}) is incompatible with the \`href\` value (${es}). `) +
                        `Read more: https://nextjs.org/docs/messages/${
                          o
                            ? "href-interpolation-failed"
                            : "incompatible-href-as"
                        }`
                    );
                }
              }
              W || K.events.emit("routeChangeStart", r, et);
              let ep = "/404" === d.pathname || "/_error" === d.pathname;
              try {
                let n = yield d.getRouteInfo({
                  route: es,
                  pathname: eo,
                  query: ei,
                  as: r,
                  resolvedAs: el,
                  routeProps: et,
                  locale: G.locale,
                  isPreview: G.isPreview,
                  hasMiddleware: ed,
                  unstable_skipClientCache: o.unstable_skipClientCache,
                  isQueryUpdating: W && !d.isFallback,
                  isMiddlewareRewrite: ec,
                });
                if (
                  (W ||
                    o.shallow ||
                    (yield d._bfl(
                      r,
                      "resolvedAs" in n ? n.resolvedAs : void 0,
                      G.locale
                    )),
                  "route" in n && ed)
                ) {
                  (es = eo = n.route || es),
                    et.shallow || (ei = Object.assign({}, n.query || {}, ei));
                  let e = x.hasBasePath(ea.pathname)
                    ? E.removeBasePath(ea.pathname)
                    : ea.pathname;
                  if (
                    (ef &&
                      eo !== e &&
                      Object.keys(ef).forEach((e) => {
                        ef && ei[e] === ef[e] && delete ei[e];
                      }),
                    m.isDynamicRoute(eo))
                  ) {
                    let e =
                        !et.shallow && n.resolvedAs
                          ? n.resolvedAs
                          : C.addBasePath(
                              S.addLocale(
                                new URL(r, location.href).pathname,
                                G.locale
                              ),
                              !0
                            ),
                      t = e;
                    x.hasBasePath(t) && (t = E.removeBasePath(t));
                    {
                      let e = f.normalizeLocalePath(t, d.locales);
                      (G.locale = e.detectedLocale || G.locale),
                        (t = e.pathname);
                    }
                    let a = v.getRouteRegex(eo),
                      o = y.getRouteMatcher(a)(
                        new URL(t, location.href).pathname
                      );
                    o && Object.assign(ei, o);
                  }
                }
                if ("type" in n) {
                  if ("redirect-internal" === n.type)
                    return d.change(e, n.newUrl, n.newAs, o);
                  return (
                    Y({ url: n.destination, router: d }), new Promise(() => {})
                  );
                }
                let l = n.Component;
                if (l && l.unstable_scriptLoader) {
                  let e = [].concat(l.unstable_scriptLoader());
                  e.forEach((e) => {
                    u.handleClientScriptLoad(e.props);
                  });
                }
                if ((n.__N_SSG || n.__N_SSP) && n.props) {
                  if (n.props.pageProps && n.props.pageProps.__N_REDIRECT) {
                    o.locale = !1;
                    let t = n.props.pageProps.__N_REDIRECT;
                    if (
                      t.startsWith("/") &&
                      !1 !== n.props.pageProps.__N_REDIRECT_BASE_PATH
                    ) {
                      let r = g.parseRelativeUrl(t);
                      r.pathname = H(r.pathname, F);
                      let { url: n, as: a } = U(d, t, t);
                      return d.change(e, n, a, o);
                    }
                    return Y({ url: t, router: d }), new Promise(() => {});
                  }
                  if (
                    ((G.isPreview = !!n.props.__N_PREVIEW),
                    n.props.notFound === z)
                  ) {
                    let e;
                    try {
                      yield d.fetchComponent("/404"), (e = "/404");
                    } catch (t) {
                      e = "/_error";
                    }
                    if (
                      ((n = yield d.getRouteInfo({
                        route: e,
                        pathname: e,
                        query: ei,
                        as: r,
                        resolvedAs: el,
                        routeProps: { shallow: !1 },
                        locale: G.locale,
                        isPreview: G.isPreview,
                        isNotFound: !0,
                      })),
                      "type" in n)
                    )
                      throw Error("Unexpected middleware effect on /404");
                  }
                }
                W &&
                  "/_error" === d.pathname &&
                  (null == (p = self.__NEXT_DATA__.props)
                    ? void 0
                    : null == (j = p.pageProps)
                    ? void 0
                    : j.statusCode) === 500 &&
                  (null == (O = n.props) ? void 0 : O.pageProps) &&
                  (n.props.pageProps.statusCode = 500);
                let s =
                    o.shallow && G.route === (null != (M = n.route) ? M : es),
                  h = null != (T = o.scroll) ? T : !W && !s,
                  _ = null != i ? i : h ? { x: 0, y: 0 } : null,
                  b = a({}, G, {
                    route: es,
                    pathname: eo,
                    query: ei,
                    asPath: er,
                    isFallback: !1,
                  });
                if (W && ep) {
                  if (
                    ((n = yield d.getRouteInfo({
                      route: d.pathname,
                      pathname: d.pathname,
                      query: ei,
                      as: r,
                      resolvedAs: el,
                      routeProps: { shallow: !1 },
                      locale: G.locale,
                      isPreview: G.isPreview,
                      isQueryUpdating: W && !d.isFallback,
                    })),
                    "type" in n)
                  )
                    throw Error(
                      `Unexpected middleware effect on ${d.pathname}`
                    );
                  "/_error" === d.pathname &&
                    (null == (I = self.__NEXT_DATA__.props)
                      ? void 0
                      : null == (k = I.pageProps)
                      ? void 0
                      : k.statusCode) === 500 &&
                    (null == (B = n.props) ? void 0 : B.pageProps) &&
                    (n.props.pageProps.statusCode = 500);
                  try {
                    yield d.set(b, n, _);
                  } catch (e) {
                    throw (
                      (c.default(e) &&
                        e.cancelled &&
                        K.events.emit("routeChangeError", e, er, et),
                      e)
                    );
                  }
                  return !0;
                }
                K.events.emit("beforeHistoryChange", r, et),
                  d.changeState(e, t, r, o);
                let P =
                  W && !_ && !V && !en && L.compareRouterStates(b, d.state);
                if (!P) {
                  try {
                    yield d.set(b, n, _);
                  } catch (e) {
                    if (e.cancelled) n.error = n.error || e;
                    else throw e;
                  }
                  if (n.error)
                    throw (
                      (W || K.events.emit("routeChangeError", n.error, er, et),
                      n.error)
                    );
                  G.locale && (document.documentElement.lang = G.locale),
                    W || K.events.emit("routeChangeComplete", r, et),
                    h && /#.+$/.test(r) && d.scrollToHash(r);
                }
                return !0;
              } catch (e) {
                if (c.default(e) && e.cancelled) return !1;
                throw e;
              }
            })();
          }
          changeState(e, t, r) {
            let n =
              arguments.length > 3 && void 0 !== arguments[3]
                ? arguments[3]
                : {};
            ("pushState" !== e || h.getURL() !== r) &&
              ((this._shallow = n.shallow),
              window.history[e](
                {
                  url: t,
                  as: r,
                  options: n,
                  __N: !0,
                  key: (this._key = "pushState" !== e ? this._key : X()),
                },
                "",
                r
              ));
          }
          handleRouteInfoError(e, t, r, a, o, i) {
            var l = this;
            return n(function* () {
              if ((console.error(e), e.cancelled)) throw e;
              if (s.isAssetError(e) || i)
                throw (
                  (K.events.emit("routeChangeError", e, a, o),
                  Y({ url: a, router: l }),
                  $())
                );
              try {
                let n;
                let { page: a, styleSheets: o } = yield l.fetchComponent(
                    "/_error"
                  ),
                  i = {
                    props: n,
                    Component: a,
                    styleSheets: o,
                    err: e,
                    error: e,
                  };
                if (!i.props)
                  try {
                    i.props = yield l.getInitialProps(a, {
                      err: e,
                      pathname: t,
                      query: r,
                    });
                  } catch (e) {
                    console.error("Error in error page `getInitialProps`: ", e),
                      (i.props = {});
                  }
                return i;
              } catch (e) {
                return l.handleRouteInfoError(
                  c.default(e) ? e : Error(e + ""),
                  t,
                  r,
                  a,
                  o,
                  !0
                );
              }
            })();
          }
          getRouteInfo(e) {
            let {
              route: t,
              pathname: r,
              query: o,
              as: i,
              resolvedAs: s,
              routeProps: u,
              locale: d,
              hasMiddleware: p,
              isPreview: h,
              unstable_skipClientCache: m,
              isQueryUpdating: g,
              isMiddlewareRewrite: y,
              isNotFound: v,
            } = e;
            var b = this;
            return n(function* () {
              let e = t;
              try {
                var P, S, w, C;
                let t = J({ route: e, router: b }),
                  c = b.components[e];
                if (u.shallow && c && b.route === e) return c;
                p && (c = void 0);
                let x = !c || "initial" in c ? void 0 : c,
                  O = {
                    dataHref: b.pageLoader.getDataHref({
                      href: _.formatWithValidation({ pathname: r, query: o }),
                      skipInterpolation: !0,
                      asPath: v ? "/404" : s,
                      locale: d,
                    }),
                    hasMiddleware: !0,
                    isServerRender: b.isSsr,
                    parseJSON: !0,
                    inflightCache: g ? b.sbc : b.sdc,
                    persistCache: !h,
                    isPrefetch: !1,
                    unstable_skipClientCache: m,
                    isBackground: g,
                  },
                  M =
                    g && !y
                      ? null
                      : yield q({
                          fetchData: () => V(O),
                          asPath: v ? "/404" : s,
                          locale: d,
                          router: b,
                        }).catch((e) => {
                          if (g) return null;
                          throw e;
                        });
                if (
                  (M &&
                    ("/_error" === r || "/404" === r) &&
                    (M.effect = void 0),
                  g &&
                    (M
                      ? (M.json = self.__NEXT_DATA__.props)
                      : (M = { json: self.__NEXT_DATA__.props })),
                  t(),
                  (null == M
                    ? void 0
                    : null == (P = M.effect)
                    ? void 0
                    : P.type) === "redirect-internal" ||
                    (null == M
                      ? void 0
                      : null == (S = M.effect)
                      ? void 0
                      : S.type) === "redirect-external")
                )
                  return M.effect;
                if (
                  (null == M
                    ? void 0
                    : null == (w = M.effect)
                    ? void 0
                    : w.type) === "rewrite"
                ) {
                  let t = l.removeTrailingSlash(M.effect.resolvedHref),
                    n = yield b.pageLoader.getPageList();
                  if (
                    (!g || n.includes(t)) &&
                    ((e = t),
                    (r = M.effect.resolvedHref),
                    (o = a({}, o, M.effect.parsedAs.query)),
                    (s = E.removeBasePath(
                      f.normalizeLocalePath(
                        M.effect.parsedAs.pathname,
                        b.locales
                      ).pathname
                    )),
                    (c = b.components[e]),
                    u.shallow && c && b.route === e && !p)
                  )
                    return a({}, c, { route: e });
                }
                if (j.isAPIRoute(e))
                  return Y({ url: i, router: b }), new Promise(() => {});
                let L =
                    x ||
                    (yield b
                      .fetchComponent(e)
                      .then((e) => ({
                        Component: e.page,
                        styleSheets: e.styleSheets,
                        __N_SSG: e.mod.__N_SSG,
                        __N_SSP: e.mod.__N_SSP,
                      }))),
                  R =
                    null == M
                      ? void 0
                      : null == (C = M.response)
                      ? void 0
                      : C.headers.get("x-middleware-skip"),
                  T = L.__N_SSG || L.__N_SSP;
                R &&
                  (null == M ? void 0 : M.dataHref) &&
                  delete b.sdc[M.dataHref];
                let { props: A, cacheKey: I } = yield b._getData(
                  n(function* () {
                    if (T) {
                      if ((null == M ? void 0 : M.json) && !R)
                        return { cacheKey: M.cacheKey, props: M.json };
                      let e = (null == M ? void 0 : M.dataHref)
                          ? M.dataHref
                          : b.pageLoader.getDataHref({
                              href: _.formatWithValidation({
                                pathname: r,
                                query: o,
                              }),
                              asPath: s,
                              locale: d,
                            }),
                        t = yield V({
                          dataHref: e,
                          isServerRender: b.isSsr,
                          parseJSON: !0,
                          inflightCache: R ? {} : b.sdc,
                          persistCache: !h,
                          isPrefetch: !1,
                          unstable_skipClientCache: m,
                        });
                      return { cacheKey: t.cacheKey, props: t.json || {} };
                    }
                    return {
                      headers: {},
                      props: yield b.getInitialProps(L.Component, {
                        pathname: r,
                        query: o,
                        asPath: i,
                        locale: d,
                        locales: b.locales,
                        defaultLocale: b.defaultLocale,
                      }),
                    };
                  })
                );
                return (
                  L.__N_SSP && O.dataHref && I && delete b.sdc[I],
                  b.isPreview ||
                    !L.__N_SSG ||
                    g ||
                    V(
                      Object.assign({}, O, {
                        isBackground: !0,
                        persistCache: !1,
                        inflightCache: b.sbc,
                      })
                    ).catch(() => {}),
                  (A.pageProps = Object.assign({}, A.pageProps)),
                  (L.props = A),
                  (L.route = e),
                  (L.query = o),
                  (L.resolvedAs = s),
                  (b.components[e] = L),
                  L
                );
              } catch (e) {
                return b.handleRouteInfoError(c.getProperError(e), r, o, i, u);
              }
            })();
          }
          set(e, t, r) {
            return (
              (this.state = e),
              this.sub(t, this.components["/_app"].Component, r)
            );
          }
          beforePopState(e) {
            this._bps = e;
          }
          onlyAHashChange(e) {
            if (!this.asPath) return !1;
            let [t, r] = this.asPath.split("#"),
              [n, a] = e.split("#");
            return (!!a && t === n && r === a) || (t === n && r !== a);
          }
          scrollToHash(e) {
            let [, t = ""] = e.split("#");
            if ("" === t || "top" === t) {
              k.handleSmoothScroll(() => window.scrollTo(0, 0));
              return;
            }
            let r = decodeURIComponent(t),
              n = document.getElementById(r);
            if (n) {
              k.handleSmoothScroll(() => n.scrollIntoView());
              return;
            }
            let a = document.getElementsByName(r)[0];
            a && k.handleSmoothScroll(() => a.scrollIntoView());
          }
          urlIsNew(e) {
            return this.asPath !== e;
          }
          prefetch(e) {
            let t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : e,
              r =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : {};
            var o = this;
            return n(function* () {
              if (T.isBot(window.navigator.userAgent)) return;
              let n = g.parseRelativeUrl(e),
                { pathname: i, query: s } = n,
                u = i;
              if (!1 === r.locale) {
                (i = f.normalizeLocalePath(i, o.locales).pathname),
                  (n.pathname = i),
                  (e = _.formatWithValidation(n));
                let a = g.parseRelativeUrl(t),
                  l = f.normalizeLocalePath(a.pathname, o.locales);
                (a.pathname = l.pathname),
                  (r.locale = l.detectedLocale || o.defaultLocale),
                  (t = _.formatWithValidation(a));
              }
              let c = yield o.pageLoader.getPageList(),
                d = t,
                p = void 0 !== r.locale ? r.locale || void 0 : o.locale,
                h = yield D({ asPath: t, locale: p, router: o });
              (n.pathname = H(n.pathname, c)),
                m.isDynamicRoute(n.pathname) &&
                  ((i = n.pathname),
                  (n.pathname = i),
                  Object.assign(
                    s,
                    y.getRouteMatcher(v.getRouteRegex(n.pathname))(
                      P.parsePath(t).pathname
                    ) || {}
                  ),
                  h || (e = _.formatWithValidation(n)));
              let b = yield q({
                fetchData: () =>
                  V({
                    dataHref: o.pageLoader.getDataHref({
                      href: _.formatWithValidation({ pathname: u, query: s }),
                      skipInterpolation: !0,
                      asPath: d,
                      locale: p,
                    }),
                    hasMiddleware: !0,
                    isServerRender: o.isSsr,
                    parseJSON: !0,
                    inflightCache: o.sdc,
                    persistCache: !o.isPreview,
                    isPrefetch: !0,
                  }),
                asPath: t,
                locale: p,
                router: o,
              });
              if (
                ((null == b ? void 0 : b.effect.type) === "rewrite" &&
                  ((n.pathname = b.effect.resolvedHref),
                  (i = b.effect.resolvedHref),
                  (s = a({}, s, b.effect.parsedAs.query)),
                  (d = b.effect.parsedAs.pathname),
                  (e = _.formatWithValidation(n))),
                (null == b ? void 0 : b.effect.type) === "redirect-external")
              )
                return;
              let S = l.removeTrailingSlash(i);
              yield Promise.all([
                o.pageLoader
                  ._isSsg(S)
                  .then(
                    (t) =>
                      !!t &&
                      V({
                        dataHref: (null == b ? void 0 : b.json)
                          ? null == b
                            ? void 0
                            : b.dataHref
                          : o.pageLoader.getDataHref({
                              href: e,
                              asPath: d,
                              locale: p,
                            }),
                        isServerRender: !1,
                        parseJSON: !0,
                        inflightCache: o.sdc,
                        persistCache: !o.isPreview,
                        isPrefetch: !0,
                        unstable_skipClientCache:
                          r.unstable_skipClientCache || (r.priority && !0),
                      }).then(() => !1)
                  ),
                o.pageLoader[r.priority ? "loadPage" : "prefetch"](S),
              ]);
            })();
          }
          fetchComponent(e) {
            var t = this;
            return n(function* () {
              let r = J({ route: e, router: t });
              try {
                let n = yield t.pageLoader.loadPage(e);
                return r(), n;
              } catch (e) {
                throw (r(), e);
              }
            })();
          }
          _getData(e) {
            let t = !1,
              r = () => {
                t = !0;
              };
            return (
              (this.clc = r),
              e().then((e) => {
                if ((r === this.clc && (this.clc = null), t)) {
                  let e = Error("Loading initial props cancelled");
                  throw ((e.cancelled = !0), e);
                }
                return e;
              })
            );
          }
          _getFlightData(e) {
            return V({
              dataHref: e,
              isServerRender: !0,
              parseJSON: !1,
              inflightCache: this.sdc,
              persistCache: !1,
              isPrefetch: !1,
            }).then((e) => {
              let { text: t } = e;
              return { data: t };
            });
          }
          getInitialProps(e, t) {
            let { Component: r } = this.components["/_app"],
              n = this._wrapApp(r);
            return (
              (t.AppTree = n),
              h.loadGetInitialProps(r, {
                AppTree: n,
                Component: e,
                router: this,
                ctx: t,
              })
            );
          }
          get route() {
            return this.state.route;
          }
          get pathname() {
            return this.state.pathname;
          }
          get query() {
            return this.state.query;
          }
          get asPath() {
            return this.state.asPath;
          }
          get locale() {
            return this.state.locale;
          }
          get isFallback() {
            return this.state.isFallback;
          }
          get isPreview() {
            return this.state.isPreview;
          }
          constructor(
            e,
            t,
            r,
            {
              initialProps: n,
              pageLoader: a,
              App: o,
              wrapApp: i,
              Component: s,
              err: u,
              subscription: c,
              isFallback: d,
              locale: f,
              locales: p,
              defaultLocale: y,
              domainLocales: v,
              isPreview: P,
            }
          ) {
            (this.sdc = {}),
              (this.sbc = {}),
              (this.isFirstPopStateEvent = !0),
              (this._key = X()),
              (this.onPopState = (e) => {
                let t;
                let { isFirstPopStateEvent: r } = this;
                this.isFirstPopStateEvent = !1;
                let n = e.state;
                if (!n) {
                  let { pathname: e, query: t } = this;
                  this.changeState(
                    "replaceState",
                    _.formatWithValidation({
                      pathname: C.addBasePath(e),
                      query: t,
                    }),
                    h.getURL()
                  );
                  return;
                }
                if (n.__NA) {
                  window.location.reload();
                  return;
                }
                if (
                  !n.__N ||
                  (r &&
                    this.locale === n.options.locale &&
                    n.as === this.asPath)
                )
                  return;
                let { url: a, as: o, options: i, key: l } = n;
                if (Z && this._key !== l) {
                  try {
                    sessionStorage.setItem(
                      "__next_scroll_" + this._key,
                      JSON.stringify({
                        x: self.pageXOffset,
                        y: self.pageYOffset,
                      })
                    );
                  } catch (e) {}
                  try {
                    let e = sessionStorage.getItem("__next_scroll_" + l);
                    t = JSON.parse(e);
                  } catch (e) {
                    t = { x: 0, y: 0 };
                  }
                }
                this._key = l;
                let { pathname: s } = g.parseRelativeUrl(a);
                (!this.isSsr ||
                  o !== C.addBasePath(this.asPath) ||
                  s !== C.addBasePath(this.pathname)) &&
                  (!this._bps || this._bps(n)) &&
                  this.change(
                    "replaceState",
                    a,
                    o,
                    Object.assign({}, i, {
                      shallow: i.shallow && this._shallow,
                      locale: i.locale || this.defaultLocale,
                      _h: 0,
                    }),
                    t
                  );
              });
            let S = l.removeTrailingSlash(e);
            (this.components = {}),
              "/_error" !== e &&
                (this.components[S] = {
                  Component: s,
                  initial: !0,
                  props: n,
                  err: u,
                  __N_SSG: n && n.__N_SSG,
                  __N_SSP: n && n.__N_SSP,
                }),
              (this.components["/_app"] = { Component: o, styleSheets: [] }),
              (this.events = K.events),
              (this.pageLoader = a);
            let w = m.isDynamicRoute(e) && self.__NEXT_DATA__.autoExport;
            if (
              ((this.basePath = ""),
              (this.sub = c),
              (this.clc = null),
              (this._wrapApp = i),
              (this.isSsr = !0),
              (this.isLocaleDomain = !1),
              (this.isReady = !!(
                self.__NEXT_DATA__.gssp ||
                self.__NEXT_DATA__.gip ||
                (self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp) ||
                (!w && !self.location.search)
              )),
              (this.locales = p),
              (this.defaultLocale = y),
              (this.domainLocales = v),
              (this.isLocaleDomain = !!b.detectDomainLocale(
                v,
                self.location.hostname
              )),
              (this.state = {
                route: S,
                pathname: e,
                query: t,
                asPath: w ? e : r,
                isPreview: !!P,
                locale: f,
                isFallback: d,
              }),
              (this._initialMatchesMiddlewarePromise = Promise.resolve(!1)),
              !r.startsWith("//"))
            ) {
              let n = { locale: f },
                a = h.getURL();
              this._initialMatchesMiddlewarePromise = D({
                router: this,
                locale: f,
                asPath: a,
              }).then(
                (o) => (
                  (n._shouldResolveHref = r !== e),
                  this.changeState(
                    "replaceState",
                    o
                      ? a
                      : _.formatWithValidation({
                          pathname: C.addBasePath(e),
                          query: t,
                        }),
                    a,
                    n
                  ),
                  o
                )
              );
            }
            window.addEventListener("popstate", this.onPopState),
              Z && (window.history.scrollRestoration = "manual");
          }
        }
        (K.events = p.default()), (t.default = K);
      },
      62721: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.addLocale = function (e, t, r, o) {
            return t &&
              t !== r &&
              (o ||
                (!a.pathHasPrefix(e.toLowerCase(), `/${t.toLowerCase()}`) &&
                  !a.pathHasPrefix(e.toLowerCase(), "/api")))
              ? n.addPathPrefix(e, `/${t}`)
              : e;
          });
        var n = r(5246),
          a = r(76325);
      },
      5246: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.addPathPrefix = function (e, t) {
            if (!e.startsWith("/") || !t) return e;
            let { pathname: r, query: a, hash: o } = n.parsePath(e);
            return `${t}${r}${a}${o}`;
          });
        var n = r(64046);
      },
      19603: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.addPathSuffix = function (e, t) {
            if (!e.startsWith("/") || !t) return e;
            let { pathname: r, query: a, hash: o } = n.parsePath(e);
            return `${r}${t}${a}${o}`;
          });
        var n = r(64046);
      },
      66385: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.compareRouterStates = function (e, t) {
            let r = Object.keys(e);
            if (r.length !== Object.keys(t).length) return !1;
            for (let n = r.length; n--; ) {
              let a = r[n];
              if ("query" === a) {
                let r = Object.keys(e.query);
                if (r.length !== Object.keys(t.query).length) return !1;
                for (let n = r.length; n--; ) {
                  let a = r[n];
                  if (!t.query.hasOwnProperty(a) || e.query[a] !== t.query[a])
                    return !1;
                }
              } else if (!t.hasOwnProperty(a) || e[a] !== t[a]) return !1;
            }
            return !0;
          });
      },
      79473: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.formatNextPathnameInfo = function (e) {
            let t = i.addLocale(
              e.pathname,
              e.locale,
              e.buildId ? void 0 : e.defaultLocale,
              e.ignorePrefix
            );
            return (
              (e.buildId || !e.trailingSlash) && (t = n.removeTrailingSlash(t)),
              e.buildId &&
                (t = o.addPathSuffix(
                  a.addPathPrefix(t, `/_next/data/${e.buildId}`),
                  "/" === e.pathname ? "index.json" : ".json"
                )),
              (t = a.addPathPrefix(t, e.basePath)),
              !e.buildId && e.trailingSlash
                ? t.endsWith("/")
                  ? t
                  : o.addPathSuffix(t, "/")
                : n.removeTrailingSlash(t)
            );
          });
        var n = r(67734),
          a = r(5246),
          o = r(19603),
          i = r(62721);
      },
      61410: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.formatUrl = o),
          (t.formatWithValidation = function (e) {
            return o(e);
          }),
          (t.urlObjectKeys = void 0);
        var n = (0, r(91598).Z)(r(53908));
        let a = /https?|ftp|gopher|file/;
        function o(e) {
          let { auth: t, hostname: r } = e,
            o = e.protocol || "",
            i = e.pathname || "",
            l = e.hash || "",
            s = e.query || "",
            u = !1;
          (t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : ""),
            e.host
              ? (u = t + e.host)
              : r &&
                ((u = t + (~r.indexOf(":") ? `[${r}]` : r)),
                e.port && (u += ":" + e.port)),
            s &&
              "object" == typeof s &&
              (s = String(n.urlQueryToSearchParams(s)));
          let c = e.search || (s && `?${s}`) || "";
          return (
            o && !o.endsWith(":") && (o += ":"),
            e.slashes || ((!o || a.test(o)) && !1 !== u)
              ? ((u = "//" + (u || "")), i && "/" !== i[0] && (i = "/" + i))
              : u || (u = ""),
            l && "#" !== l[0] && (l = "#" + l),
            c && "?" !== c[0] && (c = "?" + c),
            `${o}${u}${(i = i.replace(/[?#]/g, encodeURIComponent))}${(c =
              c.replace("#", "%23"))}${l}`
          );
        }
        t.urlObjectKeys = [
          "auth",
          "hash",
          "host",
          "hostname",
          "href",
          "path",
          "pathname",
          "port",
          "protocol",
          "query",
          "search",
          "slashes",
        ];
      },
      9184: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function (e) {
            let t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : "",
              r =
                "/" === e
                  ? "/index"
                  : /^\/index(\/|$)/.test(e)
                  ? `/index${e}`
                  : `${e}`;
            return r + t;
          });
      },
      96373: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.getNextPathnameInfo = function (e, t) {
            var r;
            let {
                basePath: i,
                i18n: l,
                trailingSlash: s,
              } = null != (r = t.nextConfig) ? r : {},
              u = {
                pathname: e,
                trailingSlash: "/" !== e ? e.endsWith("/") : s,
              };
            if (
              (i &&
                o.pathHasPrefix(u.pathname, i) &&
                ((u.pathname = a.removePathPrefix(u.pathname, i)),
                (u.basePath = i)),
              !0 === t.parseData &&
                u.pathname.startsWith("/_next/data/") &&
                u.pathname.endsWith(".json"))
            ) {
              let e = u.pathname
                  .replace(/^\/_next\/data\//, "")
                  .replace(/\.json$/, "")
                  .split("/"),
                t = e[0];
              (u.pathname =
                "index" !== e[1] ? `/${e.slice(1).join("/")}` : "/"),
                (u.buildId = t);
            }
            if (l) {
              let e = n.normalizeLocalePath(u.pathname, l.locales);
              (u.locale = null == e ? void 0 : e.detectedLocale),
                (u.pathname = (null == e ? void 0 : e.pathname) || u.pathname);
            }
            return u;
          });
        var n = r(34842),
          a = r(2476),
          o = r(76325);
      },
      3105: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.handleSmoothScroll = function (e) {
            let t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : {},
              r = document.documentElement,
              n = r.style.scrollBehavior;
            (r.style.scrollBehavior = "auto"),
              t.dontForceLayout || r.getClientRects(),
              e(),
              (r.style.scrollBehavior = n);
          });
      },
      919: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          Object.defineProperty(t, "getSortedRoutes", {
            enumerable: !0,
            get: function () {
              return n.getSortedRoutes;
            },
          }),
          Object.defineProperty(t, "isDynamicRoute", {
            enumerable: !0,
            get: function () {
              return a.isDynamicRoute;
            },
          });
        var n = r(49163),
          a = r(63162);
      },
      35036: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.interpolateAs = function (e, t, r) {
            let o = "",
              i = a.getRouteRegex(e),
              l = i.groups,
              s = (t !== e ? n.getRouteMatcher(i)(t) : "") || r;
            o = e;
            let u = Object.keys(l);
            return (
              u.every((e) => {
                let t = s[e] || "",
                  { repeat: r, optional: n } = l[e],
                  a = `[${r ? "..." : ""}${e}]`;
                return (
                  n && (a = `${t ? "" : "/"}[${a}]`),
                  r && !Array.isArray(t) && (t = [t]),
                  (n || e in s) &&
                    (o =
                      o.replace(
                        a,
                        r
                          ? t.map((e) => encodeURIComponent(e)).join("/")
                          : encodeURIComponent(t)
                      ) || "/")
                );
              }) || (o = ""),
              { params: u, result: o }
            );
          });
        var n = r(43978),
          a = r(37762);
      },
      90293: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.isBot = function (e) {
            return /Googlebot|Mediapartners-Google|AdsBot-Google|googleweblight|Storebot-Google|Google-PageRenderer|Bingbot|BingPreview|Slurp|DuckDuckBot|baiduspider|yandex|sogou|LinkedInBot|bitlybot|tumblr|vkShare|quora link preview|facebookexternalhit|facebookcatalog|Twitterbot|applebot|redditbot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|ia_archiver/i.test(
              e
            );
          });
      },
      63162: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.isDynamicRoute = function (e) {
            return r.test(e);
          });
        let r = /\/\[[^/]+?\](?=\/|$)/;
      },
      83353: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.isLocalURL = function (e) {
            if (!n.isAbsoluteUrl(e)) return !0;
            try {
              let t = n.getLocationOrigin(),
                r = new URL(e, t);
              return r.origin === t && a.hasBasePath(r.pathname);
            } catch (e) {
              return !1;
            }
          });
        var n = r(79064),
          a = r(12140);
      },
      35821: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.omit = function (e, t) {
            let r = {};
            return (
              Object.keys(e).forEach((n) => {
                t.includes(n) || (r[n] = e[n]);
              }),
              r
            );
          });
      },
      64046: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.parsePath = function (e) {
            let t = e.indexOf("#"),
              r = e.indexOf("?"),
              n = r > -1 && (t < 0 || r < t);
            return n || t > -1
              ? {
                  pathname: e.substring(0, n ? r : t),
                  query: n ? e.substring(r, t > -1 ? t : void 0) : "",
                  hash: t > -1 ? e.slice(t) : "",
                }
              : { pathname: e, query: "", hash: "" };
          });
      },
      73460: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.parseRelativeUrl = function (e, t) {
            let r = new URL(n.getLocationOrigin()),
              o = t
                ? new URL(t, r)
                : e.startsWith(".")
                ? new URL(window.location.href)
                : r,
              {
                pathname: i,
                searchParams: l,
                search: s,
                hash: u,
                href: c,
                origin: d,
              } = new URL(e, o);
            if (d !== r.origin)
              throw Error(
                `invariant: invalid relative URL, router received ${e}`
              );
            return {
              pathname: i,
              query: a.searchParamsToUrlQuery(l),
              search: s,
              hash: u,
              href: c.slice(r.origin.length),
            };
          });
        var n = r(79064),
          a = r(53908);
      },
      76325: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.pathHasPrefix = function (e, t) {
            if ("string" != typeof e) return !1;
            let { pathname: r } = n.parsePath(e);
            return r === t || r.startsWith(t + "/");
          });
        var n = r(64046);
      },
      53908: function (e, t) {
        "use strict";
        function r(e) {
          return "string" != typeof e &&
            ("number" != typeof e || isNaN(e)) &&
            "boolean" != typeof e
            ? ""
            : String(e);
        }
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.searchParamsToUrlQuery = function (e) {
            let t = {};
            return (
              e.forEach((e, r) => {
                void 0 === t[r]
                  ? (t[r] = e)
                  : Array.isArray(t[r])
                  ? t[r].push(e)
                  : (t[r] = [t[r], e]);
              }),
              t
            );
          }),
          (t.urlQueryToSearchParams = function (e) {
            let t = new URLSearchParams();
            return (
              Object.entries(e).forEach((e) => {
                let [n, a] = e;
                Array.isArray(a)
                  ? a.forEach((e) => t.append(n, r(e)))
                  : t.set(n, r(a));
              }),
              t
            );
          }),
          (t.assign = function (e) {
            for (
              var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1;
              n < t;
              n++
            )
              r[n - 1] = arguments[n];
            return (
              r.forEach((t) => {
                Array.from(t.keys()).forEach((t) => e.delete(t)),
                  t.forEach((t, r) => e.append(r, t));
              }),
              e
            );
          });
      },
      2476: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.removePathPrefix = function (e, t) {
            if (n.pathHasPrefix(e, t)) {
              let r = e.slice(t.length);
              return r.startsWith("/") ? r : `/${r}`;
            }
            return e;
          });
        var n = r(76325);
      },
      67734: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.removeTrailingSlash = function (e) {
            return e.replace(/\/$/, "") || "/";
          });
      },
      14532: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.resolveHref = function (e, t, r) {
            let d;
            let f = "string" == typeof t ? t : a.formatWithValidation(t),
              p = f.match(/^[a-zA-Z]{1,}:\/\//),
              h = p ? f.slice(p[0].length) : f,
              m = h.split("?");
            if ((m[0] || "").match(/(\/\/|\\)/)) {
              console.error(
                `Invalid href '${f}' passed to next/router in page: '${e.pathname}'. Repeated forward-slashes (//) or backslashes \\ are not valid in the href.`
              );
              let t = i.normalizeRepeatedSlashes(h);
              f = (p ? p[0] : "") + t;
            }
            if (!s.isLocalURL(f)) return r ? [f] : f;
            try {
              d = new URL(
                f.startsWith("#") ? e.asPath : e.pathname,
                "http://n"
              );
            } catch (e) {
              d = new URL("/", "http://n");
            }
            try {
              let e = new URL(f, d);
              e.pathname = l.normalizePathTrailingSlash(e.pathname);
              let t = "";
              if (u.isDynamicRoute(e.pathname) && e.searchParams && r) {
                let r = n.searchParamsToUrlQuery(e.searchParams),
                  { result: i, params: l } = c.interpolateAs(
                    e.pathname,
                    e.pathname,
                    r
                  );
                i &&
                  (t = a.formatWithValidation({
                    pathname: i,
                    hash: e.hash,
                    query: o.omit(r, l),
                  }));
              }
              let i =
                e.origin === d.origin ? e.href.slice(e.origin.length) : e.href;
              return r ? [i, t || i] : i;
            } catch (e) {
              return r ? [f] : f;
            }
          });
        var n = r(53908),
          a = r(61410),
          o = r(35821),
          i = r(79064),
          l = r(82387),
          s = r(83353),
          u = r(63162),
          c = r(35036);
      },
      43978: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.getRouteMatcher = function (e) {
            let { re: t, groups: r } = e;
            return (e) => {
              let a = t.exec(e);
              if (!a) return !1;
              let o = (e) => {
                  try {
                    return decodeURIComponent(e);
                  } catch (e) {
                    throw new n.DecodeError("failed to decode param");
                  }
                },
                i = {};
              return (
                Object.keys(r).forEach((e) => {
                  let t = r[e],
                    n = a[t.pos];
                  void 0 !== n &&
                    (i[e] = ~n.indexOf("/")
                      ? n.split("/").map((e) => o(e))
                      : t.repeat
                      ? [o(n)]
                      : o(n));
                }),
                i
              );
            };
          });
        var n = r(79064);
      },
      37762: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.getRouteRegex = s),
          (t.getNamedRouteRegex = function (e) {
            let t = u(e);
            return n({}, s(e), {
              namedRegex: `^${t.namedParameterizedRoute}(?:/)?$`,
              routeKeys: t.routeKeys,
            });
          }),
          (t.getNamedMiddlewareRegex = function (e, t) {
            let { parameterizedRoute: r } = l(e),
              { catchAll: n = !0 } = t;
            if ("/" === r) return { namedRegex: `^/${n ? ".*" : ""}$` };
            let { namedParameterizedRoute: a } = u(e);
            return { namedRegex: `^${a}${n ? "(?:(/.*)?)" : ""}$` };
          });
        var n = r(6495).Z,
          a = r(35987),
          o = r(67734);
        function i(e) {
          let t = e.startsWith("[") && e.endsWith("]");
          t && (e = e.slice(1, -1));
          let r = e.startsWith("...");
          return r && (e = e.slice(3)), { key: e, repeat: r, optional: t };
        }
        function l(e) {
          let t = o.removeTrailingSlash(e).slice(1).split("/"),
            r = {},
            n = 1;
          return {
            parameterizedRoute: t
              .map((e) => {
                if (!(e.startsWith("[") && e.endsWith("]")))
                  return `/${a.escapeStringRegexp(e)}`;
                {
                  let { key: t, optional: a, repeat: o } = i(e.slice(1, -1));
                  return (
                    (r[t] = { pos: n++, repeat: o, optional: a }),
                    o ? (a ? "(?:/(.+?))?" : "/(.+?)") : "/([^/]+?)"
                  );
                }
              })
              .join(""),
            groups: r,
          };
        }
        function s(e) {
          let { parameterizedRoute: t, groups: r } = l(e);
          return { re: RegExp(`^${t}(?:/)?$`), groups: r };
        }
        function u(e) {
          let t, r;
          let n = o.removeTrailingSlash(e).slice(1).split("/"),
            l =
              ((t = 97),
              (r = 1),
              () => {
                let e = "";
                for (let n = 0; n < r; n++)
                  (e += String.fromCharCode(t)), ++t > 122 && (r++, (t = 97));
                return e;
              }),
            s = {};
          return {
            namedParameterizedRoute: n
              .map((e) => {
                if (!(e.startsWith("[") && e.endsWith("]")))
                  return `/${a.escapeStringRegexp(e)}`;
                {
                  let { key: t, optional: r, repeat: n } = i(e.slice(1, -1)),
                    a = t.replace(/\W/g, ""),
                    o = !1;
                  return (
                    (0 === a.length || a.length > 30) && (o = !0),
                    isNaN(parseInt(a.slice(0, 1))) || (o = !0),
                    o && (a = l()),
                    (s[a] = t),
                    n
                      ? r
                        ? `(?:/(?<${a}>.+?))?`
                        : `/(?<${a}>.+?)`
                      : `/(?<${a}>[^/]+?)`
                  );
                }
              })
              .join(""),
            routeKeys: s,
          };
        }
      },
      49163: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.getSortedRoutes = function (e) {
            let t = new r();
            return e.forEach((e) => t.insert(e)), t.smoosh();
          });
        class r {
          insert(e) {
            this._insert(e.split("/").filter(Boolean), [], !1);
          }
          smoosh() {
            return this._smoosh();
          }
          _smoosh() {
            let e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : "/",
              t = [...this.children.keys()].sort();
            null !== this.slugName && t.splice(t.indexOf("[]"), 1),
              null !== this.restSlugName && t.splice(t.indexOf("[...]"), 1),
              null !== this.optionalRestSlugName &&
                t.splice(t.indexOf("[[...]]"), 1);
            let r = t
              .map((t) => this.children.get(t)._smoosh(`${e}${t}/`))
              .reduce((e, t) => [...e, ...t], []);
            if (
              (null !== this.slugName &&
                r.push(
                  ...this.children.get("[]")._smoosh(`${e}[${this.slugName}]/`)
                ),
              !this.placeholder)
            ) {
              let t = "/" === e ? "/" : e.slice(0, -1);
              if (null != this.optionalRestSlugName)
                throw Error(
                  `You cannot define a route with the same specificity as a optional catch-all route ("${t}" and "${t}[[...${this.optionalRestSlugName}]]").`
                );
              r.unshift(t);
            }
            return (
              null !== this.restSlugName &&
                r.push(
                  ...this.children
                    .get("[...]")
                    ._smoosh(`${e}[...${this.restSlugName}]/`)
                ),
              null !== this.optionalRestSlugName &&
                r.push(
                  ...this.children
                    .get("[[...]]")
                    ._smoosh(`${e}[[...${this.optionalRestSlugName}]]/`)
                ),
              r
            );
          }
          _insert(e, t, n) {
            if (0 === e.length) {
              this.placeholder = !1;
              return;
            }
            if (n) throw Error("Catch-all must be the last part of the URL.");
            let a = e[0];
            if (a.startsWith("[") && a.endsWith("]")) {
              let r = a.slice(1, -1),
                i = !1;
              if (
                (r.startsWith("[") &&
                  r.endsWith("]") &&
                  ((r = r.slice(1, -1)), (i = !0)),
                r.startsWith("...") && ((r = r.substring(3)), (n = !0)),
                r.startsWith("[") || r.endsWith("]"))
              )
                throw Error(
                  `Segment names may not start or end with extra brackets ('${r}').`
                );
              if (r.startsWith("."))
                throw Error(
                  `Segment names may not start with erroneous periods ('${r}').`
                );
              function o(e, r) {
                if (null !== e && e !== r)
                  throw Error(
                    `You cannot use different slug names for the same dynamic path ('${e}' !== '${r}').`
                  );
                t.forEach((e) => {
                  if (e === r)
                    throw Error(
                      `You cannot have the same slug name "${r}" repeat within a single dynamic path`
                    );
                  if (e.replace(/\W/g, "") === a.replace(/\W/g, ""))
                    throw Error(
                      `You cannot have the slug names "${e}" and "${r}" differ only by non-word symbols within a single dynamic path`
                    );
                }),
                  t.push(r);
              }
              if (n) {
                if (i) {
                  if (null != this.restSlugName)
                    throw Error(
                      `You cannot use both an required and optional catch-all route at the same level ("[...${this.restSlugName}]" and "${e[0]}" ).`
                    );
                  o(this.optionalRestSlugName, r),
                    (this.optionalRestSlugName = r),
                    (a = "[[...]]");
                } else {
                  if (null != this.optionalRestSlugName)
                    throw Error(
                      `You cannot use both an optional and required catch-all route at the same level ("[[...${this.optionalRestSlugName}]]" and "${e[0]}").`
                    );
                  o(this.restSlugName, r),
                    (this.restSlugName = r),
                    (a = "[...]");
                }
              } else {
                if (i)
                  throw Error(
                    `Optional route parameters are not yet supported ("${e[0]}").`
                  );
                o(this.slugName, r), (this.slugName = r), (a = "[]");
              }
            }
            this.children.has(a) || this.children.set(a, new r()),
              this.children.get(a)._insert(e.slice(1), t, n);
          }
          constructor() {
            (this.placeholder = !0),
              (this.children = new Map()),
              (this.slugName = null),
              (this.restSlugName = null),
              (this.optionalRestSlugName = null);
          }
        }
      },
      7905: function (e, t) {
        "use strict";
        let r;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.setConfig = function (e) {
            r = e;
          }),
          (t.default = void 0),
          (t.default = () => r),
          ("function" == typeof t.default ||
            ("object" == typeof t.default && null !== t.default)) &&
            void 0 === t.default.__esModule &&
            (Object.defineProperty(t.default, "__esModule", { value: !0 }),
            Object.assign(t.default, t),
            (e.exports = t.default));
      },
      63962: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = function (e) {
            let { headManager: t, reduceComponentsToState: r } = e;
            function l() {
              if (t && t.mountedInstances) {
                let a = n.Children.toArray(
                  Array.from(t.mountedInstances).filter(Boolean)
                );
                t.updateHead(r(a, e));
              }
            }
            if (a) {
              var s;
              null == t ||
                null == (s = t.mountedInstances) ||
                s.add(e.children),
                l();
            }
            return (
              o(() => {
                var r;
                return (
                  null == t ||
                    null == (r = t.mountedInstances) ||
                    r.add(e.children),
                  () => {
                    var r;
                    null == t ||
                      null == (r = t.mountedInstances) ||
                      r.delete(e.children);
                  }
                );
              }),
              o(
                () => (
                  t && (t._pendingUpdate = l),
                  () => {
                    t && (t._pendingUpdate = l);
                  }
                )
              ),
              i(
                () => (
                  t &&
                    t._pendingUpdate &&
                    (t._pendingUpdate(), (t._pendingUpdate = null)),
                  () => {
                    t &&
                      t._pendingUpdate &&
                      (t._pendingUpdate(), (t._pendingUpdate = null));
                  }
                )
              ),
              null
            );
          });
        var n = (0, r(91598).Z)(r(67294));
        let a = !1,
          o = a ? () => {} : n.useLayoutEffect,
          i = a ? () => {} : n.useEffect;
      },
      79064: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.execOnce = function (e) {
            let t,
              r = !1;
            return function () {
              for (var n = arguments.length, a = Array(n), o = 0; o < n; o++)
                a[o] = arguments[o];
              return r || ((r = !0), (t = e(...a))), t;
            };
          }),
          (t.getLocationOrigin = i),
          (t.getURL = function () {
            let { href: e } = window.location,
              t = i();
            return e.substring(t.length);
          }),
          (t.getDisplayName = l),
          (t.isResSent = s),
          (t.normalizeRepeatedSlashes = function (e) {
            let t = e.split("?"),
              r = t[0];
            return (
              r.replace(/\\/g, "/").replace(/\/\/+/g, "/") +
              (t[1] ? `?${t.slice(1).join("?")}` : "")
            );
          }),
          (t.loadGetInitialProps = u),
          (t.ST = t.SP = t.isAbsoluteUrl = t.WEB_VITALS = void 0);
        var n = r(60932).Z;
        t.WEB_VITALS = ["CLS", "FCP", "FID", "INP", "LCP", "TTFB"];
        let a = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/,
          o = (e) => a.test(e);
        function i() {
          let { protocol: e, hostname: t, port: r } = window.location;
          return `${e}//${t}${r ? ":" + r : ""}`;
        }
        function l(e) {
          return "string" == typeof e
            ? e
            : e.displayName || e.name || "Unknown";
        }
        function s(e) {
          return e.finished || e.headersSent;
        }
        function u(e, t) {
          return c.apply(this, arguments);
        }
        function c() {
          return (c = n(function* (e, t) {
            let r = t.res || (t.ctx && t.ctx.res);
            if (!e.getInitialProps)
              return t.ctx && t.Component
                ? { pageProps: yield u(t.Component, t.ctx) }
                : {};
            let n = yield e.getInitialProps(t);
            if (r && s(r)) return n;
            if (!n) {
              let t = `"${l(
                e
              )}.getInitialProps()" should resolve to an object. But found "${n}" instead.`;
              throw Error(t);
            }
            return n;
          })).apply(this, arguments);
        }
        t.isAbsoluteUrl = o;
        let d = "undefined" != typeof performance;
        t.SP = d;
        let f =
          d &&
          ["mark", "measure", "getEntriesByName"].every(
            (e) => "function" == typeof performance[e]
          );
        (t.ST = f),
          (t.DecodeError = class extends Error {}),
          (t.NormalizeError = class extends Error {}),
          (t.PageNotFoundError = class extends Error {
            constructor(e) {
              super(),
                (this.code = "ENOENT"),
                (this.message = `Cannot find module for page: ${e}`);
            }
          }),
          (t.MissingStaticPage = class extends Error {
            constructor(e, t) {
              super(),
                (this.message = `Failed to load static file for page: ${e} ${t}`);
            }
          }),
          (t.MiddlewareNotFoundError = class extends Error {
            constructor() {
              super(),
                (this.code = "ENOENT"),
                (this.message = "Cannot find the middleware module");
            }
          });
      },
      34210: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.warnOnce = void 0);
        let r = (e) => {};
        t.warnOnce = r;
      },
      59917: function (e) {
        var t,
          r,
          n,
          a,
          o,
          i,
          l,
          s,
          u,
          c,
          d,
          f,
          p,
          h,
          m,
          g,
          y,
          v,
          _,
          b,
          P,
          S,
          w,
          E,
          C,
          x,
          j,
          O,
          M,
          L,
          R,
          T,
          A,
          I,
          N,
          k,
          $,
          D,
          B,
          F,
          U,
          H,
          q,
          W,
          Z,
          z,
          G,
          V,
          X,
          Y,
          J,
          K,
          Q,
          ee;
        ((t = {}).d = function (e, r) {
          for (var n in r)
            t.o(r, n) &&
              !t.o(e, n) &&
              Object.defineProperty(e, n, { enumerable: !0, get: r[n] });
        }),
          (t.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
          }),
          (t.r = function (e) {
            "undefined" != typeof Symbol &&
              Symbol.toStringTag &&
              Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
              Object.defineProperty(e, "__esModule", { value: !0 });
          }),
          void 0 !== t && (t.ab = "//"),
          (r = {}),
          t.r(r),
          t.d(r, {
            onCLS: function () {
              return j;
            },
            onFCP: function () {
              return O;
            },
            onFID: function () {
              return k;
            },
            onINP: function () {
              return X;
            },
            onLCP: function () {
              return J;
            },
            onTTFB: function () {
              return ee;
            },
          }),
          (s = function () {
            return (
              window.performance &&
              performance.getEntriesByType &&
              performance.getEntriesByType("navigation")[0]
            );
          }),
          (u = function (e) {
            if ("loading" === document.readyState) return "loading";
            var t = s();
            if (t) {
              if (e < t.domInteractive) return "loading";
              if (
                0 === t.domContentLoadedEventStart ||
                e < t.domContentLoadedEventStart
              )
                return "dom-interactive";
              if (0 === t.domComplete || e < t.domComplete)
                return "dom-content-loaded";
            }
            return "complete";
          }),
          (c = function (e) {
            var t = e.nodeName;
            return 1 === e.nodeType
              ? t.toLowerCase()
              : t.toUpperCase().replace(/^#/, "");
          }),
          (d = function (e, t) {
            var r = "";
            try {
              for (; e && 9 !== e.nodeType; ) {
                var n = e,
                  a = n.id
                    ? "#" + n.id
                    : c(n) +
                      (n.className && n.className.length
                        ? "." + n.className.replace(/\s+/g, ".")
                        : "");
                if (r.length + a.length > (t || 100) - 1) return r || a;
                if (((r = r ? a + ">" + r : a), n.id)) break;
                e = n.parentNode;
              }
            } catch (e) {}
            return r;
          }),
          (f = -1),
          (p = function () {
            return f;
          }),
          (h = function (e) {
            addEventListener(
              "pageshow",
              function (t) {
                t.persisted && ((f = t.timeStamp), e(t));
              },
              !0
            );
          }),
          (m = function () {
            var e = s();
            return (e && e.activationStart) || 0;
          }),
          (g = function (e, t) {
            var r = s(),
              n = "navigate";
            return (
              p() >= 0
                ? (n = "back-forward-cache")
                : r &&
                  (n =
                    document.prerendering || m() > 0
                      ? "prerender"
                      : r.type.replace(/_/g, "-")),
              {
                name: e,
                value: void 0 === t ? -1 : t,
                rating: "good",
                delta: 0,
                entries: [],
                id: "v3-"
                  .concat(Date.now(), "-")
                  .concat(Math.floor(8999999999999 * Math.random()) + 1e12),
                navigationType: n,
              }
            );
          }),
          (y = function (e, t, r) {
            try {
              if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                var n = new PerformanceObserver(function (e) {
                  t(e.getEntries());
                });
                return (
                  n.observe(Object.assign({ type: e, buffered: !0 }, r || {})),
                  n
                );
              }
            } catch (e) {}
          }),
          (v = function (e, t) {
            var r = function r(n) {
              ("pagehide" !== n.type &&
                "hidden" !== document.visibilityState) ||
                (e(n),
                t &&
                  (removeEventListener("visibilitychange", r, !0),
                  removeEventListener("pagehide", r, !0)));
            };
            addEventListener("visibilitychange", r, !0),
              addEventListener("pagehide", r, !0);
          }),
          (_ = function (e, t, r, n) {
            var a, o;
            return function (i) {
              var l;
              t.value >= 0 &&
                (i || n) &&
                ((o = t.value - (a || 0)) || void 0 === a) &&
                ((a = t.value),
                (t.delta = o),
                (t.rating =
                  (l = t.value) > r[1]
                    ? "poor"
                    : l > r[0]
                    ? "needs-improvement"
                    : "good"),
                e(t));
            };
          }),
          (b = -1),
          (P = function () {
            return "hidden" !== document.visibilityState ||
              document.prerendering
              ? 1 / 0
              : 0;
          }),
          (S = function () {
            v(function (e) {
              b = e.timeStamp;
            }, !0);
          }),
          (w = function () {
            return (
              b < 0 &&
                ((b = P()),
                S(),
                h(function () {
                  setTimeout(function () {
                    (b = P()), S();
                  }, 0);
                })),
              {
                get firstHiddenTime() {
                  return b;
                },
              }
            );
          }),
          (E = function (e, t) {
            t = t || {};
            var r,
              n = [1800, 3e3],
              a = w(),
              o = g("FCP"),
              i = function (e) {
                e.forEach(function (e) {
                  "first-contentful-paint" === e.name &&
                    (s && s.disconnect(),
                    e.startTime < a.firstHiddenTime &&
                      ((o.value = e.startTime - m()),
                      o.entries.push(e),
                      r(!0)));
                });
              },
              l =
                window.performance &&
                window.performance.getEntriesByName &&
                window.performance.getEntriesByName(
                  "first-contentful-paint"
                )[0],
              s = l ? null : y("paint", i);
            (l || s) &&
              ((r = _(e, o, n, t.reportAllChanges)),
              l && i([l]),
              h(function (a) {
                (r = _(e, (o = g("FCP")), n, t.reportAllChanges)),
                  requestAnimationFrame(function () {
                    requestAnimationFrame(function () {
                      (o.value = performance.now() - a.timeStamp), r(!0);
                    });
                  });
              }));
          }),
          (C = !1),
          (x = -1),
          (j = function (e, t) {
            var r, n, a, o, i, l, s, c, f, p;
            (r = function (t) {
              (function (e) {
                if (e.entries.length) {
                  var t,
                    r = e.entries.reduce(function (e, t) {
                      return e && e.value > t.value ? e : t;
                    });
                  if (r && r.sources && r.sources.length) {
                    var n =
                      (t = r.sources).find(function (e) {
                        return e.node && 1 === e.node.nodeType;
                      }) || t[0];
                    n &&
                      (e.attribution = {
                        largestShiftTarget: d(n.node),
                        largestShiftTime: r.startTime,
                        largestShiftValue: r.value,
                        largestShiftSource: n,
                        largestShiftEntry: r,
                        loadState: u(r.startTime),
                      });
                  }
                } else e.attribution = {};
              })(t),
                e(t);
            }),
              (n = (n = t) || {}),
              (a = [0.1, 0.25]),
              C ||
                (E(function (e) {
                  x = e.value;
                }),
                (C = !0)),
              (i = function (e) {
                x > -1 && r(e);
              }),
              (l = g("CLS", 0)),
              (s = 0),
              (c = []),
              (p = y(
                "layout-shift",
                (f = function (e) {
                  e.forEach(function (e) {
                    if (!e.hadRecentInput) {
                      var t = c[0],
                        r = c[c.length - 1];
                      s &&
                      e.startTime - r.startTime < 1e3 &&
                      e.startTime - t.startTime < 5e3
                        ? ((s += e.value), c.push(e))
                        : ((s = e.value), (c = [e])),
                        s > l.value && ((l.value = s), (l.entries = c), o());
                    }
                  });
                })
              )) &&
                ((o = _(i, l, a, n.reportAllChanges)),
                v(function () {
                  f(p.takeRecords()), o(!0);
                }),
                h(function () {
                  (s = 0),
                    (x = -1),
                    (o = _(i, (l = g("CLS", 0)), a, n.reportAllChanges));
                }));
          }),
          (O = function (e, t) {
            E(function (t) {
              (function (e) {
                if (e.entries.length) {
                  var t = s(),
                    r = e.entries[e.entries.length - 1];
                  if (t) {
                    var n = t.activationStart || 0,
                      a = Math.max(0, t.responseStart - n);
                    e.attribution = {
                      timeToFirstByte: a,
                      firstByteToFCP: e.value - a,
                      loadState: u(e.entries[0].startTime),
                      navigationEntry: t,
                      fcpEntry: r,
                    };
                  }
                } else
                  e.attribution = {
                    timeToFirstByte: 0,
                    firstByteToFCP: e.value,
                    loadState: u(p()),
                  };
              })(t),
                e(t);
            }, t);
          }),
          (M = { passive: !0, capture: !0 }),
          (L = new Date()),
          (R = function (e, t) {
            n ||
              ((n = t), (a = e), (o = new Date()), I(removeEventListener), T());
          }),
          (T = function () {
            if (a >= 0 && a < o - L) {
              var e = {
                entryType: "first-input",
                name: n.type,
                target: n.target,
                cancelable: n.cancelable,
                startTime: n.timeStamp,
                processingStart: n.timeStamp + a,
              };
              i.forEach(function (t) {
                t(e);
              }),
                (i = []);
            }
          }),
          (A = function (e) {
            if (e.cancelable) {
              var t,
                r,
                n,
                a =
                  (e.timeStamp > 1e12 ? new Date() : performance.now()) -
                  e.timeStamp;
              "pointerdown" == e.type
                ? ((t = function () {
                    R(a, e), n();
                  }),
                  (r = function () {
                    n();
                  }),
                  (n = function () {
                    removeEventListener("pointerup", t, M),
                      removeEventListener("pointercancel", r, M);
                  }),
                  addEventListener("pointerup", t, M),
                  addEventListener("pointercancel", r, M))
                : R(a, e);
            }
          }),
          (I = function (e) {
            ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(
              function (t) {
                return e(t, A, M);
              }
            );
          }),
          (N = function (e, t) {
            t = t || {};
            var r,
              o = [100, 300],
              l = w(),
              s = g("FID"),
              u = function (e) {
                e.startTime < l.firstHiddenTime &&
                  ((s.value = e.processingStart - e.startTime),
                  s.entries.push(e),
                  r(!0));
              },
              c = function (e) {
                e.forEach(u);
              },
              d = y("first-input", c);
            (r = _(e, s, o, t.reportAllChanges)),
              d &&
                v(function () {
                  c(d.takeRecords()), d.disconnect();
                }, !0),
              d &&
                h(function () {
                  (r = _(e, (s = g("FID")), o, t.reportAllChanges)),
                    (i = []),
                    (a = -1),
                    (n = null),
                    I(addEventListener),
                    i.push(u),
                    T();
                });
          }),
          (k = function (e, t) {
            N(function (t) {
              var r, n;
              (n = (r = t).entries[0]),
                (r.attribution = {
                  eventTarget: d(n.target),
                  eventType: n.name,
                  eventTime: n.startTime,
                  eventEntry: n,
                  loadState: u(n.startTime),
                }),
                e(t);
            }, t);
          }),
          ($ = 0),
          (D = 1 / 0),
          (B = 0),
          (F = function (e) {
            e.forEach(function (e) {
              e.interactionId &&
                ((D = Math.min(D, e.interactionId)),
                ($ = (B = Math.max(B, e.interactionId)) ? (B - D) / 7 + 1 : 0));
            });
          }),
          (U = function () {
            return l ? $ : performance.interactionCount || 0;
          }),
          (H = function () {
            "interactionCount" in performance ||
              l ||
              (l = y("event", F, {
                type: "event",
                buffered: !0,
                durationThreshold: 0,
              }));
          }),
          (q = 0),
          (W = function () {
            return U() - q;
          }),
          (Z = []),
          (z = {}),
          (G = function (e) {
            var t = Z[Z.length - 1],
              r = z[e.interactionId];
            if (r || Z.length < 10 || e.duration > t.latency) {
              if (r)
                r.entries.push(e),
                  (r.latency = Math.max(r.latency, e.duration));
              else {
                var n = {
                  id: e.interactionId,
                  latency: e.duration,
                  entries: [e],
                };
                (z[n.id] = n), Z.push(n);
              }
              Z.sort(function (e, t) {
                return t.latency - e.latency;
              }),
                Z.splice(10).forEach(function (e) {
                  delete z[e.id];
                });
            }
          }),
          (V = function (e, t) {
            t = t || {};
            var r = [200, 500];
            H();
            var n,
              a = g("INP"),
              o = function (e) {
                e.forEach(function (e) {
                  e.interactionId && G(e),
                    "first-input" !== e.entryType ||
                      Z.some(function (t) {
                        return t.entries.some(function (t) {
                          return (
                            e.duration === t.duration &&
                            e.startTime === t.startTime
                          );
                        });
                      }) ||
                      G(e);
                });
                var t,
                  r =
                    ((t = Math.min(Z.length - 1, Math.floor(W() / 50))), Z[t]);
                r &&
                  r.latency !== a.value &&
                  ((a.value = r.latency), (a.entries = r.entries), n());
              },
              i = y("event", o, {
                durationThreshold: t.durationThreshold || 40,
              });
            (n = _(e, a, r, t.reportAllChanges)),
              i &&
                (i.observe({ type: "first-input", buffered: !0 }),
                v(function () {
                  o(i.takeRecords()),
                    a.value < 0 && W() > 0 && ((a.value = 0), (a.entries = [])),
                    n(!0);
                }),
                h(function () {
                  (Z = []),
                    (q = U()),
                    (n = _(e, (a = g("INP")), r, t.reportAllChanges));
                }));
          }),
          (X = function (e, t) {
            V(function (t) {
              (function (e) {
                if (e.entries.length) {
                  var t = e.entries.sort(function (e, t) {
                    return (
                      t.duration - e.duration ||
                      t.processingEnd -
                        t.processingStart -
                        (e.processingEnd - e.processingStart)
                    );
                  })[0];
                  e.attribution = {
                    eventTarget: d(t.target),
                    eventType: t.name,
                    eventTime: t.startTime,
                    eventEntry: t,
                    loadState: u(t.startTime),
                  };
                } else e.attribution = {};
              })(t),
                e(t);
            }, t);
          }),
          (Y = {}),
          (J = function (e, t) {
            !(function (e, t) {
              t = t || {};
              var r,
                n = [2500, 4e3],
                a = w(),
                o = g("LCP"),
                i = function (e) {
                  var t = e[e.length - 1];
                  if (t) {
                    var n = t.startTime - m();
                    n < a.firstHiddenTime &&
                      ((o.value = n), (o.entries = [t]), r());
                  }
                },
                l = y("largest-contentful-paint", i);
              if (l) {
                r = _(e, o, n, t.reportAllChanges);
                var s = function () {
                  Y[o.id] ||
                    (i(l.takeRecords()), l.disconnect(), (Y[o.id] = !0), r(!0));
                };
                ["keydown", "click"].forEach(function (e) {
                  addEventListener(e, s, { once: !0, capture: !0 });
                }),
                  v(s, !0),
                  h(function (a) {
                    (r = _(e, (o = g("LCP")), n, t.reportAllChanges)),
                      requestAnimationFrame(function () {
                        requestAnimationFrame(function () {
                          (o.value = performance.now() - a.timeStamp),
                            (Y[o.id] = !0),
                            r(!0);
                        });
                      });
                  });
              }
            })(function (t) {
              (function (e) {
                if (e.entries.length) {
                  var t = s();
                  if (t) {
                    var r = t.activationStart || 0,
                      n = e.entries[e.entries.length - 1],
                      a =
                        n.url &&
                        performance
                          .getEntriesByType("resource")
                          .filter(function (e) {
                            return e.name === n.url;
                          })[0],
                      o = Math.max(0, t.responseStart - r),
                      i = Math.max(
                        o,
                        a ? (a.requestStart || a.startTime) - r : 0
                      ),
                      l = Math.max(i, a ? a.responseEnd - r : 0),
                      u = Math.max(l, n ? n.startTime - r : 0),
                      c = {
                        element: d(n.element),
                        timeToFirstByte: o,
                        resourceLoadDelay: i - o,
                        resourceLoadTime: l - i,
                        elementRenderDelay: u - l,
                        navigationEntry: t,
                        lcpEntry: n,
                      };
                    n.url && (c.url = n.url),
                      a && (c.lcpResourceEntry = a),
                      (e.attribution = c);
                  }
                } else
                  e.attribution = {
                    timeToFirstByte: 0,
                    resourceLoadDelay: 0,
                    resourceLoadTime: 0,
                    elementRenderDelay: e.value,
                  };
              })(t),
                e(t);
            }, t);
          }),
          (K = function e(t) {
            document.prerendering
              ? addEventListener(
                  "prerenderingchange",
                  function () {
                    return e(t);
                  },
                  !0
                )
              : "complete" !== document.readyState
              ? addEventListener(
                  "load",
                  function () {
                    return e(t);
                  },
                  !0
                )
              : setTimeout(t, 0);
          }),
          (Q = function (e, t) {
            t = t || {};
            var r = [800, 1800],
              n = g("TTFB"),
              a = _(e, n, r, t.reportAllChanges);
            K(function () {
              var o = s();
              if (o) {
                if (
                  ((n.value = Math.max(o.responseStart - m(), 0)),
                  n.value < 0 || n.value > performance.now())
                )
                  return;
                (n.entries = [o]),
                  a(!0),
                  h(function () {
                    (a = _(e, (n = g("TTFB", 0)), r, t.reportAllChanges))(!0);
                  });
              }
            });
          }),
          (ee = function (e, t) {
            Q(function (t) {
              (function (e) {
                if (e.entries.length) {
                  var t = e.entries[0],
                    r = t.activationStart || 0,
                    n = Math.max(t.domainLookupStart - r, 0),
                    a = Math.max(t.connectStart - r, 0),
                    o = Math.max(t.requestStart - r, 0);
                  e.attribution = {
                    waitingTime: n,
                    dnsTime: a - n,
                    connectionTime: o - a,
                    requestTime: e.value - o,
                    navigationEntry: t,
                  };
                } else
                  e.attribution = {
                    waitingTime: 0,
                    dnsTime: 0,
                    connectionTime: 0,
                    requestTime: 0,
                  };
              })(t),
                e(t);
            }, t);
          }),
          (e.exports = r);
      },
      78018: function (e) {
        var t,
          r,
          n,
          a,
          o,
          i,
          l,
          s,
          u,
          c,
          d,
          f,
          p,
          h,
          m,
          g,
          y,
          v,
          _,
          b,
          P,
          S,
          w,
          E,
          C,
          x,
          j,
          O,
          M,
          L,
          R,
          T,
          A,
          I,
          N,
          k,
          $,
          D,
          B,
          F,
          U,
          H,
          q,
          W,
          Z,
          z;
        ((t = {}).d = function (e, r) {
          for (var n in r)
            t.o(r, n) &&
              !t.o(e, n) &&
              Object.defineProperty(e, n, { enumerable: !0, get: r[n] });
        }),
          (t.o = function (e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
          }),
          (t.r = function (e) {
            "undefined" != typeof Symbol &&
              Symbol.toStringTag &&
              Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
              Object.defineProperty(e, "__esModule", { value: !0 });
          }),
          void 0 !== t && (t.ab = "//"),
          (r = {}),
          t.r(r),
          t.d(r, {
            getCLS: function () {
              return w;
            },
            getFCP: function () {
              return b;
            },
            getFID: function () {
              return L;
            },
            getINP: function () {
              return H;
            },
            getLCP: function () {
              return W;
            },
            getTTFB: function () {
              return z;
            },
            onCLS: function () {
              return w;
            },
            onFCP: function () {
              return b;
            },
            onFID: function () {
              return L;
            },
            onINP: function () {
              return H;
            },
            onLCP: function () {
              return W;
            },
            onTTFB: function () {
              return z;
            },
          }),
          (s = -1),
          (u = function (e) {
            addEventListener(
              "pageshow",
              function (t) {
                t.persisted && ((s = t.timeStamp), e(t));
              },
              !0
            );
          }),
          (c = function () {
            return (
              window.performance &&
              performance.getEntriesByType &&
              performance.getEntriesByType("navigation")[0]
            );
          }),
          (d = function () {
            var e = c();
            return (e && e.activationStart) || 0;
          }),
          (f = function (e, t) {
            var r = c(),
              n = "navigate";
            return (
              s >= 0
                ? (n = "back-forward-cache")
                : r &&
                  (n =
                    document.prerendering || d() > 0
                      ? "prerender"
                      : r.type.replace(/_/g, "-")),
              {
                name: e,
                value: void 0 === t ? -1 : t,
                rating: "good",
                delta: 0,
                entries: [],
                id: "v3-"
                  .concat(Date.now(), "-")
                  .concat(Math.floor(8999999999999 * Math.random()) + 1e12),
                navigationType: n,
              }
            );
          }),
          (p = function (e, t, r) {
            try {
              if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                var n = new PerformanceObserver(function (e) {
                  t(e.getEntries());
                });
                return (
                  n.observe(Object.assign({ type: e, buffered: !0 }, r || {})),
                  n
                );
              }
            } catch (e) {}
          }),
          (h = function (e, t) {
            var r = function r(n) {
              ("pagehide" !== n.type &&
                "hidden" !== document.visibilityState) ||
                (e(n),
                t &&
                  (removeEventListener("visibilitychange", r, !0),
                  removeEventListener("pagehide", r, !0)));
            };
            addEventListener("visibilitychange", r, !0),
              addEventListener("pagehide", r, !0);
          }),
          (m = function (e, t, r, n) {
            var a, o;
            return function (i) {
              var l;
              t.value >= 0 &&
                (i || n) &&
                ((o = t.value - (a || 0)) || void 0 === a) &&
                ((a = t.value),
                (t.delta = o),
                (t.rating =
                  (l = t.value) > r[1]
                    ? "poor"
                    : l > r[0]
                    ? "needs-improvement"
                    : "good"),
                e(t));
            };
          }),
          (g = -1),
          (y = function () {
            return "hidden" !== document.visibilityState ||
              document.prerendering
              ? 1 / 0
              : 0;
          }),
          (v = function () {
            h(function (e) {
              g = e.timeStamp;
            }, !0);
          }),
          (_ = function () {
            return (
              g < 0 &&
                ((g = y()),
                v(),
                u(function () {
                  setTimeout(function () {
                    (g = y()), v();
                  }, 0);
                })),
              {
                get firstHiddenTime() {
                  return g;
                },
              }
            );
          }),
          (b = function (e, t) {
            t = t || {};
            var r,
              n = [1800, 3e3],
              a = _(),
              o = f("FCP"),
              i = function (e) {
                e.forEach(function (e) {
                  "first-contentful-paint" === e.name &&
                    (s && s.disconnect(),
                    e.startTime < a.firstHiddenTime &&
                      ((o.value = e.startTime - d()),
                      o.entries.push(e),
                      r(!0)));
                });
              },
              l =
                window.performance &&
                window.performance.getEntriesByName &&
                window.performance.getEntriesByName(
                  "first-contentful-paint"
                )[0],
              s = l ? null : p("paint", i);
            (l || s) &&
              ((r = m(e, o, n, t.reportAllChanges)),
              l && i([l]),
              u(function (a) {
                (r = m(e, (o = f("FCP")), n, t.reportAllChanges)),
                  requestAnimationFrame(function () {
                    requestAnimationFrame(function () {
                      (o.value = performance.now() - a.timeStamp), r(!0);
                    });
                  });
              }));
          }),
          (P = !1),
          (S = -1),
          (w = function (e, t) {
            t = t || {};
            var r = [0.1, 0.25];
            P ||
              (b(function (e) {
                S = e.value;
              }),
              (P = !0));
            var n,
              a = function (t) {
                S > -1 && e(t);
              },
              o = f("CLS", 0),
              i = 0,
              l = [],
              s = function (e) {
                e.forEach(function (e) {
                  if (!e.hadRecentInput) {
                    var t = l[0],
                      r = l[l.length - 1];
                    i &&
                    e.startTime - r.startTime < 1e3 &&
                    e.startTime - t.startTime < 5e3
                      ? ((i += e.value), l.push(e))
                      : ((i = e.value), (l = [e])),
                      i > o.value && ((o.value = i), (o.entries = l), n());
                  }
                });
              },
              c = p("layout-shift", s);
            c &&
              ((n = m(a, o, r, t.reportAllChanges)),
              h(function () {
                s(c.takeRecords()), n(!0);
              }),
              u(function () {
                (i = 0),
                  (S = -1),
                  (n = m(a, (o = f("CLS", 0)), r, t.reportAllChanges));
              }));
          }),
          (E = { passive: !0, capture: !0 }),
          (C = new Date()),
          (x = function (e, t) {
            n ||
              ((n = t), (a = e), (o = new Date()), M(removeEventListener), j());
          }),
          (j = function () {
            if (a >= 0 && a < o - C) {
              var e = {
                entryType: "first-input",
                name: n.type,
                target: n.target,
                cancelable: n.cancelable,
                startTime: n.timeStamp,
                processingStart: n.timeStamp + a,
              };
              i.forEach(function (t) {
                t(e);
              }),
                (i = []);
            }
          }),
          (O = function (e) {
            if (e.cancelable) {
              var t,
                r,
                n,
                a =
                  (e.timeStamp > 1e12 ? new Date() : performance.now()) -
                  e.timeStamp;
              "pointerdown" == e.type
                ? ((t = function () {
                    x(a, e), n();
                  }),
                  (r = function () {
                    n();
                  }),
                  (n = function () {
                    removeEventListener("pointerup", t, E),
                      removeEventListener("pointercancel", r, E);
                  }),
                  addEventListener("pointerup", t, E),
                  addEventListener("pointercancel", r, E))
                : x(a, e);
            }
          }),
          (M = function (e) {
            ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(
              function (t) {
                return e(t, O, E);
              }
            );
          }),
          (L = function (e, t) {
            t = t || {};
            var r,
              o = [100, 300],
              l = _(),
              s = f("FID"),
              c = function (e) {
                e.startTime < l.firstHiddenTime &&
                  ((s.value = e.processingStart - e.startTime),
                  s.entries.push(e),
                  r(!0));
              },
              d = function (e) {
                e.forEach(c);
              },
              g = p("first-input", d);
            (r = m(e, s, o, t.reportAllChanges)),
              g &&
                h(function () {
                  d(g.takeRecords()), g.disconnect();
                }, !0),
              g &&
                u(function () {
                  (r = m(e, (s = f("FID")), o, t.reportAllChanges)),
                    (i = []),
                    (a = -1),
                    (n = null),
                    M(addEventListener),
                    i.push(c),
                    j();
                });
          }),
          (R = 0),
          (T = 1 / 0),
          (A = 0),
          (I = function (e) {
            e.forEach(function (e) {
              e.interactionId &&
                ((T = Math.min(T, e.interactionId)),
                (R = (A = Math.max(A, e.interactionId)) ? (A - T) / 7 + 1 : 0));
            });
          }),
          (N = function () {
            return l ? R : performance.interactionCount || 0;
          }),
          (k = function () {
            "interactionCount" in performance ||
              l ||
              (l = p("event", I, {
                type: "event",
                buffered: !0,
                durationThreshold: 0,
              }));
          }),
          ($ = 0),
          (D = function () {
            return N() - $;
          }),
          (B = []),
          (F = {}),
          (U = function (e) {
            var t = B[B.length - 1],
              r = F[e.interactionId];
            if (r || B.length < 10 || e.duration > t.latency) {
              if (r)
                r.entries.push(e),
                  (r.latency = Math.max(r.latency, e.duration));
              else {
                var n = {
                  id: e.interactionId,
                  latency: e.duration,
                  entries: [e],
                };
                (F[n.id] = n), B.push(n);
              }
              B.sort(function (e, t) {
                return t.latency - e.latency;
              }),
                B.splice(10).forEach(function (e) {
                  delete F[e.id];
                });
            }
          }),
          (H = function (e, t) {
            t = t || {};
            var r = [200, 500];
            k();
            var n,
              a = f("INP"),
              o = function (e) {
                e.forEach(function (e) {
                  e.interactionId && U(e),
                    "first-input" !== e.entryType ||
                      B.some(function (t) {
                        return t.entries.some(function (t) {
                          return (
                            e.duration === t.duration &&
                            e.startTime === t.startTime
                          );
                        });
                      }) ||
                      U(e);
                });
                var t,
                  r =
                    ((t = Math.min(B.length - 1, Math.floor(D() / 50))), B[t]);
                r &&
                  r.latency !== a.value &&
                  ((a.value = r.latency), (a.entries = r.entries), n());
              },
              i = p("event", o, {
                durationThreshold: t.durationThreshold || 40,
              });
            (n = m(e, a, r, t.reportAllChanges)),
              i &&
                (i.observe({ type: "first-input", buffered: !0 }),
                h(function () {
                  o(i.takeRecords()),
                    a.value < 0 && D() > 0 && ((a.value = 0), (a.entries = [])),
                    n(!0);
                }),
                u(function () {
                  (B = []),
                    ($ = N()),
                    (n = m(e, (a = f("INP")), r, t.reportAllChanges));
                }));
          }),
          (q = {}),
          (W = function (e, t) {
            t = t || {};
            var r,
              n = [2500, 4e3],
              a = _(),
              o = f("LCP"),
              i = function (e) {
                var t = e[e.length - 1];
                if (t) {
                  var n = t.startTime - d();
                  n < a.firstHiddenTime &&
                    ((o.value = n), (o.entries = [t]), r());
                }
              },
              l = p("largest-contentful-paint", i);
            if (l) {
              r = m(e, o, n, t.reportAllChanges);
              var s = function () {
                q[o.id] ||
                  (i(l.takeRecords()), l.disconnect(), (q[o.id] = !0), r(!0));
              };
              ["keydown", "click"].forEach(function (e) {
                addEventListener(e, s, { once: !0, capture: !0 });
              }),
                h(s, !0),
                u(function (a) {
                  (r = m(e, (o = f("LCP")), n, t.reportAllChanges)),
                    requestAnimationFrame(function () {
                      requestAnimationFrame(function () {
                        (o.value = performance.now() - a.timeStamp),
                          (q[o.id] = !0),
                          r(!0);
                      });
                    });
                });
            }
          }),
          (Z = function e(t) {
            document.prerendering
              ? addEventListener(
                  "prerenderingchange",
                  function () {
                    return e(t);
                  },
                  !0
                )
              : "complete" !== document.readyState
              ? addEventListener(
                  "load",
                  function () {
                    return e(t);
                  },
                  !0
                )
              : setTimeout(t, 0);
          }),
          (z = function (e, t) {
            t = t || {};
            var r = [800, 1800],
              n = f("TTFB"),
              a = m(e, n, r, t.reportAllChanges);
            Z(function () {
              var o = c();
              if (o) {
                if (
                  ((n.value = Math.max(o.responseStart - d(), 0)),
                  n.value < 0 || n.value > performance.now())
                )
                  return;
                (n.entries = [o]),
                  a(!0),
                  u(function () {
                    (a = m(e, (n = f("TTFB", 0)), r, t.reportAllChanges))(!0);
                  });
              }
            });
          }),
          (e.exports = r);
      },
      79423: function (e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.isAPIRoute = function (e) {
            return (
              "/api" === e ||
              Boolean(null == e ? void 0 : e.startsWith("/api/"))
            );
          });
      },
      80676: function (e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = a),
          (t.getProperError = function (e) {
            return a(e)
              ? e
              : Error(n.isPlainObject(e) ? JSON.stringify(e) : e + "");
          });
        var n = r(19125);
        function a(e) {
          return (
            "object" == typeof e && null !== e && "name" in e && "message" in e
          );
        }
      },
      72431: function () {},
    },
    function (e) {
      e.O(0, [49774], function () {
        return e((e.s = 14642));
      }),
        (_N_E = e.O());
    },
  ]);
