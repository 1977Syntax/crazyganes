!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "aa61c948-536f-4ce2-bf81-ce5afcbcb7fe"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-aa61c948-536f-4ce2-bf81-ce5afcbcb7fe"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [79203],
    {
      10134: function (e, t, a) {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/game",
          function () {
            return a(20430);
          },
        ]);
      },
      3242: function (e, t, a) {
        "use strict";
        a.d(t, {
          Ue: function () {
            return s;
          },
          cn: function () {
            return i;
          },
          iA: function () {
            return o;
          },
        });
        let n = !1,
          r = [];
        function i() {
          (n = !0), r.forEach((e) => e()), (r = []);
        }
        function o() {
          (n = !1), (r = []);
        }
        function s(e) {
          if (n) {
            e();
            return;
          }
          r.push(e);
        }
      },
      60081: function (e, t, a) {
        "use strict";
        var n = a(85893),
          r = a(67294),
          i = a(9008),
          o = a.n(i),
          s = a(33209),
          l = a(75007),
          d = a(8697);
        let c = (e) => {
          let {
              canonical: t,
              title: a,
              description: i,
              imageUrl: c = "crazygames/share.png",
              imageWidth: u = 1200,
              imageHeight: g = 630,
              type: m,
            } = e,
            { locale: p } = r.useContext(d.Z),
            f = (0, l.ZP)(c, { width: u, height: g, fit: "crop" });
          return (0, n.jsxs)(o(), {
            children: [
              (0, n.jsx)("meta", { property: "og:url", content: t }),
              (0, n.jsx)("meta", { property: "og:title", content: a }),
              (0, n.jsx)("meta", { property: "og:description", content: i }),
              (0, n.jsx)("meta", {
                property: "og:locale",
                content: (0, s.Ld)(p),
              }),
              (0, n.jsx)("meta", { property: "og:image", content: f }),
              (0, n.jsx)("meta", {
                property: "og:image:width",
                content: u.toString(),
              }),
              (0, n.jsx)("meta", {
                property: "og:image:height",
                content: g.toString(),
              }),
              m && (0, n.jsx)("meta", { property: "og:type", content: m }),
              (0, n.jsx)("meta", {
                property: "twitter:card",
                content: "summary_large_image",
              }),
              (0, n.jsx)("meta", { property: "twitter:url", content: t }),
              (0, n.jsx)("meta", { property: "twitter:title", content: a }),
              (0, n.jsx)("meta", {
                property: "twitter:description",
                content: i,
              }),
              (0, n.jsx)("meta", { property: "twitter:image", content: f }),
            ],
          });
        };
        t.Z = c;
      },
      26830: function (e, t, a) {
        "use strict";
        a.d(t, {
          $W: function () {
            return f;
          },
          LG: function () {
            return b;
          },
          Q6: function () {
            return y;
          },
          Qq: function () {
            return m;
          },
          U9: function () {
            return p;
          },
          _: function () {
            return w;
          },
          _Y: function () {
            return c;
          },
          _f: function () {
            return P;
          },
          bM: function () {
            return u;
          },
          et: function () {
            return v;
          },
          h7: function () {
            return h;
          },
          tO: function () {
            return g;
          },
        });
        var n = a(45703),
          r = a(75538),
          i = a(29338),
          o = a(46313),
          s = a(33209),
          l = a(88642);
        function d(e) {
          let t = o.Z.Instance.data.domains,
            a = t.map((t) => {
              let a = "en-US" === (0, s.Jx)(t.host),
                o = { ...r.t },
                l = new n.Z(o),
                d = l.generateHome({ page: e });
              if (!d) return null;
              let c = (0, i.Z)(t.host, d.as, {
                isMainDomain: a,
                locale: t.locale,
              }).toString();
              return { locale: t.locale, href: c.toString(), host: t.host };
            });
          return a.filter((e) => !!e);
        }
        function c(e) {
          return x((e) => e.generateCompetitions(), {}, e, "competitions");
        }
        function u(e) {
          return x((e) => e.generateScholarship(), {}, e, "scholarship");
        }
        function g(e) {
          return x((e) => e.generateRecent(), {}, e, "recent");
        }
        function m(e) {
          return x((e) => e.generateOriginals(), {}, e, "originals");
        }
        function p(e) {
          return x((e) => e.generateTags(), {}, e, "tags");
        }
        function f(e, t) {
          return x((e, t) => e.generateGame(t), { slug: e }, t, "game");
        }
        function y(e) {
          return x((e) => e.generatePrivacyPolicy(), {}, e, "privacyPolicy");
        }
        function h(e) {
          return x(
            (e) => e.generateTermsAndConditions(),
            {},
            e,
            "termsAndConditions"
          );
        }
        function w(e) {
          return x((e) => e.generateSearch(), {}, e, "search");
        }
        async function v(e, t, a, n, r) {
          if (r) return d(n);
          if (t && "hot" === t)
            return x(
              (e) => e.generatePaginatedHotGames({ page: n }),
              {},
              await a.getRouteProviderData("hotGames"),
              "hotGames"
            );
          switch (e) {
            case l.Fi:
              let i = await a.getRouteProviderData("newGames");
              return x(
                (e) => e.generatePaginatedNewGames({ page: n }),
                {},
                i,
                "newGames"
              );
            case l.sc:
            case l.K6:
              return x(
                (e) => e.generatePaginatedUpdatedGames({ page: n }),
                {},
                await a.getRouteProviderData("updatedGames"),
                "updatedGames"
              );
            default:
              return console.warn(`unexpected sorting in games ${e}`), d(n);
          }
        }
        async function b(e, t, a) {
          if (e.isCategory) {
            let n = await t.getRouteProviderData("category");
            return x(
              (e, t) => e.generateCategory(t),
              { slugTrl: e.slug, page: a },
              n,
              "category"
            );
          }
          {
            let n = await t.getRouteProviderData("tag");
            return x(
              (e, t) => e.generateTag(t),
              { slugTrl: e.slug, page: a },
              n,
              "tag"
            );
          }
        }
        function P(e, t) {
          return x((t) => t.generateAllGames(e), {}, t, "allGames");
        }
        function x(e, t, a, l) {
          let d = (function (e) {
              let t = o.Z.Instance.data.domains,
                a = e.map((e) => {
                  let a = t.find((t) => {
                    let a = (0, s.Ld)(t.locale);
                    return a === e.locale;
                  });
                  return { domain: a, routeData: e };
                });
              return a;
            })(a),
            c = d.map((a) => {
              let o = a.domain,
                d = "en-US" === (0, s.Jx)(o.host),
                c = o.locale,
                u = {
                  ...r.t,
                  [l]: a.routeData.route,
                  locale: a.routeData.locale,
                },
                g = new n.Z(u),
                m = e(g, t);
              if (!m || !a.domain) return null;
              let p = (0, i.Z)(a.domain.host, m.as, {
                isMainDomain: d,
                locale: c,
              }).toString();
              return {
                locale: a.domain.locale,
                href: p.toString(),
                host: a.domain.host,
              };
            });
          return c.filter((e) => !!e);
        }
      },
      20430: function (e, t, a) {
        "use strict";
        a.r(t),
          a.d(t, {
            default: function () {
              return Q;
            },
          });
        var n = a(85893),
          r = a(67294),
          i = a(46313),
          o = a(26830),
          s = a(13301),
          l = a(4498),
          d = a(33209),
          c = a(44715),
          u = a(96851),
          g = a(88642),
          m = a(61338),
          p = a(83808),
          f = a(11163),
          y = a.n(f),
          h = a(94745),
          w = a(67278),
          v = a(90611),
          b = a(18288),
          P = a(89950),
          x = a(84973),
          T = a(37899),
          G = a(17784),
          _ = a(74040),
          S = a(13422);
        let M = (e) => {
          let { gameId: t } = e,
            { services: a } = r.useContext(T.Z),
            { user: n } = r.useContext(_.S),
            { syncPlayedTime: i } = r.useContext(S.rh),
            o = r.useRef(Date.now()),
            s = {};
          G.aQ.forEach((e) => {
            s[e] = !1;
          });
          let l = r.useRef(s),
            { gamesPlayedService: d, analyticsService: c } = a;
          r.useEffect(
            () => () => {
              i();
            },
            [i, t]
          );
          let u = (0, r.useCallback)(() => {
              let e = Math.round((Date.now() - o.current) / 1e3);
              d.handlePlayedTimeForSession(t, e),
                G.aQ.forEach((a) => {
                  e >= 60 * a &&
                    !l.current[a] &&
                    (c.trackSessionPlaytimeRanges(t, a), (l.current[a] = !0));
                });
            }, [t, d, c]),
            g = (0, r.useCallback)(() => {
              if (!n) return;
              let e = Math.round((Date.now() - o.current) / 1e3);
              d.handlePlayedTimeForUPSync(t, e);
            }, [n, t, d]);
          return (
            r.useEffect(() => {
              n && g();
            }, [n, g]),
            r.useEffect(() => {
              let e = null,
                t = () => {
                  e = window.setInterval(() => {
                    g(), u();
                  }, G.rP);
                },
                a = () => {
                  e && (window.clearInterval(e), g(), u(), (e = null));
                },
                n = () => {
                  document.hidden ? a() : t();
                };
              return (
                t(),
                document.addEventListener("visibilitychange", n),
                function () {
                  document.removeEventListener("visibilitychange", n),
                    e && window.clearInterval(e);
                }
              );
            }, [u, g]),
            null
          );
        };
        var j = a(32017),
          k = a(69395),
          D = a(3242),
          I = a(92975),
          E = a(58752);
        class R extends r.Component {
          addToRecentTimeout = null;
          gameStartTime = 0;
          constructor(e) {
            super(e), (this.state = { trackTime: !1 });
          }
          render() {
            let { game: e } = this.props,
              { trackTime: t } = this.state;
            return t && (0, n.jsx)(M, { gameId: e.id });
          }
          componentDidMount() {
            let { services: e, game: t } = this.props;
            e.crazyAnalyticsService.gamePageLoaded(t.id, t.buildId),
              window.addEventListener("message", this.processMessage),
              window.addEventListener("pagehide", this.pageUnload);
          }
          componentWillUnmount() {
            this.savePlayedGameTime(),
              this.clearGameTracking(),
              window.removeEventListener("pagehide", this.pageUnload),
              window.removeEventListener("message", this.processMessage),
              this.props.services.crazyAnalyticsService.gamePageExited();
          }
          pageUnload = () => {
            this.savePlayedGameTime();
          };
          processMessage = (e) => {
            if (e.data && e.data.type === P.V)
              switch (e.data.event) {
                case "afterPlayNow":
                  (0, j.hO)("afterPlayNow");
                  break;
                case "gameStartLoad":
                  (0, j.hO)("gameStartLoad");
                  break;
                case "gameLoaded":
                  let { gfVersion: t } = e.data,
                    a =
                      this.props.experiment?.czyExpIsPrefetchEnabled2 ===
                        "enabled" && !this.props.deviceType.isDesktop;
                  if (!a) {
                    this.handlePlayerStartedPlaying(t);
                    return;
                  }
                  (0, D.Ue)(() => {
                    this.handlePlayerStartedPlaying(t);
                  });
              }
          };
          handlePlayerStartedPlaying(e) {
            (0, j.hO)("afterGameLoad"),
              this.setGameTracking(e),
              this.addToRecent();
          }
          addToRecent() {
            this.addToRecentTimeout = window.setTimeout(
              this.delayedAddToRecent,
              45e3
            );
          }
          delayedAddToRecent = () => {
            let { game: e, userRecent: t } = this.props;
            t.addToRecent({
              id: e.id,
              slug: e.slug,
              name: e.name,
              cover: e.cover,
              videos: e.videos,
              status: e.status,
              iosFriendly: e.iosFriendly,
              androidFriendly: e.androidFriendly,
              mobileFriendly: !!(e.iosFriendly || e.androidFriendly),
              gameThumbLabels: [],
              playedTime: 45,
            });
          };
          setGameTracking(e) {
            let { services: t, game: a } = this.props,
              { gamesPlayedService: n, crazyAnalyticsService: r } = t;
            n.startedPlayingGame(a), (this.gameStartTime = Date.now());
            let i = E.Do(a.slug)?.numPlays || 1;
            r.playingStarts({
              gfVersion: e,
              gameId: a.id,
              buildId: a.buildId,
              numPlays: i,
            }),
              (0, E.ug)(a.slug),
              this.setState({ trackTime: !0 });
          }
          savePlayedGameTime() {
            let { game: e, services: t } = this.props;
            if (this.gameStartTime) {
              let a = Math.min(27e5, Date.now() - this.gameStartTime);
              t.gamesPlayedService.trackPlayedTime(e.slug, a);
            }
          }
          clearGameTracking() {
            this.addToRecentTimeout &&
              window.clearTimeout(this.addToRecentTimeout),
              this.setState({ trackTime: !1 });
          }
        }
        var Z = (0, x.Z)(
            (0, S.VP)(
              (0, I.Z)(
                (function (e) {
                  let t = (t) => {
                    let a = r.useContext(k.T);
                    return (0, n.jsx)(e, { experiment: a, ...t });
                  };
                  return t;
                })(R)
              )
            )
          ),
          C = a(60081),
          L = a(44898),
          F = a(89041),
          A = a(81792),
          U = a(98718),
          N = a(63306),
          O = a(68771),
          z = a(5152),
          W = a.n(z),
          $ = a(42257),
          q = a(17134);
        let H = W()(
            () =>
              Promise.all([a.e(84275), a.e(41589), a.e(58313)]).then(
                a.bind(a, 58313)
              ),
            {
              loadableGenerated: { webpack: () => [58313] },
              loading: () => null,
              ssr: !0,
            }
          ),
          V = W()(
            () =>
              Promise.all([a.e(84275), a.e(41589), a.e(37363)]).then(
                a.bind(a, 37363)
              ),
            {
              loadableGenerated: { webpack: () => [37363] },
              loading: () => null,
              ssr: !0,
            }
          ),
          K = (e) => {
            let {
                game: t,
                related: a,
                alternatives: o,
                isCrawler: s,
                locale: l,
              } = e,
              { routeHelper: d } = r.useContext(N.Z),
              { isDesktop: c } = r.useContext($.Z),
              u = (0, h.mV)(),
              { czyExpSkipPlayNow_CZY_13219_2: g } = r.useContext(k.T);
            r.useEffect(
              () => (
                (0, q.a)({ gameId: t.id }), () => (0, q.a)({ gameId: null })
              ),
              [t.id]
            );
            let m = { name: t.name, category: t.category?.name || "" },
              p = t.pageTitle
                ? t.pageTitle
                : u._("game.head.title", { name: t.name }),
              f =
                t.metaDescription ||
                u._("game.head.metaDescriptionFallback", m),
              y = d.gameCanonical(t.slug),
              P = i.Z.Instance.data.advertizing.domain,
              x = !c && !t.iosFriendly && !t.androidFriendly,
              T =
                !!t.disableAds || "UNAVAILABLE" === t.status || x || (0, O.j)(),
              G = t.tags.map((e) => e.enSlug || e.slug);
            return (0, n.jsxs)(n.Fragment, {
              children: [
                (0, n.jsxs)(
                  w.Z,
                  {
                    locale: l,
                    advertisingGame: {
                      gameName: t.name,
                      gameSlug: t.slug,
                      categoryEnSlug: t.category?.enSlug,
                      tagsSlug: G,
                      numLikes: t.upvotes,
                    },
                    disabled: T,
                    smartRefresh: {
                      enabled: !!t.smartRefresh,
                      minWaitInMs: t.minWaitForSmartRefreshInMs,
                      maxWaitInMs: t.maxWaitForSmartRefreshInMs,
                    },
                    edgeExperiments: {
                      skip_preroll_exp_25:
                        c && void 0 !== g ? "enabled" === g : void 0,
                    },
                    children: [
                      (0, n.jsxs)(b.Z, {
                        title: p,
                        metaDescription: f,
                        canonical: y,
                        alternatives: o,
                        children: [
                          (0, n.jsx)("meta", {
                            name: "apple-mobile-web-app-title",
                            content: t.name,
                          }),
                          (0, n.jsx)("link", { rel: "preconnect", href: P }),
                          (() => {
                            if (t.customStructuredData)
                              return (0, n.jsx)("script", {
                                type: "application/ld+json",
                                dangerouslySetInnerHTML: {
                                  __html: t.customStructuredData,
                                },
                              });
                          })(),
                        ],
                      }),
                      (0, n.jsx)(C.Z, {
                        canonical: y,
                        title: p,
                        description: f,
                        imageUrl: t.cover,
                        type: "game",
                      }),
                      (0, n.jsx)(A.Z, {
                        children: (0, n.jsx)(H, {
                          game: t,
                          crawlerData: { isCrawler: s, games: a },
                        }),
                      }),
                      (0, n.jsx)(U.Z, {
                        children: (0, n.jsx)(V, {
                          game: t,
                          crawlerData: { isCrawler: s, games: a },
                        }),
                      }),
                    ],
                  },
                  t.slug
                ),
                (0, n.jsx)(Z, { game: t }, `gametracking-${t.slug}`),
                (0, n.jsx)(v.J, { game: t }),
                (0, n.jsx)(L.Z, { gameId: t.id, gameTechnology: t.technology }),
                (0, n.jsx)(F.Z, { gameId: t.id }),
              ],
            });
          };
        K.getInitialProps = async (e) => {
          let t = (e, t, a) => {
              if (e.collection) {
                let n = t.tagPageDirectLink(e.collection, {
                  returnRelative: a,
                });
                return n;
              }
              if (e.category) {
                let n = t.categoryPageDirectLink(e.category.slug, {
                  returnRelative: a,
                });
                return n;
              }
              return t.homePageLink();
            },
            {
              pageService: a,
              routeDataService: n,
              crawlerService: r,
            } = (0, p.b)(e),
            c = e.query && e.query[g.l1],
            m = (e.query && e.query.buildId) ?? null,
            { deviceType: f } = (0, s.mO)(e),
            h = (0, s.yz)(f),
            w = !f.isDesktop,
            v = w ? l.gM : l.$d,
            [{ game: b, related: P, hotGames: x }, T] = await Promise.all([
              a.gamePage(c, v, h, m),
              n.getRouteProviderData("game"),
            ]),
            { res: G } = e,
            _ = (0, d.Kd)(e);
          if ("ARCHIVED" === b.status) {
            let a = await n.getLocaleRouteProviderData(_),
              r = u.Z.createFromContext(e, a);
            if (G) {
              let e = t(b, r, !1);
              G.writeHead(302, { Location: e.as }), G.end();
            } else {
              let e = t(b, r, !0);
              y().push(e.href, e.as);
            }
          }
          G &&
            b.isKids &&
            (G.writeHead(302, {
              Location: `${i.Z.Instance.data.kids}/game/${b.slug}`,
            }),
            G.end());
          let S = (0, o.$W)(b.slug, T),
            M = "true" === e.query[g.cv],
            j = {
              game: b,
              related: P,
              numRelatedGames: v,
              hotGames: x,
              alternatives: S,
              isCrawler: M,
              locale: _,
            };
          if (M) {
            let e = await r.replaceGamePageForCrawler(j, f);
            return e;
          }
          return j;
        };
        var Q = (0, c.Z)("game")((0, m.Z)(K));
      },
      75538: function (e, t, a) {
        "use strict";
        a.d(t, {
          P: function () {
            return n;
          },
          t: function () {
            return r;
          },
        });
        let n = [
            "newGames",
            "updatedGames",
            "hotGames",
            "tags",
            "category",
            "tag",
            "game",
            "preview",
            "termsAndConditions",
            "informationForParents",
            "privacyPolicy",
            "10-anniversary",
            "recent",
            "originals",
            "search",
            "scholarship",
            "competitions",
            "pwa",
            "pwaInstall",
            "allGames",
          ],
          r = {
            newGames: "",
            updatedGames: "",
            hotGames: "",
            tags: "",
            category: "",
            tag: "",
            game: "",
            preview: "",
            termsAndConditions: "",
            privacyPolicy: "",
            "10-anniversary": "",
            recent: "",
            originals: "",
            search: "",
            pwa: "",
            pwaInstall: "",
            allGames: "",
            locale: "",
          };
      },
    },
    function (e) {
      e.O(0, [69029, 76287, 61338, 85738, 49774, 92888, 40179], function () {
        return e((e.s = 10134));
      }),
        (_N_E = e.O());
    },
  ]);
