!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "934c7d42-6693-4116-a161-11fa26b2c7ce"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-934c7d42-6693-4116-a161-11fa26b2c7ce"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [38451],
    {
      5337: function (e, t, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/games",
          function () {
            return n(3050);
          },
        ]);
      },
      35600: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return b;
          },
        });
        var i,
          s,
          a = n(85893),
          o = n(67294),
          r = n(90512),
          l = n(92975),
          c = n(70133),
          u = n(33209),
          d = n(9978),
          m = n(94984),
          h = n(95914);
        let g = o.memo((e) =>
          (0, a.jsxs)(h.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: [
              (0, a.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M3.25757 2.33007C3.62757 1.92005 4.2599 1.88759 4.66993 2.25759L12.9814 9.75759C14.3395 10.9831 14.3395 13.0169 12.9814 14.2424L4.66993 21.7424C4.2599 22.1124 3.62757 22.08 3.25757 21.6699C2.88758 21.2599 2.92003 20.6276 3.33006 20.2576L11.6415 12.7576C12.1195 12.3263 12.1195 11.6737 11.6415 11.2424L3.33006 3.74243C2.92003 3.37243 2.88758 2.7401 3.25757 2.33007Z",
              }),
              (0, a.jsx)("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M11.2576 2.33007C11.6276 1.92005 12.2599 1.88759 12.6699 2.25759L20.9814 9.75759C22.3395 10.9831 22.3395 13.0169 20.9814 14.2424L12.6699 21.7424C12.2599 22.1124 11.6276 22.08 11.2576 21.6699C10.8876 21.2599 10.92 20.6276 11.3301 20.2576L19.6415 12.7576C20.1195 12.3263 20.1195 11.6737 19.6415 11.2424L11.3301 3.74243C10.92 3.37243 10.8876 2.7401 11.2576 2.33007Z",
              }),
            ],
          })
        );
        var _ = n(68107),
          p = n.n(_),
          y = n(4100),
          x = n.n(y);
        ((i = s || (s = {})).left = "left"), (i.right = "right");
        class C extends o.Component {
          static defaultProps = {
            scrollDelayMilliseconds: 10,
            scrollDebounceMilliseconds: 100,
            scrollInterval: 650,
            requestDataThreshold: 3,
          };
          constructor(e) {
            super(e),
              (this.needsRTL = (0, u.oN)(e.locale)),
              (this.state = {
                showLeftButton: !1,
                showRightButton: !0,
                debounce: !1,
              }),
              (this.carouselRef = o.createRef()),
              (this.sentinelRef = o.createRef()),
              (this.isFetching = !1);
          }
          componentDidMount() {
            window.addEventListener("resize", this.resizeEvent),
              this.observeChildren();
          }
          componentWillUnmount() {
            this.io && this.io.disconnect(),
              (this.io = null),
              window.removeEventListener("resize", this.resizeEvent);
          }
          componentDidUpdate(e) {
            e.children !== this.props.children && this.observeChildren();
          }
          render() {
            let {
              onMouseEnter: e,
              onMouseLeave: t,
              deviceType: n,
            } = this.props;
            return (0, a.jsxs)(m.H, {
              newClickOrigin: "carousel",
              children: [
                !n.isDesktop &&
                  (0, a.jsx)(g, {
                    onClick: this.moveRight,
                    className: (0, r.Z)(x().doubleArrow, "double-arrow"),
                  }),
                (0, a.jsxs)("div", {
                  className: (0, r.Z)(x().root, "prime-carousel"),
                  onMouseEnter: e,
                  onMouseLeave: t,
                  children: [
                    n.isDesktop &&
                      this.state.showLeftButton &&
                      (0, a.jsx)("button", {
                        onClick: this.moveLeft,
                        className: (0, r.Z)(
                          x().primeCarouselArrow,
                          x().primeCarouselArrowLeft
                        ),
                        "aria-label": "Left arrow",
                      }),
                    (0, a.jsx)("ul", {
                      className: x().primeCarouselContainer,
                      ref: this.carouselRef,
                      children: this.renderChildren(),
                    }),
                    n.isDesktop &&
                      this.state.showRightButton &&
                      (0, a.jsx)("button", {
                        onClick: this.moveRight,
                        className: (0, r.Z)(
                          x().primeCarouselArrow,
                          x().primeCarouselArrowRight
                        ),
                        "aria-label": "Right arrow",
                      }),
                  ],
                }),
              ],
            });
          }
          renderChildren() {
            let { requestDataThreshold: e, requestData: t } = this.props,
              n = o.Children.count(this.props.children),
              i = n - Math.min(n - 2, e),
              s = o.Children.map(this.props.children, (e, n) =>
                (0, a.jsx)(
                  "li",
                  {
                    className: (0, r.Z)(p().primeCarouselLi, "primeCarouselLi"),
                    ref: t && i === n ? this.sentinelRef : void 0,
                    children: e,
                  },
                  n
                )
              );
            return s;
          }
          carouselScrollTo(e, t) {
            let n = this.carouselRef.current;
            n && n.scrollTo({ left: e, behavior: t });
          }
          setupIo() {
            let e = this.carouselRef.current;
            this.io = new IntersectionObserver(
              (e) => {
                e.forEach(async (e) => {
                  let t = e.isIntersecting,
                    { nextSibling: n, previousSibling: i } = e.target;
                  if (!n && e.target === this.lastChild) {
                    let e = !t,
                      n = this.needsRTL ? "showLeftButton" : "showRightButton";
                    e !== this.state[n] && this.setState({ [n]: e });
                  }
                  if (!i && e.target === this.firstChild) {
                    let e = !t,
                      n = this.needsRTL ? "showRightButton" : "showLeftButton";
                    e !== this.state[n] && this.setState({ [n]: e });
                  }
                  if (n && i && t && !this.isFetching) {
                    let { requestData: e } = this.props;
                    e &&
                      ((this.isFetching = !0),
                      await e(),
                      (this.isFetching = !1));
                  }
                });
              },
              { root: e, threshold: [0.98] }
            );
          }
          observeChildren() {
            if ((this.io || this.setupIo(), this.io)) {
              let e = this.sentinelRef.current,
                t = this.carouselRef.current;
              if (this.props.deviceType.isDesktop) {
                let e = t.parentElement.querySelector("ul > li:first-child"),
                  n = t.parentElement.querySelector("ul > li:last-child");
                this.lastChild &&
                  this.lastChild !== n &&
                  this.io.unobserve(this.lastChild),
                  n && (this.io.observe(n), (this.lastChild = n)),
                  this.firstChild &&
                    this.firstChild !== e &&
                    this.io.unobserve(this.firstChild),
                  e && (this.io.observe(e), (this.firstChild = e));
              }
              this.lastSentinel &&
                e !== this.lastSentinel &&
                this.io.unobserve(this.lastSentinel),
                e && (this.io.observe(e), (this.lastSentinel = e));
            }
          }
          moveToClickEvent = (e) => {
            let { deviceType: t } = this.props,
              n = this.carouselRef.current,
              i = n?.firstElementChild
                ? n?.firstElementChild.clientWidth + 4
                : 0;
            if (!n) return;
            let s = n.offsetWidth,
              a = t.isDesktop ? 42 : 0,
              o = n.scrollLeft + ("left" === e ? -s : s);
            this.moveTo(o - (o % i) - a);
          };
          moveTo(e) {
            let t = this.carouselRef.current;
            t &&
              window.setTimeout(() => {
                this.carouselScrollTo(e, "smooth");
              }, this.props.scrollDelayMilliseconds);
          }
          resizeEvent = () => {
            let { debounce: e } = this.state;
            if (!e) {
              window.clearTimeout(e);
              let t = setTimeout(() => {
                this.setState({ debounce: !1 });
              }, this.props.scrollDebounceMilliseconds);
              this.setState({ debounce: t });
            }
          };
          moveLeft = () => {
            this.moveToClickEvent(s.left);
          };
          moveRight = () => {
            this.moveToClickEvent(s.right);
          };
        }
        var b = (0, c.Z)((0, l.Z)((0, d.Z)(C)));
      },
      17253: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(35600),
          o = n(78473),
          r = n(32055),
          l = n(92975),
          c = n(84973);
        class u extends s.Component {
          delayTimeout = null;
          isFetching = !1;
          constructor(e) {
            super(e),
              (this.state = {
                data: e.games,
                dataSize: e.dataSize || e.games.length,
              });
          }
          componentDidUpdate(e) {
            e.games !== this.props.games &&
              this.setState({
                data: this.props.games,
                dataSize: this.props.dataSize || this.props.games.length,
              });
          }
          componentWillUnmount() {
            this.delayTimeout && window.clearTimeout(this.delayTimeout);
          }
          render() {
            let { deviceType: e, prependElement: t } = this.props,
              n = this.getSliderContent(),
              s = this.getSliderSkeletons(),
              o = this.getAllContentPageSlide(),
              r = n.concat(s).concat(o),
              l = t ? [t, ...r] : r;
            return (0, i.jsx)(a.Z, {
              requestData: this.fetchMoreData,
              onMouseEnter: this.handleMouseEnter,
              onMouseLeave: this.handleMouseLeave,
              requestDataThreshold: e.isMobile ? 2 : 5,
              children: l,
            });
          }
          getSliderContent() {
            let { renderGameThumb: e } = this.props,
              { data: t } = this.state;
            return t.map((t, n) => {
              if (t && e)
                return (0, i.jsx)(
                  s.Fragment,
                  { children: e(t, n) },
                  t.slug || `game-${n}`
                );
            });
          }
          getSliderSkeletons() {
            let {
                maxNoItems: e,
                pageSize: t,
                deviceType: n,
                forceSkeleton: a,
                isMobileSkeletonEnabled: r,
                totalNumberOfItems: l,
                renderSkeleton: c,
              } = this.props,
              u = !n.isDesktop,
              d = this.state.dataSize;
            if ((!a && ((u && !r) || void 0 === e || d > t || d === e)) || !c)
              return [];
            let m = Math.ceil(1.5 * t);
            return (
              l && (m = Math.min(l - d, l)),
              (0, o.Z)(m).map((e) =>
                (0, i.jsx)(s.Fragment, { children: c() }, e)
              )
            );
          }
          getAllContentPageSlide() {
            let {
                maxNoItems: e,
                deviceType: t,
                allGamesLabel: n,
                allGamesLinkData: s,
              } = this.props,
              a = t.isMobile || t.isTablet;
            if (a || void 0 === e || this.state.dataSize < e || !n || !s)
              return [];
            let o = s.href.includes("//kids");
            return [
              (0, i.jsx)(
                r.Z,
                {
                  label: n,
                  linkData: s,
                  target: o ? "_blank" : void 0,
                  rel: o ? "external nofollow" : void 0,
                },
                "all-content"
              ),
            ];
          }
          handleMouseEnter = () => {
            let { pageSize: e } = this.props,
              t = Math.ceil(this.state.dataSize / e);
            t > 1 ||
              (this.delayTimeout = window.setTimeout(
                () => this.fetchMoreData(),
                1e3
              ));
          };
          handleMouseLeave = () => {
            this.delayTimeout && window.clearTimeout(this.delayTimeout);
          };
          canFetchMoreData = () => {
            let { maxNoItems: e } = this.props;
            return void 0 !== e && this.state.dataSize < e;
          };
          fetchMoreData = async () => {
            let { fetchDataFn: e, pageSize: t } = this.props,
              { data: n, dataSize: i } = this.state;
            if (
              !this.isFetching &&
              ((this.isFetching = !0), e && this.canFetchMoreData())
            ) {
              let s = await e(Math.ceil(i / t) + 1);
              if (s && s.length > 0) {
                let e = s.filter((e) => {
                  let t = n.some((t) => t && t.slug === e.slug);
                  return !t;
                });
                this.setState((t) => {
                  let n = t.dataSize + e.length;
                  return (
                    (this.isFetching = !1),
                    { data: t.data.concat(e), dataSize: n }
                  );
                });
              }
            }
          };
        }
        t.Z = (0, l.Z)((0, c.Z)(u));
      },
      57802: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(3411);
        let o = s.memo(() =>
          (0, i.jsx)("div", {
            style: {
              width: "100%",
              borderRadius: 16,
              position: "relative",
              overflow: "hidden",
              aspectRatio: "186 / 237",
              background: a.D.black[60],
            },
          })
        );
        t.Z = o;
      },
      81030: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(75007),
          o = n(51806),
          r = n(37899),
          l = n(42257),
          c = n(13301),
          u = n(88531),
          d = n(77655),
          m = n(72552),
          h = n(1982),
          g = n(20702),
          _ = n(88061),
          p = n(90512),
          y = n(9177),
          x = n.n(y),
          C = n(71890);
        let b = { portrait: "2x3", landscape: "16x9", square: "1x1" },
          f = (e) => {
            let {
                game: t,
                aspectRatio: n = "landscape",
                isResponsive: y,
                displayLabelBelow: f,
                showLabels: v = !0,
              } = e,
              [z, j] = s.useState(!1),
              [w, B] = s.useState(0),
              k = s.useRef(null),
              { gameService: Z } = s.useContext(r.Z).services,
              T = s.useRef(null),
              L = s.useContext(l.Z),
              S = (0, c.yz)(L),
              M = !L.isDesktop,
              G = s.useContext(d.Y).addViewedGames,
              R = (0, m.Z)(s.useContext(h.t));
            s.useEffect(() => {
              k.current && B(k.current.clientWidth);
            }, []),
              s.useEffect(() => {
                let e;
                return (
                  k &&
                    k.current &&
                    ((e = k.current),
                    g.Z.get().observe(k.current, () => {
                      g.Z.get().unobserve(e), G(t.id, R);
                    })),
                  () => {
                    e && g.Z.get().unobserve(e);
                  }
                );
              }, [t.id, G, R]);
            let I = () => {
                Z.prefetchGameData(t, S);
              },
              P = () => {
                !z &&
                  A &&
                  (j(!0),
                  (T.current = window.setTimeout(() => {
                    I();
                  }, 500)));
              },
              D = () => {
                A &&
                  (s.startTransition(() => {
                    j(!1);
                  }),
                  T.current && (clearTimeout(T.current), (T.current = null)));
              },
              N = y
                ? "100%"
                : ((e) => {
                    switch (n) {
                      case "landscape":
                        return e * (9 / 16);
                      case "portrait":
                        return 1.5 * e;
                      case "square":
                        return e;
                    }
                  })(C._),
              O = t.covers ? t.covers[b[n]] : t.cover,
              E = {
                quality: 85,
                width: C._,
                height: "number" == typeof N ? N : void 0,
                fit: "crop",
              },
              F = (0, a.LI)(O, E),
              A = !M && "portrait" === n,
              H = t.videos?.portraitSizes && t.videos?.portraitSizes.length > 0,
              V = (0, i.jsxs)(i.Fragment, {
                children: [
                  v &&
                    (0, i.jsx)(u.Z, {
                      videoPlaying: z,
                      gameThumbLabels: t.gameThumbLabels,
                    }),
                  (0, i.jsx)(_.Z, {
                    className: (0, p.Z)(
                      x().originalsGameLink,
                      M && x().isMobile,
                      x()[n],
                      y && x().isResponsive
                    ),
                    slug: t.slug,
                    ref: k,
                    onMouseOver: P,
                    onMouseLeave: D,
                    children: (0, i.jsxs)(i.Fragment, {
                      children: [
                        t.covers &&
                          (0, i.jsx)("img", {
                            src: (0, a.ZP)(O, E),
                            alt: t.name,
                            srcSet: F,
                            loading: M ? "lazy" : void 0,
                            decoding: M ? "async" : void 0,
                          }),
                        z &&
                          (0, i.jsx)("div", {
                            className: (0, p.Z)(
                              x().hoveredContainer,
                              H && x().withPortraitVideo
                            ),
                            children: (0, i.jsx)(o.Z, {
                              game: t,
                              videoWidth: w,
                              isPortrait: !0,
                              style: { height: H ? "100%" : void 0 },
                            }),
                          }),
                      ],
                    }),
                  }),
                ],
              });
            return f
              ? (0, i.jsx)(i.Fragment, {
                  children: (0, i.jsxs)("div", {
                    style: { position: "relative" },
                    children: [
                      V,
                      (0, i.jsx)("div", {
                        className: (0, p.Z)(
                          x().gameName,
                          M && x().isMobile,
                          x()[n],
                          y && x().isResponsive
                        ),
                        children: t.name,
                      }),
                      t.categoryName &&
                        (0, i.jsx)("div", {
                          className: (0, p.Z)(
                            x().gameCategory,
                            M && x().isMobile,
                            x()[n],
                            y && x().isResponsive
                          ),
                          children: t.categoryName,
                        }),
                    ],
                  }),
                })
              : V;
          };
        t.Z = f;
      },
      32055: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(2978),
          o = n(55176),
          r = n.n(o),
          l = n(90512),
          c = n(24909),
          u = n(42257);
        let d = (e) => {
          let { label: t, linkData: n, target: o, rel: d, searchGrid: m } = e,
            { isDesktop: h } = s.useContext(u.Z),
            g = m
              ? h
                ? r().gameThumbAllLinkDesktopSearchGrid
                : r().gameThumbAllLinkMobileSearchGrid
              : null;
          return (0, i.jsx)(a.Z, {
            ...n,
            className: (0, l.Z)(r().gameThumbAllLink, g),
            target: o,
            rel: d,
            prefetch: !0,
            children: (0, i.jsxs)("span", {
              className: (0, l.Z)(r().gameThumbAll),
              children: [
                (0, i.jsx)("div", {
                  className: r().gameThumbAllLabel,
                  children: t,
                }),
                (0, i.jsx)(c.Z, {}),
              ],
            }),
          });
        };
        t.Z = d;
      },
      51806: function (e, t, n) {
        "use strict";
        var i = n(85893);
        n(67294);
        var s = n(36060);
        let a = (e) => {
          let {
              game: t,
              videoHeight: n,
              videoWidth: a,
              style: o,
              onCanPlayThrough: r,
              isPortrait: l,
            } = e,
            c = (0, s.Z)(t, n ? { height: n } : { width: a }, l);
          return c
            ? (0, i.jsx)("video", {
                loop: !0,
                autoPlay: !0,
                preload: "none",
                muted: !0,
                playsInline: !0,
                onCanPlayThrough: r,
                style: o,
                disableRemotePlayback: !0,
                disablePictureInPicture: !0,
                children: (0, i.jsx)("source", { src: c, type: "video/mp4" }),
              })
            : null;
        };
        t.Z = a;
      },
      70150: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(95914);
        let o = s.memo((e) =>
          (0, i.jsx)(a.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M12.002 4C11.4497 4 11.002 4.44772 11.002 5C11.002 5.55228 11.4497 6 12.002 6C12.5542 6 13.002 5.55228 13.002 5C13.002 4.44772 12.5542 4 12.002 4ZM9.00195 5C9.00195 3.34315 10.3451 2 12.002 2C13.6588 2 15.002 3.34315 15.002 5C15.002 6.30623 14.1671 7.41747 13.0019 7.8293V8.5828C13.4503 8.65773 13.8922 8.78342 14.319 8.95985L19.9492 11.2903L19.9517 11.2913C20.1346 11.3664 20.302 11.4725 20.4469 11.6042C20.7759 11.7679 21.002 12.1075 21.002 12.5V17.2268C21.0116 17.4774 20.9667 17.7272 20.8703 17.959C20.7087 18.348 20.4087 18.6633 20.0283 18.8442L20.0261 18.8452L14.5641 21.4252C13.763 21.8036 12.888 22 12.002 22C11.116 22 10.241 21.8037 9.43985 21.4252L3.97668 18.8446C3.66495 18.6969 3.40537 18.4581 3.23222 18.1597C3.06692 17.8749 2.98782 17.5485 3.00395 17.2203L3.00214 12.9411C3.00009 12.9005 2.99951 12.8596 3.00041 12.8187C3.00075 12.8032 3.00131 12.7877 3.00207 12.7723L3.00196 12.5004C3.00179 12.1104 3.22494 11.7724 3.55059 11.6074C3.69899 11.4719 3.87112 11.3632 4.05945 11.2874C4.06978 11.2832 4.08015 11.2792 4.09057 11.2754L9.68448 8.96002C10.1113 8.78359 10.5536 8.65773 11.0019 8.5828V7.82929C9.83675 7.41744 9.00195 6.30621 9.00195 5ZM5.00296 14.8665L5.0039 17.118L10.2941 19.6168C10.8281 19.8691 11.4114 20 12.002 20C12.5925 20 13.1758 19.8691 13.7098 19.6168L19.002 17.117V14.866L14.559 16.9346C13.7581 17.3069 12.8851 17.5001 12.0019 17.5001C11.1187 17.5001 10.2462 17.3071 9.44532 16.9348L5.00296 14.8665ZM10.4494 10.808C10.63 10.7333 10.8147 10.6722 11.0019 10.6247V13C11.0019 13.5523 11.4496 14 12.0019 14C12.5542 14 13.0019 13.5523 13.0019 13V10.6247C13.1892 10.6722 13.3743 10.7335 13.5549 10.8081L18.5438 12.8732L13.7153 15.1212C13.1786 15.3708 12.5938 15.5001 12.0019 15.5001C11.41 15.5001 10.8253 15.3708 10.2885 15.1212L5.46001 12.8732L10.4494 10.808Z",
            }),
          })
        );
        t.Z = o;
      },
      59411: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(95914);
        let o = s.memo((e) =>
          (0, i.jsx)(a.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M15.6699 5.25759C15.2599 4.88759 14.6276 4.92005 14.2576 5.33007C13.8876 5.7401 13.92 6.37243 14.3301 6.74243L19.0483 11H3C2.44772 11 2 11.4477 2 12C2 12.5523 2.44772 13 3 13H19.0483L14.3301 17.2576C13.92 17.6276 13.8876 18.2599 14.2576 18.6699C14.6276 19.08 15.2599 19.1124 15.6699 18.7424L21.2109 13.7424C22.263 12.793 22.263 11.207 21.2109 10.2576L15.6699 5.25759Z",
            }),
          })
        );
        t.Z = o;
      },
      84872: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(95914);
        let o = s.memo((e) =>
          (0, i.jsx)(a.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M5.25759 8.33007C4.88759 8.7401 4.92005 9.37243 5.33007 9.74243C5.7401 10.1124 6.37243 10.08 6.74243 9.66994L11 4.95172L11 21C11 21.5523 11.4477 22 12 22C12.5523 22 13 21.5523 13 21L13 4.95171L17.2576 9.66994C17.6276 10.08 18.2599 10.1124 18.6699 9.74243C19.08 9.37243 19.1124 8.7401 18.7424 8.33007L13.7424 2.7891C12.793 1.73698 11.207 1.73697 10.2576 2.7891L5.25759 8.33007Z",
            }),
          })
        );
        t.Z = o;
      },
      24909: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(95914);
        let o = s.memo((e) =>
          (0, i.jsx)(a.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M7.25759 2.33006C7.62758 1.92004 8.25992 1.88759 8.66994 2.25758L16.9814 9.75758C18.3395 10.9831 18.3395 13.0169 16.9814 14.2424L8.66994 21.7424C8.25992 22.1124 7.62758 22.08 7.25759 21.6699C6.88759 21.2599 6.92005 20.6276 7.33007 20.2576L15.6415 12.7576C16.1195 12.3263 16.1195 11.6737 15.6415 11.2424L7.33007 3.74242C6.92005 3.37242 6.88759 2.74009 7.25759 2.33006Z",
            }),
          })
        );
        t.Z = o;
      },
      11120: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(95914);
        let o = s.memo((e) =>
          (0, i.jsx)(a.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              fillRule: "evenodd",
              clipRule: "evenodd",
              d: "M5.20837 2.08333C5.78367 2.08333 6.25004 2.5497 6.25004 3.12499V4.16666H7.29171C7.867 4.16666 8.33337 4.63303 8.33337 5.20833C8.33337 5.78362 7.867 6.24999 7.29171 6.24999H6.25004V7.29166C6.25004 7.86696 5.78367 8.33333 5.20837 8.33333C4.63308 8.33333 4.16671 7.86696 4.16671 7.29166V6.24999H3.12504C2.54974 6.24999 2.08337 5.78362 2.08337 5.20833C2.08337 4.63303 2.54974 4.16666 3.12504 4.16666H4.16671V3.12499C4.16671 2.5497 4.63308 2.08333 5.20837 2.08333ZM13.5417 2.08333C13.9901 2.08333 14.3881 2.37023 14.5299 2.79559L16.7537 9.467L22.2408 11.5247C22.6474 11.6771 22.9167 12.0658 22.9167 12.5C22.9167 12.9342 22.6474 13.3229 22.2408 13.4753L16.7537 15.533L14.5299 22.2044C14.3881 22.6298 13.9901 22.9167 13.5417 22.9167C13.0933 22.9167 12.6953 22.6298 12.5535 22.2044L10.3297 15.533L4.84262 13.4753C4.43605 13.3229 4.16671 12.9342 4.16671 12.5C4.16671 12.0658 4.43605 11.6771 4.84262 11.5247L10.3297 9.467L12.5535 2.79559C12.6953 2.37023 13.0933 2.08333 13.5417 2.08333ZM13.5417 6.41904L12.149 10.5973C12.0496 10.8955 11.8208 11.1328 11.5265 11.2432L8.17504 12.5L11.5265 13.7568C11.8208 13.8672 12.0496 14.1045 12.149 14.4027L13.5417 18.581L14.9344 14.4027C15.0338 14.1045 15.2626 13.8672 15.5569 13.7568L18.9084 12.5L15.5569 11.2432C15.2626 11.1328 15.0338 10.8955 14.9344 10.5973L13.5417 6.41904ZM6.25004 16.6667C6.82534 16.6667 7.29171 17.133 7.29171 17.7083V18.75H8.33337C8.90867 18.75 9.37504 19.2164 9.37504 19.7917C9.37504 20.367 8.90867 20.8333 8.33337 20.8333H7.29171V21.875C7.29171 22.4503 6.82534 22.9167 6.25004 22.9167C5.67474 22.9167 5.20837 22.4503 5.20837 21.875V20.8333H4.16671C3.59141 20.8333 3.12504 20.367 3.12504 19.7917C3.12504 19.2164 3.59141 18.75 4.16671 18.75H5.20837V17.7083C5.20837 17.133 5.67474 16.6667 6.25004 16.6667Z",
            }),
          })
        );
        t.Z = o;
      },
      80205: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            HOMEPAGE_FOOTER_HEIGHT_DESKTOP: function () {
              return f;
            },
            HOMEPAGE_FOOTER_HEIGHT_MOBILE: function () {
              return b;
            },
          });
        var i = n(85893),
          s = n(67294),
          a = n(84872),
          o = n(94745),
          r = n(70133),
          l = n(42257),
          c = n(37899),
          u = n(86650),
          d = n(4535),
          m = n(13301),
          h = n(80822),
          g = n(75485),
          _ = n(13592),
          p = n(88296),
          y = n(90512),
          x = n(4404),
          C = n.n(x);
        let b = 156,
          f = 98,
          v = (e) => {
            let { routeHelper: t } = e,
              n = s.useContext(l.Z),
              { services: r } = s.useContext(c.Z),
              { liked: x } = s.useContext(u.w3),
              { setBackToTopVisible: b } = s.useContext(g.i),
              { crazyRouterChange: f } = s.useContext(_.R),
              v = s.useRef(null),
              z = () => {
                window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
              },
              j = async () => {
                try {
                  let { randomGamesService: e } = r,
                    i = (0, m.yz)(n),
                    s = (0, m.l7)(n),
                    a = await e.getRandomGame(x, { device: i, deviceType: s }),
                    o = t.gamePageLink(a.slug);
                  f(o.href, o.as);
                } catch (e) {
                  console.error("Error page error: ", e.message || e);
                }
              };
            return (
              s.useEffect(() => {
                let e = new IntersectionObserver((e) => {
                  let [t] = e;
                  b(!t.isIntersecting);
                });
                return (
                  v.current && e.observe(v.current),
                  () => {
                    e.disconnect();
                  }
                );
              }, [v, b]),
              (0, i.jsxs)(h.Z, {
                sx: {
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  gap: n.isMobile ? 1 : 3,
                  flexDirection: n.isMobile ? "column" : "row",
                  width: "100%",
                  padding: 3,
                  "& a": { width: 1 },
                },
                ref: v,
                children: [
                  (0, i.jsxs)(p.Z, {
                    variant: "outlined",
                    color: "white",
                    fullWidth: n.isMobile,
                    className: (0, y.Z)(
                      C().footerCallToActionButton,
                      C().isDesktop && !n.isMobile
                    ),
                    height: 50,
                    onClick: j,
                    children: [
                      (0, i.jsx)(d.Z, {}),
                      (0, i.jsx)(o.cC, { id: "common.footer.randomGame" }),
                    ],
                  }),
                  (0, i.jsxs)(p.Z, {
                    variant: "contained",
                    color: "purple",
                    fullWidth: n.isMobile,
                    className: (0, y.Z)(
                      C().footerCallToActionButton,
                      C().isDesktop && !n.isMobile
                    ),
                    height: 50,
                    onClick: z,
                    children: [
                      (0, i.jsx)(a.Z, {}),
                      (0, i.jsx)(o.cC, { id: "common.backToTop" }),
                    ],
                  }),
                ],
              })
            );
          };
        t.default = (0, r.Z)(v);
      },
      44354: function (e, t, n) {
        "use strict";
        n.d(t, {
          $x: function () {
            return d;
          },
          Ah: function () {
            return l;
          },
          JO: function () {
            return r;
          },
          VS: function () {
            return m;
          },
          fC: function () {
            return o;
          },
          lp: function () {
            return u;
          },
        });
        var i = n(90948),
          s = n(3411),
          a = n(32350);
        let o = (0, i.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              margin: t(2),
              marginLeft: t(1.25),
              marginBottom: t(3),
              contentVisibility: "auto",
              contain: "layout paint",
              overflowAnchor: "none",
              height: 218,
              overflow: "hidden",
              display: "flex",
              [n.down(875)]: { flexDirection: "column", height: "unset" },
            };
          }),
          r = (0, i.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              borderRadius: 10,
              backgroundColor: s.D.black[70],
              position: "relative",
              width: 424,
              flexShrink: 0,
              padding: t(2.5),
              height: 218,
              [n.down(875)]: { width: "100%", height: 318 },
            };
          }),
          l = (0, i.ZP)("div", {
            shouldForwardProp: (e) =>
              "sx" !== e && "hovering" !== e && "expanded" !== e,
          })((e) => {
            let {
              expanded: t,
              theme: { breakpoints: n },
            } = e;
            return {
              ...(0, a.no)(4),
              color: s.D.white[60],
              fontSize: 14,
              height: t ? 500 : 146,
              [n.down(875)]: { height: t ? 500 : 244 },
              "& h2": { fontSize: 20 },
              "& a": {
                color: s.D.brand[60],
                fontWeight: 700,
                textDecoration: "underline",
              },
            };
          }),
          c = "220px",
          u = (0, i.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              height: 218,
              overflow: "hidden",
              flex: 1,
              "& ul": {
                paddingTop: 0,
                paddingBottom: 0,
                [n.down(875)]: { marginTop: t(2) },
              },
              "& .double-arrow": { display: "none" },
              "& .arrow": { top: 0, height: "100%" },
              "& li": {
                width: `min(calc(100% / 3), ${c})`,
                [n.up("md")]: { width: `min(calc(100% / 4), ${c})` },
                [n.up("lg")]: { width: `min(calc(100% / 6), ${c})` },
                [n.up("xl")]: { width: `min(calc(100% / 8), ${c})` },
              },
            };
          }),
          d = (0, i.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              height: 102,
              backgroundColor: s.D.black[80],
              marginRight: t(1),
              padding: t(2),
              borderRadius: 10,
              "& img": {
                width: 35,
                height: 35,
                color: s.D.brand[100],
                display: "block",
                marginBottom: t(0.75),
              },
              "&:hover": { backgroundColor: s.D.black[70] },
            };
          }),
          m = (0, i.ZP)("div")({
            fontWeight: 700,
            color: s.D.white[100],
            fontSize: 16,
            textOverflow: "ellipsis",
            overflow: "hidden",
            whiteSpace: "nowrap",
          });
      },
      65216: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return y;
          },
        });
        var i = n(85893),
          s = n(67294),
          a = n(2978);
        let o = (e) => {
          let {
            urlGenerator: t,
            page: n,
            disabled: s,
            children: o,
            sorting: r,
          } = e;
          if (s) return (0, i.jsx)(i.Fragment, { children: o });
          let l = t(n, r);
          return (0, i.jsx)(a.Z, { ...l, children: o });
        };
        var r = n(83514),
          l = n(64774),
          c = n(59411),
          u = n(90512),
          d = n(15417),
          m = n.n(d);
        let h = s.memo((e) => {
            let { showNum: t, page: n, next: s } = e;
            return t
              ? (0, i.jsx)(i.Fragment, { children: n })
              : s
              ? (0, i.jsx)(c.Z, {})
              : (0, i.jsx)(l.Z, {});
          }),
          g = (e) => {
            let {
                paginationLinkType: t,
                disabled: n,
                page: a,
                urlGenerator: l,
                showNum: c,
                isCurrent: d,
              } = e,
              { pageUrlHelper: g } = s.useContext(r.t),
              _ = g.getSorting();
            return (0, i.jsx)(o, {
              page: a,
              disabled: n,
              urlGenerator: l,
              sorting: _,
              children: (0, i.jsx)("div", {
                className: (0, u.Z)(
                  m().gamePageLink,
                  (d || n) && m().disabled,
                  d && m().current,
                  c && m().number
                ),
                children: (0, i.jsx)(h, {
                  showNum: c,
                  page: a,
                  next: "next" === t,
                }),
              }),
            });
          },
          _ = s.memo((e) => {
            let { currentPage: t, urlGenerator: n, totalPages: s } = e,
              a = (function (e, t, n) {
                let i = Array.from({ length: e }, (e, t) => t + 1),
                  s = n - 1;
                if (t < 3)
                  throw Error(
                    "maxLength should be at least 3 to show first, current, and last elements."
                  );
                let a = i.length;
                if (a <= t) return i;
                if (s <= Math.floor(t / 2))
                  return [...i.slice(0, t - 2), "...", i[a - 1]];
                if (s >= a - Math.floor(t / 2))
                  return [i[0], "...", ...i.slice(a - (t - 2))];
                {
                  let e = Math.max(Math.floor((t - 5) / 2), 0);
                  return [
                    i[0],
                    "...",
                    ...i.slice(Math.max(1, s - e), Math.min(a - 1, s + e + 1)),
                    "...",
                    i[a - 1],
                  ];
                }
              })(s, 7, t);
            return (0, i.jsx)(i.Fragment, {
              children: a.map((e, s) =>
                "..." === e
                  ? (0, i.jsx)(
                      "div",
                      { className: m().ellipsis, children: "..." },
                      s
                    )
                  : (0, i.jsx)(
                      g,
                      {
                        page: e,
                        disabled: !1,
                        urlGenerator: n,
                        showNum: !0,
                        isCurrent: e === t,
                      },
                      s
                    )
              ),
            });
          }),
          p = (e) => {
            let { urlGenerator: t, games: n, pageLimit: s } = e,
              { pagination: a, total: o } = n,
              r = s || Number.MAX_SAFE_INTEGER,
              l = Math.min(Math.ceil(o / a.size), r),
              c = a.page,
              u = n.items.length > a.size;
            return l < 2
              ? null
              : (0, i.jsxs)("div", {
                  className: m().paginationContainer,
                  children: [
                    (0, i.jsx)(g, {
                      page: c - 1,
                      disabled: !(c > 1),
                      paginationLinkType: "previous",
                      urlGenerator: t,
                    }),
                    (0, i.jsx)(_, {
                      currentPage: c,
                      totalPages: l,
                      urlGenerator: t,
                    }),
                    (0, i.jsx)(g, {
                      page: c + 1,
                      disabled: !(c < l && !u),
                      paginationLinkType: "next",
                      urlGenerator: t,
                    }),
                  ],
                });
          };
        var y = p;
      },
      84973: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(37899);
        t.Z = function (e) {
          let t = (t) => {
            let { services: n } = s.useContext(a.Z);
            return (0, i.jsx)(e, { services: n, ...t });
          };
          return t;
        };
      },
      60081: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(9008),
          o = n.n(a),
          r = n(33209),
          l = n(75007),
          c = n(8697);
        let u = (e) => {
          let {
              canonical: t,
              title: n,
              description: a,
              imageUrl: u = "crazygames/share.png",
              imageWidth: d = 1200,
              imageHeight: m = 630,
              type: h,
            } = e,
            { locale: g } = s.useContext(c.Z),
            _ = (0, l.ZP)(u, { width: d, height: m, fit: "crop" });
          return (0, i.jsxs)(o(), {
            children: [
              (0, i.jsx)("meta", { property: "og:url", content: t }),
              (0, i.jsx)("meta", { property: "og:title", content: n }),
              (0, i.jsx)("meta", { property: "og:description", content: a }),
              (0, i.jsx)("meta", {
                property: "og:locale",
                content: (0, r.Ld)(g),
              }),
              (0, i.jsx)("meta", { property: "og:image", content: _ }),
              (0, i.jsx)("meta", {
                property: "og:image:width",
                content: d.toString(),
              }),
              (0, i.jsx)("meta", {
                property: "og:image:height",
                content: m.toString(),
              }),
              h && (0, i.jsx)("meta", { property: "og:type", content: h }),
              (0, i.jsx)("meta", {
                property: "twitter:card",
                content: "summary_large_image",
              }),
              (0, i.jsx)("meta", { property: "twitter:url", content: t }),
              (0, i.jsx)("meta", { property: "twitter:title", content: n }),
              (0, i.jsx)("meta", {
                property: "twitter:description",
                content: a,
              }),
              (0, i.jsx)("meta", { property: "twitter:image", content: _ }),
            ],
          });
        };
        t.Z = u;
      },
      65801: function (e, t, n) {
        "use strict";
        var i = n(61730);
        let s = () =>
          (0, i.Z)("@media (orientation: landscape), (min-width: 481px)");
        t.Z = s;
      },
      92975: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(42257);
        t.Z = function (e) {
          let t = (t) => {
            let n = s.useContext(a.Z);
            return (0, i.jsx)(e, { deviceType: n, ...t });
          };
          return t;
        };
      },
      65336: function (e, t, n) {
        "use strict";
        function i(e) {
          let t = Array(e);
          for (let e = 0; e < t.length; e++) t[e] = e + 1;
          return t;
        }
        function s(e, t) {
          let n = new Map();
          for (let i of e) {
            let e = t(i);
            n.has(e) ? n.get(e).push(i) : n.set(e, [i]);
          }
          return n;
        }
        n.d(t, {
          o: function () {
            return i;
          },
          v: function () {
            return s;
          },
        });
      },
      92113: function (e, t) {
        "use strict";
        t.Z = function (e, t) {
          let n =
            arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
          try {
            return e.number(t, n);
          } catch (e) {
            return console.error(e), `${t}`;
          }
        };
      },
      39471: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(67294),
          a = n(63306);
        t.Z = function (e) {
          return class extends s.Component {
            static async getInitialProps(t) {
              let n = e.getInitialProps ? await e.getInitialProps(t) : {};
              return n;
            }
            render() {
              return (0, i.jsx)(a.Z.Consumer, {
                children: (t) => {
                  let { routeHelper: n } = t;
                  return (0, i.jsx)(e, { routeHelper: n, ...this.props });
                },
              });
            }
          };
        };
      },
      78473: function (e, t) {
        "use strict";
        t.Z = function (e) {
          let t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
          return Array.from(Array(e), (e, n) => n + t);
        };
      },
      4743: function (e, t) {
        "use strict";
        t.Z = function (e, t) {
          return t.isIos && e.swap ? e.swap : e.data;
        };
      },
      9978: function (e, t, n) {
        "use strict";
        var i = n(85893),
          s = n(2734);
        t.Z = function (e) {
          let t = (t) => {
            let n = (0, s.Z)();
            return (0, i.jsx)(e, { theme: n, ...t });
          };
          return t;
        };
      },
      3050: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return tg;
            },
          });
        var i = n(85893),
          s = n(67294),
          a = n(18288),
          o = n(44715),
          r = n(73222),
          l = n(88642),
          c = n(83808),
          u = n(89555),
          d = n(94745),
          m = n(2978),
          h = n(90512),
          g = n(68107),
          _ = n.n(g);
        let p = (e) => {
          let { linkData: t, label: n, customBtnLink: s } = e;
          if (!n) return null;
          if (t) {
            let e = new URL(t.href);
            e.searchParams.set("origin", "viewmore"), (t.href = e.toString());
          }
          return (0, i.jsxs)("div", {
            className: (0, h.Z)(
              _().carouselTitleContainerDiv,
              "titleContainer"
            ),
            children: [
              (0, i.jsx)("h2", { className: _().carouselTitle, children: n }),
              t &&
                !s &&
                (0, i.jsx)(m.Z, {
                  ...t,
                  prefetch: !0,
                  className: _().carouselTitleLink,
                  style: { userSelect: "none" },
                  children: (0, i.jsx)(d.cC, {
                    id: "carousels.category.viewMore",
                  }),
                }),
              s || null,
            ],
          });
        };
        var y = n(17253),
          x = n(42257),
          C = n(13301),
          b = n(37899),
          f = n(93988);
        let v = (e) => {
          let { pageNumber: t = 1, pageSize: n } = e,
            { carouselService: i, experimentService: a } = s.useContext(
              b.Z
            ).services,
            o = s.useContext(x.Z),
            l = o.isMobile || o.isTablet,
            [c, u] = s.useState(!0),
            [d, m] = s.useState([]),
            [h, g] = s.useState(void 0);
          s.useEffect(() => {
            let e = async () => {
              let e = await a.getModelForExpKey(f.Al);
              g(e);
            };
            e();
          }, [a]);
          let _ = s.useCallback(async () => {
            if (!h || t < 0 || !isFinite(t) || (n && n < 0)) return;
            let e = (0, C.yz)(o),
              s = (0, C.l7)(o),
              a = l ? r.r7 : r.ln,
              c = await i.getModelGames(h, e, s, {
                place: "homePage_recommendedCarousel",
                pagination: { page: t, size: n || a },
              });
            c && c.length > 0 && m(c), u(!1);
          }, [o, l, i, h, t, n]);
          return (
            s.useEffect(() => {
              _();
            }, [_]),
            { fetchedModelGames: d, loadingModelGames: c, modelName: h }
          );
        };
        var z = n(31601),
          j = n(9512),
          w = n(6590);
        let B = (e) => {
          let { games: t } = e,
            n = s.useContext(x.Z),
            a = (0, C.l7)(n),
            { services: o } = s.useContext(b.Z),
            l = n.isDesktop ? r.ln : r.r7,
            c = s.useRef(2),
            { fetchedModelGames: u, modelName: d } = v({
              pageNumber: 2,
              pageSize: l,
            }),
            m = n.isMobile,
            h = m ? r.lp : r.Qg,
            g = r.Vs - t.total,
            _ = [...t.items];
          t.total < h && g > 0 && _.push(...u);
          let p = async (e) => {
            let { gameService: t } = o,
              i = (0, C.yz)(n),
              s = await t.featuredGames(i, !0, { page: e, size: h }),
              u = s.games.items;
            if (u.length > 0) return u;
            if (!d) return;
            if (((c.current = c.current + 1), n.isDesktop && 3 === c.current)) {
              let e = n.isDesktop ? r.VH : r.dE;
              c.current = Math.ceil((e + l + 1) / l);
            }
            let m = await o.modelApi.getModelGames(d, i, a, {
              place: "homePage_recommendedCarouselMore",
              pagination: { page: c.current, size: l },
            });
            if (m && m.items.length > 0) return m.items;
          };
          return (0, i.jsx)(y.Z, {
            games: _,
            fetchDataFn: p,
            isMobileSkeletonEnabled: !0,
            maxNoItems: r.Vs,
            pageSize: m ? r.lp : r.Qg,
            renderGameThumb: (e, t) =>
              (0, i.jsx)(j.Z, {
                game: e,
                eagerLoading: t < 6,
                onClickAction: () => {
                  o.crazyAnalyticsService.gameClickedFromList(_);
                },
                isResponsive: !0,
                imgResponsiveSizes: z.D1,
              }),
            renderSkeleton: () => (0, i.jsx)(w.Z, { isResponsive: !0 }),
          });
        };
        var k = n(94984);
        let Z = (e) => {
          let { games: t } = e;
          return (0, i.jsxs)("div", {
            className: _().simpleCarouselContainer,
            children: [
              (0, i.jsx)(p, {
                label: (0, i.jsx)(d.cC, { id: "games.featured.title" }),
              }),
              (0, i.jsx)(k.H, {
                newClickOrigin: "featured",
                children: (0, i.jsx)(B, { games: t }),
              }),
            ],
          });
        };
        var T = n(82702),
          L = n(74040);
        let S = (e) => {
          let {
            label: t,
            games: n,
            pageSize: s,
            renderGameThumb: a,
            renderSkeleton: o,
            maxNoItems: r,
            maxGames: l,
            linkData: c,
            fetchDataFn: u,
            allGamesLabel: d,
            allGamesLinkData: m,
            dataSize: h,
          } = e;
          return !n || n.length < 1
            ? null
            : (0, i.jsxs)("div", {
                className: _().simpleCarouselContainer,
                children: [
                  (0, i.jsx)(p, {
                    label: (0, i.jsx)("span", { children: t }),
                    linkData: c,
                  }),
                  (0, i.jsx)(y.Z, {
                    games: n,
                    dataSize: h ?? n.length,
                    maxNoItems: r,
                    fetchDataFn: u,
                    pageSize: s,
                    totalNumberOfItems: l,
                    renderGameThumb: a,
                    renderSkeleton: o,
                    allGamesLabel: d,
                    allGamesLinkData: m,
                  }),
                ],
              });
        };
        var M = n(75007),
          G = n(90948),
          R = n(3411);
        let I = (0, G.ZP)("div")((e) => {
            let {
              theme: { spacing: t },
            } = e;
            return {
              width: `calc(100% - ${t(4)})`,
              display: "flex",
              justifyContent: "space-between",
              height: 183,
              marginTop: t(2),
              marginBottom: t(2),
              marginLeft: t(),
              marginRight: t(),
              background: R.D.black[80],
              borderRadius: t(),
            };
          }),
          P = (0, G.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              display: "flex",
              alignItems: "center",
              paddingLeft: t(7),
              paddingRight: t(5),
              width: 456,
              "& h2": { fontSize: 28, fontWeight: 700 },
              [n.down(1330)]: {
                paddingLeft: t(4),
                paddingRight: t(2),
                width: 344,
                "& h2": { fontSize: 24 },
              },
              [n.down(790)]: {
                width: 150,
                paddingLeft: t(2),
                paddingRight: t(1),
                "& img": { display: "none" },
              },
            };
          }),
          D = (0, G.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
              "& span": { fontSize: 16, fontWeight: 400, color: R.D.white[60] },
              "& h3": { fontSize: 20, fontWeight: 700 },
              [n.down(1370)]: { "& button": { fontSize: 13 } },
              [n.down(1220)]: {
                "& span": { fontSize: 12 },
                "& h3": { fontSize: 16 },
              },
              [n.down(750)]: { "& span": { display: "none" } },
              "& button": { marginTop: t(1.5) },
            };
          }),
          N = (0, G.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: t(4),
              flex: 1,
              margin: t(1.5),
              background: R.D.black[90],
              borderRadius: t(),
              padding: t(1.5),
              [n.down(1350)]: { margin: t(1) },
              "& img": {
                [n.down(1220)]: { width: 100 },
                [n.down(1160)]: { display: "none" },
              },
            };
          });
        var O = n(63306),
          E = n(88296);
        let F = () => {
            let [e, t] = s.useState([]),
              { pageService: n } = s.useContext(b.Z).services;
            return (
              s.useEffect(() => {
                (async () => {
                  t((await n.multiplayerTags()).tags);
                })();
              }, [n]),
              {
                twoPlayerSlug:
                  e.find((e) => "1d7cf360-3b2f-4442-820a-055cf967a0ad" === e.id)
                    ?.slug || "2-player",
                withFriendsSlug:
                  e.find((e) => "7a08b313-2b2f-4042-9135-821d47ad8668" === e.id)
                    ?.slug || "with-friends",
              }
            );
          },
          A = () => {
            let { routeHelper: e } = s.useContext(O.Z),
              { twoPlayerSlug: t, withFriendsSlug: n } = F(),
              a = e.tagPageDirectLink(t),
              o = e.tagPageDirectLink(n);
            return (0, i.jsxs)(I, {
              children: [
                (0, i.jsxs)(P, {
                  children: [
                    (0, i.jsx)("h2", {
                      children: (0, i.jsx)(d.cC, {
                        id: "games.multiplayer.title",
                      }),
                    }),
                    (0, i.jsx)("img", {
                      src: (0, M.ZP)(
                        "crazygames/multiplayerBanner1.svg",
                        {},
                        !1
                      ),
                      alt: "Play with friends",
                      width: 216,
                      height: 172,
                      style: { alignSelf: "end" },
                    }),
                  ],
                }),
                (0, i.jsxs)(N, {
                  children: [
                    (0, i.jsx)("img", {
                      src: (0, M.ZP)(
                        "crazygames/multiplayerBanner2.svg",
                        {},
                        !1
                      ),
                      alt: "Local multiplayer games",
                      width: 125,
                      height: 78,
                    }),
                    (0, i.jsxs)(D, {
                      children: [
                        (0, i.jsx)("h3", {
                          children: (0, i.jsx)(d.cC, {
                            id: "games.multiplayer.section1Title",
                          }),
                        }),
                        (0, i.jsx)("span", {
                          children: (0, i.jsx)(d.cC, {
                            id: "games.multiplayer.section1Subtitle",
                          }),
                        }),
                        (0, i.jsx)(m.Z, {
                          ...a,
                          prefetch: !0,
                          children: (0, i.jsx)(E.Z, {
                            variant: "contained",
                            color: "purple",
                            height: 34,
                            children: (0, i.jsx)(d.cC, {
                              id: "games.multiplayer.button",
                            }),
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, i.jsxs)(N, {
                  children: [
                    (0, i.jsx)("img", {
                      src: (0, M.ZP)(
                        "crazygames/multiplayerBanner3.svg",
                        {},
                        !1
                      ),
                      alt: "Online multiplayer games",
                      width: 104,
                      height: 89,
                    }),
                    (0, i.jsxs)(D, {
                      children: [
                        (0, i.jsx)("h3", {
                          children: (0, i.jsx)(d.cC, {
                            id: "games.multiplayer.section2Title",
                          }),
                        }),
                        (0, i.jsx)("span", {
                          children: (0, i.jsx)(d.cC, {
                            id: "games.multiplayer.section2Subtitle",
                          }),
                        }),
                        (0, i.jsx)(m.Z, {
                          ...o,
                          prefetch: !0,
                          children: (0, i.jsx)(E.Z, {
                            variant: "contained",
                            color: "purple",
                            height: 34,
                            children: (0, i.jsx)(d.cC, {
                              id: "games.multiplayer.button",
                            }),
                          }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            });
          };
        var H = n(81792);
        let V = s.memo((e) => {
            let { pageSize: t } = e;
            return (0, i.jsx)("div", {
              className: (0, h.Z)(
                _().simpleCarouselContainer,
                _().skeletonCarouselContainer
              ),
              children: (0, i.jsx)(y.Z, {
                forceSkeleton: !0,
                games: [],
                maxNoItems: r.kY,
                pageSize: t,
                renderSkeleton: () => (0, i.jsx)(w.Z, { isResponsive: !0 }),
              }),
            });
          }),
          q = s.memo((e) => {
            let {
                pageSize: t,
                slug: n,
                tag: a,
                categoryId: o,
                slidesToLoadEagerly: l = 0,
                crawlerData: c,
              } = e,
              d = s.useContext(b.Z).services,
              { routeHelper: m } = s.useContext(O.Z),
              h = s.useContext(x.Z),
              [g, v] = s.useState(c?.isCrawler && c?.games ? c.games : []),
              B = u.ag._("common.games.all", { title: a.title }),
              Z = m.tagOrCategoryPageDirectLink(n, a.isCategory);
            s.useEffect(() => {
              let e = async () => {
                let { modelApi: e } = d,
                  n = (0, C.yz)(h),
                  i = (0, C.l7)(h),
                  s = await d.experimentService.getModelForExpKey(f.Al),
                  r = await e.getModelGames(s, n, i, {
                    place: "homePage_categoryCarousel",
                    category: a.isCategory ? o : void 0,
                    tag: a.isCategory ? void 0 : o,
                    pagination: { page: 1, size: t },
                  });
                r && r.items.length > 0 && v(r.items);
              };
              e();
            }, [o, h, t, d, a.isCategory]);
            let T = async (e) => {
              let { modelApi: n } = d,
                i = (0, C.yz)(h),
                s = (0, C.l7)(h),
                r = await d.experimentService.getModelForExpKey(f.Al),
                l = await n.getModelGames(r, i, s, {
                  place: "homePage_categoryCarouselMore",
                  category: a.isCategory ? o : void 0,
                  tag: a.isCategory ? void 0 : o,
                  pagination: { page: e, size: t },
                });
              return l?.items || [];
            };
            return (0, i.jsx)(k.H, {
              newClickOrigin: a.slug_en_US,
              children: (0, i.jsxs)("div", {
                className: _().simpleCarouselContainer,
                children: [
                  (0, i.jsx)(p, {
                    label: (0, i.jsx)("span", { children: a.title }),
                    linkData: Z,
                  }),
                  (0, i.jsx)(y.Z, {
                    games: g,
                    maxNoItems: r.kY,
                    isMobileSkeletonEnabled: 0 === g.length,
                    dataSize: t,
                    pageSize: t,
                    fetchDataFn: T,
                    allGamesLinkData: Z,
                    allGamesLabel: B,
                    renderGameThumb: (e, t) =>
                      (0, i.jsx)(j.Z, {
                        game: e,
                        eagerLoading: t < l,
                        onClickAction: () => {
                          d.crazyAnalyticsService.gameClickedFromList(g);
                        },
                        isResponsive: !0,
                        imgResponsiveSizes: z.D1,
                      }),
                    renderSkeleton: () => (0, i.jsx)(w.Z, { isResponsive: !0 }),
                  }),
                ],
              }),
            });
          });
        var W = n(2138),
          K = n(4743),
          $ = n(51491);
        let X = s.memo((e) => {
            let {
                carouselData: t,
                index: n,
                isCrawler: a,
                loadingCarouselData: o,
              } = e,
              r = (0, $.Z)(),
              l = s.useContext(x.Z),
              { slug: c, tag: u } = t,
              d = (0, W.y)(l);
            return !a && o
              ? (0, i.jsx)(V, { pageSize: d }, c)
              : (0, i.jsx)(
                  q,
                  {
                    slidesToLoadEagerly: 3 >= n ? 6 : 0,
                    pageSize: d,
                    tag: u,
                    slug: c,
                    categoryId: t.id,
                    crawlerData: {
                      isCrawler: a ?? !1,
                      games: (0, K.Z)(t.games, { isIos: r }),
                    },
                  },
                  c
                );
          }),
          Y = "7a08b313-2b2f-4042-9135-821d47ad8668",
          Q = s.memo((e) => {
            let {
                categoryGames: t,
                isCrawler: n,
                weeklyRecommendedGames: a,
              } = e,
              { carouselService: o, crazyAnalyticsService: l } = s.useContext(
                b.Z
              ).services,
              c = s.useContext(x.Z),
              { loadingUser: u } = s.useContext(L.S),
              [d, m] = s.useState(!0),
              { data: h, loading: g } = T.fx(),
              _ = s.useRef(t.filter((e) => e.id !== Y)),
              [p, y] = s.useState(_.current);
            if (
              (s.useEffect(() => {
                n || u || g || m(!1);
              }, [h, u, !1, g, n]),
              !t || t.length < 1)
            )
              return null;
            let f = t.find((e) => e.id === Y),
              v = c.isMobile ? r.z : r.C8,
              B = (0, C.yz)(c);
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(X, {
                  carouselData: f,
                  index: 0,
                  isCrawler: n,
                  loadingCarouselData: d,
                }),
                (0, i.jsx)(H.Z, {
                  children: (0, i.jsx)(A, {}, "multiplayer-banner"),
                }),
                a
                  ? (0, i.jsx)(k.H, {
                      newClickOrigin: "weekly",
                      children: (0, i.jsx)(S, {
                        label: "Christmas Games",
                        games: a.items,
                        maxNoItems: Math.min(r.Sr, a.total),
                        pageSize: v,
                        fetchDataFn: (e) =>
                          o.weeklyRecommendedGames(B, { page: e, size: v }),
                        renderGameThumb: (e) =>
                          (0, i.jsx)(j.Z, {
                            game: e,
                            onClickAction: () => {
                              l.gameClickedFromList(a.items);
                            },
                            isResponsive: !0,
                            imgResponsiveSizes: z.D1,
                          }),
                        renderSkeleton: () =>
                          (0, i.jsx)(w.Z, { isResponsive: !0 }),
                      }),
                    })
                  : null,
                p.map((e, t) =>
                  (0, i.jsx)(
                    X,
                    {
                      carouselData: e,
                      index: t + 1,
                      isCrawler: n,
                      loadingCarouselData: d,
                    },
                    e.slug
                  )
                ),
              ],
            });
          }),
          U = (0, G.ZP)("div", { shouldForwardProp: (e) => "isDesktop" !== e })(
            (e) => {
              let {
                theme: { spacing: t },
                isDesktop: n,
              } = e;
              return { paddingLeft: n ? t(1) : void 0, paddingBottom: t(2.5) };
            }
          );
        var J = n(78473),
          ee = n(56774);
        let et = (e) => {
          let {
              games: t,
              completeWithPlaceholder: n,
              limit: s,
              eagerLoading: a,
              onClickAction: o,
            } = e,
            r = void 0 !== s ? s : t ? t.length : 20;
          return (0, i.jsxs)(ee.aL, {
            children: [
              !t && s
                ? (0, J.Z)(s).map((e, t) =>
                    (0, i.jsx)(w.Z, { isResponsive: !0 }, t)
                  )
                : null,
              t &&
                t
                  .slice(0, r)
                  .map((e) =>
                    (0, i.jsx)(
                      j.Z,
                      {
                        game: e,
                        onClickAction: o,
                        eagerLoading: a,
                        isResponsive: !0,
                        imgResponsiveSizes: z.D1,
                      },
                      e.slug
                    )
                  ),
              n && t && void 0 !== s && t.length < s
                ? (0, J.Z)(s - t.length).map((e, t) => n(t))
                : null,
            ],
          });
        };
        var en = n(35600);
        let ei = [
            { breakpoint: 0, width: 471 },
            { breakpoint: 600, width: 448 },
            { breakpoint: 800, width: 436 },
            { breakpoint: 1e3, width: 428 },
            { breakpoint: 1200, width: 519 },
            { breakpoint: 2100, width: 675 },
            { breakpoint: 3e3, width: 710 },
          ],
          es = (e) => {
            let {
                loading: t,
                limit: n = 20,
                games: a,
                requestData: o,
                requestDataThreshold: r,
                featured: l,
                eagerLoadIndex: c,
                firstImageHighPriority: u,
              } = e,
              { crazyAnalyticsService: d } = s.useContext(b.Z).services,
              m = l ? 5 : 1,
              h =
                a && !t
                  ? a.length - (a.length % m)
                  : Math.max(n, a?.length || 0),
              g = [],
              _ = () => {
                d.gameClickedFromList(a);
              };
            if (a || n)
              for (let e = 0; e < h; e += m) {
                if (l) {
                  let n = !!(a && a[e]);
                  n
                    ? g.push(
                        (0, i.jsx)(
                          j.Z,
                          {
                            game: a[e],
                            isResponsive: !0,
                            eagerLoading: !!(c && e < c),
                            onClickAction: _,
                            imgResponsiveSizes: ei,
                            imgDPRSize: 675,
                            imgFetchPriority: u && 0 === e ? "high" : void 0,
                          },
                          a[e].slug
                        )
                      )
                    : t &&
                      g.push(
                        (0, i.jsx)(
                          w.Z,
                          { isResponsive: !0, sx: { mx: 0.25 } },
                          e
                        )
                      );
                }
                let n = l ? e + 1 : e,
                  s = a && a[e + 1] ? a[e + 1].slug : n;
                g.push(
                  (0, i.jsx)(
                    et,
                    {
                      games: void 0 !== a ? a.slice(n, e + 5) : void 0,
                      eagerLoading: !!(c && e < c),
                      limit: t ? 4 : void 0,
                      onClickAction: _,
                      completeWithPlaceholder: t
                        ? (e) =>
                            (0, i.jsx)(
                              w.Z,
                              {
                                isResponsive: !0,
                                sx: { boxSizing: "content-box", mx: 0.25 },
                              },
                              e
                            )
                        : void 0,
                    },
                    s
                  )
                );
              }
            return (0, i.jsx)(en.Z, {
              requestData: o,
              requestDataThreshold: r,
              children: g,
            });
          },
          ea = (e) => {
            let {
              requestDataThreshold: t,
              requestData: n,
              games: s,
              loading: a = !1,
              loadingLimit: o,
            } = e;
            return (0, i.jsx)("div", {
              className: _().recommendedDesktopContainer,
              children: (0, i.jsx)(es, {
                games: s,
                featured: !0,
                requestData: n,
                requestDataThreshold: t,
                eagerLoadIndex: 10,
                limit: a ? o : void 0,
                loading: a,
                firstImageHighPriority: !0,
              }),
            });
          };
        var eo = n(96201),
          er = n(2734),
          el = n(80822),
          ec = n(51806),
          eu = n(88061),
          ed = n(10029),
          em = n(95914);
        let eh = s.memo((e) =>
          (0, i.jsx)(em.Z, {
            ...e,
            viewBox: "0 0 24 24",
            children: (0, i.jsx)("path", {
              d: "M6 19.8774V4.12264C6 2.4676 7.58699 1.45125 8.82368 2.31427L20.1119 10.1916C21.296 11.018 21.2961 12.982 20.1119 13.8084L8.82368 21.6857C7.58699 22.5487 6 21.5324 6 19.8774Z",
            }),
          })
        );
        var eg = n(77655),
          e_ = n(1982),
          ep = n(72552),
          ey = n(20702),
          ex = n(88531),
          eC = n(90949),
          eb = n.n(eC);
        let ef = s.memo((e) => {
          let { game: t, width: n, loading: a } = e,
            o = t.covers && t.covers["1x1"] ? t.covers["1x1"] : t.cover,
            { gameService: r } = s.useContext(b.Z).services,
            l = s.useContext(x.Z),
            c = (0, C.yz)(l),
            [u, d] = s.useState(!1),
            [m, g] = s.useState(!1),
            _ = s.useRef(null),
            p = s.useContext(eg.Y).addViewedGames,
            y = (0, ep.Z)(s.useContext(e_.t)),
            f = s.useRef(null),
            v = s.useCallback(() => {
              t && r.prefetchGameData(t, c);
            }, [c, t, r]);
          return (
            s.useEffect(() => {
              let e;
              return (
                _ &&
                  _.current &&
                  ((e = _.current),
                  ey.Z.get().observe(_.current, () => {
                    ey.Z.get().unobserve(e), p(t.id, y);
                  })),
                () => {
                  e && ey.Z.get().unobserve(e);
                }
              );
            }, [t.id, p, y]),
            s.useEffect(() => {
              let e = new IntersectionObserver((e) => {
                let [t] = e;
                d(t.isIntersecting),
                  !m &&
                    t.isIntersecting &&
                    (g(!0), (0, ed.requestIdleCallback)(v));
              });
              return (
                _ && _.current && e.observe(_.current),
                () => {
                  e.disconnect();
                }
              );
            }, [a, _, m, v]),
            (0, i.jsx)(eu.Z, {
              slug: t.slug,
              ref: f,
              children: (0, i.jsxs)("div", {
                className: (0, h.Z)(eb().instantThumb, eb().isLarge),
                children: [
                  (0, i.jsxs)("div", {
                    className: eb().frontArea,
                    children: [
                      u &&
                        n &&
                        !a &&
                        (0, i.jsx)(ec.Z, { videoWidth: n, game: t }),
                      n && !a
                        ? (0, i.jsx)("img", {
                            src: (0, M.ZP)(t.cover, { width: n }),
                            alt: t.name,
                            style: {
                              aspectRatio: "391 / 219",
                              borderBottomLeftRadius: 0,
                              borderBottomRightRadius: 0,
                            },
                            srcSet: (0, M.LI)(t.cover, { width: n }),
                          })
                        : (0, i.jsx)("div", {
                            className: eb().largeThumbPlaceholder,
                          }),
                      !a &&
                        (0, i.jsxs)("div", {
                          className: eb().bottomContainer,
                          children: [
                            (0, i.jsx)("img", {
                              src: (0, M.ZP)(o, { width: 50 }),
                              srcSet: (0, M.LI)(o, { width: 50 }),
                              alt: t.name,
                            }),
                            (0, i.jsxs)("div", {
                              ref: _,
                              style: { maxWidth: "calc(100% - 114px)" },
                              children: [
                                (0, i.jsx)("div", {
                                  className: eb().gameNameContainer,
                                  children: t.name,
                                }),
                                (0, i.jsx)("div", {
                                  style: { color: "rgba(255, 255, 255, 0.60)" },
                                  children: t.categoryName,
                                }),
                              ],
                            }),
                            (0, i.jsx)(E.Z, {
                              variant: "contained",
                              color: "purple",
                              children: (0, i.jsx)(eh, {
                                style: {
                                  width: 24,
                                  height: 24,
                                  marginRight: 0,
                                },
                              }),
                            }),
                          ],
                        }),
                    ],
                  }),
                  !a &&
                    n &&
                    (0, i.jsx)("div", {
                      className: eb().thumbOverlay,
                      children: (0, i.jsx)("div", {
                        className: eb().thumbBlur,
                        children: (0, i.jsx)("img", {
                          className: eb().gameBack,
                          src: (0, M.ZP)(t.cover, { width: n, blur: 20 }),
                          srcSet: (0, M.LI)(t.cover, { width: n, blur: 20 }),
                          alt: t.name,
                        }),
                      }),
                    }),
                  (0, i.jsx)(ex.Z, {
                    videoPlaying: !1,
                    gameThumbLabels: t.gameThumbLabels,
                  }),
                ],
              }),
            })
          );
        });
        var ev = n(65336);
        let ez = s.memo(() =>
          (0, i.jsx)("div", {
            style: {
              width: "100%",
              borderRadius: 16,
              position: "relative",
              overflow: "hidden",
              aspectRatio: "390 / 300",
              background: R.D.black[60],
            },
          })
        );
        var ej = n(65801);
        let ew = (e) => {
            let { games: t, loading: n, expectedSize: a, isCrawler: o } = e,
              { innerWidth: r } = s.useContext(eo.b),
              { spacing: l } = (0, er.Z)(),
              c = (0, ej.Z)(),
              u = () => (r ? (c ? Math.ceil(r / 2) : Math.ceil(r)) : void 0),
              d = c || o ? t : t.slice(0, 1);
            return (0, i.jsxs)(el.Z, {
              sx: {
                width: "100%",
                padding: l(2),
                display: "grid",
                gridTemplateColumns: "repeat(1, 1fr)",
                gridColumnGap: l(2),
                gridRowGap: l(2),
                position: "relative",
                "@media (orientation: landscape), (min-width: 481px)": {
                  gridTemplateColumns: "repeat(2, 1fr)",
                },
                maxHeight: 0 === d.length ? 284 : void 0,
                overflow: 0 === d.length ? "hidden" : void 0,
              },
              children: [
                0 === d.length &&
                  (0, ev.o)(a).map((e) => (0, i.jsx)(ez, {}, e)),
                d.map((e) =>
                  (0, i.jsx)(
                    k.H,
                    {
                      newClickOrigin: "instantLarge",
                      children: (0, i.jsx)(ef, {
                        game: e,
                        width: u(),
                        loading: n,
                      }),
                    },
                    e.slug
                  )
                ),
              ],
            });
          },
          eB = s.memo((e) => {
            let { game: t, width: n, loading: a } = e,
              o = t.covers && t.covers["1x1"] ? t.covers["1x1"] : t.cover,
              { gameService: r } = s.useContext(b.Z).services,
              l = s.useContext(x.Z),
              c = (0, C.yz)(l),
              [u, d] = s.useState(!1),
              m = s.useRef(null),
              h = s.useContext(eg.Y).addViewedGames,
              g = (0, ep.Z)(s.useContext(e_.t)),
              _ = s.useRef(null),
              p = s.useCallback(() => {
                t && r.prefetchGameData(t, c);
              }, [c, t, r]);
            return (
              s.useEffect(() => {
                let e = new IntersectionObserver((e) => {
                  let [t] = e;
                  !u &&
                    t.isIntersecting &&
                    (d(!0), (0, ed.requestIdleCallback)(p));
                });
                return (
                  m && m.current && e.observe(m.current),
                  () => {
                    e.disconnect();
                  }
                );
              }, [m, u, p]),
              s.useEffect(() => {
                let e;
                return (
                  m &&
                    m.current &&
                    ((e = m.current),
                    ey.Z.get().observe(m.current, () => {
                      ey.Z.get().unobserve(e), h(t.id, g);
                    })),
                  () => {
                    e && ey.Z.get().unobserve(e);
                  }
                );
              }, [t.id, h, g]),
              (0, i.jsxs)("div", {
                className: eb().instantThumb,
                ref: _,
                children: [
                  (0, i.jsx)(eu.Z, {
                    slug: t.slug,
                    children: (0, i.jsxs)("div", {
                      className: eb().frontArea,
                      children: [
                        a
                          ? (0, i.jsx)("div", {
                              className: eb().smallThumbPlaceholder,
                            })
                          : (0, i.jsx)("img", {
                              src: (0, M.ZP)(o, { height: n }),
                              srcSet: (0, M.LI)(o, { height: n }),
                              alt: t.name,
                            }),
                        (0, i.jsx)("div", {
                          ref: m,
                          className: eb().gameNameContainer,
                          children: t.name,
                        }),
                      ],
                    }),
                  }),
                  !a &&
                    (0, i.jsx)("div", {
                      className: eb().thumbOverlay,
                      children: (0, i.jsx)("div", {
                        className: eb().thumbBlur,
                        children: (0, i.jsx)("img", {
                          className: eb().gameBack,
                          src: (0, M.ZP)(o, { height: n, blur: 25 }),
                          srcSet: (0, M.LI)(o, { height: n, blur: 25 }),
                          alt: t.name,
                        }),
                      }),
                    }),
                  (0, i.jsx)(ex.Z, {
                    videoPlaying: !1,
                    gameThumbLabels: t.gameThumbLabels,
                  }),
                ],
              })
            );
          });
        var ek = n(57802);
        let eZ = (e) => {
          let { games: t, loading: n, expectedSize: a } = e,
            { innerWidth: o } = s.useContext(eo.b),
            { spacing: r } = (0, er.Z)(),
            l = (0, ej.Z)(),
            c = () => (o ? (l ? Math.ceil(o / 4) : Math.ceil(o / 2)) : 200);
          return (0, i.jsxs)(el.Z, {
            sx: {
              width: "100%",
              padding: r(2),
              display: "grid",
              gridTemplateColumns: "repeat(2, 1fr)",
              gridColumnGap: r(2),
              gridRowGap: r(2),
              position: "relative",
              "@media (orientation: landscape), (min-width: 481px)": {
                gridTemplateColumns: "repeat(4, 1fr)",
              },
            },
            children: [
              0 === t.length &&
                (0, ev.o)(a).map((e) => (0, i.jsx)(ek.Z, {}, e)),
              0 !== t.length &&
                t.map((e) =>
                  (0, i.jsx)(
                    k.H,
                    {
                      newClickOrigin: "instantMedium",
                      children: (0, i.jsx)(eB, {
                        game: e,
                        width: c(),
                        loading: n,
                      }),
                    },
                    e.slug
                  )
                ),
            ],
          });
        };
        var eT = n(61730),
          eL = n(98865),
          eS = n(70150),
          eM = n(11120),
          eG = n(92113),
          eR = n(86266),
          eI = n.n(eR);
        let eP = (e) => {
            let {
                game: t,
                id: n,
                isIntersecting: a,
                style: o,
                isCrawler: r,
              } = e,
              { innerWidth: l } = s.useContext(eo.b),
              { i18n: c } = (0, d.mV)(),
              u = (0, eT.Z)(
                "@media (orientation: landscape), (min-width: 481px)"
              ),
              [m, h] = s.useState(!1),
              [g, _] = s.useState(!1),
              p = m && g ? 1 : 0,
              y = l
                ? (u ? Math.ceil(l ? 0.8 * l : 0) : Math.ceil(l)) -
                  (u ? 20 : 40)
                : void 0,
              f = l ? l / (u ? 4 : 2) : y,
              { gameService: v } = s.useContext(b.Z).services,
              z = s.useContext(x.Z),
              j = (0, C.yz)(z),
              w = s.useRef(null),
              [B, k] = s.useState(!1),
              Z = s.useContext(eg.Y).addViewedGames,
              T = (0, ep.Z)(s.useContext(e_.t)),
              L = s.useCallback(() => {
                t && v.prefetchGameData(t, j);
              }, [v, t, j]);
            s.useEffect(() => {
              !B && a && (k(!0), (0, ed.requestIdleCallback)(L));
            }, [a, L, B]),
              s.useEffect(() => {
                let e;
                return (
                  w &&
                    w.current &&
                    ((e = w.current),
                    ey.Z.get().observe(w.current, () => {
                      ey.Z.get().unobserve(e), Z(t.id, T);
                    })),
                  () => {
                    e && ey.Z.get().unobserve(e);
                  }
                );
              }, [t.id, Z, T]);
            let S = t.covers && t.covers["1x1"],
              G = S ? t.covers["1x1"] : t.cover,
              R = t.gameAverageRating
                ? (0, eG.Z)(c, t.gameAverageRating, {
                    maximumFractionDigits: 1,
                  })
                : null;
            return (0, i.jsxs)("div", {
              className: eI().carouselSlide,
              id: n,
              ref: w,
              style: o,
              children: [
                (0, i.jsxs)("div", {
                  className: eI().slideRoundedContainer,
                  children: [
                    (0, i.jsx)(eu.Z, {
                      slug: t.slug,
                      children: (0, i.jsxs)("div", {
                        className: eI().content,
                        children: [
                          (y || r) &&
                            (0, i.jsxs)("div", {
                              className: eI().videoContainer,
                              children: [
                                a &&
                                  (0, i.jsx)(ec.Z, {
                                    style: { opacity: p },
                                    videoWidth: y,
                                    game: t,
                                    onCanPlayThrough: () => h(!0),
                                  }),
                                (0, i.jsx)("img", {
                                  src: (0, M.ZP)(t.cover, { width: y }),
                                  srcSet: (0, M.LI)(t.cover, { width: y }),
                                  alt: t.name,
                                }),
                              ],
                            }),
                          (l || r) &&
                            (0, i.jsxs)("div", {
                              className: eI().infoContainer,
                              children: [
                                null !== G &&
                                  (0, i.jsx)("img", {
                                    className: eI().small1x1Thumb,
                                    src: (0, M.ZP)(G, { width: S ? f : y }),
                                    srcSet: (0, M.LI)(G, { width: S ? f : y }),
                                    alt: t.name,
                                  }),
                                (0, i.jsxs)("div", {
                                  children: [
                                    (0, i.jsx)("div", {
                                      className: eI().gameTitle,
                                      children: t.name,
                                    }),
                                    (0, i.jsxs)("div", {
                                      className: eI().subtitleContainer,
                                      children: [
                                        R &&
                                          u &&
                                          (0, i.jsxs)("div", {
                                            children: [
                                              (0, i.jsx)(eM.Z, {}),
                                              `${R}/10`,
                                            ],
                                          }),
                                        (0, i.jsxs)("div", {
                                          children: [
                                            (0, i.jsx)(eL.Z, {
                                              icon: t.categoryName
                                                ?.toLowerCase()
                                                .replace(".", ""),
                                            }),
                                            " ",
                                            t.categoryName,
                                          ],
                                        }),
                                      ],
                                    }),
                                  ],
                                }),
                                (0, i.jsxs)(E.Z, {
                                  variant: "contained",
                                  color: "purple",
                                  height: 40,
                                  className: eI().playButton,
                                  children: [
                                    (0, i.jsx)(eS.Z, {
                                      className: eI().largeResolution,
                                    }),
                                    " ",
                                    (0, i.jsx)("span", {
                                      className: eI().largeResolution,
                                      children: (0, i.jsx)(d.cC, {
                                        id: "common.instant.play",
                                      }),
                                    }),
                                    (0, i.jsx)(eh, {
                                      style: { marginRight: 0 },
                                      className: eI().smallResolution,
                                    }),
                                  ],
                                }),
                              ],
                            }),
                        ],
                      }),
                    }),
                    (0, i.jsx)("div", { className: eI().thumbOverlay }),
                    a &&
                      (0, i.jsx)(ec.Z, {
                        style: { opacity: p },
                        videoWidth: y,
                        game: t,
                        onCanPlayThrough: () => _(!0),
                      }),
                    y &&
                      (0, i.jsx)("img", {
                        className: eI().gameBackImg,
                        src: (0, M.ZP)(t.cover, { width: y }),
                        srcSet: (0, M.LI)(t.cover, { width: y }),
                        alt: t.name,
                      }),
                  ],
                }),
                (0, i.jsx)(ex.Z, {
                  videoPlaying: !1,
                  gameThumbLabels: t.gameThumbLabels,
                  top: 4,
                }),
              ],
            });
          },
          eD = () =>
            (0, i.jsx)("div", {
              className: eI().carouselSlide,
              children: (0, i.jsxs)("div", {
                className: eI().slideRoundedContainer,
                children: [
                  (0, i.jsx)("div", { className: eI().content }),
                  (0, i.jsx)("div", {
                    className: (0, h.Z)(eI().thumbOverlay, eI().skeleton),
                  }),
                ],
              }),
            }),
          eN = (e) => {
            let { games: t, expectedSize: n, isCrawler: a } = e,
              [o, r] = s.useState(""),
              [l, c] = s.useState(!1),
              [u, d] = s.useState(void 0),
              m = s.useRef(null);
            s.useEffect(() => {
              let e = m.current,
                t = () => {
                  s.startTransition(() => {
                    c(!0);
                  });
                },
                n = () => {
                  s.startTransition(() => {
                    c(!1);
                  });
                },
                i = "onscrollend" in window;
              return (
                i &&
                  e &&
                  (e.addEventListener("scroll", t),
                  e.addEventListener("scrollend", n, { passive: !0 })),
                function () {
                  i &&
                    e &&
                    (e.removeEventListener("scrollend", n),
                    e.removeEventListener("scroll", t));
                }
              );
            }, []),
              s.useEffect(() => {
                let e = m.current
                  ? m.current.querySelectorAll("#topCarousel > div")
                  : null;
                e && d(e);
              }, [m, t]),
              s.useEffect(() => {
                let e = new IntersectionObserver(
                  (e) => {
                    let t = e.reduce((e, t) =>
                      t.intersectionRatio > e.intersectionRatio ? t : e
                    );
                    if (t.intersectionRatio > 0) {
                      let e = t.target.getAttribute("id");
                      e && r(e);
                    }
                  },
                  { root: m.current, threshold: 0.9 }
                );
                if (u)
                  for (let t = 0; t < u.length; t++) {
                    let n = u[t].getAttribute("id");
                    n && e.observe(u[t]);
                  }
                return function () {
                  e.disconnect();
                };
              }, [u]);
            let h = (e) => {
              let t = `slide_${e}`,
                n = () => {
                  let e = document.getElementById(t);
                  e && e.scrollIntoView({ behavior: "smooth", block: "end" });
                };
              return (0, i.jsx)(
                "svg",
                {
                  xmlns: "http://www.w3.org/2000/svg",
                  width: "7",
                  height: "7",
                  viewBox: "0 0 7 7",
                  fill: "none",
                  onClick: n,
                  children: (0, i.jsx)("circle", {
                    cx: "3.5",
                    cy: "3.5",
                    r: "3.5",
                    fill: o === t ? R.D.white[100] : R.D.white[10],
                  }),
                },
                e
              );
            };
            return 0 === t.length
              ? (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsx)("div", {
                      className: eI().carouselContainer,
                      ref: m,
                      id: "topCarousel",
                      children: (0, ev.o)(n).map((e) => (0, i.jsx)(eD, {}, e)),
                    }),
                    (0, i.jsx)("div", {
                      className: eI().dotsContainer,
                      children: (0, ev.o)(n).map((e) => h(e.toString())),
                    }),
                  ],
                })
              : (0, i.jsxs)(k.H, {
                  newClickOrigin: "instantTopCarousel",
                  children: [
                    (0, i.jsx)("div", {
                      className: eI().carouselContainer,
                      ref: m,
                      id: "topCarousel",
                      children: t.map((e) =>
                        (0, i.jsx)(
                          eP,
                          {
                            game: e,
                            id: `slide_${e.slug}`,
                            isIntersecting: o === `slide_${e.slug}` && !l,
                            isCrawler: a,
                          },
                          e.slug
                        )
                      ),
                    }),
                    (0, i.jsx)("div", {
                      className: eI().dotsContainer,
                      children: t.map((e) => h(e.slug)),
                    }),
                  ],
                });
          },
          eO = s.memo((e) => {
            let { games: t, isCrawler: n } = e;
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(eN, {
                  games: t.slice(0, 5),
                  expectedSize: 5,
                  isCrawler: n,
                }),
                (0, i.jsx)(eZ, { games: t.slice(5, 9), expectedSize: 4 }),
                (0, i.jsx)(ew, {
                  games: t.slice(9, 10).concat(t.slice(-1)),
                  expectedSize: 2,
                  isCrawler: n,
                }),
                (0, i.jsx)(eZ, { games: t.slice(10, 14), expectedSize: 4 }),
                (0, i.jsx)(ew, {
                  games: t.slice(14, 15).concat(t.slice(-2, -1)),
                  expectedSize: 2,
                  isCrawler: n,
                }),
                (0, i.jsx)(eZ, { games: t.slice(15, 19), expectedSize: 4 }),
                (0, i.jsx)(ew, {
                  games: t.slice(19, 20).concat(t.slice(-3, -2)),
                  expectedSize: 2,
                  isCrawler: n,
                }),
                (0, i.jsx)(eZ, { games: t.slice(20, 24), expectedSize: 4 }),
                (0, i.jsx)(ew, {
                  games: t.slice(24, 25).concat(t.slice(-4, -3)),
                  expectedSize: 2,
                  isCrawler: n,
                }),
              ],
            });
          }),
          eE = (e) => {
            let { games: t, loading: n, modelName: a, isCrawler: o } = e,
              l = s.useContext(x.Z),
              c = (0, C.yz)(l),
              u = (0, C.l7)(l),
              d = l.isDesktop,
              m = d ? r.VH : r.dE,
              { modelApi: h } = s.useContext(b.Z).services,
              [g, _] = s.useState([]),
              p = t.concat(g);
            s.useEffect(() => {
              _([]);
            }, [t]);
            let y = async (e, t) => {
                let n = { page: t, size: r.ln },
                  i = await h.getModelGames(e, c, u, {
                    place: "homePage_recommendedCarouselMore",
                    pagination: n,
                  });
                return i?.items;
              },
              f = async () => {
                let e = p.length < m;
                if (a && e) {
                  let e = Math.ceil(p.length / r.ln),
                    t = await y(a, d ? e + 2 : e + 1);
                  t && t.length > 0 && _(g.concat(t));
                }
              },
              v = n ? [] : p.slice(0, m);
            return d
              ? (0, i.jsx)(ea, {
                  games: v,
                  requestData: f,
                  requestDataThreshold: 2,
                  loading: n,
                  loadingLimit: 25,
                })
              : (0, i.jsx)(eO, { games: v, isCrawler: o });
          },
          eF = (e) => {
            let { prefetchedRecommendedGames: t, isCrawler: n = !1 } = e,
              {
                fetchedModelGames: s,
                loadingModelGames: a,
                modelName: o,
              } = v({}),
              r = n && t;
            return (0, i.jsx)(k.H, {
              newClickOrigin: "recommended",
              children: (0, i.jsx)(eE, {
                games: r ? t : s,
                modelName: o,
                loading: !r && a,
                isCrawler: n,
              }),
            });
          };
        var eA = n(98718),
          eH = n(65216),
          eV = n(74112);
        let eq = s.memo((e) => {
          let { games: t, sorting: n } = e,
            { routeHelper: a } = s.useContext(O.Z),
            o = (0, $.Z)(),
            { spacing: c } = (0, er.Z)(),
            u = (e, t) => {
              let i = t || n;
              switch (i) {
                case l.Fi:
                  return a.newPageLink(e);
                case l.sc:
                  return a.homePageLink(e);
                case l.K6:
                  return a.updatedPageLink(e);
                default:
                  return (
                    console.warn(`unexpected sorting ${i}`), a.homePageLink(e)
                  );
              }
            },
            h = (() => {
              if (!t) return null;
              let e = (0, K.Z)(t, { isIos: o });
              return e.items.concat(t.desktop?.items || []);
            })();
          return h && 0 !== h.length
            ? (0, i.jsxs)("div", {
                style: {
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                },
                children: [
                  (0, i.jsxs)("div", {
                    style: { width: "100%", padding: c(2), paddingTop: 0 },
                    children: [
                      (0, i.jsx)(H.Z, {
                        children:
                          h &&
                          (0, i.jsx)(eV.Z, {
                            games: h,
                            justifyContent: "center",
                            slidesToLoadEagerly: r.$V,
                            customStyles: {
                              paddingTop: c(2),
                              paddingBottom: 24,
                              width: "100%",
                            },
                            isResponsive: !0,
                            isResponsiveGrid: !0,
                            sx: z.Dx,
                            imgResponsiveSizes: z.L,
                          }),
                      }),
                      (0, i.jsx)(eA.Z, {
                        children:
                          h &&
                          (0, i.jsx)(eV.Z, {
                            games: h,
                            justifyContent: "center",
                            slidesToLoadEagerly: r.nY,
                            customStyles: { paddingTop: c(2) },
                            isResponsive: !0,
                            isResponsiveGrid: !0,
                            sx: z.Dx,
                            imgResponsiveSizes: z.L,
                          }),
                      }),
                    ],
                  }),
                  t &&
                    (0, i.jsx)(eH.Z, {
                      games: t.data,
                      urlGenerator: u,
                      pageLimit: n === l.Fi ? r.rF : void 0,
                    }),
                ],
              })
            : (0, i.jsx)("div", {
                style: {
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: c(2),
                  height: "100%",
                },
                children: (0, i.jsx)(z.qQ, {
                  children: (0, i.jsx)(d.cC, {
                    id: "games.empty.title",
                    values: {
                      homepageLink: (0, i.jsx)(m.Z, {
                        ...a.homePageLink(),
                        prefetch: !0,
                        children: (0, i.jsx)(d.cC, {
                          id: "games.empty.homepage",
                        }),
                      }),
                    },
                  }),
                }),
              });
        });
        var eW = n(20918),
          eK = n(46313),
          e$ = n(95129);
        let eX = (e) => {
            let { items: t, pageSize: n } = e,
              { carouselService: a, crazyAnalyticsService: o } = s.useContext(
                b.Z
              ).services,
              l = s.useContext(x.Z),
              { isIos: c } = s.useContext(e$.Z),
              u = (0, eW.j2)(),
              { i18n: m } = (0, d.mV)(),
              h = (0, C.yz)(l);
            return (0, i.jsx)(i.Fragment, {
              children: t.map((e, t) => {
                if ("weekly" === e.type) {
                  if (u) return null;
                  let n = l.isMobile ? r.z : r.C8;
                  return (0, i.jsx)(
                    k.H,
                    {
                      newClickOrigin: "weekly",
                      children: (0, i.jsx)(S, {
                        label: m._({ id: "games.weeklyFeatured.title" }),
                        games: e.data.items,
                        maxNoItems: Math.min(r.Sr, e.data.total),
                        pageSize: n,
                        fetchDataFn: (e) =>
                          a.weeklyRecommendedGames(h, { page: e, size: n }),
                        renderGameThumb: (t) =>
                          (0, i.jsx)(j.Z, {
                            game: t,
                            onClickAction: () => {
                              o.gameClickedFromList(e.data.items);
                            },
                            isResponsive: !0,
                            imgResponsiveSizes: z.D1,
                          }),
                        renderSkeleton: () =>
                          (0, i.jsx)(w.Z, { isResponsive: !0 }),
                      }),
                    },
                    `weekly-${t}`
                  );
                }
                if ("tag" === e.type) {
                  let { id: t, slug: s, tag: a } = e.data;
                  return (0, i.jsx)(
                    q,
                    { pageSize: n, tag: a, slug: s, categoryId: t },
                    s
                  );
                }
                if ("kids" === e.type) {
                  let t = eK.Z.Instance.data.kids,
                    n = e.data ? (0, K.Z)(e.data, { isIos: c }) : null,
                    s = m._("common.games.all", {
                      title: m._({ id: "games.kids.title" }),
                    }),
                    a = { as: t, href: t, target: "_blank" },
                    u = l.isMobile ? r.tS : l.isTablet ? r.$I : r.qi;
                  return (
                    n &&
                    (0, i.jsx)(
                      S,
                      {
                        label: m._({ id: "games.kids.title" }),
                        games: n,
                        pageSize: u,
                        maxNoItems: n.length,
                        linkData: a,
                        allGamesLabel: s,
                        allGamesLinkData: a,
                        renderGameThumb: (e) =>
                          (0, i.jsx)(j.Z, {
                            game: e,
                            onClickAction: () => {
                              o.gameClickedFromList(n);
                            },
                            isResponsive: !0,
                            imgResponsiveSizes: z.D1,
                          }),
                        renderSkeleton: () =>
                          (0, i.jsx)(w.Z, { isResponsive: !0 }),
                      },
                      "kids"
                    )
                  );
                }
              }),
            });
          },
          eY = (e) => {
            let { pageSize: t, size: n } = e;
            return (0, i.jsx)(i.Fragment, {
              children: (0, J.Z)(n).map((e) =>
                (0, i.jsx)(V, { pageSize: t }, `skeleton-${e}`)
              ),
            });
          };
        var eQ = n(98456),
          eU = n(5152),
          eJ = n.n(eU),
          e0 = n(80205);
        let e1 = eJ()(() => Promise.resolve().then(n.bind(n, 80205)), {
            loadableGenerated: { webpack: () => [80205] },
            loading: () => null,
            ssr: !1,
          }),
          e2 = () => {
            let { carouselService: e } = s.useContext(b.Z).services,
              t = s.useContext(x.Z),
              n = s.useRef(null),
              [a, o] = s.useState(!1),
              [r, l] = s.useState(!1),
              [c, u] = s.useState([]),
              d = (0, W.y)(t);
            return (
              s.useEffect(() => {
                let i, s;
                let r = [],
                  c = !1,
                  m = !1,
                  h = async () => {
                    try {
                      if (a || c) return;
                      c = !0;
                      let n = r[r.length - 1]?.carousels.pagination.page || 0,
                        i = (0, C.yz)(t),
                        l = await e.lazyCarousels(
                          d,
                          { page: n + 1, size: 6, offset: 0 },
                          i,
                          (0, eW.j2)()
                        );
                      if (
                        ((r = r.concat(l)),
                        u(r),
                        (c = !1),
                        l.carousels.total <=
                          l.carousels.pagination.page *
                            l.carousels.pagination.size)
                      ) {
                        o(!0);
                        return;
                      }
                      s = window.setTimeout(() => {
                        m && h();
                      }, 400);
                    } catch (e) {
                      console.error(e), o(!0);
                    }
                  },
                  g = (e) => {
                    let t = e.some((e) => e.isIntersecting);
                    t ? ((m = !0), h(), l(!0)) : ((m = !1), l(!1));
                  };
                return (
                  n.current &&
                    !a &&
                    (i = new window.IntersectionObserver(g, {
                      root: null,
                      threshold: 0.1,
                      rootMargin: t.isDesktop ? "500px 0px" : "300px 0px",
                    })).observe(n.current),
                  () => {
                    i && i.disconnect(), s && window.clearTimeout(s);
                  }
                );
              }, [n, t, e, d, a]),
              (0, i.jsxs)(i.Fragment, {
                children: [
                  c.map((e) =>
                    (0, i.jsx)(
                      eX,
                      { items: e.carousels.items, pageSize: d },
                      `carousel-${e.carousels.pagination.page}`
                    )
                  ),
                  (0, i.jsx)(
                    "div",
                    { style: { width: "100%" }, ref: n },
                    "observer"
                  ),
                  a
                    ? (0, i.jsx)("div", {
                        style: {
                          height: t.isMobile
                            ? e0.HOMEPAGE_FOOTER_HEIGHT_MOBILE
                            : e0.HOMEPAGE_FOOTER_HEIGHT_DESKTOP,
                        },
                        children: (0, i.jsx)(e1, {}),
                      })
                    : (0, i.jsxs)(
                        "div",
                        {
                          children: [
                            (0, i.jsx)(eY, { pageSize: d, size: 2 }),
                            (0, i.jsx)("div", {
                              style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                width: "100%",
                                height: 100,
                              },
                              children:
                                r &&
                                (0, i.jsx)(eQ.Z, {
                                  sx: { color: "white" },
                                  disableShrink: !0,
                                }),
                            }),
                          ],
                        },
                        `progress-${c.length + 1}`
                      ),
                ],
              })
            );
          };
        var e3 = n(74886),
          e5 = n(83514),
          e4 = n(44354),
          e7 = n(85254),
          e9 = n(35715);
        let e6 = (e) => {
            let { sx: t, icon: n, name: a, slug: o, isCategory: r } = e,
              { routeHelper: l } = s.useContext(O.Z),
              { pageService: c } = s.useContext(b.Z).services,
              u = s.useContext(x.Z),
              d = s.useContext(e_.t),
              h = (0, ep.Z)(d),
              [g, _] = s.useState(!1),
              p = s.useCallback(() => {
                let e = (0, C.yz)(u),
                  t = u.isMobile,
                  n = t ? e9.Zj : e9.U,
                  i = e9.wl,
                  s = u.isTablet ? e9.JV : e9.mZ;
                c.prefetchTagPage(
                  r ? "category" : "tag",
                  o,
                  { page: 1, size: n },
                  i,
                  s,
                  e,
                  e9.mk,
                  e9.U,
                  "default"
                );
              }, [u, c, o, r]);
            s.useEffect(() => {
              let e;
              return (
                g &&
                  (e = window.setTimeout(() => {
                    p();
                  }, 150)),
                function () {
                  e && window.clearTimeout(e);
                }
              );
            }, [g, p]);
            let y = r
                ? l.categoryPageDirectLink(o, {}, { origin: h }).href
                : l.tagPageDirectLink(o, {}, { origin: h }).href,
              f = r
                ? l.categoryPageDirectLink(o).as
                : l.tagPageDirectLink(o).as;
            return (0, i.jsx)(m.Z, {
              href: y,
              as: f,
              "aria-label": a,
              onMouseEnter: () => {
                _(!0);
              },
              onMouseLeave: () => {
                _(!1);
              },
              prefetch: !0,
              children: (0, i.jsxs)(e4.$x, {
                sx: t,
                children: [
                  (0, i.jsx)(eL.Z, { icon: n }),
                  (0, i.jsx)(e4.VS, { children: a }),
                ],
              }),
            });
          },
          e8 = () => {
            let { sidebarTags: e } = s.useContext(e7.Z),
              t = [];
            for (let n = 0; n < e.length; n += 2) {
              let s = e[n],
                a = e[n + 1];
              void 0 !== s &&
                t.push(
                  (0, i.jsxs)(
                    "div",
                    {
                      children: [
                        (0, i.jsx)(e6, {
                          name: s.name,
                          slug: s.slug,
                          icon: s.enSlug,
                          isCategory: s.isCategory,
                          sx: { mb: 1.5 },
                        }),
                        a
                          ? (0, i.jsx)(e6, {
                              name: a.name,
                              slug: a.slug,
                              icon: a.enSlug,
                              isCategory: a.isCategory,
                            })
                          : (0, i.jsx)(e4.$x, {
                              sx: {
                                "&:hover": { backgroundColor: R.D.black[80] },
                              },
                            }),
                      ],
                    },
                    `seoset${n}`
                  )
                );
            }
            return (0, i.jsx)(e4.lp, {
              children: (0, i.jsx)(k.H, {
                newClickOrigin: "seo",
                children: (0, i.jsx)(en.Z, { children: t }),
              }),
            });
          };
        var te = n(4404),
          tt = n.n(te);
        let tn = eJ()(
            () => Promise.all([n.e(86507), n.e(35181)]).then(n.bind(n, 35181)),
            {
              loadableGenerated: { webpack: () => [35181] },
              loading: () => null,
              ssr: !0,
            }
          ),
          ti = (e) => {
            let { text: t } = e,
              [n, a] = s.useState(!1);
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsxs)(e4.fC, {
                  children: [
                    (0, i.jsxs)(e4.JO, {
                      children: [
                        (0, i.jsx)(e4.Ah, {
                          dangerouslySetInnerHTML: { __html: t },
                          sx: { overflow: "hidden" },
                        }),
                        (0, i.jsx)(E.Z, {
                          variant: "link",
                          color: "purple",
                          className: tt().seoBlockLearnMoreButton,
                          onClick: () => a(!0),
                          children: (0, i.jsx)(d.cC, {
                            id: "games.seo.learnmore",
                          }),
                        }),
                      ],
                    }),
                    (0, i.jsx)(e8, {}),
                  ],
                }),
                (0, i.jsx)(tn, { open: n, onClose: () => a(!1), text: t }),
              ],
            });
          };
        var ts = n(23180),
          ta = n(81030);
        let to = eJ()(() => n.e(67069).then(n.bind(n, 67069)), {
            loadableGenerated: { webpack: () => [67069] },
            loading: () => null,
            ssr: !1,
          }),
          tr = (e) => {
            let {
                games: t,
                prefetchedRecommendedGames: a,
                weeklyRecommendedGames: o,
                sorting: l,
                featuredGames: c,
                newGames: d,
                processedNewGames: m,
                page: g,
                homepageCat: p,
                homepageText: y,
                desktopOnlyCarouselGames: f,
                originalGamesPaginated: v,
                isCrawler: B,
                pageHeading: T,
              } = e,
              { carouselService: L, crazyAnalyticsService: M } = s.useContext(
                b.Z
              ).services,
              { pageUrlHelper: G } = s.useContext(e5.t),
              { openDrawer: R } = s.useContext(ts.s9),
              I = s.useContext(x.Z),
              { routeHelper: P } = s.useContext(O.Z),
              D = eJ()(() => n.e(67954).then(n.bind(n, 67954)), {
                loadableGenerated: { webpack: () => [67954] },
                loading: () =>
                  (0, i.jsx)("div", {
                    style: { height: I.isDesktop ? 84 : 74, width: "100%" },
                  }),
                ssr: !1,
              }),
              N = (0, $.Z)(),
              E = G.isHomePage(),
              F = G.isOnContact(),
              A = c && (0, K.Z)(c, { isIos: N }),
              H = d && (0, K.Z)(d, { isIos: N }),
              V = v && (0, K.Z)(v, { isIos: N }),
              q = m && (0, K.Z)(m, { isIos: N }),
              X = o && (0, K.Z)(o, { isIos: N });
            return (
              s.useEffect(() => {
                F && R("mainFeedback");
              }, [F, R]),
              (0, i.jsxs)(U, {
                isDesktop: I.isDesktop,
                children: [
                  T && (0, i.jsx)(e3.Z, { title: T }),
                  1 === g &&
                    E &&
                    (() => {
                      let e = (0, C.yz)(I),
                        t = I.isMobile ? r.fr : r.ZO,
                        n = I.isMobile ? r.Vp : r.v_,
                        o =
                          (q &&
                            H &&
                            q.items.concat(
                              H.items
                                .filter(
                                  (e) => !q.items.some((t) => t.slug === e.slug)
                                )
                                .slice(0, 3)
                            )) ??
                          [],
                        l = u.ag._("common.games.all", {
                          title: u.ag._({ id: "games.new.title" }),
                        }),
                        c = P.newPageLink(),
                        d = I.isDesktop ? 6 : 2,
                        m = (0, i.jsxs)(i.Fragment, {
                          children: [
                            A && (0, i.jsx)(Z, { games: A }),
                            q &&
                              (0, i.jsx)(k.H, {
                                newClickOrigin: "new",
                                children: (0, i.jsx)(S, {
                                  label: u.ag._({ id: "games.new.title" }),
                                  games: o,
                                  dataSize: q.items.length,
                                  maxNoItems: Math.min(r.I4, q.total),
                                  pageSize: t,
                                  linkData: c,
                                  fetchDataFn: (n) =>
                                    L.newGames(e, { page: n, size: t }),
                                  allGamesLabel: l,
                                  allGamesLinkData: c,
                                  renderGameThumb: (e, t) =>
                                    (0, i.jsx)(j.Z, {
                                      game: e,
                                      eagerLoading: t < d,
                                      onClickAction: () => {
                                        M.gameClickedFromList(o);
                                      },
                                      isResponsive: !0,
                                      imgResponsiveSizes: z.D1,
                                    }),
                                  renderSkeleton: () =>
                                    (0, i.jsx)(w.Z, { isResponsive: !0 }),
                                }),
                              }),
                            V &&
                              V.items.length > 0 &&
                              (0, i.jsx)(k.H, {
                                newClickOrigin: "originals",
                                children: (0, i.jsx)("div", {
                                  className: (0, h.Z)(
                                    _().portraitCarouselContainer
                                  ),
                                  children: (0, i.jsx)(S, {
                                    label: "CrazyGames Originals",
                                    games: V.items,
                                    maxGames: V.total,
                                    maxNoItems: r.zG,
                                    pageSize: n,
                                    linkData: P.originalsPageLink(),
                                    fetchDataFn: (t) =>
                                      L.originalGames(e, { page: t, size: n }),
                                    renderGameThumb: (e) =>
                                      (0, i.jsx)(ta.Z, {
                                        game: e,
                                        aspectRatio: "portrait",
                                        isResponsive: !0,
                                        showLabels: !1,
                                      }),
                                    renderSkeleton: () =>
                                      (0, i.jsx)(w.Z, { isResponsive: !0 }),
                                  }),
                                }),
                              }),
                          ],
                        });
                      return (0, i.jsxs)(i.Fragment, {
                        children: [
                          (0, i.jsx)(D, {}),
                          (0, i.jsx)(eF, {
                            prefetchedRecommendedGames: a,
                            isCrawler: B,
                          }),
                          I.isDesktop
                            ? m
                            : (0, i.jsx)(s.Suspense, { children: m }),
                          (0, i.jsxs)(s.Suspense, {
                            children: [
                              p &&
                                (0, i.jsx)(Q, {
                                  categoryGames: p,
                                  isCrawler: B,
                                  weeklyRecommendedGames: X,
                                }),
                              f &&
                                (0, i.jsx)(S, {
                                  label: u.ag._({
                                    id: "carousels.desktopOnly.title",
                                  }),
                                  games: f,
                                  pageSize: (0, W.y)(I),
                                  renderGameThumb: (e) =>
                                    (0, i.jsx)(j.Z, {
                                      game: e,
                                      onClickAction: () => {
                                        M.gameClickedFromList(f);
                                      },
                                      isResponsive: !0,
                                      imgResponsiveSizes: z.D1,
                                    }),
                                  renderSkeleton: () =>
                                    (0, i.jsx)(w.Z, { isResponsive: !0 }),
                                }),
                            ],
                          }),
                        ],
                      });
                    })(),
                  1 === g &&
                    "default" === l &&
                    y &&
                    (0, i.jsx)(s.Suspense, {
                      children: (0, i.jsx)(ti, { text: y }),
                    }),
                  E
                    ? (0, i.jsxs)(s.Suspense, {
                        children: [
                          (0, i.jsx)(e2, {}),
                          I.isDesktop && (0, i.jsx)(to, { height: 900 }),
                        ],
                      })
                    : (0, i.jsx)(eq, { games: t, sorting: l, page: g }),
                ],
              })
            );
          };
        var tl = n(60081),
          tc = n(39471),
          tu = n(61338),
          td = n(9305),
          tm = n(26830);
        class th extends s.Component {
          static async getInitialProps(e) {
            let {
                pageService: t,
                routeDataService: n,
                crawlerService: i,
              } = (0, c.b)(e),
              { deviceType: s } = (0, C.mO)(e),
              a = (0, C.yz)(s),
              o = s.isMobile,
              u = (e.query && e.query[l.Y7]) || l.sc,
              d = Number((e.query && e.query[l.Fh]) || 1),
              m = o ? r.v1 : r.gG,
              h = Number((e.query && e.query[l.AB]) || m),
              g = { page: d, size: h },
              _ =
                (e.query && "true" === e.query.forceChristmas) || (0, eW.j2)(),
              p = (e.query && e.query[l.Hs]) || void 0,
              y = 1 === d && u === l.sc && !p,
              x = (0, tm.et)(u, p, n, d, y);
            if ((u === l.sc && 1 !== d) || (u === l.Fi && d > r.rF))
              throw new td.Z(404, "Incorrect pagination");
            let b = "true" === e.query[l.cv],
              f = async () => {
                if (y) {
                  let e = await t.gamesPage(s, _);
                  return b && (await i.replaceHomePageForCrawler(e, s)), e;
                }
                return t.gamesPageGamesOnly(u, g, a, p);
              },
              [v, z] = await Promise.all([f(), x]);
            if (
              !y &&
              1 !== g.page &&
              0 === v.games.data.items.length &&
              0 === (v.games.desktop?.items.length || 0)
            )
              throw new td.Z(404, "No games found");
            return (
              u === l.Fi &&
                e.res &&
                e.res.setHeader(
                  "Cache-Control",
                  "public, max-age=120, s-maxage=120, stale-if-error=1800, must-revalidate"
                ),
              {
                ...v,
                label: p,
                sorting: u,
                page: d,
                alternatives: z,
                isCrawler: b,
              }
            );
          }
          render() {
            let {
                i18n: e,
                games: t,
                sorting: n,
                page: s,
                featuredGames: o,
                weeklyRecommendedGames: r,
                desktopOnlyCarouselGames: l,
                newGames: c,
                processedNewGames: u,
                homepageCat: d,
                alternatives: m,
                homepageText: h,
                originalGamesPaginated: g,
                prefetchedRecommendedGames: _,
                isCrawler: p,
              } = this.props,
              y = this.getTitle(),
              x = this.getGamePageHeading(),
              C = e._({ id: "common.head.metaDescription" }),
              b = this.getCanonical(),
              f = this.getClickOrigin();
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(a.Z, {
                  title: y,
                  metaDescription: C,
                  canonical: b,
                  alternatives: m,
                }),
                (0, i.jsx)(tl.Z, { canonical: b, title: y, description: C }),
                (0, i.jsx)(k.H, {
                  newClickOrigin: f,
                  children: (0, i.jsx)(tr, {
                    games: t,
                    prefetchedRecommendedGames: _,
                    weeklyRecommendedGames: r,
                    sorting: n,
                    page: s,
                    featuredGames: o,
                    newGames: c,
                    processedNewGames: u,
                    homepageCat: d,
                    homepageText: h,
                    desktopOnlyCarouselGames: l,
                    originalGamesPaginated: g,
                    pageHeading: x,
                    isCrawler: p,
                  }),
                }),
              ],
            });
          }
          getTitle() {
            let { sorting: e, i18n: t, page: n, label: i } = this.props;
            if (i && i === l.VT)
              return `${t._({ id: "games.hot.title" })} - CrazyGames`;
            switch (e) {
              case l.Fi:
                return `${t._({ id: "games.new.title" })} - CrazyGames`;
              case l.sc:
                return t._("common.head.title", { pageNumber: n });
              case l.K6:
                return `${t._({ id: "games.updated.title" })} - CrazyGames`;
              default:
                return (
                  console.warn(`unexpected sorting ${e}`),
                  t._("common.head.title", { pageNumber: n })
                );
            }
          }
          getGamePageHeading() {
            let { sorting: e, i18n: t, label: n } = this.props;
            return n === l.VT
              ? t._({ id: "games.hot.title" })
              : e === l.Fi
              ? t._({ id: "games.new.title" })
              : e === l.K6
              ? t._({ id: "games.updated.title" })
              : void 0;
          }
          getCanonical() {
            let { routeHelper: e, sorting: t, page: n, label: i } = this.props;
            if (i === l.VT) return e.hotPageCanonical(n);
            switch (t) {
              case l.Fi:
                return e.newPageCanonical(n);
              case l.sc:
                return e.homePageCanonical(n);
              case l.K6:
                return e.updatedPageCanonical(n);
              default:
                return (
                  console.warn(`unexpected sorting ${t}`),
                  e.homePageCanonical(n)
                );
            }
          }
          getClickOrigin() {
            let { sorting: e, label: t } = this.props;
            if (t && t === l.VT) return "trending";
            switch (e) {
              case l.Fi:
                return "new";
              case l.K6:
                return "updated";
            }
          }
        }
        var tg = (0, tc.Z)((0, o.Z)("games", "carousels")((0, tu.Z)(th)));
      },
      68107: function (e) {
        e.exports = {
          czyButton: "Carousel_czyButton__6jaIA",
          "czyButton--contained--purple":
            "Carousel_czyButton--contained--purple__WK2R2",
          "czyButton--contained--white":
            "Carousel_czyButton--contained--white__P2wH7",
          "czyButton--contained--grey":
            "Carousel_czyButton--contained--grey__YX75p",
          "czyButton--contained--alert":
            "Carousel_czyButton--contained--alert__y5vYl",
          "czyButton--contained--success":
            "Carousel_czyButton--contained--success___RDL3",
          "czyButton--contained--black":
            "Carousel_czyButton--contained--black__jvS4H",
          "czyButton--contained--green-gradient":
            "Carousel_czyButton--contained--green-gradient__6_NI6",
          "czyButton--outlined--purple":
            "Carousel_czyButton--outlined--purple__gZM5f",
          "czyButton--link--purple": "Carousel_czyButton--link--purple__lfCcr",
          "czyButton--outlined--white":
            "Carousel_czyButton--outlined--white__ZD4sA",
          "czyButton--link--white": "Carousel_czyButton--link--white___iTH_",
          "czyButton--outlined--grey":
            "Carousel_czyButton--outlined--grey__AfU_9",
          "czyButton--link--grey": "Carousel_czyButton--link--grey__aQxSw",
          "czyButton--outlined--alert":
            "Carousel_czyButton--outlined--alert__xgXM4",
          "czyButton--link--alert": "Carousel_czyButton--link--alert__lQ7gu",
          "czyButton--outlined--success":
            "Carousel_czyButton--outlined--success__zev_8",
          "czyButton--link--success":
            "Carousel_czyButton--link--success__kDCdl",
          "czyButton--outlined": "Carousel_czyButton--outlined__ltgIl",
          "czyButton--disabled": "Carousel_czyButton--disabled__PAzHl",
          "czyButton--height50": "Carousel_czyButton--height50__sj4J8",
          "czyButton--height34": "Carousel_czyButton--height34__R2EvP",
          "czyButton--fullWidth": "Carousel_czyButton--fullWidth__NRSlz",
          simpleCarouselContainer: "Carousel_simpleCarouselContainer__jOmRF",
          primeCarouselLi: "Carousel_primeCarouselLi__Zk7jA",
          skeletonCarouselContainer:
            "Carousel_skeletonCarouselContainer__B4wqq",
          portraitCarouselContainer:
            "Carousel_portraitCarouselContainer__oKz2v",
          recommendedMobileContainer:
            "Carousel_recommendedMobileContainer__T9TBl",
          recommendedDesktopContainer:
            "Carousel_recommendedDesktopContainer__psbyp",
          mobileRecommendedSlideContainer:
            "Carousel_mobileRecommendedSlideContainer__NOcL8",
          carouselTitleContainerDiv:
            "Carousel_carouselTitleContainerDiv__Ci82c",
          carouselTitle: "Carousel_carouselTitle__kXgiB",
          carouselTitleLink: "Carousel_carouselTitleLink__Ldlwt",
        };
      },
      4100: function (e) {
        e.exports = {
          czyButton: "GameCarousel_czyButton__4XfK_",
          "czyButton--contained--purple":
            "GameCarousel_czyButton--contained--purple__nPZwF",
          "czyButton--contained--white":
            "GameCarousel_czyButton--contained--white__t5nYz",
          "czyButton--contained--grey":
            "GameCarousel_czyButton--contained--grey__D87Gr",
          "czyButton--contained--alert":
            "GameCarousel_czyButton--contained--alert__MNlYf",
          "czyButton--contained--success":
            "GameCarousel_czyButton--contained--success__TY93Q",
          "czyButton--contained--black":
            "GameCarousel_czyButton--contained--black__Br3LI",
          "czyButton--contained--green-gradient":
            "GameCarousel_czyButton--contained--green-gradient__lHrXH",
          "czyButton--outlined--purple":
            "GameCarousel_czyButton--outlined--purple__k67c7",
          "czyButton--link--purple":
            "GameCarousel_czyButton--link--purple__5xcCl",
          "czyButton--outlined--white":
            "GameCarousel_czyButton--outlined--white__C2biF",
          "czyButton--link--white":
            "GameCarousel_czyButton--link--white__t3GNx",
          "czyButton--outlined--grey":
            "GameCarousel_czyButton--outlined--grey__CqowT",
          "czyButton--link--grey": "GameCarousel_czyButton--link--grey__bdPmq",
          "czyButton--outlined--alert":
            "GameCarousel_czyButton--outlined--alert__l_XvH",
          "czyButton--link--alert":
            "GameCarousel_czyButton--link--alert__5aGbR",
          "czyButton--outlined--success":
            "GameCarousel_czyButton--outlined--success__MtY0_",
          "czyButton--link--success":
            "GameCarousel_czyButton--link--success__gNdnK",
          "czyButton--outlined": "GameCarousel_czyButton--outlined__M296S",
          "czyButton--disabled": "GameCarousel_czyButton--disabled__RUqbc",
          "czyButton--height50": "GameCarousel_czyButton--height50__RwfVp",
          "czyButton--height34": "GameCarousel_czyButton--height34__pUL2o",
          "czyButton--fullWidth": "GameCarousel_czyButton--fullWidth__qZmtB",
          root: "GameCarousel_root__aGOTN",
          primeCarouselArrow: "GameCarousel_primeCarouselArrow__BmHOa",
          doubleArrow: "GameCarousel_doubleArrow__BGrRW",
          primeCarouselArrowLeft: "GameCarousel_primeCarouselArrowLeft__Xeqxo",
          primeCarouselArrowRight:
            "GameCarousel_primeCarouselArrowRight__N14W3",
          primeCarouselContainer: "GameCarousel_primeCarouselContainer__6qK_o",
        };
      },
      86266: function (e) {
        e.exports = {
          czyButton: "MobileInstant_czyButton__bV_HW",
          "czyButton--contained--purple":
            "MobileInstant_czyButton--contained--purple__S2pcy",
          "czyButton--contained--white":
            "MobileInstant_czyButton--contained--white__gF2_Q",
          "czyButton--contained--grey":
            "MobileInstant_czyButton--contained--grey__CgLrJ",
          "czyButton--contained--alert":
            "MobileInstant_czyButton--contained--alert__x64D9",
          "czyButton--contained--success":
            "MobileInstant_czyButton--contained--success__CYFcK",
          "czyButton--contained--black":
            "MobileInstant_czyButton--contained--black__KZx5S",
          "czyButton--contained--green-gradient":
            "MobileInstant_czyButton--contained--green-gradient__SsjUv",
          "czyButton--outlined--purple":
            "MobileInstant_czyButton--outlined--purple__jnxKt",
          "czyButton--link--purple":
            "MobileInstant_czyButton--link--purple___VSll",
          "czyButton--outlined--white":
            "MobileInstant_czyButton--outlined--white__FDmsO",
          "czyButton--link--white":
            "MobileInstant_czyButton--link--white__S4Vn1",
          "czyButton--outlined--grey":
            "MobileInstant_czyButton--outlined--grey__V6QP3",
          "czyButton--link--grey": "MobileInstant_czyButton--link--grey__qfT45",
          "czyButton--outlined--alert":
            "MobileInstant_czyButton--outlined--alert__Fym1c",
          "czyButton--link--alert":
            "MobileInstant_czyButton--link--alert__dpCOL",
          "czyButton--outlined--success":
            "MobileInstant_czyButton--outlined--success__VHQdz",
          "czyButton--link--success":
            "MobileInstant_czyButton--link--success__7MyLi",
          "czyButton--outlined": "MobileInstant_czyButton--outlined__X3pXx",
          "czyButton--disabled": "MobileInstant_czyButton--disabled__irlO5",
          "czyButton--height50": "MobileInstant_czyButton--height50__lXfGD",
          "czyButton--height34": "MobileInstant_czyButton--height34__4d486",
          "czyButton--fullWidth": "MobileInstant_czyButton--fullWidth__Tq23F",
          carouselContainer: "MobileInstant_carouselContainer__6hNKM",
          dotsContainer: "MobileInstant_dotsContainer__PGCp_",
          carouselSlide: "MobileInstant_carouselSlide__lSo4_",
          slideRoundedContainer: "MobileInstant_slideRoundedContainer__xeGlN",
          content: "MobileInstant_content__9j5BI",
          videoContainer: "MobileInstant_videoContainer__dl_aq",
          infoContainer: "MobileInstant_infoContainer__hEKTE",
          playButton: "MobileInstant_playButton__VL2Xn",
          largeResolution: "MobileInstant_largeResolution__5Z0h9",
          smallResolution: "MobileInstant_smallResolution__7da5r",
          gameTitle: "MobileInstant_gameTitle__kEtel",
          subtitleContainer: "MobileInstant_subtitleContainer__Nb1Al",
          thumbOverlay: "MobileInstant_thumbOverlay__9XxJe",
          skeleton: "MobileInstant_skeleton__DVFVg",
          gameBackImg: "MobileInstant_gameBackImg__pb9b3",
          small1x1Thumb: "MobileInstant_small1x1Thumb__iuoOg",
        };
      },
      90949: function (e) {
        e.exports = {
          czyButton: "InstantThumb_czyButton__47VY5",
          "czyButton--contained--purple":
            "InstantThumb_czyButton--contained--purple__brpwQ",
          "czyButton--contained--white":
            "InstantThumb_czyButton--contained--white__w4Ovu",
          "czyButton--contained--grey":
            "InstantThumb_czyButton--contained--grey__8Bay7",
          "czyButton--contained--alert":
            "InstantThumb_czyButton--contained--alert__3b60V",
          "czyButton--contained--success":
            "InstantThumb_czyButton--contained--success__RfqOq",
          "czyButton--contained--black":
            "InstantThumb_czyButton--contained--black__S9Vm7",
          "czyButton--contained--green-gradient":
            "InstantThumb_czyButton--contained--green-gradient__uut3j",
          "czyButton--outlined--purple":
            "InstantThumb_czyButton--outlined--purple__u99pm",
          "czyButton--link--purple":
            "InstantThumb_czyButton--link--purple__y5CnN",
          "czyButton--outlined--white":
            "InstantThumb_czyButton--outlined--white__5Cw5U",
          "czyButton--link--white":
            "InstantThumb_czyButton--link--white__ifBkQ",
          "czyButton--outlined--grey":
            "InstantThumb_czyButton--outlined--grey__W98Hp",
          "czyButton--link--grey": "InstantThumb_czyButton--link--grey__xWFuq",
          "czyButton--outlined--alert":
            "InstantThumb_czyButton--outlined--alert__WpXmW",
          "czyButton--link--alert":
            "InstantThumb_czyButton--link--alert__411LG",
          "czyButton--outlined--success":
            "InstantThumb_czyButton--outlined--success__ZgxI7",
          "czyButton--link--success":
            "InstantThumb_czyButton--link--success__fVm_m",
          "czyButton--outlined": "InstantThumb_czyButton--outlined__Ie_sw",
          "czyButton--disabled": "InstantThumb_czyButton--disabled__XwMrQ",
          "czyButton--height50": "InstantThumb_czyButton--height50__Noou7",
          "czyButton--height34": "InstantThumb_czyButton--height34__3Q__0",
          "czyButton--fullWidth": "InstantThumb_czyButton--fullWidth__ss94a",
          instantThumb: "InstantThumb_instantThumb__yimdR",
          isLarge: "InstantThumb_isLarge__5XdDF",
          frontArea: "InstantThumb_frontArea__Nixk6",
          smallThumbPlaceholder: "InstantThumb_smallThumbPlaceholder__irmSO",
          largeThumbPlaceholder: "InstantThumb_largeThumbPlaceholder__WRSlD",
          gameNameContainer: "InstantThumb_gameNameContainer__9R5tW",
          isSmall: "InstantThumb_isSmall___KnrA",
          bottomContainer: "InstantThumb_bottomContainer__Nt0DM",
          thumbOverlay: "InstantThumb_thumbOverlay__d9rna",
          thumbBlur: "InstantThumb_thumbBlur__26KA0",
          gameBack: "InstantThumb_gameBack__kYLZ7",
        };
      },
      9177: function (e) {
        e.exports = {
          czyButton: "OriginalsGameThumb_czyButton__HGiSF",
          "czyButton--contained--purple":
            "OriginalsGameThumb_czyButton--contained--purple__1mgrA",
          "czyButton--contained--white":
            "OriginalsGameThumb_czyButton--contained--white__UP_u_",
          "czyButton--contained--grey":
            "OriginalsGameThumb_czyButton--contained--grey__miDzN",
          "czyButton--contained--alert":
            "OriginalsGameThumb_czyButton--contained--alert__k0pG6",
          "czyButton--contained--success":
            "OriginalsGameThumb_czyButton--contained--success__fss6R",
          "czyButton--contained--black":
            "OriginalsGameThumb_czyButton--contained--black__oD9f_",
          "czyButton--contained--green-gradient":
            "OriginalsGameThumb_czyButton--contained--green-gradient__Tl9n1",
          "czyButton--outlined--purple":
            "OriginalsGameThumb_czyButton--outlined--purple__AIxwE",
          "czyButton--link--purple":
            "OriginalsGameThumb_czyButton--link--purple__g9WZ7",
          "czyButton--outlined--white":
            "OriginalsGameThumb_czyButton--outlined--white__bmTT3",
          "czyButton--link--white":
            "OriginalsGameThumb_czyButton--link--white__UNI7F",
          "czyButton--outlined--grey":
            "OriginalsGameThumb_czyButton--outlined--grey__2SGuq",
          "czyButton--link--grey":
            "OriginalsGameThumb_czyButton--link--grey__4Sqcg",
          "czyButton--outlined--alert":
            "OriginalsGameThumb_czyButton--outlined--alert__Ve35Q",
          "czyButton--link--alert":
            "OriginalsGameThumb_czyButton--link--alert__ztLX8",
          "czyButton--outlined--success":
            "OriginalsGameThumb_czyButton--outlined--success__yuAO6",
          "czyButton--link--success":
            "OriginalsGameThumb_czyButton--link--success__GAZWE",
          "czyButton--outlined":
            "OriginalsGameThumb_czyButton--outlined__5QWIW",
          "czyButton--disabled":
            "OriginalsGameThumb_czyButton--disabled__VbFHK",
          "czyButton--height50":
            "OriginalsGameThumb_czyButton--height50__fW_Kd",
          "czyButton--height34":
            "OriginalsGameThumb_czyButton--height34__DXBqJ",
          "czyButton--fullWidth":
            "OriginalsGameThumb_czyButton--fullWidth__SAkRc",
          originalsGameLink: "OriginalsGameThumb_originalsGameLink___Ihy2",
          portrait: "OriginalsGameThumb_portrait__DNcP_",
          isMobile: "OriginalsGameThumb_isMobile__9N1b9",
          square: "OriginalsGameThumb_square__YrmOM",
          landscape: "OriginalsGameThumb_landscape__SE7Z_",
          isResponsive: "OriginalsGameThumb_isResponsive__tZBH5",
          hoveredContainer: "OriginalsGameThumb_hoveredContainer__dI_YW",
          withPortraitVideo: "OriginalsGameThumb_withPortraitVideo__U5Mqm",
          buttonContainer: "OriginalsGameThumb_buttonContainer__IEqqt",
          gameName: "OriginalsGameThumb_gameName__vZql2",
          gameCategory: "OriginalsGameThumb_gameCategory__19Wud",
        };
      },
      4404: function (e) {
        e.exports = {
          footerCallToActionButton: "GamesPage_footerCallToActionButton__31_w5",
          isDesktop: "GamesPage_isDesktop__7eh9X",
          seoBlockLearnMoreButton: "GamesPage_seoBlockLearnMoreButton__o4Fmi",
        };
      },
      15417: function (e) {
        e.exports = {
          czyButton: "Pagination_czyButton__CrJcu",
          "czyButton--contained--purple":
            "Pagination_czyButton--contained--purple__Tne5E",
          "czyButton--contained--white":
            "Pagination_czyButton--contained--white__W2aRh",
          "czyButton--contained--grey":
            "Pagination_czyButton--contained--grey__z87sS",
          "czyButton--contained--alert":
            "Pagination_czyButton--contained--alert__K0pje",
          "czyButton--contained--success":
            "Pagination_czyButton--contained--success__m9r7e",
          "czyButton--contained--black":
            "Pagination_czyButton--contained--black__HI8It",
          "czyButton--contained--green-gradient":
            "Pagination_czyButton--contained--green-gradient__h21nH",
          "czyButton--outlined--purple":
            "Pagination_czyButton--outlined--purple__ljowN",
          "czyButton--link--purple":
            "Pagination_czyButton--link--purple__whmjf",
          "czyButton--outlined--white":
            "Pagination_czyButton--outlined--white__nJjag",
          "czyButton--link--white": "Pagination_czyButton--link--white__fQHHx",
          "czyButton--outlined--grey":
            "Pagination_czyButton--outlined--grey__4eSQW",
          "czyButton--link--grey": "Pagination_czyButton--link--grey__uijpD",
          "czyButton--outlined--alert":
            "Pagination_czyButton--outlined--alert__sXx1Y",
          "czyButton--link--alert": "Pagination_czyButton--link--alert__23Kzv",
          "czyButton--outlined--success":
            "Pagination_czyButton--outlined--success__CDFRh",
          "czyButton--link--success":
            "Pagination_czyButton--link--success__BQJxc",
          "czyButton--outlined": "Pagination_czyButton--outlined__65OUS",
          "czyButton--disabled": "Pagination_czyButton--disabled__nbeEj",
          "czyButton--height50": "Pagination_czyButton--height50__UTPIe",
          "czyButton--height34": "Pagination_czyButton--height34__1OgCY",
          "czyButton--fullWidth": "Pagination_czyButton--fullWidth__qVwgH",
          paginationContainer: "Pagination_paginationContainer__ZdF_m",
          ellipsis: "Pagination_ellipsis__1Xzoo",
          gamePageLink: "Pagination_gamePageLink__52hMn",
          number: "Pagination_number__Nh3VT",
          current: "Pagination_current__TuEd_",
          disabled: "Pagination_disabled__R07W7",
        };
      },
    },
    function (e) {
      e.O(
        0,
        [54163, 76287, 61338, 45169, 29875, 86634, 49774, 92888, 40179],
        function () {
          return e((e.s = 5337));
        }
      ),
        (_N_E = e.O());
    },
  ]);
