!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "0843293e-7a45-40ed-8393-094369bf829e"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-0843293e-7a45-40ed-8393-094369bf829e"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [46271],
    {
      43796: function (e, t, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/multiplayer",
          function () {
            return n(97886);
          },
        ]);
      },
      57200: function (e, t, n) {
        "use strict";
        var i = n(85893),
          a = n(94745),
          l = n(67294),
          r = n(38711),
          o = n.n(r),
          s = n(90512);
        let u = (e) => {
          let { description: t, className: n } = e,
            r = l.useRef(null),
            [u, c] = l.useState(!1),
            [d, _] = l.useState(!1);
          return (
            l.useEffect(() => {
              let e = () => {
                if (!t) return;
                _(!1);
                let e = r.current;
                c(!!(e && e?.scrollHeight > e?.clientHeight));
              };
              return (
                e(),
                t && window.addEventListener("resize", e),
                function () {
                  t && window.removeEventListener("resize", e);
                }
              );
            }, [t]),
            (0, i.jsxs)("div", {
              className: (0, s.Z)(o().shortDescriptionContainer, n),
              children: [
                (0, i.jsx)("div", {
                  className: (0, s.Z)(
                    o().shortDescription,
                    d && o().expanded,
                    u && o().needsShowMoreInSubtitle
                  ),
                  ref: r,
                  dangerouslySetInnerHTML: { __html: t },
                }),
                u &&
                  !d &&
                  (0, i.jsx)("div", {
                    className: (0, s.Z)(o().showMoreLessContainer),
                    onClick: () => _(!0),
                    children: (0, i.jsx)(a.cC, { id: "common.showMore" }),
                  }),
                u &&
                  d &&
                  (0, i.jsx)("div", {
                    className: (0, s.Z)(
                      o().showMoreLessContainer,
                      o().expanded
                    ),
                    onClick: () => _(!1),
                    children: (0, i.jsx)(a.cC, { id: "common.showLess" }),
                  }),
              ],
            })
          );
        };
        t.Z = u;
      },
      18288: function (e, t, n) {
        "use strict";
        var i = n(85893),
          a = n(9008),
          l = n.n(a);
        n(67294);
        var r = n(46313),
          o = n(75007),
          s = n(33209);
        let u = "favicons/manifest-icon-3.png",
          c = "favicons/favicon-transparent.png",
          d = (e) => {
            let {
                title: t,
                metaDescription: n,
                canonical: a,
                alternatives: d = [],
                children: _,
              } = e,
              y = d.find((e) => {
                let { locale: t } = e;
                return t === s.ZW;
              }),
              p = (e, t, n) =>
                (0, o.ZP)(e, { width: t, height: n, fit: "crop" }),
              m = "development" === r.Z.Instance.environment;
            return (0, i.jsxs)(l(), {
              children: [
                (0, i.jsx)("title", {
                  children: `${m ? "\uD83E\uDD99 - " : ""}${t}`,
                }),
                (0, i.jsx)("link", { rel: "manifest", href: "/manifest" }),
                (0, i.jsx)("meta", { httpEquiv: "Accept-CH", content: "DPR" }),
                (0, i.jsx)("meta", { name: "description", content: n }),
                a && (0, i.jsx)("link", { rel: "canonical", href: a }),
                d.map((e) => {
                  let { href: t, locale: n } = e,
                    a = (0, s.xi)(n);
                  return (0, i.jsx)(
                    "link",
                    { rel: "alternate", hrefLang: a, href: t },
                    a
                  );
                }),
                y &&
                  (0, i.jsx)("link", {
                    rel: "alternate",
                    href: y.href,
                    hrefLang: "x-default",
                  }),
                (0, i.jsx)("meta", { name: "theme-color", content: "#ffffff" }),
                (0, i.jsx)("meta", {
                  name: "HandheldFriendly",
                  content: "true",
                }),
                (0, i.jsx)("meta", {
                  name: "mobile-web-app-capable",
                  content: "yes",
                }),
                (0, i.jsx)("meta", {
                  name: "apple-mobile-web-app-capable",
                  content: "yes",
                }),
                (0, i.jsx)("meta", {
                  name: "apple-mobile-web-app-status-bar-style",
                  content: "default",
                }),
                (0, i.jsx)("link", {
                  rel: "apple-touch-icon",
                  href: p(u, 120, 120),
                }),
                (0, i.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "152x152",
                  href: p(u, 152, 152),
                }),
                (0, i.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "167x167",
                  href: p(u, 167, 167),
                }),
                (0, i.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "180x180",
                  href: p(u, 180, 180),
                }),
                (0, i.jsx)("link", {
                  rel: "mask-icon",
                  href: (0, o.ZP)("favicons/safari-pinned-tab.svg", {}, !1),
                  color: "#6842ff",
                }),
                (0, i.jsx)("link", {
                  rel: "icon",
                  href: p(c, 16, 16),
                  sizes: "16x16",
                }),
                (0, i.jsx)("link", {
                  rel: "icon",
                  href: p(c, 32, 32),
                  sizes: "32x32",
                }),
                (0, i.jsx)("link", {
                  rel: "icon",
                  href: p(c, 48, 48),
                  sizes: "48x48",
                }),
                (0, i.jsx)("link", {
                  rel: "icon",
                  href: p(c, 196, 196),
                  sizes: "196x196",
                }),
                (0, i.jsx)("meta", {
                  name: "msapplication-TileColor",
                  content: "#603cba",
                }),
                (0, i.jsx)("meta", {
                  name: "msapplication-TileImage",
                  content: p(c, 144, 144),
                }),
                _,
              ],
            });
          };
        t.Z = d;
      },
      2490: function (e, t, n) {
        "use strict";
        var i = n(37899),
          a = n(1982),
          l = n(72552),
          r = n(67294);
        let o = () => {
          let { crazyAnalyticsService: e } = (0, r.useContext)(i.Z).services,
            t = (0, r.useContext)(a.t),
            n = (0, l.Z)(t),
            o = (0, r.useCallback)(
              (t) => {
                e.sendModalEvent("with_friends_learn_more", t, "learn_more", n);
              },
              [e, n]
            );
          return o;
        };
        t.Z = o;
      },
      44715: function (e, t, n) {
        "use strict";
        var i = n(85893),
          a = n(67294),
          l = n(83808);
        t.Z = function () {
          for (var e = arguments.length, t = Array(e), n = 0; n < e; n++)
            t[n] = arguments[n];
          return (e) =>
            class extends a.Component {
              static async getInitialProps(n) {
                let { trlService: i } = (0, l.b)(n);
                if (!n.req) {
                  let a = Promise.all(
                      t.map((e) => i.loadTrlMessagesToLingui(e))
                    ),
                    [l] = await Promise.all([
                      e.getInitialProps ? await e.getInitialProps(n) : {},
                      a,
                    ]);
                  return { ...l };
                }
                let a = Promise.all(t.map((e) => i.getTrlMessages(e))),
                  [r, o] = await Promise.all([
                    e.getInitialProps
                      ? e.getInitialProps(n)
                      : Promise.resolve({}),
                    a,
                  ]),
                  s = o.reduce((e, t) => Object.assign(e, t));
                return { messages: s, ...r };
              }
              render() {
                let { ...t } = this.props;
                return (0, i.jsx)(e, { ...t });
              }
            };
        };
      },
      97886: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            DEFAULT_TAB_SLUG: function () {
              return eu;
            },
            default: function () {
              return ed;
            },
          });
        var i = n(85893),
          a = n(67294),
          l = n(44715),
          r = n(61338),
          o = n(90512),
          s = n(42466),
          u = n.n(s),
          c = n(94745),
          d = n(19073),
          _ = n(30954),
          y = n(63306),
          p = n(13592),
          m = n(11163),
          g = n(88642),
          h = n(8697),
          z = n(33209);
        let B = (e) => {
          let { tag: t } = e,
            [n, l] = a.useState(g.sc),
            { routeHelper: r } = a.useContext(y.Z),
            { locale: o } = a.useContext(h.Z),
            { crazyRouterChange: s } = a.useContext(p.R),
            u = (0, m.useRouter)();
          a.useEffect(() => {
            let e = new URLSearchParams(u.asPath.slice(u.asPath.indexOf("?"))),
              t = e.get(g.Y7);
            t ? l(t) : l(g.sc);
          }, [u]);
          let B = (0, a.useCallback)(
            (e, n) => {
              l(n);
              let i = r.multiplayerPageLink(t.slug[(0, z.Ld)(o)], 1, n);
              s(i.href, i.as);
            },
            [r, s, t, o]
          );
          return (0, i.jsx)(d.ZP, {
            value: n,
            onChange: B,
            height: 40,
            width: 150,
            children: [
              { val: "default", trKey: "common.links.top" },
              { val: "new", trKey: "common.links.new" },
            ].map((e, t) => {
              let { val: a, trKey: l } = e;
              return (0, i.jsx)(
                _.Z,
                {
                  value: a,
                  disabled: n === a,
                  children: (0, i.jsx)(c.cC, { id: l }),
                },
                t
              );
            }),
          });
        };
        var x = n(2978),
          f = n(57200),
          M = n(89555);
        let w = {
            "7a08b313-2b2f-4042-9135-821d47ad8668":
              "multiplayer.onlineWithFriends",
            "cd11ac53-ba46-4364-9c85-84344a81527e": "multiplayer.online",
            "1d7cf360-3b2f-4442-820a-055cf967a0ad": "multiplayer.local",
          },
          b = a.memo((e) => {
            let { tags: t, activeTag: n } = e,
              { routeHelper: l } = a.useContext(y.Z);
            return (0, i.jsx)("div", {
              className: u().subTags,
              children: t.map((e, t) => {
                let a = e.slug === eu ? void 0 : e.slug,
                  r = l.multiplayerPageLink(a),
                  s = w[e.id] ? M.ag._(w[e.id]) : e.title;
                return (0, i.jsx)(
                  x.Z,
                  {
                    href: r.href,
                    as: r.as,
                    className: (0, o.Z)(
                      u().subTag,
                      n?.id === e.id && u().activeSubTag
                    ),
                    shallow: n?.id === e.id,
                    children: s,
                  },
                  t
                );
              }),
            });
          }),
          j = a.memo((e) => {
            let { tags: t, activeTag: n, gameCount: a } = e;
            return (0, i.jsx)("div", {
              className: u().root,
              children: (0, i.jsxs)("div", {
                className: u().titleWrapper,
                children: [
                  (0, i.jsx)("h1", {
                    children: (0, i.jsx)(c.cC, { id: "multiplayer.title" }),
                  }),
                  (0, i.jsx)(f.Z, {
                    className: u().shortDescriptionContainer,
                    description: n.shortDescription || "",
                  }),
                  (0, i.jsx)(b, { tags: t, activeTag: n }),
                  (0, i.jsxs)("div", {
                    className: u().sortingWrapper,
                    children: [
                      (0, i.jsx)(B, { tag: n }),
                      (0, i.jsx)("div", {
                        className: u().gameCount,
                        children: (0, i.jsx)(c.cC, {
                          id: "common.games.ngames",
                          values: { count: a },
                        }),
                      }),
                    ],
                  }),
                ],
              }),
            });
          });
        var k = n(88296),
          v = n(75007),
          P = n(23180),
          T = n(56460),
          C = n.n(T),
          G = n(2490);
        let Z = (0, a.memo)(() => {
          let e = (0, v.ZP)("withfriendssmileys.svg", {}, !1),
            { openDrawer: t } = a.useContext(P.s9),
            n = (0, G.Z)(),
            l = (0, a.useCallback)(() => {
              n("open"), t("playWithFriends");
            }, [t, n]),
            r = (0, c.mV)();
          return (0, i.jsxs)("div", {
            className: (0, o.Z)(C().item, C().withFriendsPill),
            onClick: l,
            children: [
              (0, i.jsx)("div", {
                className: C().upperRow,
                children: (0, i.jsxs)("div", {
                  className: C().withFriendsPillText,
                  children: [
                    (0, i.jsx)(c.cC, { id: "multiplayer.playWithYourFriends" }),
                    (0, i.jsx)(k.Z, {
                      onClick: l,
                      variant: "contained",
                      height: 34,
                      color: "white",
                      className: C().withFriendsPillButton,
                      children: (0, i.jsx)(c.cC, { id: "common.learnhow" }),
                    }),
                  ],
                }),
              }),
              (0, i.jsx)("div", {
                className: C().bottomRow,
                children: (0, i.jsx)("img", {
                  className: C().friendsSvg,
                  src: e,
                  alt: r._("multiplayer.playWithYourFriends"),
                }),
              }),
            ],
          });
        });
        var H = function () {
            let e = (0, m.useRouter)();
            return e.query.page ? parseInt(e.query.page, 10) : 1;
          },
          N = n(94984),
          S = n(9512);
        let D = a.memo((e) => {
            let { name: t, categoryName: n, maxLobbySize: a } = e,
              l = (0, c.mV)(),
              r = a
                ? a > 100
                  ? l._("multiplayer.players", { playersStr: "100+" })
                  : l._("multiplayer.upTo", { playersStr: a.toString() })
                : "";
            return (0, i.jsxs)("div", {
              className: C().title,
              children: [
                (0, i.jsx)("div", { className: C().name, children: t }),
                n &&
                  (0, i.jsxs)("div", {
                    className: C().category,
                    children: [r, !!r && " • ", n],
                  }),
              ],
            });
          }),
          F = (0, a.memo)((e) => {
            let {
                games: t,
                showWithFriendsPill: n,
                enableInstantJoin: a,
                activeTag: l,
              } = e,
              r = H();
            return (0, i.jsxs)("div", {
              className: C().root,
              children: [
                n && 1 === r && (0, i.jsx)(Z, {}),
                t.map((e) =>
                  (0, i.jsx)(
                    N.H,
                    {
                      newClickOrigin: `multiplayer_grid_${l.slug.en_US}`,
                      children: (0, i.jsx)(S.Z, {
                        hideTitle: !0,
                        className: C().item,
                        thumbClassName: C().thumb,
                        game: e,
                        isResponsive: !0,
                        enableInstantJoin: a,
                        children: (0, i.jsx)(D, {
                          name: e.name,
                          categoryName: e.categoryName,
                          minLobbySize: e.multiplayerOptions?.minLobbySize,
                          maxLobbySize: e.multiplayerOptions?.maxLobbySize,
                        }),
                      }),
                    },
                    e.id
                  )
                ),
              ],
            });
          });
        var L = n(65216),
          W = n(48715),
          E = n(42257);
        let q = (0, a.memo)((e) => {
          let { gamesData: t, activeTag: n } = e,
            l = a.useContext(E.Z),
            { routeHelper: r } = a.useContext(y.Z),
            { locale: o } = a.useContext(h.Z),
            s = (0, a.useCallback)(
              (e, t) => {
                let i = r.multiplayerPageLink(n.slug[(0, z.Ld)(o)], e, t);
                return i;
              },
              [r, n.slug, o]
            ),
            u = (0, W.K)(t, l.isDesktop);
          return (0, i.jsx)(L.Z, { games: u, urlGenerator: s });
        });
        var I = n(43753),
          O = n.n(I),
          A = n(62716),
          R = n(40657),
          K = n(21519),
          Y = n(95129),
          J = n(4743),
          U = n(3040),
          V = n(82921);
        let X = (0, a.memo)((e) => {
          let {
              games: t,
              activeTag: n,
              tags: l,
              page: r,
              topGames: o,
              topMobileGames: s,
              linkBoostedGames: u,
              tag: d,
            } = e,
            _ = t.data,
            { total: y, items: p } = _,
            m = a.useContext(Y.Z),
            { isDesktop: g } = a.useContext(E.Z),
            h = n.id === l[0].id,
            z = a.useCallback(() => {
              let { description: e, showFaq: t, intro: n, title: a } = d;
              return e
                ? (0, i.jsxs)(i.Fragment, {
                    children: [
                      (0, i.jsx)(R.A, {
                        dangerouslySetInnerHTML: { __html: e },
                      }),
                      !t &&
                        n &&
                        (0, i.jsxs)(i.Fragment, {
                          children: [
                            (0, i.jsx)("h3", {
                              children: (0, i.jsx)(c.cC, {
                                id: "tag.faq.whatAre",
                                values: { title: a },
                              }),
                            }),
                            (0, i.jsx)(R.A, {
                              dangerouslySetInnerHTML: { __html: n },
                            }),
                          ],
                        }),
                      (0, i.jsx)(K.Z, { sx: { my: 1, mx: 0 } }),
                    ],
                  })
                : null;
            }, [d]),
            B = a.useCallback(() => {
              if (!d.showFaq) return null;
              let e = o && (0, J.Z)(o, m);
              if (!e || !s) return null;
              let t = s.slice(0, 5),
                n = e.slice(0, 10),
                a = u || [];
              return (0, i.jsxs)(i.Fragment, {
                children: [
                  (0, i.jsx)(U.Z, {
                    tag: d,
                    mobileGames: t,
                    topGames: n,
                    linkBoostedGames: a,
                  }),
                  (0, i.jsx)(V.Z, {
                    tag: d,
                    mobileGames: t,
                    topGames: n,
                    linkBoostedGames: a,
                  }),
                  (0, i.jsx)(K.Z, { sx: { my: 1, mx: 0 } }),
                ],
              });
            }, [d, m, o, s, u]),
            x = {
              game: (t.data.items[0] || { name: "" }).name,
              title: n.title,
            },
            f = d.metaDescription
              ? d.metaDescription
              : M.ag._("tag.head.metaDescription", x),
            w = f || d.description || d.showFaq || d.shortDescription,
            b = (function () {
              if (g) return p;
              let e = (0, J.Z)(t, m),
                n = (t.desktop?.items || []).filter(
                  (t) => !e.items.some((e) => e.slug === t.slug)
                );
              return e.items.concat(n);
            })();
          return (0, i.jsxs)("div", {
            className: O().root,
            children: [
              (0, i.jsx)(j, { tags: l, activeTag: n, gameCount: y }),
              (0, i.jsx)(F, {
                showWithFriendsPill: h,
                games: b,
                enableInstantJoin: h,
                activeTag: n,
              }),
              (0, i.jsx)(q, { gamesData: _, activeTag: n }),
              1 === r &&
                w &&
                (0, i.jsx)(a.Suspense, {
                  children: (0, i.jsx)(A.Z, {
                    children: (0, i.jsxs)(i.Fragment, {
                      children: [z(), B(), f],
                    }),
                  }),
                }),
            ],
          });
        });
        var Q = n(18288),
          $ = n(60081);
        let ee = (e) =>
            0 !== e.data.items.length
              ? e.data.items[0].cover
              : e.desktop && 0 !== e.desktop.items.length
              ? e.desktop.items[0].cover
              : null,
          et = (e, t) => {
            let { routeHelper: n } = (0, a.useContext)(y.Z);
            return n.tagOrCategoryPageCanonical(e.slug, e.isCategory, t);
          },
          en = (e) => {
            let t = et(e.activeTag, e.page),
              { games: n, activeTag: a, page: l } = e,
              r = {
                game: (n.data.items[0] || { name: "" }).name,
                title: a.title,
              },
              o = M.ag._("multiplayer.head.metaDescription", r),
              s = M.ag._("multiplayer.head.title", {
                title: a.title,
                pageNumber: l,
              }),
              u = ee(n);
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(Q.Z, { canonical: t, title: s, metaDescription: o }),
                u &&
                  (0, i.jsx)($.Z, {
                    canonical: t,
                    title: s,
                    description: o,
                    imageUrl: u,
                  }),
              ],
            });
          },
          ei = (e) =>
            (0, i.jsxs)(i.Fragment, {
              children: [(0, i.jsx)(en, { ...e }), (0, i.jsx)(X, { ...e })],
            });
        var ea = n(83808),
          el = n(13301),
          er = n(93988),
          eo = n(35715),
          es = n(9305);
        let eu = "with-friends",
          ec = (e) =>
            (0, i.jsx)(ei, {
              ...e,
              activeTag: e.tag,
              tags: e.multiplayerPageData.tags,
            });
        ec.getInitialProps = async (e) => {
          let { pageService: t, crawlerService: n } = (0, ea.b)(e),
            { deviceType: i } = (0, el.mO)(e),
            a = i.isMobile,
            l = (0, el.yz)(i),
            r = (e.query && e.query[g.Aq]) || eu,
            o = (e.query && e.query[g.Y7]) || "default",
            s = Number((e.query && e.query[g.Fh]) || er.wK) || 1,
            u = a ? eo.Zj : 1 === s && "with-friends" === r ? eo.Gn - 1 : eo.Gn,
            c = Number((e.query && e.query[g.AB]) || u),
            d = i.isTablet ? eo.JV : eo.mZ,
            _ = i.isDesktop ? eo.wl : d,
            y = await t.tagPage(
              "tag",
              r,
              { page: s, size: c },
              _,
              d,
              l,
              eo.mk,
              c,
              o
            ),
            p = "true" === e.query[g.cv],
            {
              tag: m,
              games: h,
              topGames: z,
              topMobileGames: B,
              linkBoostedGames: x,
            } = y,
            f =
              p && o === g.sc
                ? await n.getSwappedTagCategoryGamesForCrawler(y, i, s)
                : h,
            M = (await t.multiplayerTags()).tags,
            w = M.find((e) => e.slug === r) || M[0],
            b = Math.ceil(f.data.total / c);
          if (!m.isArchived && s > b)
            throw new es.Z(404, "Incorrect pagination");
          if (
            !m.isArchived &&
            0 === f.data.items.length &&
            0 === (f.desktop?.items.length || 0)
          )
            throw new es.Z(404, "No games found");
          return {
            games: f,
            tag: m,
            topGames: z,
            topMobileGames: B,
            page: s,
            linkBoostedGames: x,
            multiplayerPageData: { activeTag: w, tags: M },
          };
        };
        var ed = (0, l.Z)("multiplayer")((0, r.Z)(ec));
      },
      38711: function (e) {
        e.exports = {
          czyButton: "PageTitle_czyButton__swk3e",
          "czyButton--contained--purple":
            "PageTitle_czyButton--contained--purple__PBW0y",
          "czyButton--contained--white":
            "PageTitle_czyButton--contained--white__Yl_CC",
          "czyButton--contained--grey":
            "PageTitle_czyButton--contained--grey__iMrqd",
          "czyButton--contained--alert":
            "PageTitle_czyButton--contained--alert__a8p_s",
          "czyButton--contained--success":
            "PageTitle_czyButton--contained--success__VPU1c",
          "czyButton--contained--black":
            "PageTitle_czyButton--contained--black__vxe7C",
          "czyButton--contained--green-gradient":
            "PageTitle_czyButton--contained--green-gradient__rBciz",
          "czyButton--outlined--purple":
            "PageTitle_czyButton--outlined--purple__gh1Oq",
          "czyButton--link--purple": "PageTitle_czyButton--link--purple__f68t0",
          "czyButton--outlined--white":
            "PageTitle_czyButton--outlined--white__kkN49",
          "czyButton--link--white": "PageTitle_czyButton--link--white__K8io3",
          "czyButton--outlined--grey":
            "PageTitle_czyButton--outlined--grey__bbBmd",
          "czyButton--link--grey": "PageTitle_czyButton--link--grey__kAMf4",
          "czyButton--outlined--alert":
            "PageTitle_czyButton--outlined--alert__E9Mm_",
          "czyButton--link--alert": "PageTitle_czyButton--link--alert__RfFeN",
          "czyButton--outlined--success":
            "PageTitle_czyButton--outlined--success__WtBwW",
          "czyButton--link--success":
            "PageTitle_czyButton--link--success__mNPzT",
          "czyButton--outlined": "PageTitle_czyButton--outlined__o6yYn",
          "czyButton--disabled": "PageTitle_czyButton--disabled__3WkBW",
          "czyButton--height50": "PageTitle_czyButton--height50__0yjpi",
          "czyButton--height34": "PageTitle_czyButton--height34__rouPD",
          "czyButton--fullWidth": "PageTitle_czyButton--fullWidth__FQip1",
          shortDescriptionContainer:
            "PageTitle_shortDescriptionContainer__92SiZ",
          shortDescription: "PageTitle_shortDescription__FqfoL",
          expanded: "PageTitle_expanded__6YbJs",
          needsShowMoreInSubtitle: "PageTitle_needsShowMoreInSubtitle__HsxTl",
          showMoreLessContainer: "PageTitle_showMoreLessContainer__K1ec7",
        };
      },
      43753: function (e) {
        e.exports = { root: "Multiplayer_root__aBi3Y" };
      },
      56460: function (e) {
        e.exports = {
          czyButton: "MultiplayerGrid_czyButton__dRhEd",
          "czyButton--contained--purple":
            "MultiplayerGrid_czyButton--contained--purple__Fjfao",
          "czyButton--contained--white":
            "MultiplayerGrid_czyButton--contained--white__vXE6h",
          "czyButton--contained--grey":
            "MultiplayerGrid_czyButton--contained--grey__XoaCW",
          "czyButton--contained--alert":
            "MultiplayerGrid_czyButton--contained--alert__xZ_O1",
          "czyButton--contained--success":
            "MultiplayerGrid_czyButton--contained--success__vz8Ws",
          "czyButton--contained--black":
            "MultiplayerGrid_czyButton--contained--black__WKFK9",
          "czyButton--contained--green-gradient":
            "MultiplayerGrid_czyButton--contained--green-gradient__9cn_4",
          "czyButton--outlined--purple":
            "MultiplayerGrid_czyButton--outlined--purple__YWesB",
          "czyButton--link--purple":
            "MultiplayerGrid_czyButton--link--purple__Eh6GJ",
          "czyButton--outlined--white":
            "MultiplayerGrid_czyButton--outlined--white__yLGQm",
          "czyButton--link--white":
            "MultiplayerGrid_czyButton--link--white__wOy4E",
          "czyButton--outlined--grey":
            "MultiplayerGrid_czyButton--outlined--grey__30vzw",
          "czyButton--link--grey":
            "MultiplayerGrid_czyButton--link--grey__7roIm",
          "czyButton--outlined--alert":
            "MultiplayerGrid_czyButton--outlined--alert__v4_BV",
          "czyButton--link--alert":
            "MultiplayerGrid_czyButton--link--alert__ISa_Y",
          "czyButton--outlined--success":
            "MultiplayerGrid_czyButton--outlined--success__XksFo",
          "czyButton--link--success":
            "MultiplayerGrid_czyButton--link--success__h2wlz",
          "czyButton--outlined": "MultiplayerGrid_czyButton--outlined__u0qHl",
          "czyButton--disabled": "MultiplayerGrid_czyButton--disabled__NPpE3",
          "czyButton--height50": "MultiplayerGrid_czyButton--height50__DaVM6",
          "czyButton--height34": "MultiplayerGrid_czyButton--height34__7jKUk",
          "czyButton--fullWidth": "MultiplayerGrid_czyButton--fullWidth__FxqOS",
          root: "MultiplayerGrid_root__CiDqZ",
          item: "MultiplayerGrid_item__cLhyS",
          title: "MultiplayerGrid_title___4qka",
          name: "MultiplayerGrid_name__i4iaZ",
          category: "MultiplayerGrid_category__JzWGO",
          thumb: "MultiplayerGrid_thumb__j_xCi",
          withFriendsPill: "MultiplayerGrid_withFriendsPill__pHsy0",
          upperRow: "MultiplayerGrid_upperRow__2I2zr",
          withFriendsPillButton: "MultiplayerGrid_withFriendsPillButton__a_ciL",
          withFriendsPillText: "MultiplayerGrid_withFriendsPillText__BhxyL",
          bottomRow: "MultiplayerGrid_bottomRow__9GLOW",
          friendsSvg: "MultiplayerGrid_friendsSvg__mBDzE",
          leftSide: "MultiplayerGrid_leftSide__2lJrB",
        };
      },
      42466: function (e) {
        e.exports = {
          czyButton: "MultiplayerHeader_czyButton__hof6H",
          "czyButton--contained--purple":
            "MultiplayerHeader_czyButton--contained--purple__etr_J",
          "czyButton--contained--white":
            "MultiplayerHeader_czyButton--contained--white__PZ6Zi",
          "czyButton--contained--grey":
            "MultiplayerHeader_czyButton--contained--grey__WKCqE",
          "czyButton--contained--alert":
            "MultiplayerHeader_czyButton--contained--alert__Eiis6",
          "czyButton--contained--success":
            "MultiplayerHeader_czyButton--contained--success__MEalE",
          "czyButton--contained--black":
            "MultiplayerHeader_czyButton--contained--black__q9ueA",
          "czyButton--contained--green-gradient":
            "MultiplayerHeader_czyButton--contained--green-gradient__xGU_D",
          "czyButton--outlined--purple":
            "MultiplayerHeader_czyButton--outlined--purple__Y3Avx",
          "czyButton--link--purple":
            "MultiplayerHeader_czyButton--link--purple__bfWZQ",
          "czyButton--outlined--white":
            "MultiplayerHeader_czyButton--outlined--white__B6TNs",
          "czyButton--link--white":
            "MultiplayerHeader_czyButton--link--white__pJHLv",
          "czyButton--outlined--grey":
            "MultiplayerHeader_czyButton--outlined--grey__eTJ17",
          "czyButton--link--grey":
            "MultiplayerHeader_czyButton--link--grey__6cPYH",
          "czyButton--outlined--alert":
            "MultiplayerHeader_czyButton--outlined--alert__4vGGO",
          "czyButton--link--alert":
            "MultiplayerHeader_czyButton--link--alert__Y0JFK",
          "czyButton--outlined--success":
            "MultiplayerHeader_czyButton--outlined--success__T3nOx",
          "czyButton--link--success":
            "MultiplayerHeader_czyButton--link--success__7jvqd",
          "czyButton--outlined": "MultiplayerHeader_czyButton--outlined__dpjjt",
          "czyButton--disabled": "MultiplayerHeader_czyButton--disabled__Q4uG9",
          "czyButton--height50": "MultiplayerHeader_czyButton--height50__kr26C",
          "czyButton--height34": "MultiplayerHeader_czyButton--height34__UmWry",
          "czyButton--fullWidth":
            "MultiplayerHeader_czyButton--fullWidth__OB79S",
          root: "MultiplayerHeader_root__8AXrb",
          shortDescriptionContainer:
            "MultiplayerHeader_shortDescriptionContainer__5K4on",
          sortingWrapper: "MultiplayerHeader_sortingWrapper__RruN5",
          titleWrapper: "MultiplayerHeader_titleWrapper__E3JtI",
          subTags: "MultiplayerHeader_subTags__vl7Ub",
          subTag: "MultiplayerHeader_subTag__Q1Xj2",
          activeSubTag: "MultiplayerHeader_activeSubTag__qwVKH",
          gameCount: "MultiplayerHeader_gameCount___cEAH",
        };
      },
    },
    function (e) {
      e.O(0, [76287, 61338, 45169, 68419, 49774, 92888, 40179], function () {
        return e((e.s = 43796));
      }),
        (_N_E = e.O());
    },
  ]);
