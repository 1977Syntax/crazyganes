!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "a2184c73-19e0-4a23-bfa2-18e1d9374afa"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-a2184c73-19e0-4a23-bfa2-18e1d9374afa"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [61494],
    {
      88078: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return k;
          },
        });
        var a = n(63366),
          i = n(87462),
          r = n(67294),
          o = n(90512),
          s = n(70917),
          l = n(94780),
          u = n(41796),
          c = n(90948),
          d = n(71657),
          g = n(1588),
          m = n(34867);
        function h(e) {
          return (0, m.ZP)("MuiSkeleton", e);
        }
        (0, g.Z)("MuiSkeleton", [
          "root",
          "text",
          "rectangular",
          "rounded",
          "circular",
          "pulse",
          "wave",
          "withChildren",
          "fitContent",
          "heightAuto",
        ]);
        var p = n(85893);
        let f = [
            "animation",
            "className",
            "component",
            "height",
            "style",
            "variant",
            "width",
          ],
          y = (e) => e,
          _,
          b,
          v,
          x,
          w = (e) => {
            let {
              classes: t,
              variant: n,
              animation: a,
              hasChildren: i,
              width: r,
              height: o,
            } = e;
            return (0, l.Z)(
              {
                root: [
                  "root",
                  n,
                  a,
                  i && "withChildren",
                  i && !r && "fitContent",
                  i && !o && "heightAuto",
                ],
              },
              h,
              t
            );
          },
          G = (0, s.F4)(
            _ ||
              (_ = y`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)
          ),
          z = (0, s.F4)(
            b ||
              (b = y`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)
          ),
          T = (0, c.ZP)("span", {
            name: "MuiSkeleton",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.root,
                t[n.variant],
                !1 !== n.animation && t[n.animation],
                n.hasChildren && t.withChildren,
                n.hasChildren && !n.width && t.fitContent,
                n.hasChildren && !n.height && t.heightAuto,
              ];
            },
          })(
            ({ theme: e, ownerState: t }) => {
              let n =
                  String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1] ||
                  "px",
                a = parseFloat(e.shape.borderRadius);
              return (0, i.Z)(
                {
                  display: "block",
                  backgroundColor: e.vars
                    ? e.vars.palette.Skeleton.bg
                    : (0, u.Fq)(
                        e.palette.text.primary,
                        "light" === e.palette.mode ? 0.11 : 0.13
                      ),
                  height: "1.2em",
                },
                "text" === t.variant && {
                  marginTop: 0,
                  marginBottom: 0,
                  height: "auto",
                  transformOrigin: "0 55%",
                  transform: "scale(1, 0.60)",
                  borderRadius: `${a}${n}/${
                    Math.round((a / 0.6) * 10) / 10
                  }${n}`,
                  "&:empty:before": { content: '"\\00a0"' },
                },
                "circular" === t.variant && { borderRadius: "50%" },
                "rounded" === t.variant && {
                  borderRadius: (e.vars || e).shape.borderRadius,
                },
                t.hasChildren && { "& > *": { visibility: "hidden" } },
                t.hasChildren && !t.width && { maxWidth: "fit-content" },
                t.hasChildren && !t.height && { height: "auto" }
              );
            },
            ({ ownerState: e }) =>
              "pulse" === e.animation &&
              (0, s.iv)(
                v ||
                  (v = y`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),
                G
              ),
            ({ ownerState: e, theme: t }) =>
              "wave" === e.animation &&
              (0, s.iv)(
                x ||
                  (x = y`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),
                z,
                (t.vars || t).palette.action.hover
              )
          ),
          Z = r.forwardRef(function (e, t) {
            let n = (0, d.Z)({ props: e, name: "MuiSkeleton" }),
              {
                animation: r = "pulse",
                className: s,
                component: l = "span",
                height: u,
                style: c,
                variant: g = "text",
                width: m,
              } = n,
              h = (0, a.Z)(n, f),
              y = (0, i.Z)({}, n, {
                animation: r,
                component: l,
                variant: g,
                hasChildren: Boolean(h.children),
              }),
              _ = w(y);
            return (0,
            p.jsx)(T, (0, i.Z)({ as: l, ref: t, className: (0, o.Z)(_.root, s), ownerState: y }, h, { style: (0, i.Z)({ width: m, height: u }, c) }));
          });
        var k = Z;
      },
      99407: function (e, t, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/originals",
          function () {
            return n(1016);
          },
        ]);
      },
      81030: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(67294),
          r = n(75007),
          o = n(51806),
          s = n(37899),
          l = n(42257),
          u = n(13301),
          c = n(88531),
          d = n(77655),
          g = n(72552),
          m = n(1982),
          h = n(20702),
          p = n(88061),
          f = n(90512),
          y = n(9177),
          _ = n.n(y),
          b = n(71890);
        let v = { portrait: "2x3", landscape: "16x9", square: "1x1" },
          x = (e) => {
            let {
                game: t,
                aspectRatio: n = "landscape",
                isResponsive: y,
                displayLabelBelow: x,
                showLabels: w = !0,
              } = e,
              [G, z] = i.useState(!1),
              [T, Z] = i.useState(0),
              k = i.useRef(null),
              { gameService: j } = i.useContext(s.Z).services,
              B = i.useRef(null),
              P = i.useContext(l.Z),
              O = (0, u.yz)(P),
              C = !P.isDesktop,
              M = i.useContext(d.Y).addViewedGames,
              R = (0, g.Z)(i.useContext(m.t));
            i.useEffect(() => {
              k.current && Z(k.current.clientWidth);
            }, []),
              i.useEffect(() => {
                let e;
                return (
                  k &&
                    k.current &&
                    ((e = k.current),
                    h.Z.get().observe(k.current, () => {
                      h.Z.get().unobserve(e), M(t.id, R);
                    })),
                  () => {
                    e && h.Z.get().unobserve(e);
                  }
                );
              }, [t.id, M, R]);
            let I = () => {
                j.prefetchGameData(t, O);
              },
              D = () => {
                !G &&
                  W &&
                  (z(!0),
                  (B.current = window.setTimeout(() => {
                    I();
                  }, 500)));
              },
              S = () => {
                W &&
                  (i.startTransition(() => {
                    z(!1);
                  }),
                  B.current && (clearTimeout(B.current), (B.current = null)));
              },
              N = y
                ? "100%"
                : ((e) => {
                    switch (n) {
                      case "landscape":
                        return e * (9 / 16);
                      case "portrait":
                        return 1.5 * e;
                      case "square":
                        return e;
                    }
                  })(b._),
              q = t.covers ? t.covers[v[n]] : t.cover,
              A = {
                quality: 85,
                width: b._,
                height: "number" == typeof N ? N : void 0,
                fit: "crop",
              },
              L = (0, r.LI)(q, A),
              W = !C && "portrait" === n,
              E = t.videos?.portraitSizes && t.videos?.portraitSizes.length > 0,
              F = (0, a.jsxs)(a.Fragment, {
                children: [
                  w &&
                    (0, a.jsx)(c.Z, {
                      videoPlaying: G,
                      gameThumbLabels: t.gameThumbLabels,
                    }),
                  (0, a.jsx)(p.Z, {
                    className: (0, f.Z)(
                      _().originalsGameLink,
                      C && _().isMobile,
                      _()[n],
                      y && _().isResponsive
                    ),
                    slug: t.slug,
                    ref: k,
                    onMouseOver: D,
                    onMouseLeave: S,
                    children: (0, a.jsxs)(a.Fragment, {
                      children: [
                        t.covers &&
                          (0, a.jsx)("img", {
                            src: (0, r.ZP)(q, A),
                            alt: t.name,
                            srcSet: L,
                            loading: C ? "lazy" : void 0,
                            decoding: C ? "async" : void 0,
                          }),
                        G &&
                          (0, a.jsx)("div", {
                            className: (0, f.Z)(
                              _().hoveredContainer,
                              E && _().withPortraitVideo
                            ),
                            children: (0, a.jsx)(o.Z, {
                              game: t,
                              videoWidth: T,
                              isPortrait: !0,
                              style: { height: E ? "100%" : void 0 },
                            }),
                          }),
                      ],
                    }),
                  }),
                ],
              });
            return x
              ? (0, a.jsx)(a.Fragment, {
                  children: (0, a.jsxs)("div", {
                    style: { position: "relative" },
                    children: [
                      F,
                      (0, a.jsx)("div", {
                        className: (0, f.Z)(
                          _().gameName,
                          C && _().isMobile,
                          _()[n],
                          y && _().isResponsive
                        ),
                        children: t.name,
                      }),
                      t.categoryName &&
                        (0, a.jsx)("div", {
                          className: (0, f.Z)(
                            _().gameCategory,
                            C && _().isMobile,
                            _()[n],
                            y && _().isResponsive
                          ),
                          children: t.categoryName,
                        }),
                    ],
                  }),
                })
              : F;
          };
        t.Z = x;
      },
      51806: function (e, t, n) {
        "use strict";
        var a = n(85893);
        n(67294);
        var i = n(36060);
        let r = (e) => {
          let {
              game: t,
              videoHeight: n,
              videoWidth: r,
              style: o,
              onCanPlayThrough: s,
              isPortrait: l,
            } = e,
            u = (0, i.Z)(t, n ? { height: n } : { width: r }, l);
          return u
            ? (0, a.jsx)("video", {
                loop: !0,
                autoPlay: !0,
                preload: "none",
                muted: !0,
                playsInline: !0,
                onCanPlayThrough: s,
                style: o,
                disableRemotePlayback: !0,
                disablePictureInPicture: !0,
                children: (0, a.jsx)("source", { src: u, type: "video/mp4" }),
              })
            : null;
        };
        t.Z = r;
      },
      18288: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(9008),
          r = n.n(i);
        n(67294);
        var o = n(46313),
          s = n(75007),
          l = n(33209);
        let u = "favicons/manifest-icon-3.png",
          c = "favicons/favicon-transparent.png",
          d = (e) => {
            let {
                title: t,
                metaDescription: n,
                canonical: i,
                alternatives: d = [],
                children: g,
              } = e,
              m = d.find((e) => {
                let { locale: t } = e;
                return t === l.ZW;
              }),
              h = (e, t, n) =>
                (0, s.ZP)(e, { width: t, height: n, fit: "crop" }),
              p = "development" === o.Z.Instance.environment;
            return (0, a.jsxs)(r(), {
              children: [
                (0, a.jsx)("title", {
                  children: `${p ? "\uD83E\uDD99 - " : ""}${t}`,
                }),
                (0, a.jsx)("link", { rel: "manifest", href: "/manifest" }),
                (0, a.jsx)("meta", { httpEquiv: "Accept-CH", content: "DPR" }),
                (0, a.jsx)("meta", { name: "description", content: n }),
                i && (0, a.jsx)("link", { rel: "canonical", href: i }),
                d.map((e) => {
                  let { href: t, locale: n } = e,
                    i = (0, l.xi)(n);
                  return (0, a.jsx)(
                    "link",
                    { rel: "alternate", hrefLang: i, href: t },
                    i
                  );
                }),
                m &&
                  (0, a.jsx)("link", {
                    rel: "alternate",
                    href: m.href,
                    hrefLang: "x-default",
                  }),
                (0, a.jsx)("meta", { name: "theme-color", content: "#ffffff" }),
                (0, a.jsx)("meta", {
                  name: "HandheldFriendly",
                  content: "true",
                }),
                (0, a.jsx)("meta", {
                  name: "mobile-web-app-capable",
                  content: "yes",
                }),
                (0, a.jsx)("meta", {
                  name: "apple-mobile-web-app-capable",
                  content: "yes",
                }),
                (0, a.jsx)("meta", {
                  name: "apple-mobile-web-app-status-bar-style",
                  content: "default",
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  href: h(u, 120, 120),
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "152x152",
                  href: h(u, 152, 152),
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "167x167",
                  href: h(u, 167, 167),
                }),
                (0, a.jsx)("link", {
                  rel: "apple-touch-icon",
                  sizes: "180x180",
                  href: h(u, 180, 180),
                }),
                (0, a.jsx)("link", {
                  rel: "mask-icon",
                  href: (0, s.ZP)("favicons/safari-pinned-tab.svg", {}, !1),
                  color: "#6842ff",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: h(c, 16, 16),
                  sizes: "16x16",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: h(c, 32, 32),
                  sizes: "32x32",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: h(c, 48, 48),
                  sizes: "48x48",
                }),
                (0, a.jsx)("link", {
                  rel: "icon",
                  href: h(c, 196, 196),
                  sizes: "196x196",
                }),
                (0, a.jsx)("meta", {
                  name: "msapplication-TileColor",
                  content: "#603cba",
                }),
                (0, a.jsx)("meta", {
                  name: "msapplication-TileImage",
                  content: h(c, 144, 144),
                }),
                g,
              ],
            });
          };
        t.Z = d;
      },
      26830: function (e, t, n) {
        "use strict";
        n.d(t, {
          $W: function () {
            return p;
          },
          LG: function () {
            return v;
          },
          Q6: function () {
            return f;
          },
          Qq: function () {
            return m;
          },
          U9: function () {
            return h;
          },
          _: function () {
            return _;
          },
          _Y: function () {
            return c;
          },
          _f: function () {
            return x;
          },
          bM: function () {
            return d;
          },
          et: function () {
            return b;
          },
          h7: function () {
            return y;
          },
          tO: function () {
            return g;
          },
        });
        var a = n(45703),
          i = n(75538),
          r = n(29338),
          o = n(46313),
          s = n(33209),
          l = n(88642);
        function u(e) {
          let t = o.Z.Instance.data.domains,
            n = t.map((t) => {
              let n = "en-US" === (0, s.Jx)(t.host),
                o = { ...i.t },
                l = new a.Z(o),
                u = l.generateHome({ page: e });
              if (!u) return null;
              let c = (0, r.Z)(t.host, u.as, {
                isMainDomain: n,
                locale: t.locale,
              }).toString();
              return { locale: t.locale, href: c.toString(), host: t.host };
            });
          return n.filter((e) => !!e);
        }
        function c(e) {
          return w((e) => e.generateCompetitions(), {}, e, "competitions");
        }
        function d(e) {
          return w((e) => e.generateScholarship(), {}, e, "scholarship");
        }
        function g(e) {
          return w((e) => e.generateRecent(), {}, e, "recent");
        }
        function m(e) {
          return w((e) => e.generateOriginals(), {}, e, "originals");
        }
        function h(e) {
          return w((e) => e.generateTags(), {}, e, "tags");
        }
        function p(e, t) {
          return w((e, t) => e.generateGame(t), { slug: e }, t, "game");
        }
        function f(e) {
          return w((e) => e.generatePrivacyPolicy(), {}, e, "privacyPolicy");
        }
        function y(e) {
          return w(
            (e) => e.generateTermsAndConditions(),
            {},
            e,
            "termsAndConditions"
          );
        }
        function _(e) {
          return w((e) => e.generateSearch(), {}, e, "search");
        }
        async function b(e, t, n, a, i) {
          if (i) return u(a);
          if (t && "hot" === t)
            return w(
              (e) => e.generatePaginatedHotGames({ page: a }),
              {},
              await n.getRouteProviderData("hotGames"),
              "hotGames"
            );
          switch (e) {
            case l.Fi:
              let r = await n.getRouteProviderData("newGames");
              return w(
                (e) => e.generatePaginatedNewGames({ page: a }),
                {},
                r,
                "newGames"
              );
            case l.sc:
            case l.K6:
              return w(
                (e) => e.generatePaginatedUpdatedGames({ page: a }),
                {},
                await n.getRouteProviderData("updatedGames"),
                "updatedGames"
              );
            default:
              return console.warn(`unexpected sorting in games ${e}`), u(a);
          }
        }
        async function v(e, t, n) {
          if (e.isCategory) {
            let a = await t.getRouteProviderData("category");
            return w(
              (e, t) => e.generateCategory(t),
              { slugTrl: e.slug, page: n },
              a,
              "category"
            );
          }
          {
            let a = await t.getRouteProviderData("tag");
            return w(
              (e, t) => e.generateTag(t),
              { slugTrl: e.slug, page: n },
              a,
              "tag"
            );
          }
        }
        function x(e, t) {
          return w((t) => t.generateAllGames(e), {}, t, "allGames");
        }
        function w(e, t, n, l) {
          let u = (function (e) {
              let t = o.Z.Instance.data.domains,
                n = e.map((e) => {
                  let n = t.find((t) => {
                    let n = (0, s.Ld)(t.locale);
                    return n === e.locale;
                  });
                  return { domain: n, routeData: e };
                });
              return n;
            })(n),
            c = u.map((n) => {
              let o = n.domain,
                u = "en-US" === (0, s.Jx)(o.host),
                c = o.locale,
                d = {
                  ...i.t,
                  [l]: n.routeData.route,
                  locale: n.routeData.locale,
                },
                g = new a.Z(d),
                m = e(g, t);
              if (!m || !n.domain) return null;
              let h = (0, r.Z)(n.domain.host, m.as, {
                isMainDomain: u,
                locale: c,
              }).toString();
              return {
                locale: n.domain.locale,
                href: h.toString(),
                host: n.domain.host,
              };
            });
          return c.filter((e) => !!e);
        }
      },
      44715: function (e, t, n) {
        "use strict";
        var a = n(85893),
          i = n(67294),
          r = n(83808);
        t.Z = function () {
          for (var e = arguments.length, t = Array(e), n = 0; n < e; n++)
            t[n] = arguments[n];
          return (e) =>
            class extends i.Component {
              static async getInitialProps(n) {
                let { trlService: a } = (0, r.b)(n);
                if (!n.req) {
                  let i = Promise.all(
                      t.map((e) => a.loadTrlMessagesToLingui(e))
                    ),
                    [r] = await Promise.all([
                      e.getInitialProps ? await e.getInitialProps(n) : {},
                      i,
                    ]);
                  return { ...r };
                }
                let i = Promise.all(t.map((e) => a.getTrlMessages(e))),
                  [o, s] = await Promise.all([
                    e.getInitialProps
                      ? e.getInitialProps(n)
                      : Promise.resolve({}),
                    i,
                  ]),
                  l = s.reduce((e, t) => Object.assign(e, t));
                return { messages: l, ...o };
              }
              render() {
                let { ...t } = this.props;
                return (0, a.jsx)(e, { ...t });
              }
            };
        };
      },
      1016: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return x;
            },
          });
        var a = n(85893),
          i = n(67294),
          r = n(94745),
          o = n(18288),
          s = n(44715),
          l = n(63306),
          u = n(61338),
          c = n(83808),
          d = n(26830),
          g = n(75007),
          m = n(81030),
          h = n(42257),
          p = n(90948);
        let f = (0, p.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              zIndex: 1,
              display: "flex",
              textAlign: "center",
              flexDirection: "column",
              alignItems: "center",
              marginTop: t(8),
              justifyContent: "flex-end",
              minHeight: 124,
              [n.down(760)]: { minHeight: "17vw" },
              [n.down("md")]: {
                "& img": {
                  width: "100%",
                  paddingLeft: t(6),
                  paddingRight: t(6),
                },
              },
              [n.down("sm")]: { marginTop: t(2) },
            };
          }),
          y = (0, p.ZP)("div")((e) => {
            let {
              theme: { spacing: t, breakpoints: n },
            } = e;
            return {
              maxWidth: 1500,
              marginTop: t(7),
              paddingLeft: t(3),
              paddingRight: t(3),
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: t(3),
              boxSizing: "content-box",
              [n.down("md")]: { maxWidth: "unset", gap: t(2) },
              [n.down("sm")]: {
                gap: t(),
                marginTop: t(3),
                paddingLeft: t(1),
                paddingRight: t(1),
              },
            };
          }),
          _ = (e) => {
            let { games: t } = e,
              { isDesktop: n } = i.useContext(h.Z);
            return (0, a.jsxs)("div", {
              style: {
                display: "flex",
                justifyContent: "center",
                flexDirection: "column",
                alignItems: "center",
              },
              children: [
                (0, a.jsx)("img", {
                  src: (0, g.ZP)("crazygames/originals_background.svg", {}, !1),
                  alt: "Originals Background",
                  loading: "lazy",
                  style: { position: "absolute", top: -25, width: "100%" },
                }),
                (0, a.jsx)(f, {
                  children: (0, a.jsx)("img", {
                    src: (0, g.ZP)("crazygames/originals_logo2.svg", {}, !1),
                    alt: "CrazyGames Originals logo",
                    loading: "lazy",
                  }),
                }),
                (0, a.jsx)(y, {
                  children: t.map((e, t) =>
                    (0, a.jsx)(
                      m.Z,
                      {
                        game: e,
                        aspectRatio: n ? "portrait" : "square",
                        displayLabelBelow: !0,
                      },
                      t
                    )
                  ),
                }),
              ],
            });
          };
        var b = n(13301);
        let v = (e) => {
          let { alternatives: t, games: n } = e,
            { i18n: s } = (0, r.mV)(),
            { routeHelper: u } = i.useContext(l.Z),
            c = u.originalsPageCanonical();
          return (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(o.Z, {
                canonical: c,
                alternatives: t,
                title: s._({ id: "originals.head.title" }),
                metaDescription: s._({ id: "originals.head.metaDescription" }),
              }),
              (0, a.jsx)(_, { games: n }),
            ],
          });
        };
        v.getInitialProps = async (e) => {
          let { routeDataService: t, gameService: n } = (0, c.b)(e),
            a = await t.getRouteProviderData("originals"),
            i = (0, d.Qq)(a),
            { deviceType: r } = (0, b.mO)(e),
            o = (0, b.yz)(r),
            s = await n.originalGames(o, !0, { page: 1, size: 30 });
          return { alternatives: i, games: s.games.items };
        };
        var x = (0, s.Z)("games", "originals")((0, u.Z)(v));
      },
      75538: function (e, t, n) {
        "use strict";
        n.d(t, {
          P: function () {
            return a;
          },
          t: function () {
            return i;
          },
        });
        let a = [
            "newGames",
            "updatedGames",
            "hotGames",
            "tags",
            "category",
            "tag",
            "game",
            "preview",
            "termsAndConditions",
            "informationForParents",
            "privacyPolicy",
            "10-anniversary",
            "recent",
            "originals",
            "search",
            "scholarship",
            "competitions",
            "pwa",
            "pwaInstall",
            "allGames",
          ],
          i = {
            newGames: "",
            updatedGames: "",
            hotGames: "",
            tags: "",
            category: "",
            tag: "",
            game: "",
            preview: "",
            termsAndConditions: "",
            privacyPolicy: "",
            "10-anniversary": "",
            recent: "",
            originals: "",
            search: "",
            pwa: "",
            pwaInstall: "",
            allGames: "",
            locale: "",
          };
      },
      9177: function (e) {
        e.exports = {
          czyButton: "OriginalsGameThumb_czyButton__HGiSF",
          "czyButton--contained--purple":
            "OriginalsGameThumb_czyButton--contained--purple__1mgrA",
          "czyButton--contained--white":
            "OriginalsGameThumb_czyButton--contained--white__UP_u_",
          "czyButton--contained--grey":
            "OriginalsGameThumb_czyButton--contained--grey__miDzN",
          "czyButton--contained--alert":
            "OriginalsGameThumb_czyButton--contained--alert__k0pG6",
          "czyButton--contained--success":
            "OriginalsGameThumb_czyButton--contained--success__fss6R",
          "czyButton--contained--black":
            "OriginalsGameThumb_czyButton--contained--black__oD9f_",
          "czyButton--contained--green-gradient":
            "OriginalsGameThumb_czyButton--contained--green-gradient__Tl9n1",
          "czyButton--outlined--purple":
            "OriginalsGameThumb_czyButton--outlined--purple__AIxwE",
          "czyButton--link--purple":
            "OriginalsGameThumb_czyButton--link--purple__g9WZ7",
          "czyButton--outlined--white":
            "OriginalsGameThumb_czyButton--outlined--white__bmTT3",
          "czyButton--link--white":
            "OriginalsGameThumb_czyButton--link--white__UNI7F",
          "czyButton--outlined--grey":
            "OriginalsGameThumb_czyButton--outlined--grey__2SGuq",
          "czyButton--link--grey":
            "OriginalsGameThumb_czyButton--link--grey__4Sqcg",
          "czyButton--outlined--alert":
            "OriginalsGameThumb_czyButton--outlined--alert__Ve35Q",
          "czyButton--link--alert":
            "OriginalsGameThumb_czyButton--link--alert__ztLX8",
          "czyButton--outlined--success":
            "OriginalsGameThumb_czyButton--outlined--success__yuAO6",
          "czyButton--link--success":
            "OriginalsGameThumb_czyButton--link--success__GAZWE",
          "czyButton--outlined":
            "OriginalsGameThumb_czyButton--outlined__5QWIW",
          "czyButton--disabled":
            "OriginalsGameThumb_czyButton--disabled__VbFHK",
          "czyButton--height50":
            "OriginalsGameThumb_czyButton--height50__fW_Kd",
          "czyButton--height34":
            "OriginalsGameThumb_czyButton--height34__DXBqJ",
          "czyButton--fullWidth":
            "OriginalsGameThumb_czyButton--fullWidth__SAkRc",
          originalsGameLink: "OriginalsGameThumb_originalsGameLink___Ihy2",
          portrait: "OriginalsGameThumb_portrait__DNcP_",
          isMobile: "OriginalsGameThumb_isMobile__9N1b9",
          square: "OriginalsGameThumb_square__YrmOM",
          landscape: "OriginalsGameThumb_landscape__SE7Z_",
          isResponsive: "OriginalsGameThumb_isResponsive__tZBH5",
          hoveredContainer: "OriginalsGameThumb_hoveredContainer__dI_YW",
          withPortraitVideo: "OriginalsGameThumb_withPortraitVideo__U5Mqm",
          buttonContainer: "OriginalsGameThumb_buttonContainer__IEqqt",
          gameName: "OriginalsGameThumb_gameName__vZql2",
          gameCategory: "OriginalsGameThumb_gameCategory__19Wud",
        };
      },
    },
    function (e) {
      e.O(0, [76287, 61338, 49774, 92888, 40179], function () {
        return e((e.s = 99407));
      }),
        (_N_E = e.O());
    },
  ]);
