!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "a5221717-fd47-4465-abe9-a0631fa10a73"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-a5221717-fd47-4465-abe9-a0631fa10a73"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [42854],
    {
      30954: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return p;
          },
        });
        var r = n(87462),
          a = n(63366),
          i = n(67294),
          o = n(33703),
          s = n(94780),
          l = n(32289),
          d = n(34867);
        function u(e) {
          return (0, d.ZP)("MuiOption", e);
        }
        (0, n(1588).Z)("MuiOption", [
          "root",
          "disabled",
          "selected",
          "highlighted",
        ]);
        var c = n(44922),
          h = n(85893);
        let f = [
            "children",
            "component",
            "disabled",
            "label",
            "slotProps",
            "slots",
            "value",
          ],
          g = i.forwardRef(function (e, t) {
            let {
                children: n,
                component: d,
                disabled: g,
                label: p,
                slotProps: m = {},
                slots: b = {},
                value: v,
              } = e,
              y = (0, a.Z)(e, f),
              w = i.useContext(l.j);
            if (!w)
              throw Error(
                "OptionUnstyled must be used within a SelectUnstyled"
              );
            let x = d || b.root || "li",
              Z = { value: v, label: p || n, disabled: g },
              C = w.getOptionState(Z),
              _ = w.getOptionProps(Z),
              M = w.listboxRef,
              k = (0, r.Z)({}, e, C),
              j = i.useRef(null),
              R = (0, o.Z)(t, j);
            i.useEffect(() => {
              if (C.highlighted) {
                if (!M.current || !j.current) return;
                let e = M.current.getBoundingClientRect(),
                  t = j.current.getBoundingClientRect();
                t.top < e.top
                  ? (M.current.scrollTop -= e.top - t.top)
                  : t.bottom > e.bottom &&
                    (M.current.scrollTop += t.bottom - e.bottom);
              }
            }, [C.highlighted, M]);
            let P = (function (e) {
                let { disabled: t, highlighted: n, selected: r } = e;
                return (0, s.Z)(
                  {
                    root: [
                      "root",
                      t && "disabled",
                      n && "highlighted",
                      r && "selected",
                    ],
                  },
                  u,
                  {}
                );
              })(k),
              S = (0, c.Z)({
                elementType: x,
                externalSlotProps: m.root,
                externalForwardedProps: y,
                additionalProps: (0, r.Z)({}, _, { ref: R }),
                className: P.root,
                ownerState: k,
              });
            return (0, h.jsx)(x, (0, r.Z)({}, S, { children: n }));
          });
        var p = i.memo(g);
      },
      88078: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return j;
          },
        });
        var r = n(63366),
          a = n(87462),
          i = n(67294),
          o = n(90512),
          s = n(70917),
          l = n(94780),
          d = n(41796),
          u = n(90948),
          c = n(71657),
          h = n(1588),
          f = n(34867);
        function g(e) {
          return (0, f.ZP)("MuiSkeleton", e);
        }
        (0, h.Z)("MuiSkeleton", [
          "root",
          "text",
          "rectangular",
          "rounded",
          "circular",
          "pulse",
          "wave",
          "withChildren",
          "fitContent",
          "heightAuto",
        ]);
        var p = n(85893);
        let m = [
            "animation",
            "className",
            "component",
            "height",
            "style",
            "variant",
            "width",
          ],
          b = (e) => e,
          v,
          y,
          w,
          x,
          Z = (e) => {
            let {
              classes: t,
              variant: n,
              animation: r,
              hasChildren: a,
              width: i,
              height: o,
            } = e;
            return (0, l.Z)(
              {
                root: [
                  "root",
                  n,
                  r,
                  a && "withChildren",
                  a && !i && "fitContent",
                  a && !o && "heightAuto",
                ],
              },
              g,
              t
            );
          },
          C = (0, s.F4)(
            v ||
              (v = b`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)
          ),
          _ = (0, s.F4)(
            y ||
              (y = b`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)
          ),
          M = (0, u.ZP)("span", {
            name: "MuiSkeleton",
            slot: "Root",
            overridesResolver: (e, t) => {
              let { ownerState: n } = e;
              return [
                t.root,
                t[n.variant],
                !1 !== n.animation && t[n.animation],
                n.hasChildren && t.withChildren,
                n.hasChildren && !n.width && t.fitContent,
                n.hasChildren && !n.height && t.heightAuto,
              ];
            },
          })(
            ({ theme: e, ownerState: t }) => {
              let n =
                  String(e.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1] ||
                  "px",
                r = parseFloat(e.shape.borderRadius);
              return (0, a.Z)(
                {
                  display: "block",
                  backgroundColor: e.vars
                    ? e.vars.palette.Skeleton.bg
                    : (0, d.Fq)(
                        e.palette.text.primary,
                        "light" === e.palette.mode ? 0.11 : 0.13
                      ),
                  height: "1.2em",
                },
                "text" === t.variant && {
                  marginTop: 0,
                  marginBottom: 0,
                  height: "auto",
                  transformOrigin: "0 55%",
                  transform: "scale(1, 0.60)",
                  borderRadius: `${r}${n}/${
                    Math.round((r / 0.6) * 10) / 10
                  }${n}`,
                  "&:empty:before": { content: '"\\00a0"' },
                },
                "circular" === t.variant && { borderRadius: "50%" },
                "rounded" === t.variant && {
                  borderRadius: (e.vars || e).shape.borderRadius,
                },
                t.hasChildren && { "& > *": { visibility: "hidden" } },
                t.hasChildren && !t.width && { maxWidth: "fit-content" },
                t.hasChildren && !t.height && { height: "auto" }
              );
            },
            ({ ownerState: e }) =>
              "pulse" === e.animation &&
              (0, s.iv)(
                w ||
                  (w = b`
      animation: ${0} 2s ease-in-out 0.5s infinite;
    `),
                C
              ),
            ({ ownerState: e, theme: t }) =>
              "wave" === e.animation &&
              (0, s.iv)(
                x ||
                  (x = b`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 2s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),
                _,
                (t.vars || t).palette.action.hover
              )
          ),
          k = i.forwardRef(function (e, t) {
            let n = (0, c.Z)({ props: e, name: "MuiSkeleton" }),
              {
                animation: i = "pulse",
                className: s,
                component: l = "span",
                height: d,
                style: u,
                variant: h = "text",
                width: f,
              } = n,
              g = (0, r.Z)(n, m),
              b = (0, a.Z)({}, n, {
                animation: i,
                component: l,
                variant: h,
                hasChildren: Boolean(g.children),
              }),
              v = Z(b);
            return (0,
            p.jsx)(M, (0, a.Z)({ as: l, ref: t, className: (0, o.Z)(v.root, s), ownerState: b }, g, { style: (0, a.Z)({ width: f, height: d }, u) }));
          });
        var j = k;
      },
      89609: function (e, t, n) {
        "use strict";
        n.d(t, {
          Z: function () {
            return l;
          },
        });
        var r = n(37078),
          a = n(61354),
          i = n(1588);
        let o = (0, i.Z)("MuiBox", ["root"]),
          s = (0, a.Z)({
            defaultClassName: o.root,
            generateClassName: r.Z.generate,
          });
        var l = s;
      },
      62478: function (e, t, n) {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/recent",
          function () {
            return n(85225);
          },
        ]);
      },
      85225: function (e, t, n) {
        "use strict";
        n.r(t),
          n.d(t, {
            default: function () {
              return P;
            },
          });
        var r = n(85893),
          a = n(67294),
          i = n(94745),
          o = n(18288),
          s = n(44715),
          l = n(2734),
          d = n(90948),
          u = n(3411);
        let c = (0, d.ZP)("div", {
            shouldForwardProp: (e) => "isDesktop" !== e,
          })((e) => {
            let {
              theme: { spacing: t, dimensions: n },
              isDesktop: r,
            } = e;
            return {
              paddingLeft: r ? t(1) : void 0,
              paddingBottom: t(2.5),
              minHeight: `calc(100vh - ${n.header.height + n.footer.height}px)`,
            };
          }),
          h = (0, d.ZP)("div")(() => ({
            "& span": { color: u.D.brand[60], fontWeight: 800 },
            "&:hover": { cursor: "pointer", opacity: 0.8 },
            "& svg": { marginBottom: -7, marginRight: 4 },
          }));
        var f = n(74112),
          g = n(31601),
          p = n(42257),
          m = n(23180),
          b = n(69037),
          v = n(74040),
          y = n(74886),
          w = n(13422),
          x = n(89555),
          Z = n(94984);
        let C = () => {
          let [e, t] = a.useState(null),
            { spacing: n } = (0, l.Z)(),
            { isDesktop: o } = a.useContext(p.Z),
            { openDrawer: s } = a.useContext(m.s9),
            { user: d, loadingUser: u } = a.useContext(v.S),
            { recent: C, loading: _ } = a.useContext(w.rh);
          a.useEffect(() => {
            u || _ || !(C.length > 0) || t(C);
          }, [C, u, _]);
          let M = (0, r.jsx)("div", {
            style: { marginTop: n(0.75) },
            onClick: () => {
              s("myGames");
            },
            children:
              !d &&
              (0, r.jsx)(h, {
                children: (0, r.jsx)(i.cC, {
                  id: "recent.createAccount.subtitle",
                  values: {
                    addLink: (0, r.jsxs)("span", {
                      children: [
                        (0, r.jsx)(b.Z, {}),
                        (0, r.jsx)(i.cC, { id: "recent.createAccount.link" }),
                      ],
                    }),
                  },
                }),
              }),
          });
          return (0, r.jsxs)(c, {
            isDesktop: o,
            children: [
              (0, r.jsx)(y.Z, {
                title: x.ag._({ id: "common.menu.recent" }),
                titleRightSlogan: d ? void 0 : M,
              }),
              (0, r.jsx)("div", {
                style: { display: "flex", alignItems: "flex-start" },
                children: (0, r.jsx)("div", {
                  style: { width: "100%", padding: n(2) },
                  children:
                    e &&
                    (0, r.jsx)(Z.H, {
                      newClickOrigin: "recent",
                      children: (0, r.jsx)(f.Z, {
                        games: e,
                        justifyContent: "center",
                        isResponsive: !0,
                        isResponsiveGrid: !0,
                        sx: g.Dx,
                        imgResponsiveSizes: g.L,
                      }),
                    }),
                }),
              }),
            ],
          });
        };
        var _ = n(63306),
          M = n(61338),
          k = n(83808),
          j = n(26830);
        let R = (e) => {
          let { alternatives: t } = e,
            { i18n: n } = (0, i.mV)(),
            { routeHelper: s } = a.useContext(_.Z),
            l = s.recentPageCanonical();
          return (0, r.jsxs)(r.Fragment, {
            children: [
              (0, r.jsx)(o.Z, {
                canonical: l,
                alternatives: t,
                title: n._({ id: "recent.head.title" }),
                metaDescription: n._({ id: "recent.head.metaDescription" }),
              }),
              (0, r.jsx)(C, {}),
            ],
          });
        };
        R.getInitialProps = async (e) => {
          let { routeDataService: t } = (0, k.b)(e),
            n = await t.getRouteProviderData("recent"),
            r = (0, j.tO)(n);
          return { alternatives: r };
        };
        var P = (0, s.Z)("recent")((0, M.Z)(R));
      },
    },
    function (e) {
      e.O(0, [76287, 61338, 45169, 29875, 49774, 92888, 40179], function () {
        return e((e.s = 62478));
      }),
        (_N_E = e.O());
    },
  ]);
