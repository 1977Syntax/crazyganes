!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "4ae53ffe-a675-4ec2-a695-a5d77973e401"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-4ae53ffe-a675-4ec2-a695-a5d77973e401"));
  } catch (e) {}
})();
var _sentryModuleMetadataGlobal =
  "undefined" != typeof window
    ? window
    : "undefined" != typeof global
    ? global
    : "undefined" != typeof self
    ? self
    : {};
(_sentryModuleMetadataGlobal._sentryModuleMetadata =
  _sentryModuleMetadataGlobal._sentryModuleMetadata || {}),
  (_sentryModuleMetadataGlobal._sentryModuleMetadata[
    new _sentryModuleMetadataGlobal.Error().stack
  ] = Object.assign(
    {},
    _sentryModuleMetadataGlobal._sentryModuleMetadata[
      new _sentryModuleMetadataGlobal.Error().stack
    ],
    { "_sentryBundlerPluginAppKey:crazygames-portal": !0 }
  )),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [74009],
    {
      89609: function (e, t, s) {
        "use strict";
        s.d(t, {
          Z: function () {
            return o;
          },
        });
        var i = s(37078),
          n = s(61354),
          a = s(1588);
        let l = (0, a.Z)("MuiBox", ["root"]),
          r = (0, n.Z)({
            defaultClassName: l.root,
            generateClassName: i.Z.generate,
          });
        var o = r;
      },
      17679: function (e, t, s) {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/tag",
          function () {
            return s(19588);
          },
        ]);
      },
      39471: function (e, t, s) {
        "use strict";
        var i = s(85893),
          n = s(67294),
          a = s(63306);
        t.Z = function (e) {
          return class extends n.Component {
            static async getInitialProps(t) {
              let s = e.getInitialProps ? await e.getInitialProps(t) : {};
              return s;
            }
            render() {
              return (0, i.jsx)(a.Z.Consumer, {
                children: (t) => {
                  let { routeHelper: s } = t;
                  return (0, i.jsx)(e, { routeHelper: s, ...this.props });
                },
              });
            }
          };
        };
      },
      19588: function (e, t, s) {
        "use strict";
        s.r(t),
          s.d(t, {
            default: function () {
              return J;
            },
          });
        var i = s(85893),
          n = s(67294),
          a = s(11163),
          l = s.n(a),
          r = s(18288),
          o = s(21519),
          d = s(94745),
          c = s(73222),
          g = s(65216),
          u = s(81792),
          m = s(98718),
          p = s(38175),
          x = s(63306);
        let h = (e) => {
          let { tag: t } = e,
            { routeHelper: s } = n.useContext(x.Z),
            { i18n: a } = (0, d.mV)(),
            { jsonLd: l, jsonLdGames: r, jsonLdCollectionPage: o } = t,
            c = (function (e) {
              try {
                let t = JSON.parse(e || "{}");
                return (t.publisher = (0, p._)(a, s)), JSON.stringify(t);
              } catch (e) {
                console.log(e);
              }
              return null;
            })(o);
          return (0, i.jsxs)(i.Fragment, {
            children: [
              (0, i.jsx)("div", { dangerouslySetInnerHTML: { __html: l } }),
              (0, i.jsx)("div", { dangerouslySetInnerHTML: { __html: r } }),
              c &&
                (0, i.jsx)("div", {
                  dangerouslySetInnerHTML: {
                    __html: `<script type="application/ld+json">${c}</script>`,
                  },
                }),
            ],
          });
        };
        var y = s(40657),
          j = s(3040),
          f = s(82921),
          v = s(74112),
          w = s(4743),
          C = s(31601),
          Z = s(74886),
          _ = s(62716),
          k = s(94984),
          G = s(2734),
          b = s(42257),
          D = s(95129),
          M = s(48715);
        let L = "7a08b313-2b2f-4042-9135-821d47ad8668",
          S = (e) => {
            let {
                metaText: t,
                linkBoostedGames: s,
                topMobileGames: a,
                topGames: l,
                tag: r,
                games: p,
                page: S,
                fillerGames: I,
              } = e,
              { spacing: T } = (0, G.Z)(),
              { routeHelper: R } = n.useContext(x.Z),
              F = n.useContext(b.Z),
              q = n.useContext(D.Z),
              E = (0, n.useCallback)(() => {
                let { description: e, showFaq: t, intro: s, title: n } = r;
                return e
                  ? (0, i.jsxs)(i.Fragment, {
                      children: [
                        (0, i.jsx)(y.A, {
                          dangerouslySetInnerHTML: { __html: e },
                        }),
                        !t &&
                          s &&
                          (0, i.jsxs)(i.Fragment, {
                            children: [
                              (0, i.jsx)("h3", {
                                children: (0, i.jsx)(d.cC, {
                                  id: "tag.faq.whatAre",
                                  values: { title: n },
                                }),
                              }),
                              (0, i.jsx)(y.A, {
                                dangerouslySetInnerHTML: { __html: s },
                              }),
                            ],
                          }),
                        (0, i.jsx)(o.Z, { sx: { my: 1, mx: 0 } }),
                      ],
                    })
                  : null;
              }, [r]),
              P = (0, n.useCallback)(
                (e, t) => {
                  let s = (0, M.K)((0, w.Z)(e, q), F.isDesktop),
                    n = (e, t) =>
                      R.tagOrCategoryPageLink(r.slug, r.isCategory, e, t);
                  return (0, i.jsx)(k.H, {
                    newClickOrigin: "grid",
                    children: (0, i.jsxs)("div", {
                      style: {
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "center",
                        alignItems: "center",
                        width: "100%",
                      },
                      children: [
                        (0, i.jsxs)("div", {
                          style: { width: "100%", padding: T(2) },
                          children: [
                            (0, i.jsx)(u.Z, {
                              children: (0, i.jsx)(v.Z, {
                                games: e.data.items,
                                justifyContent: "center",
                                slidesToLoadEagerly: c.$V,
                                customStyles: { width: "100%" },
                                isResponsive: !0,
                                imgResponsiveSizes: C.L,
                                isResponsiveGrid: !0,
                                sx: C.Dx,
                                enableInstantJoin: r.id === L,
                              }),
                            }),
                            (0, i.jsx)(m.Z, {
                              children: (0, i.jsx)(v.Z, {
                                games: t,
                                justifyContent: "center",
                                slidesToLoadEagerly: c.nY,
                                isResponsive: !0,
                                imgResponsiveSizes: C.L,
                                isResponsiveGrid: !0,
                                sx: C.Dx,
                                enableInstantJoin: r.id === L,
                              }),
                            }),
                          ],
                        }),
                        (0, i.jsx)(g.Z, { games: s, urlGenerator: n }),
                      ],
                    }),
                  });
                },
                [T, q, R, r, F.isDesktop]
              ),
              O = (0, n.useCallback)(() => {
                if (I && 0 !== I.length)
                  return (0, i.jsxs)("div", {
                    style: { padding: T(0, 2) },
                    children: [
                      (0, i.jsx)("h2", {
                        children: (0, i.jsx)(d.cC, {
                          id: "tag.fillergrid.title",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        style: {
                          display: "flex",
                          flexDirection: "column",
                          justifyContent: "center",
                          alignItems: "center",
                          width: "100%",
                          padding: T(2, 0),
                        },
                        children: (0, i.jsx)(v.Z, {
                          games: I,
                          justifyContent: "center",
                          slidesToLoadEagerly: F.isDesktop ? c.$V : c.nY,
                          customStyles: { width: "100%" },
                          isResponsive: !0,
                          imgResponsiveSizes: C.L,
                          isResponsiveGrid: !0,
                          sx: C.Dx,
                        }),
                      }),
                    ],
                  });
              }, [I, F.isDesktop, T]),
              z = (0, n.useCallback)(() => {
                if (!r.showFaq) return null;
                let e = l && (0, w.Z)(l, q);
                if (!e || !a) return null;
                let t = a.slice(0, 5),
                  n = e.slice(0, 10),
                  d = s || [];
                return (0, i.jsxs)(i.Fragment, {
                  children: [
                    (0, i.jsx)(j.Z, {
                      tag: r,
                      mobileGames: t,
                      topGames: n,
                      linkBoostedGames: d,
                    }),
                    (0, i.jsx)(f.Z, {
                      tag: r,
                      mobileGames: t,
                      topGames: n,
                      linkBoostedGames: d,
                    }),
                    (0, i.jsx)(o.Z, { sx: { my: 1, mx: 0 } }),
                  ],
                });
              }, [r, q, l, a, s]),
              A = (0, w.Z)(p, q),
              H = (p.desktop?.items || []).filter(
                (e) => !A.items.some((t) => t.slug === e.slug)
              ),
              N = A.items.concat(H),
              $ = F.isDesktop ? p.data.items.length : N.length,
              B = t || r.description || r.showFaq || r.shortDescription;
            return (0, i.jsx)(k.H, {
              newClickOrigin: `tagPage_${r.slug.en_US}`,
              children: (0, i.jsxs)(y.f, {
                isDesktop: F.isDesktop,
                children: [
                  (0, i.jsx)(h, { tag: r }),
                  (0, i.jsx)(Z.Z, {
                    tag: r,
                    title: r.title,
                    description: r.shortDescription
                      ? r.shortDescription
                      : void 0,
                  }),
                  (0, i.jsx)("div", {
                    style: { display: "flex" },
                    children: P(p, N),
                  }),
                  (0, i.jsx)("div", { children: $ <= 12 && O() }),
                  (0, i.jsx)(n.Suspense, {
                    children:
                      1 === S &&
                      B &&
                      (0, i.jsx)(_.Z, {
                        children: (0, i.jsxs)(i.Fragment, {
                          children: [E(), z(), t],
                        }),
                      }),
                  }),
                ],
              }),
            });
          };
        var I = s(44715),
          T = s(88642),
          R = s(83808),
          F = s(9305),
          q = s(13301),
          E = s(60081),
          P = s(35715),
          O = s(39471),
          z = s(61338),
          A = s(26830),
          H = s(96851),
          N = s(33209),
          $ = s(93988),
          B = s(37899);
        let U = (e) => {
          let {
              tag: t,
              metaText: s,
              page: a,
              topGames: l,
              topMobileGames: r,
              linkBoostedGames: p,
              numGamesToLoad: M,
              fillerGames: L,
              isCrawler: S,
              preloadedGames: I,
            } = e,
            [T, R] = n.useState((S && I?.data) || null),
            [F, E] = n.useState(S || !1),
            { routeHelper: O } = n.useContext(x.Z),
            z = n.useContext(b.Z),
            { modelApi: A, experimentService: H } = n.useContext(B.Z).services,
            N = (0, G.Z)(),
            U = T?.items.length ?? 0,
            V = n.useCallback(
              async (e) => {
                let t = {
                    place: "tagPage",
                    category: e.isCategory ? e.id : void 0,
                    tag: e.isCategory ? void 0 : e.id,
                    pagination: { page: a || 1, size: P.U },
                  },
                  s = (0, q.yz)(z),
                  i = (0, q.l7)(z),
                  n = await H.getModelForExpKey($.Al),
                  l = await A.getModelGames(n, s, i, t);
                return l || null;
              },
              [z, A, H, a]
            );
          n.useEffect(() => {
            S || E(!1);
          }, [a, S]),
            n.useEffect(() => {
              S ||
                (async function () {
                  let e = await V(t);
                  R(e), E(!0);
                })();
            }, [V, t, S]);
          let J = !F,
            K = () => {
              let e = n.useContext(D.Z);
              if (!t.showFaq) return null;
              let s = l && (0, w.Z)(l, e);
              if (!s || !r) return null;
              let a = r.slice(0, 5),
                d = s.slice(0, 10);
              return (0, i.jsxs)(i.Fragment, {
                children: [
                  (0, i.jsx)(j.Z, {
                    tag: t,
                    mobileGames: a,
                    topGames: d,
                    linkBoostedGames: p || [],
                  }),
                  (0, i.jsx)(f.Z, {
                    tag: t,
                    mobileGames: a,
                    topGames: d,
                    linkBoostedGames: p || [],
                  }),
                  (0, i.jsx)(o.Z, { sx: { my: 1, mx: 0 } }),
                ],
              });
            },
            Y = () => {
              let { description: e, showFaq: s, intro: n, title: a } = t;
              return e
                ? (0, i.jsxs)(i.Fragment, {
                    children: [
                      (0, i.jsx)(y.A, {
                        dangerouslySetInnerHTML: { __html: e },
                      }),
                      !s &&
                        n &&
                        (0, i.jsxs)(i.Fragment, {
                          children: [
                            (0, i.jsx)("h3", {
                              children: (0, i.jsx)(d.cC, {
                                id: "tag.faq.whatAre",
                                values: { title: a },
                              }),
                            }),
                            (0, i.jsx)(y.A, {
                              dangerouslySetInnerHTML: { __html: n },
                            }),
                          ],
                        }),
                      (0, i.jsx)(o.Z, { sx: { my: 1, mx: 0 } }),
                    ],
                  })
                : null;
            },
            X = () => {
              let e;
              if (J) {
                let t = Array.from({ length: M }, (e, t) => ({
                  name: `loading-${t}`,
                  slug: `loading-${t}`,
                  cover: `loading-${t}`,
                  videos: null,
                  loading: !0,
                }));
                e = t;
              } else e = T?.items || [];
              let t = e.concat(I?.desktop?.items || []);
              return (0, i.jsx)(k.H, {
                newClickOrigin: "grid",
                children: (0, i.jsxs)("div", {
                  style: {
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    width: "100%",
                  },
                  children: [
                    (0, i.jsxs)("div", {
                      style: { width: "100%", padding: N.spacing(2) },
                      children: [
                        (0, i.jsx)(u.Z, {
                          children: (0, i.jsx)(v.Z, {
                            games: e,
                            justifyContent: "center",
                            slidesToLoadEagerly: c.$V,
                            customStyles: { width: "100%" },
                            isResponsive: !0,
                            imgResponsiveSizes: C.L,
                            isResponsiveGrid: !0,
                            sx: C.Dx,
                          }),
                        }),
                        (0, i.jsx)(m.Z, {
                          children: (0, i.jsx)(v.Z, {
                            games: t,
                            justifyContent: "center",
                            slidesToLoadEagerly: c.nY,
                            isResponsive: !0,
                            imgResponsiveSizes: C.L,
                            isResponsiveGrid: !0,
                            sx: C.Dx,
                          }),
                        }),
                      ],
                    }),
                    (0, i.jsx)(ee, {}),
                  ],
                }),
              });
            },
            Q = () =>
              L && 0 !== L.length
                ? (0, i.jsxs)("div", {
                    style: { padding: N.spacing(0, 2) },
                    children: [
                      (0, i.jsx)("h2", {
                        children: (0, i.jsx)(d.cC, {
                          id: "tag.fillergrid.title",
                        }),
                      }),
                      (0, i.jsx)("div", {
                        style: {
                          display: "flex",
                          flexDirection: "column",
                          justifyContent: "center",
                          alignItems: "center",
                          width: "100%",
                          padding: N.spacing(2, 0),
                        },
                        children: (0, i.jsx)(v.Z, {
                          games: L,
                          justifyContent: "center",
                          slidesToLoadEagerly: z.isDesktop ? c.$V : c.nY,
                          customStyles: { width: "100%" },
                          isResponsive: !0,
                          imgResponsiveSizes: C.L,
                          isResponsiveGrid: !0,
                          sx: C.Dx,
                        }),
                      }),
                    ],
                  })
                : null,
            W = (e, s) => O.tagOrCategoryPageLink(t.slug, t.isCategory, e, s),
            ee = () => {
              let e = et(
                T || { items: [], pagination: { page: 1, size: 0 }, total: 0 }
              );
              return (0, i.jsx)(g.Z, { games: e, urlGenerator: W });
            },
            et = (e) =>
              z.isDesktop
                ? e
                : { ...e, pagination: { ...e.pagination, size: P.U } };
          return (0, i.jsx)(k.H, {
            newClickOrigin: `tagPage_${t.slug.en_US}`,
            children: (0, i.jsxs)(y.f, {
              isDesktop: z.isDesktop,
              children: [
                (0, i.jsx)(h, { tag: t }),
                (0, i.jsx)(Z.Z, {
                  tag: t,
                  title: t.title,
                  description: t.shortDescription ? t.shortDescription : void 0,
                }),
                (0, i.jsx)("div", {
                  style: { display: "flex" },
                  children: (0, i.jsx)(X, {}),
                }),
                (0, i.jsx)("div", {
                  children: !J && U <= 12 && (0, i.jsx)(Q, {}),
                }),
                1 === a &&
                  (s || t.description || t.showFaq || t.shortDescription) &&
                  (0, i.jsx)(_.Z, {
                    children: (0, i.jsxs)(i.Fragment, {
                      children: [(0, i.jsx)(Y, {}), (0, i.jsx)(K, {}), s],
                    }),
                  }),
              ],
            }),
          });
        };
        class V extends n.Component {
          static async getInitialProps(e) {
            let {
                pageService: t,
                routeDataService: s,
                crawlerService: i,
              } = (0, R.b)(e),
              { deviceType: n } = (0, q.mO)(e),
              a = n.isMobile,
              r = (0, q.yz)(n),
              o = (e.query && e.query[T.kK]) || "tag",
              d = e.query && e.query[T.pu],
              c = (e.query && e.query[T.Y7]) || "default",
              g = Number((e.query && e.query[T.Fh]) || 1),
              u = a ? P.Zj : P.U,
              m = Number((e.query && e.query[T.AB]) || u),
              p = n.isTablet ? P.JV : P.mZ,
              x = n.isDesktop ? P.wl : p,
              h = await t.tagPage(
                o,
                d,
                { page: g, size: m },
                x,
                p,
                r,
                P.mk,
                P.U,
                c
              ),
              y = "true" === e.query[T.cv],
              {
                tag: j,
                games: f,
                topGames: v,
                topMobileGames: w,
                linkBoostedGames: C,
                fillerGames: Z,
              } = h,
              _ =
                y && c === T.sc
                  ? await i.getSwappedTagCategoryGamesForCrawler(h, n, g)
                  : f;
            if (j.isArchived) {
              let t = e.res,
                i = (0, N.Kd)(e),
                n = await s.getLocaleRouteProviderData(i),
                a = H.Z.createFromContext(e, n),
                r = a.homePageLink();
              t
                ? (t.writeHead(301, { Location: r.as }), t.end())
                : l().push(r.href, r.as);
            }
            let k = Math.ceil(_.data.total / m);
            if (!j.isArchived && g > k)
              throw new F.Z(404, "Incorrect pagination");
            if (
              !j.isArchived &&
              0 === _.data.items.length &&
              0 === (_.desktop?.items.length || 0)
            )
              throw new F.Z(404, "No games found");
            let G = await (0, A.LG)(j, s, g);
            return {
              games: _,
              tag: j,
              topGames: v,
              topMobileGames: w,
              sorting: c,
              page: g,
              linkBoostedGames: C,
              alternatives: G,
              fillerGames: Z,
              isCrawler: y,
            };
          }
          render() {
            var e;
            let {
                i18n: t,
                games: s,
                tag: n,
                topGames: a,
                topMobileGames: l,
                routeHelper: o,
                page: d,
                sorting: c,
                linkBoostedGames: g,
                alternatives: u,
                fillerGames: m,
                isCrawler: p,
              } = this.props,
              x = {
                game: (s.data.items[0] || { name: "" }).name,
                title: n.title,
              },
              h = n.metaDescription
                ? n.metaDescription
                : t._("tag.head.metaDescription", x),
              y = n.metaTitle
                ? ((e = n.metaTitle), 1 === d ? e : `${e} - Page ${d}`)
                : t._("tag.head.title", { title: n.title, pageNumber: d }),
              j = void 0 === c || c === T.sc,
              f = o.tagOrCategoryPageCanonical(n.slug, n.isCategory, d),
              v = this.facebookOGCover();
            return (0, i.jsxs)(i.Fragment, {
              children: [
                (0, i.jsx)(r.Z, {
                  canonical: f,
                  title: y,
                  metaDescription: h,
                  alternatives: u,
                }),
                v &&
                  (0, i.jsx)(E.Z, {
                    canonical: f,
                    title: y,
                    description: h,
                    imageUrl: v,
                  }),
                j
                  ? (0, i.jsx)(
                      U,
                      {
                        numGamesToLoad: s.data.items.length,
                        tag: n,
                        topGames: a,
                        topMobileGames: l,
                        page: d,
                        metaText: h,
                        linkBoostedGames: g,
                        fillerGames: m,
                        isCrawler: p,
                        preloadedGames: s,
                      },
                      n.name
                    )
                  : (0, i.jsx)(
                      S,
                      {
                        games: s,
                        tag: n,
                        topGames: a,
                        topMobileGames: l,
                        page: d,
                        metaText: h,
                        linkBoostedGames: g,
                        fillerGames: m,
                      },
                      n.name
                    ),
              ],
            });
          }
          facebookOGCover() {
            let { games: e } = this.props;
            return 0 !== e.data.items.length
              ? e.data.items[0].cover
              : e.desktop && 0 !== e.desktop.items.length
              ? e.desktop.items[0].cover
              : null;
          }
        }
        var J = (0, O.Z)((0, I.Z)("tag", "carousels")((0, z.Z)(V)));
      },
    },
    function (e) {
      e.O(
        0,
        [76287, 61338, 45169, 29875, 68419, 49774, 92888, 40179],
        function () {
          return e((e.s = 17679));
        }
      ),
        (_N_E = e.O());
    },
  ]);
